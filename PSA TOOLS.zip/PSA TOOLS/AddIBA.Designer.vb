﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AddIBA
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dtm_txt_LastPingDatetime = New System.Windows.Forms.DateTimePicker()
        Me.dtm_LastPingFalseDatetime = New System.Windows.Forms.DateTimePicker()
        Me.txt_AssignedAsset = New System.Windows.Forms.TextBox()
        Me.txt_NoOfFile__Dest = New System.Windows.Forms.TextBox()
        Me.txt_NoOfFile_Dest = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txt_Owner_PNo = New System.Windows.Forms.TextBox()
        Me.txt_PingStatus = New System.Windows.Forms.TextBox()
        Me.txt_AssignedAssetIp = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txt_NoOfFile_Source = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btn_Add = New System.Windows.Forms.Button()
        Me.txt_DestinationLocation = New System.Windows.Forms.TextBox()
        Me.txt_SourceLocation = New System.Windows.Forms.TextBox()
        Me.txt_PlantName = New System.Windows.Forms.TextBox()
        Me.txt_Area = New System.Windows.Forms.TextBox()
        Me.IP_Address = New System.Windows.Forms.Label()
        Me.Second_Owner_Name = New System.Windows.Forms.Label()
        Me.Owner_Name = New System.Windows.Forms.Label()
        Me.Asset_id = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'dtm_txt_LastPingDatetime
        '
        Me.dtm_txt_LastPingDatetime.Location = New System.Drawing.Point(708, 325)
        Me.dtm_txt_LastPingDatetime.Name = "dtm_txt_LastPingDatetime"
        Me.dtm_txt_LastPingDatetime.Size = New System.Drawing.Size(270, 20)
        Me.dtm_txt_LastPingDatetime.TabIndex = 94
        '
        'dtm_LastPingFalseDatetime
        '
        Me.dtm_LastPingFalseDatetime.Location = New System.Drawing.Point(239, 328)
        Me.dtm_LastPingFalseDatetime.Name = "dtm_LastPingFalseDatetime"
        Me.dtm_LastPingFalseDatetime.Size = New System.Drawing.Size(270, 20)
        Me.dtm_LastPingFalseDatetime.TabIndex = 93
        '
        'txt_AssignedAsset
        '
        Me.txt_AssignedAsset.Location = New System.Drawing.Point(708, 105)
        Me.txt_AssignedAsset.Name = "txt_AssignedAsset"
        Me.txt_AssignedAsset.Size = New System.Drawing.Size(270, 20)
        Me.txt_AssignedAsset.TabIndex = 92
        '
        'txt_NoOfFile__Dest
        '
        Me.txt_NoOfFile__Dest.Location = New System.Drawing.Point(708, 55)
        Me.txt_NoOfFile__Dest.Name = "txt_NoOfFile__Dest"
        Me.txt_NoOfFile__Dest.Size = New System.Drawing.Size(270, 20)
        Me.txt_NoOfFile__Dest.TabIndex = 91
        '
        'txt_NoOfFile_Dest
        '
        Me.txt_NoOfFile_Dest.AutoSize = True
        Me.txt_NoOfFile_Dest.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_NoOfFile_Dest.Location = New System.Drawing.Point(525, 56)
        Me.txt_NoOfFile_Dest.Name = "txt_NoOfFile_Dest"
        Me.txt_NoOfFile_Dest.Size = New System.Drawing.Size(110, 19)
        Me.txt_NoOfFile_Dest.TabIndex = 90
        Me.txt_NoOfFile_Dest.Text = "NoOfFile_Dest"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(57, 330)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(176, 19)
        Me.Label2.TabIndex = 89
        Me.Label2.Text = "LastPingFalsedatetime"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(525, 106)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(112, 19)
        Me.Label3.TabIndex = 88
        Me.Label3.Text = "AssignedAsset"
        '
        'txt_Owner_PNo
        '
        Me.txt_Owner_PNo.Location = New System.Drawing.Point(708, 267)
        Me.txt_Owner_PNo.Name = "txt_Owner_PNo"
        Me.txt_Owner_PNo.Size = New System.Drawing.Size(270, 20)
        Me.txt_Owner_PNo.TabIndex = 87
        '
        'txt_PingStatus
        '
        Me.txt_PingStatus.Location = New System.Drawing.Point(708, 208)
        Me.txt_PingStatus.Name = "txt_PingStatus"
        Me.txt_PingStatus.Size = New System.Drawing.Size(270, 20)
        Me.txt_PingStatus.TabIndex = 86
        '
        'txt_AssignedAssetIp
        '
        Me.txt_AssignedAssetIp.Location = New System.Drawing.Point(708, 155)
        Me.txt_AssignedAssetIp.Name = "txt_AssignedAssetIp"
        Me.txt_AssignedAssetIp.Size = New System.Drawing.Size(270, 20)
        Me.txt_AssignedAssetIp.TabIndex = 85
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(525, 327)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(140, 19)
        Me.Label4.TabIndex = 84
        Me.Label4.Text = "LastPingDatetime"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(525, 268)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(94, 19)
        Me.Label5.TabIndex = 83
        Me.Label5.Text = "Owner_PNo"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(525, 207)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(88, 19)
        Me.Label6.TabIndex = 82
        Me.Label6.Text = "PingStatus"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(525, 156)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(128, 19)
        Me.Label7.TabIndex = 81
        Me.Label7.Text = "AssignedAssetIp"
        '
        'txt_NoOfFile_Source
        '
        Me.txt_NoOfFile_Source.Location = New System.Drawing.Point(239, 270)
        Me.txt_NoOfFile_Source.Name = "txt_NoOfFile_Source"
        Me.txt_NoOfFile_Source.Size = New System.Drawing.Size(270, 20)
        Me.txt_NoOfFile_Source.TabIndex = 80
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(56, 271)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(128, 19)
        Me.Label1.TabIndex = 79
        Me.Label1.Text = "NoOfFile_Source"
        '
        'btn_Add
        '
        Me.btn_Add.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Add.Location = New System.Drawing.Point(415, 398)
        Me.btn_Add.Name = "btn_Add"
        Me.btn_Add.Size = New System.Drawing.Size(284, 27)
        Me.btn_Add.TabIndex = 78
        Me.btn_Add.Text = "Add"
        Me.btn_Add.UseVisualStyleBackColor = True
        '
        'txt_DestinationLocation
        '
        Me.txt_DestinationLocation.Location = New System.Drawing.Point(239, 213)
        Me.txt_DestinationLocation.Name = "txt_DestinationLocation"
        Me.txt_DestinationLocation.Size = New System.Drawing.Size(270, 20)
        Me.txt_DestinationLocation.TabIndex = 77
        '
        'txt_SourceLocation
        '
        Me.txt_SourceLocation.Location = New System.Drawing.Point(239, 152)
        Me.txt_SourceLocation.Name = "txt_SourceLocation"
        Me.txt_SourceLocation.Size = New System.Drawing.Size(270, 20)
        Me.txt_SourceLocation.TabIndex = 76
        '
        'txt_PlantName
        '
        Me.txt_PlantName.Location = New System.Drawing.Point(239, 106)
        Me.txt_PlantName.Name = "txt_PlantName"
        Me.txt_PlantName.Size = New System.Drawing.Size(270, 20)
        Me.txt_PlantName.TabIndex = 75
        '
        'txt_Area
        '
        Me.txt_Area.Location = New System.Drawing.Point(239, 53)
        Me.txt_Area.Name = "txt_Area"
        Me.txt_Area.Size = New System.Drawing.Size(270, 20)
        Me.txt_Area.TabIndex = 74
        '
        'IP_Address
        '
        Me.IP_Address.AutoSize = True
        Me.IP_Address.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IP_Address.Location = New System.Drawing.Point(56, 212)
        Me.IP_Address.Name = "IP_Address"
        Me.IP_Address.Size = New System.Drawing.Size(160, 19)
        Me.IP_Address.TabIndex = 73
        Me.IP_Address.Text = "DestinationLocation"
        '
        'Second_Owner_Name
        '
        Me.Second_Owner_Name.AutoSize = True
        Me.Second_Owner_Name.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Second_Owner_Name.Location = New System.Drawing.Point(56, 153)
        Me.Second_Owner_Name.Name = "Second_Owner_Name"
        Me.Second_Owner_Name.Size = New System.Drawing.Size(124, 19)
        Me.Second_Owner_Name.TabIndex = 72
        Me.Second_Owner_Name.Text = "SourceLocation"
        '
        'Owner_Name
        '
        Me.Owner_Name.AutoSize = True
        Me.Owner_Name.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Owner_Name.Location = New System.Drawing.Point(56, 105)
        Me.Owner_Name.Name = "Owner_Name"
        Me.Owner_Name.Size = New System.Drawing.Size(91, 19)
        Me.Owner_Name.TabIndex = 71
        Me.Owner_Name.Text = "PlantName"
        '
        'Asset_id
        '
        Me.Asset_id.AutoSize = True
        Me.Asset_id.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Asset_id.Location = New System.Drawing.Point(56, 54)
        Me.Asset_id.Name = "Asset_id"
        Me.Asset_id.Size = New System.Drawing.Size(43, 19)
        Me.Asset_id.TabIndex = 70
        Me.Asset_id.Text = "Area"
        '
        'AddIBA
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1173, 601)
        Me.Controls.Add(Me.dtm_txt_LastPingDatetime)
        Me.Controls.Add(Me.dtm_LastPingFalseDatetime)
        Me.Controls.Add(Me.txt_AssignedAsset)
        Me.Controls.Add(Me.txt_NoOfFile__Dest)
        Me.Controls.Add(Me.txt_NoOfFile_Dest)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txt_Owner_PNo)
        Me.Controls.Add(Me.txt_PingStatus)
        Me.Controls.Add(Me.txt_AssignedAssetIp)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txt_NoOfFile_Source)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btn_Add)
        Me.Controls.Add(Me.txt_DestinationLocation)
        Me.Controls.Add(Me.txt_SourceLocation)
        Me.Controls.Add(Me.txt_PlantName)
        Me.Controls.Add(Me.txt_Area)
        Me.Controls.Add(Me.IP_Address)
        Me.Controls.Add(Me.Second_Owner_Name)
        Me.Controls.Add(Me.Owner_Name)
        Me.Controls.Add(Me.Asset_id)
        Me.Name = "AddIBA"
        Me.Text = "AddIBA"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dtm_txt_LastPingDatetime As DateTimePicker
    Friend WithEvents dtm_LastPingFalseDatetime As DateTimePicker
    Friend WithEvents txt_AssignedAsset As TextBox
    Friend WithEvents txt_NoOfFile__Dest As TextBox
    Friend WithEvents txt_NoOfFile_Dest As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txt_Owner_PNo As TextBox
    Friend WithEvents txt_PingStatus As TextBox
    Friend WithEvents txt_AssignedAssetIp As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents txt_NoOfFile_Source As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btn_Add As Button
    Friend WithEvents txt_DestinationLocation As TextBox
    Friend WithEvents txt_SourceLocation As TextBox
    Friend WithEvents txt_PlantName As TextBox
    Friend WithEvents txt_Area As TextBox
    Friend WithEvents IP_Address As Label
    Friend WithEvents Second_Owner_Name As Label
    Friend WithEvents Owner_Name As Label
    Friend WithEvents Asset_id As Label
End Class
