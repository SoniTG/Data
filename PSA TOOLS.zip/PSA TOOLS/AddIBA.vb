﻿
Imports System.Data.SqlClient
Imports System.IO
Imports Microsoft.Office.Interop
Imports System.Data.SqlClient.SqlException
Imports System.Data
Imports ClosedXML.Excel
Public Class AddIBA
    Dim con As New SqlConnection
    Dim cmd As New SqlCommand
    Private Sub btn_Add_Click(sender As Object, e As EventArgs) Handles btn_Add.Click
        If txt_Area.Text = Nothing Then
            MsgBox("Please Fill Area data")
        ElseIf txt_PlantName.Text = Nothing Then
            MsgBox("Please Fill PlantName data")
        ElseIf txt_SourceLocation.Text = Nothing Then
            MsgBox("Please Fill SourceLocation data")
        ElseIf txt_DestinationLocation.Text = Nothing Then
            MsgBox("Please Fill DestinationLocation data")
        ElseIf txt_AssignedAsset.Text = Nothing Then
            MsgBox("Please Fill AssignedAsset data")
        Else
            Try
                con = New SqlConnection("Server=176.0.0.60\lptgsqldev;Database=PSA_TOOLS;User Id=153521;Password=Welcome@135;")

                cmd = New SqlCommand("INSERT INTO [dbo].[IBA_File_Monitoring] 
           ([Area]
      ,[PlantName]
      ,[SourceLocation]
      ,[DestinationLocation]
      ,[NoOfFile_Source]
      ,[NoOfFile_Dest]
      ,[AssignedAsset]
      ,[AssignedAssetIp]
      ,[PingStatus]
      ,[Owner_PNo]
      ,[LastPingDatetime]
      ,[LastPingFalsedatetime])
            VALUES
           ('" + txt_Area.Text + "','" + txt_PlantName.Text + "','" + txt_SourceLocation.Text + "','" + txt_DestinationLocation.Text + "','" + txt_NoOfFile_Source.Text + "',
            '" + txt_NoOfFile__Dest.Text + "','" + txt_AssignedAsset.Text + "','" + txt_AssignedAssetIp.Text + "','" + txt_PingStatus.Text + "','" + txt_Owner_PNo.Text + "','" + dtm_LastPingFalseDatetime.Text + "',
            '" + dtm_txt_LastPingDatetime.Text + "')", con)
                If con.State = ConnectionState.Closed Then con.Open()

                cmd.ExecuteNonQuery()
                MsgBox("Data Inserted")
                Me.Close()
                Ip_SERVER.Close()
                Ip_SERVER.Show()
            Catch ex As Exception
                MsgBox("DATA Is Not Add!")
            End Try


        End If


    End Sub
End Class