﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Add_Edit
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Asset_id = New System.Windows.Forms.Label()
        Me.Owner_Name = New System.Windows.Forms.Label()
        Me.Second_Owner_Name = New System.Windows.Forms.Label()
        Me.IP_Address = New System.Windows.Forms.Label()
        Me.txt_Asset_id = New System.Windows.Forms.TextBox()
        Me.txt_Owner_Name = New System.Windows.Forms.TextBox()
        Me.txt_Second_Owner_Name = New System.Windows.Forms.TextBox()
        Me.txt_IP_Address = New System.Windows.Forms.TextBox()
        Me.btn_Add = New System.Windows.Forms.Button()
        Me.lbl_Id = New System.Windows.Forms.Label()
        Me.txt_ID = New System.Windows.Forms.TextBox()
        Me.txt_Third_User_Name = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Asset_id
        '
        Me.Asset_id.AutoSize = True
        Me.Asset_id.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Asset_id.Location = New System.Drawing.Point(220, 130)
        Me.Asset_id.Name = "Asset_id"
        Me.Asset_id.Size = New System.Drawing.Size(67, 19)
        Me.Asset_id.TabIndex = 0
        Me.Asset_id.Text = "Asset Id"
        '
        'Owner_Name
        '
        Me.Owner_Name.AutoSize = True
        Me.Owner_Name.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Owner_Name.Location = New System.Drawing.Point(220, 187)
        Me.Owner_Name.Name = "Owner_Name"
        Me.Owner_Name.Size = New System.Drawing.Size(104, 19)
        Me.Owner_Name.TabIndex = 1
        Me.Owner_Name.Text = "Owner Name"
        '
        'Second_Owner_Name
        '
        Me.Second_Owner_Name.AutoSize = True
        Me.Second_Owner_Name.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Second_Owner_Name.Location = New System.Drawing.Point(220, 242)
        Me.Second_Owner_Name.Name = "Second_Owner_Name"
        Me.Second_Owner_Name.Size = New System.Drawing.Size(161, 19)
        Me.Second_Owner_Name.TabIndex = 2
        Me.Second_Owner_Name.Text = "Second Owner Name"
        '
        'IP_Address
        '
        Me.IP_Address.AutoSize = True
        Me.IP_Address.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IP_Address.Location = New System.Drawing.Point(220, 301)
        Me.IP_Address.Name = "IP_Address"
        Me.IP_Address.Size = New System.Drawing.Size(88, 19)
        Me.IP_Address.TabIndex = 3
        Me.IP_Address.Text = "IP Address"
        '
        'txt_Asset_id
        '
        Me.txt_Asset_id.Location = New System.Drawing.Point(403, 129)
        Me.txt_Asset_id.Name = "txt_Asset_id"
        Me.txt_Asset_id.Size = New System.Drawing.Size(270, 20)
        Me.txt_Asset_id.TabIndex = 4
        '
        'txt_Owner_Name
        '
        Me.txt_Owner_Name.Location = New System.Drawing.Point(403, 186)
        Me.txt_Owner_Name.Name = "txt_Owner_Name"
        Me.txt_Owner_Name.Size = New System.Drawing.Size(270, 20)
        Me.txt_Owner_Name.TabIndex = 5
        '
        'txt_Second_Owner_Name
        '
        Me.txt_Second_Owner_Name.Location = New System.Drawing.Point(403, 241)
        Me.txt_Second_Owner_Name.Name = "txt_Second_Owner_Name"
        Me.txt_Second_Owner_Name.Size = New System.Drawing.Size(270, 20)
        Me.txt_Second_Owner_Name.TabIndex = 6
        '
        'txt_IP_Address
        '
        Me.txt_IP_Address.Location = New System.Drawing.Point(403, 300)
        Me.txt_IP_Address.Name = "txt_IP_Address"
        Me.txt_IP_Address.Size = New System.Drawing.Size(270, 20)
        Me.txt_IP_Address.TabIndex = 7
        '
        'btn_Add
        '
        Me.btn_Add.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Add.Location = New System.Drawing.Point(403, 394)
        Me.btn_Add.Name = "btn_Add"
        Me.btn_Add.Size = New System.Drawing.Size(128, 27)
        Me.btn_Add.TabIndex = 8
        Me.btn_Add.Text = "Save"
        Me.btn_Add.UseVisualStyleBackColor = True
        '
        'lbl_Id
        '
        Me.lbl_Id.AutoSize = True
        Me.lbl_Id.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Id.Location = New System.Drawing.Point(220, 72)
        Me.lbl_Id.Name = "lbl_Id"
        Me.lbl_Id.Size = New System.Drawing.Size(26, 19)
        Me.lbl_Id.TabIndex = 9
        Me.lbl_Id.Text = "ID"
        '
        'txt_ID
        '
        Me.txt_ID.Location = New System.Drawing.Point(403, 71)
        Me.txt_ID.Name = "txt_ID"
        Me.txt_ID.Size = New System.Drawing.Size(270, 20)
        Me.txt_ID.TabIndex = 10
        '
        'txt_Third_User_Name
        '
        Me.txt_Third_User_Name.Location = New System.Drawing.Point(403, 352)
        Me.txt_Third_User_Name.Name = "txt_Third_User_Name"
        Me.txt_Third_User_Name.Size = New System.Drawing.Size(270, 20)
        Me.txt_Third_User_Name.TabIndex = 27
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(220, 353)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(134, 19)
        Me.Label1.TabIndex = 26
        Me.Label1.Text = "Third User Name"
        '
        'Add_Edit
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1066, 496)
        Me.Controls.Add(Me.txt_Third_User_Name)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txt_ID)
        Me.Controls.Add(Me.lbl_Id)
        Me.Controls.Add(Me.btn_Add)
        Me.Controls.Add(Me.txt_IP_Address)
        Me.Controls.Add(Me.txt_Second_Owner_Name)
        Me.Controls.Add(Me.txt_Owner_Name)
        Me.Controls.Add(Me.txt_Asset_id)
        Me.Controls.Add(Me.IP_Address)
        Me.Controls.Add(Me.Second_Owner_Name)
        Me.Controls.Add(Me.Owner_Name)
        Me.Controls.Add(Me.Asset_id)
        Me.Name = "Add_Edit"
        Me.Text = "Add_Edit"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Asset_id As Label
    Friend WithEvents Owner_Name As Label
    Friend WithEvents Second_Owner_Name As Label
    Friend WithEvents IP_Address As Label
    Friend WithEvents txt_Asset_id As TextBox
    Friend WithEvents txt_Owner_Name As TextBox
    Friend WithEvents txt_Second_Owner_Name As TextBox
    Friend WithEvents txt_IP_Address As TextBox
    Friend WithEvents btn_Add As Button
    Friend WithEvents lbl_Id As Label
    Friend WithEvents txt_ID As TextBox
    Friend WithEvents txt_Third_User_Name As TextBox
    Friend WithEvents Label1 As Label
End Class
