﻿
Imports System.Data.SqlClient
Imports System.IO
Imports Microsoft.Office.Interop
Imports System.Data.SqlClient.SqlException
Imports System.Data
Imports ClosedXML.Excel
Public Class Add_Edit

    Dim con As New SqlConnection
    Dim cmd As New SqlCommand
    Private Sub btn_Add_Click(sender As Object, e As EventArgs) Handles btn_Add.Click

        If txt_ID.Text = Nothing Or txt_Asset_id.Text = Nothing Or txt_IP_Address.Text = Nothing Or txt_Owner_Name.Text = Nothing Or txt_Second_Owner_Name.Text = Nothing Or txt_Third_User_Name.Text = Nothing Then

            MsgBox("Please fill the data")
        Else

            Try
                con = New SqlConnection("Server=176.0.0.60\lptgsqldev;Database=PSA_TOOLS;User Id=153521;Password=Welcome@135;")

                cmd = New SqlCommand("INSERT INTO [dbo].[T_ASSET_MONITOR] 
                ([ID]
                ,[AssetId]
                ,[OwnerName]
                ,[SecondOwnerName]
                ,[IPAddress]
                ,[ThirdUserName])
                 VALUES
                ('" + txt_ID.Text + "','" + txt_Asset_id.Text + "','" + txt_Owner_Name.Text + "','" + txt_Second_Owner_Name.Text + "','" + txt_IP_Address.Text + "','" + txt_Third_User_Name.Text + "')", con)

                con.Open()
                cmd.ExecuteNonQuery()
                MsgBox("Data Inserted")
                Me.Close()
                System_Monitoring.Close()
                System_Monitoring.Show()
            Catch ex As Exception
                MsgBox(ex.Message)
                ' MsgBox("PLEASE CHANGE ID NO.")
            End Try
        End If





    End Sub






End Class