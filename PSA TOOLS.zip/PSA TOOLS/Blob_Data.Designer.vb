﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Blob_Data
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Select_database = New System.Windows.Forms.Label()
        Me.Select_column_name = New System.Windows.Forms.Label()
        Me.Select_blob_data = New System.Windows.Forms.Label()
        Me.Select_Table = New System.Windows.Forms.Label()
        Me.cmb_Select_database = New System.Windows.Forms.ComboBox()
        Me.cmb_Select_table = New System.Windows.Forms.ComboBox()
        Me.cmb_Select_blob_data = New System.Windows.Forms.ComboBox()
        Me.cmb_Select_column_name = New System.Windows.Forms.ComboBox()
        Me.DgvBlobData = New System.Windows.Forms.DataGridView()
        Me.btn_Export_save = New System.Windows.Forms.Button()
        Me.btn_Show = New System.Windows.Forms.Button()
        Me.Chechlist_select_data = New System.Windows.Forms.CheckedListBox()
        Me.Select_data = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txt_SearchText = New System.Windows.Forms.TextBox()
        Me.btn_connection = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txt_password = New System.Windows.Forms.TextBox()
        Me.txt_user_id = New System.Windows.Forms.TextBox()
        Me.txt_server = New System.Windows.Forms.TextBox()
        CType(Me.DgvBlobData, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Select_database
        '
        Me.Select_database.AutoSize = True
        Me.Select_database.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Select_database.Location = New System.Drawing.Point(463, 44)
        Me.Select_database.Name = "Select_database"
        Me.Select_database.Size = New System.Drawing.Size(124, 19)
        Me.Select_database.TabIndex = 33
        Me.Select_database.Text = "Select Database"
        '
        'Select_column_name
        '
        Me.Select_column_name.AutoSize = True
        Me.Select_column_name.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Select_column_name.Location = New System.Drawing.Point(859, 81)
        Me.Select_column_name.Name = "Select_column_name"
        Me.Select_column_name.Size = New System.Drawing.Size(159, 19)
        Me.Select_column_name.TabIndex = 26
        Me.Select_column_name.Text = "Select Column Name"
        '
        'Select_blob_data
        '
        Me.Select_blob_data.AutoSize = True
        Me.Select_blob_data.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Select_blob_data.Location = New System.Drawing.Point(463, 85)
        Me.Select_blob_data.Name = "Select_blob_data"
        Me.Select_blob_data.Size = New System.Drawing.Size(128, 19)
        Me.Select_blob_data.TabIndex = 25
        Me.Select_blob_data.Text = "Select Blob Data"
        '
        'Select_Table
        '
        Me.Select_Table.AutoSize = True
        Me.Select_Table.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Select_Table.Location = New System.Drawing.Point(859, 40)
        Me.Select_Table.Name = "Select_Table"
        Me.Select_Table.Size = New System.Drawing.Size(96, 19)
        Me.Select_Table.TabIndex = 24
        Me.Select_Table.Text = "Select Table"
        '
        'cmb_Select_database
        '
        Me.cmb_Select_database.Font = New System.Drawing.Font("Cambria", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_Select_database.ForeColor = System.Drawing.Color.Black
        Me.cmb_Select_database.FormattingEnabled = True
        Me.cmb_Select_database.Location = New System.Drawing.Point(628, 40)
        Me.cmb_Select_database.Name = "cmb_Select_database"
        Me.cmb_Select_database.Size = New System.Drawing.Size(202, 23)
        Me.cmb_Select_database.TabIndex = 35
        '
        'cmb_Select_table
        '
        Me.cmb_Select_table.Font = New System.Drawing.Font("Cambria", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_Select_table.FormattingEnabled = True
        Me.cmb_Select_table.Location = New System.Drawing.Point(1024, 36)
        Me.cmb_Select_table.Name = "cmb_Select_table"
        Me.cmb_Select_table.Size = New System.Drawing.Size(186, 23)
        Me.cmb_Select_table.TabIndex = 36
        '
        'cmb_Select_blob_data
        '
        Me.cmb_Select_blob_data.Font = New System.Drawing.Font("Cambria", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_Select_blob_data.FormattingEnabled = True
        Me.cmb_Select_blob_data.Location = New System.Drawing.Point(628, 81)
        Me.cmb_Select_blob_data.Name = "cmb_Select_blob_data"
        Me.cmb_Select_blob_data.Size = New System.Drawing.Size(202, 23)
        Me.cmb_Select_blob_data.TabIndex = 37
        '
        'cmb_Select_column_name
        '
        Me.cmb_Select_column_name.Font = New System.Drawing.Font("Cambria", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_Select_column_name.FormattingEnabled = True
        Me.cmb_Select_column_name.Location = New System.Drawing.Point(1024, 77)
        Me.cmb_Select_column_name.Name = "cmb_Select_column_name"
        Me.cmb_Select_column_name.Size = New System.Drawing.Size(186, 23)
        Me.cmb_Select_column_name.TabIndex = 38
        '
        'DgvBlobData
        '
        Me.DgvBlobData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgvBlobData.Location = New System.Drawing.Point(21, 243)
        Me.DgvBlobData.Name = "DgvBlobData"
        Me.DgvBlobData.Size = New System.Drawing.Size(1206, 441)
        Me.DgvBlobData.TabIndex = 40
        '
        'btn_Export_save
        '
        Me.btn_Export_save.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Export_save.Location = New System.Drawing.Point(863, 167)
        Me.btn_Export_save.Name = "btn_Export_save"
        Me.btn_Export_save.Size = New System.Drawing.Size(115, 29)
        Me.btn_Export_save.TabIndex = 43
        Me.btn_Export_save.Text = "Save Data"
        Me.btn_Export_save.UseVisualStyleBackColor = True
        '
        'btn_Show
        '
        Me.btn_Show.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Show.Location = New System.Drawing.Point(863, 118)
        Me.btn_Show.Name = "btn_Show"
        Me.btn_Show.Size = New System.Drawing.Size(115, 26)
        Me.btn_Show.TabIndex = 32
        Me.btn_Show.Text = "Show Data"
        Me.btn_Show.UseVisualStyleBackColor = True
        '
        'Chechlist_select_data
        '
        Me.Chechlist_select_data.Font = New System.Drawing.Font("Cambria", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Chechlist_select_data.FormattingEnabled = True
        Me.Chechlist_select_data.Location = New System.Drawing.Point(121, 124)
        Me.Chechlist_select_data.Name = "Chechlist_select_data"
        Me.Chechlist_select_data.Size = New System.Drawing.Size(266, 94)
        Me.Chechlist_select_data.TabIndex = 44
        '
        'Select_data
        '
        Me.Select_data.AutoSize = True
        Me.Select_data.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Select_data.ForeColor = System.Drawing.Color.Black
        Me.Select_data.Location = New System.Drawing.Point(20, 124)
        Me.Select_data.Name = "Select_data"
        Me.Select_data.Size = New System.Drawing.Size(91, 19)
        Me.Select_data.TabIndex = 27
        Me.Select_data.Text = "Select Data"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txt_SearchText)
        Me.GroupBox1.Controls.Add(Me.Chechlist_select_data)
        Me.GroupBox1.Controls.Add(Me.Select_data)
        Me.GroupBox1.Font = New System.Drawing.Font("Cambria", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox1.Location = New System.Drawing.Point(443, 13)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(784, 224)
        Me.GroupBox1.TabIndex = 45
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Show Blob Data"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(19, 105)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(94, 17)
        Me.Label1.TabIndex = 46
        Me.Label1.Text = "Search Data:"
        '
        'txt_SearchText
        '
        Me.txt_SearchText.Font = New System.Drawing.Font("Cambria", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_SearchText.Location = New System.Drawing.Point(121, 102)
        Me.txt_SearchText.Name = "txt_SearchText"
        Me.txt_SearchText.Size = New System.Drawing.Size(266, 23)
        Me.txt_SearchText.TabIndex = 45
        '
        'btn_connection
        '
        Me.btn_connection.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_connection.ForeColor = System.Drawing.Color.Black
        Me.btn_connection.Location = New System.Drawing.Point(149, 145)
        Me.btn_connection.Name = "btn_connection"
        Me.btn_connection.Size = New System.Drawing.Size(115, 29)
        Me.btn_connection.TabIndex = 56
        Me.btn_connection.Text = "Connect"
        Me.btn_connection.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(14, 31)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(101, 19)
        Me.Label2.TabIndex = 51
        Me.Label2.Text = "Server Name"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(14, 64)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(63, 19)
        Me.Label4.TabIndex = 47
        Me.Label4.Text = "User ID"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(14, 105)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(81, 19)
        Me.Label5.TabIndex = 46
        Me.Label5.Text = "Password"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txt_password)
        Me.GroupBox2.Controls.Add(Me.txt_user_id)
        Me.GroupBox2.Controls.Add(Me.txt_server)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.btn_connection)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Font = New System.Drawing.Font("Cambria", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox2.Location = New System.Drawing.Point(21, 13)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(375, 224)
        Me.GroupBox2.TabIndex = 58
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Database Conenction"
        '
        'txt_password
        '
        Me.txt_password.Font = New System.Drawing.Font("Cambria", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_password.Location = New System.Drawing.Point(149, 105)
        Me.txt_password.Name = "txt_password"
        Me.txt_password.Size = New System.Drawing.Size(191, 23)
        Me.txt_password.TabIndex = 59
        '
        'txt_user_id
        '
        Me.txt_user_id.Font = New System.Drawing.Font("Cambria", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_user_id.Location = New System.Drawing.Point(149, 68)
        Me.txt_user_id.Name = "txt_user_id"
        Me.txt_user_id.Size = New System.Drawing.Size(191, 23)
        Me.txt_user_id.TabIndex = 58
        Me.txt_user_id.Text = "153521"
        '
        'txt_server
        '
        Me.txt_server.Font = New System.Drawing.Font("Cambria", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_server.Location = New System.Drawing.Point(149, 31)
        Me.txt_server.Name = "txt_server"
        Me.txt_server.Size = New System.Drawing.Size(191, 23)
        Me.txt_server.TabIndex = 57
        Me.txt_server.Text = "176.0.0.60\lptgsqldev"
        '
        'Blob_Data
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1239, 673)
        Me.Controls.Add(Me.DgvBlobData)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.btn_Export_save)
        Me.Controls.Add(Me.btn_Show)
        Me.Controls.Add(Me.cmb_Select_column_name)
        Me.Controls.Add(Me.cmb_Select_blob_data)
        Me.Controls.Add(Me.cmb_Select_table)
        Me.Controls.Add(Me.cmb_Select_database)
        Me.Controls.Add(Me.Select_database)
        Me.Controls.Add(Me.Select_column_name)
        Me.Controls.Add(Me.Select_blob_data)
        Me.Controls.Add(Me.Select_Table)
        Me.Controls.Add(Me.GroupBox1)
        Me.ForeColor = System.Drawing.Color.Black
        Me.Name = "Blob_Data"
        Me.Text = "Blob_Data"
        CType(Me.DgvBlobData, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Select_database As Label
    Friend WithEvents Select_column_name As Label
    Friend WithEvents Select_blob_data As Label
    Friend WithEvents Select_Table As Label
    Friend WithEvents cmb_Select_database As ComboBox
    Friend WithEvents cmb_Select_table As ComboBox
    Friend WithEvents cmb_Select_blob_data As ComboBox
    Friend WithEvents cmb_Select_column_name As ComboBox
    Friend WithEvents DgvBlobData As DataGridView
    Friend WithEvents btn_Export_save As Button
    Friend WithEvents btn_Show As Button
    Friend WithEvents Chechlist_select_data As CheckedListBox
    Friend WithEvents Select_data As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btn_connection As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents txt_password As TextBox
    Friend WithEvents txt_user_id As TextBox
    Friend WithEvents txt_server As TextBox
    Friend WithEvents txt_SearchText As TextBox
    Friend WithEvents Label1 As Label
End Class
