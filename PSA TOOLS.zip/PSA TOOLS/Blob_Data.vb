﻿

Imports System.Data.SqlClient
Imports System.IO
Imports Microsoft.Office.Interop
Imports System.Data.SqlClient.SqlException
Imports System.Data
Imports ClosedXML.Excel
Public Class Blob_Data
    Dim con As New SqlConnection
    Dim cmd As New SqlCommand
    Dim dt As New DataTable
    Dim da As New SqlDataAdapter
    Dim dtb As New DataTable

    Private Sub btn_connection_Click(sender As Object, e As EventArgs) Handles btn_connection.Click
        Try

            con = New SqlConnection("Server='" + txt_server.Text + "';Database=;User Id='" + txt_user_id.Text + "';Password='" + txt_password.Text + "';")
            con.Open()
            cmd = New SqlCommand("Select * from sysdatabases ORDER BY NAME ASC ", con)

            cmb_Select_database.Text = ""
            cmb_Select_table.Text = ""
            cmb_Select_blob_data.Text = ""
            cmb_Select_column_name.Text = ""

            Chechlist_select_data.Text = ""
            Chechlist_select_data.Items.Clear()


            cmb_Select_database.Items.Clear()
            cmb_Select_table.Items.Clear()
            cmb_Select_blob_data.Items.Clear()
            cmb_Select_column_name.Items.Clear()



            Dim dt As New DataTable
            Dim da As New SqlDataAdapter
            da.SelectCommand = cmd
            da.Fill(dt)
            For i = 0 To dt.Rows.Count - 1
                cmb_Select_database.Items.Add(dt.Rows(i).Item(0).ToString)
            Next


            DgvBlobData.DataSource = Nothing


            MsgBox("Database connect Succsessfull!")


        Catch ex As Exception

            cmb_Select_database.Text = ""
            cmb_Select_table.Text = ""
            cmb_Select_blob_data.Text = ""
            cmb_Select_column_name.Text = ""

            Chechlist_select_data.Text = ""
            Chechlist_select_data.Items.Clear()
            DgvBlobData.DataSource = Nothing

            cmb_Select_database.Items.Clear()
            cmb_Select_table.Items.Clear()
            cmb_Select_blob_data.Items.Clear()
            cmb_Select_column_name.Items.Clear()





            MsgBox("Invailid Details!
                    Database not connected succsessfully!
                                                        ")


        End Try

    End Sub


    Private Sub cmb_Select_database_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmb_Select_database.SelectedIndexChanged
        DgvBlobData.Hide()
        dtb.Columns.Clear()
        dtb.Clear()
        cmb_Select_table.Text = ""
        cmb_Select_blob_data.Text = ""
        cmb_Select_column_name.Text = ""


        Chechlist_select_data.Text = ""
        Chechlist_select_data.Items.Clear()
        cmb_Select_table.Items.Clear()
        cmb_Select_blob_data.Items.Clear()
        cmb_Select_column_name.Items.Clear()


        con = New SqlConnection("Server='" + txt_server.Text + "';Database='" + cmb_Select_database.Text + "';User Id='" + txt_user_id.Text + "';Password='" + txt_password.Text + "';")

        Dim cmd As New SqlCommand("SELECT NAME FROM SYS.TABLES ORDER BY NAME ASC", con)
        Dim dt1 As New DataTable
        da.SelectCommand = cmd
        da.Fill(dt1)



        For i = 0 To dt1.Rows.Count - 1
            cmb_Select_table.Items.Add(dt1.Rows(i).Item(0).ToString)
        Next
    End Sub

    Private Sub cmb_Select_table_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmb_Select_table.SelectedIndexChanged
        DgvBlobData.Hide()
        dtb.Columns.Clear()
        dtb.Clear()
        cmb_Select_blob_data.Text = ""
        cmb_Select_column_name.Text = ""

        Chechlist_select_data.Text = ""
        Chechlist_select_data.Items.Clear()


        cmb_Select_blob_data.Items.Clear()
        cmb_Select_column_name.Items.Clear()


        Try


            Dim dt2 As New DataTable
            Dim datavalue As String

            con = New SqlConnection("Server='" + txt_server.Text + "';Database='" + cmb_Select_database.Text + "';User Id='" + txt_user_id.Text + "';Password='" + txt_password.Text + "';")


            Dim dt1 As New DataTable

            Dim cmd2 As New SqlCommand("select COLUMN_NAME from  INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME=N'" + cmb_Select_table.Text + "'", con)


            Dim da1 As New SqlDataAdapter
            da1.SelectCommand = cmd2

            da1.Fill(dt1)
            If dt1.Rows.Count <> 0 Then
                For i = 0 To dt1.Rows.Count - 1

                    Dim cmd3 As New SqlCommand("SELECT data_type FROM information_schema.columns WHERE table_name = '" + cmb_Select_table.Text + "' AND column_name = '" + dt1.Rows(i).Item(0).ToString + "'", con)

                    Dim dt4 As New DataTable
                    Dim da2 As New SqlDataAdapter
                    da2.SelectCommand = cmd3
                    da2.Fill(dt4)
                    If dt4.Rows.Count <> 0 Then
                        For j = 0 To dt4.Rows.Count - 1
                            If dt4.Rows(j).Item(0).ToString = "varbinary" Then

                                datavalue = dt1.Rows(i).Item(0).ToString

                                cmb_Select_blob_data.Items.Add(dt1.Rows(i).Item(0).ToString)

                            End If


                        Next


                    End If

                Next

                If datavalue = "" Then
                    MsgBox("Blob data is not available on this " + cmb_Select_table.Text + " Table")

                End If

            End If


        Catch ex As Exception
            MsgBox("Pleses select Table name!")
        End Try
    End Sub

    Private Sub cmb_Select_blob_data_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmb_Select_blob_data.SelectedIndexChanged
        DgvBlobData.Hide()
        dtb.Columns.Clear()
        dtb.Clear()
        cmb_Select_column_name.Text = ""


        Chechlist_select_data.Text = ""
        Chechlist_select_data.Items.Clear()


        cmb_Select_column_name.Items.Clear()


        Try


            con = New SqlConnection("Server='" + txt_server.Text + "';Database='" + cmb_Select_database.Text + "';User Id='" + txt_user_id.Text + "';Password='" + txt_password.Text + "';")
            Dim dt1 As New DataTable

            Dim cmd As New SqlCommand("select COLUMN_NAME from  INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME=N'" + cmb_Select_table.Text + "'", con)


            Dim da As New SqlDataAdapter
            da.SelectCommand = cmd

            da.Fill(dt1)





            If dt1.Rows.Count <> 0 Then
                For i = 0 To dt1.Rows.Count - 1

                    If dt1.Rows(i).Item(0) = cmb_Select_blob_data.Text Then


                        Dim dt As New DataTable




                        Dim dt2 As New DataTable
                        Dim dt3 As New DataTable
                        Dim cmd2 As New SqlCommand("select COLUMN_NAME from  INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME=N'" + cmb_Select_table.Text + "'", con)
                        Dim da1 As New SqlDataAdapter
                        da1.SelectCommand = cmd2

                        da1.Fill(dt3)
                        If dt3.Rows.Count <> 0 Then
                            For k = 0 To dt3.Rows.Count - 1

                                Dim cmd3 As New SqlCommand("SELECT data_type FROM information_schema.columns WHERE table_name = '" + cmb_Select_table.Text + "' AND column_name = '" + dt3.Rows(k).Item(0).ToString + "'", con)

                                Dim dt4 As New DataTable
                                Dim da2 As New SqlDataAdapter
                                da2.SelectCommand = cmd3
                                da2.Fill(dt4)
                                If dt4.Rows.Count <> 0 Then
                                    For j = 0 To dt4.Rows.Count - 1

                                        If dt4.Rows(j).Item(0).ToString <> "varbinary" Then

                                            cmb_Select_column_name.Items.Add(dt3.Rows(k).Item(0).ToString)

                                        End If


                                    Next


                                End If

                            Next


                        End If

                        'cmb_show_data.Text = ""

                    Else




                    End If

                Next
            Else

            End If




        Catch ex As Exception
            MsgBox("Pleses select Table name!")
        End Try
    End Sub

    Private Sub cmb_Select_column_name_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmb_Select_column_name.SelectedIndexChanged




        DgvBlobData.Hide()
        dtb.Columns.Clear()
        dtb.Clear()





        Chechlist_select_data.Text = ""
        Chechlist_select_data.Items.Clear()




        Dim dt As New DataTable


        con = New SqlConnection("Server='" + txt_server.Text + "';Database='" + cmb_Select_database.Text + "';User Id='" + txt_user_id.Text + "';Password='" + txt_password.Text + "';")



        Dim cmd3 As New SqlCommand("SELECT data_type FROM information_schema.columns WHERE table_name = '" + cmb_Select_table.Text + "' AND column_name = '" + cmb_Select_column_name.Text + "'", con)

        Dim dt4 As New DataTable
        Dim da2 As New SqlDataAdapter
        da2.SelectCommand = cmd3
        da2.Fill(dt4)
        If dt4.Rows.Count <> 0 Then
            For j = 0 To dt4.Rows.Count - 1

                If dt4.Rows(j).Item(0).ToString = "datetime" Then



                    Dim cmd8 As New SqlCommand("SELECT format(" + cmb_Select_column_name.Text + ",'yyyy-MM-dd HH:mm:ss.fff') as " + cmb_Select_column_name.Text + " FROM " + cmb_Select_table.Text + "", con)


                    Dim dt8 As New DataTable



                    Dim da8 As New SqlDataAdapter
                    da8.SelectCommand = cmd8
                    da8.Fill(dt8)
                    For im = 0 To dt8.Rows.Count - 1
                        Chechlist_select_data.Items.Add(dt8.Rows(im).Item(0).ToString)
                    Next


                Else


                    Dim dt8 As New DataTable


                    con = New SqlConnection("Server='" + txt_server.Text + "';Database='" + cmb_Select_database.Text + "';User Id='" + txt_user_id.Text + "';Password='" + txt_password.Text + "';")


                    Dim cmd8 As New SqlCommand("SELECT " + cmb_Select_column_name.Text + " FROM " + cmb_Select_table.Text + " ORDER BY " + cmb_Select_column_name.Text + " ASC", con)



                    Dim da8 As New SqlDataAdapter
                    da8.SelectCommand = cmd8
                    da8.Fill(dt8)
                    For im = 0 To dt8.Rows.Count - 1
                        'cmb_Select_data.Items.Add(dt8.Rows(im).Item(0).ToString)
                        Chechlist_select_data.Items.Add(dt8.Rows(im).Item(0).ToString)
                    Next


                End If


            Next


        End If

    End Sub


    Dim dtb4 As Integer = 1
    Private Sub btn_Show_Click(sender As Object, e As EventArgs) Handles btn_Show.Click

        If con Is Nothing Then
            MsgBox("Please Connect Database !")
        Else
            If String.IsNullOrEmpty(cmb_Select_database.Text) Then
                MsgBox("Please Select Database  Name !")
            ElseIf String.IsNullOrEmpty(cmb_Select_table.Text) Then
                MsgBox("Please Fill Table Name!")
            ElseIf String.IsNullOrEmpty(cmb_Select_blob_data.Text) Then
                MsgBox("Please Fill Blob Data!")
            ElseIf String.IsNullOrEmpty(cmb_Select_column_name.Text) Then
                MsgBox("Please Fill Column Data!")
            ElseIf String.IsNullOrEmpty(Chechlist_select_data.Text) Then
                MsgBox("Please Fill Data!")
            ElseIf Chechlist_select_data.CheckedItems.Count = 0 Then
                MsgBox("Please Select Data")

            ElseIf Chechlist_select_data.CheckedItems.Count < 2 Then
                Dim exApp As New Excel.Application
                Dim exWb As Excel.Workbook
                Try
                    DgvBlobData.Show()
                    con = New SqlConnection("Server='" + txt_server.Text + "';Database='" + cmb_Select_database.Text + "';User Id='" + txt_user_id.Text + "';Password='" + txt_password.Text + "';")
                    Dim cmd1 As New SqlCommand("SELECT  " + cmb_Select_blob_data.Text + " FROM  " + cmb_Select_table.Text + " WHERE  " + cmb_Select_column_name.Text + "='" + Chechlist_select_data.CheckedItems(0) + "'", con)


                    Dim dt As New DataTable
                    Dim adpt As New SqlDataAdapter
                    adpt.SelectCommand = cmd1
                    adpt.Fill(dt)


                    If IsDBNull(dt.Rows(0)(0)) Then
                        MsgBox("" + cmb_Select_blob_data.Text + " is not Available on this Rows" + Chechlist_select_data.Text + "")

                    Else
                        Try

                            Dim b() As Byte = dt.Rows(0)(0)


                            'Change file path
                            Dim TestString As String = Chechlist_select_data.CheckedItems(0)
                            ' Returns "Shipping List".  
                            Dim aString As String = Replace(TestString, "\", "-")
                            Dim aString1 As String = Replace(aString, "/", "-")
                            Dim aString2 As String = Replace(aString1, ":", "-")
                            Dim aString3 As String = Replace(aString2, ":", "-")
                            Dim aString4 As String = Replace(aString3, "*", "-")
                            Dim aString5 As String = Replace(aString4, "?", "-")
                            Dim aString6 As String = Replace(aString5, "<", "-")
                            Dim aString7 As String = Replace(aString6, ".", "-")
                            Dim aString8 As String = Replace(aString7, ">", "-")
                            Dim aString9 As String = Replace(aString8, "|", "-")

                            'Get Drive Name

                            Dim drive As String() = Environment.GetLogicalDrives()
                            Dim val As String
                            For Index = 0 To drive.Length - 1
                                val = drive(Index).ToString
                            Next

                            'save data as excel file
                            Dim filePath As String = "" + val + "" + aString9 + ".xlsx"
                            Try
                                File.WriteAllBytes(filePath, b)

                            Catch ex As Exception
                                MsgBox(ex.Message, aString9)
                                cmb_Select_column_name.Text = ""
                                cmb_Select_column_name.Items.Clear()
                                Chechlist_select_data.Text = ""
                                Chechlist_select_data.Items.Clear()
                                GoTo newfile
                            End Try



                            'open excel file for reading

                            exWb = exApp.Workbooks.Open(filePath)


                            Dim exSht As Excel.Worksheet = exWb.Sheets(1)

                            'read all data to datatable
                            Dim c As Integer
                            c = 1

                            While True

                                If String.IsNullOrEmpty(exSht.Cells(1, c).value) Then
                                    Exit While

                                End If

                                c = c + 1


                            End While


                            Dim r As Integer
                            r = 1


                            For i As Integer = 1 To c - 1 Step 1
                                While True
                                    If String.IsNullOrEmpty(exSht.Cells(r, i).value) Then
                                        Exit While

                                    End If
                                    r = r + 1
                                End While
                            Next



                            For i As Integer = 1 To c - 1 Step 1
                                If dtb.Rows.Count = 0 Then
                                    dtb.Columns.Add(exSht.Cells(1, i).value)
                                Else
                                    Exit For
                                End If
                                'dt44.Columns.Add(exSht.Cells(1, i).value)
                                'exSht.Cells(1, i + 1).value IsNot DataGridView1.Columns(i).HeaderText
                            Next
                            For j As Integer = 1 To r - 1 Step 1
                                dtb.Rows.Add()

                                For k As Integer = 1 To c - 1 Step 1

                                    dtb.Rows(j - 1)(k - 1) = (exSht.Cells(j + 1, k).value)


                                Next

                            Next


                            DgvBlobData.DataSource = dtb

                            exWb.Close()

                            exApp.Quit()
                            'Delete Excle file
                            If File.Exists(filePath) Then
                                File.Delete(filePath)
                            Else
                            End If
                        Catch ex As Exception
                            MsgBox(ex.Message)
                        End Try
                    End If






                Catch ex As Exception
                    MsgBox(ex.Message)


                End Try






            Else MsgBox("You can select  And Show Only One  Blob data!")

            End If
newfile:
        End If
    End Sub


    Private Sub btn_Export_save_Click(sender As Object, e As EventArgs) Handles btn_Export_save.Click
        dtb.Clear()
        dtb.Columns.Clear()
        DgvBlobData.Hide()

        Dim dtt As New DataTable
        Dim da1 As New SqlDataAdapter
        If con Is Nothing Then
            MsgBox("Please Connect Database !")
        Else
            If String.IsNullOrEmpty(cmb_Select_database.Text) Then
                MsgBox("Please Select Database  Name !")
            ElseIf String.IsNullOrEmpty(cmb_Select_table.Text) Then
                MsgBox("Please Fill Table Name!")
            ElseIf String.IsNullOrEmpty(cmb_Select_blob_data.Text) Then
                MsgBox("Please Fill Blob Data!")
            ElseIf String.IsNullOrEmpty(cmb_Select_column_name.Text) Then
                MsgBox("Please Fill Column Data!")
            ElseIf String.IsNullOrEmpty(Chechlist_select_data.Text) Then
                MsgBox("Please Fill Data!")
            ElseIf Chechlist_select_data.CheckedItems.Count = 0 Then
                MsgBox("Please Select Data")
            Else

            End If
            Using opf As FolderBrowserDialog = New FolderBrowserDialog()

                If (opf.ShowDialog() = DialogResult.OK) Then



                    path1 = opf.SelectedPath

                End If

            End Using

            dtt.Columns.Add(cmb_Select_column_name.Text)

            For i As Integer = 0 To Chechlist_select_data.CheckedItems.Count-1

                multiple_values(Chechlist_select_data.CheckedItems(i))

            Next
        End If
        MsgBox("All data saved!")

    End Sub

    Dim path1 As String
    Private Sub multiple_values(item As String)



        con = New SqlConnection("Server='" + txt_server.Text + "';Database='" + cmb_Select_database.Text + "';User Id='" + txt_user_id.Text + "';Password='" + txt_password.Text + "';")
        'Dim cmd1 As New SqlCommand("SELECT  " + cmb_Select_blob_data.Text + " FROM  " + cmb_Select_table.Text + " WHERE  " + cmb_Select_column_name.Text + "='" + item + "'", con)
        'Dim cmd1 As New SqlCommand("SELECT  " + cmb_Select_blob_data.Text + " FROM  " + cmb_Select_table.Text + " WHERE ltrim(rtrim( " + cmb_Select_column_name.Text + ")) IN (@parm1)", con)
        'cmd1.Parameters.AddWithValue("parm1", item)
        Dim cmd1 As New SqlCommand("SELECT  " + cmb_Select_blob_data.Text + " FROM  " + cmb_Select_table.Text + " Where " + cmb_Select_column_name.Text + " In ('" + item + "')", con)
        Dim dt As New DataTable
        Dim adpt As New SqlDataAdapter
        adpt.SelectCommand = cmd1
        adpt.Fill(dt)


        If IsDBNull(dt.Rows(0)(0)) Then
            MsgBox("" + cmb_Select_blob_data.Text + " is not Available on this Rows" + Chechlist_select_data.Text + "")



        Else
            Try

                Dim b() As Byte = dt.Rows(0)(0)

                '(like \ / : * ? ” < > |).
                '''''



                Dim TestString As String = item
                ' Returns "Shipping List".  
                Dim aString As String = Replace(TestString, "\", "-")
                Dim aString1 As String = Replace(aString, "/", "-")
                Dim aString2 As String = Replace(aString1, ":", "-")
                Dim aString3 As String = Replace(aString2, ":", "-")
                Dim aString4 As String = Replace(aString3, "*", "-")
                Dim aString5 As String = Replace(aString4, "?", "-")
                Dim aString6 As String = Replace(aString5, "<", "-")
                Dim aString7 As String = Replace(aString6, ".", "-")
                Dim aString8 As String = Replace(aString7, ">", "-")
                Dim aString9 As String = Replace(aString8, "|", "-")
                'save data as excel file

                'NAME CHANGES

                ''Dim cmd12n As New SqlCommand("SELECT  [H_CoilID] FROM  " + cmb_Select_table.Text + " Where " + cmb_Select_column_name.Text + " = '" + aString9 + "'", con)
                ''Dim dt12n As New DataTable
                ''Dim adpt12n As New SqlDataAdapter
                ''adpt12n.SelectCommand = cmd12n
                ''adpt12n.Fill(dt12n)
                ''Dim HCoil As String = dt12n.Rows(0)(0)
                ''Dim filePath As String = "" + path1 + "\" + aString9 + "_" + HCoil + ".xlsx"

                'END


                Dim filePath As String = "" + path1 + "\" + aString9 + ".xlsx"
                File.WriteAllBytes(filePath, b)
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If


    End Sub

    Private Sub txt_password_TextChanged(sender As Object, e As EventArgs) Handles txt_password.TextChanged
        txt_password.PasswordChar = "*"
    End Sub

    Private Sub Blob_Data_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DgvBlobData.Hide()


    End Sub

    Private Sub CheckedListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Chechlist_select_data.SelectedIndexChanged
        dtb.Clear()
        dtb.Columns.Clear()
    End Sub

    Private Sub CheckedListBox1_SelectedValueChanged(sender As Object, e As EventArgs) Handles Chechlist_select_data.SelectedValueChanged
        dtb.Clear()
        dtb.Columns.Clear()
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txt_SearchText.TextChanged
        Dim j As String = Chechlist_select_data.FindString(txt_SearchText.Text)
        Chechlist_select_data.SelectedIndex = j
        Chechlist_select_data.SelectedItem = j
    End Sub


End Class