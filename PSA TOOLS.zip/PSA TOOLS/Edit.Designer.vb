﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Edit
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn_Update = New System.Windows.Forms.Button()
        Me.txt_IP_Address = New System.Windows.Forms.TextBox()
        Me.txt_Second_Owner_Name = New System.Windows.Forms.TextBox()
        Me.txt_Owner_Name = New System.Windows.Forms.TextBox()
        Me.txt_Asset_id = New System.Windows.Forms.TextBox()
        Me.IP_Address = New System.Windows.Forms.Label()
        Me.Second_Owner_Name = New System.Windows.Forms.Label()
        Me.Owner_Name = New System.Windows.Forms.Label()
        Me.Asset_id = New System.Windows.Forms.Label()
        Me.lbl_ID = New System.Windows.Forms.Label()
        Me.txt_ID = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txt_Third_User_Name = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btn_Update
        '
        Me.btn_Update.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Update.Location = New System.Drawing.Point(402, 362)
        Me.btn_Update.Name = "btn_Update"
        Me.btn_Update.Size = New System.Drawing.Size(77, 27)
        Me.btn_Update.TabIndex = 21
        Me.btn_Update.Text = "Update"
        Me.btn_Update.UseVisualStyleBackColor = True
        '
        'txt_IP_Address
        '
        Me.txt_IP_Address.Location = New System.Drawing.Point(402, 254)
        Me.txt_IP_Address.Name = "txt_IP_Address"
        Me.txt_IP_Address.Size = New System.Drawing.Size(270, 20)
        Me.txt_IP_Address.TabIndex = 18
        '
        'txt_Second_Owner_Name
        '
        Me.txt_Second_Owner_Name.Location = New System.Drawing.Point(402, 193)
        Me.txt_Second_Owner_Name.Name = "txt_Second_Owner_Name"
        Me.txt_Second_Owner_Name.Size = New System.Drawing.Size(270, 20)
        Me.txt_Second_Owner_Name.TabIndex = 17
        '
        'txt_Owner_Name
        '
        Me.txt_Owner_Name.Location = New System.Drawing.Point(402, 134)
        Me.txt_Owner_Name.Name = "txt_Owner_Name"
        Me.txt_Owner_Name.Size = New System.Drawing.Size(270, 20)
        Me.txt_Owner_Name.TabIndex = 16
        '
        'txt_Asset_id
        '
        Me.txt_Asset_id.Location = New System.Drawing.Point(402, 81)
        Me.txt_Asset_id.Name = "txt_Asset_id"
        Me.txt_Asset_id.Size = New System.Drawing.Size(270, 20)
        Me.txt_Asset_id.TabIndex = 15
        '
        'IP_Address
        '
        Me.IP_Address.AutoSize = True
        Me.IP_Address.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IP_Address.Location = New System.Drawing.Point(219, 253)
        Me.IP_Address.Name = "IP_Address"
        Me.IP_Address.Size = New System.Drawing.Size(88, 19)
        Me.IP_Address.TabIndex = 14
        Me.IP_Address.Text = "IP Address"
        '
        'Second_Owner_Name
        '
        Me.Second_Owner_Name.AutoSize = True
        Me.Second_Owner_Name.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Second_Owner_Name.Location = New System.Drawing.Point(219, 194)
        Me.Second_Owner_Name.Name = "Second_Owner_Name"
        Me.Second_Owner_Name.Size = New System.Drawing.Size(161, 19)
        Me.Second_Owner_Name.TabIndex = 13
        Me.Second_Owner_Name.Text = "Second Owner Name"
        '
        'Owner_Name
        '
        Me.Owner_Name.AutoSize = True
        Me.Owner_Name.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Owner_Name.Location = New System.Drawing.Point(219, 133)
        Me.Owner_Name.Name = "Owner_Name"
        Me.Owner_Name.Size = New System.Drawing.Size(104, 19)
        Me.Owner_Name.TabIndex = 12
        Me.Owner_Name.Text = "Owner Name"
        '
        'Asset_id
        '
        Me.Asset_id.AutoSize = True
        Me.Asset_id.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Asset_id.Location = New System.Drawing.Point(219, 82)
        Me.Asset_id.Name = "Asset_id"
        Me.Asset_id.Size = New System.Drawing.Size(67, 19)
        Me.Asset_id.TabIndex = 11
        Me.Asset_id.Text = "Asset Id"
        '
        'lbl_ID
        '
        Me.lbl_ID.AutoSize = True
        Me.lbl_ID.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_ID.Location = New System.Drawing.Point(219, 32)
        Me.lbl_ID.Name = "lbl_ID"
        Me.lbl_ID.Size = New System.Drawing.Size(26, 19)
        Me.lbl_ID.TabIndex = 22
        Me.lbl_ID.Text = "ID"
        '
        'txt_ID
        '
        Me.txt_ID.Location = New System.Drawing.Point(402, 31)
        Me.txt_ID.Name = "txt_ID"
        Me.txt_ID.ReadOnly = True
        Me.txt_ID.Size = New System.Drawing.Size(270, 20)
        Me.txt_ID.TabIndex = 23
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(219, 312)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(138, 19)
        Me.Label1.TabIndex = 24
        Me.Label1.Text = " Third User Name"
        '
        'txt_Third_User_Name
        '
        Me.txt_Third_User_Name.Location = New System.Drawing.Point(402, 311)
        Me.txt_Third_User_Name.Name = "txt_Third_User_Name"
        Me.txt_Third_User_Name.Size = New System.Drawing.Size(270, 20)
        Me.txt_Third_User_Name.TabIndex = 25
        '
        'Edit
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(873, 454)
        Me.Controls.Add(Me.txt_Third_User_Name)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txt_ID)
        Me.Controls.Add(Me.lbl_ID)
        Me.Controls.Add(Me.btn_Update)
        Me.Controls.Add(Me.txt_IP_Address)
        Me.Controls.Add(Me.txt_Second_Owner_Name)
        Me.Controls.Add(Me.txt_Owner_Name)
        Me.Controls.Add(Me.txt_Asset_id)
        Me.Controls.Add(Me.IP_Address)
        Me.Controls.Add(Me.Second_Owner_Name)
        Me.Controls.Add(Me.Owner_Name)
        Me.Controls.Add(Me.Asset_id)
        Me.Name = "Edit"
        Me.Text = "Edit"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_Update As Button
    Friend WithEvents txt_IP_Address As TextBox
    Friend WithEvents txt_Second_Owner_Name As TextBox
    Friend WithEvents txt_Owner_Name As TextBox
    Friend WithEvents txt_Asset_id As TextBox
    Friend WithEvents IP_Address As Label
    Friend WithEvents Second_Owner_Name As Label
    Friend WithEvents Owner_Name As Label
    Friend WithEvents Asset_id As Label
    Friend WithEvents lbl_ID As Label
    Friend WithEvents txt_ID As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txt_Third_User_Name As TextBox
End Class
