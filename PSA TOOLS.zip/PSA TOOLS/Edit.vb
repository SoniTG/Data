﻿
Imports System.Data.SqlClient
Imports System.IO
Imports Microsoft.Office.Interop
Imports System.Data.SqlClient.SqlException
Imports System.Data
Imports ClosedXML.Excel
Public Class Edit


    Dim con As New SqlConnection
    Dim cmd As New SqlCommand

    Private Sub btn_Update_Click(sender As Object, e As EventArgs) Handles btn_Update.Click
        If txt_ID.Text = Nothing Or txt_Asset_id.Text = Nothing Or txt_IP_Address.Text = Nothing Or txt_Owner_Name.Text = Nothing Or txt_Second_Owner_Name.Text = Nothing Or txt_Third_User_Name.Text = Nothing Then
            MsgBox("Please fill the data")
        Else
            con = New SqlConnection("Server=176.0.0.60\lptgsqldev;Database=PSA_TOOLS;User Id=153521;Password=Welcome@135;")
            cmd = New SqlCommand("UPDATE [dbo].[T_ASSET_MONITOR]
             SET
             [AssetId] ='" + txt_Asset_id.Text + "'
             ,[OwnerName] = '" + txt_Owner_Name.Text + "'
             ,[SecondOwnerName] = '" + txt_Second_Owner_Name.Text + "'
             ,[IPAddress] = '" + txt_IP_Address.Text + "'
             ,[ThirdUserName]='" + txt_Third_User_Name.Text + "'
            WHERE[ID]='" + txt_ID.Text + "'", con)
            con.Open()
            cmd.ExecuteNonQuery()
            MsgBox("Data Update")
            Me.Close()
            System_Monitoring.Close()
            System_Monitoring.Show()
        End If


    End Sub

    Private Sub Edit_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txt_ID.Text = arrvall(0)
        txt_Asset_id.Text = arrvall(1)
        txt_Owner_Name.Text = arrvall(2)
        txt_Second_Owner_Name.Text = arrvall(3)
        txt_IP_Address.Text = arrvall(4)
        txt_Third_User_Name.Text = arrvall(5)
    End Sub
End Class