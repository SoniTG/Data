﻿Imports System.Data.SqlClient
Imports System.IO
Imports Microsoft.Office.Interop
Imports System.Data.SqlClient.SqlException
Imports System.Data
Imports ClosedXML.Excel
Public Class EditIBA

    Dim con As New SqlConnection
    Dim cmd As New SqlCommand
    Private Sub btn_Update_Click(sender As Object, e As EventArgs) Handles btn_Update.Click
        If txt_Area.Text = Nothing Then
            MsgBox("Please Fill Area data")
        ElseIf txt_PlantName.Text = Nothing Then
            MsgBox("Please Fill PlantName data")
        ElseIf txt_SourceLocation.Text = Nothing Then
            MsgBox("Please Fill SourceLocation data")
        ElseIf txt_DestinationLocation.Text = Nothing Then
            MsgBox("Please Fill DestinationLocation data")
        ElseIf txt_AssignedAsset.Text = Nothing Then
            MsgBox("Please Fill AssignedAsset data")
        Else
            Try
                con = New SqlConnection("Server=176.0.0.60\lptgsqldev;Database=PSA_TOOLS;User Id=153521;Password=Welcome@135;")
                cmd = New SqlCommand("UPDATE [dbo].[IBA_File_Monitoring]
             SET               
             [Area] ='" + txt_Area.Text + "'
             ,[PlantName] ='" + txt_PlantName.Text + "'
             ,[SourceLocation] ='" + txt_SourceLocation.Text + "'
             ,[DestinationLocation] ='" + txt_DestinationLocation.Text + "'
             ,[NoOfFile_Source] ='" + txt_NoOfFile_Source.Text + "'
             ,[NoOfFile_Dest] ='" + txt_NoOfFile__Dest.Text + "'
             ,[AssignedAsset] ='" + txt_AssignedAsset.Text + "'
             ,[AssignedAssetIp] ='" + txt_AssignedAssetIp.Text + "'
             ,[PingStatus] ='" + txt_PingStatus.Text + "'
             ,[Owner_PNo] ='" + txt_Owner_PNo.Text + "'
             ,[LastPingDatetime] ='" + dtm_txt_LastPingDatetime.Text + "'
             ,[LastPingFalsedatetime] ='" + dtm_LastPingFalseDatetime.Text + "'
            WHERE [SLNo] ='" + txt_SLNo.Text + "'", con)
                con.Open()
                cmd.ExecuteNonQuery()
                MsgBox("Data Update")
                'Form1.Close()
                Me.Close()
                Ip_SERVER.Close()
                Ip_SERVER.Show()
            Catch ex As Exception
                MsgBox("Data is not update!")
            End Try

        End If



    End Sub

    Private Sub EditIBA_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim time As String = dtm_LastPingFalseDatetime.Text
        Dim time2 As String = dtm_txt_LastPingDatetime.Text
        txt_SLNo.Text = arrval(0)
        txt_Area.Text = arrval(1)
        txt_PlantName.Text = arrval(2)
        txt_SourceLocation.Text = arrval(3)
        txt_DestinationLocation.Text = arrval(4)
        txt_NoOfFile_Source.Text = arrval(5)
        txt_NoOfFile__Dest.Text = arrval(6)
        txt_AssignedAsset.Text = arrval(7)
        txt_AssignedAssetIp.Text = arrval(8)
        txt_PingStatus.Text = arrval(9)
        txt_Owner_PNo.Text = arrval(10)
        time = arrval(11)
        time2 = arrval(12)
    End Sub
End Class