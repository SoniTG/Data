﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PSA_TOOL
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Login = New System.Windows.Forms.GroupBox()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btn_login = New System.Windows.Forms.Button()
        Me.txt_pwd = New System.Windows.Forms.TextBox()
        Me.txt_uid = New System.Windows.Forms.TextBox()
        Me.lbl_pwd = New System.Windows.Forms.Label()
        Me.lbl_user_id = New System.Windows.Forms.Label()
        Me.Login.SuspendLayout()
        Me.SuspendLayout()
        '
        'Login
        '
        Me.Login.Controls.Add(Me.LinkLabel2)
        Me.Login.Controls.Add(Me.LinkLabel1)
        Me.Login.Controls.Add(Me.Label5)
        Me.Login.Controls.Add(Me.btn_login)
        Me.Login.Controls.Add(Me.txt_pwd)
        Me.Login.Controls.Add(Me.txt_uid)
        Me.Login.Controls.Add(Me.lbl_pwd)
        Me.Login.Controls.Add(Me.lbl_user_id)
        Me.Login.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Login.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Login.Location = New System.Drawing.Point(354, 95)
        Me.Login.Name = "Login"
        Me.Login.Size = New System.Drawing.Size(493, 282)
        Me.Login.TabIndex = 0
        Me.Login.TabStop = False
        Me.Login.Text = "Login"
        '
        'LinkLabel2
        '
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel2.Location = New System.Drawing.Point(225, 182)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(131, 19)
        Me.LinkLabel2.TabIndex = 8
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "Forget Password"
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel1.Location = New System.Drawing.Point(138, 182)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(78, 19)
        Me.LinkLabel1.TabIndex = 2
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "New User"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(212, 182)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(17, 19)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "/"
        '
        'btn_login
        '
        Me.btn_login.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_login.ForeColor = System.Drawing.Color.Navy
        Me.btn_login.Location = New System.Drawing.Point(142, 141)
        Me.btn_login.Name = "btn_login"
        Me.btn_login.Size = New System.Drawing.Size(75, 28)
        Me.btn_login.TabIndex = 4
        Me.btn_login.Text = "Login"
        Me.btn_login.UseVisualStyleBackColor = True
        '
        'txt_pwd
        '
        Me.txt_pwd.Font = New System.Drawing.Font("Cambria", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_pwd.Location = New System.Drawing.Point(145, 100)
        Me.txt_pwd.Name = "txt_pwd"
        Me.txt_pwd.Size = New System.Drawing.Size(236, 23)
        Me.txt_pwd.TabIndex = 3
        '
        'txt_uid
        '
        Me.txt_uid.Font = New System.Drawing.Font("Cambria", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_uid.Location = New System.Drawing.Point(142, 40)
        Me.txt_uid.Name = "txt_uid"
        Me.txt_uid.Size = New System.Drawing.Size(239, 23)
        Me.txt_uid.TabIndex = 2
        '
        'lbl_pwd
        '
        Me.lbl_pwd.AutoSize = True
        Me.lbl_pwd.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_pwd.ForeColor = System.Drawing.Color.Black
        Me.lbl_pwd.Location = New System.Drawing.Point(37, 103)
        Me.lbl_pwd.Name = "lbl_pwd"
        Me.lbl_pwd.Size = New System.Drawing.Size(81, 19)
        Me.lbl_pwd.TabIndex = 1
        Me.lbl_pwd.Text = "Password"
        '
        'lbl_user_id
        '
        Me.lbl_user_id.AutoSize = True
        Me.lbl_user_id.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_user_id.ForeColor = System.Drawing.Color.Black
        Me.lbl_user_id.Location = New System.Drawing.Point(37, 43)
        Me.lbl_user_id.Name = "lbl_user_id"
        Me.lbl_user_id.Size = New System.Drawing.Size(63, 19)
        Me.lbl_user_id.TabIndex = 0
        Me.lbl_user_id.Text = "User ID"
        '
        'PSA_TOOL
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1038, 592)
        Me.Controls.Add(Me.Login)
        Me.Font = New System.Drawing.Font("Cambria", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "PSA_TOOL"
        Me.Text = "PSA TOOLS"
        Me.Login.ResumeLayout(False)
        Me.Login.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Login As GroupBox
    Friend WithEvents Label5 As Label
    Friend WithEvents btn_login As Button
    Friend WithEvents txt_pwd As TextBox
    Friend WithEvents txt_uid As TextBox
    Friend WithEvents lbl_pwd As Label
    Friend WithEvents lbl_user_id As Label
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents LinkLabel2 As LinkLabel
End Class
