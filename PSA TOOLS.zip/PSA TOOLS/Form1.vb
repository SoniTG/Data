﻿
Imports System.Data.SqlClient
Imports System.IO
Imports Microsoft.Office.Interop
Imports System.Data.SqlClient.SqlException

Public Class PSA_TOOL


    Private Sub btn_login_Click(sender As Object, e As EventArgs) Handles btn_login.Click
        Try
            Dim conn As New SqlConnection("Server=176.0.0.60\lptgsqldev;Database=PSA_TOOLS;User Id=153521;Password=Welcome@135;")

            Dim cmd As New SqlCommand("select * from T_USER_DETAIL where Userid='" + txt_uid.Text + "'  and password='" + txt_pwd.Text + "' ", conn)
            Dim dt As New DataTable
            Dim adpt As New SqlDataAdapter
            adpt.SelectCommand = cmd
            adpt.Fill(dt)
            If String.IsNullOrEmpty(txt_uid.Text) Then
                MsgBox("Please fill User Id")
            ElseIf String.IsNullOrEmpty(txt_pwd.Text) Then
                MsgBox("Please fill Password ")
            Else
                If dt.Rows.Count > 0 Then
                    MsgBox("Login Successfully!")
                    txt_uid.Text = ""
                    txt_pwd.Text = ""

                    Hide()
                    PSA_TOOLS1.Show()
                Else
                    MsgBox("Login Failed!")
                End If
            End If
        Catch ex As Exception
            MsgBox("Network Issue!")
        End Try



    End Sub

    Private Sub txt_pwd_TextChanged(sender As Object, e As EventArgs) Handles txt_pwd.TextChanged
        txt_pwd.PasswordChar = "*"
    End Sub

End Class
