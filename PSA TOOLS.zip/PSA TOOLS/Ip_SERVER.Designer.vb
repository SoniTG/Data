﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Ip_SERVER
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Ip_SERVER))
        Me.DvgIpServer = New System.Windows.Forms.DataGridView()
        Me.btn_AddData = New System.Windows.Forms.Button()
        Me.C_MenuStrip_IP_server = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeleteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.cmb_Owner_name = New System.Windows.Forms.ComboBox()
        Me.Asset_id = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmb_Asset_id = New System.Windows.Forms.ComboBox()
        Me.Iba_refresh_icon = New System.Windows.Forms.PictureBox()
        CType(Me.DvgIpServer, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.C_MenuStrip_IP_server.SuspendLayout()
        CType(Me.Iba_refresh_icon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DvgIpServer
        '
        Me.DvgIpServer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DvgIpServer.Location = New System.Drawing.Point(36, 66)
        Me.DvgIpServer.Name = "DvgIpServer"
        Me.DvgIpServer.Size = New System.Drawing.Size(1100, 501)
        Me.DvgIpServer.TabIndex = 0
        '
        'btn_AddData
        '
        Me.btn_AddData.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_AddData.Location = New System.Drawing.Point(946, 32)
        Me.btn_AddData.Name = "btn_AddData"
        Me.btn_AddData.Size = New System.Drawing.Size(128, 27)
        Me.btn_AddData.TabIndex = 12
        Me.btn_AddData.Text = "Add Data"
        Me.btn_AddData.UseVisualStyleBackColor = True
        '
        'C_MenuStrip_IP_server
        '
        Me.C_MenuStrip_IP_server.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EditToolStripMenuItem, Me.DeleteToolStripMenuItem})
        Me.C_MenuStrip_IP_server.Name = "ContextMenuStrip1"
        Me.C_MenuStrip_IP_server.Size = New System.Drawing.Size(153, 70)
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.EditToolStripMenuItem.Text = "Edit"
        '
        'DeleteToolStripMenuItem
        '
        Me.DeleteToolStripMenuItem.Name = "DeleteToolStripMenuItem"
        Me.DeleteToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.DeleteToolStripMenuItem.Text = "Delete"
        '
        'cmb_Owner_name
        '
        Me.cmb_Owner_name.FormattingEnabled = True
        Me.cmb_Owner_name.Location = New System.Drawing.Point(159, 33)
        Me.cmb_Owner_name.Name = "cmb_Owner_name"
        Me.cmb_Owner_name.Size = New System.Drawing.Size(151, 21)
        Me.cmb_Owner_name.TabIndex = 13
        '
        'Asset_id
        '
        Me.Asset_id.AutoSize = True
        Me.Asset_id.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Asset_id.Location = New System.Drawing.Point(348, 38)
        Me.Asset_id.Name = "Asset_id"
        Me.Asset_id.Size = New System.Drawing.Size(67, 19)
        Me.Asset_id.TabIndex = 71
        Me.Asset_id.Text = "Asset Id"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(45, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(108, 19)
        Me.Label1.TabIndex = 72
        Me.Label1.Text = "Owmer Name"
        '
        'cmb_Asset_id
        '
        Me.cmb_Asset_id.FormattingEnabled = True
        Me.cmb_Asset_id.Location = New System.Drawing.Point(421, 33)
        Me.cmb_Asset_id.Name = "cmb_Asset_id"
        Me.cmb_Asset_id.Size = New System.Drawing.Size(207, 21)
        Me.cmb_Asset_id.TabIndex = 73
        '
        'Iba_refresh_icon
        '
        Me.Iba_refresh_icon.Image = CType(resources.GetObject("Iba_refresh_icon.Image"), System.Drawing.Image)
        Me.Iba_refresh_icon.Location = New System.Drawing.Point(1101, 29)
        Me.Iba_refresh_icon.Name = "Iba_refresh_icon"
        Me.Iba_refresh_icon.Size = New System.Drawing.Size(35, 30)
        Me.Iba_refresh_icon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Iba_refresh_icon.TabIndex = 74
        Me.Iba_refresh_icon.TabStop = False
        '
        'Ip_SERVER
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1174, 605)
        Me.Controls.Add(Me.Iba_refresh_icon)
        Me.Controls.Add(Me.cmb_Asset_id)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Asset_id)
        Me.Controls.Add(Me.cmb_Owner_name)
        Me.Controls.Add(Me.btn_AddData)
        Me.Controls.Add(Me.DvgIpServer)
        Me.Name = "Ip_SERVER"
        Me.Text = "Ip_SERVER"
        CType(Me.DvgIpServer, System.ComponentModel.ISupportInitialize).EndInit()
        Me.C_MenuStrip_IP_server.ResumeLayout(False)
        CType(Me.Iba_refresh_icon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents DvgIpServer As DataGridView
    Friend WithEvents btn_AddData As Button
    Friend WithEvents C_MenuStrip_IP_server As ContextMenuStrip
    Friend WithEvents EditToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DeleteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents cmb_Owner_name As ComboBox
    Friend WithEvents Asset_id As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents cmb_Asset_id As ComboBox
    Friend WithEvents Iba_refresh_icon As PictureBox
End Class
