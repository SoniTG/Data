﻿
Imports System.Data.SqlClient
Imports System.Net.NetworkInformation
Public Class Ip_SERVER


    Sub Main()
        Dim strHostName1 As String
        strHostName1 = System.Net.Dns.GetHostName()
        Dim con As New SqlConnection("Data Source=176.0.0.60\LPTGSQLDEV;Initial Catalog=PSA_TOOLS;uid=153521;password=Welcome@135;")
        Dim dt As New DataTable
        'Dim strHostName As String
        'strHostName = System.Net.Dns.GetHostName()
        'Dim strHostName12 As String
        'strHostName12 = "TSPCA08270"
        Dim cmd As SqlCommand = New SqlCommand("SELECT * FROM [PSA_TOOLS].[dbo].[IBA_File_Monitoring] where [AssignedAsset]='" + strHostName1 + "' ", con)
        'Dim cmd As SqlCommand = New SqlCommand("SELECT * FROM [PSA_TOOLS].[dbo].[IBA_File_Monitoring] where [AssignedAsset]='" + strHostName12 + "' ", con)
        Dim da As New SqlDataAdapter
        da.SelectCommand = cmd
        da.Fill(dt)




        For i As Integer = 0 To dt.Rows.Count - 1

            Try
                Dim myPing As Ping = New Ping()
                Dim srclocation As String = dt.Rows(i)(3).ToString().Replace("\\", "").Split("\")(0)
                'Dim srclocation As String = st.Replace("\\", "").Split("\")(0)
                'check ip

                'status 
                Try
                    ' Dim reply As PingReply
                    Dim status As Boolean
                    Try
                        'reply = myPing.Send(srclocation, 5000)
                        'status = reply.Status = IPStatus.Success
                        status = My.Computer.Network.Ping(srclocation)
                    Catch ex As Exception
                        GoTo next2
                    End Try


                    Dim conn As New SqlConnection("Data Source=176.0.0.60\LPTGSQLDEV;Initial Catalog=PSA_TOOLS;uid=153521;password=Welcome@135;")

                    conn.Open()
                    'Dim status As Boolean = My.Computer.Network.Ping(srclocation)

                    If status = True Then
                        Dim SqlQuery As String = "update IBA_File_Monitoring  set PingStatus = '" & status & "',LastPingDatetime = GETDATE() where  slno = " & dt.Rows(i)("slno").ToString() & ""
                        cmd = New SqlCommand(SqlQuery, conn)
                        If conn.State = ConnectionState.Closed Then conn.Open()
                        cmd.ExecuteNonQuery()


                    Else


                        Dim flse As String = "update IBA_File_Monitoring  set PingStatus = '" & status & "',LastPingDatetime = GETDATE() where  slno = " & dt.Rows(i)("slno").ToString() & ""
                        Dim cmdf As SqlCommand = New SqlCommand(flse, con)
                        If con.State = ConnectionState.Closed Then con.Open()
                        cmdf.ExecuteNonQuery()



                        'check for 2 hours duration in lastpingfalsedatetime
                        Dim sendmail As Boolean = False
                        Dim lastpingfalsetime As DateTime
                        Dim datetimedifference As Integer
                        If IsDBNull(dt.Rows(i)("Lastpingfalsedatetime")) Then
                            cmdf.CommandText = "update IBA_File_Monitoring set Lastpingfalsedatetime=getdate() where  slno = " & dt.Rows(i)("slno").ToString() & ""
                            If con.State = ConnectionState.Closed Then con.Open()
                            cmdf.ExecuteNonQuery()
                            sendmail = True
                        Else
                            lastpingfalsetime = CDate(dt.Rows(i)("Lastpingfalsedatetime"))
                            If DateDiff(DateInterval.Hour, lastpingfalsetime, DateTime.Now) > 2 Then
                                datetimedifference = DateDiff(DateInterval.Minute, lastpingfalsetime, DateTime.Now)
                                sendmail = True
                                cmdf.CommandText = "update IBA_File_Monitoring set Lastpingfalsedatetime=getdate() where  slno = " & dt.Rows(i)("slno").ToString() & ""
                                If con.State = ConnectionState.Closed Then con.Open()
                                cmdf.ExecuteNonQuery()
                            End If
                        End If



                    End If

                    If conn.State = ConnectionState.Open Then conn.Close()
                Catch __unusedException1__ As Exception
                    Throw
                End Try

            Catch ex As Exception
                MsgBox("Error: You Have Some Timeout issue")
            End Try

next2:
        Next



    End Sub

    Sub Grid()
        Dim con As New SqlConnection("Data Source=176.0.0.60\LPTGSQLDEV;Initial Catalog=PSA_TOOLS;uid=153521;password=Welcome@135;")
        Dim dt As New DataTable
        'Dim strHostName As String
        'strHostName = System.Net.Dns.GetHostName()
        Dim cmd As SqlCommand = New SqlCommand("SELECT * FROM [PSA_TOOLS].[dbo].[IBA_File_Monitoring] where [AssignedAsset]='" + cmb_Asset_id.Text + "' ORDER BY [SLNo] ASC ", con)

        Dim da As New SqlDataAdapter
        da.SelectCommand = cmd
        da.Fill(dt)
        DvgIpServer.DataSource = dt

        DvgIpServer.EnableHeadersVisualStyles = False
        DvgIpServer.ColumnHeadersDefaultCellStyle.BackColor = Color.White
        DvgIpServer.ColumnHeadersDefaultCellStyle.ForeColor = Color.Blue
        DvgIpServer.ColumnHeadersDefaultCellStyle.Font = New Font("Cambria", 10, FontStyle.Bold)

        For i As Integer = 0 To DvgIpServer.Rows.Count - 1 Step 1


            DvgIpServer.Rows(i).DefaultCellStyle.Font = New Font("Cambria", 10, FontStyle.Regular)

        Next
        Try
            For i As Integer = 0 To DvgIpServer.Rows.Count - 2 Step 1
                Dim val As String
                val = DvgIpServer.Rows(i).Cells(9).Value

                If val = "" Then
                    DvgIpServer.Rows(i).DefaultCellStyle.BackColor = Color.Gray
                ElseIf val = True Then
                    DvgIpServer.Rows(i).DefaultCellStyle.BackColor = Color.Green
                ElseIf val = False Then
                    DvgIpServer.Rows(i).DefaultCellStyle.BackColor = Color.Red
                Else
                End If




            Next
        Catch ex As Exception
            ' MsgBox("Data Not Show1")
        End Try

    End Sub
    Dim Index As Integer

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DvgIpServer.CellClick
        Try
            DvgIpServer.Rows(e.RowIndex).Selected = True
            Index = e.RowIndex
            DvgIpServer.CurrentCell = DvgIpServer.Rows(e.RowIndex).Cells(0)

            Dim selectdrow As DataGridViewRow
            selectdrow = DvgIpServer.Rows(e.RowIndex)
            'Replace null to String
            Dim c As Integer
            c = 0
            c = DvgIpServer.Columns.Count
            For i As Integer = 0 To c - 1
                If IsDBNull(selectdrow.Cells(i).Value) = False Then
                    arrval(i) = selectdrow.Cells(i).Value
                Else


                    arrval(i) = ""
                End If
            Next
            C_MenuStrip_IP_server.Show(MousePosition.X, MousePosition.Y)
        Catch ex As Exception

        End Try

    End Sub
    Private Sub DeleteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DeleteToolStripMenuItem.Click
        Dim cofigmsg = MsgBox("Are you sure to delete!", MessageBoxButtons.YesNo)
        If cofigmsg = DialogResult.Yes Then
            Try
                Dim con As New SqlConnection("Data Source=176.0.0.60\LPTGSQLDEV;Initial Catalog=PSA_TOOLS;uid=153521;password=Welcome@135;")
                Dim cmd As SqlCommand = New SqlCommand(" DELETE From [dbo].[IBA_File_Monitoring]
      Where [SLNo]='" + arrval(0) + "'", con)

                If con.State = ConnectionState.Closed Then
                    con.Open()
                    cmd.ExecuteNonQuery()
                End If

                MsgBox("Data successfully deleted!")
                Grid()
            Catch ex As Exception
                MsgBox("Data is not delete!")
            End Try

        End If
    End Sub
    Sub cmbo_select()
        Try
            Dim con As New SqlConnection("Data Source=176.0.0.60\LPTGSQLDEV;Initial Catalog=PSA_TOOLS;uid=153521;password=Welcome@135;")
            Dim dt As New DataTable
            Dim strHostName As String
            strHostName = System.Net.Dns.GetHostName()

            Dim cmd1 As SqlCommand = New SqlCommand("SELECT DISTINCT [OwnerName] FROM [PSA_TOOLS].[dbo].[T_ASSET_MONITOR] ", con)
            Dim dt11 As New DataTable
            Dim da1 As New SqlDataAdapter
            da1.SelectCommand = cmd1
            da1.Fill(dt11)

            ' ALL VALUE ADD

            For i = 0 To dt11.Rows.Count - 1

                cmb_Owner_name.Items.Add(dt11.Rows(i).Item(0).ToString)
            Next

            '  SINGLE VALUE ADD

            Dim cmd12 As SqlCommand = New SqlCommand(" Select [OwnerName] From [PSA_TOOLS].[dbo].[T_ASSET_MONITOR] Where [AssetId] ='" + strHostName + "'", con)
            Dim dt12 As New DataTable
            da1.SelectCommand = cmd12
            da1.Fill(dt12)
            cmb_Owner_name.SelectedText = dt12.Rows(0).Item(0).ToString
            ' ALL ASSET ID SEARCH
            Dim cmd13 As SqlCommand = New SqlCommand(" Select [AssetId] From [PSA_TOOLS].[dbo].[T_ASSET_MONITOR] Where [OwnerName] ='" + dt12.Rows(0).Item(0).ToString + "'", con)
            da1.SelectCommand = cmd13
            Dim dt13 As New DataTable
            da1.Fill(dt13)
            For i = 0 To dt13.Rows.Count - 1

                cmb_Asset_id.Items.Add(dt13.Rows(i).Item(0).ToString)
            Next
            cmb_Asset_id.SelectedText = strHostName.ToString


            Main()
            Grid()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub EditToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EditToolStripMenuItem.Click

        EditIBA.Show()
    End Sub

    Private Sub btn_AddData_Click(sender As Object, e As EventArgs) Handles btn_AddData.Click
        AddIBA.Show()
    End Sub

    Private Sub Ip_SERVER_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cmbo_select()
    End Sub

    Private Sub cmb_Owner_name_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmb_Owner_name.SelectedIndexChanged
        Try
            cmb_Asset_id.Items.Clear()
            Dim VAL As String
            VAL = " - - - - - - - - - - -Select - - -- - - - - - - - -"
            Dim con As New SqlConnection("Data Source=176.0.0.60\LPTGSQLDEV;Initial Catalog=PSA_TOOLS;uid=153521;password=Welcome@135;")
            Dim da1 As New SqlDataAdapter
            Dim cmd13 As SqlCommand = New SqlCommand(" Select [AssetId]  from  [PSA_TOOLS].[dbo].[T_ASSET_MONITOR] WHERE [OwnerName]='" + cmb_Owner_name.Text + "'", con)
            da1.SelectCommand = cmd13

            Dim dt13 As New DataTable
            da1.Fill(dt13)
            For i = 0 To dt13.Rows.Count - 1

                cmb_Asset_id.Items.Add(dt13.Rows(i).Item(0).ToString)
            Next
            cmb_Asset_id.Text = ""
            cmb_Asset_id.SelectedText = VAL
        Catch ex As Exception

        End Try
    End Sub

    Private Sub cmb_Asset_id_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmb_Asset_id.SelectedIndexChanged
        'Main()
        Grid()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles Iba_refresh_icon.Click
        cmb_Asset_id.Text = ""
        cmb_Asset_id.Items.Clear()
        cmb_Owner_name.Text = ""
        cmb_Owner_name.Items.Clear()
        cmbo_select()
    End Sub
End Class