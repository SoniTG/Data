﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Merge_Excel
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.txt_location = New System.Windows.Forms.TextBox()
        Me.btn_search = New System.Windows.Forms.Button()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.rd_btn_one_Sheet = New System.Windows.Forms.RadioButton()
        Me.rd_btn_anotherSht = New System.Windows.Forms.RadioButton()
        Me.btn_M_A_Save = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txt_location
        '
        Me.txt_location.Font = New System.Drawing.Font("Cambria", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_location.Location = New System.Drawing.Point(425, 178)
        Me.txt_location.Name = "txt_location"
        Me.txt_location.Size = New System.Drawing.Size(390, 23)
        Me.txt_location.TabIndex = 0
        '
        'btn_search
        '
        Me.btn_search.Font = New System.Drawing.Font("Cambria", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_search.Location = New System.Drawing.Point(273, 172)
        Me.btn_search.Name = "btn_search"
        Me.btn_search.Size = New System.Drawing.Size(146, 32)
        Me.btn_search.TabIndex = 1
        Me.btn_search.Text = "Search"
        Me.btn_search.UseVisualStyleBackColor = True
        '
        'rd_btn_one_Sheet
        '
        Me.rd_btn_one_Sheet.AutoSize = True
        Me.rd_btn_one_Sheet.Font = New System.Drawing.Font("Cambria", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rd_btn_one_Sheet.Location = New System.Drawing.Point(273, 66)
        Me.rd_btn_one_Sheet.Name = "rd_btn_one_Sheet"
        Me.rd_btn_one_Sheet.Size = New System.Drawing.Size(261, 19)
        Me.rd_btn_one_Sheet.TabIndex = 2
        Me.rd_btn_one_Sheet.TabStop = True
        Me.rd_btn_one_Sheet.Text = "Merge Excel data from the different file"
        Me.rd_btn_one_Sheet.UseVisualStyleBackColor = True
        '
        'rd_btn_anotherSht
        '
        Me.rd_btn_anotherSht.AutoSize = True
        Me.rd_btn_anotherSht.Font = New System.Drawing.Font("Cambria", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rd_btn_anotherSht.Location = New System.Drawing.Point(555, 66)
        Me.rd_btn_anotherSht.Name = "rd_btn_anotherSht"
        Me.rd_btn_anotherSht.Size = New System.Drawing.Size(276, 19)
        Me.rd_btn_anotherSht.TabIndex = 3
        Me.rd_btn_anotherSht.TabStop = True
        Me.rd_btn_anotherSht.Text = "Merge Excel data from the different Sheet"
        Me.rd_btn_anotherSht.UseVisualStyleBackColor = True
        '
        'btn_M_A_Save
        '
        Me.btn_M_A_Save.Font = New System.Drawing.Font("Cambria", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_M_A_Save.Location = New System.Drawing.Point(273, 234)
        Me.btn_M_A_Save.Name = "btn_M_A_Save"
        Me.btn_M_A_Save.Size = New System.Drawing.Size(146, 31)
        Me.btn_M_A_Save.TabIndex = 4
        Me.btn_M_A_Save.Text = "Merge and save"
        Me.btn_M_A_Save.UseVisualStyleBackColor = True
        '
        'Merge_Excel
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1182, 564)
        Me.Controls.Add(Me.btn_M_A_Save)
        Me.Controls.Add(Me.rd_btn_anotherSht)
        Me.Controls.Add(Me.rd_btn_one_Sheet)
        Me.Controls.Add(Me.btn_search)
        Me.Controls.Add(Me.txt_location)
        Me.Name = "Merge_Excel"
        Me.Text = "Merge_Excel"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txt_location As TextBox
    Friend WithEvents btn_search As Button
    Friend WithEvents FolderBrowserDialog1 As FolderBrowserDialog
    Friend WithEvents rd_btn_one_Sheet As RadioButton
    Friend WithEvents rd_btn_anotherSht As RadioButton
    Friend WithEvents btn_M_A_Save As Button
End Class
