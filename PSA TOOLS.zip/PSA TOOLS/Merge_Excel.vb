﻿Imports System.IO

Imports System.Data.SqlClient

Imports Microsoft.Office.Interop
Imports System.Data.SqlClient.SqlException
Imports System.Data

Imports Microsoft.Office.Interop.Excel

Public Class Merge_Excel

    Dim exApp As New Excel.Application
    Dim exWb_source, exwb_dest As Excel.Workbook
    Dim exSht_source, exSht_dest, exSht_dest1 As Excel.Worksheet
    Dim excelrow As Integer
    Dim savedest1 As Boolean = False
    Dim savedest2 As Boolean = False




    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btn_M_A_Save.Click

        Using sdf As SaveFileDialog = New SaveFileDialog() With {.Filter = "Excel files (*.xlsx)|*.xlsx"}
            If savedest1 Then
                If txt_location.Text = Nothing Then
                    MsgBox("Excel file  is not save becouse Searchbox  is Empty!")
                Else
                    If sdf.ShowDialog() = DialogResult.OK Then
                        Try
                            exwb_dest.SaveAs(sdf.FileName)
                            exwb_dest.Close()
                            exApp.Quit()
                            MsgBox("Data Saved!")
                            txt_location.Clear()
                            txt_location.Text = ""
                        Catch ex As Exception
                            MsgBox("Data Not Saved!")

                        End Try
                    End If
                End If
            Else
                MsgBox("Please Select File !")
            End If

        End Using



        'Merge_Excel.Close()
        'Merge_Excel.Close()
        'System_Monitoring.Show()


    End Sub



    Dim b As Integer



    Private Sub btn_search_Click(sender As Object, e As EventArgs) Handles btn_search.Click


        'Try
        '    Dim Excel() As Process = Process.GetProcessesByName("EXCEL")
        '    For Each Process As Process In Excel
        '        Process.Kill()
        '    Next
        'Catch ex As Exception

        'End Try


        'If rd_btn_anotherSht.Checked Then
        If rd_btn_anotherSht.Checked Then


            Try
                savedest1 = True
                Dim path1 As String
                Using opf As FolderBrowserDialog = New FolderBrowserDialog()

                    If (opf.ShowDialog() = DialogResult.OK) Then

                        txt_location.Text = opf.SelectedPath

                        path1 = txt_location.Text

                    End If

                End Using
                Dim files() As String

                exwb_dest = exApp.Workbooks.Add()


                exSht_dest = exwb_dest.Worksheets(1)




                excelrow = 2
                If Directory.Exists(path1) Then
                    files = Directory.GetFiles(path1, "*.xlsx")


                    'For N As Integer = 1 To (files.Length + 1) - 1 Step 1
                    Dim N As Integer
                    If files.Length = 0 Then
                        MsgBox("Excle file Are not available on this Folder !")
                        txt_location.Clear()
                        txt_location.Text = ""
                    Else
                        For Each fName In files


                            'Dim xRet As Boolean
                            'xRet = IsWorkBookOpen(fName)
                            'If xRet Then
                            '    'MsgBox("dddd")
                            '    exWb_source.Close(fName)
                            'End If
                            Try
                                exWb_source = exApp.Workbooks.Open(fName)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                                txt_location.Clear()
                                txt_location.Text = ""
                                GoTo gyan1
                            End Try



                            N = exWb_source.Sheets.Count

                            For h As Integer = 1 To N Step 1
                                exSht_source = exWb_source.Sheets(h)

                                Dim c As Integer
                                c = 1

                                While True
                                    If String.IsNullOrEmpty(exSht_source.Cells(1, c).value) Then
                                        Exit While

                                    End If
                                    c = c + 1
                                End While

                                For i As Integer = 0 To c - 1 Step 1
                                    If exSht_dest.Cells(1, i + 1).value = Nothing Then

                                        exSht_dest.Cells(1, i + 1) = (exSht_source.Cells(1, i + 1).value)

                                    ElseIf exSht_dest.Cells(1, i + 1).value = (exSht_source.Cells(1, i + 1).value) Then


                                    Else
                                        MsgBox(" cannot  merge the excel file becouse Sheets are  diffirent!")
                                        txt_location.Clear()
                                        txt_location.Text = ""

                                        GoTo gyan1


                                    End If


                                Next


                            Next

                            For h As Integer = 1 To N Step 1
                                exSht_source = exWb_source.Sheets(h)



                                Dim c As Integer
                                c = 1

                                While True
                                    If String.IsNullOrEmpty(exSht_source.Cells(1, c).value) Then
                                        Exit While

                                    End If
                                    c = c + 1
                                End While
                                Dim r As Integer
                                r = 1
                                For i As Integer = 1 To c - 1 Step 1
                                    While True
                                        If String.IsNullOrEmpty(exSht_source.Cells(r, i).value) Then
                                            Exit While

                                        End If
                                        r = r + 1
                                    End While
                                Next


                                For i As Integer = 0 To c - 1 Step 1

                                    exSht_dest.Cells(1, i + 1) = (exSht_source.Cells(1, i + 1).value)




                                Next
                                For j As Integer = 1 To r - 1 Step 1



                                    For k As Integer = 1 To c - 1 Step 1


                                        exSht_dest.Cells(excelrow, k) = (exSht_source.Cells(j + 1, k).value)





                                    Next
                                    excelrow = excelrow + 1

                                Next
                                excelrow = excelrow - 1





                            Next









                            Exit For






                        Next
                    End If

                    'Else

                    ' MsgBox("Excle file Are not available on this table !")


                End If
            Catch ex As Exception
                MsgBox(ex.Message)
                txt_location.Clear()
                txt_location.Text = ""
            End Try

        ElseIf rd_btn_one_Sheet.Checked Then


            Try
                savedest1 = True
                Dim path1 As String
                Using opf As FolderBrowserDialog = New FolderBrowserDialog()

                    If (opf.ShowDialog() = DialogResult.OK) Then

                        txt_location.Text = opf.SelectedPath

                        path1 = txt_location.Text

                    End If

                End Using
                Dim files() As String
                exwb_dest = exApp.Workbooks.Add()


                exSht_dest = exwb_dest.Worksheets(1)



                excelrow = 2
                If Directory.Exists(path1) Then
                    files = Directory.GetFiles(path1, "*.xlsx")

                    If files.Length = 0 Then
                        MsgBox("Excle file Are not available on this Folder !")
                        txt_location.Clear()
                        txt_location.Text = ""
                        GoTo gyan1
                    Else
                        For Each fName In files


                            'Dim xRet As Boolean
                            'xRet = IsWorkBookOpen(fName)


                            'If xRet Then
                            '    exWb_source.Close(fName)
                            'End If
                            Try
                                exWb_source = exApp.Workbooks.Open(fName)

                            Catch ex As Exception
                                MsgBox(ex.Message)
                                txt_location.Clear()
                                txt_location.Text = ""
                                GoTo gyan1
                            End Try

                            exSht_source = exWb_source.Sheets(1)
                            Dim c As Integer
                            c = 1

                            While True
                                If String.IsNullOrEmpty(exSht_source.Cells(1, c).value) Then
                                    Exit While

                                End If
                                c = c + 1
                            End While
                            'Check header 
                            For i As Integer = 0 To c - 1 Step 1
                                If exSht_dest.Cells(1, i + 1).value = Nothing Then

                                    exSht_dest.Cells(1, i + 1) = (exSht_source.Cells(1, i + 1).value)

                                ElseIf exSht_dest.Cells(1, i + 1).value = (exSht_source.Cells(1, i + 1).value) Then


                                Else
                                    MsgBox(" cannot  merge the excel file becouse Excle file are diffirent from the one!")
                                    txt_location.Clear()
                                    txt_location.Text = ""

                                    GoTo gyan1


                                End If


                            Next
                            'Count Row
                            Dim r As Integer
                            r = 1

                            For i As Integer = 1 To c - 1 Step 1
                                While True
                                    If String.IsNullOrEmpty(exSht_source.Cells(r, i).value) Then
                                        Exit While

                                    End If
                                    r = r + 1
                                End While
                            Next



                            For i As Integer = 0 To c - 1 Step 1
                                exSht_dest.Cells(1, i + 1) = (exSht_source.Cells(1, i + 1).value)


                            Next



                            For j As Integer = 1 To r - 1 Step 1


                                For k As Integer = 1 To c - 1 Step 1


                                    exSht_dest.Cells(excelrow, k) = (exSht_source.Cells(j + 1, k).value)

                                Next
                                excelrow = excelrow + 1

                            Next
                            excelrow = excelrow - 1




                        Next

                    End If







                End If
            Catch ex As Exception
                MsgBox(ex.Message)
                txt_location.Clear()
                txt_location.Text = ""

            End Try
        Else
            MsgBox("Please Checked Radio Button")

        End If

gyan1:


    End Sub

    Private Sub rd_btn_one_Sheet_CheckedChanged(sender As Object, e As EventArgs) Handles rd_btn_one_Sheet.CheckedChanged

    End Sub

    Private Sub rd_btn_anotherSht_CheckedChanged(sender As Object, e As EventArgs) Handles rd_btn_anotherSht.CheckedChanged

    End Sub

    Dim newForm As Merge_Excel
    Private Sub rd_btn_one_Sheet_Click(sender As Object, e As EventArgs) Handles rd_btn_one_Sheet.Click
        'exApp.Quit()

        'Me.Close()
        'Reload.Show()
        txt_location.Clear()
        txt_location.Text = ""

    End Sub


    Private Sub rd_btn_anotherSht_Click(sender As Object, e As EventArgs) Handles rd_btn_anotherSht.Click
        'exApp.Quit()

        'Me.Close()
        'Reload.Show()
        txt_location.Clear()
        txt_location.Text = ""

    End Sub
End Class











'hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh






