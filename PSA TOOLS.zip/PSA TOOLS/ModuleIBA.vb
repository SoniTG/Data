﻿Module ModuleIBA
    Public arrval(12) As String
    Public arrvall(5) As String
End Module
