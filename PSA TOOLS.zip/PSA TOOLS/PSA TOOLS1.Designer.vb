﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class PSA_TOOLS1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btn_kill_excel = New System.Windows.Forms.Button()
        Me.btn_merge_excel = New System.Windows.Forms.Button()
        Me.btn_blob_data = New System.Windows.Forms.Button()
        Me.btn_data = New System.Windows.Forms.Button()
        Me.btn_system_m = New System.Windows.Forms.Button()
        Me.btn_task_m = New System.Windows.Forms.Button()
        Me.lbl_LogOut = New System.Windows.Forms.LinkLabel()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Cambria", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Navy
        Me.Label2.Location = New System.Drawing.Point(359, 21)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(153, 32)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "PSA TOOLS"
        '
        'btn_kill_excel
        '
        Me.btn_kill_excel.Font = New System.Drawing.Font("Cambria", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_kill_excel.Location = New System.Drawing.Point(112, 116)
        Me.btn_kill_excel.Name = "btn_kill_excel"
        Me.btn_kill_excel.Size = New System.Drawing.Size(155, 34)
        Me.btn_kill_excel.TabIndex = 4
        Me.btn_kill_excel.Text = "KILL EXCEL"
        Me.btn_kill_excel.UseVisualStyleBackColor = True
        '
        'btn_merge_excel
        '
        Me.btn_merge_excel.Font = New System.Drawing.Font("Cambria", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_merge_excel.Location = New System.Drawing.Point(318, 116)
        Me.btn_merge_excel.Name = "btn_merge_excel"
        Me.btn_merge_excel.Size = New System.Drawing.Size(155, 34)
        Me.btn_merge_excel.TabIndex = 5
        Me.btn_merge_excel.Text = "MERGE EXCEL"
        Me.btn_merge_excel.UseVisualStyleBackColor = True
        '
        'btn_blob_data
        '
        Me.btn_blob_data.Font = New System.Drawing.Font("Cambria", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_blob_data.Location = New System.Drawing.Point(523, 116)
        Me.btn_blob_data.Name = "btn_blob_data"
        Me.btn_blob_data.Size = New System.Drawing.Size(155, 34)
        Me.btn_blob_data.TabIndex = 6
        Me.btn_blob_data.Text = "BLOB DATA"
        Me.btn_blob_data.UseVisualStyleBackColor = True
        '
        'btn_data
        '
        Me.btn_data.Font = New System.Drawing.Font("Cambria", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_data.Location = New System.Drawing.Point(112, 204)
        Me.btn_data.Name = "btn_data"
        Me.btn_data.Size = New System.Drawing.Size(114, 34)
        Me.btn_data.TabIndex = 7
        Me.btn_data.Text = "DATA"
        Me.btn_data.UseVisualStyleBackColor = True
        '
        'btn_system_m
        '
        Me.btn_system_m.Font = New System.Drawing.Font("Cambria", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_system_m.Location = New System.Drawing.Point(238, 204)
        Me.btn_system_m.Name = "btn_system_m"
        Me.btn_system_m.Size = New System.Drawing.Size(235, 34)
        Me.btn_system_m.TabIndex = 8
        Me.btn_system_m.Text = "SYSTEM MONITORING"
        Me.btn_system_m.UseVisualStyleBackColor = True
        '
        'btn_task_m
        '
        Me.btn_task_m.Font = New System.Drawing.Font("Cambria", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_task_m.Location = New System.Drawing.Point(479, 204)
        Me.btn_task_m.Name = "btn_task_m"
        Me.btn_task_m.Size = New System.Drawing.Size(214, 34)
        Me.btn_task_m.TabIndex = 9
        Me.btn_task_m.Text = "TASK MONITORING"
        Me.btn_task_m.UseVisualStyleBackColor = True
        '
        'lbl_LogOut
        '
        Me.lbl_LogOut.AutoSize = True
        Me.lbl_LogOut.Font = New System.Drawing.Font("Cambria", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_LogOut.Location = New System.Drawing.Point(395, 288)
        Me.lbl_LogOut.Name = "lbl_LogOut"
        Me.lbl_LogOut.Size = New System.Drawing.Size(76, 22)
        Me.lbl_LogOut.TabIndex = 10
        Me.lbl_LogOut.TabStop = True
        Me.lbl_LogOut.Text = "Log Out"
        '
        'PSA_TOOLS1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(888, 481)
        Me.Controls.Add(Me.lbl_LogOut)
        Me.Controls.Add(Me.btn_task_m)
        Me.Controls.Add(Me.btn_system_m)
        Me.Controls.Add(Me.btn_data)
        Me.Controls.Add(Me.btn_blob_data)
        Me.Controls.Add(Me.btn_merge_excel)
        Me.Controls.Add(Me.btn_kill_excel)
        Me.Controls.Add(Me.Label2)
        Me.Name = "PSA_TOOLS1"
        Me.Text = "PSA_TOOLS"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label2 As Label
    Friend WithEvents btn_kill_excel As Button
    Friend WithEvents btn_merge_excel As Button
    Friend WithEvents btn_blob_data As Button
    Friend WithEvents btn_data As Button
    Friend WithEvents btn_system_m As Button
    Friend WithEvents btn_task_m As Button
    Friend WithEvents lbl_LogOut As LinkLabel
End Class
