﻿
Imports System.Data.SqlClient
Imports System.IO
Imports Microsoft.Office.Interop
Imports System.Data.SqlClient.SqlException
Imports System.Data
Imports ClosedXML.Excel
Imports Microsoft.Office.Interop.Excel

Public Class PSA_TOOLS1
    Private Sub btn_kill_excel_Click(sender As Object, e As EventArgs) Handles btn_kill_excel.Click



        Try
            Dim Excel() As Process = Process.GetProcessesByName("EXCEL")
            For Each Process As Process In Excel
                Process.Kill()
            Next
        Catch ex As Exception

        End Try










    End Sub

    Private Sub btn_merge_excel_Click(sender As Object, e As EventArgs) Handles btn_merge_excel.Click
        Merge_Excel.Show()
        Dim path As String


    End Sub

    Private Sub btn_blob_data_Click(sender As Object, e As EventArgs) Handles btn_blob_data.Click
        Blob_Data.Show()

    End Sub

    Private Sub btn_data_Click(sender As Object, e As EventArgs) Handles btn_data.Click
        Data.Show()

    End Sub



    Private Sub btn_task_m_Click(sender As Object, e As EventArgs) Handles btn_task_m.Click

        Task_Monitoring.Show()

    End Sub

    Private Sub btn_system_m_Click(sender As Object, e As EventArgs) Handles btn_system_m.Click
        System_Monitoring.Show()
    End Sub

    Private Sub lbl_LogOut_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lbl_LogOut.LinkClicked
        PSA_TOOL.Close()
    End Sub

    Private Sub PSA_TOOLS1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing

        Dim cofigmsg = MsgBox("Are you sure you want to Exit This Application! ?", MessageBoxButtons.YesNo)
        If cofigmsg = DialogResult.Yes Then

            PSA_TOOL.Close()
        ElseIf cofigmsg = DialogResult.No Then
            e.Cancel = True
        End If
    End Sub
End Class