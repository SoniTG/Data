﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class System_Monitoring
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btn_Add = New System.Windows.Forms.Button()
        Me.DgvSystemMonetoring = New System.Windows.Forms.DataGridView()
        Me.C_MenuStrip_Sys_Monitor = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeleteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Refresh = New System.Windows.Forms.Button()
        CType(Me.DgvSystemMonetoring, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.C_MenuStrip_Sys_Monitor.SuspendLayout()
        Me.SuspendLayout()
        '
        'btn_Add
        '
        Me.btn_Add.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Add.Location = New System.Drawing.Point(951, 40)
        Me.btn_Add.Name = "btn_Add"
        Me.btn_Add.Size = New System.Drawing.Size(87, 26)
        Me.btn_Add.TabIndex = 7
        Me.btn_Add.Text = "Add"
        Me.btn_Add.UseVisualStyleBackColor = True
        '
        'DgvSystemMonetoring
        '
        Me.DgvSystemMonetoring.AllowUserToAddRows = False
        Me.DgvSystemMonetoring.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DgvSystemMonetoring.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgvSystemMonetoring.Location = New System.Drawing.Point(56, 40)
        Me.DgvSystemMonetoring.Name = "DgvSystemMonetoring"
        Me.DgvSystemMonetoring.Size = New System.Drawing.Size(889, 421)
        Me.DgvSystemMonetoring.TabIndex = 8
        '
        'C_MenuStrip_Sys_Monitor
        '
        Me.C_MenuStrip_Sys_Monitor.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EditToolStripMenuItem, Me.DeleteToolStripMenuItem})
        Me.C_MenuStrip_Sys_Monitor.Name = "ContextMenuStrip1"
        Me.C_MenuStrip_Sys_Monitor.Size = New System.Drawing.Size(153, 70)
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.EditToolStripMenuItem.Text = "Edit"
        '
        'DeleteToolStripMenuItem
        '
        Me.DeleteToolStripMenuItem.Name = "DeleteToolStripMenuItem"
        Me.DeleteToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.DeleteToolStripMenuItem.Text = "Delete"
        '
        'Refresh
        '
        Me.Refresh.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Refresh.Location = New System.Drawing.Point(951, 88)
        Me.Refresh.Name = "Refresh"
        Me.Refresh.Size = New System.Drawing.Size(87, 26)
        Me.Refresh.TabIndex = 9
        Me.Refresh.Text = "Refresh"
        Me.Refresh.UseVisualStyleBackColor = True
        '
        'System_Monitoring
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1085, 555)
        Me.Controls.Add(Me.Refresh)
        Me.Controls.Add(Me.DgvSystemMonetoring)
        Me.Controls.Add(Me.btn_Add)
        Me.Name = "System_Monitoring"
        Me.Text = "System_Monitoring"
        CType(Me.DgvSystemMonetoring, System.ComponentModel.ISupportInitialize).EndInit()
        Me.C_MenuStrip_Sys_Monitor.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btn_Add As Button
    Friend WithEvents DgvSystemMonetoring As DataGridView
    Friend WithEvents C_MenuStrip_Sys_Monitor As ContextMenuStrip
    Friend WithEvents EditToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DeleteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Refresh As Button
End Class
