﻿
Imports System.Data.SqlClient
Imports System.IO
Imports Microsoft.Office.Interop
Imports System.Data.SqlClient.SqlException
Imports System.Data
Imports ClosedXML.Excel
Public Class System_Monitoring


    Private Sub btn_Add_Click(sender As Object, e As EventArgs) Handles btn_Add.Click
        Add_Edit.Show()
    End Sub


    Dim con As New SqlConnection
    Dim cmd As New SqlCommand

    Private Sub System_Monitoring_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        load()



        'timer.Start()
        Dim timer As New Timer()
        timer.Interval = 60000
        AddHandler timer.Tick, AddressOf timer_Tick
        timer.Start()

    End Sub



    Private Sub timer_Tick(ByVal sender As Object, ByVal e As EventArgs)
        load()


    End Sub


    Public Sub load()
        Dim dt As New DataTable
        con = New SqlConnection("Server=176.0.0.60\lptgsqldev;Database=PSA_TOOLS;User Id=153521;Password=Welcome@135;")

        cmd = New SqlCommand("SELECT [ID]
      ,[AssetId]
      ,[OwnerName]
      ,[SecondOwnerName]
      ,[IPAddress] ,[ThirdUserName] FROM [PSA_TOOLS].[dbo].[T_ASSET_MONITOR]  ORDER BY [ID] ASC", con)
        con.Open()
        cmd.ExecuteNonQuery()
        Dim adpt As New SqlDataAdapter
        adpt.SelectCommand = cmd
        adpt.Fill(dt)
        DgvSystemMonetoring.DataSource = dt
        'Dim b As Integer
        'b = DataGridView1.Rows.Count()
        DgvSystemMonetoring.EnableHeadersVisualStyles = False
        DgvSystemMonetoring.ColumnHeadersDefaultCellStyle.BackColor = Color.White
        DgvSystemMonetoring.ColumnHeadersDefaultCellStyle.ForeColor = Color.Blue
        DgvSystemMonetoring.ColumnHeadersDefaultCellStyle.Font = New Font("Cambria", 10, FontStyle.Bold)

        For i As Integer = 0 To DgvSystemMonetoring.Rows.Count - 1 Step 1


            DgvSystemMonetoring.Rows(i).DefaultCellStyle.Font = New Font("Cambria", 10, FontStyle.Regular)

        Next

        Try
            For i As Integer = 0 To DgvSystemMonetoring.Rows.Count - 1 Step 1
                'Check IP Address

                Dim val As String

                val = DgvSystemMonetoring.Rows(i).Cells(4).Value
                Try
                    My.Computer.Network.Ping(val)
                Catch ex As Exception
                    DgvSystemMonetoring.Rows(i).DefaultCellStyle.BackColor = Color.Red
                    GoTo next1
                End Try
                If My.Computer.Network.IsAvailable Then
                    If My.Computer.Network.Ping(val) = Nothing Then
                        'DataGridView1.Rows(i).Cells(4).Style.BackColor = Color.Red
                        DgvSystemMonetoring.Rows(i).DefaultCellStyle.BackColor = Color.Red
                        'DataGridView1.Columns(4).DefaultCellStyle.BackColor = Color.Red

                    ElseIf My.Computer.Network.Ping(val) Then
                        'DataGridView1.Rows(i).Cells(4).Style.BackColor = Color.Green
                        DgvSystemMonetoring.Rows(i).DefaultCellStyle.BackColor = Color.Green
                        'DataGridView1.Columns(4).DefaultCellStyle.BackColor = Color.Green
                    Else

                    End If

                End If
next1:
            Next
        Catch ex As Exception
            MsgBox("Request not send")
        End Try
    End Sub

    Dim Index As Integer

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DgvSystemMonetoring.CellClick
        Try
            DgvSystemMonetoring.Rows(e.RowIndex).Selected = True
            Index = e.RowIndex
            DgvSystemMonetoring.CurrentCell = DgvSystemMonetoring.Rows(e.RowIndex).Cells(0)
            Dim selectdrow As DataGridViewRow
            selectdrow = DgvSystemMonetoring.Rows(e.RowIndex)
            Dim c As Integer
            c = 0
            c = DgvSystemMonetoring.Columns.Count
            For i As Integer = 0 To c - 1
                If IsDBNull(selectdrow.Cells(i).Value) = False Then
                    arrvall(i) = selectdrow.Cells(i).Value
                Else
                    arrvall(i) = ""
                End If
            Next


            C_MenuStrip_Sys_Monitor.Show(MousePosition.X, MousePosition.Y)
        Catch ex As Exception

        End Try





    End Sub

    Private Sub DeleteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DeleteToolStripMenuItem.Click
        Dim cofigmsg = MsgBox("Are you sure to delete!", MessageBoxButtons.YesNo)
        If cofigmsg = DialogResult.Yes Then

            cmd = New SqlCommand(" DELETE From [dbo].[T_ASSET_MONITOR]
      Where [ID]='" + arrvall(0) + "'", con)

            cmd.ExecuteNonQuery()
            MsgBox("Data successfully deleted")
            load()


        End If
    End Sub

    Private Sub EditToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EditToolStripMenuItem.Click


        Edit.Show()
    End Sub

    Private Sub Refresh_Click(sender As Object, e As EventArgs) Handles Refresh.Click
        load()
    End Sub
End Class