﻿
Imports System.Data
Imports System.Data.SqlClient

Public Class Task_Monitoring
    Dim Sqlcon As New SqlConnection("Data Source=176.0.0.60\lptgsqldev; Database=PSA_TOOLS;uid=153521;pwd=Welcome@135")


    Public Sub gridLoad()
        Dim dt As New DataTable

        'Dim query1 As String = ""
        'Dim query As String = "select * from DB_TABLE_INFO"
        Dim cmd = New SqlCommand("select top(5) * from DB_TABLE_INFO WHERE ACTIVE = 0", Sqlcon)
        Sqlcon.Open()
        Dim adapter As New SqlDataAdapter(cmd)
        adapter.Fill(dt)

        dt.Columns.Add("LastDate", GetType(DateTime))

        For row As Integer = 0 To dt.Rows.Count - 1
            Dim dt1 As New DataTable
            dt1.Clear()
            'query1 = "select Top(1) " & dt.Rows(row)(2) & " from " & dt.Rows(row)(0) & ".[dbo]." & dt.Rows(row)(1) & " ORDER BY " & dt.Rows(row)(2) & " DESC"
            Dim cmd1 = New SqlCommand("select max(" & dt.Rows(row)(2) & ") from " & dt.Rows(row)(0) & ".[dbo]." & dt.Rows(row)(1), Sqlcon)

            Dim adapter1 As New SqlDataAdapter(cmd1)
            Try
                adapter1.Fill(dt1)
                dt.Rows(row)("LastDate") = dt1.Rows(0)(0)
            Catch ex As Exception

            End Try





        Next
        dgvData.DataSource = dt
        ''get system now datetime
        'Dim sysdatetime As DateTime = DateTime.Now
        'For i As Integer = 0 To dgvData.Rows.Count - 2
        '    Dim lastedatetimeVal As DateTime = dt.Rows(i)("LastDate")
        '    Try
        '        Dim timecheck As Int32 = DateDiff(DateInterval.Minute, lastedatetimeVal, sysdatetime)
        '        Dim timedab As Int32 = dt.Rows(i)("CheckFreqHrs") * 60
        '        Dim t1 As Int32 = DateDiff(DateInterval.Hour, lastedatetimeVal, sysdatetime)
        '        Dim t2 As Int32 = dt.Rows(i)("CheckFreqHrs")
        '        If DateDiff(DateInterval.Hour, lastedatetimeVal, sysdatetime) >= dt.Rows(i)("CheckFreqHrs") Then
        '            dgvData.Rows(i).Cells(0).Style.BackColor = Color.Red
        '        End If
        '    Catch ex As Exception

        '    End Try

        'Next


    End Sub

    Private Sub btn_Data_Monitor_Click(sender As Object, e As EventArgs) Handles btn_Data_Monitor.Click
        Sqlcon.Close()
        gridLoad()
    End Sub

    Private Sub btn_IP_Monitor_Click(sender As Object, e As EventArgs) Handles btn_IP_Monitor.Click
        Sqlcon.Close()
        Ip_SERVER.Show()
    End Sub

    Private Sub Task_Monitoring_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Sqlcon.Close()
        gridLoad()
    End Sub
End Class