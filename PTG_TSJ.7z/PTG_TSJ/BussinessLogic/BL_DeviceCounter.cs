﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;
using System.Web;

namespace PTG_TSJ_Main.BussinessLogic
{
    public class BL_DeviceCounter
    {
      
           LP_PROCESS_DATA_v1Device_Counter dbWrmDevice_Counter = new LP_PROCESS_DATA_v1Device_Counter();
            List<CHART_LP11> lst1 = new List<CHART_LP11>();
            List<ModelBox> ModelData = new List<ModelBox>();

        
        string subs1 = "";
        internal MultipleData GetDataForDeviceCounter(String fromName1, String toName1, String Username, String Password, String WaterBox1, String WaterBox2, String WaterBox3, String WaterBox4, String CC_SHARECUT, String CD_SHARECUT, String LiftingDown, String PeelBar, String TroughSwitch, String ChangeDAtetime)
        {
            string ToDate1 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            string FromDate1 = DateTime.Now.AddDays(-7).ToString("yyyy-MM-dd HH:mm:ss");

            //Declare DateTime Global And change String To DateTime;
            DateTime frmDate = new DateTime(2023, 06, 14, 11, 21, 59);

            DateTime toDate = new DateTime(2023, 06, 14, 11, 21, 59); ;
            if (fromName1 == null && toName1 == null)
            {
                fromName1 = DateTime.Now.AddDays(-7).ToString("yyyy-MM-dd HH:mm:ss");
                
                toName1 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                frmDate = DateTime.Parse(fromName1);
                toDate = DateTime.Parse(toName1);
               
            }
            else
            {
                ToDate1 = toName1;
                FromDate1 = fromName1;
                frmDate = DateTime.Parse(fromName1);

                toDate = DateTime.Parse(toName1);


            }
            var table = new MultipleData();
            List<FromDateToDate> lst = new List<FromDateToDate>();
            
            FromDateToDate c0 = new FromDateToDate()
            {

                FromDate = FromDate1,
                ToDate = ToDate1,
                FromDateName = "fromName1",
                ToDateName = "toName1",
                ID = "",
                todateId = "todateId1",
                FromdateId = "fromdateId2",
                Section = "",
                Heat = "Heat"

            };
            lst.Add(c0);

            ModelDatafuction( "Username", "Password","TroughSwitch");
            ModelDatafuction("Username", "Password", "WaterBox1");
            ModelDatafuction("Username", "Password", "WaterBox2");
            ModelDatafuction("Username", "Password", "WaterBox3");
            ModelDatafuction("Username", "Password", "WaterBox4");
            ModelDatafuction("Username", "Password", "CC_SHARECUT");
            ModelDatafuction("Username", "Password", "CD_SHARECUT");
            ModelDatafuction("Username", "Password", "LiftingDown");
            ModelDatafuction("Username", "Password", "PeelBar");

            string[] AllChartName = { WaterBox1, WaterBox2, WaterBox3, WaterBox4, CC_SHARECUT, CD_SHARECUT, LiftingDown, PeelBar, TroughSwitch };
            string Chartnamevalidate = "";
            for (int i = 0; i < AllChartName.Length; i++)
            {
                if (AllChartName[i]!="" && AllChartName[i] != null)
                {
                    HttpContext.Current.Session["Chartname"] = AllChartName[i];
                    Chartnamevalidate = AllChartName[i];
                }
            }
            int validData = 0;
            if (Username!=null && Password!=null)
            {
                 validData = IsValidate(Username, Password);
                Username = null;
                Password = null;
            }
                
            
            if (Chartnamevalidate.Length >= 1 &&  ChangeDAtetime !=null)
            {
                InsrtValue(WaterBox1, WaterBox2, WaterBox3, WaterBox4, CC_SHARECUT, CD_SHARECUT, LiftingDown, PeelBar, TroughSwitch, ChangeDAtetime);
                validData = 0;
            }
            HttpContext.Current.Session["Validation"] = validData;
            TroughSch(fromName1, toName1);
            WaterBox(fromName1, toName1);
            CC_Shear(fromName1, toName1);
            CD_Shear(fromName1, toName1);
            LiftingDownf(fromName1, toName1);
            PeelBarf(fromName1, toName1);

            table.ChartData = lst1;
            table.FromDateToDate = lst;
            table.ModelData = ModelData;
            return table;
        }


        public void TroughSch(String fromName1,String toName1)
        {

            //AllContainerChart(fromName1, toName1, "", "WRM_TROUGHSWITCH", "0", "ContainerChat1", "CC_ShareCut", "C & C ShearCut");

            //string TROUGHSWITCH1_Value = $@"  select [COUNT] FROM [LP_PROCESS_DATA_v1].[dbo].[WRM_TROUGHSWITCH] where [COUNT] !='Dummy' AND [TIMESTAMP]>(select top 1 [timestamp] from [WRM_blt_data].[dbo].[WRM_CC_SHEARCUT]  where [COUNT] = 'Dummy' order by [timestamp] desc)";
            string TROUGHSWITCH1_Value = $@"  select sum(cast([COUNT] as int)) AS TOTALCOUNT FROM [WRM_blt_data].[dbo].[WRM_TROUGHSWITCH] where [COUNT]!='DUMMY' AND [TIMESTAMP]>(select top 1 [timestamp] from [WRM_blt_data].[dbo].[WRM_TROUGHSWITCH] where [COUNT] = '0' order by [timestamp] desc)";

            //DBQuery obj = new DBQuery();
            
            //var resultTROUGHSWITCH_Value1 = obj.RunQuery<WRM_TROUGHSWITCH2>(dbWrmDevice_Counter, TROUGHSWITCH1_Value);
            var resultTROUGHSWITCH_Value = dbWrmDevice_Counter.Database.SqlQuery<WRM_TROUGHSWITCH2>(TROUGHSWITCH1_Value);
            var TroughVAlue = 0;
            foreach (WRM_TROUGHSWITCH2 m in resultTROUGHSWITCH_Value)
            {
                try
                {
                    if ( m.COUNT != null)
                    {
                        TroughVAlue += Convert.ToInt32(m.COUNT);
                    }
                }
                catch
                {

                }

            }
            //string TROUGHSWITCH = $@"  select [COUNT],TIMESTAMP  FROM [LP_PROCESS_DATA_v1].[dbo].[WRM_TROUGHSWITCH] where 
            //[COUNT]!='DUMMY' AND   timestamp  between'{fromName1}' and '{toName1}' group by [COUNT],TIMESTAMP  order by TIMESTAMP asc";
            string TROUGHSWITCH = $@"select sum(cast([COUNT] as int)) AS COUNT, CONVERT(VARCHAR,TIMESTAMP, 23) as TIMESTAMP FROM[WRM_blt_data].[dbo].[WRM_TROUGHSWITCH] where[COUNT] != 'DUMMY' AND CONVERT(VARCHAR,TIMESTAMP, 23)  between'{fromName1}' and '{toName1}' group by CONVERT(VARCHAR,TIMESTAMP, 23) order by TIMESTAMP asc";
            var resultTROUGHSWITCH = dbWrmDevice_Counter.Database.SqlQuery<WRM_TROUGHSWITCH2>(TROUGHSWITCH);
            //string[] NameXsisBubble = { "Y1", "Y2" };
            string ChartBubble = "";
            int MaxValueBubble = 0;
            ChartBubble += "{name:'TroughSwitch',type:'bar',label:{show:true,formatter: ' {b}',color:'black',fontSize:'0.5rem',fontWeight:'bold',rotate: 40},data:[";
            //ChartBubble += "{name:'TroughSwitch',type:'bar',data:[";
            try
            {
                foreach (WRM_TROUGHSWITCH2 m in resultTROUGHSWITCH)
                {
                    if (MaxValueBubble < Convert.ToInt32(m.COUNT))
                    {
                        MaxValueBubble = Convert.ToInt32(m.COUNT) + 200;
                    }

                    ChartBubble += "['" + m.TIMESTAMP + "'," + m.COUNT + "],";

                }
            }
            catch (Exception e)
            {

            }
            
            ChartBubble += "]";
            ChartBubble += " },";
            CHART_LP11 c10 = new CHART_LP11()
            {
                FromDate = "",
                ID = "Container4",
                Title = "TroughSwitch",
                TypeX = "time",
                TypeY = "Vlaue",
                ShowLegend = "true",
                Width = "{yyyy}:{MM}:{dd}",
                ShowToolBox = ChartBubble,
                MaxAxisData = Convert.ToString(MaxValueBubble),
                MinAxisData = "0",
                SeriesData = "",
                divcolsm = "6",
                divHeight = "35vh"


            };
            lst1.Add(c10);
        }

        public void CC_Shear(String fromName1, String toName1 )
        {
            AllContainerChart(fromName1, toName1, "", "WRM_CC_SHEARCUT", "Dummy", "ContainerChat2","CC_ShareCut", "C & C ShearCut");
            
        }

        public void CD_Shear(String fromName1, String toName1)
        {

            AllContainerChart(fromName1, toName1, "", "WRM_CD_SHEARCUT", "Dummy", "ContainerChat3", "CD_ShareCut", "C & D ShearCut");
            
        }
        public void LiftingDownf(String fromName1, String toName1)
        {

            AllContainerChart(fromName1, toName1, "DOWN", "WRM_LIFTING_GUIDE_PEELBAR", "Dummy", "ContainerChat4", "LiftingDown", "Lifting Down");
            
        }
        public void PeelBarf(String fromName1, String toName1)
        {

            AllContainerChart(fromName1, toName1, "PEELBAR", "WRM_LIFTING_GUIDE_PEELBAR", "Dummy", "ContainerChat5", "PeelBar", "PeelBar");
            
        }


        public void WaterBox(String fromName1, String toName1)
        {


            subs1 = "";
            var dataTotalWB1 = WaterBoxTotal("COUNT_WB1");
            var dataTotalWB2 = WaterBoxTotal("COUNT_WB2");
            var dataTotalWB3 = WaterBoxTotal("COUNT_WB3");
            var dataTotalWB4 = WaterBoxTotal("COUNT_WB4");
            var COUNT_WB1 = WaterBoxChart(fromName1, toName1, "COUNT_WB1");
            var COUNT_WB2 = WaterBoxChart(fromName1, toName1, "COUNT_WB2");
            var COUNT_WB3 = WaterBoxChart(fromName1, toName1, "COUNT_WB3");
            var COUNT_WB4 = WaterBoxChart(fromName1, toName1, "COUNT_WB4");
            var datachart = COUNT_WB1 + COUNT_WB2 + COUNT_WB3 + COUNT_WB4;

             string[] subs11 = subs1.Split(',');
            int Arraycount = subs11.Length;
            int[] myint = new int[Arraycount];
            for (int i = 0; i < myint.Length; i++)
            {
                if (subs11[i].Length >=1)
                {
                    myint[i] = int.Parse(subs11[i]);
                }
               
            }
            int WaterBx = myint.Max();
            CHART_LP11 c10 = new CHART_LP11()
            {
                FromDate = "",
                ID = "Container19",
                Title = "Water Box Counter",
                TypeX = "time",
                TypeY = "Vlaue",
                ShowLegend = "true",
                Width = "{yyyy}:{MM}:{dd}",
                ShowToolBox = datachart,
                MaxAxisData = Convert.ToString(WaterBx+100),
                MinAxisData = "0",
                SeriesData = "",
                divcolsm = "6",
                divHeight = "35vh"


            };
            lst1.Add(c10);

           

    }
        public int WaterBoxTotal(String COUNT_WB)
        {
            string WBOX_Value = $@"select sum(cast([{COUNT_WB}] as int)) As Count from[WRM_blt_data].[dbo].[WRM_WATERBOX_COUNT] where[TIMESTAMP] > (Select top 1[timestamp] from[WRM_blt_data].[dbo].[WRM_WATERBOX_COUNT] where[{COUNT_WB}] = 'Dummy' order by[timestamp] desc)";
            var resultWBOX_Value = dbWrmDevice_Counter.Database.SqlQuery<WRM_TROUGHSWITCH2>(WBOX_Value);
            var totalWBOX_Value = 0;
            try
            {
                foreach (WRM_TROUGHSWITCH2 m in resultWBOX_Value)
            {
                totalWBOX_Value += Convert.ToInt32(m.COUNT);

            }
             }
            catch (Exception e)
            {

            }
            return totalWBOX_Value;
        }
        public string WaterBoxChart(String fromName1, String toName1,String COUNT_WB)
        {
            string WBOX_CHART = $@"Select sum(isnull(cast([{COUNT_WB}] As int), 0)) As Count, CONVERT(VARCHAR,TIMESTAMP, 23) as TIMESTAMP from[WRM_blt_data].[dbo].[WRM_WATERBOX_COUNT] where[timestamp] between'{fromName1}' and '{toName1}' and [{COUNT_WB}]!= 'Dummy' group by CONVERT(VARCHAR,TIMESTAMP, 23) order by TIMESTAMP asc";
            var resultWBOX_CHART = dbWrmDevice_Counter.Database.SqlQuery<WRM_TROUGHSWITCH2>(WBOX_CHART);
           
            string ChartWB = "";
            int MaxValueBubble = 0;
            //ChartBubble += "{name:'" + NameXsisBubble[0] + "',type:'bar',label:{show:true,formatter: ' {b}',color:'black',fontSize:'0.5rem',fontWeight:'bold',rotate: 40},data:[";
            ChartWB += "{name:'"+COUNT_WB+"',type:'bar',data:[";

            try
            {
                foreach (WRM_TROUGHSWITCH2 m in resultWBOX_CHART)
                {
                    if (MaxValueBubble < Convert.ToInt32(m.COUNT))
                    {
                        MaxValueBubble = Convert.ToInt32(m.COUNT) + 10;
                        subs1 += Convert.ToString(MaxValueBubble)+",";
                    }
                    ChartWB += "['" + m.TIMESTAMP + "'," + m.COUNT + "],";

                }
            }
            catch (Exception e)
            {

            }

            ChartWB += "]";
            ChartWB += " },";
            

            return ChartWB;
        }



        public void AllContainerChart(String fromName1, String toName1,String catagory,String TableName,String Count, String ContainerName,String NameLegend,String NameChart)
        {
            string TotalValue = "";
            if (catagory != "")
            {
                TotalValue = $@"select sum(cast([COUNT] as int)) AS COUNT FROM[WRM_blt_data].[dbo].[{TableName}] where [COUNT] != 'Dummy' and CATEGORY = '{catagory}' AND[TIMESTAMP] > (select top 1[timestamp] from[WRM_blt_data].[dbo].[{TableName}]  where[COUNT] = '{Count}' and CATEGORY = '{catagory}' order by[timestamp] desc)";
            }
            else
            {
                TotalValue = $@"select sum(cast([COUNT] as int)) AS COUNT FROM [WRM_blt_data].[dbo].[{TableName}] where [COUNT]!='DUMMY' AND [TIMESTAMP]>(select top 1 [timestamp] from [WRM_blt_data].[dbo].[{TableName}] where [COUNT] = '{Count}' order by [timestamp] desc)";
            }
            
            var resultTotalValue = dbWrmDevice_Counter.Database.SqlQuery<WRM_TROUGHSWITCH2>(TotalValue).ToArray();
            var TroughVAlue = 0;
            try
            {
                foreach (WRM_TROUGHSWITCH2 m in resultTotalValue)
                {
                    TroughVAlue += Convert.ToInt32(m.COUNT);

                }
            }
            catch (Exception e)
            {

            }
            
            string ChartDataVAlue = "";
            if (catagory != "")
            {
                ChartDataVAlue = $@" select SUM(cast(COUNT as int)) as Count,CONVERT(VARCHAR,TIMESTAMP, 23) as TIMESTAMP  from [WRM_blt_data].[dbo].[{TableName}] WHERE COUNT<> 'Dummy'   and CATEGORY = '{catagory}'  and CONVERT(VARCHAR,TIMESTAMP, 23)  between'{fromName1}' and '{toName1}'  group by  CONVERT(VARCHAR,TIMESTAMP, 23)  order by TIMESTAMP asc";
            }
            else
            {
                ChartDataVAlue = $@" select SUM(cast(COUNT as int)) as Count,CONVERT(VARCHAR,TIMESTAMP, 23) as TIMESTAMP  from [WRM_blt_data].[dbo].[{TableName}] WHERE COUNT<> 'Dummy'   and CONVERT(VARCHAR,TIMESTAMP, 23)  between'{fromName1}' and '{toName1}'  group by  CONVERT(VARCHAR,TIMESTAMP, 23)  order by TIMESTAMP asc";
            }
              
            var resultChartDataVAlue = dbWrmDevice_Counter.Database.SqlQuery<WRM_TROUGHSWITCH2>(ChartDataVAlue);
            
            string ChartAll = "";
            int MaxValueBubble = 0;
            ChartAll += "{name:'" + NameLegend + "',type:'bar',data:[";
            //ChartBubble += "{name:'TroughSwitch',type:'bar',data:[";
            var checkDate = fromName1;
            try
            {
                foreach (WRM_TROUGHSWITCH2 m in resultChartDataVAlue)
                {
                    if (MaxValueBubble < Convert.ToInt32(m.COUNT))
                    {
                        MaxValueBubble = Convert.ToInt32(m.COUNT) + 300;
                    }
                    ChartAll += "['" + m.TIMESTAMP + "'," + m.COUNT + "],";

                }
            }
            catch (Exception e)
            {

            }
            
            ChartAll += "]";
            ChartAll += " },";
            CHART_LP11 c10 = new CHART_LP11()
            {
                FromDate = "",
                ID = ContainerName,
                Title = NameChart,
                TypeX = "time",
                TypeY = "Vlaue",
                ShowLegend = "true",
                Width = "{yyyy}:{MM}:{dd}",
                ShowToolBox = ChartAll,
                MaxAxisData = Convert.ToString(MaxValueBubble),
                MinAxisData = "0",
                SeriesData = "",
                divcolsm = "6",
                divHeight = "35vh"


            };
            lst1.Add(c10);

            
        }

        public void ModelDatafuction( String LgUserName, String LgPassword, String ButtonName)
        {

            ModelBox M10 = new ModelBox()
            {
                ModelName = "Login Information",
                LgUserName = LgUserName,
                LgPassword = LgPassword,
                ButtonName = ButtonName


            };
            ModelData.Add(M10);

        }
        public int  IsValidate(String LgUserName, String LgPassword)
        {
            int DataIsValidate = 0;
            string IsValidate = $@"select sl_no from [FP_PROCESS_DATA].[dbo].[USER_DETAILS] where USERNAME='{LgUserName}' and PASSWORD='{LgPassword}'";
            int resultIsValidate = dbWrmDevice_Counter.Database.SqlQuery<int>(IsValidate).FirstOrDefault();

            if (resultIsValidate>=1)
            {
                DataIsValidate = resultIsValidate;
            }
            else
            {
                DataIsValidate = 2;
            }
          
            
            return DataIsValidate;
        }
        public void InsrtValue(String WaterBox1, String WaterBox2, String WaterBox3, String WaterBox4, String CC_SHARECUT, String CD_SHARECUT, String LiftingDown, String PeelBar, String TroughSwitch, String ChangeDAtetime)
        {
            if (TroughSwitch == "TroughSwitch")
            {
                string IsValidate = $@"INSERT INTO[WRM_blt_data].[dbo].[WRM_TROUGHSWITCH] VALUES('DUMMY','DUMMY','{ChangeDAtetime}','0','{ChangeDAtetime}')";
                DataInsert(IsValidate);

            }
            else if (WaterBox1 == "WaterBox1")
            {
                string IsValidate = $@"INSERT INTO[WRM_blt_data].[dbo].[WRM_WATERBOX_COUNT] VALUES('Dummy','Dummy','{ChangeDAtetime}','Dummy','0','0','0','{ChangeDAtetime}')";
                DataInsert(IsValidate);
            }
            else if (WaterBox2 == "WaterBox2")
            {
                string IsValidate = $@"INSERT INTO[WRM_blt_data].[dbo].[WRM_WATERBOX_COUNT] VALUES('Dummy','Dummy','{ChangeDAtetime}','0','Dummy','0','0','{ChangeDAtetime}')";
                DataInsert(IsValidate);
            }
            else if (WaterBox3 == "WaterBox3")
            {
                string IsValidate = $@"INSERT INTO[WRM_blt_data].[dbo].[WRM_WATERBOX_COUNT] VALUES('Dummy','Dummy','{ChangeDAtetime}','Dummy','0','Dummy','0','{ChangeDAtetime}')";
                DataInsert(IsValidate);
            }
            else if (WaterBox4 == "WaterBox4")
            {
                string IsValidate = $@"INSERT INTO[WRM_blt_data].[dbo].[WRM_WATERBOX_COUNT] VALUES('Dummy','Dummy','{ChangeDAtetime}','0','0','0','Dummy','{ChangeDAtetime}')";
                DataInsert(IsValidate);
            }
            else if (CC_SHARECUT == "CC_SHARECUT")
            {
                string IsValidate = $@"INSERT INTO [WRM_blt_data].[dbo].[WRM_CC_SHEARCUT] VALUES ('Dummy','Dummy','{ChangeDAtetime}','Dummy','{ChangeDAtetime}')";
                DataInsert(IsValidate);
            }
            else if (CD_SHARECUT == "CD_SHARECUT")
            {
                string IsValidate = $@"INSERT INTO [WRM_blt_data].[dbo].[WRM_CD_SHEARCUT] VALUES ('Dummy','Dummy','{ChangeDAtetime}','Dummy','{ChangeDAtetime}')";
                DataInsert(IsValidate);
            }
            else if (LiftingDown == "LiftingDown")
            {
                string IsValidate = $@"INSERT INTO [WRM_blt_data].[dbo].[WRM_LIFTING_GUIDE_PEELBAR] VALUES ('Dummy','Dummy','{ChangeDAtetime}','DOWN','Dummy','{ChangeDAtetime}')";
                DataInsert(IsValidate);
            }
            else if (PeelBar == "PeelBar")
            {
                string IsValidate = $@"INSERT INTO [WRM_blt_data].[dbo].[WRM_LIFTING_GUIDE_PEELBAR] VALUES ('Dummy','Dummy','{ChangeDAtetime}','PEELBAR','Dummy','{ChangeDAtetime}')";
                DataInsert(IsValidate);
            }
            else
            {

            }


        }
        public void DataInsert(String IsvalidateData)
        {
            try
            {
                dbWrmDevice_Counter.Database.ExecuteSqlCommand(IsvalidateData);
            }
            catch (Exception e)
            {

            }
        }
        


    }
}
 

