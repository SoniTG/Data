﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;
using System.Web;

namespace PTG_TSJ_Main.BussinessLogic
{
    public class BL_Stelmore
    {

        Double Gear_ratio;
        object Plot_data, Intersections, x_intersect, y_intersect_upper, No_Rings_on_1st_Ring,y_intersect_lower, x_min_Z1, x_min_Z2, x_min_Z3, x_min_Z4, x_max_Z1, x_max_Z2, x_max_Z3, x_max_Z4;
        int I, J;
        double N, L, R, C, B; //N = mill speed, L = LH rotational speed, R = ring radius and C = conveyor speed
        int t, x, y; //t = no of rotation
        double[] x_Z1 = new double[50001], x_Z2 = new double[50001], x_Z3 = new double[50001], x_Z4 = new double[50001];
        //'Dim side         'definition of side from edge of lap
        double x_intersect_cal, y_intersect_upper_cal, y_intersect_lower_cal;  // new lines
        double B_prev, B_next;
        double Angle, angle_rad, angle_radian; //angle = angle per unit time
        double tm, time_intval;
        double lap_time;//time for one lap
        double p1, p2, p3, p4, p5, p6, p7;
        double Dia_V, Dia_H, pitch_centreline, pitch_halfway;
        double pitch_calc;
        double x_first, x_next, angle_rad_first, angle_rad_next;
        double[] x11, y11, x22, y22, y6, y33, y5, y44;
        int x1, y1, x2, y2, x3, y3, x4, y4;
        double slope1, intercept1, slope2, intercept2;
        double intersect_x, intersect_y; //'coordinates of intersection point
        double Lap_circumf; //circumference of lap
        double Width_Z1, Width_Z2, Width_Z3, Width_Z4;
        double cnt_Z1, cnt_Z2, cnt_Z3, cnt_Z4, Tot_half_width;
        double delta_x; //comveyor movement for 1 lap
        double pitch;
        string title, title1, title3, body;


        
        internal MultipleData GetDataForStelmore(String txtMillSpeed, String txtLayingHead, String txtStelmoreCon_Speed, String txtWidth_OfDead, String txtWidthOfHigh, String txtWidthOfMedium, String txtWidthOfCentralLow)
        {

            //Session["Message"] = "Hello MVC!";

          
            //session counting
            if (HttpContext.Current.Session["count"] == null)
            {
                HttpContext.Current.Session["count"] = 0;
            }
            if ((int)HttpContext.Current.Session["count"] > 4)
            {
                HttpContext.Current.Session["count"] = 1;
            }
            int Sessioncount = 0;
             Sessioncount = (int)HttpContext.Current.Session["count"] + 1;
            HttpContext.Current.Session["count"] = Sessioncount;
            
            ///////////////////////////////
            HttpContext.Current.Session["name"] = "OutPut";

            ///////Create for session object////////
            List<object> formSessiondata = new List<object>();
            List<object> ChartSessionDAta = new List<object>();
            //////////////////////////////////////


            var table = new MultipleData();
            List<InputBoxData> lst = new List<InputBoxData>();
            List<FormDAta> formlst = new List<FormDAta>();
            List<CHART_LP11> Chart_lst = new List<CHART_LP11>();
            
            

            if (txtMillSpeed == null || txtLayingHead == null || txtStelmoreCon_Speed == null || txtWidth_OfDead == null || txtWidthOfHigh == null || txtWidthOfMedium == null || txtWidthOfCentralLow == null)
            {
                txtMillSpeed = "56";
                txtLayingHead = "589";
                txtStelmoreCon_Speed = "0.84";
                txtWidth_OfDead = "130";
                txtWidthOfHigh = "150";
                txtWidthOfMedium = "170";
                txtWidthOfCentralLow = "300";
                //HttpContext.Current.Session["count"] = 0;
            }
            
            InputBoxData c0 = new InputBoxData()
            {
                InputId = "TextName1",
                InputName = "TextName1",
                InputType = "text",
                InputValue = txtMillSpeed,
                InputPlaceHolder = "",
                InputLabelName= "Mill Speed[m/s]",

            };
            lst.Add(c0);
            
            InputBoxData c1 = new InputBoxData()
            {
                InputId = "TextName2",
                InputName = "TextName2",
                InputType = "text",
                InputValue = txtLayingHead,
                InputPlaceHolder = "",
                InputLabelName= "Laying Head Speed[rpm]",

            };
            lst.Add(c1);
            InputBoxData c2 = new InputBoxData()
            {
                InputId = "TextName3",
                InputName = "TextName3",
                InputType = "text",
                InputValue = txtStelmoreCon_Speed,
                InputPlaceHolder = "",
                InputLabelName = "Stelmor Conveyor Speed[m/s]",

            };
            lst.Add(c2);
            InputBoxData c3 = new InputBoxData()
            {
                InputId = "TextName4",
                InputName = "TextName4",
                InputType = "text",
                InputValue = txtWidth_OfDead,
                InputPlaceHolder = "",
                InputLabelName = "Width Of 'Dead' Zone[Zone1][mm]",

            };
            lst.Add(c3);
            InputBoxData c4 = new InputBoxData()
            {
                InputId = "TextName5",
                InputName = "TextName5",
                InputType = "text",
                InputValue = txtWidthOfHigh,
                InputPlaceHolder = "",
                InputLabelName = "Width Of High Intersection Ensity Zone[Zone2][mm]",

            };
            lst.Add(c4);
            InputBoxData c5 = new InputBoxData()
            {
                InputId = "TextName6",
                InputName = "TextName6",
                InputType = "text",
                InputValue = txtWidthOfMedium,
                InputPlaceHolder = "",
                InputLabelName = "Width Of Medium Intersection Ensity Zone[Zone3][mm]",

            };
            lst.Add(c5);
            InputBoxData c6 = new InputBoxData()
            {
                InputId = "TextName7",
                InputName = "TextName7",
                InputType = "text",
                InputValue = txtWidthOfCentralLow,
                InputPlaceHolder = "",
                InputLabelName = "Width Of Central Low Intersection Ensity] Zone[Zone4][mm]",

            };
            lst.Add(c6);
            if (Sessioncount < 5 && Sessioncount != 1)//Sessioncount<5 && Sessioncount !=1
            {

                // All Value from input text
                N = Convert.ToDouble(txtMillSpeed);        //'mill speed
                L = Convert.ToDouble(txtLayingHead) / 60;   //'rpm converted to revolutions/sec
                C = Convert.ToDouble(txtStelmoreCon_Speed);        //'Stelmor conveyor speed
                Width_Z1 = Convert.ToDouble(txtWidth_OfDead); //'width of Z1
                Width_Z2 = Convert.ToDouble(txtWidthOfHigh);  //'width of Z2
                Width_Z3 = Convert.ToDouble(txtWidthOfMedium);  //'width of Z3
                Width_Z4 = Convert.ToDouble(txtWidthOfCentralLow);  //'width of Z4
                Tot_half_width = Width_Z1 + Width_Z2 + Width_Z3 + Width_Z4;
                //hfcount.Value = CInt(hfcount.Value) + 1
                Gear_ratio = 67 / 39d;
                tm = 0;                //' Time is zero
                x = 0;
                //Read_data()
                R = N / ((2 * (22 / 7d) * (L) * Gear_ratio)); //'radius of lap in metres
                R = R * 1000;                               //'convert radius to mm
                lap_time = 1 / (L * Gear_ratio);
                delta_x = (lap_time / 12) * C * 1000;     // 'Conveyor movement for 1/12th of a lap = 30 deg rotation
                pitch_calc = lap_time * C * 1000;       //'1000 * (22 / 7) * (2 * R) * C / N
                                                        // 'pitch_calc = C * (22 / 7) * 2 * R / N
                time_intval = 10 / (360 * L * Gear_ratio); // 'Time taken to traverse 10 degrees
                No_Rings_on_1st_Ring = Math.Round(((2 * R) / pitch_calc), 0);
                B = R;
                int ArraySize = 0;
                for (var t = 1; t <= Convert.ToInt32(No_Rings_on_1st_Ring); t++)
                {
                    for (var Angle = 0; Angle <= 360; Angle += 10)
                    {
                        ArraySize += 1;
                    }
                }
                double[] arr_layview_tm = new double[ArraySize + 1];
                int index = 0;
                double[] arr_layview_x = new double[ArraySize + 1];
                double[] arr_layview_y = new double[ArraySize + 1];
                double[] arr_layview_B = new double[ArraySize + 1];


                for (t = 1; t <= Convert.ToInt32(No_Rings_on_1st_Ring); t++)
                {
                    for (var Angle = 0; Angle <= 360; Angle += 10)
                    {
                        Generate_plot(Angle, B);

                        arr_layview_tm[index] = Math.Round(tm, 6); // Time
                        arr_layview_x[index] = x;   // x coordinate
                        arr_layview_y[index] = y;   // y coordinate
                        arr_layview_B[index] = B;
                        B = B + time_intval * C * 1000;
                        tm = tm + time_intval;
                        index = index + 1;
                    }
                }
                x11 = arr_layview_x;
                y11 = arr_layview_y;
                var ymaxblt = x11.Max(); //Output 40 
                var yminblt = y11.Min();



                string[] WTF = { "arr_layview_x" };
                string chartstr = "";
                //*************************


                if (WTF.Length > 0)
                {

                    for (int j = 0; j < x11.Length; j++)
                    {
                        chartstr += "[" + x11[j] + "," + y11[j] + "],";
                    }



                }



                CHART_LP11 Chart_c0 = new CHART_LP11()
                {

                    FromDate = "",
                    ID = "Container1"+ Sessioncount,
                    Title = "Billet Temperature (Stand#3)",
                    TypeX = "time",
                    TypeY = "Vlaue",
                    ShowLegend = "true",
                    Width = "",
                    ShowToolBox = chartstr,
                    MaxAxisData = "",
                    MinAxisData = "",
                    SeriesData = ""

                };
                Chart_lst.Add(Chart_c0);

                

                // ''----new lines added
                //'------------------------ Calculate the coordinates of intersections -------------------------------------
                int ArraySize1 = 0;
                for (I = 1; I <= 50; I++)
                {
                    for (var J = 1; J <= 200; J++)
                    {
                        B_next = B_prev + pitch_calc * J;
                        if (B_next <= (B_prev + 2 * R))
                        {
                            ArraySize1 += 1;
                        }
                        else
                        {

                            break;
                        }

                    }
                }


                double[] Lap_No1;
                double[] Lap_No = new double[ArraySize1 + 1];
                double[] B1 = new double[ArraySize1 + 1];
                double[] Y_Upper = new double[ArraySize1 + 1];
                double[] Y_Lower = new double[ArraySize1 + 1];
                double[] No_of_intersects_Other_Laps = new double[ArraySize1 + 1];
                double[] Low_zone_bound = new double[ArraySize1 + 1];
                double[] x_intersect = new double[ArraySize1 + 1];
                double[] Medium_zone_bound = new double[ArraySize1 + 1];
                double[] High_zone_bound = new double[ArraySize1 + 1];
                double[] Dead_zone_bound = new double[ArraySize1 + 1];
                int indexnext = 0;
                int K = 0;
                B_prev = R;
                for (I = 1; I <= 50; I++)
                {
                    for (var J = 1; J <= 200; J++)
                    {
                        B_next = B_prev + pitch_calc * J;

                        if (B_next <= (B_prev + 2 * R))
                        {
                            x_intersect_cal = (B_next + B_prev) / (double)2;
                            y_intersect_upper_cal = Math.Sqrt((2 * R + B_next - B_prev) * (2 * R - B_next + B_prev)) / 2d;
                            y_intersect_lower_cal = -Math.Sqrt((2 * R + B_next - B_prev) * (2 * R - B_next + B_prev)) / 2d;


                            Lap_No1 = new double[K + 1];
                            Array.Resize(ref Lap_No1, K + 1);
                            Lap_No1[K] = I;


                            Lap_No[K] = I;
                            No_of_intersects_Other_Laps[K] = J;
                            B1[K] = B_prev;
                            x_intersect[K] = x_intersect_cal;
                            Y_Upper[K] = y_intersect_upper_cal;
                            Y_Lower[K] = y_intersect_lower_cal;
                            //'--------- Create the demarkations of various zones for the intersection plot --------------------
                            if (I == 1 | I == 10 | I == 20 | I == 30 | I == 40 | I == 50)
                            {
                                Low_zone_bound[K] = Width_Z4;
                                Medium_zone_bound[K] = Width_Z4 + Width_Z3;
                                High_zone_bound[K] = Width_Z4 + Width_Z3 + Width_Z2;
                                Dead_zone_bound[K] = Width_Z4 + Width_Z3 + Width_Z2 + Width_Z1;
                            }
                            //'--------- Create the demarkations of various zones for the intersection plot --------------------
                            K = K + 1;
                            Calc_intersection_density(x_intersect_cal, y_intersect_upper_cal);
                        }
                        else
                        {
                            B_prev = B_prev + pitch_calc;
                            break;
                        }

                    }
                }

                Calc_lap_circumference();

                if (x_max_Z1 == null) { }
                int txtavgIntersectionzone1, txtavgIntersectionzone2, txtavgIntersectionzone3, txtavgIntersectionzone4, txtZone1per, txtZone2per, txtZone3per, txtZone4per;
                if ((x_max_Z1 != null && x_min_Z1 != null) && ((double)x_max_Z1 > (double)x_min_Z1))
                {
                    txtavgIntersectionzone1 = (int)Math.Round(cnt_Z1 * 1000000 / (((double)x_max_Z1 - (double)x_min_Z1) * Width_Z1), 0);
                }
                else
                {
                    txtavgIntersectionzone1 = 0;
                }
                if ((x_max_Z2 != null && x_min_Z2 != null) && ((double)x_max_Z2 > (double)x_min_Z2))
                {
                    txtavgIntersectionzone2 = (int)Math.Round(cnt_Z2 * 1000000 / (((double)x_max_Z2 - (double)x_min_Z2) * Width_Z2), 0);

                }
                else
                {
                    txtavgIntersectionzone2 = 0;
                }
                if ((x_max_Z3 != null && x_min_Z3 != null) && ((double)x_max_Z3 > (double)x_min_Z3))
                {
                    txtavgIntersectionzone3 = (int)Math.Round(cnt_Z3 * 1000000 / (((double)x_max_Z3 - (double)x_min_Z3) * Width_Z3), 0);
                }
                else
                {
                    txtavgIntersectionzone3 = 0;
                }
                if ((x_max_Z4 != null && x_min_Z4 != null) && ((double)x_max_Z4 > (double)x_min_Z4))
                {
                    txtavgIntersectionzone4 = (int)Math.Round(cnt_Z4 * 1000000 / (((double)x_max_Z4 - (double)x_min_Z4) * Width_Z4), 0);
                }
                else
                {
                    txtavgIntersectionzone4 = 0;
                }
                txtZone1per = (int)Math.Round(cnt_Z1 * 100 / (cnt_Z1 + cnt_Z2 + cnt_Z3 + cnt_Z4), 0);
                txtZone2per = (int)Math.Round(cnt_Z2 * 100 / (cnt_Z1 + cnt_Z2 + cnt_Z3 + cnt_Z4), 0);
                txtZone3per = (int)Math.Round(cnt_Z3 * 100 / (cnt_Z1 + cnt_Z2 + cnt_Z3 + cnt_Z4), 0);
                txtZone4per = (int)Math.Round(cnt_Z4 * 100 / (cnt_Z1 + cnt_Z2 + cnt_Z3 + cnt_Z4), 0);


                x22 = x_intersect;
                y22 = Y_Upper;

                y33 = Y_Lower;

                y44 = High_zone_bound;
                y5 = Medium_zone_bound;

                y6 = Low_zone_bound;
                //------------------------------------------------------------------
                var high = (int)y44.Max();
                var Medium = (int)y5.Max();
                var Low = (int)y6.Max();

                double y2max = y22.Max();
                double y3max = y33.Max();

                string ymaxlimitstr = "";

                if (y2max < high & y3max < high)
                {
                    ymaxlimitstr = "max:" + (high + 5);
                }

                string chartstr1 = "";
                //*************************
                string chartstr11 = "";

                if (WTF.Length > 0)
                {

                    for (int j = 0; j < y22.Length; j++)
                    {
                        chartstr1 += "[" + x22[j] + "," + y22[j] + "],";
                    }
                    for (int j = 0; j < y22.Length; j++)
                    {
                        chartstr11 += "[" + x22[j] + "," + y33[j] + "],";
                    }



                }

                CHART_LP11 Chart_c1 = new CHART_LP11()
                {

                    FromDate = "",
                    ID = "Container12"+ Sessioncount,
                    Title = "Billet Temperature (Stand#4)",
                    TypeX = "time",
                    TypeY = "Vlaue",
                    ShowLegend = ymaxlimitstr,
                    Width = Convert.ToString(Medium),
                    ShowToolBox = chartstr1,
                    MaxAxisData = Convert.ToString(high),
                    MinAxisData = Convert.ToString(Low),
                    SeriesData = chartstr11

                };
                Chart_lst.Add(Chart_c1);


                if (Sessioncount == 2)
                {

                    HttpContext.Current.Session["ChartValues1"] = Chart_c0;
                    HttpContext.Current.Session["ChartValues11"] = Chart_c1;
                    ChartSessionDAta.Add(HttpContext.Current.Session["ChartValues1"]);
                    ChartSessionDAta.Add(HttpContext.Current.Session["ChartValues11"]);
                    HttpContext.Current.Session["ChartValues4"] = ChartSessionDAta;
                    //formlst.Add(formdata_c1);
                }
                else if (Sessioncount == 3)
                {

                    HttpContext.Current.Session["ChartValues2"] = Chart_c0;
                    HttpContext.Current.Session["ChartValues22"] = Chart_c1;
                    ChartSessionDAta.Add(HttpContext.Current.Session["ChartValues1"]);
                    ChartSessionDAta.Add(HttpContext.Current.Session["ChartValues11"]);
                    ChartSessionDAta.Add(HttpContext.Current.Session["ChartValues2"]);
                    ChartSessionDAta.Add(HttpContext.Current.Session["ChartValues22"]);
                    HttpContext.Current.Session["ChartValues4"] = ChartSessionDAta;

                    //formlst.Add(formdata_c1);
                }
                else if (Sessioncount == 4)
                {

                    HttpContext.Current.Session["ChartValues3"] = Chart_c0;
                    HttpContext.Current.Session["ChartValues33"] = Chart_c1;
                    ChartSessionDAta.Add(HttpContext.Current.Session["ChartValues1"]);
                    ChartSessionDAta.Add(HttpContext.Current.Session["ChartValues11"]);
                    ChartSessionDAta.Add(HttpContext.Current.Session["ChartValues2"]);
                    ChartSessionDAta.Add(HttpContext.Current.Session["ChartValues22"]);
                    ChartSessionDAta.Add(HttpContext.Current.Session["ChartValues3"]);
                    ChartSessionDAta.Add(HttpContext.Current.Session["ChartValues33"]);
                    HttpContext.Current.Session["ChartValues4"] = ChartSessionDAta;

                    //formlst.Add(formdata_c1);
                }

                if (true)
                {
                    FormDAta formdata_c1 = new FormDAta()
                    {

                        InputValue1 = Convert.ToString(Math.Round(Dia_V, 0)),
                        InputValue2 = Convert.ToString(Math.Round(Dia_H, 0)),
                        InputValue3 = Convert.ToString(Math.Round(pitch_centreline, 1)),
                        InputValue4 = Convert.ToString(Math.Round(R, 0)),
                        InputValue5 = Convert.ToString(Math.Round(Lap_circumf, 0)),
                        InputValue6 = Convert.ToString(txtavgIntersectionzone1),
                        InputValue7 = Convert.ToString(txtavgIntersectionzone2),
                        InputValue8 = Convert.ToString(txtavgIntersectionzone3),
                        InputValue9 = Convert.ToString(txtavgIntersectionzone4),
                        InputValue66 = Convert.ToString(txtZone1per),
                        InputValue77 = Convert.ToString(txtZone2per),
                        InputValue88 = Convert.ToString(txtZone3per),
                        InputValue99 = Convert.ToString(txtZone4per),

                    };
                    if (Sessioncount == 2)
                    {
                        
                        HttpContext.Current.Session["InputValues1"] = formdata_c1;
                        formSessiondata.Add(HttpContext.Current.Session["InputValues1"]);
                        HttpContext.Current.Session["InputValues4"] = formSessiondata;
                        formlst.Add(formdata_c1);
                    }
                    else if (Sessioncount == 3)
                    {
                       
                        HttpContext.Current.Session["InputValues2"] = formdata_c1;
                        formSessiondata.Add(HttpContext.Current.Session["InputValues1"]);
                        formSessiondata.Add(HttpContext.Current.Session["InputValues2"]);
                        HttpContext.Current.Session["InputValues4"] = formSessiondata;

                        formlst.Add(formdata_c1);
                    }
                    else if (Sessioncount == 4)
                    {
                       
                        HttpContext.Current.Session["InputValues3"] = formdata_c1;
                        formSessiondata.Add(HttpContext.Current.Session["InputValues1"]);
                        formSessiondata.Add(HttpContext.Current.Session["InputValues2"]);
                        formSessiondata.Add(HttpContext.Current.Session["InputValues3"]);
                        HttpContext.Current.Session["InputValues4"] = formSessiondata;
                       
                        formlst.Add(formdata_c1);
                    }
                   
                   
                }

                table.ChartData = Chart_lst;
                table.FormData = formlst;
            }

            table.InputBoxData = lst;
            return table;
        }
        public int Generate_plot( int Angle, double B)
        {
            angle_radian = Angle * 2 * (22 / 7d) / 360;
            x = Convert.ToInt32(B + R * Math.Cos(angle_radian));
            y = Convert.ToInt32(R * Math.Sin(angle_radian));
            if (t == 1)
            {
                p1 = B + R * Math.Cos(0); //'x-position at initial state
                p6 = B + R * Math.Cos(45 * (22 / 7d) / 180); //'x-position at midway - first rotation
                p2 = B + R * Math.Cos(180 * (22 / 7d) / 180); //'half rotation at 180 degrees
            };
            if (t == 2)
            {
                p5 = B + R * Math.Cos(0); //'x-position at initial state
                p7 = B + R * Math.Cos(45 * (22 / 7d) / 180); //'x-position at midway - second rotation
            }
            p3 = R * Math.Sin(90 * (22 / 7d) / 180);      //'rotation at 90 degrees
            p4 = R * Math.Sin(270 * (22 / 7d) / 180); ;    // '270 degree rotation
            Dia_V = p3 - p4;
            Dia_H = p5 - p2;
            pitch_centreline = p5 - p1;
            pitch_halfway = p7 - p6;
            return 0;
        }
        public int Calc_lap_circumference()
        {
            Lap_circumf = 0;
            //' Assuming R*Sin(0.5 degree) to be one unit arc length multiplied 360 x 2 time for the entire circle
            //'Lap_circumf = R * 360 * 2 * Sin(0.5 * (22 / 7) / 180)
            Lap_circumf = lap_time * N * 1000;
            return 0;
        }
        public int Calc_intersection_density(double x_intersect, double y_intersect_upper)
        {

          
            if (y_intersect_upper <= Tot_half_width && y_intersect_upper > Tot_half_width - Width_Z1)
            {
                cnt_Z1 = cnt_Z1 + 1;
                if (cnt_Z1 > 1)
                {
                    x_Z1[(int)cnt_Z1] = x_intersect;
                    if (cnt_Z1 == 2)
                    {
                        x_min_Z1 = x_intersect;
                    }
                    else
                    {
                        if (x_intersect < (double)x_min_Z1)
                        {
                            x_min_Z1 = x_intersect;
                        }
                        if (x_intersect > (double)x_min_Z1)
                        {
                            x_max_Z1 = x_intersect;
                        }

                    }


                }
            }
            else if (y_intersect_upper <= Tot_half_width - Width_Z1 && y_intersect_upper > Tot_half_width - Width_Z1 - Width_Z2)
            {
                cnt_Z2 = cnt_Z2 + 1;
                if (cnt_Z2 > 1)
                {
                    x_Z2[(int)cnt_Z2] = x_intersect;
                    if (cnt_Z2 == 2)
                    {
                        x_min_Z2 = x_intersect;
                    }
                    else
                    {
                        if (x_intersect < (double)x_min_Z2)
                        {
                            x_min_Z2 = x_intersect;
                        }
                        if (x_intersect > (double)x_min_Z2)
                        {
                            x_max_Z2 = x_intersect;
                        }

                    }
                    // x_min_Z2 = Application.WorksheetFunction.Min(x_Z2)
                    // x_max_Z2 = Application.WorksheetFunction.Max(x_Z2)
                }
            }
            else if (y_intersect_upper <= Tot_half_width - Width_Z1 - Width_Z2 && y_intersect_upper > Tot_half_width - Width_Z1 - Width_Z2 - Width_Z3)
            {
                cnt_Z3 = cnt_Z3 + 1;
                if (cnt_Z3 > 1)
                {
                    x_Z3[(int)cnt_Z3] = x_intersect;
                    if (cnt_Z3 > 1)
                    {
                        x_Z2[(int)cnt_Z3] = x_intersect;
                        if (cnt_Z3 == 2)
                        {
                            x_min_Z3 = x_intersect;
                        }
                        else
                        {
                            if (x_intersect < (double)x_min_Z3)
                            {
                                x_min_Z3 = x_intersect;
                            }
                            if (x_intersect > (double)x_min_Z3)
                            {
                                x_max_Z3 = x_intersect;
                            }

                        }

                    }
                    // x_min_Z3 = Application.WorksheetFunction.Min(x_Z3)
                    // x_max_Z3 = Application.WorksheetFunction.Max(x_Z3)
                }
            }
            else if (y_intersect_upper <= Tot_half_width - Width_Z1 - Width_Z2 - Width_Z3 && y_intersect_upper > Tot_half_width - Width_Z1 - Width_Z2 - Width_Z3 - Width_Z4)
            {
                cnt_Z4 = cnt_Z4 + 1;
                if (cnt_Z4 > 1)
                {
                    x_Z4[(int)cnt_Z4] = x_intersect;
                    if (cnt_Z4 > 1)
                    {
                        x_Z4[(int)cnt_Z4] = x_intersect;
                        if (cnt_Z4 == 2)
                        {
                            x_min_Z4 = x_intersect;
                        }
                        else
                        {
                            if (x_intersect < (double)x_min_Z4)
                            {
                                x_min_Z4 = x_intersect;
                            }
                            if (x_intersect > (double)x_min_Z4)
                            {
                                x_max_Z4 = x_intersect;
                            }

                        }

                    }
                }
            }

            
            return 0;
        }
        public void Calc_pitch_at_diff_distances(object y_fix)
        {
            //Session["FirstName"] = "fdsgdfg";
            if (t == 1)
            {
                angle_rad_first = Math.Asin((double)y_fix / (1000 * R));
                x_first = B + 1000 * R * Math.Cos(angle_rad_first);
            }
            else if (t == 2)
            {
                angle_rad_next = Math.Asin((double)y_fix / (1000 * R));
                x_next = B + 1000 * R * Math.Cos(angle_rad_next);
            }
            pitch = x_next - x_first;
        }

    }
}