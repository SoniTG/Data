﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;

namespace PTG_TSJ_Main.BussinessLogic
{
    public class BL_WRMDash
    {


       


        LP_PROCESS_DATA_v1Entities dbWrmDashbord = new LP_PROCESS_DATA_v1Entities();
        //ModelWRM db = new ModelWRM();
        WRMDBEntities dbWrmLptg = new WRMDBEntities();
        WRMDBEntities1 dbWrmLptg1 = new WRMDBEntities1();
        List<SelectOption> SltOption = new List<SelectOption>();
        static void Main()
        {
            int result1 = Multiply(5, 3);
            Console.WriteLine("The Value is " + result1);
        }

        static int Multiply(int num1, int num2)
        {
            return num1 + num2;
        }
        internal MultipleData GetDataForDashboard(String fromName1, String toName1, String fromName2, String toName2, String fromName3, String toName3, String SelectValue)
        {

            if (SelectValue==null) {
                SelectValue = "ALL";
            }
            string ToDate1 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            string FromDate1 = DateTime.Now.AddDays(-400).ToString("yyyy-MM-dd HH:mm:ss");
            //Declare DateTime Global And change String To DateTime;
            DateTime frmDate = new DateTime(2023, 06, 14, 11, 21, 59);

            DateTime toDate = new DateTime(2023, 06, 14, 11, 21, 59); ;
            if (fromName1 == null && toName1 == null)
            {
                fromName1 = DateTime.Now.AddDays(-400).ToString("yyyy-MM-dd HH:mm:ss");
                //to = DateTime.Now.AddHours(-8).ToString("yyyy-MM-dd HH:mm:ss");
                toName1 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                frmDate = DateTime.Parse(fromName1);
                toDate = DateTime.Parse(toName1);
                DateTime ch = toDate;
            }
            else
            {
                ToDate1 = toName1;
                FromDate1 = fromName1;
                frmDate = DateTime.Parse(fromName1);

                toDate = DateTime.Parse(toName1);


            }


            var table = new MultipleData();
            //table.MainMenu = db.MainMenus.Include(c => c.SubMenus).ToList();
            //var menudata= db.MainMenus.Include(c => c.SubMenus).ToList();
            //table.WRM_Mill_Parameter1 = dbWrmDashbord.WRM_Mill_Parameter.Where(d => d.Billet_Temp_Timestamp <= frmDate && d.Billet_Temp_Timestamp >= toDate && d.Blt_temp_avg > 850 && d.LHT_avg > 520).OrderBy(c => c.Billet_Temp_Timestamp).ToList();
            //table.WRM_Mill_Parameter2 = dbWrmDashbord.WRM_Mill_Parameter.Where(d => d.Billet_Temp_Timestamp <= frmDate && d.Billet_Temp_Timestamp >= toDate).OrderBy(c => c.Billet_Temp_Timestamp).ToList();
            table.WRM_Mill_Parameter3 = dbWrmDashbord.WRM_Mill_Parameter.Where(d => d.Billet_Temp_Timestamp == dbWrmDashbord.WRM_Mill_Parameter.Max(y => y.Billet_Temp_Timestamp)).ToList();
            //table.WRM_PROCESS_SPEC1 = dbWrmDashbord.WRM_PROCESS_SPEC.ToList();

            //return View(table);


            var dtMAin = (from x in dbWrmDashbord.WRM_Mill_Parameter.Where(d => d.Billet_Temp_Timestamp <= toDate && d.Billet_Temp_Timestamp >= frmDate && d.Blt_temp_avg > 850 && d.LHT_avg > 520).OrderBy(c => c.Billet_Temp_Timestamp)
                          select new
                          {
                              x.Billet_Temp_Timestamp,
                              x.Blt_temp_avg,
                              x.LHT_avg,
                              WBox_Flow = x.WBox_Flow ?? 0,
                              speed = x.Spd_NTM ?? 0,
                              QltCD = x.QltyCD == "" ? "Other" : x.QltyCD,
                              Cast_no = x.Cast_no == "" ? "Other" : x.Cast_no,
                              x.LHTnew_avg
                          }).ToList();
            var WRM_Mill_Parameter_Data = dbWrmDashbord.WRM_Mill_Parameter.Where(d => d.Billet_Temp_Timestamp <= toDate && d.Billet_Temp_Timestamp >= frmDate).OrderBy(c => c.Billet_Temp_Timestamp).ToList();
            var WRM_PROCESS_SPEC_Data = dbWrmDashbord.WRM_PROCESS_SPEC.ToList();
            var dtBilletCntrLim = (from x in WRM_PROCESS_SPEC_Data
                                   from y in WRM_Mill_Parameter_Data
                                   .Where(y => y.Grade == x.Qlty_Code && Convert.ToDecimal(y.Section) == x.Section && x.fortype == "BltTemp")
                                   select new { USL = Convert.ToInt32(x.USL), LSL = Convert.ToInt32(x.LSL), x.UCL, x.LCL }).ToList();

            var dtFRTCntrLim = (from x in WRM_PROCESS_SPEC_Data
                                from y in WRM_Mill_Parameter_Data
                                    .Where(y => y.Grade == x.Qlty_Code && Convert.ToDecimal(y.Section) == x.Section && x.fortype == "LHT")
                                select new { USL = Convert.ToInt32(x.USL), LSL = Convert.ToInt32(x.LSL), x.UCL, x.LCL }).ToList();

            var CastNo = dbWrmDashbord.WRM_Mill_Parameter.Where(d => d.Billet_Temp_Timestamp == dbWrmDashbord.WRM_Mill_Parameter.Max(y => y.Billet_Temp_Timestamp)).Select(d => d.Cast_no);

            /////Chart Impleament////////////////////////////////////


            var dtQLt = dtMAin.Select(x => x.QltCD).Distinct().ToArray();
            //LHT_avg
            double lsl = dtFRTCntrLim[0].LSL;
            double usl = dtFRTCntrLim[0].USL;
            double ymin = Math.Min((double)dtMAin.Select(x => x.LHT_avg).Min(), lsl) - 10;
            double ymax = Math.Max((double)dtMAin.Select(x => x.LHT_avg).Max(), usl) + 10;

            string chartstr = "";
            //*************************
            for (int i = 0; i < dtQLt.Length; i++)
            {
                var qltycode = dtQLt[i];
                var data = dtMAin.Where(x => x.QltCD == qltycode).ToList();
                if (data.Count > 0)
                {
                    chartstr += "{name:'" + qltycode + "',type:'line',data:[";
                    for (int j = 0; j < data.Count; j++)
                    {
                        chartstr += "['" + ((DateTime)data[j].Billet_Temp_Timestamp).ToString("yyyy-MM-dd HH:mm:ss") + "'," + data[j].LHT_avg + "],";
                    }
                    chartstr += "]";
                    if (i == 0)
                    {
                        //draw marklines
                        chartstr += ",markLine: {lineStyle: {color: '#ff0000'},data: [{name:'USL',yAxis:" + usl + "},{name:'LSL',yAxis:" + lsl + "}]}";
                    }
                    chartstr += " },";
                }

            }
            List<CHART_LP11> lst = new List<CHART_LP11>();

            CHART_LP11 c0 = new CHART_LP11()
            {

                FromDate = FromDate1,
                ToDate = ToDate1,
                FromDateName = "fromName1",
                ToDateName = "toName1",
                ID = "",
                todateId = "todateId1",
                FromdateId = "fromdateId2",
                Section="",
                Heat="Heat"

            };
            lst.Add(c0);

            CHART_LP11 c1 = new CHART_LP11()
            {
                FromDate = "",
                ID = "Container1",
                Title = "Laying Head Temperature(C)",
                TypeX = "time",
                TypeY = "Vlaue",
                ShowLegend = "true",
                Width = "{HH}:{mm}",
                ShowToolBox = chartstr,
                MaxAxisData = Convert.ToString(ymax),
                MinAxisData = Convert.ToString(ymin),
                SeriesData = "",
                divcolsm = "6",
                divHeight = "35vh"

            };
            lst.Add(c1);

            //*************************
            //BltTemp_Avg

            //**********************
            double lslblt = dtBilletCntrLim[0].LSL;
            double uslblt = dtBilletCntrLim[0].USL;
            double yminblt = Math.Min((double)dtMAin.Select(x => x.Blt_temp_avg).Min(), lslblt) - 10;
            double ymaxblt = Math.Max((double)dtMAin.Select(x => x.Blt_temp_avg).Max(), uslblt) + 10;
            /////////////////////////////BLT/////////////
            string chartstrblt = "";
            //*************************
            for (int i = 0; i < dtQLt.Length; i++)
            {
                var qltycode = dtQLt[i];
                var data = dtMAin.Where(x => x.QltCD == qltycode).ToList();
                if (data.Count > 0)
                {
                    chartstrblt += "{name:'" + qltycode + "',type:'scatter',data:[";
                    for (int j = 0; j < data.Count; j++)
                    {
                        chartstrblt += "['" + ((DateTime)data[j].Billet_Temp_Timestamp).ToString("yyyy-MM-dd HH:mm:ss") + "'," + data[j].Blt_temp_avg + "],";
                    }
                    chartstrblt += "]";
                    if (i == 0)
                    {
                        //draw marklines
                        chartstrblt += ",markLine: {lineStyle: {color: '#ff0000'},data: [{name:'USL',yAxis:" + uslblt + "},{name:'LSL',yAxis:" + lslblt + "}]}";
                    }
                    chartstrblt += " },";
                }

            }
            CHART_LP11 c2 = new CHART_LP11()
            {
                FromDate = "",
                ID = "Container2",
                Title = "Billet Temperature (Stand#3)",
                TypeX = "time",
                TypeY = "Vlaue",
                ShowLegend = "true",
                Width = "{HH}:{mm}",
                ShowToolBox = chartstrblt,
                MaxAxisData = Convert.ToString(ymaxblt),
                MinAxisData = Convert.ToString(yminblt),
                SeriesData = "",
                divcolsm = "6",
                divHeight = "35vh"

            };
            lst.Add(c2);


            ////WaterBox Flow
            double wbf_min = (double)dtMAin.Select(x => x.WBox_Flow).Min() - 100;
            double wbf_max = (double)dtMAin.Select(x => x.WBox_Flow).Max() + 100;
            double ntm_min = (double)dtMAin.Select(x => x.speed).Min() - 3;
            double ntm_max = (double)dtMAin.Select(x => x.speed).Max() + 3;

            //////////////////////////WBF_SPEED///////////////

            string chartstrWBF_SPPED = "";
            //*************************

            string[] WTF = { "Total Water Box Flow", "NTM Speed" };
            for (int i = 0; i < WTF.Length; i++)
            {
                var qltycode = dtQLt[i];
                var data = dtMAin.Where(x => x.QltCD == qltycode).ToList();
                if (dtMAin.Count > 0)
                {
                    chartstrWBF_SPPED += "{name:'" + WTF[i] + "',type:'scatter',data:[";
                    if (i == 0)
                    {
                        for (int j = 0; j < dtMAin.Count; j++)
                        {
                            chartstrWBF_SPPED += "['" + ((DateTime)dtMAin[j].Billet_Temp_Timestamp).ToString("yyyy-MM-dd HH:mm:ss") + "'," + dtMAin[j].WBox_Flow + "],";
                        }
                        chartstrWBF_SPPED += "]";
                        //draw marklines
                        //chartstrWBF_SPPED += ",markLine: {lineStyle: {color: '#ff0000'},data: [{name:'WTF',yAxis:" + wbf_min + "},{name:'WTF',yAxis:" + wbf_max + "}]}";

                        chartstrWBF_SPPED += " },";
                    }
                    if (i == 1)
                    {
                        for (int j = 0; j < dtMAin.Count; j++)
                        {
                            chartstrWBF_SPPED += "['" + ((DateTime)dtMAin[j].Billet_Temp_Timestamp).ToString("yyyy-MM-dd HH:mm:ss") + "'," + dtMAin[j].speed + "],";
                        }
                        chartstrWBF_SPPED += "]";
                        //draw marklines
                        //chartstrWBF_SPPED += ",markLine: {lineStyle: {color: '#ff00ff'},data: [{name:'SPD',yAxis:" + ntm_min + "},{name:'SPD',yAxis:" + ntm_max + "}]}";

                        chartstrWBF_SPPED += " },";
                    }
                }

            }
            CHART_LP11 c3 = new CHART_LP11()
            {
                FromDate = "",
                ID = "Container3",
                Title = "Total WaterBox Flow And NTM Speed",
                TypeX = "time",
                TypeY = "Vlaue",
                Width = "{HH}:{mm}",
                ShowLegend = "true",
                ShowToolBox = chartstrWBF_SPPED,
                MaxAxisData = Convert.ToString(wbf_max),
                MinAxisData = Convert.ToString(ntm_min),
                SeriesData = "",
                divcolsm = "6",
                divHeight = "35vh"
            };
            lst.Add(c3);


            //////////////////Billet temp Versus Laying Head Temp////////////////////
            var Cast_no = dtMAin.Select(x => x.Cast_no).Distinct().ToArray();
            double blt_min = (double)dtMAin.Select(x => x.Blt_temp_avg).Min();
            double blt_max = (double)dtMAin.Select(x => x.Blt_temp_avg).Max() + 10;
            double LHT_avg_min = (double)dtMAin.Select(x => x.LHT_avg).Min() - 70;
            double LHT_avg_max = (double)dtMAin.Select(x => x.LHT_avg).Max() + 20;
            ////*****************************************

            string chartstrbltLHT = "";
            //*************************
            for (int i = 0; i < Cast_no.Length; i++)
            {
                var Cast_nocode = Cast_no[i];
                var data = dtMAin.Where(x => x.Cast_no == Cast_nocode).ToList();
                if (data.Count > 0)
                {
                    chartstrbltLHT += "{name:'" + Cast_nocode + "',type:'scatter',data:[";
                    for (int j = 0; j < data.Count; j++)
                    {
                        chartstrbltLHT += "[" + data[j].Blt_temp_avg + "," + data[j].LHT_avg + "],";
                    }
                    chartstrbltLHT += "]";

                    chartstrbltLHT += " },";
                }

            }
            CHART_LP11 c4 = new CHART_LP11()
            {
                FromDate = "",
                ID = "Container4",
                Title = "Billet temp Versus Laying Head Temp",
                TypeX = "time",
                TypeY = "Vlaue",
                ShowLegend = "true",
                Width = "{HH}:{mm}",
                ShowToolBox = chartstrbltLHT,
                MaxAxisData = Convert.ToString(LHT_avg_max),
                MinAxisData = Convert.ToString(LHT_avg_min),
                SeriesData = "",
                divcolsm = "6",
                divHeight = "35vh"
            };

            lst.Add(c4);

            table.ChartData = lst;

            string ToDate2 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            string FromDate2 = DateTime.Now.AddDays(-30).ToString("yyyy-MM-dd HH:mm:ss");
            DateTime startDate = new DateTime(2023, 02, 04, 0, 0, 0);
            DateTime endDAte = new DateTime(2023, 07, 04, 0, 0, 0);
            string StartDate1 = "";
            string EndDate1 = "";
            if (fromName2 == null && toName2 == null)
            {
                StartDate1 = DateTime.Now.AddDays(-30).ToString("yyyy-MM-dd HH:mm:ss");
                //to = DateTime.Now.AddHours(-8).ToString("yyyy-MM-dd HH:mm:ss");
                EndDate1 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                startDate = DateTime.Parse(StartDate1);
                endDAte = DateTime.Parse(EndDate1);

            }
            else
            {

                startDate = DateTime.Parse(fromName2);

                endDAte = DateTime.Parse(toName2);
                FromDate2 = fromName2;
                ToDate2 = toName2;
            }
            ////For Section Dropdown Items///////
            var SectionDataList = dbWrmLptg.T_WRM_FG_STOCK
                .Where(e => e.WFS_ROLLING_DATE >= startDate && e.WFS_ROLLING_DATE <= endDAte)
                .Select(e => e.WFS_SEC)
                .Distinct().ToArray();
            string SectionDataString = "";
             
            for (var i = 0; i < SectionDataList.Length; i++)
            {
                SectionDataString += SectionDataList[i]+",";
                
            }


            if (SectionDataString.Length > 0)
            {
                SelectOption cs1 = new SelectOption()
                {
                    SectionData = SectionDataString,
                    ForOptCondition = "",
                    ForSelected = "Selected",
                };
                SltOption.Add(cs1);
            }
            else
            {
                SelectOption cs1 = new SelectOption()
                {
                    SectionData = "",
                    ForOptCondition = "",
                };
                SltOption.Add(cs1);
            }



            CHART_LP11 c51 = new CHART_LP11()
            {
                FromDate = FromDate2,
                ToDate = ToDate2,
                FromDateName = "fromName2",
                ToDateName = "toName2",
                ID = "",
                todateId = "todateId3",
                FromdateId = "fromdateId4",
                Section = "Section",
                SectionValue= SelectValue,
                SectionData= SectionDataString,
                Heat = "",
                divcolsm = "6",
                divHeight = "35vh"
            };


            lst.Add(c51);
            /////////////////////////LPTG_CHART//////////////////////
            
            var WRmMonthlyRejection = (
                                   from x in dbWrmLptg.T_WRM_FG_STOCK
                                   join y in dbWrmLptg.T_WRM_QUALITY_MAST on x.WFS_QCODE equals y.WQM_QCODE
                                   where x.WFS_ROLLING_DATE >= startDate && x.WFS_ROLLING_DATE <= endDAte && "REJECT" == x.WFS_OFFLINEINSP_DECI
                                   select new
                                   {
                                       x.WFS_COIL_ID,
                                       x.WFS_WEIGHT,
                                       y.WQM_CATEGORY,
                                       x.WFS_ROLLING_DATE,
                                       x.WFS_OFFLINEINSP_REASON
                                   }
                                ).OrderBy(item => item.WFS_OFFLINEINSP_REASON).ToList();
            if (SelectValue == null || SelectValue == "ALL" || SelectValue == "" || SelectValue == "0"|| SelectValue == "7-8" || SelectValue == "10-12") {
                
                WRmMonthlyRejection = (
                                    from x in dbWrmLptg.T_WRM_FG_STOCK
                                    join y in dbWrmLptg.T_WRM_QUALITY_MAST on x.WFS_QCODE equals y.WQM_QCODE
                                    where x.WFS_ROLLING_DATE >= startDate && x.WFS_ROLLING_DATE <= endDAte && "REJECT" == x.WFS_OFFLINEINSP_DECI 
                                    select new
                                    {
                                        x.WFS_COIL_ID,
                                        x.WFS_WEIGHT,
                                        y.WQM_CATEGORY,
                                        x.WFS_ROLLING_DATE,
                                        x.WFS_OFFLINEINSP_REASON
                                    }
                                 ).OrderBy(item => item.WFS_OFFLINEINSP_REASON).ToList();
            } else {
                double SectionFloatValue = Convert.ToDouble(SelectValue);
                WRmMonthlyRejection = (
                                   from x in dbWrmLptg.T_WRM_FG_STOCK
                                   join y in dbWrmLptg.T_WRM_QUALITY_MAST on x.WFS_QCODE equals y.WQM_QCODE
                                   where x.WFS_ROLLING_DATE >= startDate && x.WFS_ROLLING_DATE <= endDAte && "REJECT" == x.WFS_OFFLINEINSP_DECI && x.WFS_SEC == SectionFloatValue
                                   select new
                                   {
                                       x.WFS_COIL_ID,
                                       x.WFS_WEIGHT,
                                       y.WQM_CATEGORY,
                                       x.WFS_ROLLING_DATE,
                                       x.WFS_OFFLINEINSP_REASON
                                   }
                                ).OrderBy(item => item.WFS_OFFLINEINSP_REASON).ToList();
                
            }
            
            


            double TMT = WRmMonthlyRejection.Where(x => x.WQM_CATEGORY == "TMT").Select(x => x.WFS_WEIGHT).Sum();
            double LCWR = WRmMonthlyRejection.Where(x => x.WQM_CATEGORY == "LCWR").Select(x => x.WFS_WEIGHT).Sum();
            double BIND = WRmMonthlyRejection.Where(x => x.WQM_CATEGORY == "BIND").Select(x => x.WFS_WEIGHT).Sum();
            double ELECTRODE = WRmMonthlyRejection.Where(x => x.WQM_CATEGORY == "ELECTRODE").Select(x => x.WFS_WEIGHT).Sum();
            double HCWR = WRmMonthlyRejection.Where(x => x.WQM_CATEGORY == "HCWR").Select(x => x.WFS_WEIGHT).Sum();
            double GRANDTOTAL = TMT + LCWR + BIND + ELECTRODE + HCWR;
            //double datacheck1 = datawhere.Sum();

            string WRmMonthlyRejection_Data = "";
            //*************************
            string[] WRmMonthlyRejection_axis = { "HCWR", "LCWR", "TMT", "BIND", "ELECTRODE", "GRANDTOTAL", "Y1" };
            double[] WRmMonthlyRejection_Name = { HCWR, LCWR, TMT, BIND, ELECTRODE, GRANDTOTAL };
            WRmMonthlyRejection_Data += "{name:'" + WRmMonthlyRejection_axis[6] + "',label:{show:true,formatter: ' {b}',color:'black',fontSize:'0.4em',fontWeight:'bold',rotate: 30},type:'bar',data:[";
            for (int j = 0; j < WRmMonthlyRejection_Name.Length; j++)
            {
                WRmMonthlyRejection_Data += "['" + WRmMonthlyRejection_axis[j] + "'," + WRmMonthlyRejection_Name[j] + "],";
            }
            WRmMonthlyRejection_Data += "]";

            WRmMonthlyRejection_Data += " },";


            CHART_LP11 c5 = new CHART_LP11()
            {
                FromDate = "",
                ID = "Container5",
                Title = "WRM Monthly Rejection",
                TypeX = "category",
                TypeY = "Vlaue",
                ShowLegend = "true",
                Width = "",
                ShowToolBox = WRmMonthlyRejection_Data,
                MaxAxisData = Convert.ToString(GRANDTOTAL + 1),
                MinAxisData = "0",
                divcolsm = "6",
                divHeight = "35vh"


            };

            lst.Add(c5);

            if (fromName2 == null && toName2 == null)
            {

                fromName2 = DateTime.Now.AddDays(-30).ToString("yyyy-MM-dd HH:mm:ss");
                //to = DateTime.Now.AddHours(-8).ToString("yyyy-MM-dd HH:mm:ss");
                toName2 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                //frmDate2 = DateTime.Parse(fromName1);
                //toDate2 = DateTime.Parse(toName1);
                //DateTime ch = toDate;

            }
            else
            {


            }
            
            string query1 = "";
            string query2 = "";
            string query3 = "";
            string query4 = "";
            if (SelectValue==null || SelectValue=="ALL"|| SelectValue==""|| SelectValue == "0") {
                 query1 = $@" select *, isnull(wfs_offlineinsp_reason,WFS_ONLINEINSP_REASON) as reason,isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) as tot from 
            (SELECT WFS_OFFLINEINSP_REASON, sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE  where
            [WFS_OFFLINEINSP_TS] between '{fromName2}' and '{toName2}' and WFS_OFFLINEINSP_DECI = 'REJECT'  group by WFS_OFFLINEINSP_REASON)
            T1 full outer join(SELECT WFS_ONLINEINSP_REASON, sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE
            where[WFS_ONLINEINSP_TS] between '{fromName2}' and '{toName2}' and  WFS_ONLINEINSP_DECI = 'REJECT'  group by  WFS_ONLINEINSP_REASON) T2
             on t1.WFS_OFFLINEINSP_REASON = t2.WFS_ONLINEINSP_REASON order by isnull(t1.WFS_WEIGHT_SUM, 0) + isnull(t2.WFS_WEIGHT_SUM, 0) desc";

                 query2 = $@"select *,isnull(wfs_offlineinsp_reason,WFS_ONLINEINSP_REASON) as reason,isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) as tot 
            from (SELECT WFS_OFFLINEINSP_REASON, sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE  where 
            [WFS_OFFLINEINSP_TS] between '{fromName2}' and '{toName2}' and WFS_OFFLINEINSP_DECI='REJECT' and WQM_CATEGORY='HCWR'  group by WFS_OFFLINEINSP_REASON) T1
            full outer join(SELECT  WFS_ONLINEINSP_REASON,sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE 
            where [WFS_ONLINEINSP_TS] between '{fromName2}' and '{toName2}' and  WFS_ONLINEINSP_DECI='REJECT' and WQM_CATEGORY='HCWR'  group by  WFS_ONLINEINSP_REASON) T2
            on t1.WFS_OFFLINEINSP_REASON=t2.WFS_ONLINEINSP_REASON order by isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) desc";

                 query3 = $@"select *,isnull(wfs_offlineinsp_reason,WFS_ONLINEINSP_REASON) as reason,isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) as tot 
            from (SELECT WFS_OFFLINEINSP_REASON, sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE  where 
            [WFS_OFFLINEINSP_TS] between '{fromName2}' and '{toName2}' and WFS_OFFLINEINSP_DECI='REJECT' and WQM_CATEGORY='TMT'  group by WFS_OFFLINEINSP_REASON) T1
            full outer join(SELECT  WFS_ONLINEINSP_REASON,sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE 
            where [WFS_ONLINEINSP_TS] between '{fromName2}' and '{toName2}' and  WFS_ONLINEINSP_DECI='REJECT' and WQM_CATEGORY='TMT'  group by  WFS_ONLINEINSP_REASON) T2
            on t1.WFS_OFFLINEINSP_REASON=t2.WFS_ONLINEINSP_REASON order by isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) desc";

                 query4 = $@"select *,isnull(wfs_offlineinsp_reason,WFS_ONLINEINSP_REASON) as reason,isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) as tot 
            from (SELECT WFS_OFFLINEINSP_REASON, sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE  where 
            [WFS_OFFLINEINSP_TS] between '{fromName2}' and '{toName2}' and WFS_OFFLINEINSP_DECI='REJECT' and ([WFS_WRM_QLTY]= 'WR-3(M)' or [WFS_WRM_QLTY] = 'ER70S6')  group by WFS_OFFLINEINSP_REASON) T1 
            full outer join(SELECT  WFS_ONLINEINSP_REASON,sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE 
            where [WFS_ONLINEINSP_TS] between '{fromName2}' and '{toName2}' and  WFS_ONLINEINSP_DECI='REJECT' and ([WFS_WRM_QLTY]= 'WR-3(M)' or [WFS_WRM_QLTY] = 'ER70S6')  group by  WFS_ONLINEINSP_REASON) T2
            on t1.WFS_OFFLINEINSP_REASON=t2.WFS_ONLINEINSP_REASON order by isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) desc";
            } else if (SelectValue=="7-8") {
                query1 = $@" select *,isnull(wfs_offlineinsp_reason,WFS_ONLINEINSP_REASON) as reason,isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) as tot from (SELECT WFS_OFFLINEINSP_REASON, sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE  where [WFS_OFFLINEINSP_TS] between '{fromName2}' and '{toName2}' and ( wfs_sec = '7' OR wfs_sec = '8') and WFS_OFFLINEINSP_DECI='REJECT'  group by WFS_OFFLINEINSP_REASON) T1 full outer join(SELECT  WFS_ONLINEINSP_REASON,sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE where [WFS_ONLINEINSP_TS] between '{fromName2}' and '{toName2}' and ( wfs_sec = '7' OR wfs_sec = '8') and  WFS_ONLINEINSP_DECI='REJECT'  group by  WFS_ONLINEINSP_REASON) T2 on t1.WFS_OFFLINEINSP_REASON=t2.WFS_ONLINEINSP_REASON order by isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) desc";

                query2 = $@"select *,isnull(wfs_offlineinsp_reason,WFS_ONLINEINSP_REASON) as reason,isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) as tot from (SELECT WFS_OFFLINEINSP_REASON, sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE  where [WFS_OFFLINEINSP_TS] between '{fromName2}' and '{toName2}' and ( wfs_sec = '7' OR wfs_sec = '8') and WFS_OFFLINEINSP_DECI='REJECT' and WQM_CATEGORY='HCWR'  group by WFS_OFFLINEINSP_REASON) T1 full outer join(SELECT  WFS_ONLINEINSP_REASON,sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE where [WFS_ONLINEINSP_TS] between '{fromName2}' and '{toName2}' and ( wfs_sec = '7' OR wfs_sec = '8') and  WFS_ONLINEINSP_DECI='REJECT' and WQM_CATEGORY='HCWR'  group by  WFS_ONLINEINSP_REASON) T2 on t1.WFS_OFFLINEINSP_REASON=t2.WFS_ONLINEINSP_REASON order by isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) desc";

                query3 = $@"select *,isnull(wfs_offlineinsp_reason,WFS_ONLINEINSP_REASON) as reason,isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) as tot from (SELECT WFS_OFFLINEINSP_REASON, sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE  where [WFS_OFFLINEINSP_TS] between '{fromName2}' and '{toName2}' and ( wfs_sec = '7' OR wfs_sec = '8') and WFS_OFFLINEINSP_DECI='REJECT' and WQM_CATEGORY='TMT'  group by WFS_OFFLINEINSP_REASON) T1 full outer join(SELECT  WFS_ONLINEINSP_REASON,sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE where [WFS_ONLINEINSP_TS] between '{fromName2}' and '{toName2}' and ( wfs_sec = '7' OR wfs_sec = '8') and  WFS_ONLINEINSP_DECI='REJECT' and WQM_CATEGORY='TMT'  group by  WFS_ONLINEINSP_REASON) T2 on t1.WFS_OFFLINEINSP_REASON=t2.WFS_ONLINEINSP_REASON order by isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) desc";

                query4 = $@"select *,isnull(wfs_offlineinsp_reason,WFS_ONLINEINSP_REASON) as reason,isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) as tot from (SELECT WFS_OFFLINEINSP_REASON, sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE  where [WFS_OFFLINEINSP_TS] between '{fromName2}' and '{toName2}' and ( wfs_sec = '7' OR wfs_sec = '8') and WFS_OFFLINEINSP_DECI='REJECT' and ([WFS_WRM_QLTY]= 'WR-3(M)' or [WFS_WRM_QLTY] = 'ER70S6')  group by WFS_OFFLINEINSP_REASON) T1 full outer join(SELECT  WFS_ONLINEINSP_REASON,sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE where [WFS_ONLINEINSP_TS] between '{fromName2}' and '{toName2}' and ( wfs_sec = '7' OR wfs_sec = '8') and  WFS_ONLINEINSP_DECI='REJECT' and ([WFS_WRM_QLTY]= 'WR-3(M)' or [WFS_WRM_QLTY] = 'ER70S6')  group by  WFS_ONLINEINSP_REASON) T2 on t1.WFS_OFFLINEINSP_REASON=t2.WFS_ONLINEINSP_REASON order by isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) desc";
            } else if (SelectValue=="10-12"){
                query1 = $@" select *,isnull(wfs_offlineinsp_reason,WFS_ONLINEINSP_REASON) as reason,isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) as tot from (SELECT WFS_OFFLINEINSP_REASON, sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE  where [WFS_OFFLINEINSP_TS] between '{fromName2}' and '{toName2}' and  wfs_sec BETWEEN '10' AND '12' and WFS_OFFLINEINSP_DECI='REJECT'  group by WFS_OFFLINEINSP_REASON) T1 full outer join(SELECT  WFS_ONLINEINSP_REASON,sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE where [WFS_ONLINEINSP_TS] between '{fromName2}' and '{toName2}' and wfs_sec BETWEEN '10' AND '12' and  WFS_ONLINEINSP_DECI='REJECT'  group by  WFS_ONLINEINSP_REASON) T2 on t1.WFS_OFFLINEINSP_REASON=t2.WFS_ONLINEINSP_REASON order by isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) desc";

                query2 = $@"select *,isnull(wfs_offlineinsp_reason,WFS_ONLINEINSP_REASON) as reason,isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) as tot from (SELECT WFS_OFFLINEINSP_REASON, sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE  where [WFS_OFFLINEINSP_TS] between '{fromName2}' and '{toName2}' and wfs_sec BETWEEN '10' AND '12' and WFS_OFFLINEINSP_DECI='REJECT' and WQM_CATEGORY='HCWR'  group by WFS_OFFLINEINSP_REASON) T1 full outer join(SELECT  WFS_ONLINEINSP_REASON,sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE where [WFS_ONLINEINSP_TS] between '{fromName2}' and '{toName2}' and wfs_sec BETWEEN '10' AND '12' and  WFS_ONLINEINSP_DECI='REJECT' and WQM_CATEGORY='HCWR'  group by  WFS_ONLINEINSP_REASON) T2 on t1.WFS_OFFLINEINSP_REASON=t2.WFS_ONLINEINSP_REASON order by isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) desc";

                query3 = $@"select *,isnull(wfs_offlineinsp_reason,WFS_ONLINEINSP_REASON) as reason,isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) as tot from (SELECT WFS_OFFLINEINSP_REASON, sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE  where [WFS_OFFLINEINSP_TS] between '{fromName2}' and '{toName2}' and wfs_sec BETWEEN '10' AND '12' and WFS_OFFLINEINSP_DECI='REJECT' and WQM_CATEGORY='TMT'  group by WFS_OFFLINEINSP_REASON) T1 full outer join(SELECT  WFS_ONLINEINSP_REASON,sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE where [WFS_ONLINEINSP_TS] between '{fromName2}' and '{toName2}' and wfs_sec BETWEEN '10' AND '12' and  WFS_ONLINEINSP_DECI='REJECT' and WQM_CATEGORY='TMT'  group by  WFS_ONLINEINSP_REASON) T2 on t1.WFS_OFFLINEINSP_REASON=t2.WFS_ONLINEINSP_REASON order by isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) desc";

                query4 = $@"select *,isnull(wfs_offlineinsp_reason,WFS_ONLINEINSP_REASON) as reason,isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) as tot from (SELECT WFS_OFFLINEINSP_REASON, sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE  where [WFS_OFFLINEINSP_TS] between '{fromName2}' and '{toName2}' and wfs_sec BETWEEN '10' AND '12' and WFS_OFFLINEINSP_DECI='REJECT' and ([WFS_WRM_QLTY]= 'WR-3(M)' or [WFS_WRM_QLTY] = 'ER70S6')  group by WFS_OFFLINEINSP_REASON) T1 full outer join(SELECT  WFS_ONLINEINSP_REASON,sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE where [WFS_ONLINEINSP_TS] between '{fromName2}' and '{toName2}' and wfs_sec BETWEEN '10' AND '12' and  WFS_ONLINEINSP_DECI='REJECT' and ([WFS_WRM_QLTY]= 'WR-3(M)' or [WFS_WRM_QLTY] = 'ER70S6')  group by  WFS_ONLINEINSP_REASON) T2 on t1.WFS_OFFLINEINSP_REASON=t2.WFS_ONLINEINSP_REASON order by isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) desc;";
            }
            else{
                query1 = $@" select *,isnull(wfs_offlineinsp_reason,WFS_ONLINEINSP_REASON) as reason,isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) as tot from (SELECT WFS_OFFLINEINSP_REASON, sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE  where [WFS_OFFLINEINSP_TS] between '{fromName2}' and '{toName2}' and WFS_SEC=8 and WFS_OFFLINEINSP_DECI='REJECT'  group by WFS_OFFLINEINSP_REASON) T1 full outer join(SELECT  WFS_ONLINEINSP_REASON,sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE where [WFS_ONLINEINSP_TS] between '{fromName2}' and '{toName2}' and WFS_SEC={SelectValue} and  WFS_ONLINEINSP_DECI='REJECT'  group by  WFS_ONLINEINSP_REASON) T2 on t1.WFS_OFFLINEINSP_REASON=t2.WFS_ONLINEINSP_REASON order by isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) desc";

                query2 = $@"select *,isnull(wfs_offlineinsp_reason,WFS_ONLINEINSP_REASON) as reason,isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) as tot from (SELECT WFS_OFFLINEINSP_REASON, sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE  where [WFS_OFFLINEINSP_TS] between '{fromName2}' and '{toName2}' and WFS_SEC=8 and WFS_OFFLINEINSP_DECI='REJECT' and WQM_CATEGORY='HCWR'  group by WFS_OFFLINEINSP_REASON) T1 full outer join(SELECT  WFS_ONLINEINSP_REASON,sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE where [WFS_ONLINEINSP_TS] between '{fromName2}' and '{toName2}' and WFS_SEC={SelectValue} and  WFS_ONLINEINSP_DECI='REJECT' and WQM_CATEGORY='HCWR'  group by  WFS_ONLINEINSP_REASON) T2 on t1.WFS_OFFLINEINSP_REASON=t2.WFS_ONLINEINSP_REASON order by isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) desc";

                query3 = $@"select *,isnull(wfs_offlineinsp_reason,WFS_ONLINEINSP_REASON) as reason,isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) as tot from (SELECT WFS_OFFLINEINSP_REASON, sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE  where [WFS_OFFLINEINSP_TS] between '{fromName2}' and '{toName2}' and WFS_SEC=8 and WFS_OFFLINEINSP_DECI='REJECT' and WQM_CATEGORY='TMT'  group by WFS_OFFLINEINSP_REASON) T1 full outer join(SELECT  WFS_ONLINEINSP_REASON,sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE where [WFS_ONLINEINSP_TS] between '{fromName2}' and '{toName2}' and WFS_SEC={SelectValue} and  WFS_ONLINEINSP_DECI='REJECT' and WQM_CATEGORY='TMT'  group by  WFS_ONLINEINSP_REASON) T2 on t1.WFS_OFFLINEINSP_REASON=t2.WFS_ONLINEINSP_REASON order by isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) desc";

                query4 = $@"select *,isnull(wfs_offlineinsp_reason,WFS_ONLINEINSP_REASON) as reason,isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) as tot from (SELECT WFS_OFFLINEINSP_REASON, sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE  where [WFS_OFFLINEINSP_TS] between '{fromName2}' and '{toName2}' and WFS_SEC=8 and WFS_OFFLINEINSP_DECI='REJECT' and ([WFS_WRM_QLTY]= 'WR-3(M)' or [WFS_WRM_QLTY] = 'ER70S6')  group by WFS_OFFLINEINSP_REASON) T1 full outer join(SELECT  WFS_ONLINEINSP_REASON,sum(WFS_WEIGHT) as WFS_WEIGHT_SUM  FROM T_WRM_FG_STOCK Join T_WRM_QUALITY_MAST  ON WFS_QCODE = WQM_QCODE where [WFS_ONLINEINSP_TS] between '{fromName2}' and '{toName2}' and WFS_SEC={SelectValue} and  WFS_ONLINEINSP_DECI='REJECT' and ([WFS_WRM_QLTY]= 'WR-3(M)' or [WFS_WRM_QLTY] = 'ER70S6')  group by  WFS_ONLINEINSP_REASON) T2 on t1.WFS_OFFLINEINSP_REASON=t2.WFS_ONLINEINSP_REASON order by isnull(t1.WFS_WEIGHT_SUM,0)+isnull(t2.WFS_WEIGHT_SUM,0) desc";
            }
            



            string ChartXaxisName = "";
            string[] queryName = { query1, query2, query3, query4 };

            for (int i = 0; i < queryName.Length; i++)
            {
                var result = dbWrmLptg.Database.SqlQuery<MyModel>(queryName[i]);
                double TotalSum = 0.0;
                double sumData = 0.0;
                double minValue = 0;
                double maxValue = 0;
                string xAxisDataName = "";
                try
                {

                    foreach (MyModel m in result)
                    {

                        TotalSum += m.tot;

                    }
                }
                catch (Exception e)
                {

                }
                string ChartRejection1 = "";

                string[] NameXsis = { "Y1", "Y2" };

                //*************************
                for (int j = 0; j < NameXsis.Length; j++)
                {
                    if (j == 0)
                    {
                        ChartRejection1 += "{name:'" + NameXsis[j] + "',type:'line',data:[";
                        foreach (MyModel m in result)
                        {

                            sumData += m.tot * 100 / TotalSum;
                            if (maxValue < sumData) { maxValue = sumData; }
                            ChartRejection1 += "['" + m.reason + "'," + sumData + "],";
                            //ChartRejection1 += "[" + sumData + "," + m.tot + "],";
                        }
                        ChartRejection1 += "]";

                        ChartRejection1 += " },";
                    }

                    if (j == 1)
                    {
                        ChartXaxisName = "";
                        foreach (MyModel m in result)
                        {
                            ChartXaxisName += "'" + m.reason + "',";
                        }


                        ChartRejection1 += "{name:'" + NameXsis[j] + "',label:{show:true,formatter: ' {b}',rotate: 90},type:'bar', yAxisIndex: 1,data:[";
                        foreach (MyModel m in result)
                        {

                            ChartRejection1 += "['" + m.reason + "'," + m.tot + "],";

                            //ChartRejection1 += "[" + m.tot + "],";
                        }

                        ChartRejection1 += "]";

                        ChartRejection1 += " }";
                    }




                }
                if (i == 0)
                {
                    CHART_LP11 c6 = new CHART_LP11()
                    {
                        FromDate = "",
                        ID = "Container6",
                        Title = "Total Rejection",
                        TypeX = "category",
                        TypeY = "Vlaue",
                        ShowLegend = "true",
                        Width = "",
                        ShowToolBox = ChartRejection1,
                        MaxAxisData = Convert.ToString(maxValue),
                        MinAxisData = "0",
                        SeriesData = "axisLabel: { interval: 0, rotate: 90 }",
                        divcolsm = "6",
                        divHeight = "35vh"

                    };

                    lst.Add(c6);
                }
                if (i == 1)
                {
                    CHART_LP11 c7 = new CHART_LP11()
                    {
                        FromDate = "",
                        ID = "Container7",
                        Title = "High Carbon",
                        TypeX = "category",
                        TypeY = "Vlaue",
                        ShowLegend = "true",
                        Width = "",
                        ShowToolBox = ChartRejection1,
                        MaxAxisData = Convert.ToString(maxValue),
                        MinAxisData = "0",
                        SeriesData = ChartXaxisName,
                        divcolsm = "6",
                        divHeight = "35vh"

                    };

                    lst.Add(c7);
                }
                if (i == 2)
                {
                    CHART_LP11 c8 = new CHART_LP11()
                    {
                        FromDate = "",
                        ID = "Container8",
                        Title = "TMT",
                        TypeX = "category",
                        TypeY = "Vlaue",
                        ShowLegend = "true",
                        Width = "",
                        ShowToolBox = ChartRejection1,
                        MaxAxisData = Convert.ToString(maxValue),
                        MinAxisData = "0",
                        SeriesData = ChartXaxisName,
                        divcolsm = "6",
                        divHeight = "35vh"

                    };

                    lst.Add(c8);
                }
                if (i == 3)
                {
                    CHART_LP11 c9 = new CHART_LP11()
                    {
                        FromDate = "",
                        ID = "Container9",
                        Title = "WR#3 / ER70S6",
                        TypeX = "category",
                        TypeY = "Vlaue",
                        ShowLegend = "true",
                        Width = "",
                        ShowToolBox = ChartRejection1,
                        MaxAxisData = Convert.ToString(maxValue),
                        MinAxisData = "0",
                        SeriesData = ChartXaxisName,
                        divcolsm = "6",
                        divHeight = "35vh"


                    };

                    lst.Add(c9);
                }

            }
            string ToDate3 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            string FromDate3 = DateTime.Now.AddDays(-90).ToString("yyyy-MM-dd HH:mm:ss");

            if (fromName3 == null && toName3 == null)
            {

                fromName3 = DateTime.Now.AddDays(-90).ToString("yyyy-MM-dd HH:mm:ss");
                //to = DateTime.Now.AddHours(-8).ToString("yyyy-MM-dd HH:mm:ss");
                toName3 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                //frmDate2 = DateTime.Parse(fromName1);
                //toDate2 = DateTime.Parse(toName1);
                //DateTime ch = toDate;

            }
            else
            {
                ToDate3 = toName3;
                FromDate3 = fromName3;

            }
            CHART_LP11 c101 = new CHART_LP11()
            {
                FromDate = FromDate3,
                ToDate = ToDate3,
                FromDateName = "fromName3",
                ToDateName = "toName3",
                ID = "",
                todateId = "todateId5",
                FromdateId = "fromdateId6",
                Section = "",
                Heat = "",
                divcolsm = "6",
                divHeight = "35vh"
            };


            lst.Add(c101);
            string querybubble = $@" select SUM([WCR_REM_BLTS]) AS [WCR_REM_BLTS],[WCR_CD_QLTY] FROM [WRMDB].[dbo].[T_WRM_CAST_RECEIPT] where WCR_RECVSAP_TS
                                    between '{fromName3}' and '{toName3}' GROUP BY WCR_CD_QLTY  having SUM([WCR_REM_BLTS]) >5";

            var resultBubble = dbWrmLptg1.Database.SqlQuery<MyModel>(querybubble);
            string[] NameXsisBubble = { "Y1", "Y2" };
            string ChartBubble = "";
            int MaxValueBubble = 0;
            ChartBubble += "{name:'" + NameXsisBubble[0] + "',type:'scatter',symbolSize:function(data){  return Math.sqrt(data[1]*5) },label:{show:true,formatter: ' {b}',color:'black',fontSize:'0.4rem',fontWeight:'bold',rotate: 40},itemStyle: { shadowBlur: 10,shadowColor: 'rgba(25, 100, 150, 0.5)',  shadowOffsetY: 5,color: new echarts.graphic.RadialGradient(0.7, 0.7, 0.1, [{offset: 0,  color: 'rgb(129, 227, 238)' }, {  offset: 1, color: 'rgb(25, 183, 207)' }]) },data:[";

            foreach (MyModel m in resultBubble)
            {
                if (MaxValueBubble < m.WCR_REM_BLTS)
                {
                    MaxValueBubble = m.WCR_REM_BLTS;
                }

                ChartBubble += "['" + m.WCR_CD_QLTY + "'," + m.WCR_REM_BLTS + "],";
                //ChartBubble += "'" + m.WCR_REM_BLTS + "',";


            }
            ChartBubble += "]";

            ChartBubble += " },";
            CHART_LP11 c10 = new CHART_LP11()
            {
                FromDate = "",
                ID = "Container10",
                Title = "Bubble Chart",
                TypeX = "category",
                TypeY = "Vlaue",
                ShowLegend = "true",
                Width = "",
                ShowToolBox = ChartBubble,
                MaxAxisData = Convert.ToString(MaxValueBubble),
                MinAxisData = "0",
                SeriesData = "",
                divcolsm = "6",
                divHeight = "35vh"


            };

            lst.Add(c10);
            table.SelectOption = SltOption;
            return table;
        }
    }
}