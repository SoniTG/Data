﻿using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace PTG_TSJ_Main.BussinessLogic.CGL2
{
    public class Al_Fe_Prediction_Model
    {
        MultipleData table = new MultipleData();
        EffectiveAlFeCalculation calc = new EffectiveAlFeCalculation();
        //  objEffectiveAlFeCalculation calc = new objEffectiveAlFeCalculation();
        //public alfeinput ProcessAlFe(alfeinput input)
        //{
        //    if (input.pottemp == null)
        //    {
        //        input.pottemp = 460.0;
        //    }
        //    return input;
        //}

        Double T_Bath_C, T_Bath_K, Al_tot_old, Fe_Tot_old, Al_eff, Fe_eff, Fe1, Fe2, J_Calc, Fe_solb, xTemp, Fe_tot;
        PTG_WEBSITEEntities dbPtgMenu = new PTG_WEBSITEEntities();
        internal MultipleData GetDataForAl_Fe_Prediction_Model(string btn_on_click, string btn_off_click, string tran_on_click, string tran_off_click, double? txtTotalAI, double? txtTotalFE, double? txtPotTemp,string btnStart, string txt_Tran_From_Date, string txt_Tran_To_Date, string txtFrom, string txtTo, string btnStart1)

        {

            //assigning values 


            if (txtPotTemp == null)
            {
                table.pottemp = 460.0;
                table.totalai = 0.1217;
                table.totalfe = 0.0341;
                //table.lblSamplingDateAL = DateTime.Now.ToString();
                //table.lblSamplingDateFE = DateTime.Now.ToString();

                //sbse niche wala date
                table.DateTo = DateTime.Now;
                table.DateFrom = DateTime.Now.AddMonths(-1);
                
                EffectiveAlAndFeChart(table.DateFrom.ToString("yyyy-MM-dd HH:mm:ss"), table.DateTo.ToString("yyyy-MM-dd HH:mm:ss"));
                table.btn_on = true;
                table.btn_trans_off = true;



                

                //table.txt_Tran_To_Date = DateTime.Now;
                //table.txt_Tran_From_Date = DateTime.Now.AddDays(-3);

                //txtTo.Text = Now.ToString("yyyy-MM-dd HH:mm:ss")
                /* upar wala sabse nicche page ka last*/ //txtFrom.Text = Now.AddMonths(-1).ToString("yyyy-MM-dd HH:mm:ss")
                                                         //btnStart_Click(sender, e)
                                                         /* niche wala*/  //txt_Tran_To_Date.Text = Now.ToString("yyyy-MM-dd HH:mm:ss")
                                                                          /*  upar wala date inn trans*/  //txt_Tran_From_Date.Text = Now.AddDays(-3).ToString("yyyy-MM-dd HH:mm:ss")

            }
            else
            {
                table.pottemp = txtPotTemp;
                table.totalai = txtTotalAI;
                table.totalfe = txtTotalFE;
                table.DateTo = DateTime.Now;
                table.DateFrom = DateTime.Now.AddMonths(-1);

                EffectiveAlAndFeChart(table.DateFrom.ToString("yyyy-MM-dd HH:mm:ss"), table.DateTo.ToString("yyyy-MM-dd HH:mm:ss"));


            }



                if (tran_off_click == null || tran_off_click == "toff" || btn_on_click == "bON")
                {
                    LoadValues(table.totalai, table.totalfe, table.pottemp);
                    CreateGraph();  
                    table.btn_off = false;
                    table.btn_trans_on = false;
                    table.btn_on = true;
                    table.btn_trans_off = true;

                    // CreateGraph();
                }
               if(tran_on_click == "tON")
                {
                    //ye wo date hai jo trans_on hone p niche show krega
                    table.txt_Tran_From_Date = DateTime.Now.AddDays(-3);
                    table.txt_Tran_To_Date = DateTime.Now;
                    table.btn_off = true;
                    table.btn_trans_on = true;
                    table.btn_on = false;
                    table.btn_trans_off = false;

                    LoadValues(table.totalai, table.totalfe, table.pottemp);
                    TransitionGraph(table.txt_Tran_From_Date, table.txt_Tran_To_Date);
                }
            if(btnStart == "START")
            {
                //ye wo date hai jo trans_on hone p niche show krega
                table.txt_Tran_From_Date =Convert.ToDateTime( txt_Tran_From_Date);
                table.txt_Tran_To_Date = Convert.ToDateTime(txt_Tran_To_Date);
                table.btn_off = true;
                table.btn_trans_on = true;
                table.btn_on = false;
                table.btn_trans_off = false;

                LoadValues(table.totalai, table.totalfe, table.pottemp);
                TransitionGraph(table.txt_Tran_From_Date, table.txt_Tran_To_Date);
            }
            if (btnStart1 == "START")
            {
                table.DateFrom = Convert.ToDateTime(txtFrom);
                table.DateTo =Convert.ToDateTime(txtTo);
                EffectiveAlAndFeChart(txtFrom, txtTo);
            }
            




            //table.X_Axis = "'1', '2', '3', '4', '5', '6','7'";
            //table.SeriesData = "5, 20, 40, 10, 10, 20,30";
            return table;
        }
        public void LoadValues(double? txtTotalAI, double? txtTotalFE, double? txtPotTemp)
        {


            // txtPotTemp = String.IsNullOrEmpty(txtPotTemp) ? "460" : txtPotTemp;

            //double txtPotTemp1 = 460;
            //table.pottemp = 460;

            T_Bath_C = txtPotTemp.Value;
            T_Bath_K = T_Bath_C + 273.15;




            string q1 = $@"SELECT TOP(1) CLR_TIMESTAMP,CLR_PROCESS_LINE,CLR_ID_COIL,CLR_SAMPLE_ID,CLR_PARAM_TEST,CLR_TEST_VALUE,CLR_UOM,CLR_DT_SAMPLING_DATE,CLR_SHIFT,CLR_PARAM_MIN,CLR_PARAM_MAX FROM [FP_PROCESS_DATA].[dbo].[CRM_LABTEST_RES] WHERE CLR_PARAM_TEST IN ('ZAAL','ZAZS','ZAGA') AND CLR_PROCESS_LINE = 'L' ORDER BY CLR_DT_SAMPLING_DATE DESC";
            dbPtgMenu.Database.CommandTimeout = 300;
            var dt1 = dbPtgMenu.Database.SqlQuery<dtAlData>(q1).ToArray();

            if (dt1.Count() > 0)
            {
                table.totalai = Convert.ToDouble(dt1[0].CLR_TEST_VALUE);
                //table.totalai = Convert.ToDouble(dt1[0].CLR_TEST_VALUE.ToString());
                //txtTotalAI = dtAlData.Rows[0]["CLR_TEST_VALUE"].ToString();
                var clrParamMin = dt1[0].CLR_PARAM_MIN;
                // clrParamMin = Convert.ToDecimal(dtAlData.Rows[0]["CLR_PARAM_MIN"]);



                //txtTotalAI = TotalAI;



                if (clrParamMin == 0.125m)
                {
                    table.pottemp = 470;
                }
                else if (clrParamMin == 0.165m || clrParamMin == 0.15m)
                {
                    table.pottemp = 460;
                }
                // lblSamplingDateAL.Text = " On " + Convert.ToDateTime(dtAlData.Rows[0]["CLR_DT_SAMPLING_DATE"]).ToString("dd-MM-yy HH:mm");
                table.lblSamplingDateAL = " On " + dt1[0].CLR_DT_SAMPLING_DATE.ToString("dd-MM-yy HH:mm");


            }



            string q2 = $@"SELECT TOP(1) CLR_TIMESTAMP,CLR_PROCESS_LINE,CLR_ID_COIL,CLR_SAMPLE_ID,CLR_PARAM_TEST,CLR_TEST_VALUE,CLR_UOM,CLR_DT_SAMPLING_DATE,CLR_SHIFT,CLR_PARAM_MIN,CLR_PARAM_MAX FROM [FP_PROCESS_DATA].[dbo].[CRM_LABTEST_RES] WHERE CLR_PARAM_TEST = 'ZAFE' AND CLR_PROCESS_LINE = 'L' ORDER BY CLR_DT_SAMPLING_DATE DESC";
            dbPtgMenu.Database.CommandTimeout = 300;
            var dt2 = dbPtgMenu.Database.SqlQuery<dtFeData>(q2).ToArray();

            if (dt2.Count() > 0)
            {
                //txtTotalFE.Text = dtFeData.Rows[0]["CLR_TEST_VALUE"].ToString();
                table.totalfe = Convert.ToDouble(dt2[0].CLR_TEST_VALUE.ToString());
                table.lblSamplingDateFE = " On " + dt1[0].CLR_DT_SAMPLING_DATE.ToString("dd-MM-yy HH:mm");





                //  txtTotalFE = TotalFE;


            }
            Al_tot_old = table.totalai.Value;
            Fe_Tot_old = table.totalfe.Value;

            //till here new pot temp.total fe,total ai value is generated


        }

        public void CreateGraph()
        {

            // Al Effective
            // ###########################
            // Dim objEffectiveAlFeCalculation As New EffectiveAlFeCalculation
            Al_tot_old = table.totalai.Value;
            Fe_Tot_old = table.totalfe.Value;
            //Al_tot_old = txtTotalAI.Text;
            //Fe_Tot_old = txtTotalFE.Text;
            T_Bath_C = table.pottemp.Value;
            T_Bath_K = T_Bath_C + 273.15;
            //T_Bath_C = txtPotTemp.Text;
            //T_Bath_K = txtPotTemp.Text + 273.15;



            calc.Main(T_Bath_C, T_Bath_K);
            //table.txtAITriplePoint.Text = Math.Round(calc.Al_trip, 4);
            //table.txtFETriplePoint.Text = Math.Round(calc.Fe_trip, 4);

            table.txtAITriplePoint = Math.Round(calc.Al_trip, 4);
            table.txtFETriplePoint = Math.Round(calc.Fe_trip, 4);

            // objEffectiveAlFeCalculation.mtdEffectivAlFeCal(Al_tot_old, T_Bath_K, objEffectiveAlFeCalculation.Al_trip, objEffectiveAlFeCalculation.Fe_trip)
            calc.Aleffcal(Al_tot_old, Fe_Tot_old);

            table.txtAITriplePoint = Math.Round(calc.Al_trip, 4);
            table.txtFETriplePoint = Math.Round(calc.Fe_trip, 4);
            Al_eff = Math.Round(calc.Al_liq, 4);
            if (Al_eff == 0)
            {




                table.lblError = "Effective AL = 0; \"Inappropriate values of Total AL or Total FE\"";
                // UserMsgBox("Inappropriate values for Total AL or Total FE.")
                //return;

            }
            table.txtAIEffective = Al_eff;

            Fe_eff = Math.Round(calc.Fe_liq, 4);
            table.txtFEEffective = Fe_eff;
            // ###########################


            // Dim objEffectiveAlFeCalculation As New EffectiveAlFeCalculation
            Al_tot_old = table.totalai.Value;

            double AL_St_pnt, Fe_St_pnt, AL_End_pnt, Fe_End_pnt, Al_increment;
            AL_St_pnt = 0.08;
            Fe_St_pnt = 0.0;
            AL_End_pnt = 0.3;  // ''' changed by mamta on 21 sep'18 to increase x-axis till 0.3 -old value 0.26
            Fe_End_pnt = 0.1;   // changed by mamta on 21 sep'18 to increase y-axis till 0.1 -- old valuec 0.05
            int no_iteration;

            // ye niche wla ek line jo hai usko shi krna hai uncomment krke
            no_iteration = Convert.ToInt32((AL_End_pnt - AL_St_pnt) * 10000 + 1);
           // no_iteration = Convert.ToInt32((Al_max - Al_min) * 10000 + 1);

            Al_increment = 0.0001;
            double[] arrSolCurve_Al = new double[no_iteration];
            double[] arrSolCurve_Fe = new double[no_iteration];

            for (int i = 0; i <= no_iteration - 1; i++)
            {
                Al_tot_old = Math.Round(AL_St_pnt + i * Al_increment, 4);

                //ReDim Preserve arrSolCurve_Al(no_iteration - 1)
                //ReDim Preserve arrSolCurve_Fe(no_iteration - 1)


                calc.mtdEffectivAlFeCal(Al_tot_old, T_Bath_K, calc.Al_trip, calc.Fe_trip);
                arrSolCurve_Al[i] = Al_tot_old;
                arrSolCurve_Fe[i] = Math.Round(calc.Fe_liq, 4);
            }

            equation_line();
            PlotLineChart("% Al", "% Fe", table.litLineGraph, "divContainer", "test", "Fe-Al-Zn* Ternary Phase Diagram at " + table.pottemp.Value + " ℃", "Y Label");
        }




        private decimal[,] arrSlope = new decimal[26, 2];
        public void equation_line()
        {
            // get slope
            Al_tot_old = table.totalai.Value;
            Fe_Tot_old = table.totalfe.Value;

            //Decimal Slope_line = Fe_Tot_old - Fe_eff / (double)Al_tot_old - Al_eff;

            decimal Slope_line = (decimal)((Fe_Tot_old - Fe_eff) / (double)(Al_tot_old - Al_eff));

            decimal intercept = (decimal)Fe_Tot_old - Slope_line * (decimal)Al_tot_old;

            decimal y = 0;
            decimal x = 0;
            for (int i = 0; i <= 25; i++)
            {
                y = y + (decimal)i * 0.05m;
                x = (y - intercept) / (decimal)Slope_line;

                arrSlope[i, 0] = x;
                arrSlope[i, 1] = y;
                if (x > 0.25m)
                    //if (x > (decimal)0.25m) dono me se kya hoga
                    break;
            }

        }

        //////plotline

        public void PlotLineChart(string XAxisColName, string YAxisColName, string LiteralName, string ContainerName, string PlotName, string ChartTitle, string YAxisLabelName)
        {

            try
            {
                LiteralName = "";
                string min_time, max_time;
                min_time = 0.08.ToString();
                max_time = 0.3.ToString(); // Changed from 0.26 to 0.3 as told by Mamta on 21st sep 2018

                // Dim yVal() As Decimal
                // yVal = (From row In dt Select col = CDec(row(YAxisColName))).ToArray()

                string y_min = 0.0.ToString();
                string y_max = 0.1.ToString(); // Changed from 0.06 to 0.1 as told by Mamta on 24th August 2018

                string js = "<script language='javascript' type='text/javascript'>" + "$.jqplot.config.enablePlugins = true;"; //+ "  $('#resizable').resizable({delay:20});" + " $('#resizable').bind('resize', function(event, ui) {test.replot( { resetAxes: false } ); }); ";

                // dt.DefaultView.RowFilter = ""
                // Dim dvDefault As DataView = dt.DefaultView
                // Dim bottomLineDataForLeftBox As String = "var bottomLineDataForLeftBox = [[0.125, 0.038], [0.135, 0.038]];"
                // Dim rightLineDataForLeftBox As String = "var rightLineDataForLeftBox = [[0.135, 0.038], [0.135, 0.048]];"
                // Dim topLineDataForLeftBox As String = "var topLineDataForLeftBox = [[0.135, 0.048], [0.125, 0.048]];"
                // Dim leftLineDataForLeftBox As String = "var leftLineDataForLeftBox = [[0.125, 0.048], [0.125, 0.038]];"

                string bottomLineDataForLeftBox = "var bottomLineDataForLeftBox = [[0.113, 0.03], [0.127, 0.03]];";
                string rightLineDataForLeftBox = "var rightLineDataForLeftBox = [[0.127, 0.03], [0.127, 0.04]];";
                string topLineDataForLeftBox = "var topLineDataForLeftBox = [[0.127, 0.04], [0.113, 0.04]];";
                string leftLineDataForLeftBox = "var leftLineDataForLeftBox = [[0.113, 0.04], [0.113, 0.03]];";

                string bottomLineDataForRightBox = "var bottomLineDataForRightBox = [[0.185, 0.016], [0.205, 0.016]];";
                string rightLineDataForRightBox = "var rightLineDataForRightBox = [[0.205, 0.016], [0.205, 0.020]];";
                string topLineDataForRightBox = "var topLineDataForRightBox = [[0.205, 0.020], [0.185, 0.020]];";
                string leftLineDataForRightBox = "var leftLineDataForRightBox = [[0.185, 0.020], [0.185, 0.016]];";

                bool flag = false;
                bool boolCheckData = false;
                js += "";
                for (int i = 0; i <= calc.dict.Count - 1; i++)
                {
                    boolCheckData = false;

                    js += "var line" + (i + 1).ToString() + " = [";

                    double[] arrData = calc.dict[i];

                    double left = 0;
                    for (int j = 0; j < calc.dict[i].Length; j++)
                    {
                        if (arrData[j] <= 0)
                            continue;

                        if (boolCheckData == true)
                            js += ",";

                        js += "[";

                        if (i == 0)
                        {
                            if (j < 10)
                                js += "" + calc.arrAl_Liq[j] + ", " + arrData[j] + ",'a'";
                            else
                                js += "" + calc.arrAl_Liq[j] + ", " + arrData[j] + ",'b'";
                        }
                        else if (i == 3)
                        {
                            if (left == 0)
                            {
                                left = (165 / 0.056) * calc.arrAl_Liq[j]; // To calculate the left position of the label placed in the CONODE area.
                                table.litLabelPosition = "<script type='text/javascript'>document.getElementById('divLabel3').style.top = '50px'; document.getElementById('divLabel3').style.left = '" + left + "px';</script>";
                            }
                            js += "" + calc.arrAl_Liq[j] + ", " + arrData[j] + ",'c'";
                        }
                        else
                            js += "" + calc.arrAl_Liq[j] + ", " + arrData[j] + ",'c'";

                        js += "]";
                        boolCheckData = true;
                    }

                    js += "];";
                    flag = true;
                }
                // Till here four lines are created

                boolCheckData = false;
                js += "";

                js += "var line" + (calc.dict.Count + 1).ToString() + " = [";
                for (int j = 0; j <= 25; j++)
                {
                    if (boolCheckData == true)
                        js += ",";

                    js += "[";

                    js += "" + arrSlope[j, 0] + ", " + arrSlope[j, 1];

                    js += "]";
                    boolCheckData = true;
                }
                js += "];";
                flag = true;
                js += "";
                js += "var line" + (calc.dict.Count + 2).ToString() + " = [";
                js += "[";
                js += "" + table.totalai.Value + ", " + table.totalfe.Value;
                js += "]";
                js += "];";
                js += "";
                js += "var line" + (calc.dict.Count + 3).ToString() + " = [";
                js += "[";
                js += "" + table.txtAIEffective + ", " + table.txtFEEffective;
                js += "]";
                js += "];";
                js += "";
                js += "var line" + (calc.dict.Count + 4).ToString() + " = [";
                js += "[";
                js += "" + table.totalai.Value + ", " + table.totalfe.Value;
                js += "],";
                js += "[";
                js += "" + table.totalai.Value + ", " + 0;
                js += "]";
                js += "];";
                js += "";
                js += "var line" + (calc.dict.Count + 5).ToString() + " = [";
                js += "[";
                js += "" + table.totalai.Value + ", " + table.totalfe.Value;
                js += "],";
                js += "[";
                js += "" + 0 + ", " + table.totalfe.Value;
                js += "]";
                js += "];" + "";
                js += "";

                // ----------------------------------------------------------------------------------------------------------------------------
                js += bottomLineDataForLeftBox + rightLineDataForLeftBox + topLineDataForLeftBox + leftLineDataForLeftBox;
                js += bottomLineDataForRightBox + rightLineDataForRightBox + topLineDataForRightBox + leftLineDataForRightBox;

                string boxSeries = @"{pointLabels: { show:false }, showLine:true, lineWidth:2, color: '#0B9126', markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: true,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold; font-size:12px;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}";
                // ----------------------------------------------------------------------------------------------------------------------------

                string strg = "";
                string strseries = "";

                if (flag)
                {
                    strg = "[line1";
                    strseries = @" {pointLabels:{ show:false, location:'s'}, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: true,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}";
                    for (int i = 1; i <= calc.dict.Count + 4; i++) // - 1 'dtGrades.Rows.Count - 1
                    {
                        strg = strg + ",line" + (i + 1);

                        if (i == 4 | i == 7 | i == 8)
                            strseries = strseries + @", {pointLabels: { show:false }, showLine:true, lineWidth:1, linePattern: 'dashed',  markerOptions:{ size: 5 }, highlighter: {show: false,showMarker: true,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}";
                        else if (i >= 5)
                            strseries = strseries + ", {pointLabels: { show:false }, neighborThreshold: 0, showLine:false, showMarker:true, markerOptions: { style:'X' }}";
                        else
                            strseries = strseries + @", {pointLabels: { show:false }, showLine:true, lineWidth:3, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: true,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}";
                    }
                    strseries = strseries + ", " + boxSeries + ", " + boxSeries + ", " + boxSeries + ", " + boxSeries + ", " + boxSeries + ", " + boxSeries + ", " + boxSeries + ", " + boxSeries;
                    strg += ", bottomLineDataForLeftBox, rightLineDataForLeftBox, topLineDataForLeftBox, leftLineDataForLeftBox, bottomLineDataForRightBox, rightLineDataForRightBox, topLineDataForRightBox, leftLineDataForRightBox";
                    strg += "]";
                }

                js += "var seriesName = ['";
                string str = "";
                string[] testarr = new[] { "line1", "line2", "line3", "line4", "line5", "line6", "line7", "line8", "line9" };
                for (int i = 0; i <= calc.dict.Count - 1; i++)
                    str += testarr[i] + "', '";
                str = str.Remove(str.LastIndexOf(", '"));

                str += "];";
                js += str;

                js += "opts = {" + "title: '" + ChartTitle + "'," + "seriesDefaults: { axisLabel:{textStyle:{fontWeight:'bold'}}, pointLabels: { show:false }, showMarker:false, rendererOptions: {showDataLabels: true, dataLabels:  'label', diameter: 250, dataLabelPositionFactor: 0.5,sliceMargin: 3,color:'#DCDCDC' } }," + "series:[" + strseries + "]," + "axesDefaults: {" + "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," + "tickOptions: {" + "fontSize:'9pt'" + "," + " textColor: 'black'" +"}" + "}," + "axes: {" + "xaxis: {" + "min: " + min_time + ", max: " + max_time + "," + "label: '" + XAxisColName + "'," + "tickOptions:{formatString:'', angle: -30}," + "tickInterval:0.005," + "pad:0" + "}," + "yaxis: { " + "min: " + y_min + "," + "max: " + y_max + "," + "tickOptions:{formatString:'', angle: -30}," + "tickInterval:0.005," + "label: '" + YAxisColName + "'," + "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" + "}" + "}," + "cursor: {" + "showTooltip: false," + "zoom: true" + "}," + "animate: true," + "grid: {backgroundColor:  'rgb(255,255,255)'}," + "};" + "" + PlotName + " = $.jqplot('" + ContainerName + "', " + strg + ", opts);" + "</script>";

                table.litLineGraph = js;
            }
            catch (Exception ex)
            {
            }
        }





        public void TransitionGraph(DateTime txt_Tran_From_Date, DateTime txt_Tran_To_Date)
        {
            table.lblError = "";
            // Al Effective
            // ###########################
            // Dim objEffectiveAlFeCalculation As New EffectiveAlFeCalculation
            Al_tot_old = table.totalai.Value;
            Fe_Tot_old = table.totalfe.Value;
            T_Bath_C = table.pottemp.Value;
            T_Bath_K = T_Bath_C + 273.15;

            calc.Main(T_Bath_C, T_Bath_K);
            table.txtAITriplePoint = Math.Round(calc.Al_trip, 4);
            table.txtFETriplePoint = Math.Round(calc.Fe_trip, 4);

            // objEffectiveAlFeCalculation.mtdEffectivAlFeCal(Al_tot_old, T_Bath_K, objEffectiveAlFeCalculation.Al_trip, objEffectiveAlFeCalculation.Fe_trip)
            calc.Aleffcal(Al_tot_old, Fe_Tot_old);

            table.txtAITriplePoint = Math.Round(calc.Al_trip, 4);
            table.txtFETriplePoint = Math.Round(calc.Fe_trip, 4);
            Al_eff = Math.Round(calc.Al_liq, 4);
            if (Al_eff == 0)
            {

                table.lblError = "Inappropriate values for Total AL or Total FE.";
                // UserMsgBox("Inappropriate values for Total AL or Total FE.")
                return;
            }
            table.txtAIEffective = Al_eff;

            Fe_eff = Math.Round(calc.Fe_liq, 4);
            table.txtFEEffective = Fe_eff;
            // ###########################


            // Dim objEffectiveAlFeCalculation As New EffectiveAlFeCalculation
            Al_tot_old = table.totalai.Value;

            double AL_St_pnt, Fe_St_pnt, AL_End_pnt, Fe_End_pnt, Al_increment;
            AL_St_pnt = 0.08;
            Fe_St_pnt = 0.0;
            AL_End_pnt = 0.35;  // changed by mamta on 21 sep'18 to increase x-axis till 0.35 -old value 0.26
            Fe_End_pnt = 0.1;   // changed by mamta on 21 sep'18 to increase y-axis till 0.1 -- old valuec 0.05
            int no_iteration;

            no_iteration = (int)(AL_End_pnt - AL_St_pnt) * 10000 + 1;
            Al_increment = 0.0001;
            double[] arrSolCurve_Al = new double[no_iteration];
            double[] arrSolCurve_Fe = new double[no_iteration];

            for (int i = 0; i <= no_iteration - 1; i++)
            {
                Al_tot_old = Math.Round(AL_St_pnt + i * Al_increment, 4);

                calc.mtdEffectivAlFeCal(Al_tot_old, T_Bath_K, calc.Al_trip, calc.Fe_trip);

                arrSolCurve_Al[i] = Al_tot_old;
                arrSolCurve_Fe[i] = Math.Round(calc.Fe_liq, 4);
            }


            equation_line();
            PlotLineChart1("% Al", "% Fe", table.litLineGraph, "divContainer", "test", "Fe-Al-Zn* Ternary Phase Diagram at " + table.pottemp.Value + " ℃", "Y Label", table.txt_Tran_From_Date, table.txt_Tran_To_Date);
        }
        public void PlotLineChart1(string XAxisColName, string YAxisColName, string LiteralName, string ContainerName, string PlotName, string ChartTitle, string YAxisLabelName, DateTime Trans_From_Date, DateTime Trans_To_Date)
        {
            try
            {
                LiteralName = "";



                //string q1 = $@"SELECT TOP(1) CLR_TIMESTAMP,CLR_PROCESS_LINE,CLR_ID_COIL,CLR_SAMPLE_ID,CLR_PARAM_TEST,CLR_TEST_VALUE,CLR_UOM,CLR_DT_SAMPLING_DATE,CLR_SHIFT,CLR_PARAM_MIN,CLR_PARAM_MAX FROM [FP_PROCESS_DATA].[dbo].[CRM_LABTEST_RES] WHERE CLR_PARAM_TEST IN ('ZAAL','ZAZS','ZAGA') AND CLR_PROCESS_LINE = 'L' ORDER BY CLR_DT_SAMPLING_DATE DESC";
                //dbPtgMenu.Database.CommandTimeout = 300;
                //var dt1 = dbPtgMenu.Database.SqlQuery<dtAlData>(q1).ToArray();
                string s1 = $@"SELECT CZT_EFF_AL, CZT_EFF_FE, CZT_TIMESTAMP, CZT_CAMP_AL, CZT_POT_AL, CZT_POT_FE,""CAMPAIGN"" = CASE WHEN CZT_EFF_AL > 0.15 AND CZT_EFF_AL <= 0.4 THEN 'GI' WHEN CZT_EFF_AL >= 0.1 AND CZT_EFF_AL <= 0.15 THEN 'GA' END, ""UCL"" = CASE WHEN CZT_EFF_AL > 0.15 AND CZT_EFF_AL <= 0.4 THEN 0.19 WHEN CZT_EFF_AL >= 0.1 AND CZT_EFF_AL <= 0.15 THEN 0.133 END, ""LCL"" = CASE WHEN CZT_EFF_AL > 0.15 AND CZT_EFF_AL <= 0.4 THEN 0.18 WHEN CZT_EFF_AL >= 0.1 AND CZT_EFF_AL <= 0.15 THEN 0.123 END FROM [FP_PROCESS_DATA].dbo.[CGL2_ZNBATH_TREND] WHERE CZT_TIMESTAMP BETWEEN  '{Trans_From_Date}' and '{Trans_To_Date}' ORDER BY CZT_TIMESTAMP";
                dbPtgMenu.Database.CommandTimeout = 300;
                var dtTransitionData = dbPtgMenu.Database.SqlQuery<dttransitiondata>(s1).ToArray();


                decimal[] arrEffAl_X = (from row in dtTransitionData
                                        select System.Convert.ToDecimal(row.CZT_POT_AL)).ToArray();
                decimal[] arrEffFe_Y = (from row in dtTransitionData
                                        select System.Convert.ToDecimal(row.CZT_POT_FE)).ToArray();

                string min_time, max_time;
                min_time = 0.08.ToString();
                max_time = 0.3.ToString(); // Changed from 0.26 to 0.3 as told by Mamta on 21st sep 2018

                decimal[] yVal;
                //yVal = (from row in dtTransitionData
                //        select System.Convert.ToDecimal(row.YAxisColName)).ToArray();

                string y_min = 0.0.ToString();
                string y_max = 0.1.ToString(); // Changed from 0.06 to 0.1 as told by Mamta on 24th August 2018

                string js = "<script language='javascript' type='text/javascript'>" + "$.jqplot.config.enablePlugins = true;"; //+ "  $('#resizable').resizable({delay:20});" + " $('#resizable').bind('resize', function(event, ui) {test.replot( { resetAxes: false } ); }); ";

                // Dim bottomLineDataForLeftBox As String = "var bottomLineDataForLeftBox = [[0.125, 0.038], [0.135, 0.038]];"
                // Dim rightLineDataForLeftBox As String = "var rightLineDataForLeftBox = [[0.135, 0.038], [0.135, 0.048]];"
                // Dim topLineDataForLeftBox As String = "var topLineDataForLeftBox = [[0.135, 0.048], [0.125, 0.048]];"
                // Dim leftLineDataForLeftBox As String = "var leftLineDataForLeftBox = [[0.125, 0.048], [0.125, 0.038]];"

                string bottomLineDataForLeftBox = "var bottomLineDataForLeftBox = [[0.113, 0.03], [0.127, 0.03]];";
                string rightLineDataForLeftBox = "var rightLineDataForLeftBox = [[0.127, 0.03], [0.127, 0.04]];";
                string topLineDataForLeftBox = "var topLineDataForLeftBox = [[0.127, 0.04], [0.113, 0.04]];";
                string leftLineDataForLeftBox = "var leftLineDataForLeftBox = [[0.113, 0.04], [0.113, 0.03]];";

                string bottomLineDataForRightBox = "var bottomLineDataForRightBox = [[0.185, 0.016], [0.205, 0.016]];";
                string rightLineDataForRightBox = "var rightLineDataForRightBox = [[0.205, 0.016], [0.205, 0.020]];";
                string topLineDataForRightBox = "var topLineDataForRightBox = [[0.205, 0.020], [0.185, 0.020]];";
                string leftLineDataForRightBox = "var leftLineDataForRightBox = [[0.185, 0.020], [0.185, 0.016]];";

                //dtTransitionData.DefaultView.RowFilter = "";
                //DataView dvDefault = dtTransitionData.DefaultView;
                bool flag = false;

                bool boolCheckData = false;
                js += "";
                for (int i = 0; i <= calc.dict.Count - 1; i++)
                {
                    boolCheckData = false;
                    js += "";
                    js += "var line" + (i + 1).ToString() + " = [";

                    double[] arrData = calc.dict[i];






                    double left = 0;
                    for (int j = 0; j < (calc.dict[i].Length); j++)
                    {
                        if (arrData[j] <= 0)
                            continue;

                        if (boolCheckData == true)
                            js += ",";

                        js += "[";

                        if (i == 0)
                        {
                            if (j < 10)
                                js += "" + calc.arrAl_Liq[j] + ", " + arrData[j] + ",'a'";
                            else
                                js += "" + calc.arrAl_Liq[j] + ", " + arrData[j] + ",'b'";
                        }
                        else if (i == 3)
                        {
                            if (left == 0)
                            {
                                left = (165 / 0.056) * calc.arrAl_Liq[j]; // To calculate the left position of the label placed in the CONODE area.
                                table.litLabelPosition = "<script type='text/javascript'>document.getElementById('divLabel3').style.top = '50px'; document.getElementById('divLabel3').style.left = '" + left + "px';</script>";
                            }
                            js += "" + calc.arrAl_Liq[j] + ", " + arrData[j] + ",'c'";
                        }
                        else
                            js += "" + calc.arrAl_Liq[j] + ", " + arrData[j] + ",'c'";

                        js += "]";
                        boolCheckData = true;
                    }

                    js += "];" + "";
                    flag = true;
                }
                // Till here four lines are created

                boolCheckData = false;
                js += "";
                js += "var line" + (calc.dict.Count + 1).ToString() + " = [";
                for (int j = 0; j <= 25; j++)
                {
                    if (boolCheckData == true)
                        js += ",";

                    js += "[";




                    js += "" + arrSlope[j, 0] + ", " + arrSlope[j, 1];

                    js += "]";
                    boolCheckData = true;
                }
                js += "];" + "";
                flag = true;
                js += "";
                js += "var line" + (calc.dict.Count + 2).ToString() + " = [";
                js += "[";
                js += "" + table.totalai.Value + ", " + table.totalfe.Value;
                js += "]";
                js += "];" + "";
                js += "";
                js += "var line" + (calc.dict.Count + 3).ToString() + " = [";
                js += "[";
                js += "" + table.txtAIEffective + ", " + table.txtFEEffective;
                js += "]";
                js += "];" + "";
                js += "";
                js += "var line" + (calc.dict.Count + 4).ToString() + " = [";
                js += "[";
                js += "" + table.totalai.Value + ", " + table.totalfe.Value;
                js += "],";
                js += "[";
                js += "" + table.totalai.Value + ", " + 0;
                js += "]";
                js += "];" + "";
                js += "";
                js += "var line" + (calc.dict.Count + 5).ToString() + " = [";
                js += "[";
                js += "" + table.totalai.Value + ", " + table.totalfe.Value;
                js += "],";
                js += "[";
                js += "" + 0 + ", " + table.totalfe.Value;
                js += "]";
                js += "];" + "";
                js += "";

                // ----------------------------------------------------------------------------------------------------------------------------
                js += bottomLineDataForLeftBox + rightLineDataForLeftBox + topLineDataForLeftBox + leftLineDataForLeftBox;
                js += bottomLineDataForRightBox + rightLineDataForRightBox + topLineDataForRightBox + leftLineDataForRightBox;

                string boxSeries = @"{pointLabels: { show:false }, showLine:true, lineWidth:2, color: '#0B9126', markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: true,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold; font-size:12px;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}";
                // ----------------------------------------------------------------------------------------------------------------------------

                string strg = "";
                string strseries = "";

                if (flag)
                {
                    strg = "[line1";
                    strseries = @" {pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: true,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}" ;
                    for (int i = 1; i <= calc.dict.Count + 4; i++) // - 1 'dtGrades.Rows.Count - 1
                    {
                        strg = strg + ",line" + (i + 1);

                        if (i == 4 | i == 7 | i == 8)
                            strseries = strseries + @", {pointLabels: { show:false }, showLine:true, lineWidth:1, linePattern: 'dashed',  markerOptions:{ size: 5 }, highlighter: {show: false,showMarker: true,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}" ;
                        else if (i >= 5)
                            strseries = strseries + ", {pointLabels: { show:false }, neighborThreshold: 0, showLine:false, showMarker:true, markerOptions: { style:'X' }}";
                        else
                            strseries = strseries + @", {pointLabels: { show:false }, showLine:true, lineWidth:3, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: true,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}" ;
                    }
                    strseries += @", {pointLabels: { show:true }, showLine:false, color: '#1D00FF', lineWidth:2, markerOptions:{ show:true, size: 5, style:'circle' }, highlighter: {show: true,showMarker: true,tooltipAxes:'xy',yvalues: 3,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}" ;
                    strseries = strseries + ", " + boxSeries + ", " + boxSeries + ", " + boxSeries + ", " + boxSeries + ", " + boxSeries + ", " + boxSeries + ", " + boxSeries + ", " + boxSeries;
                    strg += ", EffData, bottomLineDataForLeftBox, rightLineDataForLeftBox, topLineDataForLeftBox, leftLineDataForLeftBox, bottomLineDataForRightBox, rightLineDataForRightBox, topLineDataForRightBox, leftLineDataForRightBox]";
                }

                js += "";
                js += "var EffData = [";
                for (int i = 0; i <= arrEffAl_X.Length - 1; i++)
                {
                    if (i > 0)
                        js += ", ";
                    js += "[" + arrEffAl_X[i] + ", " + arrEffFe_Y[i] + ", '" + (i + 1) + "']";
                }
                js += "];";

                js += "";
                js += "var seriesName = ['";
                string str = "";
                string[] testarr = new[] { "line1", "line2", "line3", "line4", "line5", "line6", "line7", "line8", "line9" };
                for (int i = 0; i <= calc.dict.Count - 1; i++)
                    str += testarr[i] + "', '";
                str = str.Remove(str.LastIndexOf(", '"));
                str += ", 'EffData'";

                str += "];";
                js += str;
                js += "";
                js += "opts = {" + "title: '" + ChartTitle + "'," + "seriesDefaults: { pointLabels: { show:false }, showMarker:false, rendererOptions: {showDataLabels: true, dataLabels:  'label', diameter: 250, dataLabelPositionFactor: 0.5,sliceMargin: 3,color:'#DCDCDC', smooth:false } }," + "series:[" + strseries + "]," + "axesDefaults: {" + "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," + "tickOptions: {" + "fontSize:'9pt'" + "," + " textColor: 'black'" + "}" + "}," + "axes: {" + "xaxis: {" + "min: " + min_time + ", max: " + max_time + "," + "label: '" + XAxisColName + "'," + "tickOptions:{formatString:'', angle: -30}," + "tickInterval:0.005," + "pad:0" + "}," + "yaxis: { " + "min: " + y_min + "," + "max: " + y_max + "," + "tickOptions:{formatString:'', angle: -30}," + "tickInterval:0.005," + "label: '" + YAxisColName + "'," + "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" + "}" + "}," + "cursor: {" + "showTooltip: false," + "zoom: true" + "}," + "animate: true," + "grid: {backgroundColor:  'rgb(255,255,255)'}," + "};" + "" + PlotName + " = $.jqplot('" + ContainerName + "', " + strg + ", opts);" + "</script>";

                table.litLineGraph = js;
            }
            catch (Exception ex)
            {
            }
        }

        public void EffectiveAlAndFeChart(string fromdt,string todt)
        {
            //try
            //{
            //LiteralName = "";
            string s2q = $@"SELECT CZT_EFF_AL, CZT_EFF_FE, CZT_TIMESTAMP, CZT_CAMP_AL, CZT_POT_AL, CZT_POT_FE,""CAMPAIGN"" = CASE WHEN CZT_EFF_AL > 0.15 AND CZT_EFF_AL <= 0.4 THEN 'GI' WHEN CZT_EFF_AL >= 0.1 AND CZT_EFF_AL <= 0.15 THEN 'GA' END, ""UCL"" = CASE WHEN CZT_EFF_AL > 0.15 AND CZT_EFF_AL <= 0.4 THEN 0.19 WHEN CZT_EFF_AL >= 0.1 AND CZT_EFF_AL <= 0.15 THEN 0.133 END, ""LCL"" = CASE WHEN CZT_EFF_AL > 0.15 AND CZT_EFF_AL <= 0.4 THEN 0.18 WHEN CZT_EFF_AL >= 0.1 AND CZT_EFF_AL <= 0.15 THEN 0.123 END FROM FP_PROCESS_DATA.DBO.CGL2_ZNBATH_TREND WHERE CZT_TIMESTAMP BETWEEN  '{fromdt}' and '{todt}' ORDER BY CZT_TIMESTAMP";

            string s2 = $@"SELECT CZT_EFF_AL, CZT_EFF_FE, CZT_TIMESTAMP, CZT_CAMP_AL, CZT_POT_AL, CZT_POT_FE,""CAMPAIGN"" = CASE WHEN CZT_EFF_AL > 0.15 AND CZT_EFF_AL <= 0.4 THEN 'GI' WHEN CZT_EFF_AL >= 0.1 AND CZT_EFF_AL <= 0.15 THEN 'GA' END, ""UCL"" = CASE WHEN CZT_EFF_AL > 0.15 AND CZT_EFF_AL <= 0.4 THEN 0.19 WHEN CZT_EFF_AL >= 0.1 AND CZT_EFF_AL <= 0.15 THEN 0.133 END, ""LCL"" = CASE WHEN CZT_EFF_AL > 0.15 AND CZT_EFF_AL <= 0.4 THEN 0.18 WHEN CZT_EFF_AL >= 0.1 AND CZT_EFF_AL <= 0.15 THEN 0.123 END FROM FP_PROCESS_DATA.DBO.CGL2_ZNBATH_TREND WHERE CZT_TIMESTAMP BETWEEN  '{fromdt}' and '{todt}' ORDER BY CZT_TIMESTAMP";
                dbPtgMenu.Database.CommandTimeout = 300;
                var dtTransitionData = dbPtgMenu.Database.SqlQuery<dttransitiondata>(s2q).ToArray();

                //        


                var dtGI = dtTransitionData.Where(c => c.CAMPAIGN == "GI").OrderBy(o => o.CZT_TIMESTAMP).ToArray();

                var dtGA = dtTransitionData.Where(c => c.CAMPAIGN == "GA").OrderBy(o => o.CZT_TIMESTAMP).ToArray();










            //from val in dt.AsEnumerable()
            //            where val.Field<string>("CAMPAIGN") == "GI"
            //            orderby val.Field<DateTime>("CZT_TIMESTAMP")
            //            select val;
            //DataTable dtGI = query.CopyToDataTable;
            //query = from val in dt.AsEnumerable()
            //        where val.Field<string>("CAMPAIGN") == "GA"
            //        orderby val.Field<DateTime>("CZT_TIMESTAMP")
            //        select val;
            //  DataTable dtGA = query.CopyToDataTable;

            // Below are the temporary datatables holding false record in between two rows having time difference of 24 hours or more.
            DataTable dtGI_Temp = new DataTable();
                dtGI_Temp.Columns.Add("CZT_EFF_AL", typeof(decimal));
                dtGI_Temp.Columns.Add("CZT_EFF_FE", typeof(decimal));
                dtGI_Temp.Columns.Add("CZT_TIMESTAMP", typeof(DateTime));
                dtGI_Temp.Columns.Add("CZT_CAMP_AL", typeof(string));
                dtGI_Temp.Columns.Add("CZT_POT_AL", typeof(decimal));
                dtGI_Temp.Columns.Add("CZT_POT_FE", typeof(decimal));
                dtGI_Temp.Columns.Add("CAMPAIGN", typeof(string));
                dtGI_Temp.Columns.Add("UCL", typeof(decimal));
                dtGI_Temp.Columns.Add("LCL", typeof(decimal));
                for (int i = 0; i <= dtGI.Length - 1; i++)
                {
                    DataRow row = dtGI_Temp.NewRow();
                    row["CZT_EFF_AL"] = dtGI[i].CZT_EFF_AL; //.Rows(i)("CZT_EFF_AL");
                    row["CZT_EFF_FE"] = dtGI[i].CZT_EFF_FE;
                    row["CZT_TIMESTAMP"] = (DateTime)dtGI[i].CZT_TIMESTAMP;
                    row["CZT_CAMP_AL"] = dtGI[i].CZT_CAMP_AL;
                    row["CZT_POT_FE"] = dtGI[i].CZT_POT_AL;
                    //row("CZT_POT_AL") = dtGI.Rows(i)("CZT_POT_AL");
                    row["CZT_POT_FE"] = dtGI[i].CZT_POT_FE;
                    row["CAMPAIGN"] = dtGI[i].CAMPAIGN;
                    row["UCL"] = dtGI[i].UCL;
                    row["LCL"] = dtGI[i].LCL;
                    dtGI_Temp.Rows.Add(row);

            

                    if (i < dtGI.Length - 1)
                    {
                        // TimeSpan span = DateTime.Parse(dtGI.Rows(i + 1)("CZT_TIMESTAMP")).Subtract(DateTime.Parse(dtGI.Rows(i)("CZT_TIMESTAMP")));
                       TimeSpan span = dtGI[i + 1].CZT_TIMESTAMP.Subtract(dtGI[i].CZT_TIMESTAMP);
                        if (span.TotalHours >= 24)
                            dtGI_Temp.Rows.Add(dtGI[i].CZT_EFF_AL, dtGI[i].CZT_EFF_FE, (DateTime)dtGI[i].CZT_TIMESTAMP.AddMinutes(10), dtGI[i].CZT_CAMP_AL, dtGI[i].CZT_POT_AL, dtGI[i].CZT_POT_FE, dtGI[i].CAMPAIGN, 0, 0);
                    }
                }

                DataTable dtGA_Temp = new DataTable();
                dtGA_Temp.Columns.Add("CZT_EFF_AL", typeof(decimal));
                dtGA_Temp.Columns.Add("CZT_EFF_FE", typeof(decimal));
                dtGA_Temp.Columns.Add("CZT_TIMESTAMP", typeof(DateTime));
                dtGA_Temp.Columns.Add("CZT_CAMP_AL", typeof(string));
                dtGA_Temp.Columns.Add("CZT_POT_AL", typeof(decimal));
                dtGA_Temp.Columns.Add("CZT_POT_FE", typeof(decimal));
                dtGA_Temp.Columns.Add("CAMPAIGN", typeof(string));
                dtGA_Temp.Columns.Add("UCL", typeof(decimal));
                dtGA_Temp.Columns.Add("LCL", typeof(decimal));
                for (int i = 0; i <= dtGA.Length - 1; i++)
                {
                    DataRow row = dtGA_Temp.NewRow();
                    row["CZT_EFF_AL"] = dtGA[i].CZT_EFF_AL;
                    row["CZT_EFF_FE"] = dtGA[i].CZT_EFF_FE;
                    row["CZT_TIMESTAMP"] = (DateTime)dtGA[i].CZT_TIMESTAMP;
                    row["CZT_CAMP_AL"] = dtGA[i].CZT_CAMP_AL;
                    row["CZT_POT_AL"] = dtGA[i].CZT_POT_AL;
                    row["CZT_POT_FE"] = dtGA[i].CZT_POT_FE;
                    row["CAMPAIGN"] = dtGA[i].CAMPAIGN;
                    row["UCL"] = dtGA[i].UCL;
                    row["LCL"] = dtGA[i].LCL;
                    dtGA_Temp.Rows.Add(row);
                    if (i < dtGA.Length - 1)
                    {
                       // TimeSpan span = DateTime.Parse(dtGA.Rows(i + 1)("CZT_TIMESTAMP")).Subtract(DateTime.Parse(dtGA.Rows(i)("CZT_TIMESTAMP")));
                        TimeSpan span = dtGA[i + 1].CZT_TIMESTAMP.Subtract(dtGA[i].CZT_TIMESTAMP);
                        if (span.TotalHours >= 24)
                            dtGA_Temp.Rows.Add(dtGA[i].CZT_EFF_AL, dtGA[i].CZT_EFF_FE, (DateTime)dtGA[i].CZT_TIMESTAMP.AddMinutes(10), dtGA[i].CZT_CAMP_AL, dtGA[i].CZT_POT_AL, dtGA[i].CZT_POT_FE, dtGA[i].CAMPAIGN, 0, 0);
                    }
                }
                // ---------------------------------------END OF TEMPORARY DATATABLES----------------------------------------------

                // Dim giUclDataPoints As String = "var GI_UCL = [['" & CDate(dtGI.Rows(0)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGI.Rows(0)("UCL") & "], ['" & CDate(dtGI.Rows(dtGI.Rows.Count - 1)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGI.Rows(dtGI.Rows.Count - 1)("UCL") & "]];"
                string giUclDataPoints = "var GI_UCL = [[";
                for (int i = 0; i <= dtGI_Temp.Rows.Count - 1; i++)
                {
                    if (i == dtGI_Temp.Rows.Count - 1)
                        giUclDataPoints += "'" + Convert.ToDateTime(dtGI_Temp.Rows[i]["CZT_TIMESTAMP"]).ToString("yyyy-MM-dd HH:mm") + "', " + (Convert.ToDecimal(dtGI_Temp.Rows[i]["UCL"].ToString()) == 0 ? "null" : dtGI_Temp.Rows[i]["UCL"]) + "]];";
                    else
                        giUclDataPoints += "'" + Convert.ToDateTime(dtGI_Temp.Rows[i]["CZT_TIMESTAMP"]).ToString("yyyy-MM-dd HH:mm") + "', " + (Convert.ToDecimal(dtGI_Temp.Rows[i]["UCL"].ToString()) == 0 ? "null" : dtGI_Temp.Rows[i]["UCL"]) + "], [";
                }
                if (dtGI_Temp.Rows.Count == 0)
                    giUclDataPoints += "]];";
           
                // Dim giLclDataPoints As String = "var GI_LCL = [['" & CDate(dtGI_Temp.Rows(0)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGI_Temp.Rows(0)("LCL") & "], ['" & CDate(dtGI_Temp.Rows(dtGI_Temp.Rows.Count - 1)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGI_Temp.Rows(dtGI_Temp.Rows.Count - 1)("LCL") & "]];"
                string giLclDataPoints = "var GI_LCL = [[";
                for (int i = 0; i <= dtGI_Temp.Rows.Count - 1; i++)
                {
                    if (i == dtGI_Temp.Rows.Count - 1)
                        giLclDataPoints += "'" + Convert.ToDateTime(dtGI_Temp.Rows[i]["CZT_TIMESTAMP"]).ToString("yyyy-MM-dd HH:mm") + "', " + (Convert.ToDecimal(dtGI_Temp.Rows[i]["LCL"].ToString()) == 0 ? "null" : dtGI_Temp.Rows[i]["LCL"]) + "]];";
                    else
                        giLclDataPoints += "'" + Convert.ToDateTime(dtGI_Temp.Rows[i]["CZT_TIMESTAMP"]).ToString("yyyy-MM-dd HH:mm") + "', " + (Convert.ToDecimal(dtGI_Temp.Rows[i]["LCL"].ToString()) == 0 ? "null" : dtGI_Temp.Rows[i]["LCL"]) + "], [";
                }
                if (dtGI_Temp.Rows.Count == 0)
                    giLclDataPoints += "]];";
                // Dim gaUclDataPoints As String = "var GA_UCL = [['" & CDate(dtGA.Rows(0)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGA.Rows(0)("UCL") & "], ['" & CDate(dtGA.Rows(dtGA.Rows.Count - 1)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGA.Rows(dtGA.Rows.Count - 1)("UCL") & "]];"
                string gaUclDataPoints = "var GA_UCL = [[";
                for (int i = 0; i <= dtGA_Temp.Rows.Count - 1; i++)
                {
                    if (i == dtGA_Temp.Rows.Count - 1)

                        //gaUclDataPoints += "'" + (DateTime)dtGA_Temp.Rows(i)("CZT_TIMESTAMP").ToString("yyyy-MM-dd HH:mm") + "', " + IIf(dtGA_Temp.Rows(i)("UCL") == 0, "null", dtGA_Temp.Rows(i)("UCL")) + "]];";

                        gaUclDataPoints += "'" + Convert.ToDateTime(dtGA_Temp.Rows[i]["CZT_TIMESTAMP"]).ToString("yyyy-MM-dd HH:mm") + "', " + (Convert.ToDecimal(dtGA_Temp.Rows[i]["UCL"].ToString()) == 0 ? "null": dtGA_Temp.Rows[i]["UCL"]) + "]];";

                    else

                        //gaUclDataPoints += "'" + (DateTime)dtGA_Temp.Rows(i)("CZT_TIMESTAMP").ToString("yyyy-MM-dd HH:mm") + "', " + IIf(dtGA_Temp.Rows(i)("UCL") == 0, "null", dtGA_Temp.Rows(i)("UCL")) + "], [";

                        gaUclDataPoints += "'" + Convert.ToDateTime(dtGA_Temp.Rows[i]["CZT_TIMESTAMP"]).ToString("yyyy-MM-dd HH:mm") + "', " + (Convert.ToDecimal(dtGA_Temp.Rows[i]["UCL"].ToString()) == 0 ? "null" : dtGA_Temp.Rows[i]["UCL"]) + "], [";
                }
                if (dtGA_Temp.Rows.Count == 0)
                    gaUclDataPoints += "]];";
                // Dim gaLclDataPoints As String = "var GA_LCL = [['" & CDate(dtGA_Temp.Rows(0)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGA_Temp.Rows(0)("LCL") & "], ['" & CDate(dtGA_Temp.Rows(dtGA_Temp.Rows.Count - 1)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGA_Temp.Rows(dtGA_Temp.Rows.Count - 1)("LCL") & "]];"
                string gaLclDataPoints = "var GA_LCL = [[";
                for (int i = 0; i <= dtGA_Temp.Rows.Count - 1; i++)
                {
                    if (i == dtGA_Temp.Rows.Count - 1)
                        gaLclDataPoints += "'" + Convert.ToDateTime(dtGA_Temp.Rows[i]["CZT_TIMESTAMP"]).ToString("yyyy-MM-dd HH:mm") + "', " + (Convert.ToDecimal(dtGA_Temp.Rows[i]["LCL"].ToString()) == 0 ? "null" : dtGA_Temp.Rows[i]["LCL"]) + "]];";
                    else
                        gaLclDataPoints += "'" + Convert.ToDateTime(dtGA_Temp.Rows[i]["CZT_TIMESTAMP"]).ToString("yyyy-MM-dd HH:mm") + "', " + (Convert.ToDecimal(dtGA_Temp.Rows[i]["LCL"].ToString()) == 0 ? "null" : dtGA_Temp.Rows[i]["LCL"]) + "], [";
                }
                if (dtGA_Temp.Rows.Count == 0)
                    gaLclDataPoints += "]];";
                string min_time, max_time;
                min_time = dtTransitionData.Min(p => p.CZT_TIMESTAMP).ToString("yyyy-MM-dd HH:mm"); //dtTransitionData.Min(p=>p .Rows(0)("CZT_TIMESTAMP"), "yyyy-MM-dd HH:mm");
                max_time = dtTransitionData.Max(p => p.CZT_TIMESTAMP).ToString("yyyy-MM-dd HH:mm"); //Format(dt.Rows(dt.Rows.Count - 1)("CZT_TIMESTAMP"), "yyyy-MM-dd HH:mm");

                string[] xTimestampVal, y1EffectiveAlVal, y2EffectiveFe;

                xTimestampVal = dtTransitionData.Select(p => p.CZT_TIMESTAMP.ToString()).ToArray();
                //(from row in dt
                //                 select row("CZT_TIMESTAMP").ToString).ToArray;
                y1EffectiveAlVal = dtTransitionData.Select(p => p.CZT_EFF_AL.ToString()).ToArray();
                //(from row in dt
                //                    select row("CZT_EFF_AL").ToString).ToArray();
                y2EffectiveFe = dtTransitionData.Select(p => p.CZT_EFF_FE.ToString()).ToArray();
                //(from row in dt
                //                 select row("CZT_EFF_FE").ToString).ToArray();

                // Dim Al_min As String = 0 'As per the Excel file.
                // Dim Al_max As String = 0.35 'As per the Excel file.
                // Dim Fe_min As String = 0 'As per the Excel file.
                // Dim Fe_max As String = 0.07 'As per the Excel file.
                string Al_min = 0.ToString(); // Changed by mamta on 11-Jan-2018
                string Al_max = 0.3.ToString(); // Changed by mamta on 11-Jan-2018
                string Fe_min = 0.ToString(); // Changed by mamta on 11-Jan-2018
                string Fe_max = 0.05.ToString();//; // Changed by mamta on 11-Jan-2018

                var js = "<script language='javascript' type='text/javascript'>" + "$(document).ready(function(){" + "$.jqplot.config.enablePlugins = true;" + "var series= ['Effective Aluminium', 'Effective Iron', 'GI Limits', 'GA Limits']" + ";var data1 = [[";
                for (var i = 0; i <= dtTransitionData.Length - 1; i++)
                {
                    if (i == xTimestampVal.Length - 1)
                        js += "'" + DateTime.Parse(xTimestampVal.GetValue(i).ToString().Trim()).ToString("yyyy-MM-dd HH:mm") + "', " + y1EffectiveAlVal.GetValue(i).ToString().Trim() + "]]; ";
                    else
                        js += "'" + DateTime.Parse(xTimestampVal.GetValue(i).ToString().Trim()).ToString("yyyy-MM-dd HH:mm") + "', " + y1EffectiveAlVal.GetValue(i).ToString().Trim() + "], [";
                }


                js += "var data2 = [[";
                for (var i = 0; i <= dtTransitionData.Length - 1; i++)
                {
                    if (i == xTimestampVal.Length - 1)
                        js += "'" + DateTime.Parse(xTimestampVal.GetValue(i).ToString().Trim()).ToString("yyyy-MM-dd HH:mm") + "', " + y2EffectiveFe.GetValue(i).ToString().Trim() + "]]; ";
                    else
                        js += "'" + DateTime.Parse(xTimestampVal.GetValue(i).ToString().Trim()).ToString("yyyy-MM-dd HH:mm") + "', " + y2EffectiveFe.GetValue(i).ToString().Trim() + "], [";
                }

                js +=   giLclDataPoints + giUclDataPoints + gaLclDataPoints + gaUclDataPoints;

                string EffAl_Series = @"{pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:80px; width:180px; background-color:#0D5CA5; font-weight:bold; font-size:x-large; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td><center>%s</center></td></tr></table>'}}";
                string EffFe_Series = @"{pointLabels: { show:false }, showLine: true, yaxis:'y2axis', lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:80px; width:180px; background-color:#BC2318; font-weight:bold; font-size:x-large; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td><center>%s</center></td></tr></table>'}}";
                string GI_Limit_Series = @"{pointLabels:{show:!1},showLine:!0,lineWidth:2,breakOnNull: true,linePattern:'dashed',showMarker:!1,color:'#00FF19',highlighter:{show:!0,showMarker:!1,tooltipAxes:'xy',yvalues:2,formatString:'<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}";
                string GA_Limit_Series = @"{pointLabels:{show:!1},showLine:!0,lineWidth:2,breakOnNull: true,linePattern:'dashed',showMarker:!1,color:'#000000',highlighter:{show:!0,showMarker:!1,tooltipAxes:'xy',yvalues:2,formatString:'<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}";

                js += "opts = {" + "title: 'Calculated Effective Al & Fe'," + "series:[" + EffAl_Series + ", " + EffFe_Series + ", " + GI_Limit_Series + ", " + GI_Limit_Series + ", " + GA_Limit_Series + ", " + GA_Limit_Series + "]," + "seriesColors: ['#0D5CA5', '#BC2318']," + "axesDefaults: {" + "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," + "tickOptions: {" + "fontSize:'9pt'" + "," + " textColor: 'black'" +"}" + "}," + "axes: {" + "xaxis: {" + "min: '" + min_time + "', max: '" + max_time + "'," + "renderer:$.jqplot.DateAxisRenderer," + "tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," + "pad:0" + "}," + "yaxis: { " + "tickOptions: { formatString: '%.3f' }," + "min: " + Al_min + "," + "max: " + Al_max + ","  + "label: '% Effective Al'," + "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" + "}," + "y2axis: { " + "tickOptions: { formatString: '%.3f' }," + "min: " + Fe_min + "," + "max: " + Fe_max + ","  + "label: '% Effective Fe'," + "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" + "}" + "}," + "cursor: {" + "zoom: true" + "}," +  "grid: {backgroundColor:  'rgb(255,255,255)'}," + "legend: {" + "show: true," + "location: 's'," + "labels: series," + "renderer: $.jqplot.EnhancedLegendRenderer," + "placement: 'outsideGrid'," + "rendererOptions: {" + "numberRows: 1," + "numberColumns: 2," + "marginTop: 10" + "}" + "}" + "};" + "plotFeAl = $.jqplot('divContainer1', [data1, data2, GI_UCL, GI_LCL, GA_UCL, GA_LCL], opts);" + "});" + "</script>";

                table.litEffGraph = js;
               // litChart.Text = js;
            //}
            //catch (Exception ex)
            //{
            //}
        }





    }



}


























