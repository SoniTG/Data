﻿using PTG_TSJ_Main.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PTG_TSJ_Main.BussinessLogic.CGL2
{
    public class BL_Cgl2alfemonitoring
    {
        public MultipleData Main_Cgl2alfemonitoring()
        {
            var table = new MultipleData();

            return table;
        }
    }
}