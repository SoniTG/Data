﻿using System;
using System.Collections.Generic;

public class EffectiveAlFeCalculation
{
    // Dim frmAl_Prediction As New frmAl_Prediction
    private double xTemp, Fe_tot, Fe_solb, J_Calc;
    public double Al_trip, Fe_trip, Al_liq, Fe_liq;
    public double[] arrAl_Liq, arrFeZn7_Left, arrFe2Zn5_right, arrConode_Left, arrConode_Right, arrRight_conode_parallel_line;
    public Dictionary<int, double[]> dict = new Dictionary<int, double[]>();

    public void Main(double T_Bath_C, double T_Bath_K)
    {
        

        Al_trip = Al_Triple_Pnt_Calc(T_Bath_C);
        Fe_trip = Fe_Triple_Pnt_Calc(T_Bath_K);

        // fill data in arrAl_liq
        int no_iteration;
        double Al_increment;

        double Al_min, Al_max, Fe_min, Fe_max;

        Al_min = 0.08;
        Al_max = 0.3;
        Fe_min = 0;
        Fe_max = 0.1;
        no_iteration = Convert.ToInt32((Al_max - Al_min) * 10000 + 1); // changed by mamta on 21st sep'18 -- old (0.26 - 0.08) * 10000 + 1
        Al_increment = 0.0001;

        arrAl_Liq = new double[no_iteration];
        arrFeZn7_Left = new double[no_iteration];
         arrConode_Right = new double[no_iteration];
       arrRight_conode_parallel_line = new double[no_iteration];


        //var oldArrAl_Liq = arrAl_Liq;
        //arrAl_Liq = new double[no_iteration - 1 + 1];
        //if (oldArrAl_Liq != null)
        //    Array.Copy(oldArrAl_Liq, arrAl_Liq, Math.Min(no_iteration - 1 + 1, oldArrAl_Liq.Length));
        //var oldArrFeZn7_Left = arrFeZn7_Left;
        //arrFeZn7_Left = new double[no_iteration - 1 + 1];
        //if (oldArrFeZn7_Left != null)
        //    Array.Copy(oldArrFeZn7_Left, arrFeZn7_Left, Math.Min(no_iteration - 1 + 1, oldArrFeZn7_Left.Length));
        //var oldArrConode_Right = arrConode_Right;
        //arrConode_Right = new double[no_iteration - 1 + 1];
        //if (oldArrConode_Right != null)
        //    Array.Copy(oldArrConode_Right, arrConode_Right, Math.Min(no_iteration - 1 + 1, oldArrConode_Right.Length));
        //var oldArrRight_conode_parallel_line = arrRight_conode_parallel_line;
        //arrRight_conode_parallel_line = new double[no_iteration - 1 + 1];
        //if (oldArrRight_conode_parallel_line != null)
        //    Array.Copy(oldArrRight_conode_parallel_line, arrRight_conode_parallel_line, Math.Min(no_iteration - 1 + 1, oldArrRight_conode_parallel_line.Length));




        // Filling X-axis Value
        for (int i = 0; i <= no_iteration - 1; i++)
            arrAl_Liq[i] = Math.Round(Al_min + i * Al_increment, 4);




        // FeZn7 Left - left side of solubility curve
        for (int i = 0; i <= no_iteration - 1; i++)
        {
            if (arrAl_Liq[i] < Al_trip)
                arrFeZn7_Left[i] = Fe_trip + 0.0483125 * Al_trip - 0.0483125 * arrAl_Liq[i];
            else
                
                break;
        }

        if (!dict.ContainsKey(0))
            dict.Add(0, arrFeZn7_Left);
        
      arrFe2Zn5_right = new double[no_iteration - 1 + 1];

        // Fe2Al5 right-right side of solubility curve
         
        //ReDim Preserve arrFe2Zn5_right(no_iteration - 1)

        

        for (int i = 0; i <= no_iteration - 1; i++)
        {
            if (arrAl_Liq[i] >= (Al_trip - 0.0001))
                arrFe2Zn5_right[i] = J_Calc * (Math.Pow(arrAl_Liq[i], (-2.5755814)));
        }
        if (!dict.ContainsKey(1))
            dict.Add(1, arrFe2Zn5_right);

        // Conode Left

        //  Dim val As Double
        //ReDim Preserve arrConode_Left(no_iteration - 1)

        double val;
       
      arrConode_Left = new double[no_iteration - 1 + 1];
       

        for (int i = 0; i <= no_iteration - 1; i++)
        {
            if (arrAl_Liq[i] >= (Al_trip - 0.0001))
            {
                val = (Fe_trip - 3.3117161 * Al_trip) + 3.3117161 * arrAl_Liq[i];
                if (val <= Fe_max)
                    arrConode_Left[i] = val;
            }
        }
        if (!dict.ContainsKey(2))
            dict.Add(2, arrConode_Left);
       
      //double[]  arrConode_Right = new double[no_iteration - 1 + 1];

        // Conode right

        //ReDim Preserve arrConode_Right(no_iteration - 1)
       
        for (int i = 0; i <= no_iteration - 1; i++)
        {
            if (arrAl_Liq[i] >= (Al_trip - 0.0001))
            {
                val = (Fe_trip - 0.8036331 * Al_trip) + 0.8036331 * arrAl_Liq[i];
                if (val <= Fe_max)
                    arrConode_Right[i] = val;
            }
        }
        if (!dict.ContainsKey(3))
            dict.Add(3, arrConode_Right);
    }










    //ReDim Preserve arrConode_Right(no_iteration - 1)
    public void mtdEffectivAlFeCal(double Al_tot_old, double T_Bath_K, double Al_trip, double Fe_trip)
    {
        Fe_solb = Math.Exp(17.78 - (15388 / (double)T_Bath_K));
        if (Al_tot_old < 0.134)
        {
            xTemp = 3 * (0.42 * Al_tot_old) * (1 - (0.42 * Al_tot_old)) + (0.42 * Al_tot_old) * (Math.Log(0.42 * Al_tot_old)) + ((1 - (0.42 * Al_tot_old)) * (Math.Log(1 - (0.42 * Al_tot_old)))) / (double)(1 - (0.42 * Al_tot_old));
            Fe_tot = 1.9 * Fe_solb * Math.Exp(8 * xTemp);
        }
        else
            Fe_tot = Math.Sqrt((Math.Exp(32.3 - (36133 / (double)T_Bath_K))) / (Math.Pow(Al_tot_old, 5)));
        Al_liq = ((Fe_trip + (0.0483125 * Al_trip)) - Fe_tot + (3.25 * Al_tot_old)) / 3.3600286;  // 3.3117161
        Fe_liq = Fe_tot - (0.8036331 * Al_tot_old) + (0.8036331 * Al_liq);
    }




    //done by subiya from here

  
      

    //here
    public void Aleffcal(double Al_tot_old, double Fe_tot_old)
    {
        double temp1, Fe1, Fe2, Fe3, Fe4, Fetot, Altot, Altriple, err;
        double aleff = 0.0, Feeff = 0.0;
        double calvar;
        int temp2;

        //done by subiya from here

        Altot = Al_tot_old;
        Fetot = Fe_tot_old; // Range("C5").Value
        Altriple = Al_trip; // Range("K3").Value
        temp2 = 0;
        temp1 = Math.Round(Al_tot_old, 4);  // Format((Range("C4").Value), "#0.0000")
        while ((Math.Round(arrAl_Liq[temp2], 4) < temp1))
        {
            if (temp2 == arrAl_Liq.Length - 1)
                break;
            temp2 = temp2 + 1;
        }

        Fe1 = Fe_trip + 0.0483125 * Al_trip - 0.0483125 * arrAl_Liq[temp2];
        Fe2 = (Fe_trip - 3.3117161 * Al_trip) + 3.3117161 * arrAl_Liq[temp2];
        Fe3 = Fe_trip - 0.8036331 * Al_trip + 0.8036331 * arrAl_Liq[temp2];
        Fe4 = J_Calc * Math.Pow(arrAl_Liq[temp2], (-2.5755814));

        temp1 = 10;
        if ((Fetot >= Fe4 & Fetot <= Fe3 & Altot > Altriple))
        {
            // MsgBox ("IV")
            temp2 = 0;
            while ((temp2 <= arrAl_Liq.Length - 1))
            {
                calvar = (Fe_tot_old - 0.8036331 * Al_tot_old) + 0.8036331 * arrAl_Liq[temp2];
                if ((calvar <= 0.05 & calvar > 0.002))
                {
                    arrRight_conode_parallel_line[temp2] = calvar;
                    err = Math.Abs(arrRight_conode_parallel_line[temp2] - arrFe2Zn5_right[temp2]);
                    if (err < temp1)
                    {
                        temp1 = err;
                        aleff = arrAl_Liq[temp2];
                        Feeff = calvar;
                    }
                }
                temp2 = temp2 + 1;
            }
        }
        else if ((Altot >= Altriple & Fetot > Fe3 & Fetot < Fe2))
        {
            // MsgBox ("II")
            Al_liq = Math.Round(Altriple, 4);
            Fe_liq = Math.Round(Fe_trip, 4);
            goto last;
        }
        else if ((Altot >= Altriple & Fetot > Fe2))
        {
            // MsgBox ("II")
            temp2 = 0;
            while ((temp2 <= arrAl_Liq.Length - 1))
            {
                calvar = (Fe_tot_old - 3.3117161 * Al_tot_old) + 3.3117161 * arrAl_Liq[temp2];
                if ((calvar <= 0.05 & calvar > 0.002))
                {
                    arrRight_conode_parallel_line[temp2] = calvar;
                    err = Math.Abs(arrRight_conode_parallel_line[temp2] - arrFeZn7_Left[temp2]);
                    if (err < temp1)
                    {
                        temp1 = err;
                        aleff = arrAl_Liq[temp2];
                        Feeff = calvar;
                    }
                }
                temp2 = temp2 + 1;
            }
        }
        else if ((Altot < Altriple & Fetot > Fe1))
        {
            // MsgBox ("I")
            temp2 = 0;
            while ((temp2 <= arrAl_Liq.Length - 1))
            {
                calvar = (Fe_tot_old - 3.3117161 * Al_tot_old) + 3.3117161 * arrAl_Liq[temp2];
                if ((calvar <= 0.05 & calvar > 0.002))
                {
                    arrRight_conode_parallel_line[temp2] = calvar;
                    err = Math.Abs(arrRight_conode_parallel_line[temp2] - arrFeZn7_Left[temp2]);
                    if (err < temp1)
                    {
                        temp1 = err;
                        aleff = arrAl_Liq[temp2];
                        Feeff = calvar;
                    }
                }
                temp2 = temp2 + 1;
            }
        }
        else
            // MsgBox ("Invalid Values")
            goto last;
        Al_liq = Math.Round(aleff, 4);
        Fe_liq = Math.Round(Feeff, 4);

        last:
        ;
    }



    // Al triple point Calculation
    public double Al_Triple_Pnt_Calc(double T_Bath_C)
    {
        double AlTrip;
        AlTrip = 0.017 + (0.00025 * T_Bath_C);
        return AlTrip;
    }

    // Fe triple point Calculation
    public double Fe_Triple_Pnt_Calc(double T_Bath_K)
    {
        double FeTrip, Delta_G, Int_A, Int_B, J;
        // Delta_G Calculation
        Delta_G = ((1.72 * ((0.1384 * T_Bath_K) - 8678.4711)) + (4.43 * ((3.7924 * T_Bath_K) - 9662.2839))) / (double)(1.987 * T_Bath_K);
        Int_A = (4.41027195404554E+21 * (Math.Exp(Delta_G / (1))));
        Int_B = (146350673298.009 * (Math.Pow((19.2692 - (0.0133 * T_Bath_K)), 1.72))) * ((Math.Pow((8.3424 - (0.0074 * T_Bath_K)), 4.43)));
        J_Calc = Math.Pow((Int_A / Int_B), 0.581395349);

        FeTrip = J_Calc * (Math.Pow(Al_trip, (-2.5755814)));

        return FeTrip;
    }
}
