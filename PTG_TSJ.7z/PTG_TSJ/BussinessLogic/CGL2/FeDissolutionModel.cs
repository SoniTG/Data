﻿using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace PTG_TSJ_Main.BussinessLogic.CGL2
{
    public class FeDissolutionModel
    {
        MultipleData table = new MultipleData();
        PTG_WEBSITEEntities dbPtgMenu = new PTG_WEBSITEEntities();

        internal MultipleData GetDataForAl_Fe_Prediction_Model(string StDt, string EndDt)
        {
            if (StDt == null && EndDt == null)
            {
                table.dst = DateTime.Now.AddDays(-29).ToString("yyyy - MM - dd 00:00:01");

                table.det = DateTime.Now.ToString("yyyy-MM-dd 23:59:59");


                CalFeDisso_Weight(table.dst, table.det);

                double RaiseLevel = Math.Round((0.13 * 200 * 1000 / 100));
                table.lblAlReqToRaiseAlLevel = RaiseLevel.ToString();

                double FeSolubility = Math.Round((0.022 * 200 * 1000 / 100 * 135 / 112));
                table.lblAlReqFeSolubility = FeSolubility.ToString();


                Cal_STRIP_FE_KG_DISSOLVED(table.dst, table.det);

                CalGANoOfDays(table.dst, table.det);

                CalGAStartEndDate(table.dst, table.det);

                double data = CalPreviousDross(table.dst, table.det);
                var data1 = data * 10;

                double a = 0.0;

                DrawChart(table.dst, table.det, a);

            }
            else
            {
                table.dst = StDt.ToString();

                table.det = EndDt.ToString();
                //DateTime dtStart = DateTime.Now.AddDays(-29);

                //string dst = dtStart.ToString("yyyy-MM-dd 00:00:01");
                //DateTime dtEnd = DateTime.Now;

                //string det = dtEnd.ToString("yyyy-MM-dd 23:59:59");




                CalFeDisso_Weight(table.dst, table.det);

                double RaiseLevel = Math.Round((0.13 * 200 * 1000 / 100));
                table.lblAlReqToRaiseAlLevel = RaiseLevel.ToString();

                double FeSolubility = Math.Round((0.022 * 200 * 1000 / 100 * 135 / 112));
                table.lblAlReqFeSolubility = FeSolubility.ToString();


                Cal_STRIP_FE_KG_DISSOLVED(table.dst, table.det);

                CalGANoOfDays(table.dst, table.det);

                CalGAStartEndDate(table.dst, table.det);

                double data = CalPreviousDross(table.dst, table.det);
                var data1 = data * 10;

               // double a = 0.0;

                DrawChart(table.dst, table.det, data1);

            }
           

            return table;


        }
       

        public void CalFeDisso_Weight(string dst, string det)
        {

            string s1 = $@"SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END  FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END BETWEEN '{dst}' AND '{det}' order by PRM_TS_END desc";
            dbPtgMenu.Database.CommandTimeout = 300;
            var dt1 = dbPtgMenu.Database.SqlQuery<dtt1>(s1).ToArray();


            DateTime EndDate = Convert.ToDateTime(dt1[0].PRM_TS_END);
            int cnt = 4;
            DateTime AEndDate = EndDate;
            DateTime ZCampDate;
            while (true)
            {

                string s2 = $@"SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='Z' and PRM_TS_END <='{AEndDate}' order by PRM_TS_END desc";
                dbPtgMenu.Database.CommandTimeout = 300;
                var dt2 = dbPtgMenu.Database.SqlQuery<dtt1>(s2).ToArray();
                ZCampDate = Convert.ToDateTime(dt2[0].PRM_TS_END);

                string s3 = $@"SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END <='{ZCampDate}' order by PRM_TS_END desc";
                dbPtgMenu.Database.CommandTimeout = 300;
                var dt3 = dbPtgMenu.Database.SqlQuery<dtt1>(s3).ToArray();

                DateTime ACampDate = Convert.ToDateTime(dt3[0].PRM_TS_END);

                string s4 = $@"SELECT count(*) as count FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_TS_END] > '{ACampDate}' and PRM_TS_END <='{ZCampDate}'";
                dbPtgMenu.Database.CommandTimeout = 300;
                var dt4 = dbPtgMenu.Database.SqlQuery<dtt1>(s4).ToArray();
                cnt = Convert.ToInt32(dt4[0].count);

                if (cnt < 7)
                {
                    AEndDate = ACampDate;
                }
                else
                {
                    break;
                }
            }

            string s5 = $@"SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END >='{ZCampDate}' order by PRM_TS_END ";
            dbPtgMenu.Database.CommandTimeout = 300;
            var dt5 = dbPtgMenu.Database.SqlQuery<dtt1>(s5).ToArray();
            DateTime StartDate = dt5[0].PRM_TS_END;


            string s6 = $@"select  (sum(PRM_MS_COIL_ACTL))/1000 as sum  FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] = 'A' and PRM_TS_END BETWEEN '{StartDate}' AND '{EndDate}'";
            dbPtgMenu.Database.CommandTimeout = 300;
            var dt6 = dbPtgMenu.Database.SqlQuery<dtt1>(s6).ToArray();
            decimal sumtotal0 = dt6[0].sum;

            decimal sumtotal1 = Math.Round(sumtotal0);
            table.lblGAWeight = sumtotal1.ToString();



        }






        public void Cal_STRIP_FE_KG_DISSOLVED(string dst, string det)
        {
            string s1 = $@"SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END  FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END BETWEEN '{dst}' AND '{det}' order by PRM_TS_END desc";
            dbPtgMenu.Database.CommandTimeout = 300;
            var dt1 = dbPtgMenu.Database.SqlQuery<dtt2>(s1).ToArray();
            DateTime EndDate = dt1[0].PRM_TS_END;


            int cnt = 4;
            var AEndDate = EndDate;
            DateTime ZCampDate;



            while (true)
            {
                string s2 = $@"SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='Z' and PRM_TS_END <='{AEndDate}' order by PRM_TS_END desc";
                dbPtgMenu.Database.CommandTimeout = 300;
                var dt2 = dbPtgMenu.Database.SqlQuery<dtt2>(s2).ToArray();
                ZCampDate = dt2[0].PRM_TS_END;

                string s3 = $@"SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END <='{ZCampDate}' order by PRM_TS_END desc";
                dbPtgMenu.Database.CommandTimeout = 300;
                var dt3 = dbPtgMenu.Database.SqlQuery<dtt2>(s3).ToArray();
                DateTime ACampDate = dt3[0].PRM_TS_END;



                string s4 = $@"SELECT count(*) as Count FROM[FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where[PRM_TS_END] > '{ACampDate}' and PRM_TS_END <='{ZCampDate}'";
                dbPtgMenu.Database.CommandTimeout = 300;
                var dt4 = dbPtgMenu.Database.SqlQuery<dtt2>(s4).ToArray();
                cnt = dt4[0].count;



                if (cnt < 7)
                {
                    AEndDate = ACampDate;
                }
                else
                {
                    break;
                }
            }

            string s5 = $@"SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END >='{ ZCampDate}' order by PRM_TS_END ";
            dbPtgMenu.Database.CommandTimeout = 300;
            var dt5 = dbPtgMenu.Database.SqlQuery<dtt2>(s5).ToArray();
            DateTime StartDate = dt5[0].PRM_TS_END;

            string s6 = $@"SELECT SUM(CFD_STRIP_FE_KG_DISSOLVED) Fe,SUM(CFD_AL_REQ_FOR_DISSOLVED_FE) Al FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] INNER JOIN  [FP_PROCESS_DATA].[dbo].[CGL2_FE_DISSOLUTION] ON T_CGL_FUR_PARAM.PRM_MESSAGE_ID=CGL2_FE_DISSOLUTION.CFD_MESSAGE_ID  where T_CGL_FUR_PARAM.PRM_TS_END BETWEEN '{StartDate}' AND '{EndDate}' group by convert(date,T_CGL_FUR_PARAM.PRM_TS_END)";
            dbPtgMenu.Database.CommandTimeout = 300;
            var dt6 = dbPtgMenu.Database.SqlQuery<dtt2>(s6).ToArray();

            var Fe = dt6.Select(e => e.Fe).ToArray();
            var al = dt6.Select(e => e.Al).ToArray();
           
            decimal Fe_dross = Fe.Sum();
            decimal al_dross = al.Sum();
          

            //for fe

            var lblCalFeInDross0 = String.Format("{0:0.000}", Fe_dross);
            table.lblCalFeInDross = lblCalFeInDross0.ToString();
           // var data = Math.Round(236.125835, 4);
            decimal lblCalDross0 = Math.Round(Fe_dross * 10,2);

            table.lblCalDross = lblCalDross0.ToString();

            //for al

            var lblAlReqConvrtBottomDross0 = String.Format("{0:0.000}", al_dross);
            table.lblAlReqConvrtBottomDross = lblAlReqConvrtBottomDross0.ToString();


            Double FeSolubility = Convert.ToDouble(table.lblAlReqFeSolubility);
            Double AL_DROSS = Convert.ToDouble(al_dross);
            Double RaiseLevel = Convert.ToDouble(table.lblAlReqToRaiseAlLevel);

               double totalAlCharged = Math.Round(FeSolubility + AL_DROSS + RaiseLevel);
            table.lblTotalAlCharged = totalAlCharged.ToString();

            double recoveryloss = Math.Round(totalAlCharged * 10 / (double)100);
            table.lblRecoveryLossError = recoveryloss.ToString();

            double blockcharge = Math.Round((totalAlCharged + recoveryloss)) * 100 / (double)5 / (double)100;
            blockcharge = Math.Round(blockcharge);
            table.lblMinAlBlocksCharged =blockcharge.ToString();
            













            //  decimal sumtotal1 = Math.Round(sumtotal0);
            // table.lblGAWeight = sumtotal1.ToString();
            // decimal[] al = new decimal[dt6.Length] ;
            //  decimal[] fe = new decimal[dt6.Length] ;




            //int[] arr = new int[] { 1, 2, 3 };
            //int sum = 0;
            //for (int i = 0; i < arr.Length; i++)
            //{
            //    sum += arr[i];
            //}
            //  decimal sumtotal1 = Math.Round(sumtotal0);
            // table.lblGAWeight = sumtotal1.ToString();




        }
        public void CalGANoOfDays(string dst, string det)
        {


            // lblNoOfDaysGACampaign = objcontroller.CalGANoOfDays(dst, det);
            // var totalAlCharged = Math.Round((FeSolubility + sum_al1 + RaiseLevel));
            // var table.lblAlReqFeSolubility* sum_al*table.lblAlReqToRaiseAlLevel

            string s1 = $@"SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END  FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END BETWEEN '{dst}' AND '{det}' order by PRM_TS_END desc";
            dbPtgMenu.Database.CommandTimeout = 300;
            var dt1 = dbPtgMenu.Database.SqlQuery<dtt2>(s1).ToArray();
            DateTime EndDate = dt1[0].PRM_TS_END;
            int cnt = 4;
            DateTime AEndDate = EndDate;
            DateTime ZCampDate;



            while (true)
            {
                string s2 = $@"SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='Z' and PRM_TS_END <='{AEndDate}' order by PRM_TS_END desc";
                dbPtgMenu.Database.CommandTimeout = 300;
                var dt2 = dbPtgMenu.Database.SqlQuery<dtt2>(s2).ToArray();
                ZCampDate = dt2[0].PRM_TS_END;

                string s3 = $@"SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM[FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where[PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END <='{ZCampDate}' order by PRM_TS_END desc";
                dbPtgMenu.Database.CommandTimeout = 300;
                var dt3 = dbPtgMenu.Database.SqlQuery<dtt2>(s3).ToArray();
                DateTime ACampDate = dt3[0].PRM_TS_END;

                string s4 = $@"SELECT count(*)  as Count FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_TS_END] > '{ACampDate}' and PRM_TS_END <='{ ZCampDate}'";
                dbPtgMenu.Database.CommandTimeout = 300;
                var dt4 = dbPtgMenu.Database.SqlQuery<dtt2>(s4).ToArray();
                cnt = dt4[0].count;



                if (cnt < 7)
                {
                    AEndDate = ACampDate;
                }
                else
                {
                    break;
                }
            }

                string s5 = $@"SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END >='{ZCampDate}' order by PRM_TS_END ";
                dbPtgMenu.Database.CommandTimeout = 300;
                var dt5 = dbPtgMenu.Database.SqlQuery<dtt2>(s5).ToArray();
                DateTime StartDate = dt5[0].PRM_TS_END;


                TimeSpan timeDifference = EndDate - StartDate;
                int days = Math.Abs(timeDifference.Days) + 1;
                // string NoOfDays = DateTime.DateDiff(DateInterval.Day, StartDate, EndDate).ToString() + 1;
                string NoOfDays = days.ToString();
                table.lblNoOfDaysGACampaign = NoOfDays;

            
        }

        public void CalGAStartEndDate(string dst, string det)
        {


            string s1 = $@"SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END  FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END BETWEEN '{dst}' AND '{det}' order by PRM_TS_END desc";
            dbPtgMenu.Database.CommandTimeout = 300;
            var dt1 = dbPtgMenu.Database.SqlQuery<dtt2>(s1).ToArray();
            DateTime EndDate = dt1[0].PRM_TS_END;
            int cnt = 4;
            DateTime AEndDate = EndDate;
            DateTime ZCampDate;


            while (true)
            {
                string s2 = $@"SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='Z' and PRM_TS_END <='{AEndDate}' order by PRM_TS_END desc";
                dbPtgMenu.Database.CommandTimeout = 300;
                var dt2 = dbPtgMenu.Database.SqlQuery<dtt2>(s2).ToArray();
                ZCampDate = dt2[0].PRM_TS_END;

                string s3 = $@"SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END <='{ZCampDate}' order by PRM_TS_END desc";
                dbPtgMenu.Database.CommandTimeout = 300;
                var dt3 = dbPtgMenu.Database.SqlQuery<dtt2>(s3).ToArray();
                DateTime ACampDate = dt3[0].PRM_TS_END;

                string s4 = $@"SELECT count(*) as count FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_TS_END] >'{ACampDate}' and PRM_TS_END <='{ZCampDate}'";
                dbPtgMenu.Database.CommandTimeout = 300;
                var dt4 = dbPtgMenu.Database.SqlQuery<dtt2>(s4).ToArray();
                cnt = dt4[0].count;


                if (cnt < 7)
                {
                    AEndDate = ACampDate;

                }
                else
                {
                    break;
                }
            }
            string s5 = $@"SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END >='{ZCampDate}' order by PRM_TS_END ";
            dbPtgMenu.Database.CommandTimeout = 300;
            var dt5 = dbPtgMenu.Database.SqlQuery<dtt2>(s5).ToArray();
            DateTime StartDate = dt5[0].PRM_TS_END;

             table.lblStart = StartDate.ToString("dd-MM-yyyy HH:mm:ss");
            table.lblEnd = EndDate.ToString("dd-MM-yyyy HH:mm:ss");
          


        }
        public double CalPreviousDross(string dst, string det)
        {

            string s1 = $@"SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END  FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END BETWEEN '{dst}' AND '{det}' order by PRM_TS_END desc";
            dbPtgMenu.Database.CommandTimeout = 300;
            var dt1 = dbPtgMenu.Database.SqlQuery<dtt2>(s1).ToArray();
            DateTime EndDate = dt1[0].PRM_TS_END;

            int cnt = 4;
            DateTime AEndDate = EndDate;
            DateTime ZCampDate;


            while (true)
            {
                string s2 = $@"SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='Z' and PRM_TS_END <='{AEndDate}' order by PRM_TS_END desc";
                dbPtgMenu.Database.CommandTimeout = 300;
                var dt2 = dbPtgMenu.Database.SqlQuery<dtt2>(s2).ToArray();
                ZCampDate = dt2[0].PRM_TS_END;

                string s3 = $@"SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM[FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where[PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END <='{ZCampDate}' order by PRM_TS_END desc";
                dbPtgMenu.Database.CommandTimeout = 300;
                var dt3 = dbPtgMenu.Database.SqlQuery<dtt2>(s3).ToArray();
                DateTime ACampDate = dt3[0].PRM_TS_END;

                string s4 = $@"SELECT count(*)  as Count FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_TS_END] > '{ ACampDate} ' and PRM_TS_END <='{ZCampDate}'";
                dbPtgMenu.Database.CommandTimeout = 300;
                var dt4 = dbPtgMenu.Database.SqlQuery<dtt2>(s4).ToArray();
                cnt = dt4[0].count;


                if (cnt < 7)
                {
                    AEndDate = ACampDate;

                }
                else
                {
                    break;
                }

            }
            string s5 = $@"SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END >='{ZCampDate}' order by PRM_TS_END ";
            dbPtgMenu.Database.CommandTimeout = 300;
            var dt5 = dbPtgMenu.Database.SqlQuery<dtt3>(s5).ToArray();
            DateTime StartDate = dt5[0].PRM_TS_END;

            string s6 = $@"select top 1 RESET_DATE_TIME from [FP_PROCESS_DATA].[dbo].[CGL_FUR_PARAM_RESET_DATETIME] where RESET_DATE_TIME <= '{StartDate}' order by RESET_DATE_TIME desc";
            dbPtgMenu.Database.CommandTimeout = 300;
            var dt6 = dbPtgMenu.Database.SqlQuery<dtt3>(s6).ToArray();

            if (dt6.Count() == 0)
            {
                return 0.0;// DtPreviousResetDate = 0.0;//return 0.00;
            }

            DateTime DtPreviousResetDate = dt6[0].RESET_DATE_TIME;

             
           




            string s7 = $@"SELECT SUM(CFD_STRIP_FE_KG_DISSOLVED) Fe,SUM(CFD_AL_REQ_FOR_DISSOLVED_FE) Al FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] INNER JOIN  [FP_PROCESS_DATA].[dbo].[CGL2_FE_DISSOLUTION] ON T_CGL_FUR_PARAM.PRM_MESSAGE_ID=CGL2_FE_DISSOLUTION.CFD_MESSAGE_ID  where T_CGL_FUR_PARAM.PRM_TS_END BETWEEN '{DtPreviousResetDate}' AND '{StartDate}' group by convert(date,T_CGL_FUR_PARAM.PRM_TS_END)";
            dbPtgMenu.Database.CommandTimeout = 300;
            var dt7 = dbPtgMenu.Database.SqlQuery<dtt3>(s7).ToArray();


            var Fe = dt7.Select(e => e.Fe).ToArray();

            var Fe_dross = Fe.Sum();

            double DoublePreviousDross = Convert.ToDouble(Fe_dross);
            return DoublePreviousDross;
     
        }
        public void DrawChart(string dst, string det, Double previousdross)
        {


            CalChartData(dst, det);
                decimal[] dt1 = table.dt;


                char c = 'a';
                int stAlphabet = (int)c;


                StringBuilder s = new StringBuilder("<script>");

                s.Append("FeTank = Morris.Area({element:  'chart',data: [{y:'0',");
                s.Append(((char)stAlphabet) + "0:null");
                for (int row = 0; row < dt1.Count(); row++)
                {
                    s.Append(",");
                    s.Append(((char)(stAlphabet)) + (row + 1).ToString() + ":null");
                }

                int tankHeight = 2200;
                double unitHeight = 100.0 / tankHeight;
                s.Append("},{y:'1',");
                string ykeys = "";
                string labels = "";
                for (int row = 0; row < dt1.Count(); row++)
                {
                    if (row != 0)
                    {
                        s.Append(",");
                        ykeys += ",";
                        labels += ",";
                    }

                   // s.Append("" + Strings.Chr(stAlphabet) + ((row + 1).ToString()) + ":" + dt.Rows(row)(0) * unitHeight);
                    s.Append(((char)(stAlphabet)) + (row + 1).ToString() + ":" + (double)dt1[row] * unitHeight);
                    ykeys += "'" + ((char)(stAlphabet)) + (row + 1).ToString() + "'";
                    labels += "'Day" + (row + 1) + "'";
                }
                s.Append("},{y:'2'");
                for (int row = 0; row < dt1.Count(); row++)
                {
                    s.Append(",");
                    s.Append(((char)(stAlphabet)) + (row + 1).ToString() + ":null");
                }
                s.Append("}],xkey:   'y', padding: 0,ykeys: [");
                s.Append(ykeys);
                s.Append("],labels: [");
                s.Append(labels);
                s.Append("],ymin: 0,ymax: 100,axes: false,hideHover: true,grid:false,resize: true,pointSize:0,lineColors: colors});");
                if (dt1.Count() > 10)
                {
                    s.Append("</script>");
                }
                else
                {
                    s.Append("prepareLegendFe();</script>");
                }
                table.litChart = s.ToString();

            s.Clear();
            s.Append("<script> Morris.Bar({element:  'chart1',gridTextSize:12, gridTextWeight:'bold',gridTextColor:'#000',data: [");
            double cummulative = previousdross;
            decimal[] dt2 = table.dt1;

            
           
            for (int row = 0; row < dt2.Count(); row++)
            {
                if (row > 0)
                {
                    s.Append(",");
                }
                cummulative += Math.Round(Convert.ToDouble(dt2[row]), 3);
                s.Append($"{{x:\"Day{row + 1}\",y:{cummulative}}}");
            }

          
  
          

            //s.Append(",");

            //cummulative += Math.Round(dt1.Rows(row)(0), 3);
            //s.Append("{x:'Day" + (row + 1) + "',y:" + cummulative + "}");


            s.Append("],xkey: 'x', ykeys: ['y'],labels: ['y'],barRatio: 0.4,barColors:function(row,series,type){if (row.label=='Prev') return '#696969'; else return '#0b62a4';},xLabelAngle: 35,hideHover:  'auto'});</script>");
            table.litChart1 = s.ToString();

        }


    


        public void CalChartData(string StDt, string EndDt)
        {
            string s1 = $@"SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END  FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END BETWEEN '{StDt}' AND '{EndDt}' order by PRM_TS_END desc";
            dbPtgMenu.Database.CommandTimeout = 300;
            var dt1 = dbPtgMenu.Database.SqlQuery<dtt2>(s1).ToArray();
            DateTime EndDate = dt1[0].PRM_TS_END;

            int cnt = 4;
            DateTime AEndDate = EndDate;
            DateTime ZCampDate;

            while (true)
            {

                string s2 = $@"SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='Z' and PRM_TS_END <=' { AEndDate} ' order by PRM_TS_END desc";
                dbPtgMenu.Database.CommandTimeout = 300;
                var dt2 = dbPtgMenu.Database.SqlQuery<dtt3>(s2).ToArray();
                ZCampDate = dt2[0].PRM_TS_END;


                string s3 = $@"SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END <='{ ZCampDate} ' order by PRM_TS_END desc";
                dbPtgMenu.Database.CommandTimeout = 300;
                var dt3 = dbPtgMenu.Database.SqlQuery<dtt3>(s3).ToArray();
                DateTime ACampDate = dt3[0].PRM_TS_END;

                string s4 = $@"SELECT count(*) as count FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_TS_END] > '{ ACampDate} ' and PRM_TS_END <='{ ZCampDate}'";
                dbPtgMenu.Database.CommandTimeout = 300;
                var dt4 = dbPtgMenu.Database.SqlQuery<dtt3>(s4).ToArray();
                cnt = dt4[0].count;


                if (cnt < 7)
                {
                    AEndDate = ACampDate;

                }
                else
                {
                    break;
                }


            }

            string s5 = $@"SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END >='{ ZCampDate}' order by PRM_TS_END";
            dbPtgMenu.Database.CommandTimeout = 300;
            var dt5 = dbPtgMenu.Database.SqlQuery<dtt3>(s5).ToArray();
            DateTime StartDate = dt5[0].PRM_TS_END;

            string s6 = $@"select (sum(CFD_STRIP_FE_KG_DISSOLVED)*10*1000*10*20 / (3.6*2.5*10000*7.1)) as ds FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] INNER JOIN [FP_PROCESS_DATA].[dbo].[CGL2_FE_DISSOLUTION] ON T_CGL_FUR_PARAM.PRM_MESSAGE_ID=CGL2_FE_DISSOLUTION.CFD_MESSAGE_ID  where T_CGL_FUR_PARAM.PRM_TS_END BETWEEN '{ StartDate}' AND '{ EndDate}' group by convert(date,T_CGL_FUR_PARAM.PRM_TS_END)";
            dbPtgMenu.Database.CommandTimeout = 300;
            var dt6 = dbPtgMenu.Database.SqlQuery<dtt3>(s6).ToArray();

            //var Fe = dt6.Select(e => e.ds).ToArray();
            decimal[] ds1 = new decimal[dt6.Length];
            for (int j = 0; j < dt6.Length; j++)
            {
                ds1[j] = dt6[j].ds;
            }
            //decimal[] ds1 = new decimal[dt6.Length];
            //for (int i=0;i<Fe.Length; i++)
            //{
                
            //    ds1[i]= Convert.ToDecimal(Fe[i]);


            //}
           

            //decimal d1 = dt6[0].ds;
            //decimal d2= dt6[1].ds;

            //decimal[] ds1 = new decimal[2];
            //ds1[0]= d1;
            //ds1[1] = d1;

            table.dt = ds1;
           // var a = table.ds;
            string s7= $@"select (sum(CFD_STRIP_FE_KG_DISSOLVED)*10) as dt  FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] INNER JOIN [FP_PROCESS_DATA].[dbo].[CGL2_FE_DISSOLUTION] ON T_CGL_FUR_PARAM.PRM_MESSAGE_ID=CGL2_FE_DISSOLUTION.CFD_MESSAGE_ID  where T_CGL_FUR_PARAM.PRM_TS_END BETWEEN '{StartDate}' AND '{EndDate}' group by convert(date,T_CGL_FUR_PARAM.PRM_TS_END)";
             dbPtgMenu.Database.CommandTimeout = 300;
            var dt7 = dbPtgMenu.Database.SqlQuery<dtt3>(s7).ToArray();

            var total_dt_count = dt7.Select(e => e.dt).ToArray();

            decimal[] dt_t2 = new decimal[total_dt_count.Length];
            for (int i = 0; i < total_dt_count.Length; i++)
            {

                dt_t2[i] = Convert.ToDecimal(total_dt_count[i]);


            }
            //decimal d3 = dt7[0].ds;
            //decimal d4 = dt7[1].ds;

            //decimal[] ds2 = new decimal[2];
            //ds1[0] = d1;
            //ds1[1] = d1;

            table.dt1 = dt_t2;
        }




    }
}




