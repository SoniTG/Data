﻿using PTG_TSJ_Main.BussinessLogic.SIDE_MENU;
using PTG_TSJ_Main.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PTG_TSJ_Main.BussinessLogic.PAGE_HITS
{
    
    public class PageHitsFunction
    {
        //SIDE_MENU_DATA DB_SIDE_Menu_DATA = new SIDE_MENU_DATA();
        PTG_WEBSITEEntities DB_SIDE_Menu_DATA = new PTG_WEBSITEEntities();
        public int FunctionForPageHits(String PageName,String Yes_No)
        {
            int Count = 0;
            if (Yes_No == "Yes")
            {
                Page_hits HitsData = new Page_hits();
                 Count = HitsData.GetPageHits(PageName);
                
            }
            if (Yes_No == "No")
            {
                string q2 = $@"select TIMESTAMP from [FP_PROCESS_DATA].[dbo].PAGE_HIT_DTLS where PAGE_NAME= '" + PageName + "'";
                var dt2 = DB_SIDE_Menu_DATA.Database.SqlQuery<PageHitsData>(q2).ToArray();
                 Count = dt2.Count();
            }
            return Count;
           
        }
        public string PageNameFunction(string PageName)
        {
            PTG_WEBSITEEntities1 DB_SIDE_Menu_DATA = new PTG_WEBSITEEntities1();
            string allPageConfigration = "";
            try
            {
                var SplitPageName = PageName.Split('/');
                var data111 = SplitPageName[1];
                var data222 = SplitPageName[0];
                var dt1 = (from x in DB_SIDE_Menu_DATA.Side_Menu.Where(e => e.SIDE_SUB_CONTROLLER == data222 && e.SIDE_MAIN_URL == data111)
                           select new { x.SIDE_MAIN_MENU, x.SIDE_SUB_MENU, x.SIDE_MAIN_URL, x.SIDE_SUB_CONTROLLER }).Distinct().ToList();
                allPageConfigration = $@"ShowName@{dt1[0].SIDE_MAIN_MENU}/{dt1[0].SIDE_SUB_MENU}$ActionName@{dt1[0].SIDE_MAIN_URL}$ControllerName@{dt1[0].SIDE_SUB_CONTROLLER}";
            }
            catch
            {
                allPageConfigration = "";
            }
            return allPageConfigration;


        }

    }
}