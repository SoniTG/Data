﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;

namespace PTG_TSJ_Main.BussinessLogic.PAGE_HITS
{
    public class Page_hits
    {
        PTG_WEBSITEEntities DB_SIDE_Menu_DATA = new PTG_WEBSITEEntities();
        public int GetPageHits(String PageName)
        {

            int count = 0;
            string REFDATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");

            

           
            
            bool Records=CheckRecordsIn("[FP_PROCESS_DATA].[dbo].PAGE_HIT_DTLS", "PAGE_NAME", "TIMESTAMP='" + REFDATE + "' and PAGE_NAME='" + PageName + "'");
            if (!Records)
            {
                string q1 = $@"insert into [FP_PROCESS_DATA].[dbo].PAGE_HIT_DTLS values('" + PageName + "','" + REFDATE + "',NULL)";
                DB_SIDE_Menu_DATA.Database.ExecuteSqlCommand(q1);
            }
            
            string q2 = $@"select TIMESTAMP from [FP_PROCESS_DATA].[dbo].PAGE_HIT_DTLS where PAGE_NAME= '" + PageName + "'";
            var dt2 = DB_SIDE_Menu_DATA.Database.SqlQuery<PageHitsData>(q2).ToArray();

            count = dt2.Count();
            return count;
            
                
               
            }
        public bool CheckRecordsIn(string TableName, string CountOnColumn, string Condition)
        {
            bool val = false;
            try
            {
                string query = "SELECT COUNT(" + CountOnColumn + ") as Count  FROM " + TableName + " WHERE " + Condition;
                var dt = DB_SIDE_Menu_DATA.Database.SqlQuery<PageHitsData>(query).ToArray();
                if (dt[0].Count > 0)
                {
                    val = true;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            return val;
        }




    }
}
