﻿using PTG_TSJ_Main.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PTG_TSJ_Main.BussinessLogic.PLTCM
{
    public class Anamoly
    {
        PTG_WEBSITEEntities dbPtgMenu = new PTG_WEBSITEEntities();

        public List<AnamolyModel> GetColorForStands()
        {
            string q = $@"select top 5 FILESTARTTIME as DATADATETIME,STANDNO,TOP_ROLL_HEALTH,BOT_ROLL_HEALTH from [FP_CRM_EQUIP_MAINTENANCE].[dbo].[PLTCM_BUR_HEALTH]  order by 1 desc, 2 asc";
            var dt = dbPtgMenu.Database.SqlQuery<AnamolyModel>(q).ToList();
            return dt;
        }
        
        public string GetChartData(AnamolyInputModel im)
        {
            System.Text.StringBuilder chartdata = new System.Text.StringBuilder("");
            if (im.fromdt == null || im.fromdt == "")
            {
                im.fromdt = DateTime.Now.AddHours(-8).ToString("yyyy-MM-dd HH:mm:ss");
                im.todt = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            }
            
            try
            {
                chartdata.Append("<script>let names=['','','BOTTOM BUR','','TOP BUR', '','',''];");
                for (int i = 1; i <= 5; i++)
                {
                    string q = $@"select DATADATETIME,STANDNO,TOP_ROLL_HEALTH,BOT_ROLL_HEALTH from [FP_CRM_EQUIP_MAINTENANCE].[dbo].[PLTCM_BUR_HEALTH] where DATADATETIME between '{im.fromdt}' and '{im.todt}' and standno={i} order by 1";
                    var dt = dbPtgMenu.Database.SqlQuery<AnamolyModel>(q).ToList();

                    string xdata = "";
                    string seriesR = "", seriesO = "", seriesY = "", seriesG = "";
                    foreach (var row in dt)
                    {
                        xdata += ",'" + row.DATADATETIME.ToString("yyyy-MM-dd HH:mm") + "'";
                        if (row.TOP_ROLL_HEALTH == "Red")
                        {
                            seriesR += ",['" + row.DATADATETIME.ToString("yyyy-MM-dd HH:mm") + "', 5]";
                        }
                        else if (row.TOP_ROLL_HEALTH == "Orange")
                        {
                            seriesO += ",['" + row.DATADATETIME.ToString("yyyy-MM-dd HH:mm") + "', 5]";
                        }
                        else if (row.TOP_ROLL_HEALTH == "Yellow")
                        {
                            seriesY += ",['" + row.DATADATETIME.ToString("yyyy-MM-dd HH:mm") + "', 5]";
                        }
                        else if (row.TOP_ROLL_HEALTH == "Green")
                        {
                            seriesG += ",['" + row.DATADATETIME.ToString("yyyy-MM-dd HH:mm") + "', 5]";
                        }

                        if (row.BOT_ROLL_HEALTH == "Red")
                        {
                            seriesR += ",['" + row.DATADATETIME.ToString("yyyy-MM-dd HH:mm") + "', 3]";
                        }
                        else if (row.BOT_ROLL_HEALTH == "Orange")
                        {
                            seriesO += ",['" + row.DATADATETIME.ToString("yyyy-MM-dd HH:mm") + "', 3]";
                        }
                        else if (row.BOT_ROLL_HEALTH == "Yellow")
                        {
                            seriesY += ",['" + row.DATADATETIME.ToString("yyyy-MM-dd HH:mm") + "', 3]";
                        }
                        else if (row.BOT_ROLL_HEALTH == "Green")
                        {
                            seriesG += ",['" + row.DATADATETIME.ToString("yyyy-MM-dd HH:mm") + "', 3]";
                        }


                    }

                    if (xdata.Length == 0) xdata = ",";
                    if (seriesG.Length == 0) seriesG = ",";
                    if (seriesY.Length == 0) seriesY = ",";
                    if (seriesO.Length == 0) seriesO = ",";
                    if (seriesR.Length == 0) seriesR = ",";

                    chartdata.Append("echarts.init(document.getElementById('chart" + i + "')).setOption({toolbox: { feature: { dataZoom: { yAxisIndex: 'none'}, restore: {},}},grid: {left: 30,right: 30,bottom: 20,top:10,containLabel: true},tooltip:{trigger:'item', formatter:function(params){return '' + params.data[0];}}, xAxis: {");
                    chartdata.Append("    type: 'time',axisLabel:{hideOverlap:true,formatter: '{yyyy}-{MM}-{dd} {HH}:{mm}',color:'black', fontSize:14}, splitLine: {show: true},data: [" + xdata.Substring(1) + "]},");
                    chartdata.Append(" yAxis: {type: 'value',show: true,interval: 1,min: 1,max: 7,axisLabel: {color:'black', fontSize:14,formatter: function (value, index) {return names[index];}}},");
                    chartdata.Append(" series:[{symbolSize: 20,type: 'scatter', itemStyle:{color:'red'},data:[" + seriesR.Substring(1) + "]},");
                    chartdata.Append(" { symbolSize: 20,type: 'scatter', itemStyle:{color:'orange'},data:[" + seriesO.Substring(1) + "]},");
                    chartdata.Append(" {symbolSize: 20,type: 'scatter', itemStyle:{color:'yellow'},data:[" + seriesY.Substring(1) + "]},");
                    chartdata.Append("{ symbolSize: 20,type: 'scatter', itemStyle:{color:'green'},data:[" + seriesG.Substring(1) + "]}]");
                    chartdata.Append("});");
                }
                chartdata.Append("</script>");

            }
            catch (Exception e)
            {
                
            }
            return chartdata.ToString();
        }
    }
}