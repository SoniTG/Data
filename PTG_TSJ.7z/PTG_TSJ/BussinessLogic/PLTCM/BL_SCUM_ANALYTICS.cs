﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;
using System.Web;
using System.Dynamic;

namespace PTG_TSJ_Main.BussinessLogic.PLTCM
{
    public class BL_SCUM_ANALYTICS
    {

        //List<BridgeRollChart> lst1 = new List<BridgeRollChart>();
       
        List<CHART_LP11> lst1 = new List<CHART_LP11>();
        List<FromDateToDate> lst = new List<FromDateToDate>();
        PLTCM_Entity DbContextData = new PLTCM_Entity();
        List<SelectOption> SltOption = new List<SelectOption>();
        DBQuery obj = new DBQuery();
        List<ScumDataColumn> lstBot = new List<ScumDataColumn>();
        List<ScumDataColumn> lstTop = new List<ScumDataColumn>();
        List<ScumDataColumn> lstForAll = new List<ScumDataColumn>();
        internal MultipleData GetDataForBL_SCUM_ANALYTICS(String fromName1, String toName1, String[] GRADE, String[] Defect, String[] TDC, String[] Severity)
        {
           
            var table = new MultipleData();
            DbContextData.Database.CommandTimeout = 180;
            string StringGRADE = "";
            string StringDefect = "";
            string StringTDC = "";
            string StringSeverity = "";
            string StringSeverity1 = "";
            string lowfrom = "0";
            string lowto = "5";
            string midfrom = "6";
            string midto = "10";
            string highval = "11";
           
            if (fromName1 == null && toName1 == null)
            {
                fromName1 = DateTime.Now.AddHours(-8).ToString("yyyy-MM-dd HH:mm:ss");

                toName1 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            }
            

            List<FromDateToDate> lst = new List<FromDateToDate>();

            FromDateToDate c0 = new FromDateToDate()
            {

                FromDate = fromName1,
                ToDate = toName1,
                FromDateName = "fromName1",
                ToDateName = "toName1",
                ID = "",
                todateId = "todateId1",
                FromdateId = "fromdateId2",
                Section = "",
                Heat = "Heat"

            };
            lst.Add(c0);

            if (GRADE!=null)
            {
                StringGRADE=StringBuilder(GRADE);
                StringDefect = StringBuilder( Defect);
                StringTDC = StringBuilder(TDC);
                StringSeverity1 = StringBuilder( Severity);
                StringSeverity = StringSeverity1.Replace("'", "");
                ////////////////////////////////////////////////
                DrawChart( fromName1,toName1, StringGRADE, StringDefect, StringTDC, StringSeverity, lowfrom, lowto, midfrom, midto, highval);
            }
            loadListBox();
            
            table.SelectOption = SltOption;
            table.FromDateToDate = lst;
            table.ChartData = lst1;
            table.ScumDataColumn = lstForAll;
            return table;
        }
        private string StringBuilder(String[] StringBuilder)
        {
            string str1 = "";
            if (StringBuilder.Length > 0)
            {
                for (var i = 0; i < StringBuilder.Length; i++)
                {
                    str1 += ","+"'"+StringBuilder[i] + "'";
                }
                
            }
            return str1.Substring(1);
        }
        private void CombileDataTable(List<ScumDataColumn> ListTop, List<ScumDataColumn> ListBot,String FindScum)
        {
            if (FindScum == "SCUM_C")
            {
                for (var i=0;i<= ListTop.Count()-1; i++)
                {
                    //For Top
                    lstForAll[i].SCUM_C_TOP_1 = ListTop[i].SCUM_C_TOP_1;
                    lstForAll[i].SCUM_C_TOP_2 = ListTop[i].SCUM_C_TOP_2;
                    lstForAll[i].SCUM_C_TOP_3 = ListTop[i].SCUM_C_TOP_3;
                    lstForAll[i].SCUM_C_TOP_4 = ListTop[i].SCUM_C_TOP_4;
                    lstForAll[i].SCUM_C_TOP_5 = ListTop[i].SCUM_C_TOP_5;
                    //For Bot
                    lstForAll[i].SCUM_C_BOTTOM_1 = ListTop[i].SCUM_C_BOTTOM_1;
                    lstForAll[i].SCUM_C_BOTTOM_2 = ListTop[i].SCUM_C_BOTTOM_2;
                    lstForAll[i].SCUM_C_BOTTOM_3 = ListTop[i].SCUM_C_BOTTOM_3;
                    lstForAll[i].SCUM_C_BOTTOM_4 = ListTop[i].SCUM_C_BOTTOM_4;
                    lstForAll[i].SCUM_C_BOTTOM_5 = ListTop[i].SCUM_C_BOTTOM_5;
                    lstForAll[i].TDC = ListTop[i].TDC;
                    lstForAll[i].Width = ListTop[i].Width;
                    lstForAll[i].Date = ListTop[i].Date;
                }
            }
            if (FindScum == "SCUM_D")
            {
                for (var i = 0; i <= ListTop.Count()-1; i++)
                {
                    //For Top
                    lstForAll[i].SCUM_D_TOP_1 = ListTop[i].SCUM_D_TOP_1;
                    lstForAll[i].SCUM_D_TOP_2 = ListTop[i].SCUM_D_TOP_2;
                    lstForAll[i].SCUM_D_TOP_3 = ListTop[i].SCUM_D_TOP_3;
                    lstForAll[i].SCUM_D_TOP_4 = ListTop[i].SCUM_D_TOP_4;
                    lstForAll[i].SCUM_D_TOP_5 = ListTop[i].SCUM_D_TOP_5;
                    //For Bot
                    lstForAll[i].SCUM_D_BOTTOM_1 = ListTop[i].SCUM_D_BOTTOM_1;
                    lstForAll[i].SCUM_D_BOTTOM_2 = ListTop[i].SCUM_D_BOTTOM_2;
                    lstForAll[i].SCUM_D_BOTTOM_3 = ListTop[i].SCUM_D_BOTTOM_3;
                    lstForAll[i].SCUM_D_BOTTOM_4 = ListTop[i].SCUM_D_BOTTOM_4;
                    lstForAll[i].SCUM_D_BOTTOM_5 = ListTop[i].SCUM_D_BOTTOM_5;

                }
            }
            if (FindScum == "SCUM_X")
            {
                for (var i = 0; i <= ListTop.Count()-1; i++)
                {
                    //For Top
                    lstForAll[i].SCUM_X_TOP_1 = ListTop[i].SCUM_X_TOP_1;
                    lstForAll[i].SCUM_X_TOP_2 = ListTop[i].SCUM_X_TOP_2;
                    lstForAll[i].SCUM_X_TOP_3 = ListTop[i].SCUM_X_TOP_3;
                    lstForAll[i].SCUM_X_TOP_4 = ListTop[i].SCUM_X_TOP_4;
                    lstForAll[i].SCUM_X_TOP_5 = ListTop[i].SCUM_X_TOP_5;
                    //For Bot         
                    lstForAll[i].SCUM_X_BOTTOM_1 = ListTop[i].SCUM_X_BOTTOM_1;
                    lstForAll[i].SCUM_X_BOTTOM_2 = ListTop[i].SCUM_X_BOTTOM_2;
                    lstForAll[i].SCUM_X_BOTTOM_3 = ListTop[i].SCUM_X_BOTTOM_3;
                    lstForAll[i].SCUM_X_BOTTOM_4 = ListTop[i].SCUM_X_BOTTOM_4;
                    lstForAll[i].SCUM_X_BOTTOM_5 = ListTop[i].SCUM_X_BOTTOM_5;

                }
            }
        }
        private void StatringData(String[,] StringCoilID)
        {
            string CoilIddata = "";
            int divdatab = StringCoilID.Length / 9;
            for (int k = 0; k <= divdatab - 1; k++)
            {
                CoilIddata += ",'" + StringCoilID[k, 0] + "'";
            }
            //string dtcoilinfo =$@"select CR_COIL_ID as COILID,HR_COIL_ID as [HR COILID],CONCAT(FORMAT(HR_THICKNESS,'0.0#'),' / ',CR_THICKNESS) as [THICKNESS],'' as [ROLLING DATE],CONCAT(FORMAT(HR_WIDTH,'0.#'),' / ',FORMAT(CR_WIDTH,'0.#')) AS [HR_CR_WIDTH],CCL_TDC_ACTL as TDC1,'' as PL_SPEED,'' as P1,'' as P2,'' as Prediction,'' as Remark from [FP_PROCESS_DATA].[dbo].[CRM_HR_CR_RLN] where CR_COIL_ID in ({CoilIddata.Substring(1)}) order by TCM_ROLLING_DT";
            string dtcoilinfo = $@"select CR_COIL_ID as COILID,HR_COIL_ID as HR_COILID,CONCAT(FORMAT(HR_THICKNESS,'0.0#'),' / ',CR_THICKNESS) as [THICKNESS],'' as ROLLING_DATE,CONCAT(FORMAT(HR_WIDTH,'0.#'),' / ',FORMAT(CR_WIDTH,'0.#')) AS HR_CR_WIDTH,CCL_TDC_ACTL as TDC1,'' as PL_SPEED,'' as P1,'' as P2,'' as Prediction,'' as Remark from [FP_PROCESS_DATA].[dbo].[CRM_HR_CR_RLN] where CR_COIL_ID in ({CoilIddata.Substring(1)}) order by TCM_ROLLING_DT";
            var dt = DbContextData.Database.SqlQuery<ScumDataColumn>(dtcoilinfo).ToArray();
            if (dt.Length != 0)
            {

                lstBot = new List<ScumDataColumn>();
                for (int k = 0; k <= dt.Length - 1; k++)
                {
                    ScumDataColumn c0 = new ScumDataColumn()
                    {
                        COILID       =  dt[k].COILID,
                        HR_COILID    =  dt[k].HR_COILID,
                        THICKNESS    =  dt[k].THICKNESS,
                        ROLLING_DATE =  dt[k].ROLLING_DATE,
                        HR_CR_WIDTH  =  dt[k].HR_CR_WIDTH,
                        TDC1         =  dt[k].TDC1,
                        PL_SPEED     =  dt[k].PL_SPEED,
                        P1           =  dt[k].P1,
                        P2           =  dt[k].P2,
                        Prediction   =  dt[k].Prediction,
                        Remark       =  dt[k].Remark,
                       
                    };
                    lstForAll.Add(c0);

                }
            }
        }
        private void DrawChart(String fromName1, String toName1, String StringGRADE,String  StringDefect,String  StringTDC,String  StringSeverity,String lowfrom,String lowto,String  midfrom,String midto,String highval)
        {
            
                string radio_select = "date";
            string[] defarray = StringDefect.Split(',');
            string [,] dtAll= null;
            


            for (var i = 0; i < defarray.Length; i++)
            {
                //str1 += "," + "'" + StringBuilder[i] + "'";------------------ Dim dt As DataTable = objController.
                var dt= GetDataForInspectionByWidth(fromName1, toName1, defarray[i], "B", "", "", "Length1", "PLTCM", "TCM_ROLLING_DT", radio_select, "", StringSeverity, StringGRADE, StringTDC);

                string process_a = null;
                string process_b = null;
                string slab_rev = slab_reversal("PLTCM");
                string[] s = slab_rev.Split(new char[] { ',' });
                var indx= 1;
                // 'BOTTOM_PLOT
                process_a = s[0];
                // 'TOP_PLOT
                process_b = s[1];

                string torb = "";
                var defarray1 = defarray[i].Replace("'", "");
                // 'BOTTOM
              var dtbot =  DrawHeatChartForInsDefByWidth("PLTCM", dt, torb, "1", "5", lowfrom, lowto, midfrom, midto, highval, "Length", process_a, defarray1, StringGRADE, StringTDC,radio_select, indx);
                //   if (Session("torb") is null){
                //Session("torb") = "";
                //Session("torb") += "," + defarray(i).Replace("'", "") + " (" + torb + ")";
                //            }

                int divdata = dtbot.Length / 9;
                var defarray12Add_ = defarray1.Replace(" ", "_");
                //////////////////////////////////////////////////
                if (lstForAll.Count == 0)
                {
                    StatringData(dtbot);
                }
                
               
               var dtTop = DrawHeatChartForInsDefByWidth("PLTCM", dt, torb, "1", "5", lowfrom, lowto, midfrom, midto, highval, "Length", process_b, defarray1, StringGRADE, StringTDC, radio_select, indx);

                var defarray12Add_1 = defarray1.Replace(" ", "_");
                int divdatab = dtTop.Length / 9;
                lstTop = new List<ScumDataColumn>();
                if (defarray12Add_1 == "SCUM_C")
                {
                    for (int k = 0; k <= divdatab-1; k++)
                    {
                        ScumDataColumn c0 = new ScumDataColumn()
                        {
                            SCUM_C_TOP_1 = dtTop[k, 1],
                            SCUM_C_TOP_2 = dtTop[k, 5],
                            SCUM_C_TOP_3 = dtTop[k, 6],
                            SCUM_C_TOP_4 = dtTop[k, 7],
                            SCUM_C_TOP_5 = dtTop[k, 8],

                            SCUM_C_BOTTOM_1 = dtbot[k, 1],
                            SCUM_C_BOTTOM_2 = dtbot[k, 5],
                            SCUM_C_BOTTOM_3 = dtbot[k, 6],
                            SCUM_C_BOTTOM_4 = dtbot[k, 7],
                            SCUM_C_BOTTOM_5 = dtbot[k, 8],
                            TDC = dtTop[k, 2],
                            Width = dtTop[k, 3],
                            Date = dtTop[k, 4],
                        };
                        lstTop.Add(c0);
                    }
                }
                if (defarray12Add_1 == "SCUM_D")
                {
                    for (int k = 0; k <= divdatab-1; k++)
                    {
                        ScumDataColumn c0 = new ScumDataColumn()
                        {
                            SCUM_D_TOP_1 =dtTop[k, 1],
                            SCUM_D_TOP_2 =dtTop[k, 5],
                            SCUM_D_TOP_3 =dtTop[k, 6],
                            SCUM_D_TOP_4 =dtTop[k, 7],
                            SCUM_D_TOP_5 =dtTop[k, 8],
                            SCUM_D_BOTTOM_1 = dtbot[k, 1],
                            SCUM_D_BOTTOM_2 = dtbot[k, 5],
                            SCUM_D_BOTTOM_3 = dtbot[k, 6],
                            SCUM_D_BOTTOM_4 = dtbot[k, 7],
                            SCUM_D_BOTTOM_5 = dtbot[k, 8],
                            TDC = dtTop[k, 2],
                            Width = dtTop[k, 3],
                            Date = dtTop[k, 4],
                        };
                        lstTop.Add(c0);
                    }
                }
                if (defarray12Add_1 == "SCUM_X")
                {
                    for (int k = 0; k <= divdatab-1; k++)
                    {
                        ScumDataColumn c0 = new ScumDataColumn()
                        {
                            SCUM_X_TOP_1 = dtTop[k, 1],
                            SCUM_X_TOP_2 = dtTop[k, 5],
                            SCUM_X_TOP_3 = dtTop[k, 6],
                            SCUM_X_TOP_4 = dtTop[k, 7],
                            SCUM_X_TOP_5 = dtTop[k, 8],
                            SCUM_X_BOTTOM_1 = dtbot[k, 1],
                            SCUM_X_BOTTOM_2 = dtbot[k, 5],
                            SCUM_X_BOTTOM_3 = dtbot[k, 6],
                            SCUM_X_BOTTOM_4 = dtbot[k, 7],
                            SCUM_X_BOTTOM_5 = dtbot[k, 8],
                            TDC = dtTop[k, 2],
                            Width = dtTop[k, 3],
                            Date = dtTop[k, 4],
                        };
                        lstTop.Add(c0);
                    }
                }


                if (lstForAll.Count != 0)
                {
                    CombileDataTable(lstTop, lstBot, defarray12Add_1);
                }
                

               
            }
            string q = $@"select * from openquery(CRM_ORACLE,'Select FHC_ID_HR_COIL1 as HR_COILIID , FHC_ID_COIL as CR_COILID,to_char(FHC_TM_ROL_STR, ''YYYY-MM-DD HH24:MI:SS'') as TCM_Roll_start,fhc_sec1_cr_coil as CR_THICKNESS , FHC_SEC2_CR_COIL as CR_WIDTH,FHC_LN_CR_COIL as CR_LEN,FHC_QLTY_CD as CR_Quality_code ,ROUND(((1 - fhc_sec1_cr_coil / fhc_sec1_hr_coil1) * 100),2)as REDUCTION,fhc_ms_input as INPUT_MASS ,HRP_MIN_SPD_PLT as PLTCM_MIN_SPD, HRP_AVG_SPD_PLT AS PLTCM_AVG_SPD,HRP_MAX_SPD_PLT AS PLTCM_MAX_SP_PLT,HRP_MIN_ELON_TL  as TL_Elongation_Min, HRP_MAX_ELON_TL  as TL_Elongation_Max,HRP_AVG_ELON_TL  as TL_Elongation_Avg,HRC_FRT,HRC_CT,HRC_CROWN,HRC_WEDGE from crmdba.V_FULL_HARD_COILS Join CRMDBA.t_HR_COIL_PROCESS on HRP_ID_PC_USRKEY = FHC_ID_HR_COIL1 LEFT OUTER JOIN V_HR_COIL ON FHC_ID_HR_COIL1=HRC_ID_PC_USRKEY where FHC_TM_ROL_STR between to_date(''" + fromName1 + "'',''YYYY-MM-DD HH24:MI:SS'') and to_date(''" + toName1 + "'',''YYYY-MM-DD HH24:MI:SS'') order by FHC_TM_ROL_STR')";
            string q1 = $@"select * from openquery(CRM_ORACLE,'Select FHC_ID_HR_COIL1 as HR_COILIID , FHC_ID_COIL as CR_COILID,HRP_MIN_SPD_PLT as PLTCM_MIN_SPD, HRP_AVG_SPD_PLT AS PLTCM_AVG_SPD,HRP_MAX_SPD_PLT AS PLTCM_MAX_SP_PLT,HRP_MIN_ELON_TL  as TL_Elongation_Min, HRP_MAX_ELON_TL  as TL_Elongation_Max,HRP_AVG_ELON_TL  as TL_Elongation_Avg,HRC_FRT,HRC_CT,HRC_CROWN,HRC_WEDGE   from crmdba.V_FULL_HARD_COILS Join CRMDBA.t_HR_COIL_PROCESS on HRP_ID_PC_USRKEY = FHC_ID_HR_COIL1 LEFT OUTER JOIN V_HR_COIL ON FHC_ID_HR_COIL1=HRC_ID_PC_USRKEY where FHC_TM_ROL_STR between to_date(''" + fromName1 + "'',''YYYY-MM-DD HH24:MI:SS'') and to_date(''" + toName1 + "'',''YYYY-MM-DD HH24:MI:SS'') order by FHC_TM_ROL_STR')";

            var dtoracle = DbContextData.Database.SqlQuery<SCUM_ANALYTICS_Data>(q1).ToArray();
            for (int k = 0; k <= lstForAll.Count() - 1; k++)
            {
                //dtAll.Rows(i)("ROLLING DATE") = dtAll.Rows(i)("DATE");
                lstForAll[k].ROLLING_DATE = lstForAll[k].Date;
                string q2 = "select CYC_COLOR,FFT_COLOR,isnull([PL_SPEED_020],'') as PL_SPEED_020,isnull([PL_SPEED_2040],'') as PL_SPEED_2040,isnull([PL_SPEED_4060],'') as PL_SPEED_4060 ,isnull([PL_SPEED_6080],'') as PL_SPEED_6080 ,isnull([PL_SPEED_80100],'') as PL_SPEED_80100,goodbad,isnull(remark,'') as remark from [FP_DEFECT_ANALYSIS].[dbo].[T_BR_CURRENT_CYCLICITY] where COIL_ID = '" + lstForAll[k].HR_COILID + "'";
                var dtCyc = DbContextData.Database.SqlQuery<SCUM_ANALYTICS_Data>(q2).ToArray();
                if (dtCyc.Count() > 0)
                {
                    lstForAll[k].P1 = dtCyc[0].CYC_COLOR;
                    lstForAll[k].P2 = dtCyc[0].FFT_COLOR;
                    lstForAll[k].PL_SPEED = dtCyc[0].PL_SPEED_020 + "#" + dtCyc[0].PL_SPEED_2040 + "#" + dtCyc[0].PL_SPEED_4060 + "#" + dtCyc[0].PL_SPEED_6080 + "#" + dtCyc[0].PL_SPEED_80100;
                    lstForAll[k].Prediction = dtCyc[0].goodbad;
                    lstForAll[k].Remark = dtCyc[0].remark;
                }
                //Dim dr() As DataRow = dtFromOrac.Select("CR_COILID='" & (dtAll.Rows(i)("COILID")) & "'");

                var dr1 = dtoracle.Where(e => e.CR_COILID == lstForAll[k].COILID).ToArray();
                if (dr1.Count() > 0)
                {
                    lstForAll[k].PL_SPEED_MIN = dr1[0].PLTCM_MIN_SPD.ToString();
                    lstForAll[k].PL_SPEED_AVG = dr1[0].PLTCM_AVG_SPD.ToString();
                    lstForAll[k].PL_SPEED_MAX = dr1[0].PLTCM_MAX_SP_PLT.ToString();
                    lstForAll[k].TL_ELONG_MIN = dr1[0].TL_Elongation_Min.ToString();
                    lstForAll[k].TL_ELONG_AVG = dr1[0].TL_Elongation_Avg.ToString();
                    lstForAll[k].TL_ELONG_MAX = dr1[0].TL_Elongation_Max.ToString();
                    lstForAll[k].HRC_FRT = dr1[0].HRC_FRT.ToString();
                    lstForAll[k].HRC_CT = dr1[0].HRC_CT.ToString();
                    lstForAll[k].HRC_CROWN = dr1[0].HRC_CROWN.ToString();
                    lstForAll[k].HRC_WEDGE = dr1[0].HRC_WEDGE.ToString();
                }

                string q3 = "select HCL_ACID_T1,HCL_ACID_T2,HCL_ACID_T3,HCL_ACID_T4,IRON_T1,IRON_T2,IRON_T3,IRON_T4 from [FP_IQMS].[dbo].[PLTCM_LAB_DATA_COILWISE] where CR_COIL_ID='" + lstForAll[k].COILID + "'";
                var dtLab = DbContextData.Database.SqlQuery<ScumDataColumn>(q3).ToArray();
                if (dtLab.Count() > 0)
                {
                    lstForAll[k].HCL_ACID_T1 = dtLab[0].HCL_ACID_T1;
                    lstForAll[k].HCL_ACID_T2 = dtLab[0].HCL_ACID_T2;
                    lstForAll[k].HCL_ACID_T3 = dtLab[0].HCL_ACID_T3;
                    lstForAll[k].HCL_ACID_T4 = dtLab[0].HCL_ACID_T4;
                    lstForAll[k].IRON_T1 = dtLab[0].IRON_T1;
                    lstForAll[k].IRON_T2 = dtLab[0].IRON_T2;
                    lstForAll[k].IRON_T3 = dtLab[0].IRON_T3;
                    lstForAll[k].IRON_T4 = dtLab[0].IRON_T4;
                }
            }

        }
        public String[,] DrawHeatChartForInsDefByWidth(string PROCESS_LINE, SCUM_ANALYTICS_Data[] dtdata, String ContainerName, string from_val, string Too, string lowfrom, string lowto, string midfrom, string midto, string high, string tooltip, string title = "", string defectName = "", string grade = "", string tdcno = "", string proc = "date", int indx = 0)
        {
            try {
                //var dtret = new DataTable();
                //dtret.Columns.Add("CoilID", typeof(string));

                //dtret.Columns.Add(defectName.Replace(" ", "#") + "_" + title + "_" + "1", typeof(string));
                //dtret.Columns.Add("TDC", typeof(string));
                //dtret.Columns.Add("Width", typeof(string));
                //dtret.Columns.Add("Date", typeof(string));
                //dtret.Columns.Add(defectName.Replace(" ", "#") + "_" + title + "_" + "2", typeof(string));

                //dtret.Columns.Add(defectName.Replace(" ", "#") + "_" + title + "_" + "3", typeof(string));

                //dtret.Columns.Add(defectName.Replace(" ", "#") + "_" + title + "_" + "4", typeof(string));

                //dtret.Columns.Add(defectName.Replace(" ", "#") + "_" + title + "_" + "5", typeof(string));

                var dt = dtdata.GroupBy(p => p.DATECREATE).Select(e => e.First()).ToArray();

                int I1 = 0;
                int I2 = 0;
                int I3 = 0;
                if (PROCESS_LINE == "PLTCM" | PROCESS_LINE == "SPM")
                {
                    I1 = 1;
                    I2 = 2;
                    I3 = 2;
                }
                else if (PROCESS_LINE == "ECL" | PROCESS_LINE == "BAF")
                {
                    I1 = 2;
                    I2 = 1;
                    I3 = 1;
                }
                else if (PROCESS_LINE == "CGL1" | PROCESS_LINE == "CGL2" | PROCESS_LINE == "HSM")
                {
                    I1 = 1;
                    I2 = 1;
                    I3 = 1;
                }
                else if (PROCESS_LINE == "RCL1" | PROCESS_LINE == "RCL2" | PROCESS_LINE == "RCL3" | PROCESS_LINE == "RCL3")
                {
                    I1 = 1;
                    I2 = 1;
                    I3 = 1;
                }
                //var s = new StringBuilder("<script>");
                SCUM_ANALYTICS_Data[] DataView=new SCUM_ANALYTICS_Data[0];
                
                //DataTable dtDist = dt.DefaultView.ToTable(true, "dateCreate");
                //DataView dv = dt.DefaultView;
                string TorB = title.Substring(0, 1);
                string oTorB = TorB == "T" ? "B" : "T";


                string[,] dtret = new string[dt.Length, 9];
                //int[,] intArray;
                //intArray = new int[3, 3];


                for (var i = 0; i < dt.Length; i++)
                {
                    
                    //int oCount = dt.Select("dateCreate='" + dtDist.Rows(row)(0) + "' and (surface='" + oTorB + "')").Count;
                    var oCount = dtdata.Where(e => e.DATECREATE == dt[i].DATECREATE && e.SURFACE== oTorB).Select(e => e.DATECREATE).ToList().Count();
                    //int Count = dt.Select("dateCreate='" + dtDist.Rows(row)(0) + "' and (surface='" + TorB + "')").Count;
                    var Count = dtdata.Where(e => e.DATECREATE == dt[i].DATECREATE && e.SURFACE == TorB).Select(e => e.DATECREATE).ToList().Count();
                    //string coilId = dt.Select("dateCreate='" + dtDist.Rows(row)(0) + "'")(0)(1);
                    var coilId = dtdata.Where(e => e.DATECREATE == dt[i].DATECREATE).Select(e => e.ALIAS).ToList();
                    string tdc = null; // 'tooltip
                    string width = null; // 'tooltip
                    try
                    {

                        if (PROCESS_LINE != "RCL")
                        {
                            //tdc = dt.Select("dateCreate='" + dtDist.Rows(row)(0) + "'")(0)(11);
                            var fdhghgdh = dt[i].DATECREATE;
                            var tdcdata = dtdata.Where(e => e.DATECREATE == dt[i].DATECREATE).ToList();
                            if(tdcdata.Count() != 0)
                            {
                                tdc = dtdata.Where(e => e.DATECREATE == dt[i].DATECREATE).Select(e => e.TDC_No).ToList()[0].ToString();
                            }

                            //tdc = dt.Where(e => e.DATECREATE == dt[i].DATECREATE && e.SURFACE == TorB).Select(e => e.TDC_No).ToList()[0];

                            var CheckIsnull = dtdata.Where(e => e.DATECREATE == dt[i].DATECREATE).Select(e => e.WIDTH).ToList()[0];
                            //var CheckIsnull = dt.Where(e => e.DATECREATE == dt[i].DATECREATE && e.SURFACE == TorB).Select(e => e.WIDTH).ToList()[0];
                            if (CheckIsnull != null)
                            {
                                width = dtdata.Where(e => e.DATECREATE == dt[i].DATECREATE).Select(e => e.WIDTH).ToList()[0];
                            }
                            else
                            {
                               var qWidth=$@"select Sec2_PDI from [FP_PROCESS_DATA].[dbo].[RCL_JCAP_SURFACE_INSPECTION] where substring(MOTHER_COIL,0,7)=substring('{coilId[0]}',0,7)";
                               var dt1 = DbContextData.Database.SqlQuery<SCUM_ANALYTICS_Data>(qWidth).ToArray();
                                width = dt1[0].Sec2_PDI;
                            }
                        }
                        else
                        {
                            
                            tdc= dtdata.Where(e => e.DATECREATE == dt[i].DATECREATE).Select(e => e.noCloumn).ToList()[0];
                            
                            width = dtdata.Where(e => e.DATECREATE == dt[i].DATECREATE).Select(e => e.TDC_No).ToList()[0];
                        }
                    }

                    catch (Exception ex)
                    {

                    }

                    var date_time = dtdata.Where(e => e.DATECREATE == dt[i].DATECREATE).Select(e => e.DATECREATE).ToList()[0];
                    /*string date_tim = date_time.ToString("yyyy-MM-dd HH:mm:ss");*///;---- important
                    string date_tim = date_time.Value.ToString("yyyy-MM-dd HH:mm:ss");
                    if (PROCESS_LINE == "PLTCM")
                    {
                        string filter_rcl_jcap = dtdata.Where(e => e.DATECREATE == dt[i].DATECREATE).Select(e => e.noCloumn).ToList()[0]; 
                        if (filter_rcl_jcap == "J")
                        {
                            if (TorB == "T")
                            {

                                DataView = dtdata.Where(e => e.DATECREATE == dt[i].DATECREATE && (e.SURFACE=="B" || e.SURFACE==null)).ToArray(); 
                            }
                            else if (TorB == "B")
                            {
                                DataView = dtdata.Where(e => e.DATECREATE == dt[i].DATECREATE && (e.SURFACE == "T" || e.SURFACE == null)).ToArray();
                            }
                        }
                        else
                        {
                            DataView = dtdata.Where(e => e.DATECREATE == dt[i].DATECREATE && (e.SURFACE== TorB || e.SURFACE==null)).ToArray();
                            
                        }
                    }
                    else
                    {
                        DataView = dtdata.Where(e => e.DATECREATE == dt[i].DATECREATE && (e.SURFACE == TorB || e.SURFACE == null)).ToArray();
                    }
                    //var dtmanualchem = new DataTable();
                    //// adding columns into datatable
                    //dtmanualchem.Columns.Add("COIL_ID");
                    //dtmanualchem.Columns.Add("START_WIDTH");
                    //dtmanualchem.Columns.Add("END_WIDTH");
                    //dtmanualchem.Columns.Add("SEV");

                    //string[] dtmanualchem = new string[4];
                    string[,] dtmanualchem = new string[5,4];
                    int VAL_1 = 0;
                    int VAL_2 = 0;
                    int VAL_3 = 0;
                    int VAL_4 = 0;
                    int VAL_5 = 0;
                    int ROW_COUNT = 0;
                    int Filter = 0;
                    for (var j = 0; j < DataView.Length; j++)
                    {

                        // 'SLAB-REVERSAL
                        if (DataView[j].DEFECT_ST_WIDTH!= null)
                        {
                            if (DataView[j].RCL1_DATETIME != null )
                            {
                                Filter = I1;
                            }
                            else if (DataView[j].RCL2_DATETIME != null )
                            {
                                Filter = I2;
                            }
                            else if (DataView[j].RCL3_DATETIME != null )
                            {
                                Filter = I3;
                            }
                            else
                            {
                                Filter = 1;
                            }
                            if (Filter == 1)
                            {
                                for (var LOCAT = Convert.ToInt32(DataView[j].DEFECT_ST_WIDTH); LOCAT <= Convert.ToInt32(DataView[j].DEFECT_END_WIDTH); LOCAT++ )
                                {

                                    if (LOCAT == 1)
                                    {
                                        VAL_1 = VAL_1 + Convert.ToInt32(DataView[j].LENSEVERITY);
                                    }
                                    if (LOCAT == 2)
                                    {
                                        VAL_2 = VAL_2 + Convert.ToInt32(DataView[j].LENSEVERITY);
                                    }
                                    if (LOCAT == 3)
                                    {
                                        VAL_3 = VAL_3 + Convert.ToInt32(DataView[j].LENSEVERITY);
                                    }
                                    if (LOCAT == 4)
                                    {
                                        VAL_4 = VAL_4 + Convert.ToInt32(DataView[j].LENSEVERITY);
                                    }
                                    if (LOCAT == 5)
                                    {
                                        VAL_5 = VAL_5 + Convert.ToInt32(DataView[j].LENSEVERITY);
                                    }
                                }
                            }
                            else if (Filter == 2)
                            {
                                for (var LOCAT = Convert.ToInt32(DataView[j].DEFECT_ST_WIDTH); LOCAT <= Convert.ToInt32(DataView[j].DEFECT_END_WIDTH); LOCAT++)
                                {

                                    if (LOCAT == 1)
                                    {
                                        VAL_5 = VAL_5 + Convert.ToInt32(DataView[j].LENSEVERITY);
                                    }
                                    if (LOCAT == 2)
                                    {
                                        VAL_4 = VAL_4 + Convert.ToInt32(DataView[j].LENSEVERITY);
                                    }
                                    if (LOCAT == 3)
                                    {
                                        VAL_3 = VAL_3 + Convert.ToInt32(DataView[j].LENSEVERITY);
                                    }
                                    if (LOCAT == 4)
                                    {
                                        VAL_2 = VAL_2 + Convert.ToInt32(DataView[j].LENSEVERITY);
                                    }
                                    if (LOCAT == 5)
                                    {
                                        VAL_1 = VAL_1 + Convert.ToInt32(DataView[j].LENSEVERITY);
                                    }

                                }
                            }

                        }
                    }
                    //End Loop
                    for (int I = 1; I <= 5; I++)
                    {

                        //DataRow newrow = dtmanualchem.NewRow();
                        if (width == null)
                        {
                            //dtmanualchem[0] = coilId.ToString();
                            //dtmanualchem[1] = I.ToString();
                            //dtmanualchem[2] = I.ToString();
                            //dtmanualchem[3] = (-1).ToString();
                            dtmanualchem[I-1,0] = coilId.ToString();
                            dtmanualchem[I - 1, 1] = I.ToString();
                            dtmanualchem[I - 1, 2] = I.ToString();
                            dtmanualchem[I - 1, 3] = (-1).ToString();
                        }
                        else
                        {
                            dtmanualchem[I - 1, 0] = coilId[0].ToString(); // dv.Item(0)(1)
                            if (I == 1)
                            {
                                dtmanualchem[I - 1, 1] = I.ToString();
                                dtmanualchem[I - 1, 2] = I.ToString();
                                dtmanualchem[I - 1, 3] = VAL_1.ToString();
                                            
                            }               
                            else if (I == 2)
                            {               
                                dtmanualchem[I - 1, 1] = I.ToString();
                                dtmanualchem[I - 1, 2] = I.ToString();
                                dtmanualchem[I - 1, 3] = VAL_2.ToString();
                                             
                            }                
                            else if (I == 3) 
                            {                
                                dtmanualchem[I - 1, 1] = I.ToString();
                                dtmanualchem[I - 1, 2] = I.ToString();
                                dtmanualchem[I - 1, 3] = VAL_3.ToString();
                                             
                            }                
                            else if (I == 4) 
                            {                
                                dtmanualchem[I - 1, 1] = I.ToString();
                                dtmanualchem[I - 1, 2] = I.ToString();
                                dtmanualchem[I - 1, 3] = VAL_4.ToString();
                                             
                            }                
                            else if (I == 5) 
                            {                
                                dtmanualchem[I - 1, 1] = I.ToString();
                                dtmanualchem[I - 1, 2] = I.ToString();
                                dtmanualchem[I - 1, 3] = VAL_5.ToString();
                              
                            }
                        }
                        //dtmanualchem.Rows.Add(newrow);
                    }
                    //End Loop
                    int count_width = Convert.ToInt32(from_val)- 1;
                    int idx = 5;
                    var loopCount = Convert.ToInt32(Too) - Convert.ToInt32(from_val);
                    //[CoilID,SCUM#C_TOP_1,TDC,Width,Date,SCUM#C_TOP_2,SCUM#C_TOP_3,SCUM#C_TOP_4,SCUM#C_TOP_5]
                    //string[,] dtret = new string[loopCount, 8];
                    for (int k = 0; k <= loopCount; k++)
                    {
                        if (k > 0)
                        {
                            //s.Append(",");
                            
                        }

                        int? Val = null;
                        //Convert.ToInt32(dtmanualchem.Rows(count_width)("SEV"))
                        if (Convert.ToInt32(dtmanualchem[count_width, 3]) >= Convert.ToInt32(high))
                        {
                            Val = 3;
                        }
                        else if (Convert.ToInt32(dtmanualchem[count_width, 3]) >= Convert.ToInt32(midfrom) & Convert.ToInt32(dtmanualchem[count_width, 3]) <= Convert.ToInt32(midto))
                        {
                            Val = 2;
                        }
                        else if (Convert.ToInt32(dtmanualchem[count_width, 3]) == -1)
                        {
                            Val = 4; // Gray Color
                        }
                        else if (Convert.ToInt32(dtmanualchem[count_width, 3]) >= Convert.ToInt32(lowfrom) & Convert.ToInt32(dtmanualchem[count_width, 3]) <= Convert.ToInt32(lowto))
                        {
                            Val = 1;
                        }

                        if (k == 0)
                        {
                            //dtret.Rows.Add(dtmanualchem[i, 0]), Val + "_" + Convert.ToInt32(dtmanualchem[i, 3]), tdc, width, date_tim);
                            //dtret[count_width, 0]= dtmanualchem[i, 0];
                            //dtret[count_width, 1] = Val + "_" + Convert.ToInt32(dtmanualchem[i, 3]);
                            //dtret[count_width, 2] = tdc;
                            //dtret[count_width, 3] = width;
                            //dtret[count_width, 4] = date_tim;
                            dtret[i, 0] = dtmanualchem[count_width, 0];
                            dtret[i, 1] = Val + "_" + Convert.ToInt32(dtmanualchem[count_width, 3]);
                            dtret[i, 2] = tdc;
                            dtret[i, 3] = width;
                            dtret[i, 4] = date_tim;

                        }
                        else
                        {

                            //dtret.Rows(dtret.Rows.Count - 1)(idx) = Val + "_" + Convert.ToInt32(dtmanualchem[i, 3]);
                            dtret[i,idx]= Val + "_" + Convert.ToInt32(dtmanualchem[count_width, 3]);
                            idx += 1;

                        }

                        // s.Append("[" & (row) & "," & (k) & ",'" & Val & "_" & Convert.ToInt32(dtmanualchem.Rows(count_width)("SEV")) & "','" & dtmanualchem.Rows(count_width)("COIL_ID") & "," & "" & tdc & "', '" & date_tim & "','" & width & "']")
                        count_width = count_width + 1;
                    }

                    //dv.RowFilter = "";
                }
                //End ForLoop

                if (PROCESS_LINE == "PLTCM" | PROCESS_LINE == "ECL" | PROCESS_LINE == "BAF")
                {
                    if (title == "TOP")
                    {
                        title = "BOTTOM";
                        ContainerName = "BOTTOM";
                    }
                    else
                    {
                        title = "TOP";
                        ContainerName = "TOP";
                    }
                }
                int pos = Convert.ToInt32(Too) - Convert.ToInt32(from_val) + 1;
                

                    
                //Return dtret;
                return dtret;
                //return dtret;
            }
            catch
            {
                return null;
            }
             
        }

        private SCUM_ANALYTICS_Data[] GetDataForInspectionByWidth(String fromName1, String toName1, String DefectName, String Surface, String fil_from, String fil_to, String process, String time_process, String date_time, String refr = "date", String coilid = null, String StringSeverity = "1,2,3,4,5", String StringGRADE = "", String StringTDC = "")
        {
            string str1 = "";
            

            //string StringSeverity = StringSeverity1.Replace("'", "");
            string tdc_qur = " select distinct(CCL_TDC_ACTL) as String1 from [FP_PROCESS_DATA].[dbo].[RCL_JCAP_SURFACE_INSPECTION] inner join [FP_PROCESS_DATA].[dbo].[CRM_HR_CR_RLN] on Mother_Coil = CR_COIL_ID where tdc_no in (" + StringTDC + ")";

            var dt = DbContextData.Database.SqlQuery<SCUM_ANALYTICS_Data>(tdc_qur).ToArray();
            for (var i = 0; i < dt.Length; i++)
            {
                str1 += "," + "'" + dt[i].String1 + "'";
            };
            string tdc_string = str1.Substring(1);

            string query = "";
            string filter = "";

            if (fil_from.Equals("") & fil_to.Equals(""))
            {
            }
            else
            {
                filter = "and t1.Sec2_PDI between " + fil_from + " and " + fil_to + " ";
            }

            if (time_process != "RCL")
            {

                if (process == "Length")
                {

                   
                    query = $@" With joinedData as (SELECT CR_COIL_ID AS MOTHER_COIL,SURFACE, DEFECT_ST_WIDTH, DEFECT_END_WIDTH,SUM(DEFECT_LENGTH) AS LENSEVERITY,GRADE,TDC_NO, SEVERITY,Defect_Name,CCL_TDC_AIM,substring(Daughter_Coil,0,2) as keyy,Sec2_PDI FROM [FP_PROCESS_DATA].[dbo].[CRM_HR_CR_RLN] LEFT OUTER JOIN [FP_PROCESS_DATA].[dbo].[RCL_JCAP_SURFACE_INSPECTION] ON substring(CR_COIL_ID,0,7)=substring(MOTHER_COIL,0,7)  WHERE {date_time} between '{fromName1}' and '{toName1}' and (Defect_Name is null or Defect_Name in ({DefectName}))  and (severity is null or severity in ({StringSeverity})) and (grade  is null or grade in ({StringGRADE})) and ( tdc_no in ({StringTDC})  )GROUP BY CR_COIL_ID,SURFACE,GRADE,TDC_NO,DEFECT_ST_WIDTH,DEFECT_END_WIDTH,SEVERITY,Defect_Name,CCL_TDC_AIM,substring(Daughter_Coil,0,2),Sec2_PDI) SELECT t.DATECREATE,t.ALIAS,joinedData.SURFACE,joinedData.DEFECT_ST_WIDTH,joinedData.DEFECT_END_WIDTH,joinedData.LENSEVERITY, isnull(t1.MOTHER_COIL,0) as rcl_coil,t.RCL1_DATETIME,t.RCL2_DATETIME,t.RCL3_DATETIME,isnull(t1.keyy,0),t1.TDC_No,t1.Sec2_PDI as width FROM joinedData RIGHT OUTER JOIN (SELECT {date_time} AS DATECREATE,CR_COIL_ID AS ALIAS,RCL1_DATETIME,RCL2_DATETIME,RCL3_DATETIME FROM [FP_PROCESS_DATA].[dbo].[CRM_HR_CR_RLN]  WHERE {date_time} between '{fromName1}' and '{toName1}' and CCL_TDC_ACTL in ({tdc_string})) t left join (SELECT distinct CR_COIL_ID AS MOTHER_COIL,TDC_NO,Sec2_PDI,substring(Daughter_Coil,0,2) as keyy FROM [FP_PROCESS_DATA].[dbo].[CRM_HR_CR_RLN] inner JOIN [FP_PROCESS_DATA].[dbo].[RCL_JCAP_SURFACE_INSPECTION] ON substring(CR_COIL_ID,0,7)=substring(MOTHER_COIL,0,7)  WHERE {date_time} between '{fromName1}' and '{toName1}' and CCL_TDC_ACTL in ({tdc_string}))t1 on substring(t1.MOTHER_COIL,0,7)=substring(ALIAS,0,7) ON substring(joinedData.MOTHER_COIL,0,7)=substring(ALIAS,0,7) where t1.TDC_No is null or t1.TDC_No in ({StringTDC}) {filter}   order by datecreate";
                }
                else
                {
                    query = $@"SELECT TCM_ROLLING_DT AS DATECREATE,CR_COIL_ID AS ALIAS,SURFACE,DEFECT_ST_WIDTH,DEFECT_END_WIDTH,LENSEVERITY, isnull(t1.MOTHER_COIL,0) as rcl_coil,RCL1_DATETIME,RCL2_DATETIME,RCL3_DATETIME,isnull(t1.keyy,0) as noCloumn,CCL_TDC_ACTL as TDC_No,Sec2_PDI as WIDTH,TCM_ROLLING_DT FROM [FP_PROCESS_DATA].[dbo].[CRM_HR_CR_RLN] LEFT OUTER JOIN (SELECT CR_COIL_ID AS MOTHER_COIL,SURFACE, DEFECT_ST_WIDTH, DEFECT_END_WIDTH,SUM(DEFECT_LENGTH) AS LENSEVERITY,GRADE,TDC_NO, SEVERITY,Defect_Name,CCL_TDC_AIM,substring(Daughter_Coil,0,2) as keyy,Sec2_PDI FROM [FP_PROCESS_DATA].[dbo].[CRM_HR_CR_RLN] LEFT OUTER JOIN [FP_PROCESS_DATA].[dbo].[RCL_JCAP_SURFACE_INSPECTION] ON substring(CR_COIL_ID,0,7)=substring(MOTHER_COIL,0,7) WHERE TCM_ROLLING_DT between '{fromName1}' and '{toName1}' and (Defect_Name is null or Defect_Name in ({DefectName})) and (severity is null or severity in ({StringSeverity}) and (grade is null or grade in ({StringGRADE}))) GROUP BY CR_COIL_ID,SURFACE,GRADE,TDC_NO,DEFECT_ST_WIDTH,DEFECT_END_WIDTH,SEVERITY,Defect_Name,CCL_TDC_AIM,substring(Daughter_Coil,0,2),Sec2_PDI) t1 ON substring(t1.MOTHER_COIL,0,7)=substring(CR_COIL_ID,0,7) WHERE TCM_ROLLING_DT between '{fromName1}' and '{toName1}' and (CCL_TDC_ACTL is null or CCL_TDC_ACTL in ({StringTDC})) order by TCM_ROLLING_DT ";
                   
                }
            }

            if (time_process == "RCL")
            {
                if (fil_from.Equals("") & fil_to.Equals(""))
                {
                }
                else
                {
                    filter = "and Sec2_PDI between " + fil_from + " and " + fil_to + " ";
                }
                string str = "Date_Create";
                if (fil_from.Equals("") & fil_to.Equals(""))
                {
                }
                else
                {
                    filter = " and Sec2_PDI between " + fil_from + " and " + fil_to + " ";
                }
                if (process == "Length")
                {
                    
                    query = $@" select t.dateCreate,t.Mother_Coil,surface,isnull(Defect_St_Width,0) as Defect_St_Width,isnull(Defect_End_Width,0) as Defect_End_Width,isnull(t1.lenseverity,0) as lenseverity,t1.alias,t.RCL1_DATETIME,t.RCL2_DATETIME,t.RCL3_DATETIME,t.TDC_No,Sec2_PDI as width,width1  from ( select distinct   Date_Create as dateCreate,Mother_Coil,RCL1_DATETIME,RCL2_DATETIME,RCL3_DATETIME,TDC_No,Sec2_PDI,COALESCE(Sec2_PDI,cr_width) as width1  from  [FP_PROCESS_DATA].[dbo].[RCL_JCAP_SURFACE_INSPECTION] INNER JOIN CRM_HR_CR_RLN ON substring(Mother_Coil,0,7) = substring(CR_COIL_ID,0,7)  where   {str} between '{fromName1}' and '{toName1}'  and Defect_Name in ({DefectName}) and severity in ({StringSeverity}) and grade in ({StringGRADE}) and tdc_no in ({StringTDC})      ) T left outer join    (SELECT [Mother_Coil],Sum([Defect_Length]) as lenSeverity,surface,Defect_St_Width,Defect_End_Width,Mother_Coil as alias FROM [FP_PROCESS_DATA].[dbo].[RCL_JCAP_SURFACE_INSPECTION] INNER JOIN CRM_HR_CR_RLN ON substring(Mother_Coil,0,7) = substring(CR_COIL_ID,0,7)   where   {str} between '{fromName1}' and '{toName1}'  and Defect_Name in ({DefectName})  and severity in ({StringSeverity}) and grade in ({StringGRADE}) and tdc_no in ({StringTDC}) {filter}  Group by [Mother_Coil], Defect_St_Width,Defect_End_Width,Surface)  T1   on T.Mother_Coil=T1.Mother_Coil order by dateCreate";
                }
                else
                {
                   
                    query = $@" select t.dateCreate,t.Mother_Coil,surface,isnull(Defect_St_Width,0) as Defect_St_Width,isnull(Defect_End_Width,0) as Defect_End_Width,isnull(t1.lenseverity,0) as lenseverity,t1.alias,t.RCL1_DATETIME,t.RCL2_DATETIME,t.RCL3_DATETIME,t.TDC_No,Sec2_PDI as width,width1  from ( select distinct   Date_Create as dateCreate,Mother_Coil,RCL1_DATETIME,RCL2_DATETIME,RCL3_DATETIME,TDC_No,Sec2_PDI,COALESCE(Sec2_PDI,cr_width) as width1  from [FP_PROCESS_DATA].[dbo].[RCL_JCAP_SURFACE_INSPECTION]  INNER JOIN CRM_HR_CR_RLN ON substring(Mother_Coil,0,7) = substring(CR_COIL_ID,0,7)  where   {str} between '{fromName1}' and '{toName1}'  and Defect_Name in ({DefectName}) and severity in ({StringSeverity}) and grade in ({StringGRADE}) and tdc_no in ({StringTDC})      ) T left outer join    (SELECT [Mother_Coil],count([Mother_Coil]) as lenSeverity,surface,Defect_St_Width,Defect_End_Width,Mother_Coil as alias FROM [FP_PROCESS_DATA].[dbo].[RCL_JCAP_SURFACE_INSPECTION] INNER JOIN CRM_HR_CR_RLN ON substring(Mother_Coil,0,7) = substring(CR_COIL_ID,0,7)    where  {str} between '{fromName1}' and '{toName1}'  and Defect_Name in ({DefectName}) and severity in ({StringSeverity}) and grade in ({StringGRADE}) and tdc_no in ({StringTDC}) {filter} Group by [Mother_Coil], Defect_St_Width,Defect_End_Width,Surface)  T1   on T.Mother_Coil=T1.Mother_Coil order by dateCreate";
                }


            }
            var dt1 = DbContextData.Database.SqlQuery<SCUM_ANALYTICS_Data>(query).ToArray();
            return dt1;
        }
        public string slab_reversal(string process_line)
        {
            string process_a = null;
            try
            {

                // ' Dim process_b As String = Nothing

                if (process_line == "HSM")
                {
                    process_a = "BOTTOM,TOP";
                }
                // 'process_b = "TOP"
                else if (process_line == "PLTCM")
                {
                    process_a = "TOP,BOTTOM";
                }
                // ' process_b = "BOTTOM"
                else if (process_line == "ECL")
                {
                    process_a = "TOP,BOTTOM";
                }
                // ' process_b = "BOTTOM"
                else if (process_line == "SPM")
                {
                    process_a = "BOTTOM,TOP";
                }
                // ' process_b = "TOP"
                else if (process_line == "CGL1")
                {
                    process_a = "BOTTOM,TOP";
                }
                // ' process_b = "TOP"
                else if (process_line == "CGL2")
                {
                    process_a = "BOTTOM,TOP";
                }
                // ' process_b = "TOP"
                else if (process_line == "BAF")
                {
                    process_a = "TOP,BOTTOM";
                }
                // 'process_b = "BOTTOM"
                else if (process_line == "RCL1" | process_line == "RCL2" | process_line == "RCL3" | process_line == "RCL")
                {
                    process_a = "BOTTOM,TOP";
                    // 'process_b = "TOP"

                }
            }

            catch (Exception ex)
            {

            }
            return process_a;
        }

        private void loadListBox()
        {
            //SCUM_ANALYTICS_Data[] sp_tdc = new SCUM_ANALYTICS_Data[] { "CA04", "CA06", "CA08", "CA10", "MU04", "AU12" };
            string[] sp_tdc = { "CA04", "CA06", "CA08", "CA10", "MU04", "AU12" };
            string[] Severity = { "1", "2", "3", "4", "5" };

            string q = $@"SELECT DISTINCT GRADE FROM [FP_PROCESS_DATA].[dbo].[RCL_JCAP_SURFACE_INSPECTION]   ORDER BY GRADE;";
            //var dt = dbWrmDevice_Counter.Database.SqlQuery<SCUM_ANALYTICS_Data>(q).ToArray();
            var dt = obj.RunQuery<SCUM_ANALYTICS_Data>(DbContextData, q);

            string[] ArrayOfdt = new string[dt.Length];
            for (int i = 0; i < dt.Length; i++)
            {
                ArrayOfdt[i] = dt[i].GRADE;
            }

            string q1 = $@"SELECT DISTINCT Defect_Name FROM [FP_PROCESS_DATA].[dbo].[RCL_JCAP_SURFACE_INSPECTION] where  Defect_Name like '%SCUM%' ORDER BY DEFECT_NAME";
            var dt1 = obj.RunQuery<SCUM_ANALYTICS_Data>(DbContextData, q1).ToArray();
            string[] ArrayOfdt1 = new string[dt1.Length];
            for (int i = 0; i < dt1.Length; i++)
            {
                ArrayOfdt1[i] = dt1[i].Defect_Name;
            }

            loadDataListBox(ArrayOfdt, "GRADE");
            loadDataListBox(ArrayOfdt1, "Defect");
            loadDataListBox(sp_tdc, "TDC");
            loadDataListBox(Severity, "Severity");

        }
        private void loadDataListBox(String[] dt, String nameListBox)
        {
            string SectionDataString = "";
            if (dt.Length > 0)
            {
                for (var i = 0; i < dt.Length; i++)
                {
                    SectionDataString += dt[i] + ",";
                }
            }
            if (dt.Length > 0)
            {
                SelectOption cs1 = new SelectOption()
                {
                    SectionData = SectionDataString,
                    ForOptCondition = nameListBox,
                    ForSelected = "Selected",
                };
                SltOption.Add(cs1);
            }
            else
            {
                SelectOption cs1 = new SelectOption()
                {
                    SectionData = "",
                    ForOptCondition = nameListBox,
                };
                SltOption.Add(cs1);
            }

        }

       






    }
}







