﻿using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PTG_TSJ_Main.BussinessLogic.PLTCM
{
    public class BL_pltcm_historical
    {
        PTG_WEBSITEEntities dbPtgMenu = new PTG_WEBSITEEntities();
        List<CHART_LP11> lst1 = new List<CHART_LP11>();
        List<SelectOption> SltOption = new List<SelectOption>();

        internal MultipleData GetDataForBL_pltcm_historical(string fromName1, string toName1, string ddlEncoders)
        {
            //AllContainerChart(fromName1,toName1, catagory, TableName,Count,ContainerName,NameLegend,NameChart);


            if (fromName1 == null && toName1 == null)
            {
                fromName1 = DateTime.Now.AddDays(-7).ToString("yyyy-MM-dd HH:mm:ss");

                toName1 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            }
            List<FromDateToDate> lst = new List<FromDateToDate>();

            FromDateToDate c0 = new FromDateToDate()
            {

                FromDate = fromName1,
                ToDate = toName1,
                FromDateName = "fromName1",
                ToDateName = "toName1",
                ID = "",
                todateId = "todateId1",
                FromdateId = "fromdateId2",
                Section = "",
                Heat = "Heat"

            };
            lst.Add(c0);


            var table = new MultipleData();

            table.FromDateToDate = lst;
            table.ChartData = lst1;
            table.SelectOption = SltOption;

            string q = $@"select pl_alias,pl_sl_no from[FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_PLTCM_LIMITS] where pl_header_name is not null order by pl_sl_no";
            var dt = dbPtgMenu.Database.SqlQuery<historical>(q).ToArray();

            table.hist = dt;

            table.selectedHistEncoder = "All";        //i.e only string

            if (ddlEncoders != null && ddlEncoders != "All")
            {
                table.selectedHistEncoder = ddlEncoders;

                string q1 = $@"select PEM_STARTTIME,PEM_SPD_STDDEV_MAX from [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_PLTCM_ENCODER_MAX]  where PEM_STARTTIME between '" + fromName1 + "' and '" + toName1 + "' order by PEM_STARTTIME";
                dbPtgMenu.Database.CommandTimeout = 300;
                var dt1 = dbPtgMenu.Database.SqlQuery<historicaldata>(q1).ToArray();

                string seriesdata = "";

                foreach (var d in dt1)
                {
                    var data1 = Convert.ToInt16(ddlEncoders);
                    var data = d.PEM_SPD_STDDEV_MAX.Split(new char[] { ',' })[data1 - 1];
                    seriesdata += ",['" + d.PEM_STARTTIME.ToString("yyyy-MM-dd HH:mm:ss") + "'," + d.PEM_SPD_STDDEV_MAX.Split(new char[] { ',' })[Convert.ToInt16(ddlEncoders) - 1] + "]";
                }

                List<CHART_LP11> charts = new List<CHART_LP11>();

                CHART_LP11 chart1 = new CHART_LP11()
                {
                    ID = "c1",
                    Height = 500,
                    divHeight = "300px",
                    divcolsm = "12",
                    TypeX = "time",
                    ShowToolBox = "{type:'line',data:[" + seriesdata.Substring(1) + "]}",
                    Width = "{dd}-{MMM} {HH}:{mm}",
                    MinAxisData = "null",
                    MaxAxisData = "null",
                    yAxisName="Speed  stdDev  (MPM)"



                    // FromDate = "",
                    //        ID = ContainerName,
                    //        Title = NameChart,
                    //        TypeX = "time",
                    //        TypeY = "Vlaue",
                    //        ShowLegend = "true",
                    //        Width = "{yyyy}:{MM}:{dd}",
                    //        ShowToolBox = ChartAll,
                    //        MaxAxisData = Convert.ToString(MaxValueBubble),
                    //        MinAxisData = "0",
                    //        SeriesData = "",
                    //        divcolsm = "6",
                    //        divHeight = "35vh"
                };

                charts.Add(chart1);
                table.ChartData = charts;


            }


            return table;
        }

        //    public void AllContainerChart(string fromName1, string toName1)
        //{

        //    string q = $@"select pl_alias,pl_sl_no from[FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_PLTCM_LIMITS] where pl_header_name is not null order by pl_sl_no";
        //    var dt = dbPtgMenu.Database.SqlQuery<historical>(q).ToArray();


        //    string q1 = $@"select PEM_STARTTIME,PEM_SPD_STDDEV_MAX from [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_PLTCM_ENCODER_MAX]  where PEM_STARTTIME between '" + fromName1 + "' and '" + toName1 + "' order by PEM_STARTTIME";
        //    var dt1 = dbPtgMenu.Database.SqlQuery<historicaldata>(q1).ToArray();


        //    //var pltcm_limits = (from x in obj.CRM_PLTCM_LIMITS select x).ToList();
        //    //var pltcm_encoder = (from x in obj.CRM_PLTCM_ENCODER_MAX select x).Take(800).ToList();



        //    string TotalValue = "";
        //    //if (catagory != "")
        //    //{
        //    //    TotalValue = $@"select sum(cast([COUNT] as int)) AS COUNT FROM[WRM_blt_data].[dbo].[{TableName}] where [COUNT] != 'Dummy' and CATEGORY = '{catagory}' AND[TIMESTAMP] > (select top 1[timestamp] from[WRM_blt_data].[dbo].[{TableName}]  where[COUNT] = '{Count}' and CATEGORY = '{catagory}' order by[timestamp] desc)";
        //    //}
        //    //else
        //    //{
        //    //    TotalValue = $@"select sum(cast([COUNT] as int)) AS COUNT FROM [WRM_blt_data].[dbo].[{TableName}] where [COUNT]!='DUMMY' AND [TIMESTAMP]>(select top 1 [timestamp] from [WRM_blt_data].[dbo].[{TableName}] where [COUNT] = '{Count}' order by [timestamp] desc)";
        //    //}

        //    //var resultTotalValue = dbPtgMenu.Database.SqlQuery<WRM_TROUGHSWITCH2>(TotalValue);
        //    //var TroughVAlue = 0;
        //    //try
        //    //{
        //    //    foreach (WRM_TROUGHSWITCH2 m in resultTotalValue)
        //    //    {
        //    //        TroughVAlue += Convert.ToInt32(m.COUNT);

        //    //    }
        //    //}
        //    //catch (Exception e)
        //    //{

        //    //}

        //    string ChartDataVAlue = "";
        //    //if (catagory != "")
        //    //{
        //    //    ChartDataVAlue = $@" select SUM(cast(COUNT as int)) as Count,CONVERT(VARCHAR,TIMESTAMP, 23) as TIMESTAMP  from [WRM_blt_data].[dbo].[{TableName}] WHERE COUNT<> 'Dummy'   and CATEGORY = '{catagory}'  and CONVERT(VARCHAR,TIMESTAMP, 23)  between'{fromName1}' and '{toName1}'  group by  CONVERT(VARCHAR,TIMESTAMP, 23)  order by TIMESTAMP asc";
        //    //}
        //    //else
        //    //{
        //    //    ChartDataVAlue = $@" select SUM(cast(COUNT as int)) as Count,CONVERT(VARCHAR,TIMESTAMP, 23) as TIMESTAMP  from [WRM_blt_data].[dbo].[{TableName}] WHERE COUNT<> 'Dummy'   and CONVERT(VARCHAR,TIMESTAMP, 23)  between'{fromName1}' and '{toName1}'  group by  CONVERT(VARCHAR,TIMESTAMP, 23)  order by TIMESTAMP asc";
        //    //}

        //    var resultChartDataVAlue = dbPtgMenu.Database.SqlQuery<WRM_TROUGHSWITCH2>(ChartDataVAlue);

        //    string ChartAll = "";
        //    int MaxValueBubble = 0;
        //    ChartAll += "{name:'" + NameLegend + "',type:'bar',data:[";
        //    //ChartBubble += "{name:'TroughSwitch',type:'bar',data:[";
        //    var checkDate = fromName1;
        //    try
        //    {
        //        foreach (WRM_TROUGHSWITCH2 m in resultChartDataVAlue)
        //        {
        //            if (MaxValueBubble < Convert.ToInt32(m.COUNT))
        //            {
        //                MaxValueBubble = Convert.ToInt32(m.COUNT) + 300;
        //            }
        //            ChartAll += "['" + m.TIMESTAMP + "'," + m.COUNT + "],";

        //        }
        //    }
        //    catch (Exception e)
        //    {

        //    }

        //    ChartAll += "]";
        //    ChartAll += " },";
        //    CHART_LP11 c10 = new CHART_LP11()
        //    {
        //        FromDate = "",
        //        ID = ContainerName,
        //        Title = NameChart,
        //        TypeX = "time",
        //        TypeY = "Vlaue",
        //        ShowLegend = "true",
        //        Width = "{yyyy}:{MM}:{dd}",
        //        ShowToolBox = ChartAll,
        //        MaxAxisData = Convert.ToString(MaxValueBubble),
        //        MinAxisData = "0",
        //        SeriesData = "",
        //        divcolsm = "6",
        //        divHeight = "35vh"


        //    };
        //    lst1.Add(c10);


        //}



    }
}
