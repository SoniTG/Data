﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;
using System.Web;



namespace PTG_TSJ_Main.BussinessLogic.PLTCM
{
    public class Bridle_Roll_SlipPage
    {
        DBQuery obj = new DBQuery();
        LP_PROCESS_DATA_v1Device_Counter dbWrmDevice_Counter = new LP_PROCESS_DATA_v1Device_Counter();
        //List<BridgeRollChart> lst1 = new List<BridgeRollChart>();
        List<CHART_LP11> lst1 = new List<CHART_LP11>();
        List<FromDateToDate> lst = new List<FromDateToDate>();
        PLTCM_Entity db_PLTCM_Menu = new PLTCM_Entity();

        string[] HeaderName = { };
        string[] HeaderAlias = { };
        internal MultipleData GetDataForBridle_Roll_SlipPage(String fromName1, String toName1,String SelectValue)
        {
           
            var table = new MultipleData();
            string ToDate1 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            string FromDate1 = DateTime.Now.AddDays(-3).ToString("yyyy-MM-dd HH:mm:ss");
            if(SelectValue== null)
            {
                SelectValue = "Average";
            }

            //Declare DateTime Global And change String To DateTime;
            DateTime frmDate = new DateTime(2023, 06, 14, 11, 21, 59);

            DateTime toDate = new DateTime(2023, 06, 14, 11, 21, 59); ;
            if (fromName1 == null && toName1 == null)
            {
                fromName1 = DateTime.Now.AddDays(-3).ToString("yyyy-MM-dd HH:mm:ss");

                toName1 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                frmDate = DateTime.Parse(fromName1);
                toDate = DateTime.Parse(toName1);

            }
            else
            {
                ToDate1 = toName1;
                FromDate1 = fromName1;
                frmDate = DateTime.Parse(fromName1);

                toDate = DateTime.Parse(toName1);


            }
            string[] SelectionData = { "Average", "BoxPlot" };
            FromDateToDate c0 = new FromDateToDate()
            {

                FromDate = FromDate1,
                ToDate = ToDate1,
                FromDateName = "fromName1",
                ToDateName = "toName1",
                ID = "",
                todateId = "todateId1",
                FromdateId = "fromdateId2",
                Section = SelectValue,
                Heat = "Heat",
                SelectOption = SelectionData,
            };
            lst.Add(c0);

            DrawCharts(fromName1, toName1, SelectValue);


            table.FromDateToDate = lst;
            table.ChartData = lst1;
            return table;
        }

        private void DrawCharts(String fromName1, String toName1, String SelectValue)
        {

            dbWrmDevice_Counter.Database.CommandTimeout = 180;

            FetchHeaderName();

            for (int i = 0; i < HeaderName.Length; i++)
            {
               var Dtdata= PopulatePltcmCylinderData(fromName1, toName1, HeaderName[i]);
              
                BoxPlotForPltcmCylinder(Dtdata, "plot" + (i + 1),i, SelectValue);
                
            }
          


        }
        private void FetchHeaderName()
        {
            string q = "select sq_no,CPAT_VAR_NAME,CPAT_VAR_NAME_ALIAS,isnull(cast(LSL as varchar(50)),'') as LSL,isnull(cast(Multiplier as varchar(50)),'') as Multiplier,isnull(cast(USL as varchar(50)),'') as USL from [FP_PROCESS_DATA].[dbo].[CRM_PLTCM_CRITICAL_PARAMETER_TREND_MASTER]";
            var dt = obj.RunQuery<Bridge_Roll>(dbWrmDevice_Counter, q);
            //var dt = dbWrmDevice_Counter.Database.SqlQuery<Bridge_Roll>(q).ToArray();
            var h = dt.AsEnumerable().Select(f => f.CPAT_VAR_NAME).Distinct().ToArray();
            var h_a = dt.AsEnumerable().Select(f => f.CPAT_VAR_NAME_ALIAS).Distinct().ToArray();

            HeaderName = h;
            HeaderAlias = h_a;
            
        }
        private Bridge_Roll[] PopulatePltcmCylinderData(String fromName1, String toName1, String HeaderName)
        {
            string q = $@"SELECT  CONVERT(VARCHAR,CPAT_START_TIME, 20) as CPAT_START_TIME ,[CPAT_VAR_VAL_BOXPLOT],isnull(cast(Multiplier as varchar(50)),'') as Multiplier,isnull(cast(LSL as varchar(50)),'') as LSL,isnull(cast(USL as varchar(50)),'') as USL   FROM [FP_PROCESS_DATA].[dbo].[CRM_PLTCM_CRITICAL_PARAMETER_TREND] t1 inner join [FP_PROCESS_DATA].[dbo].[CRM_PLTCM_CRITICAL_PARAMETER_TREND_MASTER] t2 on t1.CPAT_VAR_NAME=t2.CPAT_VAR_NAME  where [CPAT_START_TIME] between  '{fromName1}' and '{toName1}'  and t1.CPAT_VAR_NAME='{HeaderName}' order by [CPAT_START_TIME]";

            DBQuery obj = new DBQuery();
            var dt = obj.RunQuery<Bridge_Roll>(dbWrmDevice_Counter, q);

            
            //var dt = dbWrmDevice_Counter.Database.SqlQuery<Bridge_Roll>(q).ToArray();
            var h = dt.AsEnumerable().Select(f => f.CPAT_VAR_NAME).Distinct().ToArray();
            //var h_a = dt.AsEnumerable().Select(f => f.CPAT_VAR_NAME_ALIAS).Distinct().ToArray();
            return dt;


        }
        private void BoxPlotForPltcmCylinder(Bridge_Roll[] dt,String PlotName,int val,String SelectValue)
        {
            
                try
                {
                   
                    string ticks = "[";
                    string line1 = "", line2 = "", line3 = "", line4 = "", line5 = "";
                    line1 += "[";
                    line2 += "[";
                    line3 += "[";
                    line4 += "[";
                    line5 += "[";

                    string multiplier = "", lsl = "", usl = "";
                    if (dt.Length > 0)
                    {
                   
                    multiplier = dt[0].Multiplier.ToString();
                    lsl = dt[0].LSL.ToString();
                    usl = dt[0].USL.ToString();

                   }
                    if (string.IsNullOrEmpty(multiplier))
                        multiplier = 1.ToString();

                double mulfactor = Convert.ToDouble(multiplier);

                for (int i = 0; i <= dt.Length-1; i++)
                {
                    if (dt[i].CPAT_START_TIME.ToString() != "")
                    {

                        try
                        {
                            ticks += "'" + Convert.ToDateTime(dt[i].CPAT_START_TIME).ToString("yyyy-MM-dd HH:mm:ss") + "'";


                            string[] tmpCyl = dt[i].CPAT_VAR_VAL_BOXPLOT.Split(new char[] { ',' });
                            //var temp = dt[i].CPAT_VAR_VAL_BOXPLOT.Split(new char[] { ',' });

                            double lbound = Convert.ToDouble(tmpCyl[0]);
                            double ubound = Convert.ToDouble(tmpCyl[1]);
                            double min_ = Convert.ToDouble(tmpCyl[7]);
                            double max_ =  Convert.ToDouble(tmpCyl[8]);

                            if (min_ >= lbound)
                                lbound = min_;
                            if (max_ <= ubound)
                                ubound = max_;

                            line1 += "[" + lbound * mulfactor + "," + Convert.ToDouble(tmpCyl[4]) * mulfactor + "," + Convert.ToDouble(tmpCyl[3])  * mulfactor + "," + Convert.ToDouble(tmpCyl[5]) * mulfactor + "," + ubound * mulfactor + "]";

                            line2 += (Convert.ToDouble(tmpCyl[4])  * mulfactor).ToString(); // avg
                            line3 += (Convert.ToDouble(tmpCyl[7]) * mulfactor).ToString(); // min
                            line4 += (Convert.ToDouble(tmpCyl[8]) * mulfactor).ToString(); // max
                            line5 += (Convert.ToDouble(tmpCyl[6]) * mulfactor).ToString(); // stdev

                            if (i != 0 | i != dt.Length)
                            {
                                ticks += ",";
                                line1 += ",";
                                line2 += ",";
                                line3 += ",";
                                line4 += ",";
                                line5 += ",";
                            }
                        }



                        catch (Exception ex)
                        {
                            continue;
                        }
                    }

                }
                ticks += "]";
                    line1 += "]";
                    line2 += "]";
                    line3 += "]";
                    line4 += "]";
                    line5 += "]";

                    string minmax = "";
                    if (!string.IsNullOrEmpty(lsl) & !string.IsNullOrEmpty(usl))
                    {
                        minmax = "min:" + lsl + ",max:" + usl;
                    }
                    string markline = "";
                    if (!string.IsNullOrEmpty(lsl) & !string.IsNullOrEmpty(usl))
                    {
                        markline = ",markLine: { data: [{  name: 'lsl',yAxis:" + lsl + ",lineStyle:{type:'solid',color:'red'} },{  name: 'usl',yAxis:" + usl + ",lineStyle:{type:'solid',color:'red'} }]}";
                    }
                
                CHART_LP11 c10 = new CHART_LP11()
                {
                    
                    ID = "s" + val,
                    ticks = ticks,
                    line1 = line1,
                    line2 = line2,
                    line3 = line3,
                    line4 = line4,
                    line5 = line5,
                    markline = markline,
                    Heat= minmax,
                    Title= HeaderAlias[val],
                    Section= SelectValue,
                };
                lst1.Add(c10);
            }
                catch (Exception ex)
                {
                    throw ex;
                }
            



        }




    }
}