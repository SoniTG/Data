﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;
using System.Web;


namespace PTG_TSJ_Main.BussinessLogic.PLTCM
{
    public class CPC
    {
        LP_PROCESS_DATA_v1Device_Counter dbWrmDevice_Counter = new LP_PROCESS_DATA_v1Device_Counter();
        //List<BridgeRollChart> lst1 = new List<BridgeRollChart>();
        List<CHART_LP11> lst1 = new List<CHART_LP11>();
        List<FromDateToDate> lst = new List<FromDateToDate>();
        PLTCM_Entity db_PLTCM_Menu = new PLTCM_Entity();

        internal MultipleData GetDataForCPC(String fromName1, String toName1, String SelectValue)
        {

            var table = new MultipleData();
            string ToDate1 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            string FromDate1 = DateTime.Now.AddDays(-3).ToString("yyyy-MM-dd HH:mm:ss");


            //Declare DateTime Global And change String To DateTime;
            DateTime frmDate = new DateTime(2023, 06, 14, 11, 21, 59);

            DateTime toDate = new DateTime(2023, 06, 14, 11, 21, 59); ;
            if (fromName1 == null && toName1 == null)
            {
                fromName1 = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd HH:mm:ss");

                toName1 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                frmDate = DateTime.Parse(fromName1);
                toDate = DateTime.Parse(toName1);

            }
            else
            {
                ToDate1 = toName1;
                FromDate1 = fromName1;
                frmDate = DateTime.Parse(fromName1);

                toDate = DateTime.Parse(toName1);


            }
            string[] SelectionData = { "Box Plot", "Average", "Std Deviation" };
            if (SelectValue == null)
            {
                SelectValue = "Box Plot";
            }
            FromDateToDate c0 = new FromDateToDate()
            {

                FromDate = FromDate1,
                ToDate = ToDate1,
                FromDateName = "fromName1",
                ToDateName = "toName1",
                ID = "",
                todateId = "todateId1",
                FromdateId = "fromdateId2",
                Section = SelectValue,
                Heat = "Heat",
                SelectOption = SelectionData,

            };
            lst.Add(c0);


            try
            {


                string gggh = "";
                var dt = PopulatePltcmCylinderData(fromName1, toName1, gggh);
                if (dt.Length == 0)
                {
                    try
                    {
                        string q = $@"SELECT top(5) CPCT_START_TIME FROM [TSJ_E_MAINTENANCE].[dbo].[CRM_PLTCM_CPC_TREND] order by CPCT_START_TIME  desc";
                        string lastDatime = dbWrmDevice_Counter.Database.SqlQuery<CPCdata1>(q).ToArray()[0].CPCT_START_TIME.ToString();
                        table.selectedHistEncoder = lastDatime;
                    }
                    catch
                    {

                    }

                }
                var query = dt.Select(e => e.VAR_NAME).Distinct().ToArray();

                var StripData = query.Where(e => e.Contains("STRIP")).ToList();
                var CylData = query.Where(e => e.Contains("CYL")).ToList();
                string stripStr = "";
                string cylStr = "";
                for (int i = 0; i < StripData.Count(); i++)
                {
                    var data1 = Enumerable.Range(0, 100).Where(j => StripData[i].Contains(j.ToString()));
                    foreach (var c in data1)
                    {
                        stripStr += "," + c.ToString();
                    }

                }
                for (int l = 0; l < CylData.Count(); l++)
                {
                    var data1 = Enumerable.Range(0, 100).Where(j => CylData[l].Contains(j.ToString()));

                    foreach (var c in data1)
                    {
                        cylStr += "," + c.ToString();
                    }
                }
                var dataC1 = stripStr.Substring(1).Split(',');
                var dataC2 = stripStr.Substring(1).Split(',');
                //int[] C1 = Array.ConvertAll(data1, int.Parse);
                int min = Math.Min(Array.ConvertAll(dataC1, int.Parse).Min(), Array.ConvertAll(dataC2, int.Parse).Min());
                int max = Math.Max(Array.ConvertAll(dataC1, int.Parse).Max(), Array.ConvertAll(dataC2, int.Parse).Max());

                for (int i = min; i <= max; i++)
                {
                    if (dt.Length > 0)
                    {
                        var Stripdt = dt.Where(e => e.VAR_NAME.Contains(i + "STRIP")).ToArray();
                        var Cyldt = dt.Where(e => e.VAR_NAME.Contains(i + "CYL")).ToArray();
                        BoxPlotForPltcmCylinder(Stripdt, Cyldt, "plot" + (i + 1), i, SelectValue);
                    }

                }


            }



            catch (Exception ex)
            {

            }




            table.FromDateToDate = lst;
            table.ChartData = lst1;
            return table;
        }
        public class CPCdata1
        {
            public string CPCT_FILENAME { get; set; }
            public DateTime CPCT_START_TIME { get; set; }
            public string VAR_NAME { get; set; }
            public string VAR_DEV { get; set; }
            public string Systemname { get; set; }
        }

        private CPCdata1[] PopulatePltcmCylinderData(String fromName1, String toName1, String HeaderName)
        {

            try
            {
                //string q = $@"SELECT CPCT_FILENAME,CPCT_START_TIME ,VAR_NAME,VAR_DEV,Systemname FROM [TSK_E_MAINTENANCE].[dbo].[CRM_PLTCM_CPC_TREND] where  CPCT_START_TIME between '2023-04-01 15:20:40' and '2024-04-02 15:20:41' order by CPCT_START_TIME ";
                string q = $@"SELECT CPCT_FILENAME,CPCT_START_TIME ,VAR_NAME,VAR_DEV,Systemname FROM [TSJ_E_MAINTENANCE].[dbo].[CRM_PLTCM_CPC_TREND] where  CPCT_START_TIME between '{fromName1}' and '{toName1}' order by CPCT_START_TIME ";
                var dt = dbWrmDevice_Counter.Database.SqlQuery<CPCdata1>(q).ToArray();
                return dt;

            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }

        }
        private void BoxPlotForPltcmCylinderEmpty(String LastDAtetime)
        {
            CHART_LP11 c10 = new CHART_LP11()
            {

                line1 = LastDAtetime,
                Section = "DataIsnotAvailable",
            };
            lst1.Add(c10);
        }
        private void BoxPlotForPltcmCylinder(CPCdata1[] Stripdt, CPCdata1[] Cyldt, String PlotName, int val, String SelectValue)
        {
            if (SelectValue == "Box Plot")
            {
                try
                {
                    string ticks = "[";
                    string line1 = "", line2 = "";
                    line1 += "[";
                    line2 += "[";

                    int Max = Math.Max(Stripdt.Length, Cyldt.Length);
                    for (int i = 0; i < Max; i++)
                    {
                        try
                        {
                            if (Stripdt.Length != 0)
                            {
                                if (Stripdt[i].VAR_DEV != "")
                                {
                                    string Sval = Stripdt[i].VAR_DEV;
                                    string[] tmpStrip = Sval.Split(new char[] { ',' });
                                    line2 += "[" + tmpStrip[0] + "," + tmpStrip[4] + "," + tmpStrip[3] + "," + tmpStrip[5] + "," + tmpStrip[1] + "]";
                                    if (i != 0 | i != Stripdt.Length - 1)
                                    {
                                        line2 += ",";
                                    }
                                }
                            }

                            if (Cyldt.Length != 0)
                            {
                                if (Cyldt[i].VAR_DEV != "")
                                {
                                    string cval = Cyldt[i].VAR_DEV;
                                    string[] tmpCyl = cval.Split(new char[] { ',' });
                                    line1 += "[" + tmpCyl[0] + "," + tmpCyl[4] + "," + tmpCyl[3] + "," + tmpCyl[5] + "," + tmpCyl[1] + "]";
                                    if (i != 0 | i != Cyldt.Length - 1)
                                    {
                                        line1 += ",";
                                    }
                                }
                            }
                            if (Stripdt.Length == Cyldt.Length)
                            {
                                ticks += "'" + Cyldt[i].CPCT_START_TIME + "'";
                                if (i != 0 | i != Cyldt.Length - 1)
                                {
                                    ticks += ",";
                                }
                            }
                            else if (Stripdt.Length < Cyldt.Length)
                            {
                                ticks += "'" + Cyldt[i].CPCT_START_TIME + "'";
                                if (i != 0 | i != Cyldt.Length - 1)
                                {
                                    ticks += ",";
                                }
                            }
                            else if (Stripdt.Length > Cyldt.Length)
                            {
                                ticks += "'" + Stripdt[i].CPCT_START_TIME + "'";
                                if (i != 0 | i != Stripdt.Length - 1)
                                {
                                    ticks += ",";
                                }
                            }



                        }
                        catch (Exception ex)
                        {
                            continue;
                        }
                    }
                    ticks += "]";
                    line1 += "]";
                    line2 += "]";

                    CHART_LP11 c10 = new CHART_LP11()
                    {

                        ID = "s" + val,
                        ticks = ticks,
                        line1 = line1,
                        line2 = line2,
                        Title = "CPC " + val + " Cylinder & Strip Trend",
                        Section = SelectValue,
                    };
                    lst1.Add(c10);
                }
                catch (Exception ex)
                {

                }
            }
            if (SelectValue == "Average" | SelectValue == "Std Deviation")
            {

                try
                {
                    string ticks = "[";
                    string line1 = "", line2 = "";
                    line1 += "[";
                    line2 += "[";
                    int Max = Math.Max(Stripdt.Length, Cyldt.Length);
                    for (int i = 0; i < Max; i++)
                    {
                        try
                        {
                            if (Stripdt.Length != 0)
                            {
                                if (Stripdt[i].VAR_DEV != "")
                                {
                                    string Sval = Stripdt[i].VAR_DEV;
                                    string[] tmpStrip = Sval.Split(new char[] { ',' });
                                    if (SelectValue == "Average")
                                    {
                                        line2 += tmpStrip[2];
                                    }
                                    else
                                    {
                                        line2 += tmpStrip[6];
                                    }
                                    if (i != 0 | i != Stripdt.Length - 1)
                                    {
                                        line2 += ",";
                                    }
                                }
                            }

                            if (Cyldt.Length != 0)
                            {
                                if (Cyldt[i].VAR_DEV != "")
                                {
                                    string cval = Cyldt[i].VAR_DEV;
                                    string[] tmpCyl = cval.Split(new char[] { ',' });
                                    if (SelectValue == "Average")
                                    {
                                        line1 += tmpCyl[2];
                                    }
                                    else
                                    {
                                        line1 += tmpCyl[6];
                                    }
                                    if (i != 0 | i != Cyldt.Length - 1)
                                    {
                                        line1 += ",";
                                    }
                                }
                            }
                            if (Stripdt.Length == Cyldt.Length)
                            {
                                ticks += "'" + Cyldt[i].CPCT_START_TIME + "'";
                                if (i != 0 | i != Cyldt.Length - 1)
                                {
                                    ticks += ",";
                                }
                            }
                            else if (Stripdt.Length < Cyldt.Length)
                            {
                                ticks += "'" + Cyldt[i].CPCT_START_TIME + "'";
                                if (i != 0 | i != Cyldt.Length - 1)
                                {
                                    ticks += ",";
                                }
                            }
                            else if (Stripdt.Length > Cyldt.Length)
                            {
                                ticks += "'" + Stripdt[i].CPCT_START_TIME + "'";
                                if (i != 0 | i != Stripdt.Length - 1)
                                {
                                    ticks += ",";
                                }
                            }



                        }
                        catch (Exception ex)
                        {
                            continue;
                        }
                    }

                    ticks += "]";
                    line1 += "]";
                    line2 += "]";
                    CHART_LP11 c10 = new CHART_LP11()
                    {

                        ID = "s" + val,
                        ticks = ticks,
                        line1 = line1,
                        line2 = line2,
                        Title = "CPC " + val + " Cylinder & Strip Trend",
                        Section = SelectValue,
                    };
                    lst1.Add(c10);
                }
                catch (Exception ex)
                {

                }



            }

        }
        //string[] HeaderName = new string[] { "CPC 1 Cylinder & Strip Trend", "CPC 2 Cylinder & Strip Trend", "CPC 3 Cylinder & Strip Trend", "CPC 4 Cylinder & Strip Trend", "CPC 5 Cylinder & Strip Trend", "CPC 6 Cylinder & Strip Trend", "CPC 7 Cylinder & Strip Trend" };
        //internal MultipleData GetDataForCPC(String fromName1, String toName1,String SelectValue)
        //{

        //    var table = new MultipleData();
        //    string ToDate1 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        //    string FromDate1 = DateTime.Now.AddDays(-3).ToString("yyyy-MM-dd HH:mm:ss");


        //    //Declare DateTime Global And change String To DateTime;
        //    DateTime frmDate = new DateTime(2023, 06, 14, 11, 21, 59);

        //    DateTime toDate = new DateTime(2023, 06, 14, 11, 21, 59); ;
        //    if (fromName1 == null && toName1 == null)
        //    {
        //        fromName1 = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd HH:mm:ss");

        //        toName1 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

        //        frmDate = DateTime.Parse(fromName1);
        //        toDate = DateTime.Parse(toName1);

        //    }
        //    else
        //    {
        //        ToDate1 = toName1;
        //        FromDate1 = fromName1;
        //        frmDate = DateTime.Parse(fromName1);

        //        toDate = DateTime.Parse(toName1);


        //    }
        //    string[] SelectionData = { "Box Plot", "Average", "Std Deviation" };
        //    if (SelectValue == null)
        //    {
        //        SelectValue = "Box Plot";
        //    }
        //    FromDateToDate c0 = new FromDateToDate()
        //    {

        //        FromDate = FromDate1,
        //        ToDate = ToDate1,
        //        FromDateName = "fromName1",
        //        ToDateName = "toName1",
        //        ID = "",
        //        todateId = "todateId1",
        //        FromdateId = "fromdateId2",
        //        Section = SelectValue,
        //        Heat = "Heat",
        //        SelectOption = SelectionData,

        //    };
        //    lst.Add(c0);


        //        try
        //        {

        //        //string dtStart = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd HH:mm:ss");
        //        //string dtEnd = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        //            string gggh = "";
        //            var dt = PopulatePltcmCylinderData(fromName1, toName1, gggh);
        //            for (int i = 0; i < HeaderName.Length; i++)
        //            {
        //                if (dt.Length > 0)
        //                {

        //                    BoxPlotForPltcmCylinder(dt, "plot" + (i + 1), i, SelectValue);
        //                }
        //                if (dt.Length == 0)
        //                {

        //                    BoxPlotForPltcmCylinderEmpty( HeaderName[i], i);
        //                }
        //        }


        //            }



        //        catch (Exception ex)
        //        {

        //        }




        //    table.FromDateToDate = lst;
        //    table.ChartData = lst1;
        //    return table;
        //}

        //private CPCdata[] PopulatePltcmCylinderData(String fromName1, String toName1, String HeaderName)
        //{

        //    try
        //    {
        //        string q = $@"select CPCT_START_TIME,CPCT_CPC1_CYL_DEV_5PNTS as Cylinder1,CPCT_CPC2_STRIP_DEV_5PNTS as Strip1,CPCT_CPC2_CYL_DEV_5PNTS as Cylinder2,CPCT_CPC2_STRIP_DEV_5PNTS as Strip2,CPCT_CPC3_CYL_DEV_5PNTS as Cylinder3,CPCT_CPC3_STRIP_DEV_5PNTS as Strip3,CPCT_CPC4_CYL_DEV_5PNTS as Cylinder4,CPCT_CPC4_STRIP_DEV_5PNTS as Strip4, CPCT_CPC5_CYL_DEV_5PNTS as Cylinder5,CPCT_CPC5_STRIP_DEV_5PNTS as Strip5,CPCT_CPC6_CYL_DEV_5PNTS as Cylinder6,CPCT_CPC6_STRIP_DEV_5PNTS as Strip6,CPCT_CPC7_CYL_DEV_5PNTS as Cylinder7,CPCT_CPC7_STRIP_DEV_5PNTS as Strip7 from [FP_PROCESS_DATA].[dbo].[CRM_PLTCM_CPC_TREND] where CPCT_START_TIME between '{fromName1}' and '{toName1}' order by CPCT_START_TIME";
        //        var dt = dbWrmDevice_Counter.Database.SqlQuery<CPCdata>(q).ToArray();
        //        //var h = dt.AsEnumerable().Select(f => f.CPAT_VAR_NAME).Distinct().ToArray();

        //        return dt;

        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception(ex.ToString());
        //    }

        //}
        //private void BoxPlotForPltcmCylinderEmpty( String PlotName, int val)
        //{
        //    CHART_LP11 c10 = new CHART_LP11()
        //    {

        //        ID = "s" + val,
        //        ticks = "",
        //        line1 = "",
        //        line2 = "",
        //        Title = PlotName+"---------No Data--------",
        //        Section = "",
        //    };
        //    lst1.Add(c10);
        //}
        //private void BoxPlotForPltcmCylinder(CPCdata[] dt, String PlotName, int val, String SelectValue)
        //{

        //        if (SelectValue == "Box Plot")
        //        {
        //            try
        //            {
        //                string ticks = "[";
        //                string line1 = "", line2 = "";
        //                line1 += "[";
        //                line2 += "[";

        //            for (int i = 0; i < dt.Length-1; i++ )
        //                {
        //                string cval = "";
        //                string Sval = "";

        //                switch (val)
        //                {
        //                    case 0:
        //                        cval = dt[i].Cylinder1;
        //                        Sval = dt[i].Strip1;
        //                        break;
        //                    case 1:
        //                        cval = dt[i].Cylinder2;
        //                        Sval = dt[i].Strip2;
        //                        break;
        //                    case 2:
        //                        cval = dt[i].Cylinder3;
        //                        Sval = dt[i].Strip3;
        //                        break;
        //                    case 3:
        //                        cval = dt[i].Cylinder4;
        //                        Sval = dt[i].Strip4;
        //                        break;
        //                    case 4:
        //                        cval = dt[i].Cylinder5;
        //                        Sval = dt[i].Strip5;
        //                        break;
        //                    case 5:
        //                        cval = dt[i].Cylinder6;
        //                        Sval = dt[i].Strip6;
        //                        break;
        //                    case 6:
        //                        cval = dt[i].Cylinder7;
        //                        Sval = dt[i].Strip7;
        //                        break;

        //                }

        //                if (cval.ToString() != "")
        //                {

        //                    try
        //                    {

        //                        ticks += "'" + dt[i].CPCT_START_TIME + "'";

        //                        string[] tmpCyl = cval.Split(new char[] { ',' });
        //                        line1 += "[" + tmpCyl[0] + "," + tmpCyl[4] + "," + tmpCyl[3] + "," + tmpCyl[5] + "," + tmpCyl[1] + "]";

        //                        string[] tmpStrip = Sval.Split(new char[] { ',' });
        //                        line2 += "[" + tmpStrip[0] + "," + tmpStrip[4] + "," + tmpStrip[3] + "," + tmpStrip[5] + "," + tmpStrip[1] + "]";

        //                        if (i != 0 | i != dt.Length - 1)
        //                        {
        //                            ticks += ",";
        //                            line1 += ",";
        //                            line2 += ",";
        //                        }
        //                    }



        //                    catch (Exception ex)
        //                    {
        //                        continue;
        //                    }
        //                }

        //            }
        //                ticks += "]";
        //                line1 += "]";
        //                line2 += "]";
        //            CHART_LP11 c10 = new CHART_LP11()
        //            {

        //                ID = "s" + val,
        //                ticks = ticks,
        //                line1 = line1,
        //                line2 = line2,
        //                Title = HeaderName[val],
        //                Section = SelectValue,
        //            };
        //            lst1.Add(c10);
        //        }
        //            catch (Exception ex)
        //            {

        //            }
        //        }


        //        if (SelectValue == "Average" | SelectValue == "Std Deviation")
        //        {

        //            try
        //            {
        //                string ticks = "[";
        //                string line1 = "", line2 = "";
        //                line1 += "[";
        //                line2 += "[";
        //                for (int i = 0; i < dt.Length-1; i++ )
        //                {
        //                string cval = "";
        //                string Sval = "";

        //                switch (val)
        //                {
        //                    case 0:
        //                        cval = dt[i].Cylinder1;
        //                        Sval = dt[i].Strip1;
        //                        break;
        //                    case 1:
        //                        cval = dt[i].Cylinder2;
        //                        Sval = dt[i].Strip2;
        //                        break;
        //                    case 2:
        //                        cval = dt[i].Cylinder3;
        //                        Sval = dt[i].Strip3;
        //                        break;
        //                    case 3:
        //                        cval = dt[i].Cylinder4;
        //                        Sval = dt[i].Strip4;
        //                        break;
        //                    case 4:
        //                        cval = dt[i].Cylinder5;
        //                        Sval = dt[i].Strip5;
        //                        break;
        //                    case 5:
        //                        cval = dt[i].Cylinder6;
        //                        Sval = dt[i].Strip6;
        //                        break;
        //                    case 6:
        //                        cval = dt[i].Cylinder7;
        //                        Sval = dt[i].Strip7;
        //                        break;

        //                }
        //                if (cval.ToString() != "")
        //                    {

        //                        try
        //                        {
        //                            ticks += "'" + dt[i].CPCT_START_TIME  + "'";

        //                        string[] tmpCyl = cval.Split(new char[] { ',' });
        //                        if (SelectValue == "Average")
        //                            {
        //                                line1 += tmpCyl[2];
        //                            }
        //                            else
        //                            {
        //                                line1 += tmpCyl[6];
        //                            }


        //                        string[] tmpStrip = Sval.Split(new char[] { ',' });
        //                        if (SelectValue == "Average")
        //                            {
        //                                line2 += tmpStrip[2];
        //                            }
        //                            else
        //                            {
        //                                line2 += tmpStrip[6];
        //                            }


        //                            if (i != 0 | i != dt.Length- 1)
        //                            {
        //                                ticks += ",";
        //                                line1 += ",";
        //                                line2 += ",";
        //                            }
        //                        }



        //                        catch (Exception ex)
        //                        {
        //                            continue;
        //                        }
        //                    }

        //                }
        //                ticks += "]";
        //                line1 += "]";
        //                line2 += "]";
        //            CHART_LP11 c10 = new CHART_LP11()
        //            {

        //                ID = "s" + val,
        //                ticks = ticks,
        //                line1 = line1,
        //                line2 = line2,
        //                Title = HeaderName[val],
        //                Section = SelectValue,
        //            };
        //            lst1.Add(c10);
        //        }
        //            catch (Exception ex)
        //            {

        //            }



        //        }






        //}


    }
}