﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;
using System.Web;

namespace PTG_TSJ_Main.BussinessLogic.PLTCM
{
    public class CRM_LabData
    {
        LP_PROCESS_DATA_v1Device_Counter dbWrmDevice_Counter = new LP_PROCESS_DATA_v1Device_Counter();
        List<CHART_LP11> lstChart = new List<CHART_LP11>();
        List<CheckBoxData> Checklst1 = new List<CheckBoxData>();
        List<FromDateToDate> lst = new List<FromDateToDate>();
      
        string[] HeaderName = new string[] { "CPC 1 Cylinder & Strip Trend", "CPC 2 Cylinder & Strip Trend", "CPC 3 Cylinder & Strip Trend", "CPC 4 Cylinder & Strip Trend", "CPC 5 Cylinder & Strip Trend", "CPC 6 Cylinder & Strip Trend", "CPC 7 Cylinder & Strip Trend" };
        internal MultipleData GetDataCrm_LabData(String fromName1, String toName1, String SelectValue,String[] Checkboxes)
        {

            var table = new MultipleData();
            string ToDate1 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            string FromDate1 = DateTime.Now.AddMonths(-1).ToString("yyyy-MM-dd HH:mm:ss");


            //Declare DateTime Global And change String To DateTime;
            DateTime frmDate = new DateTime(2023, 06, 14, 11, 21, 59);

            DateTime toDate = new DateTime(2023, 06, 14, 11, 21, 59); ;
            if (fromName1 == null && toName1 == null)
            {
                fromName1 = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd HH:mm:ss");

                toName1 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                frmDate = DateTime.Parse(fromName1);
                toDate = DateTime.Parse(toName1);

            }
            else
            {
                ToDate1 = toName1;
                FromDate1 = fromName1;
                frmDate = DateTime.Parse(fromName1);

                toDate = DateTime.Parse(toName1);


            }
            string[] SelectionData = { "Box Plot", "Average", "Std Deviation" };
            if (SelectValue == null)
            {
                SelectValue = "Box Plot";
            }
            FromDateToDate c0 = new FromDateToDate()
            {

                FromDate = FromDate1,
                ToDate = ToDate1,
                FromDateName = "fromName1",
                ToDateName = "toName1",
                ID = "",
                todateId = "todateId1",
                FromdateId = "fromdateId2",
                Section = SelectValue,
                Heat = "Heat",
                SelectOption = SelectionData,

            };
            lst.Add(c0);


            string CLR_Data=CLR_FinfData(fromName1, toName1, SelectValue);

            CheckData(CLR_Data, Checkboxes);
            if(Checkboxes != null)
            {
                PlotChart(fromName1, toName1, SelectValue, Checkboxes, CLR_Data);
            }
            

            table.ChartData = lstChart;
            table.FromDateToDate = lst;
            table.CheckBoxData = Checklst1;
            return table;
        }
        private string CLR_FinfData(String fromName1, String toName1, String SelectValue)
        {
            SelectValue = "PLTCM";
            string Find_CLR_Data = "";
            
            if (SelectValue =="PLTCM")
            {
                Find_CLR_Data = "P";
            }
            else if (SelectValue == "CGL1")
            {
                Find_CLR_Data = "G";
            }
            else if (SelectValue == "CGL2")
            {
                Find_CLR_Data = "L";
            }

            return Find_CLR_Data;


        }
        private void CheckData( String CheckData, String[] Checkboxes)
        {

            
            string q = $@"SELECT DISTINCT CLR_PARAM_TEST,[FP_PROCESS_DATA].[dbo].UFN_GET_PARAM_ALIAS_NAME(CLR_PARAM_TEST) AS PARAM_TEST FROM[FP_PROCESS_DATA].[dbo].[CRM_LABTEST_RES] WHERE CLR_PARAM_TEST <> '' and CLR_PROCESS_LINE in ('{CheckData}') ORDER BY PARAM_TEST";
            var dt = dbWrmDevice_Counter.Database.SqlQuery<crmlab>(q).ToArray();

            
            var dataName = dt.Select(e => e.PARAM_TEST).Distinct().ToArray();
            string[] Datavalue = new string[dataName.Length];
            for (int k=0;k< dataName.Length; k++)
            {
                var datavalue1 = dt.Where(e => e.PARAM_TEST == dataName[k]).Select(e=>e.CLR_PARAM_TEST).ToArray();
                for (int j = 0; j < datavalue1.Length; j++)
                {
                    if (datavalue1.Length != 1)
                    {
                        Datavalue[k] += datavalue1[j].ToString()+",";
                    }
                    else
                    {
                        Datavalue[k] = datavalue1[j].ToString();
                    }   
                }
            }
            int CountArray = Datavalue.Length;
            string[] P_Test = new string[CountArray];
            string[] CLR_P_Test = new string[CountArray];
            string[] ChecedData = new string[CountArray];
            string[] ChecedData1 = new string[CountArray];
            for (int i = 0; i < dataName.Length; i++)
            {
                P_Test[i] = dataName[i];
                CLR_P_Test[i] = Datavalue[i];
            }

            if (Checkboxes != null)
            {
                for (int i = 0; i < Checkboxes.Length; i++)
                {
                    ChecedData[i] = Checkboxes[i];
                }

                for (int i = 0; i < Checkboxes.Length; i++)
                {
                    for (int j = 0; j < dataName.Length; j++)
                    {
                        string d1 = CLR_P_Test[j];
                        string d2 = ChecedData[i];
                        if ( d1==d2 )
                        {
                            //ChecedData[j] = CLR_P_Test[j]+"@";
                            ChecedData1[j] = "A";
                        }
                       
                    }
                }

            }

            CheckBoxData c10 = new CheckBoxData()
            {
               CheckBoxValue= P_Test,
               CheckBoxName= CLR_P_Test,
               DrplData= CheckData,
                CheckBoxChecked= ChecedData1,
                SelectName = "Checkboxes",
            };
            Checklst1.Add(c10);
        }
        private void PlotChart(String fromName1, String toName1, String SelectValue, String[] Checkboxes,String CLR_Data)
        {
            
            int m = 0;
            var arrayLength2 = Checkboxes.Length * 2;
            
            string[] CheckBoxesValues = new string[arrayLength2];
            if (Checkboxes !=null)
            {
                for (int i = 0; i < Checkboxes.Length ; i++)
                {
                    if (Checkboxes[i].Contains(","))
                    {
                        var data = Checkboxes[i].Split(',');
                        for (int l = 0; l < data.Length; l++)
                        {
                            if (data[l] != "")
                            {
                                CheckBoxesValues[m] = data[l];
                                m = m + 1;
                            }
                        }
                    }else
                    {
                        var dataall = Checkboxes[i];
                        CheckBoxesValues[m] = dataall;
                        m = m + 1;
                    }
                }
            }
            String dataValueString = "";
            if (CheckBoxesValues.Length > 1)
            {
                for (int i = 0; i < CheckBoxesValues.Length; i++)
                {
                    if (CheckBoxesValues[i] != null)
                    {
                        dataValueString += "," + "'"+CheckBoxesValues[i]+"'";
                    }
                }
            }
            var removedata = dataValueString.Substring(1);
            string q = $@"select CLR_TEST_VALUE,CLR_DT_SAMPLING_DATE,ISNULL(CLR_PARAM_MIN,0) AS CLR_PARAM_MIN,CLR_PARAM_TEST,'CLR_PARAM_TEST_NEW' = CASE WHEN CLR_TEST_VALUE > 0.15 AND CLR_TEST_VALUE <= 0.4 AND(CLR_PARAM_TEST='ZAAL' OR CLR_PARAM_TEST='ZAZS' OR CLR_PARAM_TEST='ZAGA') THEN 'GI' WHEN CLR_TEST_VALUE >= 0.1 AND CLR_TEST_VALUE <= 0.15 AND (CLR_PARAM_TEST='ZAAL' OR CLR_PARAM_TEST='ZAZS' OR CLR_PARAM_TEST='ZAGA') THEN 'GA' WHEN CLR_PARAM_TEST='ZAFE' THEN 'FE' WHEN CLR_PARAM_TEST='ZASB' THEN 'Antimony' WHEN CLR_PARAM_TEST='CRPT' THEN 'Chromate Prepertion' WHEN CLR_PARAM_TEST='ZAPB' THEN 'Lead' WHEN CLR_PARAM_TEST='ALET' THEN 'ECL tank' WHEN CLR_PARAM_TEST='ALPT' THEN 'Predeg. tank' WHEN CLR_PARAM_TEST='SHCR' THEN 'Sheet Chromium' WHEN CLR_PARAM_TEST='CRWT' THEN 'Working tank' WHEN CLR_PARAM_TEST='ACIDT1' THEN 'HCL Acid T1' WHEN CLR_PARAM_TEST='ACIDT2' THEN 'HCL Acid T2' WHEN CLR_PARAM_TEST='ACIDT3' THEN 'HCL Acid T3' WHEN CLR_PARAM_TEST='ACIDT4' THEN 'HCL Acid T4' WHEN CLR_PARAM_TEST='HCLWT1' THEN 'HCL T1' WHEN CLR_PARAM_TEST='HCLWT2' THEN 'HCL T2' WHEN CLR_PARAM_TEST='HCLWT3' THEN 'HCL T3' WHEN CLR_PARAM_TEST='HCLWT4' THEN 'HCL T4' WHEN CLR_PARAM_TEST='ALTK' THEN 'Alkali tank' WHEN CLR_PARAM_TEST='ALHW' THEN 'Hot Rinse Water' WHEN CLR_PARAM_TEST='ZASN' THEN 'Tin' WHEN CLR_PARAM_TEST='ALETO' THEN 'ECL Tank (Fe %)' WHEN CLR_PARAM_TEST='ZAEAL' THEN 'Eff Aluminium' WHEN CLR_PARAM_TEST='FE' THEN 'FE' WHEN CLR_PARAM_TEST='ZAZN' THEN 'Zinc' WHEN CLR_PARAM_TEST='WL' THEN 'WL' WHEN CLR_PARAM_TEST='FET1' THEN 'Iron FE T1' WHEN CLR_PARAM_TEST='FEWT1' THEN 'Iron FEW T1' WHEN CLR_PARAM_TEST='FET2' THEN 'Iron FE T2' WHEN CLR_PARAM_TEST='FEWT2' THEN 'Iron FEW T2' WHEN CLR_PARAM_TEST='FET3' THEN 'Iron FE T3' WHEN CLR_PARAM_TEST='FEWT3' THEN 'Iron FEW T3' WHEN CLR_PARAM_TEST='FET4' THEN 'Iron FE T4' WHEN CLR_PARAM_TEST='FEWT4' THEN 'Iron FEW T4' ELSE CLR_PARAM_TEST END from [FP_PROCESS_DATA].[dbo].[CRM_LABTEST_RES] where CLR_DT_SAMPLING_DATE between '{fromName1}' and '{toName1}' and cast(CLR_TEST_VALUE as float)>0 and CLR_PROCESS_LINE in ('{CLR_Data}') and CLR_PARAM_TEST in ({dataValueString.Substring(1)}) order by CLR_DT_SAMPLING_DATE";
            var dt = dbWrmDevice_Counter.Database.SqlQuery<CrmLabChart>(q).ToArray();
            string  min_time = dt.Select(x => x.CLR_DT_SAMPLING_DATE).Min().AddMinutes(-30).ToString("yyyy-MM-dd HH:mm"); ;
            string  max_time = dt.Select(x => x.CLR_DT_SAMPLING_DATE).Max().AddMinutes(30).ToString("yyyy-MM-dd HH:mm"); ;

            //var clrtestValue = dt.Select(e => e.CLR_TEST_VALUE).ToArray();
            var min = (double)(dt.Select(x => x.CLR_TEST_VALUE).Min());
            var max = (double)(dt.Select(x => x.CLR_TEST_VALUE).Max());
            var Ymin = min - (10d / 100 * min);
            var Ymax = max + (10d / 100 * max);
            var clrNewData = dt.Select(e => e.CLR_PARAM_TEST_NEW).Distinct().ToArray();
            string chartstrblt = "";
            if (clrNewData != null && clrNewData.Length > 0)
            {
                for (int i = 0; i < clrNewData.Length; i++)
                {
                    var checkBoxesData = (from x in dt.Where(d => d.CLR_PARAM_TEST_NEW == clrNewData[i])
                                          select new
                                          {
                                              x.CLR_PARAM_MIN,
                                              x.CLR_TEST_VALUE,
                                              x.CLR_DT_SAMPLING_DATE,
                                             x.CLR_PARAM_TEST,
                                             x.CLR_PARAM_TEST_NEW
                                          }).ToList();

                    chartstrblt += "{name:'" + clrNewData[i] + "',type:'line',data:[";
                    for (int j = 0; j < checkBoxesData.Count; j++)
                    {
                        chartstrblt += "['" + ((DateTime)checkBoxesData[j].CLR_DT_SAMPLING_DATE).ToString("yyyy-MM-dd HH:mm:ss") + "'," + checkBoxesData[j].CLR_TEST_VALUE + "],";
                    }
                    chartstrblt += "]";
                    
                    chartstrblt += " },";
                }
            }
            else
            {

            }
            CHART_LP11 c1 = new CHART_LP11()
            {
                FromDate = "",
                ID = "Container1",
                Title = "CRM_LabData",
                TypeX = "time",
                TypeY = "Vlaue",
                ShowLegend = "true",
                Width = "{yyyy}:{MM}:{dd}",
                ShowToolBox = chartstrblt,
                MaxAxisData = Convert.ToString(Ymax),
                MinAxisData = Convert.ToString(Ymin),
                SeriesData = "",
                divcolsm="12",
                divHeight="55vh"

            };
            lstChart.Add(c1);
        }
    }
}