﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;
using System.Web;

namespace PTG_TSJ_Main.BussinessLogic.PLTCM
{
    public class MainSubMenu
    {
        PLTCM_Entity db_PLTCM_Menu = new PLTCM_Entity();
        internal MultipleData GetDataForMillGlance(MultipleData table)
        {
           
            List<SideMenu> Lst = new List<SideMenu>();

            var PtgMenu = (from x in db_PLTCM_Menu.PLTCM_Menu
                           select new { x.PLTCM_MAIN_MENU_ID, x.PLTCM_MAIN_MENU }).Distinct().OrderBy(x => x.PLTCM_MAIN_MENU_ID).ToList();
            for (int k = 0; k < PtgMenu.Count; k++)
            {

                var data = PtgMenu[k].PLTCM_MAIN_MENU_ID;
                var PtgMenuSub = (from x in db_PLTCM_Menu.PLTCM_Menu.Where(e => e.PLTCM_MAIN_MENU_ID == data)
                                  select new { x.PLTCM_MAIN_URL_ID, x.PLTCM_SUB_MENU, x.PLTCM_MAIN_URL, x.PLTCM_SUB_CONTROLLER }).Distinct().ToList();
                string[] ArraMenuSize = new string[PtgMenuSub.Count()];
                string ActionN = "";
                string ContrlN = "";

                if (PtgMenuSub.Count() > 0)
                {
                    for (int m = 0; m < PtgMenuSub.Count; m++)
                    {
                        ArraMenuSize[m] = PtgMenuSub[m].PLTCM_SUB_MENU;
                        ActionN = PtgMenuSub[m].PLTCM_MAIN_URL;
                        ContrlN = PtgMenuSub[m].PLTCM_SUB_CONTROLLER;
                    }

                }
                SideMenu c1 = new SideMenu()
                {
                    MainMenu = PtgMenu[k].PLTCM_MAIN_MENU,
                    SubMenu = ArraMenuSize,
                    //ActionName = ActionN,
                    //ControllerName = ContrlN,

                };
                Lst.Add(c1);
            }


            table.SideMenu = Lst;
            return table;
        }
    }
}