﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;
using System.Web;


namespace PTG_TSJ_Main.BussinessLogic.PLTCM
{
    public class MillGlance
    {
        LP_PROCESS_DATA_v1Device_Counter dbWrmDevice_Counter = new LP_PROCESS_DATA_v1Device_Counter();
        List<CHART_LP11> lst1 = new List<CHART_LP11>();
        internal MultipleData GetDataForMillGlance(String fromName1, String toName1)
        {
            dbWrmDevice_Counter.Database.CommandTimeout = 180;
            string ToDate1 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            string FromDate1 = DateTime.Now.AddHours(-8).ToString("yyyy-MM-dd HH:mm:ss");
            
            //Declare DateTime Global And change String To DateTime;
            DateTime frmDate = new DateTime(2023, 06, 14, 11, 21, 59);

            DateTime toDate = new DateTime(2023, 06, 14, 11, 21, 59); ;
            if (fromName1 == null && toName1 == null)
            {
                fromName1 = DateTime.Now.AddHours(-8).ToString("yyyy-MM-dd HH:mm:ss");

                toName1 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                frmDate = DateTime.Parse(fromName1);
                toDate = DateTime.Parse(toName1);

            }
            else
            {
                ToDate1 = toName1;
                FromDate1 = fromName1;
                frmDate = DateTime.Parse(fromName1);

                toDate = DateTime.Parse(toName1);


            }
           
            List<FromDateToDate> lst = new List<FromDateToDate>();

            FromDateToDate c0 = new FromDateToDate()
            {

                FromDate = FromDate1,
                ToDate = ToDate1,
                FromDateName = "fromName1",
                ToDateName = "toName1",
                ID = "",
                todateId = "todateId1",
                FromdateId = "fromdateId2",
                Section = "",
                Heat = "Heat"

            };
            lst.Add(c0);

           
            var table = new MultipleData();
            DrawCharts( ToDate1,FromDate1);


            table.FromDateToDate = lst;
            table.ChartData = lst1;
            return table;
        }

        public void DrawCharts(String ToDate1, String FromDate1)
        {

            DrawChart_Encoder(ToDate1,FromDate1, "Encoders", "Encoders");

            DrawChart_BR("4BR_Loadbalance_curr_diff", "c2", ToDate1, FromDate1, "BR#4 Current","Current");
            DrawChart_BR("5BR_Loadbalance_curr_diff", "c3", ToDate1, FromDate1, "BR#5 Current", "Current");
            DrawChart_BR("6BR_R1_Loadbalance_Curr_diff", "c4", ToDate1, FromDate1, "BR#6 R1 Current", "Current");
            DrawChart_BR("6BR_R2_Loadbalance_Curr_diff", "c5", ToDate1, FromDate1, "BR#6 R2 Current", "Current");

            DrawChart_PL("ACIDT1", "d1", 3, ToDate1, FromDate1, "PL TANK 1","Tank");
            DrawChart_PL("ACIDT2", "d2", 4, ToDate1, FromDate1, "PL TANK 2", "Tank");
            DrawChart_PL("ACIDT3", "d3", 6, ToDate1, FromDate1, "PL TANK 3", "Tank");
            DrawChart_PL("ACIDT4", "d4", 9, ToDate1, FromDate1, "PL TANK 4", "Tank");
        }


        private void DrawChart_Encoder(String ToDate1, String FromDate1,String Title,String Section)
        {
            string strEncoder1 = $@"SELECT [PL_SL_NO],[PL_PARAM_NAME],[PL_MAX_LIMIT],[PL_MIN_LIMIT] FROM [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_PLTCM_LIMITS] WHERE [PL_ACTIVE]=1 ORDER BY 1";
            string strEncoder2 = $@"SELECT MAX(PEM_STARTTIME) as PEM_STARTTIME FROM [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_PLTCM_ENCODER_MAX]";
            string strEncoder3 = $@"SELECT PEM_SPD_STDDEV_MAX,PEM_STARTTIME FROM [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_PLTCM_ENCODER_MAX] WHERE PEM_STARTTIME BETWEEN '{FromDate1}' AND '{ToDate1}' ORDER BY PEM_STARTTIME";

            var dtLimit = dbWrmDevice_Counter.Database.SqlQuery<Millglance>(strEncoder1).ToArray();
            var valEncoderMax = dbWrmDevice_Counter.Database.SqlQuery<Millglance>(strEncoder2).ToList() ;
            var dtData = dbWrmDevice_Counter.Database.SqlQuery<Millglance>(strEncoder3).ToArray();
            
            
            double percentage = 0;

            string CpatTime = "";
            if (dtLimit.Length > 0)
            {
                CpatTime = valEncoderMax[0].PEM_STARTTIME.ToString("dd-MMM-yy HH:mm");
            }

            if (dtData.Length > 0)
            {
                var totAlerts = new int[dtLimit.Length];
                for (int i = 0; i < dtData.Count(); i++)
                {
                    string result = dtData[i].PEM_SPD_STDDEV_MAX ;
                    
                    string[] temp = result.Split(new char[] { ',' });
                    for (int j = 0; j < dtLimit.Length; j++)
                    {
                        try
                        {
                            int data = dtLimit[j].PL_SL_NO-1;
                            if (Convert.ToDecimal(temp[data]) > dtLimit[j].PL_MAX_LIMIT)
                            {
                                totAlerts[j] = 1;
                            }
                        }
                        catch (Exception ex)
                        {

                        }
                    }
                }
                int totalsum = totAlerts.Sum();
                 percentage = (double)totalsum * 100 / dtLimit.Length;

                CHART_LP11 c10 = new CHART_LP11()
                {
                    ID = "GS",
                    Title = Title,
                    ShowToolBox = Convert.ToString(percentage),
                    MaxAxisData = CpatTime,
                    MinAxisData = "",
                    FromDate = ToDate1,
                    ToDate = FromDate1,
                    Section = Section,


                };
                lst1.Add(c10);
            }
            else
            {
                CHART_LP11 c10 = new CHART_LP11()
                {
                    ID = "GS",
                    Title = "",
                    ShowToolBox = "",
                    MaxAxisData = "",
                    MinAxisData = "",
                    FromDate = ToDate1,
                    ToDate = FromDate1,

                };
                lst1.Add(c10);
            }

           

        }


        private void DrawChart_BR(string param, string container, String ToDate1, String FromDate1,String Title, String Section)
        {

            string strEncoder1 = $@"SELECT CPAT_VAR_VAL_BOXPLOT,CPAT_START_TIME FROM [FP_PROCESS_DATA].[dbo].[CRM_PLTCM_CRITICAL_PARAMETER_TREND] WHERE CPAT_START_TIME BETWEEN '{FromDate1}' and '{ToDate1}' AND LOWER(CPAT_VAR_NAME)='{param.ToLower()}' ORDER BY CPAT_START_TIME desc";
            string strEncoder2 = $@"SELECT MAX(CPAT_START_TIME) as CPAT_START_TIME FROM [FP_PROCESS_DATA].[dbo].[CRM_PLTCM_CRITICAL_PARAMETER_TREND] where LOWER(CPAT_VAR_NAME)='{param.ToLower()}'";

            var dtData = dbWrmDevice_Counter.Database.SqlQuery<Millglance>(strEncoder1).ToArray();
            var dtLimit = dbWrmDevice_Counter.Database.SqlQuery<Millglance>(strEncoder2).ToArray();
            
            double thresholdLimit = 1.0d;
            string CpatTime = "";
            if (dtLimit.Length > 0)
            {
                CpatTime = dtLimit[0].CPAT_START_TIME.ToString("dd-MMM-yy HH:mm");
            }
            if (dtData.Length > 0)
            {
                
                var vals = dtData.AsEnumerable().Select(f => f.CPAT_VAR_VAL_BOXPLOT.Split(new char[] { ',' })[(int)BoxPlotValues.StdDev]).ToList();
                var totalRows = vals.Count;
                var thresholdRows = vals.Where(f => Convert.ToDouble(f) >= thresholdLimit).Count(); 
                double percentage =(double)thresholdRows * 100 / totalRows;
                //GetChartString(container, percentage);
                CHART_LP11 c10 = new CHART_LP11()
                {
                    ID = container,
                    Title = Title,
                    ShowToolBox = Convert.ToString(percentage),
                    MaxAxisData = CpatTime,
                    MinAxisData = "",
                    FromDate = ToDate1,
                    ToDate = FromDate1,
                    Section = Section,
                };
                lst1.Add(c10);
            }
            else
            {
                CHART_LP11 c10 = new CHART_LP11()
                {
                   
                    ID = container,
                    Title = Title,
                    ShowToolBox = "",
                    MaxAxisData = "",
                    MinAxisData = "",
                    FromDate = ToDate1,
                    ToDate = FromDate1,
                    
                };
                lst1.Add(c10);
            }

            

        }

        private void DrawChart_PL(string param, string container, decimal threshold, String ToDate1, String FromDate1,String Title, String Section)
        {

            string strEncoder1 = $@"select  * from Openquery(CRM_ORACLE,'Select  to_char(CSE_TS_SAMPLING,''YYYY-MM-DD HH24:MI:SS'') as CSE_TS_SAMPLING,to_char(CSR_TS_TEST,''YYYY-MM-DD HH24:MI:SS'') as CSR_TS_TEST, CSR_TEST_PARA,CSR_TEST_VAL,to_char(CSE_TS_TST_OVR,''YYYY-MM-DD HH24:MI:SS'') as CSE_TS_TST_OVR  FROM CRMDBA.t_CONS_RESULT  INNER JOIN CRMDBA.t_CONS_SAMPLE ON CSR_CD_CONSUMABLE = CSE_CD_CONSUMABLE  AND CSR_ID_SAMPLE = CSE_ID_SAMPLE AND CSR_CD_PROCESS= CSE_CD_PROCESS WHERE CSR_CD_PROCESS=''P''  AND CSR_TEST_PARA in (''{param}'') and CSR_TS_TEST between ''{FromDate1}'' and ''{ToDate1}'' ORDER BY CSE_TS_TST_OVR DESC')";
           

            var dtData = dbWrmDevice_Counter.Database.SqlQuery<Millglance>(strEncoder1).ToArray();
            decimal thresholdLimit = threshold;
            string CpatTime = "";
            if (dtData.Length > 0)
            {
                CpatTime =  Convert.ToDateTime(dtData[0].CSR_TS_TEST).ToString("dd-MMM-yy HH:mm");
            }
            if (dtData.Length > 0)
            {
                var vals = dtData.AsEnumerable().Select(f => f.CSR_TEST_VAL).ToList();
                var totalRows = vals.Count();
                var thresholdRows = vals.Where(f => f < thresholdLimit).Count();
                double percentage = (double)thresholdRows * 100 / totalRows;

                CHART_LP11 c10 = new CHART_LP11()
                {
                  
                    ID = container,
                    Title = Title,
                    ShowToolBox = Convert.ToString(percentage),
                    MaxAxisData = CpatTime,
                    MinAxisData = "PL",
                    FromDate = ToDate1,
                    ToDate = FromDate1,
                    Section = Section,


                };
                lst1.Add(c10);
            }
            else
            {
                CHART_LP11 c10 = new CHART_LP11()
                {
                  
                    ID = container,
                    Title = Title,
                    ShowToolBox = "",
                    MaxAxisData = "",
                    MinAxisData = "PL",
                    FromDate = ToDate1,
                    ToDate = FromDate1,
                    

                };
                lst1.Add(c10);
            }


        }

        enum BoxPlotValues
        {
            LowerBound,
        UpperBound,
        Avg,
        Median,
        L_Q,
        U_Q,
        StdDev,
        Min,
        Max,
        }
       

    }
}