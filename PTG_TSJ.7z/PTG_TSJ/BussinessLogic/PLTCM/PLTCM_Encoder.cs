﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;
using System.Web;


namespace PTG_TSJ_Main.BussinessLogic.PLTCM
{
    public class PLTCM_Encoder
    {
        LP_PROCESS_DATA_v1Device_Counter dbWrmDevice_Counter = new LP_PROCESS_DATA_v1Device_Counter();
        List<CHART_LP11> lst1 = new List<CHART_LP11>();
        PLTCM_Entity db_PLTCM_Menu = new PLTCM_Entity();
        internal MultipleData GetDataForMillGlance(String fdate, String tdate)
        {
            dbWrmDevice_Counter.Database.CommandTimeout = 180;
            var table = new MultipleData();

            if (fdate==null && tdate == null)
            {
                DrawCharts();
            }
            else
            {
                DrawCharts(fdate, tdate);
            }
           
            table.ChartData = lst1;
            return table;
        }


        private void DrawCharts()
        {

            dbWrmDevice_Counter.Database.CommandTimeout = 180;

            string strEncoder1 = $@"select top 1 * from [FP_CRM_EQUIP_MAINTENANCE].[dbo].CRM_PLTCM_ENCODER_MAX order by PEM_STARTTIME desc";
            string strEncoder2 = $@"select * from [FP_CRM_EQUIP_MAINTENANCE].[dbo].CRM_PLTCM_LIMITS WHERE PL_ACTIVE=1 order by PL_SEQ_NO";


            var dtLimit = dbWrmDevice_Counter.Database.SqlQuery<Pltcm_Encoder>(strEncoder1).ToArray();


            var dtData = dbWrmDevice_Counter.Database.SqlQuery<Pltcm_Encoder>(strEncoder2).ToArray();


            var groups = dtData.AsEnumerable().Select(f => f.PL_SEQ_NO).Distinct().ToArray();
            var TitleName = dtData.AsEnumerable().Select(f => f.PL_HEADER_NAME).Distinct().ToArray();
            int i = 1;
            int j = 0;
            int cidx = 0;
            if (dtLimit.Length > 0)
            {
                var temp = dtLimit.AsEnumerable().Select(f => f.PEM_SPD_STDDEV_MAX.Split(new char[] { ',' })).ToList();
                var VAlsCount = temp[0].Count();
                string[] valarr = new string[VAlsCount];

                for (int k = 0; k < VAlsCount; k++)
                {
                    int idx = k;

                    valarr[k] = temp[0][k];
                }



                string[] arrData = valarr;
                for (int m = 0; m < groups.Length; m++)
                //for (int m = 0; m < 3; m++)
                {
                    var groupCount = dtData.Where(e => e.PL_SEQ_NO == groups[m]).ToArray();


                    var results = arrData.Skip(j).Take(groupCount.Length);
                    j = j + groupCount.Length;
                    string xdata = "";
                    string ydata = "";

                    for (int k = 0; k < groupCount.Length; k++)
                    {
                        xdata += ",'" + dtData[i - 1].PL_ALIAS + "'";
                        string color = "#3398DB";
                        if (dtData[i - 1].PL_MAX_LIMIT > 0 && Convert.ToDecimal(arrData[dtData[i - 1].PL_SL_NO - 1]) >= dtData[i - 1].PL_MAX_LIMIT)
                        {
                            color = "#F05D5E";
                        }
                        var arrValue = arrData[dtData[i - 1].PL_SL_NO - 1];
                        ydata += ",{value:" + arrValue + ",itemStyle:{normal:{color:'" + color + "'}}}";
                        //ydata += ",{value:" + hghghghg + "}";
                        i = i + 1;
                    }

                    CHART_LP11 c10 = new CHART_LP11()
                    {
                        ID = Convert.ToString(i),
                        Title = TitleName[m],
                        ShowToolBox = xdata,
                        MaxAxisData = ydata,
                        MinAxisData = "",
                        Section = "",


                    };
                    lst1.Add(c10);

                }
            }

        }
        private void DrawCharts(String fdate, String tdate)
        {

            dbWrmDevice_Counter.Database.CommandTimeout = 180;
          
            string strEncoder1 = $@"select  * from [FP_CRM_EQUIP_MAINTENANCE].[dbo].CRM_PLTCM_ENCODER_MAX where PEM_STARTTIME between '{tdate}' and '{fdate}' order by PEM_STARTTIME desc; ";
            string strEncoder2 = $@"select * from [FP_CRM_EQUIP_MAINTENANCE].[dbo].CRM_PLTCM_LIMITS WHERE PL_ACTIVE=1 order by PL_SEQ_NO";


            var dtLimit = dbWrmDevice_Counter.Database.SqlQuery<Pltcm_Encoder>(strEncoder1).ToArray();


            var dtData = dbWrmDevice_Counter.Database.SqlQuery<Pltcm_Encoder>(strEncoder2).ToArray();



            var groups = dtData.AsEnumerable().Select(f => f.PL_SEQ_NO).Distinct().ToArray();
            var TitleName = dtData.AsEnumerable().Select(f => f.PL_HEADER_NAME).Distinct().ToArray();
            int i = 1;
            int j = 0;
            int cidx = 0;
            if (dtLimit.Length > 0)
            {
                var temp = dtLimit.AsEnumerable().Select(f => f.PEM_SPD_STDDEV_MAX.Split(new char[] { ',' })).ToList();
                var VAlsCount = temp[0].Count();
                string[] valarr = new string[VAlsCount];
                for (int k = 0; k < VAlsCount; k++)
                {
                    int idx = k;

                    valarr[k] = dtLimit.AsEnumerable().Select(f => Convert.ToDouble(f.PEM_SPD_STDDEV_MAX.Split(new char[] { ',' })[idx])).Max().ToString();
                }



                string[] arrData = valarr;
                for (int m = 0; m < groups.Length; m++)
                //for (int m = 0; m < 3; m++)
                {
                    var groupCount = dtData.Where(e => e.PL_SEQ_NO == groups[m]).ToArray();


                    var results = arrData.Skip(j).Take(groupCount.Length);
                    j = j + groupCount.Length;
                    string xdata = "";
                    string ydata = "";

                    for (int k = 0; k < groupCount.Length; k++)
                    {
                        xdata += ",'" + dtData[i - 1].PL_ALIAS + "'";
                        string color = "#3398DB";
                        if (dtData[i - 1].PL_MAX_LIMIT > 0 && Convert.ToDecimal(arrData[dtData[i - 1].PL_SL_NO - 1]) >= dtData[i - 1].PL_MAX_LIMIT)
                        {
                            color = "#F05D5E";
                        }
                        var arrValue = arrData[dtData[i - 1].PL_SL_NO - 1];
                        ydata += ",{value:" + arrValue + ",itemStyle:{normal:{color:'" + color + "'}}}";
                        //ydata += ",{value:" + hghghghg + "}";
                        i = i + 1;
                    }
                    string TimeView = fdate + "  -  " + tdate;
                    CHART_LP11 c10 = new CHART_LP11()
                    {
                        ID = Convert.ToString(i),
                        Title = TitleName[m],
                        ShowToolBox = xdata,
                        MaxAxisData = ydata,
                        MinAxisData = "",
                        Section = TimeView,


                    };
                    lst1.Add(c10);

                }
            }

        }
    }
}