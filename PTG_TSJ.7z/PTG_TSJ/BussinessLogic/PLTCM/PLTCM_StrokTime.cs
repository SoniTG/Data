﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;
using System.Web;

namespace PTG_TSJ_Main.BussinessLogic.PLTCM
{
    public class PLTCM_StrokTime
    {
        LP_PROCESS_DATA_v1Device_Counter dbWrmDevice_Counter = new LP_PROCESS_DATA_v1Device_Counter();
        //LP_PROCESS_DATA_v1Device_Counter DB = new LP_PROCESS_DATA_v1Device_Counter();
        List<CHART_LP11> lstChart = new List<CHART_LP11>();
        internal MultipleData GetDataForStrokTime(String fromName1, String toName1)
        {

            if (fromName1 == null && toName1 == null)
            {
                fromName1 = DateTime.Now.AddDays(-10).ToString("yyyy-MM-dd HH:mm:ss");

                toName1 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            }
            
            List<FromDateToDate> lst = new List<FromDateToDate>();

            FromDateToDate c0 = new FromDateToDate()
            {

                FromDate = fromName1,
                ToDate = toName1,
                FromDateName = "fromName1",
                ToDateName = "toName1",
                ID = "",
                todateId = "todateId1",
                FromdateId = "fromdateId2",
                Section = "",
                Heat = "Heat"

            };
            lst.Add(c0);

            DrawChartsData(fromName1, toName1);
            var table = new MultipleData();
            table.ChartData = lstChart;
            table.FromDateToDate = lst;
            return table;
        }

        public void DrawChartsData( String FromDate1,String ToDate1)
        {
            //try
            //{
            dbWrmDevice_Counter.Database.CommandTimeout = 180;
            string q1 = $@"select * From [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_PLTCM_WELDER_DATA] where CPW_DATETIME between '{FromDate1}' AND '{ToDate1}' order by CPW_DATETIME";
                string q2 = $@"select distinct CPW_PARAM_ALIAS,CPW_PARAM_NAME,ISNULL(CPW_LIMIT_MAX,0) as CPW_LIMIT_MAX From [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_PLTCM_WELDER_LIMIT] order by 1";
                var dt1 = dbWrmDevice_Counter.Database.SqlQuery<WelderData>(q1).ToArray();
                var dt2 = dbWrmDevice_Counter.Database.SqlQuery<WelderData>(q2).ToList();
                for (int i = 0; i <= dt2.Count()-1; i++)
                {

                //dv.RowFilter = "CPW_PARAM_NAME='" + dtDist.Rows(i)(1) + "'";
                //dttemp = dv.ToTable();
                var P_Alias = dt2[i].CPW_PARAM_ALIAS.ToString();
                    var data_CPW_PARAM_NAME = dt2.Select(e => e.CPW_PARAM_NAME).ToArray();
                    var RowFilter_CPW_PARAM_NAME = (from x in dt1.Where(e => e.CPW_PARAM_NAME == data_CPW_PARAM_NAME[i]) select x).ToArray();
                if (dt1.Count() > 0)
                {
                    PlotLineChart(RowFilter_CPW_PARAM_NAME, P_Alias, i,dt2[i].CPW_LIMIT_MAX); 
                }
                if (dt1.Count() == 0)
                {
                    PlotLineChartBlank( P_Alias, i);
                }

            }
            //}


            //catch (Exception ex)
            //{

            //}
           
           



        }

        public void PlotLineChart(WelderData[] dt,String P_Alias,int idx,decimal limit)
        {


            string chartstrblt = "";
            var Ymin = 0.000;
            var Ymax = 0.000;
            if (dt.Count() > 0)
            {
                string min_time = dt.Select(x => x.CPW_DATETIME).Min().AddMinutes(-30).ToString("yyyy-MM-dd HH:mm");
                string max_time = dt.Select(x => x.CPW_DATETIME).Max().AddMinutes(30).ToString("yyyy-MM-dd HH:mm");

                var yVal = dt.Select(e => e.CPW_PARAM_VAL).ToArray();

                string y_min = ((double)yVal.Min() - 10d / 100d * (double)yVal.Min()).ToString();
                string y_max = ((double)yVal.Max() + 10d / 100d * (double)yVal.Max()).ToString();




                //var clrtestValue = dt.Select(e => e.CLR_TEST_VALUE).ToArray();
                var min = (double)(dt.Select(x => x.CPW_PARAM_VAL).Min());
                var max = (double)(dt.Select(x => x.CPW_PARAM_VAL).Max());
                 Ymin = min - (10d / 100 * min);
                 Ymax = max + (10d / 100 * max);
                if (Ymax < (double)limit)
                {
                    //y_max = (double)limit;
                }


                if (true)
                {

                    //chartstrblt += "{name:'" + dt[1].CPW_PARAM_NAME + "',type:'line',data:[";
                    chartstrblt += "{name:'',type:'line',data:[";
                    for (int j = 0; j < dt.Count(); j++)
                    {
                        chartstrblt += "['" + ((DateTime)dt[j].CPW_DATETIME).ToString("yyyy-MM-dd HH:mm:ss") + "'," + dt[j].CPW_PARAM_VAL + "],";
                    }
                    chartstrblt += "]";

                    chartstrblt += " },";

                }
                else
                {

                }
            }
                
                    if (chartstrblt == "")
                    {
                        CHART_LP11 c1 = new CHART_LP11()
                        {
                            FromDate = "",
                            ID = idx.ToString(),
                            Title = P_Alias,
                            TypeX = "time",
                            TypeY = "Vlaue",
                            ShowLegend = "true",
                            Width = "",
                            ShowToolBox = "",
                            MaxAxisData = "",
                            MinAxisData = "",
                            SeriesData = "",
                            divcolsm = "6",
                            divHeight = "35vh"

                        };
                        lstChart.Add(c1);
                    }
                    else
                    {
                    CHART_LP11 c1 = new CHART_LP11()
                    {
                        FromDate = "",
                        ID = idx.ToString(),
                        Title = P_Alias,
                        TypeX = "time",
                        TypeY = "Vlaue",
                        ShowLegend = "true",
                        Width = "{yyyy}:{MM}:{dd}",
                        ShowToolBox = chartstrblt,
                        MaxAxisData = Convert.ToString(Ymax),
                        MinAxisData = Convert.ToString(Ymin),
                        SeriesData = "",
                        divcolsm = "6",
                        divHeight = "35vh"

                    };
                    lstChart.Add(c1);
                }
        }

        public void PlotLineChartBlank( String P_Alias, int idx)
        {

            CHART_LP11 c1 = new CHART_LP11()
            {
                FromDate = "",
                ID = idx.ToString(),
                Title = P_Alias + "--------No Data----------",
                TypeX = "time",
                TypeY = "Vlaue",
                ShowLegend = "true",
                Width = "",
                ShowToolBox = "",
                MaxAxisData = "",
                MinAxisData = "",
                SeriesData = "",
                divcolsm = "6",
                divHeight = "35vh"

            };
            lstChart.Add(c1);

        }

    }
}