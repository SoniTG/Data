﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;
using System.Web;
namespace PTG_TSJ_Main.BussinessLogic.PLTCM
{
    public class PLTCM_sub_chart
    {
        LP_PROCESS_DATA_v1Device_Counter dbWrmDevice_Counter = new LP_PROCESS_DATA_v1Device_Counter();
        List<CHART_LP11> lst1 = new List<CHART_LP11>();
        internal MultipleData GetDataForPLTCM_Sub_Chart(String LineName)
        {
            dbWrmDevice_Counter.Database.CommandTimeout = 180;
            var table = new MultipleData();

            string maxValue = "0.0";
            string maxLimit = "0.0";
            string ret = "[";
            string xaxis = "[";

            string q1 = $@"SELECT [PL_SL_NO],PL_MAX_LIMIT FROM [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_PLTCM_LIMITS] WHERE RTRIM(LTRIM([PL_ALIAS]))='{LineName}';";
            string q2 = $@"SELECT TOP 48 *  FROM [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_PLTCM_ENCODER_MAX] ORDER BY PEM_STARTTIME DESC";
            

            var dt1 = dbWrmDevice_Counter.Database.SqlQuery<Sub_Chart>(q1).ToArray();
            var dt2 = dbWrmDevice_Counter.Database.SqlQuery<Sub_Chart>(q2).ToArray();
            if (dt1.Length > 0)
            {
                int cnt = dt1[0].PL_SL_NO;
                maxLimit = dt1[0].PL_MAX_LIMIT.ToString();
                maxValue = maxLimit;
                for (int i = 0; i <= dt2.Length-1; i++)
                {
                    if (i > 0)
                    {
                        ret += ",";
                        xaxis += ",";
                    }
                    string signalval = "";
                    if (dt2[i].PEM_SPD_STDDEV_MAX.Contains(","))//dt1[i].PEM_SPD_STDDEV_MAX.ToString.Contains(",")
                    {
                        signalval = dt2[i].PEM_SPD_STDDEV_MAX.Split(new char[] { ',' })[cnt - 1];//ds.Tables(1).Rows(i)("PEM_SPD_STDDEV_MAX").ToString.Split(",")(cnt - 1)
                    }
                    else
                    {
                        signalval = "0";
                    }

                    ret += signalval;
                    if (Convert.ToDouble(signalval) > Convert.ToDouble(maxValue))
                        maxValue = Convert.ToDouble(signalval).ToString();
                    xaxis += "'" + Convert.ToDateTime(dt2[i].PEM_STARTTIME).ToString("MM-dd HH:mm") + "'";//ds.Tables(1).Rows(i)("PEM_STARTTIME")
                }
            }
            ret += "]";
            xaxis += "]";

            CHART_LP11 c10 = new CHART_LP11()
            {
                ID = "GS",
                Title = LineName,
                line1 = ret,
                line2 = xaxis,
                line3 = maxLimit,
                line4 = maxValue,
               
                


            };
            lst1.Add(c10);
            table.ChartData = lst1;
            return table;
        }
    }
}


