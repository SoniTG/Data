﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;
using System.Web;


namespace PTG_TSJ_Main.BussinessLogic.PLTCM
{
    public class PlTank
    {
        LP_PROCESS_DATA_v1Device_Counter dbWrmDevice_Counter = new LP_PROCESS_DATA_v1Device_Counter();
        List<CHART_LP11> lst1 = new List<CHART_LP11>();
        List<FromDateToDate> lst = new List<FromDateToDate>();
        PLTCM_Entity db_PLTCM_Menu = new PLTCM_Entity();

        string[] header = new string[] { "ACIDT1", "ACIDT2", "ACIDT3", "ACIDT4" };
        string[] headername = new string[] { "PL Tank1", "PL Tank3", "PL Tank3", "PL Tank4" };
        int[] red = new int[] { 3, 4, 6, 9 };
        int[] green = new int[] { 5, 6, 9, 12 };
        internal MultipleData GetDataForPlTank(String fromName1, String toName1)
        {
           
            var table = new MultipleData();
            string ToDate1 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            string FromDate1 = DateTime.Now.AddHours(-8).ToString("yyyy-MM-dd HH:mm:ss");

            //Declare DateTime Global And change String To DateTime;
            DateTime frmDate = new DateTime(2023, 06, 14, 11, 21, 59);

            DateTime toDate = new DateTime(2023, 06, 14, 11, 21, 59); ;
            if (fromName1 == null && toName1 == null)
            {
                fromName1 = DateTime.Now.AddHours(-8).ToString("yyyy-MM-dd HH:mm:ss");

                toName1 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                frmDate = DateTime.Parse(fromName1);
                toDate = DateTime.Parse(toName1);

            }
            else
            {
                ToDate1 = toName1;
                FromDate1 = fromName1;
                frmDate = DateTime.Parse(fromName1);

                toDate = DateTime.Parse(toName1);


            }

            List<FromDateToDate> lst = new List<FromDateToDate>();

            FromDateToDate c0 = new FromDateToDate()
            {

                FromDate = FromDate1,
                ToDate = ToDate1,
                FromDateName = "fromName1",
                ToDateName = "toName1",
                ID = "",
                todateId = "todateId1",
                FromdateId = "fromdateId2",
                Section = "",
                Heat = "Heat"

            };
            lst.Add(c0);

             DrawCharts(fromName1, toName1);
            
            
            //DrawCharts(ToDate1, FromDate1);


            table.FromDateToDate = lst;
            table.ChartData = lst1;
            return table;

            
        }
        private void DrawCharts(String fromName1, String toName1)
        {

            dbWrmDevice_Counter.Database.CommandTimeout = 180;

            for (int i = 0; i <= header.Length-1; i++)
            {
                try
                {

                    string q = $@"select  * from Openquery(CRM_ORACLE,'Select  CSE_TS_SAMPLING,CSR_TS_TEST,CSR_TEST_PARA,CSR_TEST_VAL,CSE_TS_TST_OVR FROM CRMDBA.t_CONS_RESULT  INNER JOIN CRMDBA.t_CONS_SAMPLE ON CSR_CD_CONSUMABLE = CSE_CD_CONSUMABLE  AND CSR_ID_SAMPLE = CSE_ID_SAMPLE AND CSR_CD_PROCESS= CSE_CD_PROCESS WHERE CSR_CD_PROCESS=''P''  AND CSR_TEST_PARA in (''{header[i]}'') and CSR_TS_TEST between ''{fromName1}'' and ''{toName1}'' ORDER BY CSE_TS_TST_OVR')";
                    var dt = dbWrmDevice_Counter.Database.SqlQuery<PLTANK>(q).ToArray();

                    PlotLineEChart(dt, "CSR_TS_TEST", "CSR_TEST_VAL", i);
                }
                catch (Exception ex)
                {

                }
                
            }



        }
        
        private void PlotLineEChart(PLTANK[] dt,String XAxisColName, String YAxisColName, int idx)
        {
            string data = null;
            string date_val = null;


            for (int I = 0; I <= dt.Length-1; I++)
            {

                string temp = dt[I].CSR_TEST_VAL.ToString();
                data += temp + ",";
                date_val += "'" + Convert.ToDateTime(dt[I].CSR_TS_TEST).ToString("dd-MMM-yy HH:mm") + "',";
            }
            CHART_LP11 c10 = new CHART_LP11()
            {

                ID = "cHart"+ idx,
                Title = headername[idx],
                line1 = data,
                line2 = date_val,
                line3 = Convert.ToString(red[idx]),
                line4 = Convert.ToString(green[idx]),
                line5="",


            };
            lst1.Add(c10);


        }
    }
}