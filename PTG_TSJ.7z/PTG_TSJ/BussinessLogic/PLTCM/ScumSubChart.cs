﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;
using System.Web;
namespace PTG_TSJ_Main.BussinessLogic.PLTCM
{
    public class ScumSubChart
    {
        LP_PROCESS_DATA_v1Device_Counter dbWrmDevice_Counter = new LP_PROCESS_DATA_v1Device_Counter();
        List<CHART_LP11> lst1 = new List<CHART_LP11>();
        internal MultipleData GetDataForScum_Sub_Chart(String subparam, String defect)
        {
            dbWrmDevice_Counter.Database.CommandTimeout = 180;
            var table = new MultipleData();
            //populateParameters();

            return table;
        }
        //public void populateParameters()
        //{
        //    //DataTable dt = objController.GetExcelData();
        //    GetExcelData()
        //    for (int c = 4, loopTo = dt.Columns.Count - 1; c <= loopTo; c++)
        //    {
        //        if (dt.columns(c).columnName.tostring.trim == "3-4BR current")
        //        {
        //            continue;
        //        }
        //        clbParamTest.Items.Add(new ListItem(getColumnAlias(dt.Columns(c).ColumnName), dt.Columns(c).ColumnName));
        //    }
        //}
        //public void GetExcelData(string hrcoilid="")
        //{
        //    DataTable dt;
        //    if (hrcoilid == "")
        //    {
        //        dt = data_Datahandler.Getsql_data("select top 1 raw_data_file,HR_COIL_ID From [FP_DEFECT_ANALYSIS].[dbo].[PL_DATA_COILWISE]");
        //    }
        //    else
        //    {
        //        dt = data_Datahandler.Getsql_data("select top 1 raw_data_file,HR_COIL_ID From [FP_DEFECT_ANALYSIS].[dbo].[PL_DATA_COILWISE] where [HR_COIL_ID]='" + hrcoilid + "'");
        //    }

        //}
    }
}


