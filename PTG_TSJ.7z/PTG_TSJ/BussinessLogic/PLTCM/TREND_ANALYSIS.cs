﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;
using System.Web;
using System.IO;
using OfficeOpenXml;


namespace PTG_TSJ_Main.BussinessLogic.PLTCM
{
    public class TREND_ANALYSIS
    {
        PLTCM_Entity db_PLTCM_Menu = new PLTCM_Entity();
        internal MultipleData GetDataForMillGlance()
        {
            var table = new MultipleData();
            string chartData = "var option={xAxis:{type:'category',data:['Mon','Tue','Wed','Thu','Fri','Sat','Sun']},yAxis:{type:'value'},series:[{data:[150,230,224,218,135,147,260],type:'line'}]};";
            return table;
        }
        internal string  Glancejsondata()
        {
            //var table = new MultipleData();
            //string chartData = "{xAxis:{type:'category',data:['Mon','Tue','Wed','Thu','Fri','Sat','Sun']},yAxis:{type:'value'},series:[{data:[150,230,224,218,135,147,260],type:'line'}]}";
            //return chartData;

            string pathDirectory1 = @"\\10.136.192.169\f\ImportantPrograms\TGWebPage\ld2viz";
            string[] pathDirectoris = { @"\\10.136.192.169\f\ImportantPrograms\TGWebPage\fpwebsite", @"\\10.136.192.169\f\ImportantPrograms\TGWebPage\ld2viz", @"\\10.136.192.169\f\ImportantPrograms\TGWebPage\ld3caster\ld3caster080518", @"\\10.136.192.169\f\ImportantPrograms\TGWebPage\lpwebsite", @"\\10.136.192.169\f\ImportantPrograms\TGWebPage\Metallurgical_Tools", @"\\10.136.192.169\f\ImportantPrograms\TGWebPage\MMONLINEDATA", @"\\10.136.192.169\f\ImportantPrograms\TGWebPage\TG_SMS_Service_v2", @"\\10.136.192.169\f\ImportantPrograms\TGWebPage\TSM" };
            string[] pathPtg = { @"\\10.136.192.169\f\ImportantPrograms\TGWebPage\PTG", @"\\10.136.192.169\f\ImportantPrograms\TGWebPage\PTG\defectanalysis", @"\\10.136.192.169\f\ImportantPrograms\TGWebPage\PTG\defectanalysisdev", @"\\10.136.192.169\f\ImportantPrograms\TGWebPage\PTG\RCIL", @"\\10.136.192.169\f\ImportantPrograms\TGWebPage\PTG\technocric", @"\\10.136.192.169\f\ImportantPrograms\TGWebPage\PTG\tsk", @"\\10.136.192.169\f\ImportantPrograms\TGWebPage\PTG\tsm", @"\\10.136.192.169\f\ImportantPrograms\TGWebPage\PTG\Welder" };
            if (Directory.Exists(pathDirectory1))
            {
                
                ExcelPackage.LicenseContext = LicenseContext.Commercial;
                using (ExcelPackage excelPackege= new ExcelPackage())
                {
                    ExcelWorksheet workSheet = excelPackege.Workbook.Worksheets.Add("All_aspx_page");
                    for (int i = 0; i < pathPtg.Count(); i++)
                    {

                        List<string> pageName = new List<string>();
                        //string pathDirectory = @"\\10.136.192.169\f\ImportantPrograms\TGWebPage\lpwebsite";
                        string filePathExcel = @"E:\Ranjan\AllPagesName\tgWebsiteAllPagesNamePTG11.xlsx";
                        string[] aspxFiles = Directory.GetFiles(pathPtg[i], "*.aspx", SearchOption.AllDirectories);
                        foreach (string file in aspxFiles)
                        {
                            string fileName = Path.GetFileNameWithoutExtension(file);
                            pageName.Add(fileName);
                        }
                       
                        string[] splitdata = pathPtg[i].Split('\\');
                        var data = splitdata[splitdata.Length - 1];
                        //string[] fruitArray = pathDirectoris[i].Split(new char[] { '\\' },
                        workSheet.Cells[1, i+1].Value = splitdata[splitdata.Length-1];
                        for (int j = 1; j < pageName.Count(); j++)
                        {

                            workSheet.Cells[j + 2, i+1].Value = pageName[j];
                        }
                        FileInfo excelFile = new FileInfo(filePathExcel);
                        excelPackege.SaveAs(excelFile);
                    }
                    
                }
            }
            var table = new MultipleData();
            string chartData = "{xAxis:{type:'category',data:['Mon','Tue','Wed','Thu','Fri','Sat','Sun']},yAxis:{type:'value'},series:[{data:[150,230,224,218,135,147,260],type:'line'}]}";
            return chartData;
        }
    }
}