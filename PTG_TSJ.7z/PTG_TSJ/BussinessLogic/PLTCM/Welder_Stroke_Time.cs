﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;
using System.Web;


namespace PTG_TSJ_Main.BussinessLogic.PLTCM
{
    public class Welder_Stroke_Time
    {
        
        List<CardData> CardList = new List<CardData>();
        internal MultipleData GetDataForWelder_Stroke_Time()
        {

            string[] SelectImagePath = { "/PTG_TSJ/Content/dist/img/pg2_live_img.png",
                                         "/PTG_TSJ/Content/dist/img/pg2_Dash_img.png",
                                         "/PTG_TSJ/Content/dist/img/main_tenance.png"
                                       };
            string[] SelectionImgageName = { "Live Trend", "Dashboard", "Maintenance Interventions"};
            string[] SelectionBtnId = { "Pltcm_stroketimeChart/PLTCM", "ComingSoon/PLTCM", "ComingSoon/PLTCM" };

            for(int i=0;i< SelectImagePath.Length; i++)
            {
                CardData c0 = new CardData()
                {

                    ImgagePath = SelectImagePath[i],
                    ImgageName = SelectionImgageName[i],
                    BtnId = SelectionBtnId[i],

                };
                CardList.Add(c0);
            }
            

            var table = new MultipleData();
            table.CardData = CardList;
            return table;
        }
    }
}