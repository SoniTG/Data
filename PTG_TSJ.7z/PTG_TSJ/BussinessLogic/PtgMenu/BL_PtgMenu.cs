﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;
using System.Web;
namespace PTG_TSJ_Main.BussinessLogic.PtgMenu
{
    public class BL_PtgMenu
    {
        //PTG_MenuEntity11 dbPtgMenu = new PTG_MenuEntity11();
        PTG_WEBSITEEntities dbPtgMenu = new PTG_WEBSITEEntities();
        internal MultipleData GetDataForDeviceCounter(String PMD_MAIN_AREA, String PMD_MAIN_AREA_ID, String PMD_SUB_AREA, String PMD_SUB_AREA_ID, String PMD_MAIN_DIV, String PMD_MAIN_DIV_ID, String PMD_SUB_DIV, String PMD_SUB_DIV_ID, String ColorName)
        {
            var table = new MultipleData();


            //for data charrt
            var PtgMenu = (from x in dbPtgMenu.PTG_MASTER_DATA
             select new { x.PMD_MAIN_AREA,x.PMD_MAIN_AREA_ID }).Distinct().ToList();

            List<PtgMainMenuString> Str = new List<PtgMainMenuString>();
            var PtgMenu1 = (from x in dbPtgMenu.PTG_MASTER_DATA
                           select new { x.PMD_MAIN_AREA, x.PMD_MAIN_AREA_ID }).Distinct().ToList();


            string datChartButton = "";
            datChartButton = "{\"name\":\"PTG\",";
            datChartButton += "\"children\": [  ";
            if (PtgMenu1.Count() > 0)
            {
                for (int i = 0; i < PtgMenu.Count; i++)
                {
                    datChartButton += "{\"name\": '" + PtgMenu1[i].PMD_MAIN_AREA + "',";

                    int areaid = PtgMenu1[i].PMD_MAIN_AREA_ID;
                    var PtgMenuSub = (from x in dbPtgMenu.PTG_MASTER_DATA
                                    .Where(y => y.PMD_MAIN_AREA_ID == areaid)
                                    .OrderBy(item => item.PMD_MAIN_AREA_ID)
                                      select new { x.PMD_SUB_AREA, x.PMD_SUB_AREA_ID }).Distinct().ToList();
                    datChartButton += "\"children\": [  ";
                    if (PtgMenuSub.Count() > 0)
                    {
                        for (int j = 0; j < PtgMenuSub.Count; j++)
                        {
                            datChartButton += "{\"name\": '" + PtgMenuSub[j].PMD_SUB_AREA + "',";
                            int areaid1 = PtgMenu1[i].PMD_MAIN_AREA_ID;
                            int Sareaid1 = PtgMenuSub[j].PMD_SUB_AREA_ID;
                            var PtgMenuSub1 = (from x in dbPtgMenu.PTG_MASTER_DATA
                                            .Where(y => y.PMD_MAIN_AREA_ID == areaid &&  y.PMD_SUB_AREA_ID == Sareaid1)
                                            .OrderBy(item => item.PMD_MAIN_DIV_ID)
                                              select new { x.PMD_MAIN_DIV, x.PMD_MAIN_DIV_ID }).Distinct().ToList();
                            datChartButton += "\"children\": [  ";
                            if (PtgMenuSub1.Count() > 0)
                            {
                                for (int k = 0; k < PtgMenuSub1.Count; k++)
                                {
                                    datChartButton += "{\"name\": '" + PtgMenuSub1[k].PMD_MAIN_DIV + "',";

                                    int areaiddiv1 = PtgMenu1[i].PMD_MAIN_AREA_ID;
                                    int Sareaiddiv1 = PtgMenuSub[j].PMD_SUB_AREA_ID;
                                    int Dareaiddiv1 = PtgMenuSub1[j].PMD_MAIN_DIV_ID;
                                    var PtgMenuSubdiv1 = (from x in dbPtgMenu.PTG_MASTER_DATA
                                                    .Where(y => y.PMD_MAIN_AREA_ID == areaid && y.PMD_SUB_AREA_ID == Sareaid1 && y.PMD_MAIN_DIV_ID == Dareaiddiv1)
                                                       select new { x.PMD_SUB_DIV, x.PMD_SUB_DIV_ID,x.PMD_CONTROLLER,x.PMD_ACTION_MTD }).Distinct().OrderBy(item => item.PMD_SUB_DIV_ID).ToList();
                                    datChartButton += "\"children\": [  ";
                                    if (PtgMenuSubdiv1.Count() > 0)
                                    {
                                        for (int m = 0; m < PtgMenuSubdiv1.Count; m++)
                                        {
                                            datChartButton += "{\"name\": '" + PtgMenuSubdiv1[m].PMD_SUB_DIV + "',";
                                            datChartButton += "\"ControllerName\": '" + PtgMenuSubdiv1[m].PMD_CONTROLLER + "',";
                                            datChartButton += "\"ActionName\": '" + PtgMenuSubdiv1[m].PMD_ACTION_MTD + "',";

                                            datChartButton += "},";
                                        }
                                        datChartButton += "]";
                                    }
                                    datChartButton += "},";
                                }
                                datChartButton += "]";
                            }
                            datChartButton += "},";
                        }
                        datChartButton += "]";
                    }

                    datChartButton += "},";
                }
                datChartButton += "]}";
            }

            PtgMainMenuString c1 = new PtgMainMenuString()
            {
                PMD_MAIN_AREA_String = datChartButton,

            };
            Str.Add(c1);
            
            table.PtgMainMenuString = Str;
            return table;
        }
    }
}


//List<PtgMainMenu> lst = new List<PtgMainMenu>();


//var PtgMenu = (from x in dbPtgMenu.PTG_MASTER_DATA
//              select new { x.PMD_MAIN_AREA,x.PMD_MAIN_AREA_ID }).Distinct().ToList();
//string[] ColorName1 = { "#9370DB", "#008000", "#DC143C", "#48D1CC", "#FF4500", "#00BFFF", "#9310DB", "#008000", "#DA143C", "#48D1CC", "#FF2200", "#22BFFF" };

//for (int i = 0; i < PtgMenu.Count; i++)
//{
//    PtgMainMenu c0 = new PtgMainMenu()
//    {
//        PMD_MAIN_AREA = PtgMenu[i].PMD_MAIN_AREA,
//        PMD_MAIN_AREA_ID = Convert.ToString(PtgMenu[i].PMD_MAIN_AREA_ID),
//        PMD_SUB_AREA1 = "PMD_SUB_AREA",
//        PMD_MAIN_DIV1 = "",
//        PMD_SUB_DIV1 = "",
//        PMD_MAIN_AREA1 = "",
//        ColorName = ColorName1[i]

//    };
//    lst.Add(c0);
//}


//if (PMD_SUB_AREA !=null && PMD_SUB_AREA != "")
//{
//    for (int i = 0; i < PtgMenu.Count; i++)
//    {
//        PtgMainMenu c0 = new PtgMainMenu()
//        {
//            PMD_MAIN_AREA = PtgMenu[i].PMD_MAIN_AREA,
//            PMD_MAIN_AREA_ID = Convert.ToString(PtgMenu[i].PMD_MAIN_AREA_ID),
//            PMD_SUB_AREA1 = "PMD_MAIN_DIV",
//            PMD_MAIN_DIV1 = "",
//            PMD_SUB_DIV1 = "",
//            PMD_MAIN_AREA1 = "",
//            ColorName = ColorName1[i]

//        };
//        lst.Add(c0);
//    }
//}