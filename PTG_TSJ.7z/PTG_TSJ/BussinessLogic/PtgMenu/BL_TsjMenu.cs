﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;
using System.Web;

namespace PTG_TSJ_Main.BussinessLogic.PtgMenu
{
    
    public class BL_TsjMenu
    {
        PTG_WEBSITEEntities dbPtgMenu = new PTG_WEBSITEEntities();
        List<MenuBoxes> lst_Boxes = new List<MenuBoxes>();
        internal MultipleData GetDataForTsjMenu()
        {
            
            var table = new MultipleData();
            BoxesData("TSJ", "LP");
            BoxesData("TSJ", "FP");
            table.MenuBoxes = lst_Boxes;
            return table;
        }

        public void BoxesData(String MainArea, String catgry)
        {

            string q = $@"SELECT DISTINCT PMD_MAIN_DIV,PMD_MAIN_DIV_CONTROLLER,PMD_MAIN_ACTION_MTD,PMD_MAIN_DIV_ID  FROM [PTG_WEBSITE].[dbo].[PTG_MASTER_DATA] where [PMD_MAIN_AREA]='{MainArea}' AND PMD_SUB_AREA='{catgry}' Order By PMD_MAIN_DIV_ID;";
            var dt = dbPtgMenu.Database.SqlQuery<BoxesData>(q).ToArray();
            var id = "";
            string box_Image = "";
            if (catgry == "LP")
            {
                box_Image = "/Content/dist/img/rolling_image.jpg";
            }
            if (catgry == "FP")
            {
                box_Image = "/Content/dist/img/Flat_Image.jpg";
            }

            var box_color = "";
            var box_Name = "";
            for (int i = 0; i < dt.Length; i++)
            {

                string q1 = $@"SELECT PMD_COLOR  FROM [PTG_WEBSITE].[dbo].[PTG_MASTER_DATA] where [PMD_MAIN_DIV]='{dt[i].PMD_MAIN_DIV}' ;";
                var dt1 = dbPtgMenu.Database.SqlQuery<BoxesData>(q1).ToArray();
                var idData = dt[i].PMD_MAIN_DIV_CONTROLLER + "&&" + dt[i].PMD_MAIN_ACTION_MTD;
                id = idData;
                
                box_color = "";
                box_Name = dt[i].PMD_MAIN_DIV;

                MenuBoxes c10 = new MenuBoxes()
                {
                    Box_id = id,
                    Box_catgry = catgry,
                    Box_Color = dt1[0].PMD_COLOR,
                    Box_Name = box_Name,
                    Box_Image= catgry,
                };
                lst_Boxes.Add(c10);
            }
            



        }

    }
}