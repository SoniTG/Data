﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;
using System.Web;

namespace PTG_TSJ_Main.BussinessLogic.PtgMenu
{
    public class CRMmenu
    {
        PTG_WEBSITEEntities dbPtgMenu = new PTG_WEBSITEEntities();
        List<MenuBoxes> lst_Boxes = new List<MenuBoxes>();
        internal MultipleData GetDataForTsjMenu()
        {

            var table = new MultipleData();
            BoxesData();
           
            table.MenuBoxes = lst_Boxes;
            return table;
        }

        public void BoxesData()
        {



            string q = $@"SELECT DISTINCT PMD_CONTROLLER,PMD_SUB_DIV_ID,PMD_ACTION_MTD  FROM [PTG_WEBSITE].[dbo].[PTG_MASTER_DATA] where [PMD_MAIN_AREA]='TSJ' AND PMD_SUB_AREA='FP'AND [PMD_MAIN_DIV] ='CRM'Order By PMD_SUB_DIV_ID;";
            var dt = dbPtgMenu.Database.SqlQuery<BoxesData>(q).ToArray();
            var id = "";
            string box_Image = "/Content/dist/img/rolling_image.jpg";
            var box_color = "";
            var box_Name = "";
            for (int i = 0; i < dt.Length; i++)
            {
                string q1 = $@"SELECT PMD_COLOR  FROM [PTG_WEBSITE].[dbo].[PTG_MASTER_DATA] where [PMD_MAIN_AREA]='TSJ' AND [PMD_CONTROLLER]='{dt[i].PMD_CONTROLLER}' ;";
                var dt1 = dbPtgMenu.Database.SqlQuery<BoxesData>(q1).ToArray();

                var idData = dt[i].PMD_CONTROLLER + "&&" + dt[i].PMD_ACTION_MTD;
                id = idData;

                box_color = dt1[0].PMD_COLOR;
                box_Name = dt[i].PMD_CONTROLLER;

                MenuBoxes c10 = new MenuBoxes()
                {
                    Box_id = id,
                    Box_catgry = "",
                    Box_Color = box_color,
                    Box_Name = box_Name,
                    Box_Image = "FP",
                };
                lst_Boxes.Add(c10);
            }
            

        }

    }
}