﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;
using System.Web;
namespace PTG_TSJ_Main.BussinessLogic.SIDE_MENU
{
    public class SIDE_MENU_DATA
    {
        PTG_WEBSITEEntities1 DB_SIDE_Menu_DATA = new PTG_WEBSITEEntities1();
       public List<SideMenu> GetSIdeMenuDAta(String PLANTNAME)
        {

            List<SideMenu> Lst = new List<SideMenu>();

            var PtgMenu = (from x in DB_SIDE_Menu_DATA.Side_Menu.Where(e=>e.SIDE_Plant_Name== PLANTNAME)
                           select new { x.SIDE_MAIN_MENU_ID, x.SIDE_MAIN_MENU }).Distinct().OrderBy(x => x.SIDE_MAIN_MENU_ID).ToList();
            for (int k = 0; k < PtgMenu.Count; k++)
            {

                var data = PtgMenu[k].SIDE_MAIN_MENU_ID;
                
                var PtgMenuSub = (from x in DB_SIDE_Menu_DATA.Side_Menu.Where(e => e.SIDE_MAIN_MENU_ID == data && e.SIDE_Plant_Name == PLANTNAME)
                                  select new { x.SIDE_MAIN_URL_ID, x.SIDE_SUB_MENU, x.SIDE_MAIN_URL, x.SIDE_SUB_CONTROLLER,x.SIDE_SUB_MENU_ID }).Distinct().OrderBy(x => x.SIDE_SUB_MENU_ID).ToList();
                string[] ArraMenuSize = new string[PtgMenuSub.Count()];
                string[] ActionN = new string[PtgMenuSub.Count()];
                string[] ContrlN = new string[PtgMenuSub.Count()];

                if (PtgMenuSub.Count() > 0)
                {
                    for (int m = 0; m < PtgMenuSub.Count; m++)
                    {
                        ArraMenuSize[m] = PtgMenuSub[m].SIDE_SUB_MENU;
                        ActionN[m] = PtgMenuSub[m].SIDE_MAIN_URL;
                        ContrlN[m] = PtgMenuSub[m].SIDE_SUB_CONTROLLER;
                    }

                }
                SideMenu c1 = new SideMenu()
                {
                    MainMenu = PtgMenu[k].SIDE_MAIN_MENU,
                    SubMenu = ArraMenuSize,
                    ActionName = ActionN,
                    ControllerName = ContrlN,

                };
                Lst.Add(c1);
            }


            return Lst;
        }
    }
}


