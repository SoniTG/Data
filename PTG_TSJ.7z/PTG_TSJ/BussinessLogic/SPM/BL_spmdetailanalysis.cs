﻿using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;

namespace PTG_TSJ_Main.BussinessLogic.SPM
{
    public class BL_spmdetailanalysis
    {
        LP_PROCESS_DATA_v1Device_Counter dbWrmDevice_Counter = new LP_PROCESS_DATA_v1Device_Counter();
        List<CheckBoxData> Checklst1 = new List<CheckBoxData>();
        List<RedioButtonData> RedioButton1 = new List<RedioButtonData>();
        List<RedioButtonData> lstradio = new List<RedioButtonData>();
        List<SelectOption> SltOption = new List<SelectOption>();
        List<ModelBox> inputbox = new List<ModelBox>();
        List<CHART_LP11> lst11 = new List<CHART_LP11>();
        internal MultipleData GetDataForSPMdetailAnalysis(String fromName1, String toName1, String inlineRadioOptions,String TDS,String GREAD, String CoilIDText, String[] COILName, String[] TestParameterName)
        {
            
            var table = new MultipleData();
            if (fromName1 == null && toName1 == null)
            {
                fromName1 = DateTime.Now.AddDays(-244).ToString("yyyy-MM-dd HH:mm:ss");

                toName1 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            }

            List<FromDateToDate> lst = new List<FromDateToDate>();

            FromDateToDate c0 = new FromDateToDate()
            {

                FromDate = fromName1,
                ToDate = toName1,
                FromDateName = "fromName1",
                ToDateName = "toName1",
                ID = "",
                todateId = "todateId1",
                FromdateId = "fromdateId2",
                Section = "",
                Heat = "Heat"

            };
            lst.Add(c0);
            //RadioButtion
            RadioButtonClickOption(inlineRadioOptions);
            //CoilParameter
            
            
            //ForGread
            DropDownGread(fromName1, toName1);
            //ForTDC
            if(TDS!=null && TDS != "All")
            {
               DropDownTDC(fromName1, toName1, TDS, GREAD);
            }else
            {
                DropDownTDC(fromName1, toName1, "All","All");
            }

            //ForInputFilledBox
            if (TDS != null && TDS != "All")
            {
                inputBoxfillData(fromName1, toName1, TDS, GREAD, inlineRadioOptions, CoilIDText, TestParameterName, COILName);
            }
            else
            {
                inputBoxfillData(fromName1, toName1, "", "", inlineRadioOptions, CoilIDText, TestParameterName, COILName);
            }

            ////For Chart
            if (TestParameterName != null  && COILName != null )
            {
                SelectParamAndCoil(fromName1, toName1, COILName,  TestParameterName);
            }
           


            table.ModelData = inputbox;
            table.SelectOption = SltOption;
            table.RedioButtonData = lstradio;
            table.CheckBoxData = Checklst1;
            table.ChartData = lst11;
            table.FromDateToDate = lst;
          
            return table;
           
        }
        private void CoilPrmter(String fromName1, String toName1, String RedioOption,String TDSCoilID,String filter, String CoilIDText, String[] TestParameterName, String[] COILName)
        {

            dbWrmDevice_Counter.Database.CommandTimeout = 180;


            
            if (RedioOption == "DateWise")
            {
                CoilIDParameter(fromName1, toName1, RedioOption, TDSCoilID, filter, COILName);
                
            }
            if (RedioOption == "CoilWise")
            {
                SearchCoilId(CoilIDText, RedioOption);
               
            }
            
            string q2 = $@" select 'S11_SPEED_ACT' as C1,'S11 Speed Act' as C2 union  select 'S11_SPEED_ACT' as C1,'S11 Speed Act' as C2 union  select 'C90_COILER_SPEED_ACT' as C1,'C90 Coiler Speed Act' as C2   union select 'ENLONGATION_ACT' as C1,'Elongation Act' as C2 union select 'ROLLFORCE' as C1,'Rollforce' as C2 union select 'ROLLFORCE_DS' as C1,'Rollforce Ds' as C2 union select 'ROLLFORCE_OS' as C1,'Rollforce Os' as C2 union select 'WORK_ROLL_BEND_POS_SET' as C1,'Work Roll Bend Pos Set' as C2 union select 'WORK_ROLL_BEND_POS_ACT' as C1,'Work Roll Bend Pos Act' as C2 union select 'WORK_ROLL_BEND_NEG_SET' as C1,'Work Roll Bend Neg Set' as C2 union select 'WORK_ROLL_BEND_NEG_ACT' as C1,'Work Roll Bend Neg Act' as C2 union select 'ROLL_GAP_DS' as C1,'Roll Gap Ds' as C2 union select 'ROLL_GAP_OS'as C1,'Roll Gap Os' as C2 union select 'TENSION_POR_ENTRY_REF' as C1,'Tension Por Entry Ref' as C2 union select 'TENSION_POR_ENTRY' as C1,'Tension Por Entry' asC2 union select 'TENSION_TR' as C1,'Tension Tr' as C2 union select 'UNIT_TENSION_POR_ENTRY_REF' as C1,'Unit Tension Por Entry Ref' as C2 union select 'UNIT_TENSION_POR_ENTRY' as C1,'Unit Tension Por Entry' as C2  union select 'UNIT_TENSION_TR' as C1,'Unit Tension Tr' as C2";
            var dt2 = dbWrmDevice_Counter.Database.SqlQuery<SpmDetailsAnls>(q2).ToArray();


            var C1 = dt2.Select(e => e.C1).ToArray();
            var C2 = dt2.Select(e => e.C2).ToArray();
            string[] CheckedData = new string[dt2.Length];

            int CountArray = dt2.Length;
            string[] P_Test = new string[CountArray];
            string[] CLR_P_Test = new string[CountArray];
            string[] ChecedData = new string[CountArray];
            string[] ChecedData1 = new string[CountArray];
            for (int i = 0; i < dt2.Length; i++)
            {
                P_Test[i] = C1[i];
                CLR_P_Test[i] = C2[i];
            }

            if (TestParameterName != null)
            {
                for (int i = 0; i < TestParameterName.Length; i++)
                {
                    ChecedData[i] = TestParameterName[i];
                }

                for (int i = 0; i < TestParameterName.Length; i++)
                {
                    for (int j = 0; j < C1.Length; j++)
                    {
                        string d1 = P_Test[j];
                        string d2 = ChecedData[i];
                        if (d1 == d2)
                        {
                            //ChecedData[j] = CLR_P_Test[j]+"@";
                            ChecedData1[j] = "A";
                        }

                    }
                }

            }
            CheckBoxData c10 = new CheckBoxData()
            {
                CheckBoxValue = C2,
                CheckBoxName = C1,
                DrplData = RedioOption,
                CheckBoxChecked = ChecedData1,
                BtnData = "A",
                SelectName="TestParameterName"
            };
            Checklst1.Add(c10);
        }

        private void RadioButtonClickOption(String inlineRadioOptions)
        {
            if (inlineRadioOptions == "CoilWise")
            {
                RedioButtonData c11 = new RedioButtonData()
                {
                    Valuedata = "CoilWise",
                    Labledata = "CoilWise",
                    Forchecked = "A",
                    Forchecked1 = "CoilWise"
                };
                lstradio.Add(c11);
                RedioButtonData c12 = new RedioButtonData()
                {
                    Valuedata = "DateWise",
                    Labledata = "DateWise",
                    Forchecked = "",
                    Forchecked1 = "CoilWise"
                };
                lstradio.Add(c12);
            }

            if (inlineRadioOptions == null || inlineRadioOptions == "DateWise")
            {
                RedioButtonData c11 = new RedioButtonData()
                {
                    Valuedata = "CoilWise",
                    Labledata = "CoilWise",
                    Forchecked = "",
                    Forchecked1 = "DateWise"
                };
                lstradio.Add(c11);
                RedioButtonData c12 = new RedioButtonData()
                {
                    Valuedata = "DateWise",
                    Labledata = "DateWise",
                    Forchecked = "A",
                    Forchecked1 = "DateWise"

                };
                lstradio.Add(c12);
            }

        }
        private void DropDownGread(String fromName1, String toName1)
        {
            dbWrmDevice_Counter.Database.CommandTimeout = 180;
            string q1 = $@"SELECT distinct GRADE from [FP_PROCESS_DATA].[dbo].CRM_SPM_PROCESS_DATA_COILWISE_BODY where COIL_STARTDATETIME between '{fromName1}' and '{toName1}' and (GRADE <> '0' and GRADE is not null) ORDER BY GRADE";
            var dt1 = dbWrmDevice_Counter.Database.SqlQuery<SpmDetailsAnls>(q1).ToArray();
            string SectionDataString = "";
            if (dt1.Length > 0)
            {
                for (var i = 0; i < dt1.Length; i++)
                {
                    SectionDataString += dt1[i].GRADE + ",";
                }
            }

            if (dt1.Length > 0)
            {
                SelectOption cs1 = new SelectOption()
                {
                    SectionData = SectionDataString,
                    ForOptCondition = "GRADE",
                };
                SltOption.Add(cs1);
            }
            else
            {
                SelectOption cs1 = new SelectOption()
                {
                    SectionData = "",
                    ForOptCondition = "GRADE",
                };
                SltOption.Add(cs1);
            }

        }
        private void DropDownTDC(String fromName1, String toName1, String TDS, String GREAD)
        {

            string filter = "";
            if (GREAD != "All")
            {
                if (GREAD != "")
                {
                    filter += " and GRADE = '" + GREAD + "'";
                }
            }

            string q11 = $@"SELECT distinct TDC_No from[FP_PROCESS_DATA].[dbo].CRM_SPM_PROCESS_DATA_COILWISE_BODY where COIL_STARTDATETIME between '{fromName1}' and '{toName1}' and(TDC_No<> '0' and TDC_No is not null and TDC_No <> '') {filter} order by TDC_No";
            var dt11 = dbWrmDevice_Counter.Database.SqlQuery<SpmDetailsAnls>(q11).ToArray();
            string SectionDataString1 = "";
            if (dt11.Length > 0)
            {
                for (var i = 0; i < dt11.Length; i++)
                {
                    SectionDataString1 += dt11[i].TDC_No + ",";

                }
            }

            if (dt11.Length > 0)
            {
                SelectOption cs2 = new SelectOption()
                {
                    SectionData = SectionDataString1,
                    ForOptCondition = "TDC_No",
                    ForSelected = TDS,
                };
                SltOption.Add(cs2);
            }
            else
            {
                SelectOption cs2 = new SelectOption()
                {
                    SectionData = "",
                    ForOptCondition = "TDC_No",
                    ForSelected = TDS,
                };
                SltOption.Add(cs2);
            };
        }
        private void inputBoxfillData(String fromName1, String toName1, String TDS, String GREAD,String inlineRadioOptions,String  CoilIDText, String[] TestParameterName, String[] COILName)
        {


            var dt111=ThiknessPrameter(fromName1, toName1,TDS, GREAD);
            var dt114=WidthParameter(fromName1, toName1,TDS, GREAD, dt111[0].Min.ToString(), dt111[0].Max.ToString());

            string filter = " 1=1";
            //if (GREAD != "All" && GREAD != "")
            //{
            //    filter += " and GRADE = '" + GREAD + "'";
            //}
            //if (TDS != "All" && TDS != "")
            //{
            //    filter += " and TDC_No = '" + TDS + "'";
            //}
            if (dt111[0].Min.ToString() != "" && dt111[0].Max.ToString() != "")
            {
                filter += " and THICKNESS between " + dt111[0].Min.ToString() + " and " + dt111[0].Max.ToString() + "";

            }
            if (dt111[0].Min.ToString() != "" && dt111[0].Max.ToString() != "")
            {
                filter += " and WIDTH between " + dt114[0].Min.ToString() + " and " + dt114[0].Max.ToString() + "";

            } 

            if (inlineRadioOptions == null || inlineRadioOptions == "DateWise")
            {
                if (TDS != null && TDS != "All")
                {
                    CoilPrmter(fromName1, toName1, "DateWise", TDS, filter, CoilIDText, TestParameterName, COILName);
                }
                else
                {
                    CoilPrmter(fromName1, toName1, "DateWise", "All", filter, CoilIDText, TestParameterName, COILName);
                }

            }
            if (inlineRadioOptions == "CoilWise")
            {
                CoilPrmter(fromName1, toName1, "CoilWise", "", filter, CoilIDText, TestParameterName, COILName);
            }



            ModelBox cs3 = new ModelBox()
            {
                ModelName = dt111[0].Min.ToString(),
                LgUserName = dt111[0].Max.ToString(),
                LgPassword = Math.Round(dt114[0].Min * 1000, 0).ToString(),
                ButtonName = Math.Round(dt114[0].Max * 1000, 0).ToString(),
            };
            inputbox.Add(cs3);

        }
        private void CoilIDParameter(String fromName1, String toName1, String RedioOption, String TDSCoilID,String filter,String[] COILName)
        {

            string q1 = $@"SELECT  DAUGHTER_COILID_NUM,DAUGHTER_COILID_NUM + '#' + CONVERT(VARCHAR,COIL_STARTDATETIME,120) as VALCOILID from [FP_PROCESS_DATA].[dbo].[CRM_SPM_PROCESS_DATA_COILWISE_BODY] where COIL_STARTDATETIME between '{fromName1}' and '{toName1}' and (DAUGHTER_COILID_NUM <> '0' and DAUGHTER_COILID_NUM is not null) and  {filter} ORDER BY COIL_STARTDATETIME";
            var dt1 = dbWrmDevice_Counter.Database.SqlQuery<SpmDetailsAnls>(q1).ToArray();
            var DAUGHTER_COILID_NUM = dt1.Select(e => e.DAUGHTER_COILID_NUM).ToArray();
            var VALCOILID = dt1.Select(e => e.VALCOILID).ToArray();

            string[] ChecedData1 = new string[dt1.Length];

            

            int CountArray = dt1.Length;
            string[] P_Test = new string[CountArray];
            string[] CLR_P_Test = new string[CountArray];
            string[] ChecedData = new string[CountArray];
           
            for (int i = 0; i < dt1.Length; i++)
            {
                P_Test[i] = DAUGHTER_COILID_NUM[i];
                CLR_P_Test[i] = VALCOILID[i];
            }

            if (COILName != null)
            {
                for (int i = 0; i < COILName.Length; i++)
                {
                    ChecedData[i] = COILName[i];
                }

                for (int i = 0; i < COILName.Length; i++)
                {
                    for (int j = 0; j < DAUGHTER_COILID_NUM.Length; j++)
                    {
                        string d1 = CLR_P_Test[j];
                        string d2 = ChecedData[i];
                        if (d1 == d2)
                        {
                            //ChecedData[j] = CLR_P_Test[j]+"@";
                            ChecedData1[j] = "A";
                        }

                    }
                }

            }
            CheckBoxData c11 = new CheckBoxData()
            {
                CheckBoxValue = DAUGHTER_COILID_NUM,
                CheckBoxName = VALCOILID,
                DrplData = RedioOption,
                CheckBoxChecked = ChecedData1,
                SelectName = "COILName"
            };
            Checklst1.Add(c11);
        }

        private SpmDetailsAnls[] WidthParameter(String fromName1, String toName1, String TDS, String GREAD,String TThikness1, String TThikness2)
        {
            string filter = "";

            if (GREAD != "All" && GREAD != "")
            {
                if (GREAD != "")
                {
                    filter += " and GRADE = '" + GREAD + "'";
                }
            }
            else
            {
                filter += " and 1=1";
            }
            if (TDS != "All")
            {
                if (TDS != "")
                {
                    filter += " and TDC_No = '" + TDS + "'";
                }
                else
                {
                    filter += " and 1=1";
                }
            }
            if (TThikness1 != "" && TThikness2 != "")
            {

                filter += "  and THICKNESS between " + TThikness1 + " and " + TThikness2 + "";



            }
            string q114 = $@"SELECT min(WIDTH) as Min,max(WIDTH) as Max from [FP_PROCESS_DATA].[dbo].CRM_SPM_PROCESS_DATA_COILWISE_BODY where COIL_STARTDATETIME between '{fromName1}' and '{toName1}'   {filter}";
            var dt114 = dbWrmDevice_Counter.Database.SqlQuery<SpmDetailsAnls>(q114).ToArray();
            return dt114;
        }
        private SpmDetailsAnls[] ThiknessPrameter(String fromName1, String toName1, String TDS, String GREAD)
        {
            string filter = "";

            if (GREAD != "All" && GREAD != "")
            {
                if (GREAD != "")
                {
                    filter += " and GRADE = '" + GREAD + "'";
                }
            }
            else
            {
                filter += " and 1=1";
            }
            if (TDS != "All")
            {
                if (TDS != "")
                {
                    filter += " and TDC_No = '" + TDS + "'";
                }
                else
                {
                    filter += " and 1=1";
                }
            }
            string q111 = $@"SELECT min(THICKNESS) as Min, max(THICKNESS) as Max from[FP_PROCESS_DATA].[dbo].CRM_SPM_PROCESS_DATA_COILWISE_BODY where COIL_STARTDATETIME between '{fromName1}' and '{toName1}'  {filter}";
            var dt111 = dbWrmDevice_Counter.Database.SqlQuery<SpmDetailsAnls>(q111).ToArray();

            return dt111;
        }

        private String filterCoilData(String fromName1, String toName1, String TDS, String GREAD)
        {
            var dt111 = ThiknessPrameter(fromName1, toName1, TDS, GREAD);
            var dt114 = WidthParameter(fromName1, toName1, TDS, GREAD, dt111[0].Min.ToString(), dt111[0].Max.ToString());

            string filter = " 1=1";
            //if (GREAD != "All")
            //{
            //    filter += " and GRADE = '" + GREAD + "'";
            //}
            //if (TDS != "All")
            //{
            //    filter += " and TDC_No = '" + TDS + "'";
            //}
            if (dt111[0].Min.ToString() != "" & dt111[0].Max.ToString() != "")
            {
                filter += " and THICKNESS between " + dt111[0].Min.ToString() + " and " + dt111[0].Max.ToString() + "";

            }
            if (dt111[0].Min.ToString() != "" & dt111[0].Max.ToString() != "")
            {
                filter += " and WIDTH between " + dt114[0].Min.ToString() + " and " + dt114[0].Max.ToString() + "";

            }
            return filter;
        }
        private void SearchCoilId(String CoilIdText,String RedioOption)
        {
            if (CoilIdText!=null && CoilIdText != "")
            {
                String q = $@"SELECT  DAUGHTER_COILID_NUM,DAUGHTER_COILID_NUM + '#' + CONVERT(VARCHAR,COIL_STARTDATETIME,120) as VALCOILID from [FP_PROCESS_DATA].[dbo].CRM_SPM_PROCESS_DATA_COILWISE_BODY where DAUGHTER_COILID_NUM LIKE '{CoilIdText}%' and (DAUGHTER_COILID_NUM <> '0' and DAUGHTER_COILID_NUM is not null) ORDER BY COIL_STARTDATETIME";
                var dt = dbWrmDevice_Counter.Database.SqlQuery<SpmDetailsAnls>(q).ToArray();
                var DAUGHTER_COILID_NUM = dt.Select(e => e.DAUGHTER_COILID_NUM).ToArray();
                var VALCOILID = dt.Select(e => e.VALCOILID).ToArray();
                string[] ChecedData1 = new string[dt.Length];
                CheckBoxData c11 = new CheckBoxData()
                {
                    CheckBoxValue = DAUGHTER_COILID_NUM,
                    CheckBoxName = VALCOILID,
                    DrplData = RedioOption,
                    CheckBoxChecked = ChecedData1,
                    SelectName = "COILName"

                };
                Checklst1.Add(c11);
            }
            else
            {
                string[] CheckBoxValue = new string[0];
                string[] CheckBoxName = new string[0];
                string[] CheckBoxValue1 = new string[0];
                
                CheckBoxData c11 = new CheckBoxData()
                {
                    CheckBoxValue = CheckBoxValue,
                    CheckBoxName = CheckBoxName,
                    DrplData = RedioOption,
                    CheckBoxChecked = CheckBoxValue1,
                    SelectName = "COILName"
                };
                Checklst1.Add(c11);
            }
            
        }


        /////Function For Plot Chart
        DataTable TableMerge = new DataTable();
        
        private void SelectParamAndCoil(String fromName1, String toName1, String[] COILName, String[] TestParameterName)
        {
            for (int i = 0; i < COILName.Length; i++)
            {
                DataTable dt =GetSPMProcessDataDetailAnalysis("CRM_SPM_PROCESS_DATA_COILWISE_BODY", COILName[i]);
                

                TableMerge.Merge(dt);

            }
            var filteredDT = TableMerge.AsEnumerable().Where(e => e.Field<string>("ELONGATION_SET_ORA") != null && e.Field<string>("ELONGATION_SET_ORA") != "").Select(e => e.Field<string>("ELONGATION_SET_ORA")).ToArray();
            string csv = String.Join(",", filteredDT);
            for (var i = 0; i < TableMerge.Columns.Count-1; i++)
            {

                if (TableMerge.Columns[i].ColumnName == "Coil Thickness")
                {
                    TableMerge.Columns[i].ColumnName = "Thickness";
                }
                if (TableMerge.Columns[i].ColumnName == "Coil Width")
                {
                    TableMerge.Columns[i].ColumnName = "Width";
                }

            }
            var coilid = TableMerge.Rows[0]["Coil_Id"];
            var dtUnit = GetUnitForSPM("[FP_PROCESS_DATA].[dbo].[UNIT_DETAILS]", TestParameterName);
            var unit = new string[TestParameterName.Length + 1];
            string multiplier = "1.0";

            //for (var i = 0; i < TableMerge.Columns.Count - 1; i++)
            for (var i = 0; i < TestParameterName.Length; i++)
            {

                var row = (from x in dtUnit.Where(e => e.PARAMETER_NAME == TestParameterName[i])
                           select new {
                               x.PARAMETER_NAME, x.MULTIPLIER,x.UNIT  
                           }).ToArray();
                if (row.Length > 0)
                {
                    multiplier = row[0].MULTIPLIER;
                    unit[i] = row[0].UNIT;
                    //multiplier = row[i].MULTIPLIER;
                    //unit[i]= row[i].UNIT;
                }
                else
                {
                    multiplier = "1.0";
                }
                int index = 0;

                bool isDerived = false;
                string containerName = TestParameterName[i];
                if (TestParameterName[i].StartsWith("UNIT_"))
                {
                    isDerived = true;
                    TestParameterName[i] = TestParameterName[i].Replace("UNIT_", "");
                }

                if (TestParameterName[i] == "C00_COILER_SPEED_ACT")
                {
                    index = 5;
                }
                else if (TestParameterName[i] == "S11_SPEED_ACT")
                {
                    index = 6;
                }
                else if (TestParameterName[i] == "C90_COILER_SPEED_ACT")
                {
                    index = 7;
                }
                // ElseIf a(i) = "ENLONGATION_SET" Then
                // index = 8
                else if (TestParameterName[i] == "ENLONGATION_ACT")
                {
                    string valuedata = " CRMIS Set Value: " + csv;
                    index = 9;
                }
                else if (TestParameterName[i] == "ROLLFORCE")
                {
                    index = 10;
                }
                else if (TestParameterName[i] == "ROLLFORCE_DS")
                {
                    index = 11;
                }
                else if (TestParameterName[i] == "ROLLFORCE_OS")
                {
                    index = 12;
                }
                else if (TestParameterName[i] == "WORK_ROLL_BEND_POS_SET")
                {
                    index = 13;
                }
                else if (TestParameterName[i] == "WORK_ROLL_BEND_POS_ACT")
                {
                    index = 14;
                }
                else if (TestParameterName[i] == "WORK_ROLL_BEND_NEG_SET")
                {
                    index = 15;
                }
                else if (TestParameterName[i] == "WORK_ROLL_BEND_NEG_ACT")
                {
                    index = 16;
                }
                else if (TestParameterName[i] == "ROLL_GAP_DS")
                {
                    index = 17;
                }
                else if (TestParameterName[i] == "ROLL_GAP_OS")
                {
                    index = 18;
                }
                else if (TestParameterName[i] == "TENSION_POR_ENTRY_REF")
                {
                    index = 19;
                }
                else if (TestParameterName[i] == "TENSION_POR_ENTRY")
                {
                    index = 20;
                }
                else if (TestParameterName[i] == "TENSION_TR_REF")
                {
                    index = 21;
                }
                else if (TestParameterName[i] == "TENSION_TR")
                {
                    index = 22;


                }
                var cname = TableMerge.Columns[index - 1].ColumnName;
                var newcname = cname;
                if (isDerived)
                {
                    newcname = "UNIT_" + cname;
                }
                
                TableMerge.Columns.Add("[" + newcname + "_C]", typeof(double), "Convert([" + cname + "], System.Double) * " + multiplier);
                PlotLineChartForSPMDetailAnalysis(TableMerge, "[" + newcname + "_C]","l"+i, containerName, "plot" + i + 1,"", unit[i], "Coil_Id", TestParameterName[i]);
            }

              
        }
        private   DataTable GetSPMProcessDataDetailAnalysis(String ColumnName, String COILName)
        {
            string[] coils = COILName.Split('#');
            String q = $@"select RAW_DATA_FILE,TDC_No,ELONGATION_SET_ORA from [FP_PROCESS_DATA].[dbo].[CRM_SPM_PROCESS_DATA_COILWISE_BODY] where DAUGHTER_COILID_NUM = '{coils[0]}' AND COIL_STARTDATETIME='{coils[1]}'";
            var dt = dbWrmDevice_Counter.Database.SqlQuery<SpmDetailsAnls>(q).ToArray();
            int ElVal;
        

            if (dt[0].ELONGATION_SET_ORA ==null)  
            {
                ElVal = 0;
            }
            else
            {
                ElVal = (int)dt[0].ELONGATION_SET_ORA;
            }
            // Create a new MemoryStream
            var ms = new MemoryStream();

            // Write the bytes to the MemoryStream
            ms.Write(dt[0].RAW_DATA_FILE, 0, dt[0].RAW_DATA_FILE.Length);
            var ep = new ExcelPackage(ms);

            ExcelPackage.LicenseContext = LicenseContext.Commercial;
            
            ExcelWorksheet workSheet = ep.Workbook.Worksheets.First();

            DataTable table = new DataTable();
            for (var i = 0; i < workSheet.Dimension.End.Column ; i++)
            {
                var s = workSheet.Cells[1, i + 1].Text;
                if (s == "")
                {
                    s = "C" + i;
                }
                table.Columns.Add(s);

            }

            table.Columns.Add("file");
            table.Columns.Add("slabid");
            table.Columns.Add("tdc");
            table.Columns.Add("ELONGATION_SET_ORA");

            for (var i = 2; i < workSheet.Dimension.End.Row ; i++)
            {
               
                if (workSheet.Cells[i, 5].Text == "")
                {
                    break;
                }
                var row = workSheet.Cells[i, 1, i, workSheet.Dimension.End.Column];
                var workRow = table.NewRow();
             
                foreach (var cell in row)
                {
                    var CheckData=cell.Text;
                    int colIndex = cell.Start.Column;
                    workRow[colIndex-1] = cell.Text;
                    
                }
                workRow[workSheet.Dimension.End.Column - 1] = coils[0];
                table.Rows.Add(workRow);
            }
            table.Rows[0]["tdc"] = dt[0].ELONGATION_SET_ORA;
            table.Rows[0]["ELONGATION_SET_ORA"] = ElVal;

            return  table;
            
        }
        private SpmDetailsAnls[] GetUnitForSPM(String TableName , String[] TestParameterName)
        {

           
            String ColumnName = "";
            for(int i=0;i< TestParameterName.Length; i++)
            {
                ColumnName += ",'"+TestParameterName[i].ToString()+"'";
            }
            String q = $@"select *  from {TableName} where PARAMETER_NAME in({ ColumnName.Substring(1)})";
            var dt = dbWrmDevice_Counter.Database.SqlQuery<SpmDetailsAnls>(q).ToArray();
            return dt;

        }
        public DataTable GetLimit(string TdcNo, double Thickness, double Width)
        {
            DataTable newtable = new DataTable();
            string query = "";
            query = "select Avg - (Avg*Percent_limit/100) as min, Avg + (Avg * Percent_limit/100) as max,Avg * 102.0408 as Avg  from CRM_SPM_Cutoff where TDC = '" + TdcNo + "' and " + Thickness + " > Thickness_min and " + Thickness + " <= Thickness_max and " + Width * 1000d + " > Width_min and " + Width * 1000d + " <= Width_max";
            return newtable;
        }
        public void PlotLineChartForSPMDetailAnalysis(DataTable dt,string lit, string YAxisColName,string ContainerName, string PlotName, string ChartTitle, string YAxisLabelName, string GroupByColName, string name = "")
        {

            int lineindex = -1;
            string strOverlay = "";
            double multiplier = 1.0d;
            if (name == "ENLONGATION_ACT")
            {
                multiplier = 100d;
                lineindex = 8;
            }

            else if (lit.StartsWith("[UNIT"))
            {
                if (name == "TENSION_TR")
                {
                    multiplier = 1d / (9.8d * 1000d);
                    lineindex = 21;
                }
            }
            else if (name == "TENSION_TR")
            {
                multiplier = 1d / 9.8d;
                lineindex = 21;
            }
            else if (name == "ROLLFORCE")
            {
                multiplier = 102.0408d;
                lineindex = 25;
            }
            else if (name == "WORK_ROLL_BEND_POS_ACT")
            {
                multiplier = 102.0408d;
                lineindex = 14;
            }

            double[] yVal;
            
            double minVal=0.00;

            
            if (name != "ROLLFORCE" && name != "WORK_ROLL_BEND_POS_ACT")
            {
                minVal = dt.AsEnumerable().Min(row => row.Field<double>(lit));


            }
            yVal = dt.AsEnumerable().Select(row => row.Field<double>(lit)).ToArray();
            
            double y_min = (yVal.Min() - 10d / 100d * Math.Abs(yVal.Min()));
            double y_max = (yVal.Max() + 10d / 100d * Math.Abs(yVal.Max()));
            var distinctValues = dt.AsEnumerable()
                .Select(e => e.Field<string>(GroupByColName)).Distinct().ToArray();
            
            DataView dvDefault = dt.DefaultView;
            bool flag = false;
            int cnt = 1;
            int stcnt;

            // Changes for elongation set 
            string elongseries = "";
            string elongseriesdata = "";
            string js = "";
            for (int i = 0; i < distinctValues.Length; i++)
            {
               
                 js += "{name:'" + (i + 1).ToString() + "',type:'scatter',data:[";        
                dvDefault.RowFilter = "" + GroupByColName + "='" + distinctValues[i] + "'";
                stcnt = cnt;
                var data = dvDefault[1][GroupByColName];
                for (int j = 0; j < dvDefault.Count; j++)
                {
                    if (j > 0)
                    {
                        js += ",";
                    }
                    js += "[";

                    if (dvDefault[j][GroupByColName] == null)
                    {
                        if (dvDefault[j][lit] != null)
                        {
                            js += "" + dvDefault[j][lit] + ", " + "null";
                        }
                        else
                        {
                            js += " " + "null, null";
                        }
                    }
                    else if (dvDefault[j][lit] != null)
                    {
                        var dt1 = dvDefault[j][lit];
                        var dt2 = dvDefault[j][GroupByColName];
                        var dt3 = dvDefault[j]["Thickness"];
                        var dt4 = Convert.ToDouble(dvDefault[j]["Width"])*1000;
                        var dt5 = dvDefault[0]["tdc"];
                       
                        js += cnt + "," + dt1 + ",'" + dt2 + "'" + ",'" + dt3 + "'" + ",'" + dt4 + "'" + ",'" + dt5 + "'";
                        cnt += 1;
                        
                    }
                    js += "]";
                }
              
                //if (lineindex > -1)
                //{
                //    if (lit.StartsWith("[UNIT"))
                //    {
                //        if (name == "TENSION_TR")
                //        {
                //            multiplier = multiplier / ((double)dvDefault[0]["Thickness"]  * (double)dvDefault[0]["Width"]);
                //            // strOverlay &= "{horizontalLine: {name: '" & dvDefault.Item(0)(GroupByColName) & "',color: 'rgb(255,0,0)',showTooltip: true,tooltipFormatString:" & dvDefault.Item(0)(lineindex - 1) * multiplier & " ,xmin:" & stcnt & ",xmax:" & cnt - 1 & ",y:" & dvDefault.Item(0)(lineindex - 1) * multiplier & ",lineWidth:2}},"
                //            strOverlay += "{horizontalLine: {name: '" + dvDefault[0][GroupByColName] + "',color: 'rgb(255,0,0)',showTooltip: true,tooltipFormatString:" + minVal * multiplier + " ,xmin:" + stcnt + ",xmax:" + (cnt - 1) + ",y:" + minVal * multiplier + ",lineWidth:2}},";
                //        }
                //    }
                //    else if (name == "ENLONGATION_ACT")
                //    {
                //        elongseriesdata += "var eLine" + (i + 1) + "=[";
                //        elongseries += ",eLine" + (i + 1);

                //        for (int k = 0; k < dvDefault.Count; k++)
                //            elongseriesdata += "[" + (stcnt + k) + "," + (int)dvDefault[k]["ENLONGATIONSET"] * 100 + "],";

                //        elongseriesdata += "];";
                //    }
                //    else if (name != "ROLLFORCE" & name != "WORK_ROLL_BEND_POS_ACT")
                //    {

                //        // If name = "ENLONGATION_ACT" Then
                //        // strOverlay &= "{horizontalLine: {name: '" & dvDefault.Item(0)(GroupByColName) & "1',color: 'rgb(255,140,0)',showTooltip: true,tooltipFormatString:'" & minVal * multiplier & "',xmin:" & stcnt & ",xmax:" & cnt - 1 & ",y:" & dvDefault.Item(0)("ELONGATION_SET_ORA") & ",lineWidth:2}},"
                //        // End If
                //        // strOverlay &= "{horizontalLine: {name: '" & dvDefault.Item(0)(GroupByColName) & "',color: 'rgb(255,0,0)',showTooltip: true,tooltipFormatString:'" & dvDefault.Item(0)(lineindex - 1) * multiplier & "',xmin:" & stcnt & ",xmax:" & cnt - 1 & ",y:" & dvDefault.Item(0)(lineindex - 1) * multiplier & ",lineWidth:2}},"
                //        // Commented by Pratik as on 01-04-2020
                //        strOverlay += "{horizontalLine: {name: '" + dvDefault[0][GroupByColName] + "',color: 'rgb(255,0,0)',showTooltip: true,tooltipFormatString:'" + minVal * 1 + "',xmin:" + stcnt + ",xmax:" + (cnt - 1) + ",y:" + minVal * 1 + ",lineWidth:2}},";
                //    }

                //    else
                //    {

                //        DataTable dtLim = GetLimit(dvDefault[0]["TDC"].ToString(), (double)dvDefault[0]["Thickness"], (double)dvDefault[0]["Width"]);
                //        if (dtLim.Rows.Count > 0)
                //        {
                //            double min = (double)dtLim.Rows[0][0];
                //            double max = (double)dtLim.Rows[0][1];
                //            double avg = (double)dtLim.Rows[0][2];
                //            if (name == "WORK_ROLL_BEND_POS_ACT")                       
                //            {
                //                min = (double)dtLim.Rows[1][0];
                //                max = (double)dtLim.Rows[1][1];
                //                avg = (double)dtLim.Rows[1][2];


                //            }

                //            strOverlay += "{horizontalLine: {name: '" + dvDefault[0][GroupByColName] + "',color: 'rgb(255,140,0)',showTooltip: true,tooltipFormatString:'" + Math.Round(min * multiplier, 3) + "',xmin:" + stcnt + ",xmax:" + (cnt - 1) + ",y:" + min * multiplier + ",lineWidth:2}},";
                //            strOverlay += "{horizontalLine: {name: '" + dvDefault[0][GroupByColName] + "1',color: 'rgb(255,0,0)',showTooltip: true,tooltipFormatString:'" + Math.Round(max * multiplier, 3) + "',xmin:" + stcnt + ",xmax:" + (cnt - 1) + ",y:" + max * multiplier + ",lineWidth:2}},";
                //            if (name == "ROLLFORCE")
                //            {
                //                strOverlay += "{horizontalLine: {name: '" + dvDefault[0][GroupByColName] + "1',color: 'rgb(0,128,0)',showTooltip: true,tooltipFormatString:'" + Math.Round(avg, 3) + "',xmin:" + stcnt + ",xmax:" + (cnt - 1) + ",y:" + avg + ",lineWidth:2}},";
                //            }
                //            if (name == "WORK_ROLL_BEND_POS_ACT")
                //            {
                //                strOverlay += "{horizontalLine: {name: '" + dvDefault[0][GroupByColName] + "1',color: 'rgb(0,128,0)',showTooltip: true,tooltipFormatString:'" + Math.Round(avg, 3) + "',xmin:" + stcnt + ",xmax:" + (cnt - 1) + ",y:" + avg + ",lineWidth:2}},";
                //            }
                //            if (y_min < min * multiplier)
                //            {
                //            }
                //            else
                //            {
                //                y_min = min * multiplier;
                //                y_min = y_min - 0.01d * y_min;
                //            }
                //            if (y_max > max * multiplier)
                //            {
                //            }
                //            else
                //            {
                //                y_max = max * multiplier;
                //                y_max = y_max + 0.01d * y_max;
                //            }
                //        }
                //    }

                //}
                js += "]},";
                flag = true;
            }
            //js += "],";


            CHART_LP11 c1 = new CHART_LP11()
            {
                FromDate = "",
                ID = YAxisColName,
                Title = ContainerName,
                TypeX = "time",
                TypeY = "Vlaue",
                ShowLegend = "true",
                Width = "",
                ShowToolBox = js,
                MaxAxisData = Convert.ToString(y_max),
                MinAxisData = Convert.ToString(y_min),
                SeriesData = "",
                divcolsm = "12",
                divHeight = "45vh"

            };
            lst11.Add(c1);
            
           
            //string strg = "";
            //string strseries = "";
            //if (flag)
            //{
            //    strg = "line1";
            //    strseries = @" {pointLabels: { show:false }, showLine:false, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 5,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>Sl No: %s</td></tr>\ <tr><td>Y Value: %s</td></tr>\ <tr><td>Coil Id: %s</td></tr>\ <tr><td>Thickness: %s</td></tr>\ <tr><td>Width: %s</td></tr>\ <tr><td>TDC: %s</td></tr>\ </table>'}}";
            //    for (int i = 0; i < distinctValues.Length; i++)
            //    {
            //        strg = strg + ",line" + (i + 1);
            //        strseries = strseries + @", {pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 5,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>Sl No: %s</td></tr>\ <tr><td>Y Value: %s</td></tr>\ <tr><td>Coil Id: %s</td></tr>\ <tr><td>Thickness: %s</td></tr>\ <tr><td>Width: %s</td></tr>\ <tr><td>TDC: %s</td></tr>\ </table>'}}";
            //    }

            //    if (elongseries.Length > 0)
            //    {
            //        for (int j = 0; j < distinctValues.Length; j++)
            //            strseries = strseries + @", {pointLabels: { show:false }, showLine:true,color: '#FF0000',markerOptions:{ size: 1 }, lineWidth:1, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>Sl No: %s</td></tr>\ <tr><td>Y Value: %s</td></tr>\ </table>'}}";


            //    }
            //    strg += "";
            //}
            //js += elongseriesdata;
            //js += "var seriesName = ['";
            //string str = "";
            //for (int j = 0; j < distinctValues.Length; j++)
            //{
            //    str += dtGrades.Rows(i)(0).ToString().Trim() + "', '";
            //}

            //str = str.Remove(str.LastIndexOf(", '"));
            //str += "];";
            //js += str;



        }


    }
}