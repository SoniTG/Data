﻿using PTG_TSJ_Main.BussinessLogic.SIDE_MENU;
using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using System;
using System.Text;
using PTG_TSJ_Main.BussinessLogic.CGL2;
using PTG_TSJ_Main.BussinessLogic.PAGE_HITS;

namespace PTG_TSJ_Main.Controllers
{
    public class CGL2Controller : Controller
    {
        // GET: CGL2
        PageHitsFunction HitsFunction = new PageHitsFunction();
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Al_Fe_PredictionModel(String btn_on_click, String btn_off_click, string tran_on_click, string tran_off_click, double? txtTotalAI, double? txtTotalFE, double? txtPotTemp, string btnStart, string txt_Tran_From_Date, string txt_Tran_To_Date, string txtFrom, string txtTo, string btnStart1)

        {


            //For Hits
            string PageName = "CGL2/Al_Fe_PredictionModel";
            int Count = 0;
            Count = Request.HttpMethod != "POST" ? HitsFunction.FunctionForPageHits(PageName, "Yes") : HitsFunction.FunctionForPageHits(PageName, "No");
            ViewBag.PageHitsData = Count;
            ViewBag.PageName = HitsFunction.PageNameFunction(PageName);
            //
            SIDE_MENU_DATA dataside = new SIDE_MENU_DATA();
            List<SideMenu> lst = dataside.GetSIdeMenuDAta("CGL2");
            ViewBag.SideMenuData = lst;

            Al_Fe_Prediction_Model obj = new Al_Fe_Prediction_Model();

            MultipleData table = obj.GetDataForAl_Fe_Prediction_Model(btn_on_click, btn_off_click, tran_on_click, tran_off_click, txtTotalAI, txtTotalFE, txtPotTemp, btnStart, txt_Tran_From_Date, txt_Tran_To_Date, txtFrom, txtTo, btnStart1);


            return View(table);
        }
        public ActionResult FeDissolutionModel(string StDt, string EndDt)



        {

            SIDE_MENU_DATA dataside = new SIDE_MENU_DATA();
            List<SideMenu> lst = dataside.GetSIdeMenuDAta("CGL2");
            ViewBag.SideMenuData = lst;

            string PageName = "CGL2/FeDissolutionModel";
            int Count = 0;
            Count = Request.HttpMethod != "POST" ? HitsFunction.FunctionForPageHits(PageName, "Yes") : HitsFunction.FunctionForPageHits(PageName, "No");
            ViewBag.PageHitsData = Count;
            ViewBag.PageName = HitsFunction.PageNameFunction(PageName);

            FeDissolutionModel obj = new FeDissolutionModel();

            MultipleData table = obj.GetDataForAl_Fe_Prediction_Model(StDt, EndDt);


            return View(table);

        }
        public ActionResult Cgl2alfemonitoring(string StDt, string EndDt)
        {
            BL_Cgl2alfemonitoring obj = new BL_Cgl2alfemonitoring();
            var table = obj.Main_Cgl2alfemonitoring();
            return View();
        }
        
    }
}