﻿using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using System;
using System.Text;
using PTG_TSJ_Main.BussinessLogic.PtgMenu;

namespace PTG_TSJ_Main.Controllers
{
    public class HomeController : Controller
    {
        PTG_MASTER_DATA dbPtgMenu = new PTG_MASTER_DATA();

        public ActionResult PTG(String PMD_MAIN_AREA, String PMD_MAIN_AREA_ID, String PMD_SUB_AREA, String PMD_SUB_AREA_ID, String PMD_MAIN_DIV, String PMD_MAIN_DIV_ID, String PMD_SUB_DIV, String PMD_SUB_DIV_ID, String ColorName)
        {
            BL_PtgMenu obj = new BL_PtgMenu();
            MultipleData table = obj.GetDataForDeviceCounter(PMD_MAIN_AREA, PMD_MAIN_AREA_ID, PMD_SUB_AREA, PMD_SUB_AREA_ID, PMD_MAIN_DIV, PMD_MAIN_DIV_ID, PMD_SUB_DIV, PMD_SUB_DIV_ID, ColorName);
            return View(table);
        }
        public ActionResult FP_Analytics()
        {

            return View();
        }
        public ActionResult Index()
        {

            return View();

        }
        public ActionResult DPCR_Visualization()
        {

            return View();

        }
        public ActionResult DPCR_Timeline()
        {

            return View();

        }
        public ActionResult Metallurgical_Tools()
        {

            return View();

        }
        public ActionResult TSM()
        {

            return View();

        }



    }
}