﻿using PTG_TSJ_Main.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PTG_TSJ_Main.BussinessLogic.PtgMenu;
namespace PTG_TSJ_Main.Controllers
{
    public class MenuCategoriesController : Controller
    {
        // GET: MenuCategories
        public ActionResult TsjMenu()
        {
            var table = new MultipleData();
            BL_TsjMenu obj = new BL_TsjMenu();
            table = obj.GetDataForTsjMenu();
            return View(table);
        }
        public ActionResult CRM_Menu()
        {
            var table = new MultipleData();
            CRMmenu obj = new CRMmenu();
            table = obj.GetDataForTsjMenu();
            return View(table);
        }
    }
}