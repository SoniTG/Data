﻿using PTG_TSJ_Main.BussinessLogic.SIDE_MENU;
using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using System;
using System.Text;
using PTG_TSJ_Main.BussinessLogic.PLTCM;
using PTG_TSJ_Main.BussinessLogic.PAGE_HITS;

namespace PTG_TSJ_Main.Controllers
{
    public class PLTCMController : Controller
    {
        // GET: PLTCM
        PTG_MASTER_DATA dbPtgMenu = new PTG_MASTER_DATA();
        PageHitsFunction HitsFunction = new PageHitsFunction();
        public ActionResult MILL_GLANCE(String fromName1, String toName1, String PLANTNAME= "PLTCM")
        {

            TempData["plantname"] = PLANTNAME;
            SIDE_MENU_DATA dataside = new SIDE_MENU_DATA();
            List<SideMenu> lst = dataside.GetSIdeMenuDAta(PLANTNAME);
            ViewBag.SideMenuData = lst;

            //For Hits
            string PageName = "PLTCM/MILL_GLANCE";
            int Count = 0;
            Count = Request.HttpMethod != "POST" ? HitsFunction.FunctionForPageHits(PageName, "Yes") : HitsFunction.FunctionForPageHits(PageName, "No");
            ViewBag.PageHitsData = Count;
            ViewBag.PageName = HitsFunction.PageNameFunction(PageName);
            //

            MillGlance obj = new MillGlance();
           // MainSubMenu objMenu = new MainSubMenu();
            MultipleData table = obj.GetDataForMillGlance(fromName1, toName1);
            //table = objMenu.GetDataForMillGlance(table);
            return View(table);
        }
        public ActionResult TREND_ANALYSIS(String PLANTNAME = "PLTCM")
        {

            TempData.Keep("plantname");
            PLANTNAME = TempData["plantname"] as string;

            SIDE_MENU_DATA dataside = new SIDE_MENU_DATA();
            List<SideMenu> lst = dataside.GetSIdeMenuDAta(PLANTNAME = "PLTCM");
            ViewBag.SideMenuData = lst;


            //For Hits
            string PageName = "PLTCM/TREND_ANALYSIS";
            int Count = 0;
            Count = Request.HttpMethod != "POST" ? HitsFunction.FunctionForPageHits(PageName, "Yes") : HitsFunction.FunctionForPageHits(PageName, "No");
            ViewBag.PageHitsData = Count;
            ViewBag.PageName = HitsFunction.PageNameFunction(PageName);
            //

            TREND_ANALYSIS obj = new TREND_ANALYSIS();
            MultipleData table = obj.GetDataForMillGlance();

            //return View(table);
            string strdata = obj.Glancejsondata();
            return View(table); 
        }
        [HttpPost]
        public ActionResult cpkcoildata()
        {

            string PageName = "TSM/cpkcoildata";
            int Count = 0;
            Count = Request.HttpMethod != "POST" ? HitsFunction.FunctionForPageHits(PageName, "Yes") : HitsFunction.FunctionForPageHits(PageName, "No");
            ViewBag.PageHitsData = Count;
            ViewBag.PageName = HitsFunction.PageNameFunction(PageName);

            //BL_CpK obj = new BL_CpK();
            TREND_ANALYSIS obj = new TREND_ANALYSIS();
           

            //return View(table);
            string strdata = obj.Glancejsondata();
            //return View(table);
            return Json(strdata, JsonRequestBehavior.AllowGet);
           
        }
        public ActionResult PLTCM_Encoder(String fdate, String tdate, String PLANTNAME = "PLTCM")
        {

            //For Hits
            string PageName = "PLTCM/PLTCM_Encoder";
            int Count = 0;
            Count = Request.HttpMethod != "POST" ? HitsFunction.FunctionForPageHits(PageName, "Yes") : HitsFunction.FunctionForPageHits(PageName, "No");
            ViewBag.PageHitsData = Count;
            ViewBag.PageName = HitsFunction.PageNameFunction(PageName);
            //
            TempData.Keep("plantname");
            PLANTNAME = TempData["plantname"] as string;

            SIDE_MENU_DATA dataside = new SIDE_MENU_DATA();
            List<SideMenu> lst = dataside.GetSIdeMenuDAta(PLANTNAME = "PLTCM");
            ViewBag.SideMenuData = lst;

            PLTCM_Encoder obj = new PLTCM_Encoder();
            MultipleData table = obj.GetDataForMillGlance(fdate, tdate);
            return View(table);
        }
        public ActionResult Bridle_Roll_SlipPage(String fromName1, String toName1, String SelectValue, String PLANTNAME = "PLTCM")
        {
            //For Hits
            string PageName = "PLTCM/Bridle_Roll_SlipPage";
            int Count = 0;
            Count = Request.HttpMethod != "POST" ? HitsFunction.FunctionForPageHits(PageName, "Yes") : HitsFunction.FunctionForPageHits(PageName, "No");
            ViewBag.PageHitsData = Count;
            ViewBag.PageName = HitsFunction.PageNameFunction(PageName);
            //
            TempData.Keep("plantname");
            PLANTNAME = TempData["plantname"] as string;
            SIDE_MENU_DATA dataside = new SIDE_MENU_DATA();
            List<SideMenu> lst = dataside.GetSIdeMenuDAta(PLANTNAME = "PLTCM");
            ViewBag.SideMenuData = lst;

            Bridle_Roll_SlipPage obj = new Bridle_Roll_SlipPage();
            MultipleData table = obj.GetDataForBridle_Roll_SlipPage(fromName1, toName1, SelectValue);
            return View(table);
        }
        public ActionResult PlTank(String fromName1, String toName1, String PLANTNAME = "PLTCM")
        {
            //For Hits
            string PageName = "PLTCM/PlTank";
            int Count = 0;
            Count = Request.HttpMethod != "POST" ? HitsFunction.FunctionForPageHits(PageName, "Yes") : HitsFunction.FunctionForPageHits(PageName, "No");
            ViewBag.PageHitsData = Count;
            ViewBag.PageName = HitsFunction.PageNameFunction(PageName);
            //
            TempData.Keep("plantname");
            PLANTNAME = TempData["plantname"] as string;
            SIDE_MENU_DATA dataside = new SIDE_MENU_DATA();
            List<SideMenu> lst = dataside.GetSIdeMenuDAta(PLANTNAME = "PLTCM");
            ViewBag.SideMenuData = lst;

            PlTank obj = new PlTank();
            MultipleData table = obj.GetDataForPlTank(fromName1, toName1);
            return View(table);
        }
        public ActionResult PLTCM_Sub_Chart(String LineName, String PLANTNAME = "PLTCM")
        {
            //For Hits
            string PageName = "PLTCM/PLTCM_Sub_Chart";
            int Count = 0;
            Count = Request.HttpMethod != "POST" ? HitsFunction.FunctionForPageHits(PageName, "Yes") : HitsFunction.FunctionForPageHits(PageName, "No");
            ViewBag.PageHitsData = Count;
            ViewBag.PageName = HitsFunction.PageNameFunction(PageName);
            //
            TempData.Keep("plantname");
            PLANTNAME = TempData["plantname"] as string;
            SIDE_MENU_DATA dataside = new SIDE_MENU_DATA();
            List<SideMenu> lst = dataside.GetSIdeMenuDAta(PLANTNAME = "PLTCM");
            ViewBag.SideMenuData = lst;

            PLTCM_sub_chart obj = new PLTCM_sub_chart();
            MultipleData table = obj.GetDataForPLTCM_Sub_Chart(LineName);
            return View(table);
        }
        public ActionResult CPC(String fromName1, String toName1, String SelectValue, String PLANTNAME = "PLTCM")
        {
            //For Hits
            string PageName = "PLTCM/CPC";
            int Count = 0;
            Count = Request.HttpMethod != "POST" ? HitsFunction.FunctionForPageHits(PageName, "Yes") : HitsFunction.FunctionForPageHits(PageName, "No");
            ViewBag.PageHitsData = Count;
            ViewBag.PageName = HitsFunction.PageNameFunction(PageName);
            //
            TempData.Keep("plantname");
            PLANTNAME = TempData["plantname"] as string;
            SIDE_MENU_DATA dataside = new SIDE_MENU_DATA();
            List<SideMenu> lst = dataside.GetSIdeMenuDAta(PLANTNAME = "PLTCM");
            ViewBag.SideMenuData = lst;

            CPC obj = new CPC();
            MultipleData table = obj.GetDataForCPC(fromName1, toName1, SelectValue);
            return View(table);
        }
        public ActionResult CrmLabData(String fromName1, String toName1, String SelectValue, String[] Checkboxes, String PLANTNAME = "PLTCM")
        {
            //For Hits
            string PageName = "PLTCM/CrmLabData";
            int Count = 0;
            Count = Request.HttpMethod != "POST" ? HitsFunction.FunctionForPageHits(PageName, "Yes") : HitsFunction.FunctionForPageHits(PageName, "No");
            ViewBag.PageHitsData = Count;
            ViewBag.PageName = HitsFunction.PageNameFunction(PageName);
            //
            TempData.Keep("plantname");
            PLANTNAME = TempData["plantname"] as string;
            SIDE_MENU_DATA dataside = new SIDE_MENU_DATA();
            List<SideMenu> lst = dataside.GetSIdeMenuDAta(PLANTNAME = "PLTCM");
            ViewBag.SideMenuData = lst;

            CRM_LabData obj = new CRM_LabData();
            MultipleData table = obj.GetDataCrm_LabData(fromName1, toName1, SelectValue, Checkboxes);
            return View(table);
        }
        public ActionResult PLTCM_E_Maint_StrokeTime(String fromName1, String toName1, String SelectValue, String[] Checkboxes, String PLANTNAME = "PLTCM")
        {
            //For Hits
            string PageName = "PLTCM/PLTCM_E_Maint_StrokeTime";
            int Count = 0;
            Count = Request.HttpMethod != "POST" ? HitsFunction.FunctionForPageHits(PageName, "Yes") : HitsFunction.FunctionForPageHits(PageName, "No");
            ViewBag.PageHitsData = Count;
            ViewBag.PageName = HitsFunction.PageNameFunction(PageName);
            //
            TempData.Keep("plantname");
            PLANTNAME = TempData["plantname"] as string;
            SIDE_MENU_DATA dataside = new SIDE_MENU_DATA();
            List<SideMenu> lst = dataside.GetSIdeMenuDAta(PLANTNAME = "PLTCM");
            ViewBag.SideMenuData = lst;

            Welder_Stroke_Time obj = new Welder_Stroke_Time();
            MultipleData table = obj.GetDataForWelder_Stroke_Time();
            return View(table);
        }
        public ActionResult Pltcm_stroketime(String fromName1, String toName1, String SelectValue,  String[] Checkboxes, String PLANTNAME = "PLTCM")
        {
            //For Hits
            string PageName = "PLTCM/Pltcm_stroketime";
            int Count = 0;
            Count = Request.HttpMethod != "POST" ? HitsFunction.FunctionForPageHits(PageName, "Yes") : HitsFunction.FunctionForPageHits(PageName, "No");
            ViewBag.PageHitsData = Count;
            ViewBag.PageName = HitsFunction.PageNameFunction(PageName);
            //
            TempData.Keep("plantname");
            PLANTNAME = TempData["plantname"] as string;
            SIDE_MENU_DATA dataside = new SIDE_MENU_DATA();
            List<SideMenu> lst = dataside.GetSIdeMenuDAta(PLANTNAME = "PLTCM");
            ViewBag.SideMenuData = lst;

            Welder_Stroke_Time obj = new Welder_Stroke_Time();
            MultipleData table = obj.GetDataForWelder_Stroke_Time();
            return View(table);
        }
        public ActionResult Pltcm_stroketimeChart(String fromName1, String toName1, String SelectValue, String[] Checkboxes, String PLANTNAME = "PLTCM")
        {
            //For Hits
            string PageName = "PLTCM/Pltcm_stroketimeChart";
            int Count = 0;
            Count = Request.HttpMethod != "POST" ? HitsFunction.FunctionForPageHits(PageName, "Yes") : HitsFunction.FunctionForPageHits(PageName, "No");
            ViewBag.PageHitsData = Count;
            ViewBag.PageName = HitsFunction.PageNameFunction(PageName);
            //
            TempData.Keep("plantname");
            PLANTNAME = TempData["plantname"] as string;
            SIDE_MENU_DATA dataside = new SIDE_MENU_DATA();
            List<SideMenu> lst = dataside.GetSIdeMenuDAta("PLTCM");
            ViewBag.SideMenuData = lst;

            PLTCM_StrokTime obj = new PLTCM_StrokTime();
            MultipleData table = obj.GetDataForStrokTime(fromName1, toName1);
            return View(table);
        }
        public ActionResult ComingSoon(String fromName1, String toName1, String SelectValue, String[] Checkboxes, String PLANTNAME = "PLTCM")
        {
            //For Hits
            string PageName = "PLTCM/ComingSoon";
            int Count = 0;
            Count = Request.HttpMethod != "POST" ? HitsFunction.FunctionForPageHits(PageName, "Yes") : HitsFunction.FunctionForPageHits(PageName, "No");
            ViewBag.PageHitsData = Count;
            ViewBag.PageName = HitsFunction.PageNameFunction(PageName);
            //
            TempData.Keep("plantname");
            PLANTNAME = TempData["plantname"] as string;
            SIDE_MENU_DATA dataside = new SIDE_MENU_DATA();
            List<SideMenu> lst = dataside.GetSIdeMenuDAta("PLTCM");
            ViewBag.SideMenuData = lst;

            
            return View();
        }
        public ActionResult pltcm_historical(string fromName1, string toName1, string ddlEncoders)
        {

            string PageName = "PLTCM/pltcm_historical";
            int Count = 0;
            Count = Request.HttpMethod != "POST" ? HitsFunction.FunctionForPageHits(PageName, "Yes") : HitsFunction.FunctionForPageHits(PageName, "No");
            ViewBag.PageHitsData = Count;
            ViewBag.PageName = HitsFunction.PageNameFunction(PageName);

            SIDE_MENU_DATA dataside = new SIDE_MENU_DATA();
            List<SideMenu> lst = dataside.GetSIdeMenuDAta("PLTCM");
            ViewBag.SideMenuData = lst;

            BL_pltcm_historical obj = new BL_pltcm_historical();

            MultipleData table = obj.GetDataForBL_pltcm_historical(fromName1, toName1, ddlEncoders);


            return View(table);
        }
        public ActionResult SCUM_ANALYTICS(string fromName1, string toName1,String[] GRADE, String[] Defect, String[] TDC, String[] Severity)
        {

            string PageName = "PLTCM/SCUM_ANALYTICS";
            int Count = 0;
            Count = Request.HttpMethod != "POST" ? HitsFunction.FunctionForPageHits(PageName, "Yes") : HitsFunction.FunctionForPageHits(PageName, "No");
            ViewBag.PageHitsData = Count;
            ViewBag.PageName = HitsFunction.PageNameFunction(PageName);
            SIDE_MENU_DATA dataside = new SIDE_MENU_DATA();
            List<SideMenu> lst = dataside.GetSIdeMenuDAta("PLTCM");
            ViewBag.SideMenuData = lst;

            BL_SCUM_ANALYTICS obj = new BL_SCUM_ANALYTICS();

            MultipleData table = obj.GetDataForBL_SCUM_ANALYTICS(fromName1, toName1,  GRADE,  Defect,  TDC,  Severity);


            return View(table);
        }
        public ActionResult Scum_Sub_chart(string subparam, string defect)
        {
            ScumSubChart obj = new ScumSubChart();
            MultipleData table = obj.GetDataForScum_Sub_Chart(subparam, defect);
            return View(table);
        }
        public ActionResult rollanamoly(AnamolyInputModel im)
        {

            //For Hits
            string PageName = "PLTCM/rollanamoly";
            int Count = 0;
            Count = Request.HttpMethod != "POST" ? HitsFunction.FunctionForPageHits(PageName, "Yes") : HitsFunction.FunctionForPageHits(PageName, "No");
            ViewBag.PageHitsData = Count;
            ViewBag.PageName = HitsFunction.PageNameFunction(PageName);
            //
            SIDE_MENU_DATA dataside = new SIDE_MENU_DATA();
            List<SideMenu> lst = dataside.GetSIdeMenuDAta("PLTCM");
            ViewBag.SideMenuData = lst;

            AnamolyViewModel vm = new AnamolyViewModel();

            Anamoly obj = new Anamoly();
            vm.lstData = obj.GetColorForStands();
            vm.chartData = obj.GetChartData(im);
            vm.im = im;
            return View(vm);
        }

    }
}