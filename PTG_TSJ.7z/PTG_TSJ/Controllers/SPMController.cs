﻿using PTG_TSJ_Main.BussinessLogic.PAGE_HITS;
using PTG_TSJ_Main.BussinessLogic.SIDE_MENU;
using PTG_TSJ_Main.BussinessLogic.SPM;
using PTG_TSJ_Main.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PTG_TSJ_Main.Controllers
{
    public class SPMController : Controller
    {
        // GET: SPM
        PageHitsFunction HitsFunction = new PageHitsFunction();
        public ActionResult SPM_PAGE(String PLANTNAME)
        {
            SIDE_MENU_DATA dataside = new SIDE_MENU_DATA();
            List<SideMenu> lst =  dataside.GetSIdeMenuDAta(PLANTNAME);

            ViewBag.SideMenuData = lst;
            
            return View();
        }
        public ActionResult SPM_PAGE1(String PLANTNAME)
        {
            SIDE_MENU_DATA dataside = new SIDE_MENU_DATA();
            List<SideMenu> lst = dataside.GetSIdeMenuDAta(PLANTNAME);

            ViewBag.SideMenuData = lst;

            return View();
        }

        public ActionResult SPMdetailanalysis(String fromName1, String toName1, String PLANTNAME,String inlineRadioOptions,String TDS,String GREAD, String CoilIDText, String[] COILName, String[] TestParameterName)
        {
            SIDE_MENU_DATA dataside = new SIDE_MENU_DATA();
            List<SideMenu> lst = dataside.GetSIdeMenuDAta(PLANTNAME);
            ViewBag.SideMenuData = lst;

            //For Hits
            string PageName = "SPM/SPMdetailanalysis";
            int Count = 0;
            Count = Request.HttpMethod != "POST" ? HitsFunction.FunctionForPageHits(PageName, "Yes") : HitsFunction.FunctionForPageHits(PageName, "No");
            ViewBag.PageHitsData = Count;
            ViewBag.PageName = HitsFunction.PageNameFunction(PageName);
            //


            BL_spmdetailanalysis obj = new BL_spmdetailanalysis();
          
            MultipleData table = obj.GetDataForSPMdetailAnalysis(fromName1, toName1, inlineRadioOptions, TDS, GREAD, CoilIDText, COILName, TestParameterName);
            
            return View(table);
        }
    }
}