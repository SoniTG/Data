﻿using PTG_TSJ_Main.Models;
using PTG_TSJ_Main.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using System;
using System.Text;
using PTG_TSJ_Main.BussinessLogic;
using PTG_TSJ_Main.BussinessLogic.SIDE_MENU;
using PTG_TSJ_Main.BussinessLogic.PAGE_HITS;

namespace PTG_TSJ_Main.Controllers
{
    public class WRMController : Controller
    {
        // GET: Home1
        LP_PROCESS_DATA_v1Entities dbWrmDashbord = new LP_PROCESS_DATA_v1Entities();
        //ModelWRM db = new ModelWRM();
        WRMDBEntities dbWrmLptg = new WRMDBEntities();
        WRMDBEntities1 dbWrmLptg1 = new WRMDBEntities1();
        PageHitsFunction HitsFunction = new PageHitsFunction();

        PTG_MASTER_DATA dbPtgMenu = new PTG_MASTER_DATA();
        public ActionResult Index(String fromName1, String toName1, String fromName2, String toName2, String fromName3, String toName3,String SelectValue, String PLANTNAME)
        //public ActionResult Index()
        {
            //For Hits
            string PageName = "WRM/Index";
            int Count = 0;
            Count = Request.HttpMethod != "POST" ? HitsFunction.FunctionForPageHits(PageName, "Yes") : HitsFunction.FunctionForPageHits(PageName, "No");
            ViewBag.PageHitsData = Count;
            ViewBag.PageName = HitsFunction.PageNameFunction(PageName);
            //
            PLANTNAME = "WRM";
            TempData["plantname"] = PLANTNAME;
            SIDE_MENU_DATA dataside = new SIDE_MENU_DATA();
            List<SideMenu> lst = dataside.GetSIdeMenuDAta(PLANTNAME);
            ViewBag.SideMenuData = lst;

            BL_WRMDash obj = new BL_WRMDash();
            MultipleData table = obj.GetDataForDashboard(fromName1, toName1, fromName2, toName2, fromName3, toName3, SelectValue);

            Session["Message"] = "Hello MVC!";
            return View(table);
            
        }
        public ActionResult WrmDash(String PLANTNAME)
        {
            //For Hits
            string PageName = "WRM/WrmDash";
            int Count = 0;
            Count = Request.HttpMethod != "POST" ? HitsFunction.FunctionForPageHits(PageName, "Yes") : HitsFunction.FunctionForPageHits(PageName, "No");
            ViewBag.PageHitsData = Count;
            ViewBag.PageName = HitsFunction.PageNameFunction(PageName);
            //
            PLANTNAME = "WRM";
            TempData["plantname"] = PLANTNAME;
            SIDE_MENU_DATA dataside = new SIDE_MENU_DATA();
            List<SideMenu> lst = dataside.GetSIdeMenuDAta(PLANTNAME);
            ViewBag.SideMenuData = lst;

            var table = new MultipleData();

            //table.MainMenu = db.MainMenus.Include(c => c.SubMenus).ToList();
            table.WRM_PROCESS_SPEC1 = dbWrmDashbord.WRM_PROCESS_SPEC.ToList();

           

            return View(table);

        }
        public ActionResult Stelmore_Line(String TextName1, String TextName2, String TextName3, String TextName4, String TextName5, String TextName6, String TextName7, String PLANTNAME)
        {
            //For Hits
            string PageName = "WRM/Stelmore_Line";
            int Count = 0;
            Count = Request.HttpMethod != "POST" ? HitsFunction.FunctionForPageHits(PageName, "Yes") : HitsFunction.FunctionForPageHits(PageName, "No");
            ViewBag.PageHitsData = Count;
            ViewBag.PageName = HitsFunction.PageNameFunction(PageName);
            //
            PLANTNAME = "WRM";
            TempData["plantname"] = PLANTNAME;
            SIDE_MENU_DATA dataside = new SIDE_MENU_DATA();
            List<SideMenu> lst = dataside.GetSIdeMenuDAta(PLANTNAME);
            ViewBag.SideMenuData = lst;

            if (Request.HttpMethod == "GET")
            {
                Session["count"] = 0;
            }
            BL_Stelmore obj = new BL_Stelmore();
            MultipleData table = obj.GetDataForStelmore(TextName1, TextName2, TextName3, TextName4, TextName5, TextName6, TextName7);

          

            

            return View(table);

        }
        public ActionResult Counter_Chart(String fromName1, String toName1, String Username, String Password, String WaterBox1, String WaterBox2, String WaterBox3, String WaterBox4, String CC_SHARECUT, String CD_SHARECUT, String LiftingDown, String PeelBar, String TroughSwitch, String ChangeDAtetime, String PLANTNAME)
        {
            //For Hits
            string PageName = "WRM/Counter_Chart";
            int Count = 0;
            Count = Request.HttpMethod != "POST" ? HitsFunction.FunctionForPageHits(PageName, "Yes") : HitsFunction.FunctionForPageHits(PageName, "No");
            ViewBag.PageHitsData = Count;
            ViewBag.PageName = HitsFunction.PageNameFunction(PageName);
            //
            PLANTNAME = "WRM";
            TempData["plantname"] = PLANTNAME;
            SIDE_MENU_DATA dataside = new SIDE_MENU_DATA();
            List<SideMenu> lst = dataside.GetSIdeMenuDAta(PLANTNAME);
            ViewBag.SideMenuData = lst;

            var gahgshg= RedirectToAction("Request");
            if (Request.HttpMethod == "GET")
            {
                Username = null;
                Password = null;
            }
            BL_DeviceCounter obj = new BL_DeviceCounter();
            MultipleData table = obj.GetDataForDeviceCounter( fromName1,  toName1,  Username,  Password,  WaterBox1,  WaterBox2,  WaterBox3,  WaterBox4,  CC_SHARECUT,  CD_SHARECUT,  LiftingDown,  PeelBar,  TroughSwitch, ChangeDAtetime);

            return View(table);

        }
        public ActionResult Contact1()
        {
            ViewBag.Message = "Your contact page.";
            var data = Convert.ToInt32("A");

            return View(data);
        }

    }
}



