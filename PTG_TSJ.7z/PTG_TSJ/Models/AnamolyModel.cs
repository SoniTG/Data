﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PTG_TSJ_Main.Models
{
    public class AnamolyModel
    {
        public DateTime DATADATETIME { get; set; }
        public string TOP_ROLL_HEALTH { get; set; }
        public string BOT_ROLL_HEALTH { get; set; }
    }

    public class AnamolyInputModel
    {
        public string dt { get; set; }
        public string stand { get; set; }

        public string fromdt { get; set; }

        public string  todt { get; set; }
    }
}