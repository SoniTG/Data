﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PTG_TSJ_Main.Models
{
    public class DBQuery
    {
        public T[] RunQuery<T>(System.Data.Entity.DbContext context, String Query)
        {
            try
            {
                return context.Database.SqlQuery<T>(Query).ToArray();
            }
            catch (Exception)
            {
                return null;
            }
            
        }
    }
}