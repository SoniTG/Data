﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PTG_TSJ_Main.Models
{
    public class MyModel
    {
        public string WFS_OFFLINEINSP_REASON { get; set; }
        public double WFS_WEIGHT_SUM_OFFLINE { get; set; }

        public string WFS_ONLINEINSP_REASON { get; set; }
        public double WFS_WEIGHT_SUM_ONLINE { get; set; }
        public string reason { get; set; }
        public double tot { get; set; }

        public int WCR_REM_BLTS { get; set; }
        public string WCR_CD_QLTY { get; set; }
    }
    //public class WRM_TROUGHSWITCH1
    //{
    //    public string FULL_FILENAME { get; set; }
    //    public string FILENAME { get; set; }
    //    public DateTime START_TIME { get; set; }
    //    public int COUNT { get; set; }
    //    public string TIMESTAMP { get; set; }
    //}
    public class WRM_TROUGHSWITCH2
    {
        public string FULL_FILENAME { get; set; }
        public string FILENAME { get; set; }
        public DateTime START_TIME { get; set; }
        public int COUNT { get; set; }
        public string TIMESTAMP { get; set; }
        public int SL_NO { get; set; }

    }
    public class BoxesData
    {
        public string PMD_MAIN_DIV { get; set; }
        public string PMD_CONTROLLER { get; set; }
        public string PMD_ACTION_MTD { get; set; }
        public string PMD_COLOR { get; set; }
        public string PMD_MAIN_ACTION_MTD { get; set; }
        public string PMD_MAIN_DIV_CONTROLLER { get; set; }


    }
    public class Millglance
    {
        public string CSE_TS_SAMPLING { get; set; }
        public string CSR_TS_TEST { get; set; }
        public string CSR_TEST_PARA { get; set; }
        public decimal CSR_TEST_VAL { get; set; }
        public string CSE_TS_TST_OVR { get; set; }
        public DateTime PEM_STARTTIME { get; set; }
        public decimal PL_MIN_LIMIT { get; set; }
        public decimal PL_MAX_LIMIT { get; set; }
        public string PL_PARAM_NAME { get; set; }
        public int PL_SL_NO { get; set; }
        public string PEM_SPD_STDDEV_MAX { get; set; }
        public DateTime  CPAT_START_TIME { get; set; }
        public string CPAT_VAR_VAL_BOXPLOT { get; set; }


    }
    public class Pltcm_Encoder
    {
        public string PEM_FILENAME { get; set; }
        public DateTime PEM_STARTTIME { get; set; }
        public string PEM_SPD_STDDEV_MAX { get; set; }
        public string Systemname { get; set; }

        public int PL_SL_NO { get; set; }
        public string PL_PARAM_NAME { get; set; }
        public decimal PL_MAX_LIMIT { get; set; }
        public decimal PL_MIN_LIMIT { get; set; }
        public string PL_ALIAS { get; set; }
        public string PL_SIGNAL_CATEGORY { get; set; }
        public int PL_SEQ_NO { get; set; }
        public string PL_HEADER_NAME { get; set; }
        public int PL_ACTIVE { get; set; }

    }

    public class Bridge_Roll
    {
     
        public int Sq_No { get; set; }
        public string CPAT_VAR_NAME { get; set; }
        public string CPAT_VAR_NAME_ALIAS { get; set; }
        public string Multiplier { get; set; }
        public string LSL { get; set; }
        public string  USL { get; set; }
        public string CPAT_START_TIME { get; set; }
        public string CPAT_VAR_VAL_BOXPLOT { get; set; }
        
        

    }
    public class PLTANK
    {

        public DateTime CSE_TS_SAMPLING { get; set; }
        public DateTime CSR_TS_TEST { get; set; }
        public string CSR_TEST_PARA { get; set; }
        public decimal CSR_TEST_VAL { get; set; }
        public DateTime CSE_TS_TST_OVR { get; set; }
        
    }
    public class Sub_Chart
    {

        public int PL_SL_NO { get; set; }
        public decimal PL_MAX_LIMIT { get; set; }
        public string PEM_FILENAME { get; set; }
        public DateTime PEM_STARTTIME { get; set; }
        public string PEM_SPD_STDDEV_MAX { get; set; }
        public string Systemname { get; set; }


    }
    public class CPCdata
    {
        public DateTime CPCT_START_TIME { get; set; }
        public string Strip1 { get; set; }
        public string Strip2 { get; set; }
        public string Strip3 { get; set; }
        public string Strip4 { get; set; }
        public string Strip5 { get; set; }
        public string Strip6 { get; set; }
        public string Strip7 { get; set; }
        public string Cylinder1 { get; set; }
        public string Cylinder2 { get; set; }
        public string Cylinder3 { get; set; }
        public string Cylinder4 { get; set; }
        public string Cylinder5 { get; set; }
        public string Cylinder6 { get; set; }
        public string Cylinder7 { get; set; }
    }
    public class crmlab
    {
       
        public string CLR_PROCESS_LINE { get; set; }
        public string PARAM_TEST { get; set; }
        public string CLR_PARAM_TEST { get; set; }

    }
    public class CrmLabChart
    {
        public decimal CLR_TEST_VALUE { get; set; }
        public DateTime CLR_DT_SAMPLING_DATE { get; set; }
        public decimal CLR_PARAM_MIN { get; set; }
        public string CLR_PARAM_TEST_NEW { get; set; }
        public string CLR_PARAM_TEST { get; set; }
    }
    public class WelderData
    {
        public decimal CPW_LIMIT_MAX { get; set; }
        public string CPW_PARAM_NAME { get; set; }
        public string CPW_PARAM_ALIAS { get; set; }
       
        public string CPW_FILENAME { get; set; }
        public DateTime CPW_DATETIME { get; set; }
        public decimal CPW_PARAM_VAL { get; set; }
        public string COMPUTER_NAME { get; set; }

    }
    public class SpmDetailsAnls
    {
        public string TDC_No { get; set; }
        public string C1 { get; set; }
        public string C2 { get; set; }
        public string DAUGHTER_COILID_NUM { get; set; }
        public string VALCOILID { get; set; }
        public string GRADE { get; set; }
        public decimal Min { get; set; }
        public decimal Max { get; set; }
        public byte[] RAW_DATA_FILE { get; set; }
        public decimal ELONGATION_SET_ORA { get; set; }
        public string PARAMETER_NAME { get; set; }
        public string MULTIPLIER { get; set; }
        public string UNIT { get; set; }


    }

    public class PageHitsData
    {

        public DateTime TIMESTAMP { get; set; }
        public int Count { get; set; }

    }
    public class historical
    {
        public string PL_ALIAS { get; set; }
        public int PL_SL_NO { get; set; }



    }

    public class historicaldata
    {
        public DateTime PEM_STARTTIME { get; set; }
        public string PEM_SPD_STDDEV_MAX { get; set; }
    }
    public class SCUM_ANALYTICS_Data
    {
       
        public string GRADE { get; set; }
        public string Defect_Name { get; set; }
        public string[] sp_tdc { get; set; }
        public string String1 { get; set; }

        public DateTime? DATECREATE { get; set; }
        public string ALIAS { get; set; }
        public string SURFACE { get; set; }
        public string  DEFECT_ST_WIDTH { get; set; }
        public string  DEFECT_END_WIDTH { get; set; }
        public int? LENSEVERITY { get; set; }
        public string rcl_coil { get; set; }
        public DateTime? RCL1_DATETIME { get; set; }
        public DateTime? RCL2_DATETIME { get; set; }
        public DateTime? RCL3_DATETIME { get; set; }
        public string noCloumn { get; set; }
        public string TDC_No { get; set; }
        public string WIDTH { get; set; }
        public DateTime? TCM_ROLLING_DT { get; set; }
        public string Sec2_PDI { get; set; }
        public string HR_COILIID { get; set; }
        public string CR_COILID { get; set; }
        public decimal PLTCM_MIN_SPD { get; set; }
        public decimal PLTCM_AVG_SPD { get; set; }
        public decimal PLTCM_MAX_SP_PLT { get; set; }
        public decimal TL_Elongation_Min { get; set; }
        public decimal TL_Elongation_Avg { get; set; }
        public decimal TL_Elongation_Max { get; set; }
        public decimal? HRC_FRT { get; set; }
        public decimal? HRC_CT { get; set; }
        public decimal? HRC_CROWN { get; set; }
        public decimal? HRC_WEDGE { get; set; }
        public string dtLab { get; set; }
        public string CYC_COLOR { get; set; }
        public string FFT_COLOR { get; set; }
        public string PL_SPEED_020 { get; set; }
       
        public string PL_SPEED_2040 { get; set; }
        public string PL_SPEED_4060 { get; set; }
        public string PL_SPEED_6080 { get; set; }
        public string PL_SPEED_80100 { get; set; }
        public string remark { get; set; }
        public string goodbad { get; set; }


    }
    public class ScumDataColumn
    {
        public string Width { get; set; }
        public string Date { get; set; }
        public string  COILID { get; set; }
        public string HR_COILID { get; set; }
        public string THICKNESS { get; set; }
        public string ROLLING_DATE { get; set; }
        public string HR_CR_WIDTH { get; set; }
        public string TDC1 { get; set; }
        public string PL_SPEED { get; set; }
        public string P1 { get; set; }
        public string P2 { get; set; }
        public string Prediction { get; set; }
        public string Remark { get; set; }
        public string SCUM_C_TOP_1 { get; set; }
        public string TDC { get; set; }
        public string SCUM_C_TOP_2 { get; set; }
        public string SCUM_C_TOP_3 { get; set; }
        public string SCUM_C_TOP_4 { get; set; }
        public string SCUM_C_TOP_5 { get; set; }
        public string SCUM_C_BOTTOM_1 { get; set; }
        public string SCUM_C_BOTTOM_2 { get; set; }
        public string SCUM_C_BOTTOM_3 { get; set; }
        public string SCUM_C_BOTTOM_4 { get; set; }
        public string SCUM_C_BOTTOM_5 { get; set; }
        public string SCUM_D_TOP_1 { get; set; }
        public string SCUM_D_TOP_2 { get; set; }
        public string SCUM_D_TOP_3 { get; set; }
        public string SCUM_D_TOP_4 { get; set; }
        public string SCUM_D_TOP_5 { get; set; }
        public string SCUM_D_BOTTOM_1 { get; set; }
        public string SCUM_D_BOTTOM_2 { get; set; }
        public string SCUM_D_BOTTOM_3 { get; set; }
        public string SCUM_D_BOTTOM_4 { get; set; }
        public string SCUM_D_BOTTOM_5 { get; set; }
        public string SCUM_X_TOP_1 { get; set; }
        public string SCUM_X_TOP_2 { get; set; }
        public string SCUM_X_TOP_3 { get; set; }
        public string SCUM_X_TOP_4 { get; set; }
        public string SCUM_X_TOP_5 { get; set; }
        public string SCUM_X_BOTTOM_1 { get; set; }
        public string SCUM_X_BOTTOM_2 { get; set; }
        public string SCUM_X_BOTTOM_3 { get; set; }
        public string SCUM_X_BOTTOM_4 { get; set; }
        public string SCUM_X_BOTTOM_5 { get; set; }

        public string PL_SPEED_MIN { get; set; }
        public string PL_SPEED_AVG { get; set; }
                             
        public string PL_SPEED_MAX { get; set; }
        public string TL_ELONG_MIN { get; set; }
        public string TL_ELONG_AVG { get; set; }
        public string TL_ELONG_MAX { get; set; }
        public string HRC_FRT { get; set; }
        public string HRC_CT { get; set; }
        public string HRC_CROWN { get; set; }
        public string HRC_WEDGE { get; set; }
        public decimal? HCL_ACID_T1 { get; set; }
        public decimal? HCL_ACID_T2 { get; set; }
        public decimal? HCL_ACID_T3 { get; set; }
        public decimal? HCL_ACID_T4 { get; set; }
        public decimal? IRON_T1 { get; set; }
        public decimal? IRON_T2 { get; set; }
        public decimal? IRON_T3 { get; set; }
                   
        public decimal? IRON_T4  { get; set; }
    
    }
    public class dtAlData
    {
        public decimal CLR_TEST_VALUE { get; set; }
        public decimal CLR_PARAM_MIN { get; set; }
        public DateTime CLR_DT_SAMPLING_DATE { get; set; }
    }
    public class dtFeData
    {
        public decimal CLR_TEST_VALUE { get; set; }
        //public string CLR_DT_SAMPLING_DATE { get; set; }
    }
    public class dttransitiondata
    {
        public decimal? CZT_EFF_AL { get; set; }

        public decimal? CZT_EFF_FE { get; set; }

        public DateTime CZT_TIMESTAMP { get; set; }
        public string CZT_CAMP_AL { get; set; }
        public decimal? CZT_POT_AL { get; set; }
        public decimal? CZT_POT_FE { get; set; }
        public string CAMPAIGN { get; set; }
        public decimal? UCL { get; set; }
        public decimal? LCL { get; set; }

    }
    public class dtt1
    {
        public string PRM_CD_SURF_ROUGH { get; set; }

        public DateTime PRM_TS_END { get; set; }
        public decimal sum { get; set; }
        public int count { get; set; }

    }
    public class dtt2
    {

        public string PRM_CD_SURF_ROUGH { get; set; }

        public DateTime PRM_TS_END { get; set; }
        public int count { get; set; }
        public decimal Fe { get; set; }
        public decimal Al { get; set; }
        public DateTime RESET_DATE_TIME { get; set; }

    }
    public class dtt3
    {

        public string PRM_CD_SURF_ROUGH { get; set; }

        public DateTime PRM_TS_END { get; set; }
        public int count { get; set; }
        public decimal? Fe { get; set; }
        public decimal? Al { get; set; }
        public DateTime RESET_DATE_TIME { get; set; }
        public decimal ds { get; set; }
        public decimal dt { get; set; }

    }


}