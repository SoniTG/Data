$(function () {
    var stD, enD;
    if ($('#hfFrom').val() != "") {
        stD = moment($('#hfFrom').val());
        enD = moment($('#hfTo').val());
    }
    else {
        stD = moment().subtract('days', 29);
        enD = moment();
    }
    /* reportrange */
    if ($("#reportrange").length > 0) {
        $("#reportrange").daterangepicker({
            ranges: {
                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                'This Month': [moment().startOf('month'), moment().endOf('month')],
                'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            },
            timePicker: true,
            opens: 'left',
            buttonClasses: ['btn btn-default'],
            applyClass: 'btn-small btn-primary',
            cancelClass: 'btn-small',
            format: 'DD.MM.YYYY hh:mm A',
            separator: ' to ',
            startDate: stD,
            endDate: enD
        }, function (start, end) {
            $('#reportrange span').html(start.format('DD.MMM.YY hh:mm A') + ' - ' + end.format('DD.MMM.YY hh:mm A'));
        });
        if ($('#hfFrom').val() == "") {
            $("#reportrange span").html(moment().subtract('days', 29).format('DD.MMM.YY hh:mm A') + ' - ' + moment().format('DD.MMM.YY hh:mm A'));
            //            $("#reportrange span").html(moment().subtract('days', 29).format('YYYY-MM-DD HH:mm:ss') + ' - ' + moment().format('YYYY-MM-DD HH:mm:ss'));
            $('#hfFrom').val((moment().subtract('days', 29).format('YYYY-MM-DD HH:mm:ss')));
            //            $("#reportrange span").html(moment().subtract('months', 4).format('DD.MMM.YY hh:mm A') + ' - ' + moment().format('DD.MMM.YY hh:mm A'));
            //            $('#hfFrom').val((moment().subtract('months', 4).format('YYYY-MM-DD HH:mm:ss')));
            $('#hfTo').val((moment().format('YYYY-MM-DD HH:mm:ss')));
        }
        else {
            $("#reportrange span").html(moment($('#hfFrom').val()).format('DD.MMM.YY hh:mm A') + ' - ' + moment($('#hfTo').val()).format('DD.MMM.YY hh:mm A'));
        }
        //$("#reportrange span").html(moment().subtract('days', 29).format('MMMM D, YYYY') + ' - ' + moment().format('MMMM D, YYYY'));
    }


    //$(function(){        
    //    /* reportrange */
    //    if($("#reportrange").length > 0){   
    //        $("#reportrange").daterangepicker({                    
    //            ranges: {
    //                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
    //                'This Month': [moment().startOf('month'), moment().endOf('month')],
    //                'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
    //            },
    //            opens: 'left',
    //            buttonClasses: ['btn btn-default'],
    //            applyClass: 'btn-small btn-primary',
    //            cancelClass: 'btn-small',
    //            format: 'MM.DD.YYYY',
    //            separator: ' to ',
    //            startDate: moment().subtract('days', 29),
    //            endDate: moment()            
    //        },function(start, end) {
    //            $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
    //        });

    //        $("#reportrange span").html(moment().subtract('days', 29).format('MMMM D, YYYY') + ' - ' + moment().format('MMMM D, YYYY'));
    //    }
    /* end reportrange */
    //    var s1 = [2, 6, 7, 10];
    //    var ticks = ['a', 'b', 'c', 'd'];

    //    plot1 = $.jqplot('chart1', [s1], {
    //        // Only animate if we're not using excanvas (not in IE 7 or IE 8)..
    //        animate: !$.jqplot.use_excanvas,
    //        seriesDefaults: {
    //            renderer: $.jqplot.BarRenderer,
    //            pointLabels: { show: true }
    //        },
    //        axes: {
    //            xaxis: {
    //                renderer: $.jqplot.CategoryAxisRenderer,
    //                ticks: ticks
    //            }
    //        },
    //        highlighter: { show: false }
    //    });

    //    $('#chart1').bind('jqplotDataClick',
    //            function (ev, seriesIndex, pointIndex, data) {
    //                $('#info1').html('series: ' + seriesIndex + ', point: ' + pointIndex + ', data: ' + data);
    //            }
    //        );
    /* Donut dashboard chart */
    //    Morris.Donut({
    //        element: 'dashboard-donut-1',
    //        data: [
    //            {label: "Returned", value: 2513},
    //            {label: "New", value: 764},
    //            {label: "Registred", value: 311}
    //        ],
    //        colors: ['#33414E', '#1caf9a', '#FEA223'],
    //        resize: true
    //    });
    /* END Donut dashboard chart */

    /* Bar dashboard chart */
    //   dashboard_bar_3 = Morris.Bar({
    //        element: 'dashboard-bar-3',
    //        data: [
    //            { y: '', a: 10, b:10, c:10,d:10,e:10,f:10,g:10 }            
    //        ],
    //        xkey: 'y',
    //        ykeys: ['a','b','c','d','e','f','g'],
    //        labels: ['Day1','Day2','Day3'],
    //        gridTextSize: '10px',
    //        barSizeRatio: 1,
    //        ymin: 0,
    //        ymax: 100,
    //        axes: 'y',
    //        hideHover: true,
    //        resize: true,
    //        stacked: true,
    //        gridLineColor: '#E5E5E5'
    //    });

    //    dashboard_bar_2 = Morris.Bar({
    //        element: 'dashboard-bar-2',
    //        data: [
    //            { y: 'Oct 10', a: 75, b: 35 },
    //            { y: 'Oct 11', a: 64, b: 26 },
    //            { y: 'Oct 12', a: 78, b: 39 },
    //            { y: 'Oct 13', a: 82, b: 34 },
    //            { y: 'Oct 14', a: 86, b: 39 },
    //            { y: 'Oct 15', a: 94, b: 40 },
    //            { y: 'Oct 16', a: 96, b: 41 }
    //        ],
    //        xkey: 'y',
    //        ykeys: ['a', 'b'],
    //        labels: ['New Users', 'Returned'],        
    //        gridTextSize: '10px',
    //        hideHover: true,
    //        resize: true,
    //        stacked: true,
    //        gridLineColor: '#E5E5E5'
    //    });
    //    /* END Bar dashboard chart */
    //    
    //    /* Line dashboard chart */
    //    Morris.Line({
    //      element: 'dashboard-trend-1',
    //      data: [
    //        { "period": "2011 Q3", "licensed": 20, "sorned": 30, "ttip":"abcs" },
    //       { "period": "2011 Q2", "licensed": 20, "sorned": 30, "ttip": "abcs" },
    //       { "period": "2011 Q1", "licensed": 25, "sorned": 33, "ttip": "abcs" },
    //       { "period": "2010 Q4", "licensed": 21, "sorned": 44, "ttip": "abcs" },
    //       { "period": "2009 Q4", "licensed": 22, "sorned": 12, "ttip": "abcs" },
    //       { "period": "2008 Q4", "licensed": 31, "sorned": 11, "ttip": "abcs" },
    //       { "period": "2007 Q4", "licensed": 41, "sorned": 21, "ttip": "abcs" },
    //       { "period": "2006 Q4", "licensed": 31, "sorned": null, "ttip": "abcs" },
    //       { "period": "2005 Q4", "licensed": 31, "sorned": null, "ttip": "abcs" }
    //      ],
    //      xkey: 'period',
    //      ykeys: ['licensed', 'sorned'],     
    //      labels: ['Sales','Event'],
    //      resize: true,
    //      hideHover: true,
    //      xLabels: 'day',
    //      gridTextSize: '10px',
    //      lineColors: ['#1caf9a','#33414E'],
    //      gridLineColor: '#E5E5E5',
    //      hoverCallback: function (index, options, content) {
    //          var data = options.data[index];
    //          $(".morris-hover").html('<div>Custom label: ' + data.ttip + '</div>');
    //      }
    //  });

    //  new Morris.Line({
    //      element: 'dashboard-trend-2',
    //      xkey: 'year',
    //      ykeys: ['value'],
    //      labels: ['Value'],
    //      data: [
    //      { year: '2008', value: 20 },
    //      { year: '2009', value: 10 },
    //      { year: '2010', value: null },
    //      { year: '2011', value: 5 },
    //      { year: '2012', value: 20 }
    //    ]
    //  });

    //  new Morris.Line({
    //      element: 'dashboard-trend-3',
    //      xkey: 'year',
    //      ykeys: ['value'],
    //      labels: ['Value'],
    //      data: [
    //      { year: '2008', value: 20 },
    //      { year: '2009', value: 10 },
    //      { year: '2010', value: 5 },
    //      { year: '2011', value: 5 },
    //      { year: '2012', value: 20 }
    //    ]
    //  });

    //  new Morris.Line({
    //      element: 'dashboard-trend-4',
    //      xkey: 'year',
    //      ykeys: ['value'],
    //      labels: ['Value'],
    //      data: [
    //      { year: '2008', value: 20 },
    //      { year: '2009', value: 10 },
    //      { year: '2010', value: 5 },
    //      { year: '2011', value: 5 },
    //      { year: '2012', value: 20 }
    //    ]
    //  });
    //    /* EMD Line dashboard chart */
    //    /* Moris Area Chart */
    //      Morris.Area({
    //      element: 'dashboard-area-1',
    //      data: [
    //        { y: '2014-10-10', a: 10,b: 40, c:25},
    //        { y: '2014-10-12', a: 10, b: 40,c:25 }
    //      ],
    //      xkey: 'y',
    //      ykeys: ['a','b','c'],
    //      labels: ['Day1','Day2','Day3'],
    //      resize: true,
    //      hideHover: true,
    //      xLabels: 'day',
    //      axes: 'y',
    //      ymin:0,
    //      ymax: 100,
    //      gridTextSize: '10px',
    //      gridLineColor: '#E5E5E5'
    //    });
    /* End Moris Area Chart */



});

