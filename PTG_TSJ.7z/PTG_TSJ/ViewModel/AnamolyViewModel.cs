﻿using PTG_TSJ_Main.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PTG_TSJ_Main.ViewModel
{
    public class AnamolyViewModel
    {
        public  List<AnamolyModel> lstData { get; set; }

        public AnamolyInputModel im { get; set; }

        public string chartData { get; set; }
    }
}