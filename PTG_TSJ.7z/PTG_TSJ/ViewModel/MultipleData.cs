﻿using PTG_TSJ_Main.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PTG_TSJ_Main.ViewModel
{
    public class MultipleData
    {
        public IEnumerable<PtgMainMenu> PtgMainMenu { get; set; }
        //public IEnumerable<MainMenu> MainMenu { get; set; }
        public IEnumerable<WRM_Mill_Parameter> WRM_Mill_Parameter1 { get; set; }
        public IEnumerable<WRM_Mill_Parameter> WRM_Mill_Parameter2 { get; set; }
        public IEnumerable<WRM_Mill_Parameter> WRM_Mill_Parameter3 { get; set; }
        public IEnumerable<WRM_PROCESS_SPEC> WRM_PROCESS_SPEC1 { get; set; }
        public IEnumerable<CHART_LP11> ChartData { get; set; }
        public IEnumerable<InputBoxData> InputBoxData { get; set; }
        public IEnumerable<ModelBox> ModelData { get; set; }
        public IEnumerable<FromDateToDate> FromDateToDate { get; set; }
        public IEnumerable<FormDAta> FormData { get; set; }
        public IEnumerable<T_WRM_FG_STOCK> T_WRM_FG_STOCK { get; set; }
        public IEnumerable<T_WRM_QUALITY_MAST> T_WRM_QUALITY_MAST { get; set; }
        public IEnumerable<T_WRM_CAST_RECEIPT> T_WRM_CAST_RECEIPT { get; set; }
        public IEnumerable<PtgMainMenuString> PtgMainMenuString { get; set; }
        public IEnumerable<SideMenu> SideMenu { get; set; }
        public IEnumerable<CheckBoxData> CheckBoxData { get; set; }
        public IEnumerable<CardData> CardData { get; set; }
        public IEnumerable<RedioButtonData> RedioButtonData { get; set; }
        public IEnumerable<SelectOption> SelectOption { get; set; }
        public IEnumerable<MenuBoxes> MenuBoxes { get; set; }
        public string selectedHistEncoder { get; set; }
        public IEnumerable<historical> hist { get; set; }
        public IEnumerable<historicaldata> histdata { get; set; }
        public IEnumerable<ScumDataColumn> ScumDataColumn { get; set; }
        public string SeriesData { get; set; }
        public string X_Axis { get; set; }
        public string Y_Axis { get; set; }
        public double? pottemp { get; set; }

        public double? totalai { get; set; }


        public double? totalfe { get; set; }

        //public DateTime? Al_Date { get; set; }
        //public DateTime? Fe_Date { get; set; }



        public string lblSamplingDateAL { get; set; }
        public string lblSamplingDateFE { get; set; }


        public double txtAIEffective { get; set; }

        public double txtFEEffective { get; set; }

        public double txtAITriplePoint { get; set; }

        public double txtFETriplePoint { get; set; }

        public string litLineGraph { get; set; }

        public string litEffGraph { get; set; }
        public string litLabelPosition { get; set; }

        public string lblError { get; set; }

        public DateTime txt_Tran_From_Date { get; set; }

        public DateTime txt_Tran_To_Date { get; set; }

        public Boolean btn_on { get; set; }

        public Boolean btn_off { get; set; }

        public Boolean btn_trans_on { get; set; }


        public Boolean btn_trans_off { get; set; }






        public DateTime DateTo { get; set; }

        public DateTime DateFrom { get; set; }
        public string dst { get; set; }
        public string det { get; set; }
        public string sumtotal { get; set; }

        public string lblGAWeight { get; set; }

        public string lblAlReqToRaiseAlLevel { get; set; }

        public string lblAlReqFeSolubility { get; set; }


        public string lblCalFeInDross { get; set; }
        public string lblCalDross { get; set; }

        public string lblAlReqConvrtBottomDross { get; set; }
        public string lblTotalAlCharged { get; set; }

        public string lblRecoveryLossError { get; set; }
        public string lblMinAlBlocksCharged { get; set; }
        public string lblNoOfDaysGACampaign { get; set; }

        public string lblStart { get; set; }

        public string lblEnd { get; set; }

        public string litChart { get; set; }

        public string litChart1 { get; set; }

        public decimal[] dt { get; set; }

        public decimal[] dt1 { get; set; }






    }

    public partial class CHART_LP11
        {
            public string ID { get; set; }
            public Nullable<int> Height { get; set; }
            public string Width { get; set; }
            public string Title { get; set; }
            public string TypeY { get; set; }
            public string MaxAxisData { get; set; }
            public string MinAxisData { get; set; }
            public string SeriesData { get; set; }
            public string ShowLegend { get; set; }
            public string ShowTitle { get; set; }
            public string ShowToolBox { get; set; }
            public string TypeX { get; set; }
            public string FromDate { get; set; }
            public string ToDate { get; set; }
            public string FromDateName { get; set; }
            public string ToDateName { get; set; }
            public string FromdateId { get; set; }
            public string todateId { get; set; }
            public string Section { get; set; }
            public string SectionValue { get; set; }
            public string SectionData { get; set; }
            public string Heat { get; set; }
            public string ticks { get; set; }
            public string line1 { get; set; }
            public string line2 { get; set; }
            public string line3 { get; set; }
            public string line4 { get; set; }
            public string line5 { get; set; }
            public string markline { get; set; }
            public string plottype { get; set; }
            public string divcolsm { get; set; }
            public string divHeight { get; set; }
            public string yAxisName { get; set; }

    }
    public partial class InputBoxData
    {
        public string InputBoxName { get; set; }
        public string InputId { get; set; }
        public string InputName { get; set; }
        public string InputLabelName { get; set; }
        public string InputType { get; set; }
        public string InputValue { get; set; }
        public string InputPlaceHolder { get; set; }
    }
    public partial class FormDAta
    {
       
        public string InputValue1 { get; set; }
        public string InputValue2 { get; set; }
        public string InputValue3 { get; set; }
        public string InputValue4 { get; set; }
        public string InputValue5 { get; set; }
        public string InputValue6 { get; set; }
        public string InputValue7 { get; set; }
        public string InputValue8 { get; set; }
        public string InputValue9 { get; set; }
        public string InputValue66 { get; set; }
        public string InputValue77 { get; set; }
        public string InputValue88 { get; set; }
        public string InputValue99 { get; set; }

    }
    public partial class FromDateToDate
    {
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string FromDateName { get; set; }
        public string ToDateName { get; set; }
        public string FromdateId { get; set; }
        public string todateId { get; set; }
        public string ID { get; set; }
        public string Section { get; set; }
        public string Heat { get; set; }
        public string[] SelectOption { get; set; }
       
    }

    public partial class ModelBox
    {
        public string ModelName { get; set; }
        public string LgUserName { get; set; }
        public string LgPassword { get; set; }
        public string ButtonName { get; set; }


    }
    public partial class PtgMainMenu
    {
        public string PMD_MAIN_AREA { get; set; }
        public string PMD_MAIN_AREA_ID { get; set; }
        public string PMD_SUB_AREA { get; set; }
        public string PMD_SUB_AREA_ID { get; set; }
        public string PMD_MAIN_DIV { get; set; }
        public string PMD_MAIN_DIV_ID { get; set; }
        public string PMD_SUB_DIV { get; set; }
        public string PMD_SUB_DIV_ID { get; set; }
        public string ColorName { get; set; }
        public string PMD_MAIN_AREA1 { get; set; }
        public string PMD_SUB_AREA1 { get; set; }
        public string PMD_MAIN_DIV1 { get; set; }
        public string PMD_SUB_DIV1 { get; set; }


    }
    public partial class PtgMainMenuString
    {
        public string PMD_MAIN_AREA_String { get; set; }
        


    }
    public partial class SideMenu
    {
        public string MainMenu { get; set; }
        public string[] SubMenu { get; set; }
        public string[] ActionName { get; set; }
        public string[] ControllerName { get; set; }
       
    }
    public partial class CheckBoxData
    {
        public string DrplData { get; set; }
        public string[] CheckBoxName { get; set; }
        public string[] CheckBoxValue { get; set; }
        public string[] CheckBoxChecked { get; set; }
        public string BtnData { get; set; }
        public string SelectName { get; set; }


    }
    public partial class CardData
    {
        public string ImgagePath { get; set; }
        public string ImgageName { get; set; }
        public string BtnId { get; set; }
        
    }
    public partial class RedioButtonData
    {
        public string Valuedata { get; set; }
        public string Labledata { get; set; }
        public string Forchecked { get; set; }
        public string Forchecked1 { get; set; }

    }
    public partial class SelectOption
    {
        public string SectionData { get; set; }
        public string ForOptCondition { get; set; }
        public string ForSelected { get; set; }
        public string OptionName { get; set; }
    }
    public partial class MenuBoxes
    {
        public string Box_Color { get; set; }
        public string Box_id { get; set; }
        public string Box_catgry { get; set; }
        public string Box_Name { get; set; }
        public string Box_Image { get; set; }
    }
}