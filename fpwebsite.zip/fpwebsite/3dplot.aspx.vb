﻿Imports OfficeOpenXml
Partial Class _3dplot
    Inherits System.Web.UI.Page

    Private Sub _3dplot_Load(sender As Object, e As EventArgs) Handles Me.Load
        Using epplus As New ExcelPackage(New IO.FileInfo(Server.MapPath(".") & "\sample3ddata.xlsx"))
            Dim sht As ExcelWorksheet = epplus.Workbook.Worksheets(1)

            Dim r As Integer = sht.Dimension.End.Row
            Dim c As Integer = sht.Dimension.End.Column

            Dim xdata, ydata As String
            Dim data As String = ""

            For i As Integer = 0 To r - 2
                xdata &= ",'" & sht.Cells(i + 2, 1).Value & "'"
                For j As Integer = 0 To c - 2
                    If (i = 0) Then
                        ydata &= ",'" & (j + 1) & "'"
                    End If
                    data &= ",[" & i & "," & j & "," & sht.Cells(i + 2, j + 2).Value & "]"
                Next
            Next

            Dim s As String = ""
            s = "<script>echarts.init(document.getElementById('chart1')).setOption(" & vbCrLf &
                    "{" & vbCrLf &
   "tooltip:  {}," & vbCrLf &
  " visualMap:  {" & vbCrLf &
   "  max: 500,min:-500," & vbCrLf &
    " inRange: {" & vbCrLf &
     "  color: [" & vbCrLf &
         "    '#a50026'," & vbCrLf &
 "   '#d73027'," & vbCrLf &
 "     '#f46d43'," & vbCrLf &
      "   '#fdae61'," & vbCrLf &
 "    '#fee090'," & vbCrLf &
  "    '#ffffbf'," & vbCrLf &  
     "    '#e0f3f8'," & vbCrLf &
      "    '#abd9e9'," & vbCrLf &
        "    '#74add1'," & vbCrLf &
    "    '#4575b4'," & vbCrLf &
"    '#313695'" & vbCrLf &
   "    ]" & vbCrLf &
  "   }" & vbCrLf &
  " }," & vbCrLf &
  " xAxis3D: {" & vbCrLf &
 "    type: 'category'," & vbCrLf &
 "data :  [" & vbCrLf & ydata.Substring(1) & vbCrLf & "]" & vbCrLf &
  " }," & vbCrLf &
 "  yAxis3D: {" & vbCrLf &
  "   type: 'category'," & vbCrLf &
  "   data: [" & vbCrLf & xdata.Substring(1) & vbCrLf & "]" & vbCrLf &
  " }," & vbCrLf &
  " zAxis3D: {" & vbCrLf &
  "   type: 'value'" & vbCrLf &
  " }," & vbCrLf &
 "  grid3D: {" & vbCrLf &
   "  boxWidth: 200," & vbCrLf &
  "   boxDepth: 80," & vbCrLf &
  "   light :  {" & vbCrLf &
   "    main: {" & vbCrLf &
   "      intensity: 1.2" & vbCrLf &
   "    }," & vbCrLf &
   "    ambient: {" & vbCrLf &
   "      intensity: 0.3" & vbCrLf &
  "     }" & vbCrLf &
  "   }" & vbCrLf &
 "  }," & vbCrLf &
  " series: [" & vbCrLf &
  "   {" & vbCrLf &
    "   type: 'bar3D'," & vbCrLf &
  "     data: [" & vbCrLf & data.Substring(1) & vbCrLf & "].map(function (item) {" & vbCrLf &
  "       return {" & vbCrLf &
  "         value: [item[1], item[0], item[2]]" & vbCrLf &
  "       };" & vbCrLf &
  "     })," & vbCrLf &
   "    shading: 'color'," & vbCrLf &
   "    label: {" & vbCrLf &
    "     show: false," & vbCrLf &
     "    fontSize: 16," & vbCrLf &
  "       borderWidth: 1" & vbCrLf &
   "    }," & vbCrLf &
   "    itemStyle: {" & vbCrLf &
   "      opacity: 1" & vbCrLf &
   "    }," & vbCrLf &
  "     emphasis: {" & vbCrLf &
  "       label: {" & vbCrLf &
   "        fontSize: 20," & vbCrLf &
   "        color: '#900'" & vbCrLf &
  "       }," & vbCrLf &
  "       itemStyle: {" & vbCrLf &
  "         color: '#900'" & vbCrLf &
  "       }" & vbCrLf &
  "     }" & vbCrLf &
 "    }" & vbCrLf &
 "  ]" & vbCrLf &
 "});</script>"

            Lit1.Text = s


        End Using

    End Sub
End Class
