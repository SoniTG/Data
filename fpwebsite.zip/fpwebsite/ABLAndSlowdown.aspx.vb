﻿Imports System.Data
Imports System.Data.OleDb
Imports System.IO
Partial Class ABLAndSlowdown
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-5).ToString("yyyy-MM-dd HH:mm")
                'Dim dtStart As DateTime = DateTime.Now.AddMonths(-4).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

                'hfFrom.Value = dtStart
                'hfTo.Value = dtEnd
                ' Dim filter As String = " 1=1"
                DrawChartTop(dtStart, dtEnd, ddlCaster.SelectedItem.Text)





            Catch ex As Exception

            End Try
        End If
    End Sub




    Sub DrawChartTop(ByVal FromDt As String, ByVal ToDt As String, ByVal Caster As String)
        Try

            Dim dtStart As String = FromDt
            Dim dtEnd As String = ToDt


            'Dim dtLimits As DataTable = objController.PopulateLimitsForHMO()
            Dim dt As DataTable = objController.PopulateDataForABL(dtStart, dtEnd, Caster)
            Dim dt1 As DataTable = objController.PopulateDataForSlowDown(dtStart, dtEnd, Caster)
            objController.PlotBarGraphForABL(dt, Lit1, "container1", "plot1")
            objController.PlotBarGraphForSlowDown(dt1, Lit2, "container2", "plot2")
            'objController.LD3LINECHART(dt, Lit1, "container1", "plot1", "", dtLimits)


            'objController.LD3LINECHART(dtcast2, Lit2, "container2", "plot2", "", dtLimits)


        Catch ex As Exception

        End Try
    End Sub



    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try
            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            DrawChartTop(dtStart, dtEnd, ddlCaster.SelectedItem.Text)

        Catch ex As Exception

        End Try

    End Sub
    Private Sub ddlCaster_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlCaster.SelectedIndexChanged
        'If ddl1.SelectedIndex = 0 Then
        '    UserMsgBoxError("Select caster")
        '    Return
        'End If

        Dim dtStart As String = hfFrom.Value
        Dim dtEnd As String = hfTo.Value
        DrawChartTop(dtStart, dtEnd, ddlCaster.SelectedItem.Text)



    End Sub

End Class
