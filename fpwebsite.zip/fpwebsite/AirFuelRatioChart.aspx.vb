﻿Imports System.Data
Imports System.IO
Imports OfficeOpenXml


Partial Class AirFuelRatioChart
    Inherits System.Web.UI.Page

    Dim objdatahandler As New DataHandler
    Dim objDataHandlerGcp As New DataHandlerGCP

    Dim SELECT_LINE As String = ""
    Dim Select_Field1 As String = ""
    Dim Select_Field2 As String = ""
    Dim Date_Field As String = ""
    Dim DatabaseName As String = ""

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Try

            Dim ticks As String
            Dim line1 As String
            Dim line2 As String
            Dim ChartTitle As String
            Dim Lit As Literal
            Dim containerName As String
            Dim PlotName As String


            If Not Page.IsPostBack Then


                Dim dtdate As DataTable = objDataHandlerGcp.DataReading("select FORMAT_DATE('%F %T',DATE_TIME) as DATE_TIME FROM `tsl-datalake.PTG_PSA.HSM_REHT_FURNC` Order By DATE_TIME Desc Limit 1")

                Dim ddtdate As DateTime = dtdate.Rows(0)("DATE_TIME")

                Dim frmDate As String = ddtdate.ToString("yyyy-MM-dd HH:mm:ss")

                Dim toDate As String = ddtdate.AddDays(-3).ToString("yyyy-MM-dd HH:mm:ss")
                '=============LINEA AND B

                ''''''=======Need to Be Commented Below LIne=======================


                'Session("checkboxval") = "1"
                'Session("checkLineChartField1") = "Z1_AIR_FUEL_RATIO"
                'Session("checkLineChartField2") = "Z1_EXCESS_AIR"
                'Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
                'Session("DateField") = "DATE_TIME"

                SELECT_LINE = Session("checkboxval")
                Select_Field1 = Session("checkLineChartField1")
                Select_Field2 = Session("checkLineChartField2")
                DatabaseName = Session("DBName")
                Date_Field = Session("DateField")

                PlotName = "plot1"
                containerName = "container1"
                Lit = Lit1

                'Dim ds As DataSet = objdatahandler.GetDataSetFromQuery("SELECT   [DATETIME], " & Select_Parameters & "  FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL] where LINE =  '" & SELECT_LINE & "'  AND  [datetime] between '" & toDate & "' and '" & frmDate & "' and " & Select_Parameters & "  is not null ORDER BY DATETIME ASC")

                Dim dt As DataTable = objDataHandlerGcp.DataReading("SELECT   FORMAT_DATE('%F %T'," & Date_Field & ") As DATE_TIME, " & Select_Field1 & "," & Select_Field2 & "  FROM `" & DatabaseName & "` where FCE_ID =  " & SELECT_LINE & "  AND  " & Date_Field & " between '" & toDate & "' and '" & frmDate & "' and " & Select_Field1 & "  is not null and " & Select_Field2 & " is not null ORDER BY " & Date_Field & " ASC")


                If dt.Rows.Count > 0 Then


                    Dim dtDist As DataTable = dt
                    Dim rs As DataView = dt.DefaultView

                    For i As Integer = 0 To dtDist.Rows.Count - 1

                        'ticks &= " '" & CDate(dtDist.Rows(i)(0)).ToString("yyyy-MM-dd") & "'," 'DATE_TIME
                        ticks &= " '" & CDate(dtDist.Rows(i)("DATE_TIME")).ToString("yyyy-MM-dd HH:mm:ss") & "',"

                        If rs.Count > 0 Then
                            line1 &= " '" & dt.Rows(i)(Select_Field1) & "',"

                        Else
                            line1 &= ","
                        End If

                        If rs.Count > 0 Then
                            line2 &= " '" & dt.Rows(i)(Select_Field2) & "',"

                        Else
                            line2 &= ","
                        End If
                        '''''''''''''For USL Above (+5)'''''''''''''''''''''
                        'If rs.Count > 0 Then
                        '    uslPoint &= "'5',"

                        'Else
                        '    uslPoint &= ","
                        'End If
                        ''''''''''''''For LSL Below (-5)'''''''''''''''''''''
                        'If rs.Count > 0 Then
                        '    lslPoint &= "'-5',"

                        'Else
                        '    lslPoint &= ","
                        'End If

                    Next

                    Dim val As Decimal = 1.9

                    ChartTitle = ""
                    Lit1.Text = ""

                    Dim js = "<script language='javascript' type='text/javascript'>"

                    'js &= "var chartDom = document.getElementById('main');"
                    'js &= "var myChart = echarts.init(chartDom);"
                    js &= "var option;"
                    js &= "const colors = ['#5470C6', '#D86509', '#F4200E'];"
                    js &= "option = {"
                    js &= "color: colors,"
                    js &= "tooltip: {"
                    js &= "trigger: 'axis',"
                    js &= "axisPointer: {"
                    js &= "type: 'cross'"
                    js &= "}"
                    js &= "},"
                    js &= "grid: {"
                    js &= "right: '15%'"
                    js &= "},"
                    js &= "toolbox: {"
                    js &= "feature: {"
                    js &= "dataZoom:{},"
                    js &= "dataView: { show: true, readOnly: false },"
                    js &= "magicType: { show: true, type: ['line', 'bar'] },"
                    js &= "restore: { show: true },"
                    js &= "saveAsImage: { show: true }"
                    js &= "},"
                    js &= "right:'5%',"
                    js &= "},"
                    js &= "legend: {"
                    'js &= "data: ['GasFlow']"
                    js &= "data: ['" & Select_Field1 & "','" & Select_Field2 & "']"
                    js &= "},"
                    js &= "xAxis: ["
                    js &= "{"
                    js &= "type: 'category',"
                    js &= "axisTick: {"
                    js &= "alignWithLabel: true"
                    js &= "},"
                    'js &= "// prettier-ignore "
                    'js &= "data: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']"
                    js &= "data: [" & ticks & "]"
                    js &= "}"
                    js &= "],"
                    js &= "yAxis:["
                    js &= "{"
                    js &= "type: 'value',"
                    'js &= "name: 'Evaporation',"
                    'js &= "name: '" & Select_Field1 & "',"

                    'js &= "name:'%Totalizer/Sum(Section Flow Gas)',"
                    js &= "name:'AIR FUEL RATIO',"
                    js &= "nameRotate:'90',"
                    js &= "nameLocation:'center',"
                    js &= "nameTextStyle: {"
                    js &= "fontSize:9,"
                    js &= "fontStyle:'italic',"
                    js &= "fontWeight:'bold',"
                    js &= "},"
                    js &= "nameGap:'35',"
                    'js &= "name: '" & Select_Field1 & "',"
                    js &= "position: 'left',"
                    js &= "alignTicks: true,"
                    js &= "axisLine: {"
                    js &= "show: true,"
                    js &= "lineStyle: {"
                    js &= "color: colors[0]"
                    js &= "}"
                    js &= "},"
                    js &= "axisLabel: {"
                    js &= "formatter: '{value}'"
                    js &= "}"
                    js &= "},"
                    js &= "{"
                    js &= "type: 'value',"
                    'js &= "name: 'Precipitation',"
                    'js &= "name: '" & Select_Field2 & "',"
                    js &= "position: 'right',"
                    js &= "alignTicks: true,"
                    'js &= "show: false,"
                    js &= "show: true,"
                    'js &= "offset: 80,"
                    js &= "offset: 20,"
                    js &= "axisLine: {"
                    js &= "show: true,"
                    js &= "lineStyle: {"
                    js &= "color: colors[1]"
                    js &= "}"
                    js &= "},"
                    js &= "axisLabel: {"
                    js &= "formatter: '{value} ml'"
                    js &= "}"
                    js &= "},"
                    js &= "{"
                    js &= "type: 'value',"
                    js &= "name: '温度',"
                    js &= "position: 'left',"
                    js &= "alignTicks: true,"
                    js &= "show: false,"
                    js &= "axisLine: {"
                    js &= "show: true,"
                    js &= "lineStyle: {"
                    js &= "color: colors[2]"
                    js &= "}"
                    js &= "}"
                    'js &= "//axisLabel: {"
                    'js &= "//  formatter: '{value} °C'"
                    'js &= "//  }"
                    js &= "}"
                    js &= "],"
                    js &= "series: ["
                    js &= "{"
                    'js &= "name: 'GasFlow',"
                    js &= "name: '" & Select_Field1 & "',"
                    js &= "type: 'line',"
                    js &= "data: ["
                    js &= "" & line1 & ""
                    js &= "]"
                    js &= "},"
                    js &= "{"
                    'js &= "name: 'USL',"
                    js &= "name: '" & Select_Field2 & "',"
                    js &= "type: 'line',"
                    js &= "symbol: 'none',"
                    js &= "yAxisIndex: 1,"
                    'js &= "yAxisIndex: 0,"
                    'js &= "data: [" & uslPoint & "]"
                    js &= "data: [" & line2 & "]"
                    js &= "},"
                    'js &= "{"
                    'js &= "name: 'LSL',"
                    'js &= "type: 'line',"
                    'js &= "symbol: 'none',"
                    ''js &= "yAxisIndex: 2,"
                    'js &= "yAxisIndex: 0,"
                    'js &= "data: [" & lslPoint & "]"
                    'js &= "}"
                    js &= "]"
                    js &= "};"
                    'js &= "option && myChart.setOption(option);"

                    js &= "var " & PlotName & " = echarts.init(document.getElementById('" & containerName & "'));" & PlotName & ".setOption(option);"
                    js &= "</script>"
                    Lit.Text = js

                Else
                    Lit.Text = "<script>$('#container1').html('<p>No Data</p>')</script>"
                End If

            End If

        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

    End Sub

    Protected Sub txtDate_TextChanged(sender As Object, e As System.EventArgs) Handles txtDate.TextChanged
        Try
            ''Session("checkboxval") = "1"
            ''Session("checkLineChartField1") = "Z1_AIR_FUEL_RATIO"
            ''Session("checkLineChartField2") = "Z1_EXCESS_AIR"
            ''Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
            ''Session("DateField") = "DATE_TIME"

            Dim ticks As String
            Dim line1 As String
            Dim line2 As String
            'Dim dt As DataTable
            Dim Lit As Literal
            Dim containerName As String
            Dim PlotName As String
            Dim ChartTitle As String


            Dim fromDt As DateTime = hfFrom.Value
            Dim toDt As DateTime = hfTo.Value

            Dim StDate As String = fromDt.ToString("yyyy-MM-dd HH:mm:ss")
            Dim EndDate As String = toDt.ToString("yyyy-MM-dd HH:mm:ss")


            Dim DateDifference As String = DateDiff(DateInterval.Day, fromDt, toDt).ToString()
            If DateDifference > 3 Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "Pop", "$('#loginModal').modal('show');", True)
            Else
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "Pop", "$('#loginModal').modal('hide');", True)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "Pop", "$('#noDataModal').modal('hide');", True)

                SELECT_LINE = Session("checkboxval")
                Select_Field1 = Session("checkLineChartField1")
                Select_Field2 = Session("checkLineChartField2")
                Date_Field = Session("DateField")
                DatabaseName = Session("DBName")

                PlotName = "plot1"
                containerName = "container1"
                Lit = Lit1

                Dim query As String
                query = "SELECT   FORMAT_DATE('%F %T'," & Date_Field & ") As DATE_TIME, " & Select_Field1 & "," & Select_Field2 & "  FROM `" & DatabaseName & "` where FCE_ID =  " & SELECT_LINE & "  AND  " & Date_Field & " between '" & StDate & "' and '" & EndDate & "' and " & Select_Field1 & "  is not null and " & Select_Field2 & " is not null ORDER BY " & Date_Field & " ASC"

                Dim dt As DataTable = objDataHandlerGcp.DataReading(query)

                If dt.Rows.Count > 0 Then


                    Dim dtDist As DataTable = dt
                    Dim rs As DataView = dt.DefaultView

                    For i As Integer = 0 To dtDist.Rows.Count - 1

                        'ticks &= " '" & CDate(dtDist.Rows(i)(0)).ToString("yyyy-MM-dd") & "'," 'DATE_TIME
                        ticks &= " '" & CDate(dtDist.Rows(i)("DATE_TIME")).ToString("yyyy-MM-dd") & "',"

                        If rs.Count > 0 Then
                            line1 &= " '" & dtDist.Rows(i)(Select_Field1) & "',"

                        Else
                            line1 &= ","
                        End If

                        If rs.Count > 0 Then
                            line2 &= " '" & dtDist.Rows(i)(Select_Field2) & "',"

                        Else
                            line2 &= ","
                        End If


                    Next

                    Dim val As Decimal = 1.9

                    ChartTitle = ""

                End If

                Lit1.Text = ""

                If dt.Rows.Count > 0 Then

                    Dim js = "<script language='javascript' type='text/javascript'>"

                    'js &= "var chartDom = document.getElementById('main');"
                    'js &= "var myChart = echarts.init(chartDom);"
                    js &= "var option;"
                    ''#2F5BB4', '#E59250', '#F4200E'
                    ''#5470C6', '#F4200E', '#F4200E'
                    js &= "const colors = ['#5470C6', '#D86509', '#F4200E'];"
                    js &= "option = {"
                    js &= "color: colors,"
                    js &= "tooltip: {"
                    js &= "trigger: 'axis',"
                    js &= "axisPointer: {"
                    js &= "type: 'cross'"
                    js &= "}"
                    js &= "},"
                    js &= "grid: {"
                    js &= "right: '15%'"
                    js &= "},"
                    js &= "toolbox: {"
                    js &= "feature: {"
                    js &= "dataView: { show: true, readOnly: false },"
                    js &= "magicType: { show: true, type: ['line', 'bar'] },"
                    js &= "restore: { show: true },"
                    js &= "saveAsImage: { show: true }"
                    js &= "},"
                    js &= "right:'5%',"
                    js &= "},"
                    js &= "legend: {"
                    'js &= "data: ['GasFlow']"
                    js &= "data: ['" & Select_Field1 & "','" & Select_Field2 & "']"
                    js &= "},"
                    js &= "xAxis: ["
                    js &= "{"
                    js &= "type: 'category',"
                    js &= "axisTick: {"
                    js &= "alignWithLabel: true"
                    js &= "},"
                    'js &= "// prettier-ignore "
                    'js &= "data: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']"
                    js &= "data: [" & ticks & "]"
                    js &= "}"
                    js &= "],"
                    js &= "yAxis:["
                    js &= "{"
                    js &= "type: 'value',"
                    'js &= "name: 'Evaporation',"
                    'js &= "name: '" & Select_Field1 & "',"

                    'js &= "name:'%Totalizer/Sum(Section Flow Gas)',"
                    js &= "name:'AIR FUEL RATIO',"
                    js &= "nameRotate:'90',"
                    js &= "nameLocation:'center',"
                    js &= "nameTextStyle: {"
                    js &= "fontSize:9,"
                    js &= "fontStyle:'italic',"
                    js &= "fontWeight:'bold',"
                    js &= "},"
                    js &= "nameGap:'35',"
                    'js &= "name: '" & Select_Field1 & "',"
                    js &= "position: 'left',"
                    js &= "alignTicks: true,"
                    js &= "axisLine: {"
                    js &= "show: true,"
                    js &= "lineStyle: {"
                    js &= "color: colors[0]"
                    js &= "}"
                    js &= "},"
                    js &= "axisLabel: {"
                    js &= "formatter: '{value}'"
                    js &= "}"
                    js &= "},"
                    js &= "{"
                    js &= "type: 'value',"
                    'js &= "name: 'Precipitation',"
                    'js &= "name: '" & Select_Field2 & "',"
                    js &= "position: 'right',"
                    js &= "alignTicks: true,"
                    'js &= "show: false,"
                    js &= "show: true,"
                    'js &= "offset: 80,"
                    js &= "offset: 20,"
                    js &= "axisLine: {"
                    js &= "show: true,"
                    js &= "lineStyle: {"
                    js &= "color: colors[1]"
                    js &= "}"
                    js &= "},"
                    js &= "axisLabel: {"
                    js &= "formatter: '{value} ml'"
                    js &= "}"
                    js &= "},"
                    js &= "{"
                    js &= "type: 'value',"
                    js &= "name: '温度',"
                    js &= "position: 'left',"
                    js &= "alignTicks: true,"
                    js &= "show: false,"
                    js &= "axisLine: {"
                    js &= "show: true,"
                    js &= "lineStyle: {"
                    js &= "color: colors[2]"
                    js &= "}"
                    js &= "}"
                    'js &= "//axisLabel: {"
                    'js &= "//  formatter: '{value} °C'"
                    'js &= "//  }"
                    js &= "}"
                    js &= "],"
                    js &= "series: ["
                    js &= "{"
                    'js &= "name: 'GasFlow',"
                    js &= "name: '" & Select_Field1 & "',"
                    js &= "type: 'line',"
                    js &= "data: ["
                    js &= "" & line1 & ""
                    js &= "]"
                    js &= "},"
                    js &= "{"
                    'js &= "name: 'USL',"
                    js &= "name: '" & Select_Field2 & "',"
                    js &= "type: 'line',"
                    js &= "symbol: 'none',"
                    js &= "yAxisIndex: 1,"
                    'js &= "yAxisIndex: 0,"
                    'js &= "data: [" & uslPoint & "]"
                    js &= "data: [" & line2 & "]"
                    js &= "},"
                    'js &= "{"
                    'js &= "name: 'LSL',"
                    'js &= "type: 'line',"
                    'js &= "symbol: 'none',"
                    ''js &= "yAxisIndex: 2,"
                    'js &= "yAxisIndex: 0,"
                    'js &= "data: [" & lslPoint & "]"
                    'js &= "}"
                    js &= "]"
                    js &= "};"
                    'js &= "option && myChart.setOption(option);"



                    js &= "var " & PlotName & " = echarts.init(document.getElementById('" & containerName & "'));" & PlotName & ".setOption(option);"
                    js &= "</script>"
                    Lit.Text = js
                Else
                    Lit.Text = "<script>$('#container11').html('<p>No Data</p>')</script>"
                End If
            End If






        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub

    'Private Sub lnkDownload_Click(sender As Object, e As EventArgs) Handles lnkDownload.Click
    '    Try
    '        Dim fromDt As String = hfFrom.Value
    '        Dim toDt As String = hfTo.Value

    '        SELECT_LINE = Session("checkboxval")
    '        Select_Parameters = Session("checkLineChartParameters")
    '        Date_Field = Session("DateField")
    '        DatabaseName = Session("DBName")

    '        'Dim ds As DataSet = objdatahandler.GetDataSetFromQuery("SELECT   FORMAT([DATETIME],'dd-MM-yyyy HH:mm:ss')  As [DATETIME], " & Select_Parameters & "  FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL] where LINE =  '" & SELECT_LINE & "'  AND  [datetime] between '" & fromDt & "' and '" & toDt & "' and " & Select_Parameters & "  is not null ORDER BY DATETIME ASC")
    '        'Dim dt1 As DataTable = ds.Tables(0)

    '        'Dim dt1 As DataTable = objDataHandlerGcp.DataReading("SELECT   FORMAT_DATE('%F %T',DATE_TIME) As DATE_TIME, " & Select_Parameters & "  FROM `" & DatabaseName & "` where FCE_ID =  " & SELECT_LINE & "  AND  DATE_TIME between '2023-05-01 11:59:23' and '2023-07-07 11:59:23' and " & Select_Parameters & "  is not null ORDER BY DATE_TIME ASC")
    '        Dim dt1 As DataTable = objDataHandlerGcp.DataReading("SELECT   FORMAT_DATE('%F %T'," & Date_Field & ") As DATE_TIME, " & Select_Parameters & "  FROM `" & DatabaseName & "` where FCE_ID =  " & SELECT_LINE & "  AND  " & Date_Field & " between '" & fromDt & "' and '" & toDt & "' and " & Select_Parameters & "  is not null ORDER BY " & Date_Field & " ASC")

    '        Dim i As Integer = 1
    '        Using ep As New ExcelPackage()
    '            'For Each dt As DataTable In ds.Tables
    '            'Dim ws As ExcelWorksheet = ep.Workbook.Worksheets.Add("s" & i)
    '            Dim ws As ExcelWorksheet = ep.Workbook.Worksheets.Add("Download")
    '            ws.Cells("A1").LoadFromDataTable(dt1, True)

    '            'i += 1
    '            'Next
    '            Using ms As New MemoryStream
    '                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    '                Response.AddHeader("content-disposition", "attachment; filename=download.xlsx")
    '                ep.SaveAs(ms)
    '                ms.WriteTo(Response.OutputStream)
    '                Response.Flush()
    '                Response.End()
    '            End Using
    '        End Using



    '    Catch ex As Exception
    '        Throw New Exception(ex.ToString())
    '    End Try
    'End Sub

    'Private Sub lnkDownloadNew_Click(sender As Object, e As EventArgs) Handles lnkDownloadNew.Click
    '    Try
    '        Dim fromDt As String = hfFrom.Value
    '        Dim toDt As String = hfTo.Value

    '        SELECT_LINE = Session("checkboxval")
    '        Select_Parameters = Session("checkLineChartParameters")
    '        Date_Field = Session("DateField")
    '        DatabaseName = Session("DBName")

    '        'Dim ds As DataSet = objdatahandler.GetDataSetFromQuery("SELECT   FORMAT([DATETIME],'dd-MM-yyyy HH:mm:ss')  As [DATETIME], " & Select_Parameters & "  FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL] where LINE =  '" & SELECT_LINE & "'  AND  [datetime] between '" & fromDt & "' and '" & toDt & "' and " & Select_Parameters & "  is not null ORDER BY DATETIME ASC")
    '        'Dim dt1 As DataTable = ds.Tables(0)

    '        'Dim dt1 As DataTable = objDataHandlerGcp.DataReading("SELECT   FORMAT_DATE('%F %T',DATE_TIME) As DATE_TIME, " & Select_Parameters & "  FROM `" & DatabaseName & "` where FCE_ID =  " & SELECT_LINE & "  AND  DATE_TIME between '2023-05-01 11:59:23' and '2023-07-07 11:59:23' and " & Select_Parameters & "  is not null ORDER BY DATE_TIME ASC")
    '        Dim dt1 As DataTable = objDataHandlerGcp.DataReading("SELECT   FORMAT_DATE('%F %T'," & Date_Field & ") As DATE_TIME, " & Select_Parameters & "  FROM `" & DatabaseName & "` where FCE_ID =  " & SELECT_LINE & "  AND  " & Date_Field & " between '" & fromDt & "' and '" & toDt & "' and " & Select_Parameters & "  is not null ORDER BY " & Date_Field & " ASC")
    '        If dt1.Rows.Count > 0 Then
    '            Dim attachment As String = "attachment; filename=city.xls"
    '            Response.ClearContent()
    '            Response.AddHeader("content-disposition", attachment)
    '            Response.ContentType = "application/vnd.ms-excel"
    '            Dim tab As String = ""
    '            For Each dc As DataColumn In dt1.Columns
    '                Response.Write(tab & dc.ColumnName)
    '                tab = "\t"
    '            Next

    '            Response.Write("\n")
    '            Dim i As Integer
    '            For Each dr As DataRow In dt1.Rows
    '                tab = ""
    '                For i = 0 To dt1.Columns.Count - 1
    '                    Response.Write(tab & dr(i).ToString())
    '                    tab = "\t"
    '                Next
    '                Response.Write("\n")
    '            Next
    '            Response.End()
    '        Else
    '            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "showalert", "alert('Data Not Available between the Choosen Dates. Please Select a Different Date Range.');", True)
    '        End If

    '    Catch ex As Exception
    '        Throw New Exception(ex.ToString())
    '    End Try
    'End Sub
End Class
