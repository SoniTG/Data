﻿Imports System.Data
Imports System.IO
Imports System.Data.OleDb
Imports Oracle.ManagedDataAccess.Client

Partial Class Al_Fe_Model

    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim objEffectiveAlFeCalculation As New EffectiveAlFeCalculation
    Dim objAl_FeModel As New ACPM_MODEL
    Dim arrAlNew() As Double
    Dim arrPotLvlNew() As Double
    Dim pred_dura_blck_1(,) As Double
    Dim Ramp_start_Time As DateTime '' ZS-->GA
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    '........oracle connection....
    'Dim Oleconnection_ora As OracleConnection = New OracleConnection("Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=133.0.1.2)(PORT=1521))(CONNECT_DATA=(SID=crm2)));User ID=crmisptg;Password=abc#123;Unicode=True")
    Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("ACPM_Ora_New").ConnectionString
    Dim Oleconnection_ora As New OracleConnection(strConnectionString)
    Dim OleAdap As New OracleDataAdapter
    Dim schdeule_set As New DataSet
    Dim schdeule_table As New DataTable
    Dim OleCom As New OracleCommand
    Dim dtStart As String
    Dim dtEnd As String
    Dim dt_get_time As DataTable
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load


        If dgv_ingot_predict.Rows.Count > 0 Then
            dgv_ingot_predict.UseAccessibleHeader = True
            dgv_ingot_predict.HeaderRow.TableSection = TableRowSection.TableHeader
        End If
        If gdvDetails.Rows.Count > 0 Then
            gdvDetails.UseAccessibleHeader = True
            gdvDetails.HeaderRow.TableSection = TableRowSection.TableHeader
        End If

        Dim p As String = Request("__EVENTARGUMENT")
        If p = "ramp" Then

            dtStart = hfFrom.Value
            dtEnd = hfTo.Value
            dt_get_time = objController.GetStartTime(dtStart, dtEnd)
            'Dim startTime As String = dt(dt.Rows.Count - 1)("CZT_TIMESTAMP")
            txtlevelton.Text = 200
            txtAl.Text = dt_get_time(dt_get_time.Rows.Count - 1)("CZT_POT_AL")
            txtFe.Text = dt_get_time(dt_get_time.Rows.Count - 1)("CZT_POT_FE")
            dtStart = CDate(dt_get_time(dt_get_time.Rows.Count - 1)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm")
            objController.PopulateAcpmData(dtStart, dtEnd, gdvDetails, "Al-Fe Model")
            get_scheduled_coil_data()
            Calculation(dtStart, dtEnd)

        End If

        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))

                dtStart = DateTime.Now.AddDays(-4).ToString("yyyy-MM-dd HH:mm")

                    'Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                    dtEnd = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
               

                

                ' Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd")
                ' Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd")
                dt_get_time = objController.GetStartTime(dtStart, dtEnd)
                'Dim startTime As String = dt(dt.Rows.Count - 1)("CZT_TIMESTAMP")
                txtlevelton.Text = 200
                txtAl.Text = dt_get_time(dt_get_time.Rows.Count - 1)("CZT_POT_AL")
                txtFe.Text = dt_get_time(dt_get_time.Rows.Count - 1)("CZT_POT_FE")
                dtStart = CDate(dt_get_time(dt_get_time.Rows.Count - 1)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm")
                objController.PopulateAcpmData(dtStart, dtEnd, gdvDetails, "Al-Fe Model")
                get_scheduled_coil_data()
                Calculation(dtStart, dtEnd)


            Catch ex As Exception

            End Try
        End If
    End Sub

    Protected Sub txtDate_TextChanged(sender As Object, e As System.EventArgs) Handles txtDate.TextChanged
        Try

            dtStart = hfFrom.Value
            dtEnd = hfTo.Value
            dt_get_time = objController.GetStartTime(dtStart, dtEnd)
            txtAl.Text = dt_get_time(dt_get_time.Rows.Count - 1)("CZT_POT_AL")
            txtFe.Text = dt_get_time(dt_get_time.Rows.Count - 1)("CZT_POT_FE")
            dtStart = CDate(dt_get_time(dt_get_time.Rows.Count - 1)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm")

            Dim fromDt As String = dtStart
            Dim toDt As String = dtEnd
            objController.PopulateAcpmData(fromDt, toDt, gdvDetails, "Al-Fe Model")
            ' btnRun_Click(sender, e)
            Calculation(fromDt, toDt)

        Catch ex As Exception

        End Try
    End Sub


    Sub Calculation(ByVal stDate As String, ByVal enDate As String)
        Try

            'dtStart = hfFrom.Value
            'dtEnd = hfTo.Value
            'dt_get_time = objController.GetStartTime(dtStart, dtEnd)
            'dtStart = CDate(dt_get_time(dt_get_time.Rows.Count - 1)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm")

            'Dim fromDt As String = dtStart
            'Dim toDt As String = dtEnd

            Dim dt As DataTable = objController.GetDataForAcpmThermalGalvBath(stDate, enDate)

            ReDim Preserve arrAlNew(dt.Rows.Count - 1)

            Array.Clear(arrAlNew, 0, dt.Rows.Count - 1)
            Dim firstDatetime As String = CDate(dt.Rows(dt.Rows.Count - 1)("starttime")).ToString("yyyy-MM-dd HH:mm:ss")
            Dim dt1 As DataTable = objController.GetSurfRough(firstDatetime)
            If dt.Rows(dt.Rows.Count - 1)("PRM_CD_SURF_ROUGH") = "A" And dt1(0)("PRM_CD_SURF_ROUGH") = "Z" Then
                Ramp_start_Time = dt.Rows(dt.Rows.Count - 1)("starttime")
            End If
            Dim potlvl, al_old, Fe_old As Decimal
            potlvl = txtlevelton.Text
            al_old = txtAl.Text
            Fe_old = txtFe.Text
            'For r = dt.Rows.Count - 1 To 0 Step -1
            objAl_FeModel.main(dt, gdvDetails, dgv_ingot_predict, potlvl, arrAlNew, al_old, Fe_old, hfRadio.Value)
            ' Next
            DrawChart(stDate, enDate)

        Catch ex As Exception

        End Try
    End Sub


    'Protected Sub btnRun_Click(sender As Object, e As System.EventArgs) Handles btnRun.Click
    '    dtStart = hfFrom.Value
    '    dtEnd = hfTo.Value
    '    dt_get_time = objController.GetStartTime(dtStart, dtEnd)
    '    dtStart = CDate(dt_get_time(dt_get_time.Rows.Count - 1)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm")

    '    Dim fromDt As String = dtStart
    '    Dim toDt As String = dtEnd

    '    Dim dt As DataTable = objController.GetDataForAcpmThermalGalvBath(fromDt, toDt)

    '    ReDim Preserve arrAlNew(dt.Rows.Count - 1)

    '    Array.Clear(arrAlNew, 0, dt.Rows.Count - 1)
    '    Dim firstDatetime As String = CDate(dt.Rows(dt.Rows.Count - 1)("starttime")).ToString("yyyy-MM-dd HH:mm:ss")
    '    Dim dt1 As DataTable = objController.GetSurfRough(firstDatetime)
    '    If dt.Rows(dt.Rows.Count - 1)("PRM_CD_SURF_ROUGH") = "A" And dt1(0)("PRM_CD_SURF_ROUGH") = "Z" Then
    '        Ramp_start_Time = dt.Rows(dt.Rows.Count - 1)("starttime")
    '    End If
    '    Dim potlvl, al_old As Decimal
    '    potlvl = txtlevelton.Text
    '    al_old = txtAl.Text
    '    'For r = dt.Rows.Count - 1 To 0 Step -1
    '    objAl_FeModel.main(dt, gdvDetails, dgv_ingot_predict, potlvl, arrAlNew, al_old)
    '    ' Next
    '    DrawChart()
    'End Sub

    'Protected Sub gdvDetails_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gdvDetails.RowCommand
    '    Dim index = Convert.ToInt32(e.CommandArgument)
    '    If e.CommandName = "lnkEdit" Then


    '        CType(gdvDetails.Rows(index).FindControl("txtSHG"), TextBox).ReadOnly = False
    '        CType(gdvDetails.Rows(index).FindControl("txtCGG"), TextBox).ReadOnly = False
    '        CType(gdvDetails.Rows(index).FindControl("txtFivePer"), TextBox).ReadOnly = False
    '        CType(gdvDetails.Rows(index).FindControl("txtSHG"), TextBox).Enabled = True
    '        CType(gdvDetails.Rows(index).FindControl("txtCGG"), TextBox).Enabled = True
    '        CType(gdvDetails.Rows(index).FindControl("txtFivePer"), TextBox).Enabled = True


    '    End If

    'End Sub



    'Protected Sub gdvDetails_RowEditing(sender As Object, e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles gdvDetails.RowEditing
    '    gdvDetails.EditIndex = e.NewEditIndex
    'End Sub

    Sub DrawChart(ByVal stDate As String, ByVal enDate As String)
        Try

            chartdiv.Visible = True
            chartdiv1.Visible = True
            'dtStart = hfFrom.Value
            'dtEnd = hfTo.Value
            'dt_get_time = objController.GetStartTime(dtStart, dtEnd)
            'dtStart = CDate(dt_get_time(dt_get_time.Rows.Count - 1)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm")

            Dim fromDt As String = stDate
            Dim toDt As String = enDate
            Dim dt As DataTable = objController.GetZnBathTrendForAcpm(fromDt, toDt)
            '####################[08112019]
            Dim dtIngot As DataTable = objController.GetIngotForAlFe(fromDt, toDt)
            Dim int2 As Integer = dtIngot.Rows.Count - 1
            Dim SHGCGGAlPer_NewSeries(,) As String = New String(int2, 3) {}
            For i As Integer = 0 To dtIngot.Rows.Count - 1

                SHGCGGAlPer_NewSeries(i, 0) = CDate(dtIngot.Rows(i)("cia_timestamp")).ToString("yyyy-MM-dd HH:mm:ss")
                SHGCGGAlPer_NewSeries(i, 1) = dtIngot.Rows(i)("cia_shg_wt")
                SHGCGGAlPer_NewSeries(i, 2) = dtIngot.Rows(i)("cia_cgg_wt")
                SHGCGGAlPer_NewSeries(i, 3) = dtIngot.Rows(i)("cia_5alper_wt")
            Next
            '#####################
            Dim int As Integer = gdvDetails.Rows.Count - 1
            Dim int1 As Integer = dgv_ingot_predict.Rows.Count - 1
            Dim tAct() As String = New String(int) {}
            Dim SHG_frGridFirst() As String = New String(int) {}
            Dim CGG_frGridFirst() As String = New String(int) {}
            Dim AlPer_frGridFirst() As String = New String(int) {}

            Dim tCalc() As String = New String(int) {}
            Dim time() As String = New String(int) {}
            Dim AlEffectiveCalc() As String = New String(int) {}
            Dim AlEffectiveAct() As String = New String(dt.Rows.Count - 1) {}

            Dim timealEffective() As String = New String(dt.Rows.Count - 1) {}
            Dim AlTotal() As String = New String(dt.Rows.Count - 1) {}
            Dim FeTotal() As String = New String(dt.Rows.Count - 1) {}
            Dim time1() As String = New String(int1) {}
            Dim SHG() As String = New String(int1) {}
            Dim CGG() As String = New String(int1) {}
            Dim AlPer() As String = New String(int1) {}
            Dim Al_Pred() As String = New String(int1) {}
            Dim Al_Tot_Pred() As String = New String(int1) {}
            Dim startdatetime As DateTime = DateTime.Parse(gdvDetails.Rows(0).Cells(14).Text.ToString)
            Dim interval() As String = New String(int1) {}
            Dim pred_dur As Double = 0
            Dim pred_dur_1 As Double = 0


            pred_dura_blck_1 = objAl_FeModel.pred_dura_blck_1
            Dim bound0 As Integer = pred_dura_blck_1.GetUpperBound(0)
            'Dim bound1 As Integer = pred_dura_blck_1.GetUpperBound(1)
            Dim Arr1(bound0) As Double
            Dim Arr2(bound0) As Double
            Dim Arr3(bound0) As Double
            Dim Arr4(bound0) As Double
            Dim ArrTime(bound0) As String

            'arrtime(x)-->the array is made of 30 sec interval. but the values in the array are stored at minute interval. 
            'the ingots can be added one(ton) by one(ton). in case there is a requirement of 2 ton addition, 
            'first one ton addition is done, then calculated for next ton done in next 30 sec.
            For x As Integer = 0 To bound0
                ' Get element.
                If (pred_dura_blck_1(x, 1) + pred_dura_blck_1(x, 2) + pred_dura_blck_1(x, 3)) > 0 Then
                    ' Arr1(x) = pred_dura_blck_1(x, 0)             '0 - duration
                    Arr2(x) = pred_dura_blck_1(x, 1)              '1 - SHG    
                    Arr3(x) = pred_dura_blck_1(x, 2)              '2 - Cgg 
                    Arr4(x) = pred_dura_blck_1(x, 3)              ' 3- 5AL  
                    ArrTime(x) = startdatetime.AddMinutes(x)
                    
                End If


            Next



            For i As Integer = gdvDetails.Rows.Count - 1 To 0 Step -1

                'tAct(i) = gdvDetails.Rows(i).Cells(16).Text.ToString

                tCalc(i) = gdvDetails.Rows(i).Cells(17).Text.ToString

                time(i) = gdvDetails.Rows(i).Cells(14).Text.ToString
                AlEffectiveCalc(i) = gdvDetails.Rows(i).Cells(25).Text.ToString
                SHG_frGridFirst(i) = gdvDetails.Rows(i).Cells(10).Text.ToString

                CGG_frGridFirst(i) = gdvDetails.Rows(i).Cells(12).Text.ToString

                AlPer_frGridFirst(i) = gdvDetails.Rows(i).Cells(11).Text.ToString




            Next


            '......for AlEffective chart data comes from database
            If dt.Rows.Count > 0 Then

                For i As Integer = 0 To dt.Rows.Count - 1
                    AlEffectiveAct(i) = dt.Rows(i)("CZT_EFF_AL")
                    ' AlEffectiveCalc(i) = gdvDetails.Rows(i).Cells(27).Text.ToString 'dt.Rows(i)("CZT_EFF_AL")
                    timealEffective(i) = dt.Rows(i)("CZT_TIMESTAMP")
                    AlTotal(i) = dt.Rows(i)("CZT_POT_AL")
                    FeTotal(i) = dt.Rows(i)("CZT_POT_FE")
                    Dim dt1 As DataTable = objController.GetZnBathTrendForAcpm_ALEFF(Format(Convert.ToDateTime(timealEffective(i)), "yyyy-MM-dd HH:mm:ss"))
                    Dim temp As Double = dt1.Rows(0)("PRM_ZINC_POT_TMP").ToString
                    objEffectiveAlFeCalculation.Main(temp, temp + 273.15)
                    objEffectiveAlFeCalculation.Aleffcal(Convert.ToDouble(AlTotal(i)), Convert.ToDouble(FeTotal(i)))
                    AlEffectiveAct(i) = objEffectiveAlFeCalculation.Al_liq

                Next
            End If
            '......for combine chart(chart3)......

            For i As Integer = 0 To dgv_ingot_predict.Rows.Count - 1

                ' SHG(i) = dgv_ingot_predict.Rows(i).Cells(13).Text.ToString

                ' AlPer(i) = dgv_ingot_predict.Rows(i).Cells(14).Text.ToString
                ' CGG(i) = dgv_ingot_predict.Rows(i).Cells(15).Text.ToString
                interval(i) = dgv_ingot_predict.Rows(i).Cells(5).Text / dgv_ingot_predict.Rows(i).Cells(17).Text
                pred_dur = pred_dur + interval(i)
                time1(i) = startdatetime.AddMinutes(pred_dur)
                Al_Pred(i) = dgv_ingot_predict.Rows(i).Cells(11).Text.ToString
                Al_Tot_Pred(i) = dgv_ingot_predict.Rows(i).Cells(18).Text.ToString



            Next


            objController.PlotLineChartForThermaAcpm(time, timealEffective, time1, AlTotal, tCalc, Al_Tot_Pred, Lit1, "container1", "plot1", "Al-Fe")
            'objController.PlotLineChartForThermaAcpm1(time, timealEffective, AlEffectiveAct, AlEffectiveCalc, Lit2, "container2", "plot2", "Al-Fe")
            'objController.PlotLineChartForThermaAcpm2(time, timealEffective, time1, AlEffectiveAct, AlEffectiveCalc, SHG, CGG, AlPer, Al_Pred, SHG_frGridFirst, CGG_frGridFirst, AlPer_frGridFirst, Lit3, "container3", "plot3", "Al-Fe")
            objController.PlotLineChartForThermaAcpm2(time, timealEffective, time1, ArrTime, AlEffectiveAct, AlEffectiveCalc, Arr2, Arr3, Arr4, Al_Pred, SHG_frGridFirst, CGG_frGridFirst, AlPer_frGridFirst, Lit3, "container3", "plot3", "Al-Fe", SHGCGGAlPer_NewSeries)


        Catch ex As Exception

        End Try
    End Sub

    ''''''''''''''''''''''Fetch data from oracle database as on 2-jan-2019.....
    'Public Sub get_scheduled_coil_data()
    '    Try

    '        CloseConnection()
    '        schdeule_set.Clear()
    '        schdeule_table.Clear()
    '        Dim OraQuery As String = "select * from (select pdl_id_coil,pdl_cd_status,pdl_no_seq,pdl_sec1_coil ,trunc(pdl_sec2_coil,0)as pdl_sec2_coil ,pdl_ln_coil,pdl_grd_steel,pdl_cd_prod,pdl_cd_coat,pdl_id_schedule,PDL_PROC_SPEED,PDL_TP_COAT_AMT,PDL_BT_COAT_AMT  from v_pr_data_ip_cg2 " &
    '        "where(pdl_cd_status = 'UP' or pdl_cd_status = 'WW' or  pdl_cd_status = 'WC' or  pdl_cd_status = 'WS') and pdl_ts_creation > to_char(to_date(sysdate-2,'DD-MM-YYYY HH24:MI:SS')) order by pdl_id_pdi  asc) T1 where rownum<=20 order by rownum"

    '        Ora_selectquery(OraQuery)
    '        OleAdap.Fill(schdeule_set)
    '        schdeule_table = schdeule_set.Tables(0)
    '        If schdeule_table.Rows.Count > 0 Then
    '            dgv_ingot_predict.DataSource = schdeule_table
    '            dgv_ingot_predict.DataBind()

    '        End If
    '        If dgv_ingot_predict.Rows.Count > 0 Then
    '            dgv_ingot_predict.UseAccessibleHeader = True
    '            dgv_ingot_predict.HeaderRow.TableSection = TableRowSection.TableHeader
    '        End If


    '    Catch ex As Exception

    '    End Try

    'End Sub

    Public Sub get_scheduled_coil_data()
        Try

            'Logic to remove the wrong coil from the schedule 
            'check the processed coil and to be processed coils list..
            'If there is any coil (odd man out type) remove it from the list

            Dim startdatetime As DateTime
            Dim coil_str(3), status, grade As String
            grade = coil_str(0)
            If gdvDetails.Rows.Count > 3 Then
                startdatetime = DateTime.Parse(gdvDetails.Rows(0).Cells(14).Text.ToString)
                coil_str(1) = gdvDetails.Rows(0).Cells(13).Text.ToString
                coil_str(2) = gdvDetails.Rows(1).Cells(13).Text.ToString
                coil_str(3) = gdvDetails.Rows(2).Cells(13).Text.ToString

                If coil_str(1) = coil_str(2) And coil_str(1) = coil_str(3) Then
                    status = "OK"
                    grade = coil_str(1)
                Else
                    grade = ""
                End If

            End If


            CloseConnection()
            schdeule_set.Clear()
            schdeule_table.Clear()
            Dim OraQuery As String
            'If grade = "" Then
                OraQuery = "select * from (select pdl_id_coil,pdl_cd_status,pdl_no_seq,pdl_sec1_coil ,trunc(pdl_sec2_coil,0)as pdl_sec2_coil ,pdl_ln_coil,pdl_grd_steel,pdl_cd_prod,pdl_cd_coat,pdl_id_schedule,PDL_PROC_SPEED,PDL_TP_COAT_AMT,PDL_BT_COAT_AMT  from v_pr_data_ip_cg2 " &
            "where(pdl_cd_status = 'UP' or pdl_cd_status = 'WW' or  pdl_cd_status = 'WC' or  pdl_cd_status = 'WS') and pdl_ts_creation > to_char(to_date(sysdate-2,'DD-MM-YYYY HH24:MI:SS')) order by pdl_id_pdi  asc) T1 where rownum<=20 order by rownum"
            'Else
                'OraQuery = "select * from (select pdl_id_coil,pdl_cd_status,pdl_no_seq,pdl_sec1_coil ,trunc(pdl_sec2_coil,0)as pdl_sec2_coil ,pdl_ln_coil,pdl_grd_steel,pdl_cd_prod,pdl_cd_coat,pdl_id_schedule,PDL_PROC_SPEED,PDL_TP_COAT_AMT,PDL_BT_COAT_AMT  from v_pr_data_ip_cg2 " &
            '"where(pdl_cd_status = 'UP' or pdl_cd_status = 'WW' or  pdl_cd_status = 'WC' or  pdl_cd_status = 'WS') and pdl_ts_creation > to_char(to_date(sysdate-2,'DD-MM-YYYY HH24:MI:SS')) and pdl_cd_prod = '" & grade & "' order by pdl_id_pdi  asc) T1 where rownum<=20 order by rownum"
            'End If

            Ora_selectquery(OraQuery)
            OleAdap.Fill(schdeule_set)

            'schdeule_table = OraTable(OraQuery)
            schdeule_table = schdeule_set.Tables(0)
            If schdeule_table.Rows.Count > 0 Then
                dgv_ingot_predict.DataSource = schdeule_table
                dgv_ingot_predict.DataBind()

            End If
            If dgv_ingot_predict.Rows.Count > 0 Then
                dgv_ingot_predict.UseAccessibleHeader = True
                dgv_ingot_predict.HeaderRow.TableSection = TableRowSection.TableHeader
            End If


        Catch ex As Exception

        End Try

    End Sub

    Sub CloseConnection()
        Try
            If Oleconnection_ora.State <> ConnectionState.Closed Then
                Oleconnection_ora.Close()
            End If
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

    End Sub
    Public Function Ora_selectquery(ByVal strselect As String) As OracleDataAdapter
        Try
            OleCom.Connection = Oleconnection_ora

            OleCom.CommandText = strselect
            OleAdap.SelectCommand = OleCom

            Return OleAdap
        Catch ex As Exception

        End Try

    End Function

    Private Sub btnExportToExcel_Click(sender As Object, e As EventArgs) Handles btnExportToExcel.Click
        Try
            Response.Clear()
            Response.Buffer = True
            Response.ClearContent()
            Response.ClearHeaders()
            Response.Charset = ""
            Dim FileName = "AlFe Processed coils " + DateTime.Now + ".xls"
            Dim strwritter As New StringWriter()
            Dim htmltextwrtter As New HtmlTextWriter(strwritter)
            Response.Cache.SetCacheability(HttpCacheability.NoCache)
            Response.ContentType = "application/vnd.ms-excel"
            Response.AddHeader("Content-Disposition", "attachment;filename=" + FileName)
            gdvDetails.GridLines = GridLines.Both
            gdvDetails.HeaderStyle.Font.Bold = True
            'gdvDetails.Columns(0).Visible = True
            'gdvDetails.Columns(5).Visible = False
            'gdvDetails.Columns(6).Visible = False
            gdvDetails.RenderControl(htmltextwrtter)
            Response.Write(strwritter.ToString())
            Response.End()
        Catch ex As Exception

        End Try

    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)
        ' Verifies that the control is rendered 
    End Sub
End Class


