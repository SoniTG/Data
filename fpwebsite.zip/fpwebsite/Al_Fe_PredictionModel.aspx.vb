﻿Imports System.Data
Imports System.IO

Partial Class Al_Fe_PredictionModel
    Inherits System.Web.UI.Page
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Dim objController As New Controller

    Dim arrSolCurve_Al(), arrSolCurve_Fe() As Double
    Public Shared T_Bath_C, T_Bath_K, Al_tot_old, Fe_Tot_old, Al_eff, Fe_eff, Fe1, Fe2, J_Calc, Fe_solb, xTemp, Fe_tot As Double

    Sub CreateGraph()
        lblError.Text = ""
        'Al Effective
        '###########################
        ' Dim objEffectiveAlFeCalculation As New EffectiveAlFeCalculation
        Al_tot_old = txtTotalAI.Text
        Fe_Tot_old = txtTotalFE.Text
        T_Bath_C = txtPotTemp.Text
        T_Bath_K = txtPotTemp.Text + 273.15

        objEffectiveAlFeCalculation.Main(T_Bath_C, T_Bath_K)
        txtAITriplePoint.Text = Math.Round(objEffectiveAlFeCalculation.Al_trip, 4)
        txtFETriplePoint.Text = Math.Round(objEffectiveAlFeCalculation.Fe_trip, 4)

        'objEffectiveAlFeCalculation.mtdEffectivAlFeCal(Al_tot_old, T_Bath_K, objEffectiveAlFeCalculation.Al_trip, objEffectiveAlFeCalculation.Fe_trip)
        objEffectiveAlFeCalculation.Aleffcal(Al_tot_old, Fe_Tot_old)

        txtAITriplePoint.Text = Math.Round(objEffectiveAlFeCalculation.Al_trip, 4)
        txtFETriplePoint.Text = Math.Round(objEffectiveAlFeCalculation.Fe_trip, 4)
        Al_eff = Math.Round(objEffectiveAlFeCalculation.Al_liq, 4)
        If Al_eff = 0 Then
            litLineGraph.Text = ""
            txtAIEffective.Text = ""
            txtFEEffective.Text = ""
            txtAITriplePoint.Text = ""
            txtFETriplePoint.Text = ""
            lblError.Text = "Effective AL = 0; ""Inappropriate values of Total AL or Total FE"""
            'UserMsgBox("Inappropriate values for Total AL or Total FE.")
            Exit Sub
        End If
        txtAIEffective.Text = Al_eff

        Fe_eff = Math.Round(objEffectiveAlFeCalculation.Fe_liq, 4)
        txtFEEffective.Text = Fe_eff
        '###########################


        'Dim objEffectiveAlFeCalculation As New EffectiveAlFeCalculation
        Al_tot_old = txtTotalAI.Text

        Dim AL_St_pnt, Fe_St_pnt, AL_End_pnt, Fe_End_pnt, Al_increment As Double
        AL_St_pnt = 0.08
        Fe_St_pnt = 0.0
        AL_End_pnt = 0.3  ' changed by mamta on 21 sep'18 to increase x-axis till 0.3 -old value 0.26
        Fe_End_pnt = 0.1   ' changed by mamta on 21 sep'18 to increase y-axis till 0.1 -- old valuec 0.05
        Dim no_iteration As Integer
        no_iteration = (AL_End_pnt - AL_St_pnt) * 10000 + 1
        Al_increment = 0.0001
        ReDim Preserve arrSolCurve_Al(no_iteration - 1)
        ReDim Preserve arrSolCurve_Fe(no_iteration - 1)
        For i As Integer = 0 To no_iteration - 1
            Al_tot_old = Math.Round(AL_St_pnt + i * Al_increment, 4)

            objEffectiveAlFeCalculation.mtdEffectivAlFeCal(Al_tot_old, T_Bath_K, objEffectiveAlFeCalculation.Al_trip, objEffectiveAlFeCalculation.Fe_trip)
            arrSolCurve_Al(i) = Al_tot_old
            arrSolCurve_Fe(i) = Math.Round(objEffectiveAlFeCalculation.Fe_liq, 4)

        Next

        equation_line()
        PlotLineChart("% Al", "% Fe", litLineGraph, "divContainer", "test", "Fe-Al-Zn* Ternary Phase Diagram at " & txtPotTemp.Text & " ℃", "Y Label")

        'PlotCurve()
        'equation_line()

    End Sub

    Sub TransitionGraph(ByVal FromDate As String, ByVal ToDate As String)
        lblError.Text = ""
        'Al Effective
        '###########################
        ' Dim objEffectiveAlFeCalculation As New EffectiveAlFeCalculation
        Al_tot_old = txtTotalAI.Text
        Fe_Tot_old = txtTotalFE.Text
        T_Bath_C = txtPotTemp.Text
        T_Bath_K = txtPotTemp.Text + 273.15

        objEffectiveAlFeCalculation.Main(T_Bath_C, T_Bath_K)
        txtAITriplePoint.Text = Math.Round(objEffectiveAlFeCalculation.Al_trip, 4)
        txtFETriplePoint.Text = Math.Round(objEffectiveAlFeCalculation.Fe_trip, 4)

        'objEffectiveAlFeCalculation.mtdEffectivAlFeCal(Al_tot_old, T_Bath_K, objEffectiveAlFeCalculation.Al_trip, objEffectiveAlFeCalculation.Fe_trip)
        objEffectiveAlFeCalculation.Aleffcal(Al_tot_old, Fe_Tot_old)

        txtAITriplePoint.Text = Math.Round(objEffectiveAlFeCalculation.Al_trip, 4)
        txtFETriplePoint.Text = Math.Round(objEffectiveAlFeCalculation.Fe_trip, 4)
        Al_eff = Math.Round(objEffectiveAlFeCalculation.Al_liq, 4)
        If Al_eff = 0 Then
            litLineGraph.Text = ""
            txtAIEffective.Text = ""
            txtFEEffective.Text = ""
            txtAITriplePoint.Text = ""
            txtFETriplePoint.Text = ""
            lblError.Text = "Inappropriate values for Total AL or Total FE."
            'UserMsgBox("Inappropriate values for Total AL or Total FE.")
            Exit Sub
        End If
        txtAIEffective.Text = Al_eff

        Fe_eff = Math.Round(objEffectiveAlFeCalculation.Fe_liq, 4)
        txtFEEffective.Text = Fe_eff
        '###########################


        'Dim objEffectiveAlFeCalculation As New EffectiveAlFeCalculation
        Al_tot_old = txtTotalAI.Text

        Dim AL_St_pnt, Fe_St_pnt, AL_End_pnt, Fe_End_pnt, Al_increment As Double
        AL_St_pnt = 0.08
        Fe_St_pnt = 0.0
        AL_End_pnt = 0.35  ' changed by mamta on 21 sep'18 to increase x-axis till 0.35 -old value 0.26
        Fe_End_pnt = 0.1   ' changed by mamta on 21 sep'18 to increase y-axis till 0.1 -- old valuec 0.05
        Dim no_iteration As Integer
        no_iteration = (AL_End_pnt - AL_St_pnt) * 10000 + 1
        Al_increment = 0.0001
        ReDim Preserve arrSolCurve_Al(no_iteration - 1)
        ReDim Preserve arrSolCurve_Fe(no_iteration - 1)
        For i As Integer = 0 To no_iteration - 1
            Al_tot_old = Math.Round(AL_St_pnt + i * Al_increment, 4)

            objEffectiveAlFeCalculation.mtdEffectivAlFeCal(Al_tot_old, T_Bath_K, objEffectiveAlFeCalculation.Al_trip, objEffectiveAlFeCalculation.Fe_trip)
            arrSolCurve_Al(i) = Al_tot_old
            arrSolCurve_Fe(i) = Math.Round(objEffectiveAlFeCalculation.Fe_liq, 4)

        Next

        Dim dt As New DataTable
        equation_line()
        PlotLineChart(dt, "% Al", "% Fe", litLineGraph, "divContainer", "test", "Fe-Al-Zn* Ternary Phase Diagram at " & txtPotTemp.Text & " ℃", "Y Label", FromDate, ToDate)

        'PlotCurve()
        'equation_line()

    End Sub

    Sub EffectiveAlAndFeChart()
        Try
            litChart.Text = ""
            Dim dt As DataTable = objController.GetZnBathTrendData(txtFrom.Text.Trim, txtTo.Text.Trim)
            Dim query = From val In dt.AsEnumerable() Where val.Field(Of String)("CAMPAIGN") = "GI" Select val Order By val.Field(Of DateTime)("CZT_TIMESTAMP")
            'Dim dtGI As DataTable = query.CopyToDataTable
            Dim dtGI As DataTable
            Try
                dtGI = query.CopyToDataTable
            Catch ex As Exception
                dtGI = New DataTable
            End Try
            query = From val In dt.AsEnumerable() Where val.Field(Of String)("CAMPAIGN") = "GA" Select val Order By val.Field(Of DateTime)("CZT_TIMESTAMP")
            'Dim dtGA As DataTable = query.CopyToDataTable
            Dim dtGA As DataTable
            Try
                dtGA = query.CopyToDataTable
            Catch ex As Exception
                dtGA = New DataTable
            End Try

            'Below are the temporary datatables holding false record in between two rows having time difference of 24 hours or more.
            Dim dtGI_Temp As New DataTable
            dtGI_Temp.Columns.Add("CZT_EFF_AL", GetType(Decimal))
            dtGI_Temp.Columns.Add("CZT_EFF_FE", GetType(Decimal))
            dtGI_Temp.Columns.Add("CZT_TIMESTAMP", GetType(DateTime))
            dtGI_Temp.Columns.Add("CZT_CAMP_AL", GetType(String))
            dtGI_Temp.Columns.Add("CZT_POT_AL", GetType(Decimal))
            dtGI_Temp.Columns.Add("CZT_POT_FE", GetType(Decimal))
            dtGI_Temp.Columns.Add("CAMPAIGN", GetType(String))
            dtGI_Temp.Columns.Add("UCL", GetType(Decimal))
            dtGI_Temp.Columns.Add("LCL", GetType(Decimal))
            For i As Integer = 0 To dtGI.Rows.Count - 1
                Dim row As DataRow = dtGI_Temp.NewRow
                row("CZT_EFF_AL") = dtGI.Rows(i)("CZT_EFF_AL")
                row("CZT_EFF_FE") = dtGI.Rows(i)("CZT_EFF_FE")
                row("CZT_TIMESTAMP") = CDate(dtGI.Rows(i)("CZT_TIMESTAMP"))
                row("CZT_CAMP_AL") = dtGI.Rows(i)("CZT_CAMP_AL")
                row("CZT_POT_AL") = dtGI.Rows(i)("CZT_POT_AL")
                row("CZT_POT_FE") = dtGI.Rows(i)("CZT_POT_FE")
                row("CAMPAIGN") = dtGI.Rows(i)("CAMPAIGN")
                row("UCL") = dtGI.Rows(i)("UCL")
                row("LCL") = dtGI.Rows(i)("LCL")
                dtGI_Temp.Rows.Add(row)
                If i < dtGI.Rows.Count - 1 Then
                    Dim span As TimeSpan = DateTime.Parse(dtGI.Rows(i + 1)("CZT_TIMESTAMP")).Subtract(DateTime.Parse(dtGI.Rows(i)("CZT_TIMESTAMP")))
                    If span.TotalHours >= 24 Then
                        dtGI_Temp.Rows.Add(dtGI.Rows(i)("CZT_EFF_AL"), dtGI.Rows(i)("CZT_EFF_FE"), CDate(dtGI.Rows(i)("CZT_TIMESTAMP")).AddMinutes(10),
                                           dtGI.Rows(i)("CZT_CAMP_AL"), dtGI.Rows(i)("CZT_POT_AL"), dtGI.Rows(i)("CZT_POT_FE"), dtGI.Rows(i)("CAMPAIGN"), 0, 0)
                    End If
                End If
            Next

            Dim dtGA_Temp As New DataTable
            dtGA_Temp.Columns.Add("CZT_EFF_AL", GetType(Decimal))
            dtGA_Temp.Columns.Add("CZT_EFF_FE", GetType(Decimal))
            dtGA_Temp.Columns.Add("CZT_TIMESTAMP", GetType(DateTime))
            dtGA_Temp.Columns.Add("CZT_CAMP_AL", GetType(String))
            dtGA_Temp.Columns.Add("CZT_POT_AL", GetType(Decimal))
            dtGA_Temp.Columns.Add("CZT_POT_FE", GetType(Decimal))
            dtGA_Temp.Columns.Add("CAMPAIGN", GetType(String))
            dtGA_Temp.Columns.Add("UCL", GetType(Decimal))
            dtGA_Temp.Columns.Add("LCL", GetType(Decimal))
            For i As Integer = 0 To dtGA.Rows.Count - 1
                Dim row As DataRow = dtGA_Temp.NewRow
                row("CZT_EFF_AL") = dtGA.Rows(i)("CZT_EFF_AL")
                row("CZT_EFF_FE") = dtGA.Rows(i)("CZT_EFF_FE")
                row("CZT_TIMESTAMP") = CDate(dtGA.Rows(i)("CZT_TIMESTAMP"))
                row("CZT_CAMP_AL") = dtGA.Rows(i)("CZT_CAMP_AL")
                row("CZT_POT_AL") = dtGA.Rows(i)("CZT_POT_AL")
                row("CZT_POT_FE") = dtGA.Rows(i)("CZT_POT_FE")
                row("CAMPAIGN") = dtGA.Rows(i)("CAMPAIGN")
                row("UCL") = dtGA.Rows(i)("UCL")
                row("LCL") = dtGA.Rows(i)("LCL")
                dtGA_Temp.Rows.Add(row)
                If i < dtGA.Rows.Count - 1 Then
                    Dim span As TimeSpan = DateTime.Parse(dtGA.Rows(i + 1)("CZT_TIMESTAMP")).Subtract(DateTime.Parse(dtGA.Rows(i)("CZT_TIMESTAMP")))
                    If span.TotalHours >= 24 Then
                        dtGA_Temp.Rows.Add(dtGA.Rows(i)("CZT_EFF_AL"), dtGA.Rows(i)("CZT_EFF_FE"), CDate(dtGA.Rows(i)("CZT_TIMESTAMP")).AddMinutes(10),
                                           dtGA.Rows(i)("CZT_CAMP_AL"), dtGA.Rows(i)("CZT_POT_AL"), dtGA.Rows(i)("CZT_POT_FE"), dtGA.Rows(i)("CAMPAIGN"), 0, 0)
                    End If
                End If
            Next
            '---------------------------------------END OF TEMPORARY DATATABLES----------------------------------------------

            'Dim giUclDataPoints As String = "var GI_UCL = [['" & CDate(dtGI.Rows(0)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGI.Rows(0)("UCL") & "], ['" & CDate(dtGI.Rows(dtGI.Rows.Count - 1)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGI.Rows(dtGI.Rows.Count - 1)("UCL") & "]];"
            Dim giUclDataPoints As String = "var GI_UCL = [["
            For i As Integer = 0 To dtGI_Temp.Rows.Count - 1
                If i = dtGI_Temp.Rows.Count - 1 Then
                    giUclDataPoints &= "'" & CDate(dtGI_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGI_Temp.Rows(i)("UCL") = 0, "null", dtGI_Temp.Rows(i)("UCL")) & "]];"
                Else
                    giUclDataPoints &= "'" & CDate(dtGI_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGI_Temp.Rows(i)("UCL") = 0, "null", dtGI_Temp.Rows(i)("UCL")) & "], ["
                End If
            Next
            If dtGI_Temp.Rows.Count = 0 Then
                giUclDataPoints &= "]];"
            End If

            'Dim giLclDataPoints As String = "var GI_LCL = [['" & CDate(dtGI_Temp.Rows(0)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGI_Temp.Rows(0)("LCL") & "], ['" & CDate(dtGI_Temp.Rows(dtGI_Temp.Rows.Count - 1)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGI_Temp.Rows(dtGI_Temp.Rows.Count - 1)("LCL") & "]];"
            Dim giLclDataPoints As String = "var GI_LCL = [["
            For i As Integer = 0 To dtGI_Temp.Rows.Count - 1
                If i = dtGI_Temp.Rows.Count - 1 Then
                    giLclDataPoints &= "'" & CDate(dtGI_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGI_Temp.Rows(i)("LCL") = 0, "null", dtGI_Temp.Rows(i)("LCL")) & "]];"
                Else
                    giLclDataPoints &= "'" & CDate(dtGI_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGI_Temp.Rows(i)("LCL") = 0, "null", dtGI_Temp.Rows(i)("LCL")) & "], ["
                End If
            Next
            If dtGI_Temp.Rows.Count = 0 Then
                giLclDataPoints &= "]];"
            End If

            'Dim gaUclDataPoints As String = "var GA_UCL = [['" & CDate(dtGA.Rows(0)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGA.Rows(0)("UCL") & "], ['" & CDate(dtGA.Rows(dtGA.Rows.Count - 1)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGA.Rows(dtGA.Rows.Count - 1)("UCL") & "]];"
            Dim gaUclDataPoints As String = "var GA_UCL = [["
            For i As Integer = 0 To dtGA_Temp.Rows.Count - 1
                If i = dtGA_Temp.Rows.Count - 1 Then
                    gaUclDataPoints &= "'" & CDate(dtGA_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGA_Temp.Rows(i)("UCL") = 0, "null", dtGA_Temp.Rows(i)("UCL")) & "]];"
                Else
                    gaUclDataPoints &= "'" & CDate(dtGA_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGA_Temp.Rows(i)("UCL") = 0, "null", dtGA_Temp.Rows(i)("UCL")) & "], ["
                End If
            Next
            If dtGA_Temp.Rows.Count = 0 Then
                gaUclDataPoints &= "]];"
            End If

            'Dim gaLclDataPoints As String = "var GA_LCL = [['" & CDate(dtGA_Temp.Rows(0)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGA_Temp.Rows(0)("LCL") & "], ['" & CDate(dtGA_Temp.Rows(dtGA_Temp.Rows.Count - 1)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGA_Temp.Rows(dtGA_Temp.Rows.Count - 1)("LCL") & "]];"
            Dim gaLclDataPoints As String = "var GA_LCL = [["
            For i As Integer = 0 To dtGA_Temp.Rows.Count - 1
                If i = dtGA_Temp.Rows.Count - 1 Then
                    gaLclDataPoints &= "'" & CDate(dtGA_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGA_Temp.Rows(i)("LCL") = 0, "null", dtGA_Temp.Rows(i)("LCL")) & "]];"
                Else
                    gaLclDataPoints &= "'" & CDate(dtGA_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGA_Temp.Rows(i)("LCL") = 0, "null", dtGA_Temp.Rows(i)("LCL")) & "], ["
                End If
            Next
            If dtGA_Temp.Rows.Count = 0 Then
                gaLclDataPoints &= "]];"
            End If

            Dim min_time, max_time As String
            min_time = Format(dt.Rows(0)("CZT_TIMESTAMP"), "yyyy-MM-dd HH:mm")
            max_time = Format(dt.Rows(dt.Rows.Count - 1)("CZT_TIMESTAMP"), "yyyy-MM-dd HH:mm")

            Dim xTimestampVal(), y1EffectiveAlVal(), y2EffectiveFe() As String

            xTimestampVal = (From row In dt Select col = row("CZT_TIMESTAMP").ToString).ToArray
            y1EffectiveAlVal = (From row In dt Select col = row("CZT_EFF_AL").ToString).ToArray()
            y2EffectiveFe = (From row In dt Select col = row("CZT_EFF_FE").ToString).ToArray()

            'Dim Al_min As String = 0 'As per the Excel file.
            'Dim Al_max As String = 0.35 'As per the Excel file.
            'Dim Fe_min As String = 0 'As per the Excel file.
            'Dim Fe_max As String = 0.07 'As per the Excel file.
            Dim Al_min As String = 0 'Changed by mamta on 11-Jan-2018
            Dim Al_max As String = 0.3 'Changed by mamta on 11-Jan-2018
            Dim Fe_min As String = 0 'Changed by mamta on 11-Jan-2018
            Dim Fe_max As String = 0.05 'Changed by mamta on 11-Jan-2018

            Dim js = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$(document).ready(function(){" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf &
                    "var series= ['Effective Aluminium', 'Effective Iron', 'GI Limits', 'GA Limits']" & vbCrLf &
                    "var data1 = [["
            For i = 0 To dt.Rows.Count - 1
                If i = xTimestampVal.Length - 1 Then
                    js &= "'" & DateTime.Parse(xTimestampVal.GetValue(i).ToString().Trim()).ToString("yyyy-MM-dd HH:mm") & "', " & y1EffectiveAlVal.GetValue(i).ToString().Trim() & "]]; " & vbCrLf
                Else
                    js &= "'" & DateTime.Parse(xTimestampVal.GetValue(i).ToString().Trim()).ToString("yyyy-MM-dd HH:mm") & "', " & y1EffectiveAlVal.GetValue(i).ToString().Trim() & "], ["
                End If
            Next


            js &= "var data2 = [["
            For i = 0 To dt.Rows.Count - 1
                If i = xTimestampVal.Length - 1 Then
                    js &= "'" & DateTime.Parse(xTimestampVal.GetValue(i).ToString().Trim()).ToString("yyyy-MM-dd HH:mm") & "', " & y2EffectiveFe.GetValue(i).ToString().Trim() & "]]; " & vbCrLf
                Else
                    js &= "'" & DateTime.Parse(xTimestampVal.GetValue(i).ToString().Trim()).ToString("yyyy-MM-dd HH:mm") & "', " & y2EffectiveFe.GetValue(i).ToString().Trim() & "], ["
                End If
            Next

            js &= vbCrLf & vbCrLf & giLclDataPoints & vbCrLf & vbCrLf & giUclDataPoints & vbCrLf & vbCrLf & gaLclDataPoints & vbCrLf & vbCrLf & gaUclDataPoints & vbCrLf & vbCrLf

            Dim EffAl_Series As String = "{pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:80px; width:180px; background-color:#0D5CA5; font-weight:bold; font-size:x-large; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td><center>%s</center></td></tr></table>'}}"
            Dim EffFe_Series As String = "{pointLabels: { show:false }, showLine: true, yaxis:'y2axis', lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:80px; width:180px; background-color:#BC2318; font-weight:bold; font-size:x-large; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td><center>%s</center></td></tr></table>'}}"
            Dim GI_Limit_Series As String = "{pointLabels:{show:!1},showLine:!0,lineWidth:2,breakOnNull: true,linePattern:'dashed',showMarker:!1,color:'#00FF19',highlighter:{show:!0,showMarker:!1,tooltipAxes:'xy',yvalues:2,formatString:'<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
            Dim GA_Limit_Series As String = "{pointLabels:{show:!1},showLine:!0,lineWidth:2,breakOnNull: true,linePattern:'dashed',showMarker:!1,color:'#000000',highlighter:{show:!0,showMarker:!1,tooltipAxes:'xy',yvalues:2,formatString:'<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"

            js &= "opts = {" & vbCrLf &
            "title: 'Calculated Effective Al & Fe'," & vbCrLf &
            "series:[" & EffAl_Series & ", " & EffFe_Series & ", " & GI_Limit_Series & ", " & GI_Limit_Series & ", " & GA_Limit_Series & ", " & GA_Limit_Series & "]," & vbCrLf &
            "seriesColors: ['#0D5CA5', '#BC2318']," & vbCrLf &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            "fontSize:'8pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf &
            "renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
            "tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," & vbCrLf &
            "//tickInterval:'1 hour'," & vbCrLf &
            "pad:0" & vbCrLf &
            "}," & vbCrLf &
            "yaxis: { " & vbCrLf &
            "tickOptions: { formatString: '%.3f' }," & vbCrLf &
            "min: " & Al_min & "," & vbCrLf &
            "max: " & Al_max & "," & vbCrLf &
            "//autoscale:true," & vbCrLf &
            "label: '% Effective Al'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}," & vbCrLf &
            "y2axis: { " & vbCrLf &
            "tickOptions: { formatString: '%.3f' }," & vbCrLf &
            "min: " & Fe_min & "," & vbCrLf &
            "max: " & Fe_max & "," & vbCrLf &
            "//autoscale:true," & vbCrLf &
            "//tickOptions:{showGridline:false}," & vbCrLf &
            "label: '% Effective Fe'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "//highlighter: { show: 'true', tooltipFormatString: '%.1f', useAxesFormatters: false }," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
            "legend: {" & vbCrLf &
            "show: true," & vbCrLf &
            "location: 's'," & vbCrLf &
            "labels: series," & vbCrLf &
            "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
            "placement: 'outsideGrid'," & vbCrLf &
            "rendererOptions: {" & vbCrLf &
            "numberRows: 1," & vbCrLf &
            "numberColumns: 2," & vbCrLf &
            "marginTop: 10" & vbCrLf &
            "}" & vbCrLf &
            "}" & vbCrLf &
            "};" & vbCrLf &
            "plotFeAl = $.jqplot('divContainer1', [data1, data2, GI_UCL, GI_LCL, GA_UCL, GA_LCL], opts);" & vbCrLf &
            "});" & vbCrLf &
            "</script>" & vbCrLf

            litChart.Text = js
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnCreateGraph_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCreateGraph.Click
        Try
            CreateGraph()
        Catch ex As Exception

        End Try

    End Sub

    Public Sub LoadValues()
        T_Bath_C = txtPotTemp.Text
        T_Bath_K = T_Bath_C + 273.15

        Dim dsAlFeData As DataSet = objController.GetAlFeData("L")
        If dsAlFeData.Tables.Count > 0 Then
            Dim dtAlData As DataTable = dsAlFeData.Tables(0)
            Dim dtFeData As DataTable = dsAlFeData.Tables(1)

            If dtAlData.Rows.Count > 0 Then
                txtTotalAI.Text = dtAlData.Rows(0)("CLR_TEST_VALUE")

                If CDec(dtAlData.Rows(0)("CLR_PARAM_MIN")) = 0.125 Then
                    txtPotTemp.Text = "470"
                ElseIf CDec(dtAlData.Rows(0)("CLR_PARAM_MIN")) = 0.165 Or CDec(dtAlData.Rows(0)("CLR_PARAM_MIN")) = 0.15 Then
                    txtPotTemp.Text = "460"
                End If

                lblSamplingDateAL.Text = " On " & CDate(dtAlData.Rows(0)("CLR_DT_SAMPLING_DATE")).ToString("dd-MM-yy HH:mm")
            End If
            If dtFeData.Rows.Count > 0 Then
                txtTotalFE.Text = dtFeData.Rows(0)("CLR_TEST_VALUE")
                lblSamplingDateFE.Text = " On " & CDate(dtFeData.Rows(0)("CLR_DT_SAMPLING_DATE")).ToString("dd-MM-yy HH:mm")
            End If
            'lblSamplingDateFE.Text = "Sampling Date " & CDate(dtAlData.Rows(0)("CLR_DT_SAMPLING_DATE")).ToString("dd-MMM-yyyy HH:mm:ss")
        End If

        Al_tot_old = txtTotalAI.Text
        Fe_Tot_old = txtTotalFE.Text
    End Sub

    Sub UserMsgBox(ByVal Message As String)
        ScriptManager.RegisterClientScriptBlock(Me, Me.GetType(), "alertMessage", "alert('" & Message & "')", True)
    End Sub

    Public Sub dataValidationForAl_Fe()
        If Al_tot_old > 0.1 And Al_tot_old < 0.35 Then
        Else
            UserMsgBox("Total Al should be between 0.1000 & 0.3500")
        End If
        If Fe_Tot_old > 0.005 And Fe_Tot_old < 0.05 Then
        Else
            UserMsgBox("Total Al should be between 0.005 & 0.05")
        End If

        If T_Bath_C > 430 And T_Bath_C < 480 Then
        Else
            UserMsgBox("Total Al should be between 430 & 480")
        End If
    End Sub

    Public Sub PlotLineChart(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal,
                             ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String,
                             ByVal Trans_From_Date As String, ByVal Trans_To_Date As String)
        Try
            LiteralName.Text = ""

            Dim dtTransitionData As DataTable = objController.GetZnBathTrendData(Trans_From_Date, Trans_To_Date)
            Dim arrEffAl_X() As Decimal = (From row In dtTransitionData Select col = CDec(row("CZT_POT_AL"))).ToArray()
            Dim arrEffFe_Y() As Decimal = (From row In dtTransitionData Select col = CDec(row("CZT_POT_FE"))).ToArray()

            Dim min_time, max_time As String
            min_time = 0.08
            max_time = 0.3 'Changed from 0.26 to 0.3 as told by Mamta on 21st sep 2018

            Dim yVal() As Decimal
            yVal = (From row In dt Select col = CDec(row(YAxisColName))).ToArray()

            Dim y_min As String = 0.0
            Dim y_max As String = 0.1 'Changed from 0.06 to 0.1 as told by Mamta on 24th August 2018

            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf &
                    "  $('#resizable').resizable({delay:20});" &
                    " $('#resizable').bind('resize', function(event, ui) {test.replot( { resetAxes: false } ); }); "

            'Dim bottomLineDataForLeftBox As String = "var bottomLineDataForLeftBox = [[0.125, 0.038], [0.135, 0.038]];"
            'Dim rightLineDataForLeftBox As String = "var rightLineDataForLeftBox = [[0.135, 0.038], [0.135, 0.048]];"
            'Dim topLineDataForLeftBox As String = "var topLineDataForLeftBox = [[0.135, 0.048], [0.125, 0.048]];"
            'Dim leftLineDataForLeftBox As String = "var leftLineDataForLeftBox = [[0.125, 0.048], [0.125, 0.038]];"

            Dim bottomLineDataForLeftBox As String = "var bottomLineDataForLeftBox = [[0.113, 0.03], [0.127, 0.03]];"
            Dim rightLineDataForLeftBox As String = "var rightLineDataForLeftBox = [[0.127, 0.03], [0.127, 0.04]];"
            Dim topLineDataForLeftBox As String = "var topLineDataForLeftBox = [[0.127, 0.04], [0.113, 0.04]];"
            Dim leftLineDataForLeftBox As String = "var leftLineDataForLeftBox = [[0.113, 0.04], [0.113, 0.03]];"

            Dim bottomLineDataForRightBox As String = "var bottomLineDataForRightBox = [[0.185, 0.016], [0.205, 0.016]];"
            Dim rightLineDataForRightBox As String = "var rightLineDataForRightBox = [[0.205, 0.016], [0.205, 0.020]];"
            Dim topLineDataForRightBox As String = "var topLineDataForRightBox = [[0.205, 0.020], [0.185, 0.020]];"
            Dim leftLineDataForRightBox As String = "var leftLineDataForRightBox = [[0.185, 0.020], [0.185, 0.016]];"

            dt.DefaultView.RowFilter = ""
            Dim dvDefault As DataView = dt.DefaultView
            Dim flag As Boolean = False

            Dim boolCheckData As Boolean = False
            js &= vbCrLf
            For i As Integer = 0 To objEffectiveAlFeCalculation.dict.Count - 1
                boolCheckData = False
                js &= vbCrLf
                js &= "var line" & (i + 1).ToString & " = ["

                Dim arrData() As Double = objEffectiveAlFeCalculation.dict(i)

                Dim left As Object = 0
                For j As Integer = 0 To UBound(objEffectiveAlFeCalculation.dict(i))
                    If arrData(j) <= 0 Then
                        Continue For
                    End If

                    If boolCheckData = True Then
                        js &= ","
                    End If

                    js &= "["

                    If i = 0 Then
                        If j < 10 Then
                            js &= "" & objEffectiveAlFeCalculation.arrAl_Liq(j) & ", " & arrData(j) & ",'a'"
                        Else
                            js &= "" & objEffectiveAlFeCalculation.arrAl_Liq(j) & ", " & arrData(j) & ",'b'"

                        End If
                    ElseIf i = 3 Then
                        If left = 0 Then
                            left = (165 / 0.056) * objEffectiveAlFeCalculation.arrAl_Liq(j) 'To calculate the left position of the label placed in the CONODE area.
                            litLabelPosition.Text = "<script type='text/javascript'>document.getElementById('divLabel3').style.top = '50px'; document.getElementById('divLabel3').style.left = '" & left & "px';</script>"
                        End If
                        js &= "" & objEffectiveAlFeCalculation.arrAl_Liq(j) & ", " & arrData(j) & ",'c'"
                    Else
                        js &= "" & objEffectiveAlFeCalculation.arrAl_Liq(j) & ", " & arrData(j) & ",'c'"
                    End If

                    js &= "]"
                    boolCheckData = True
                Next

                js &= "];" & vbCrLf
                flag = True
            Next
            'Till here four lines are created

            boolCheckData = False
            js &= vbCrLf
            js &= "var line" & (objEffectiveAlFeCalculation.dict.Count + 1).ToString & " = ["
            For j As Integer = 0 To 25
                If boolCheckData = True Then
                    js &= ","
                End If

                js &= "["

                js &= "" & arrSlope(j, 0) & ", " & arrSlope(j, 1)

                js &= "]"
                boolCheckData = True

            Next
            js &= "];" & vbCrLf
            flag = True
            js &= vbCrLf
            js &= "var line" & (objEffectiveAlFeCalculation.dict.Count + 2).ToString & " = ["
            js &= "["
            js &= "" & txtTotalAI.Text & ", " & txtTotalFE.Text
            js &= "]"
            js &= "];" & vbCrLf
            js &= vbCrLf
            js &= "var line" & (objEffectiveAlFeCalculation.dict.Count + 3).ToString & " = ["
            js &= "["
            js &= "" & txtAIEffective.Text & ", " & txtFEEffective.Text
            js &= "]"
            js &= "];" & vbCrLf
            js &= vbCrLf
            js &= "var line" & (objEffectiveAlFeCalculation.dict.Count + 4).ToString & " = ["
            js &= "["
            js &= "" & txtTotalAI.Text & ", " & txtTotalFE.Text
            js &= "],"
            js &= "["
            js &= "" & txtTotalAI.Text & ", " & 0
            js &= "]"
            js &= "];" & vbCrLf
            js &= vbCrLf
            js &= "var line" & (objEffectiveAlFeCalculation.dict.Count + 5).ToString & " = ["
            js &= "["
            js &= "" & txtTotalAI.Text & ", " & txtTotalFE.Text
            js &= "],"
            js &= "["
            js &= "" & 0 & ", " & txtTotalFE.Text
            js &= "]"
            js &= "];" & vbCrLf
            js &= vbCrLf

            '----------------------------------------------------------------------------------------------------------------------------
            js &= bottomLineDataForLeftBox & vbCrLf & rightLineDataForLeftBox & vbCrLf & topLineDataForLeftBox & vbCrLf & leftLineDataForLeftBox & vbCrLf
            js &= bottomLineDataForRightBox & vbCrLf & rightLineDataForRightBox & vbCrLf & topLineDataForRightBox & vbCrLf & leftLineDataForRightBox & vbCrLf

            Dim boxSeries As String = "{pointLabels: { show:false }, showLine:true, lineWidth:2, color: '#0B9126', markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: true,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold; font-size:12px;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
            '----------------------------------------------------------------------------------------------------------------------------

            Dim strg As String = ""
            Dim strseries As String = ""

            If flag Then
                strg = "[line1"
                strseries = " {pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: true,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}" & vbCrLf
                For i As Integer = 1 To objEffectiveAlFeCalculation.dict.Count + 4 '- 1 'dtGrades.Rows.Count - 1
                    strg = strg + ",line" & i + 1

                    If i = 4 Or i = 7 Or i = 8 Then
                        strseries = strseries + ", {pointLabels: { show:false }, showLine:true, lineWidth:1, linePattern: 'dashed',  markerOptions:{ size: 5 }, highlighter: {show: false,showMarker: true,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}" & vbCrLf
                    ElseIf i >= 5 Then
                        strseries = strseries + ", {pointLabels: { show:false }, neighborThreshold: 0, showLine:false, showMarker:true, markerOptions: { style:'X' }}"

                    Else
                        strseries = strseries + ", {pointLabels: { show:false }, showLine:true, lineWidth:3, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: true,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}" & vbCrLf
                    End If

                Next
                strseries &= ", {pointLabels: { show:true }, showLine:false, color: '#1D00FF', lineWidth:2, markerOptions:{ show:true, size: 5, style:'circle' }, highlighter: {show: true,showMarker: true,tooltipAxes:'xy',yvalues: 3,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}" & vbCrLf
                strseries = strseries & ", " & boxSeries & ", " & boxSeries & ", " & boxSeries & ", " & boxSeries & ", " & boxSeries & ", " & boxSeries & ", " & boxSeries & ", " & boxSeries
                strg &= ", EffData, bottomLineDataForLeftBox, rightLineDataForLeftBox, topLineDataForLeftBox, leftLineDataForLeftBox, bottomLineDataForRightBox, rightLineDataForRightBox, topLineDataForRightBox, leftLineDataForRightBox]"
            End If

            js &= vbCrLf
            js &= "var EffData = ["
            For i As Integer = 0 To arrEffAl_X.Length - 1
                If i > 0 Then
                    js &= ", "
                End If
                js &= "[" & arrEffAl_X(i) & ", " & arrEffFe_Y(i) & ", '" & (i + 1) & "']"
            Next
            js &= "];"

            js &= vbCrLf
            js &= "var seriesName = ['"
            Dim str As String = ""
            Dim testarr() As String = {"line1", "line2", "line3", "line4", "line5", "line6", "line7", "line8", "line9"}
            For i As Integer = 0 To objEffectiveAlFeCalculation.dict.Count - 1
                str &= testarr(i) & "', '"
            Next
            str = str.Remove(str.LastIndexOf(", '"))
            str &= ", 'EffData'"

            str &= "];"
            js &= str
            js &= vbCrLf
            js &= "opts = {" & vbCrLf &
            "title: '" & ChartTitle & "'," & vbCrLf &
            "seriesDefaults: { pointLabels: { show:false }, showMarker:false, rendererOptions: {showDataLabels: true, dataLabels:  'label', diameter: 250, dataLabelPositionFactor: 0.5,sliceMargin: 3,color:'#DCDCDC', smooth:false } }," & vbCrLf &
            "series:[" & strseries & "]," & vbCrLf &
            "//seriesColors: ['#FFA500']," & vbCrLf &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            "fontSize:'8pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "min: " & min_time & ", max: " & max_time & "," & vbCrLf &
            "label: '" & XAxisColName & "'," & vbCrLf &
            "//labelRenderer: $.jqplot.CanvasAxisLabelRenderer," & vbCrLf &
            "//renderer:$.jqplot.EnhancedLegendRenderer," & vbCrLf &
            "tickOptions:{formatString:'', angle: -30}," & vbCrLf &
            "tickInterval:0.005," & vbCrLf &
            "//numberTicks: 0.0001," & vbCrLf &
            "pad:0" & vbCrLf &
            "}," & vbCrLf &
            "yaxis: { " & vbCrLf &
            "//tickOptions: { formatString: '%.3f' }," & vbCrLf &
            "min: " & y_min & "," & vbCrLf &
            "max: " & y_max & "," & vbCrLf &
            "//autoscale:true," & vbCrLf &
             "tickOptions:{formatString:'', angle: -30}," & vbCrLf &
            "tickInterval:0.005," & vbCrLf &
            "label: '" & YAxisColName & "'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "showTooltip: false," & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "animate: true," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "', " & strg & ", opts);" & vbCrLf &
            "</script>" & vbCrLf

            litLineGraph.Text = js
        Catch ex As Exception

        End Try
    End Sub

    Public Sub PlotLineChart(ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal,
                             ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String)
        Try

            LiteralName.Text = ""
            Dim min_time, max_time As String
            min_time = 0.08
            max_time = 0.3 'Changed from 0.26 to 0.3 as told by Mamta on 21st sep 2018

            'Dim yVal() As Decimal
            'yVal = (From row In dt Select col = CDec(row(YAxisColName))).ToArray()

            Dim y_min As String = 0.0
            Dim y_max As String = 0.1 'Changed from 0.06 to 0.1 as told by Mamta on 24th August 2018

            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf &
                    "  $('#resizable').resizable({delay:20});" &
                    " $('#resizable').bind('resize', function(event, ui) {test.replot( { resetAxes: false } ); }); "

            'dt.DefaultView.RowFilter = ""
            'Dim dvDefault As DataView = dt.DefaultView
            'Dim bottomLineDataForLeftBox As String = "var bottomLineDataForLeftBox = [[0.125, 0.038], [0.135, 0.038]];"
            'Dim rightLineDataForLeftBox As String = "var rightLineDataForLeftBox = [[0.135, 0.038], [0.135, 0.048]];"
            'Dim topLineDataForLeftBox As String = "var topLineDataForLeftBox = [[0.135, 0.048], [0.125, 0.048]];"
            'Dim leftLineDataForLeftBox As String = "var leftLineDataForLeftBox = [[0.125, 0.048], [0.125, 0.038]];"

            Dim bottomLineDataForLeftBox As String = "var bottomLineDataForLeftBox = [[0.113, 0.03], [0.127, 0.03]];"
            Dim rightLineDataForLeftBox As String = "var rightLineDataForLeftBox = [[0.127, 0.03], [0.127, 0.04]];"
            Dim topLineDataForLeftBox As String = "var topLineDataForLeftBox = [[0.127, 0.04], [0.113, 0.04]];"
            Dim leftLineDataForLeftBox As String = "var leftLineDataForLeftBox = [[0.113, 0.04], [0.113, 0.03]];"

            Dim bottomLineDataForRightBox As String = "var bottomLineDataForRightBox = [[0.185, 0.016], [0.205, 0.016]];"
            Dim rightLineDataForRightBox As String = "var rightLineDataForRightBox = [[0.205, 0.016], [0.205, 0.020]];"
            Dim topLineDataForRightBox As String = "var topLineDataForRightBox = [[0.205, 0.020], [0.185, 0.020]];"
            Dim leftLineDataForRightBox As String = "var leftLineDataForRightBox = [[0.185, 0.020], [0.185, 0.016]];"

            Dim flag As Boolean = False
            Dim boolCheckData As Boolean = False
            js &= vbCrLf
            For i As Integer = 0 To objEffectiveAlFeCalculation.dict.Count - 1
                boolCheckData = False
                js &= vbCrLf
                js &= "var line" & (i + 1).ToString & " = ["

                Dim arrData() As Double = objEffectiveAlFeCalculation.dict(i)

                Dim left As Object = 0
                For j As Integer = 0 To UBound(objEffectiveAlFeCalculation.dict(i))
                    If arrData(j) <= 0 Then
                        Continue For
                    End If

                    If boolCheckData = True Then
                        js &= ","
                    End If

                    js &= "["

                    If i = 0 Then
                        If j < 10 Then
                            js &= "" & objEffectiveAlFeCalculation.arrAl_Liq(j) & ", " & arrData(j) & ",'a'"
                        Else
                            js &= "" & objEffectiveAlFeCalculation.arrAl_Liq(j) & ", " & arrData(j) & ",'b'"

                        End If
                    ElseIf i = 3 Then
                        If left = 0 Then
                            left = (165 / 0.056) * objEffectiveAlFeCalculation.arrAl_Liq(j) 'To calculate the left position of the label placed in the CONODE area.
                            litLabelPosition.Text = "<script type='text/javascript'>document.getElementById('divLabel3').style.top = '50px'; document.getElementById('divLabel3').style.left = '" & left & "px';</script>"
                        End If
                        js &= "" & objEffectiveAlFeCalculation.arrAl_Liq(j) & ", " & arrData(j) & ",'c'"
                    Else
                        js &= "" & objEffectiveAlFeCalculation.arrAl_Liq(j) & ", " & arrData(j) & ",'c'"
                    End If

                    js &= "]"
                    boolCheckData = True
                Next

                js &= "];" & vbCrLf
                flag = True
            Next
            'Till here four lines are created

            boolCheckData = False
            js &= vbCrLf
            js &= "var line" & (objEffectiveAlFeCalculation.dict.Count + 1).ToString & " = ["
            For j As Integer = 0 To 25
                If boolCheckData = True Then
                    js &= ","
                End If

                js &= "["

                js &= "" & arrSlope(j, 0) & ", " & arrSlope(j, 1)

                js &= "]"
                boolCheckData = True

            Next
            js &= "];" & vbCrLf
            flag = True
            js &= vbCrLf
            js &= "var line" & (objEffectiveAlFeCalculation.dict.Count + 2).ToString & " = ["
            js &= "["
            js &= "" & txtTotalAI.Text & ", " & txtTotalFE.Text
            js &= "]"
            js &= "];" & vbCrLf
            js &= vbCrLf
            js &= "var line" & (objEffectiveAlFeCalculation.dict.Count + 3).ToString & " = ["
            js &= "["
            js &= "" & txtAIEffective.Text & ", " & txtFEEffective.Text
            js &= "]"
            js &= "];" & vbCrLf
            js &= vbCrLf
            js &= "var line" & (objEffectiveAlFeCalculation.dict.Count + 4).ToString & " = ["
            js &= "["
            js &= "" & txtTotalAI.Text & ", " & txtTotalFE.Text
            js &= "],"
            js &= "["
            js &= "" & txtTotalAI.Text & ", " & 0
            js &= "]"
            js &= "];" & vbCrLf
            js &= vbCrLf
            js &= "var line" & (objEffectiveAlFeCalculation.dict.Count + 5).ToString & " = ["
            js &= "["
            js &= "" & txtTotalAI.Text & ", " & txtTotalFE.Text
            js &= "],"
            js &= "["
            js &= "" & 0 & ", " & txtTotalFE.Text
            js &= "]"
            js &= "];" & vbCrLf
            js &= vbCrLf

            '----------------------------------------------------------------------------------------------------------------------------
            js &= bottomLineDataForLeftBox & vbCrLf & rightLineDataForLeftBox & vbCrLf & topLineDataForLeftBox & vbCrLf & leftLineDataForLeftBox & vbCrLf
            js &= bottomLineDataForRightBox & vbCrLf & rightLineDataForRightBox & vbCrLf & topLineDataForRightBox & vbCrLf & leftLineDataForRightBox & vbCrLf

            Dim boxSeries As String = "{pointLabels: { show:false }, showLine:true, lineWidth:2, color: '#0B9126', markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: true,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold; font-size:12px;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
            '----------------------------------------------------------------------------------------------------------------------------

            Dim strg As String = ""
            Dim strseries As String = ""

            If flag Then
                strg = "[line1"
                strseries = " {pointLabels:{ show:false, location:'s'}, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: true,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
                For i As Integer = 1 To objEffectiveAlFeCalculation.dict.Count + 4 '- 1 'dtGrades.Rows.Count - 1
                    strg = strg + ",line" & i + 1

                    If i = 4 Or i = 7 Or i = 8 Then
                        strseries = strseries + ", {pointLabels: { show:false }, showLine:true, lineWidth:1, linePattern: 'dashed',  markerOptions:{ size: 5 }, highlighter: {show: false,showMarker: true,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
                    ElseIf i >= 5 Then
                        strseries = strseries + ", {pointLabels: { show:false }, neighborThreshold: 0, showLine:false, showMarker:true, markerOptions: { style:'X' }}"

                    Else
                        strseries = strseries + ", {pointLabels: { show:false }, showLine:true, lineWidth:3, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: true,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
                    End If

                Next
                strseries = strseries & ", " & boxSeries & ", " & boxSeries & ", " & boxSeries & ", " & boxSeries & ", " & boxSeries & ", " & boxSeries & ", " & boxSeries & ", " & boxSeries
                strg &= ", bottomLineDataForLeftBox, rightLineDataForLeftBox, topLineDataForLeftBox, leftLineDataForLeftBox, bottomLineDataForRightBox, rightLineDataForRightBox, topLineDataForRightBox, leftLineDataForRightBox"
                strg &= "]"
            End If

            js &= "var seriesName = ['"
            Dim str As String = ""
            Dim testarr() As String = {"line1", "line2", "line3", "line4", "line5", "line6", "line7", "line8", "line9"}
            For i As Integer = 0 To objEffectiveAlFeCalculation.dict.Count - 1
                str &= testarr(i) & "', '"
            Next
            str = str.Remove(str.LastIndexOf(", '"))

            str &= "];"
            js &= str

            js &= "opts = {" & vbCrLf &
            "title: '" & ChartTitle & "'," & vbCrLf &
            "seriesDefaults: { pointLabels: { show:false }, showMarker:false, rendererOptions: {showDataLabels: true, dataLabels:  'label', diameter: 250, dataLabelPositionFactor: 0.5,sliceMargin: 3,color:'#DCDCDC' } }," &
            "series:[" & strseries & "]," & vbCrLf &
            "//seriesColors: ['#FFA500']," & vbCrLf &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            "fontSize:'8pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "min: " & min_time & ", max: " & max_time & "," & vbCrLf &
            "label: '" & XAxisColName & "'," & vbCrLf &
            "//labelRenderer: $.jqplot.CanvasAxisLabelRenderer," & vbCrLf &
            "//renderer:$.jqplot.EnhancedLegendRenderer," & vbCrLf &
            "tickOptions:{formatString:'', angle: -30}," & vbCrLf &
            "tickInterval:0.005," & vbCrLf &
            "//numberTicks: 0.0001," & vbCrLf &
            "pad:0" & vbCrLf &
            "}," & vbCrLf &
            "yaxis: { " & vbCrLf &
            "//tickOptions: { formatString: '%.3f' }," & vbCrLf &
            "min: " & y_min & "," & vbCrLf &
            "max: " & y_max & "," & vbCrLf &
            "//autoscale:true," & vbCrLf &
             "tickOptions:{formatString:'', angle: -30}," & vbCrLf &
            "tickInterval:0.005," & vbCrLf &
            "label: '" & YAxisColName & "'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "showTooltip: false," & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "animate: true," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "', " & strg & ", opts);" & vbCrLf &
            "</script>" & vbCrLf

            litLineGraph.Text = js
        Catch ex As Exception

        End Try
    End Sub

    'Protected Sub btnFindAIEffective_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnFindAIEffective.Click
    '    ' Dim objEffectiveAlFeCalculation As New EffectiveAlFeCalculation
    '    Al_tot_old = txtTotalAI.Text
    '    Fe_Tot_old = txtTotalFE.Text
    '    T_Bath_K = txtPotTemp.Text + 273.15
    '    'objEffectiveAlFeCalculation.mtdEffectivAlFeCal(Al_tot_old, T_Bath_K, objEffectiveAlFeCalculation.Al_trip, objEffectiveAlFeCalculation.Fe_trip)
    '    objEffectiveAlFeCalculation.Aleffcal(Al_tot_old, Fe_Tot_old)

    '    txtAITriplePoint.Text = Math.Round(objEffectiveAlFeCalculation.Al_trip, 4)
    '    txtFETriplePoint.Text = Math.Round(objEffectiveAlFeCalculation.Fe_trip, 4)
    '    Al_eff = Math.Round(objEffectiveAlFeCalculation.Al_liq, 4)
    '    txtAIEffective.Text = Al_eff

    '    Fe_eff = Math.Round(objEffectiveAlFeCalculation.Fe_liq, 4)
    '    txtFEEffective.Text = Fe_eff
    'End Sub

    Dim objEffectiveAlFeCalculation As New EffectiveAlFeCalculation
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                'btnTranOff_Click(sender, e)
                btnOn_Click(sender, e)
                txtTo.Text = Now.ToString("yyyy-MM-dd HH:mm:ss")
                txtFrom.Text = Now.AddMonths(-1).ToString("yyyy-MM-dd HH:mm:ss")
                btnStart_Click(sender, e)
                txt_Tran_To_Date.Text = Now.ToString("yyyy-MM-dd HH:mm:ss")
                txt_Tran_From_Date.Text = Now.AddDays(-3).ToString("yyyy-MM-dd HH:mm:ss")
            Catch ex As Exception

            End Try

        End If
    End Sub

    Dim arrSlope(25, 1) As Double
    Public Sub equation_line()
        'get slope
        Al_tot_old = txtTotalAI.Text
        Fe_Tot_old = txtTotalFE.Text
        Dim Slope_line As Decimal = (Fe_Tot_old - Fe_eff) / (Al_tot_old - Al_eff)

        Dim intercept As Decimal = Fe_Tot_old - Slope_line * Al_tot_old
        'chrtSolubilityCurve.Series.Add("Line")
        'chrtSolubilityCurve.Series("Line").ChartType = SeriesChartType.Line
        'chrtSolubilityCurve.Series("Line").Color = Color.Brown
        'chrtSolubilityCurve.Series("Line").BorderDashStyle = ChartDashStyle.Dash


        Dim y As Decimal = 0
        Dim x As Decimal = 0
        For i As Integer = 0 To 25
            y = y + i * 0.05
            x = (y - intercept) / Slope_line

            arrSlope(i, 0) = x
            arrSlope(i, 1) = y
            If x > 0.25 Then
                Exit For
            End If
            'chrtSolubilityCurve.Series("Line").Points.AddXY(x, y)
            'chrtSolubilityCurve.Series("Line").ToolTip = " X Value : #VALX  Y Value : #VALY "
        Next


    End Sub

    Protected Sub btnOff_Click(sender As Object, e As EventArgs) Handles btnOff.Click
        Try
            lblError.Text = ""
            btnOn.CssClass = "btn btn-default"
            btnOff.CssClass = "btn btn-danger"
            litTimer.Text = ""
            btnCreateGraph.Visible = True
            txtPotTemp.ReadOnly = False
            txtTotalAI.ReadOnly = False
            txtTotalFE.ReadOnly = False
            lblSamplingDateAL.Visible = False
            lblSamplingDateFE.Visible = False
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub btnOn_Click(sender As Object, e As EventArgs) Handles btnOn.Click
        Try
            lblError.Text = ""
            btnOn.CssClass = "btn btn-success"
            btnOff.CssClass = "btn btn-default"
            litTimer.Text = "<meta http-equiv='Refresh' content='1800' />"
            btnCreateGraph.Visible = False
            txtPotTemp.ReadOnly = True
            txtTotalAI.ReadOnly = True
            txtTotalFE.ReadOnly = True
            lblSamplingDateAL.Visible = True
            lblSamplingDateFE.Visible = True

            btnTranOff_Click(sender, e)

            LoadValues()
            CreateGraph()
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub btnTranOff_Click(sender As Object, e As EventArgs) Handles btnTranOff.Click
        Try
            btnTranOn.CssClass = "btn btn-default"
            btnTranOff.CssClass = "btn btn-danger"

            'btnOn code--------------------------------------------------------
            lblError.Text = ""
            btnOn.CssClass = "btn btn-success"
            btnOff.CssClass = "btn btn-default"
            litTimer.Text = "<meta http-equiv='Refresh' content='1800' />"
            btnCreateGraph.Visible = False
            txtPotTemp.ReadOnly = True
            txtTotalAI.ReadOnly = True
            txtTotalFE.ReadOnly = True
            lblSamplingDateAL.Visible = True
            lblSamplingDateFE.Visible = True
            '------------------------------------------------------------------

            btn_Tran_Show.Visible = False
            txt_Tran_From_Date.Visible = False
            txt_Tran_To_Date.Visible = False

            LoadValues()
            CreateGraph()
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub btnTranOn_Click(sender As Object, e As EventArgs) Handles btnTranOn.Click
        Try
            btnTranOn.CssClass = "btn btn-success"
            btnTranOff.CssClass = "btn btn-default"

            btnOff_Click(sender, e)
            btnCreateGraph.Visible = False
            txtPotTemp.ReadOnly = True
            txtTotalAI.ReadOnly = True
            txtTotalFE.ReadOnly = True
            lblSamplingDateAL.Visible = True
            lblSamplingDateFE.Visible = True

            txt_Tran_From_Date.Visible = True
            txt_Tran_To_Date.Visible = True
            btn_Tran_Show.Visible = True
            TransitionGraph(txt_Tran_From_Date.Text.Trim, txt_Tran_To_Date.Text.Trim)
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub btnStart_Click(sender As Object, e As EventArgs) Handles btnStart.Click
        Try
            If txtFrom.Text.Trim <> "" And txtTo.Text.Trim <> "" Then
                If objController.IsValidDateRange(txtFrom, txtTo) Then
                    EffectiveAlAndFeChart()
                Else
                    UserMsgBoxError("Date range incorrect.")
                End If

            End If
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub btn_Tran_Show_Click(sender As Object, e As EventArgs) Handles btn_Tran_Show.Click
        Try
            If objController.IsValidDateRange(txtFrom, txtTo) Then
                TransitionGraph(txt_Tran_From_Date.Text.Trim, txt_Tran_To_Date.Text.Trim)
            Else
                UserMsgBoxError("Date range incorrect.")
            End If
        Catch ex As Exception

        End Try


    End Sub
End Class
