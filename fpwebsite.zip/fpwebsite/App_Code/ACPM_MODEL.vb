﻿Imports Microsoft.VisualBasic
Imports System.Data
Imports Microsoft.SolverFoundation.Common
Imports Microsoft.SolverFoundation.Services
Imports Microsoft.SolverFoundation.Solvers

Public Class ACPM_MODEL
    Dim startdatetime, endDatetime, Ramp_start_Time As DateTime   ''Ramp_start_time ZS-->GA
    Dim DS(100, 14) As ArrayList
    Dim Total_dross As Double '' If GA-->ZS sum of all dross during GA will be Totakl dross for starting ZS
    Dim Qstrip As Double
    Dim Mass_Ingot, Mass_Coil, Tmelt, Tamb, Cp_Zn_l, T_Bath_C, T_bath_K, sum_t, duration, PI, T_strip_K, T_strip_C, SET_C, SET_K, thickness, width, StripTemp, ZinPotTemp As Decimal
    Dim a1, b1, c1, Lmelt, Qloss_avg, SteelDensity As Double
    Dim StripWidth, SHG, CGG, Al5per, StripThickness, StripLength, TopCoating, BottomCoating, CoatVal, LineSpeed, line_speed_arr() As Double
    Dim Al_trip, Fe_disl, Fe_solu, fe_disl_percoil, Fe_trip, Fe1, Fe2, Fe_tot, fe_liq, Al_liq, Fe_eff, Zn_out, Tot_SurfaceArea, Fe_percoil, Fe2Al5_percoil, T_inhi, Fe_inhi, fe_disl_total, Al_inhi, Al_tot_old, Al_tot_new, Al_dross, Fe_dross, Pot_lvl_old, Fe_Tot_old, fe_tot_new As Double
    Dim pot_lvl_new, Top_dross, Bottom_dross, J, IntA, IntB, Delta_G, Dross_val, Activation_Energy, Fe_diffusivity, Viscocity, dissolution_rate, linespeed_factor, coil_duration() As Double
    Dim J_calc As Double
    Dim Pot_Flag, prod_flag, grade As String
    Dim tc, bc, coat As Double
    Dim cgg_al_percent As Double = 0.5
    Dim objEffectiveAlFeCalculation As New EffectiveAlFeCalculation
    Public Property val As String
    Public Al_depletion(), zn_depletion(), zn_depletion_rate(), Al_depletion_rate(), pred_dura_blck_1(,), pred_dura_blck_2(,), SHG_pred() As Double   'in kg
    Public pred_time_addition1, pred_time_addition2, nxt_pred_time_addition1, nxt_pred_time_addition2, melting_1_ton_dura, timer As Double
    Dim cradle_status1, cradle_status2 As String
    Public Sub ThermalModel(ByVal dt As DataTable, ByVal r As Integer, ByVal gdvDetails As GridView, Optional ByRef avgDt As Double = 0.0)
        Dim coil_len As Double
        Qloss_avg = 185 ''KW
        SteelDensity = 7850
        Tmelt = 420 + 273
        Tamb = 40 + 273
        Lmelt = 111884.4
        Cp_Zn_l = 479.5
        Mass_Ingot = 0
        Qstrip = 0

        duration = dt.Rows(r)(6)
        coil_len = dt.Rows(r)(9)
        thickness = dt.Rows(r)(4)
        width = dt.Rows(r)(5)
        Try
            StripTemp = dt.Rows(r)(7)
        Catch ex As Exception
            StripTemp = 0.0
        End Try
        Try
            ZinPotTemp = dt.Rows(r)(8)
        Catch ex As Exception
            ZinPotTemp = 0.0
        End Try

        Mass_Coil = calc_CoilMass(thickness, width, coil_len, SteelDensity)
        Try
            Mass_Ingot = CDec(IIf(CType(gdvDetails.Rows(r).FindControl("txtSHG"), TextBox).Text = "", 0, CType(gdvDetails.Rows(r).FindControl("txtSHG"), TextBox).Text)) + CDec(IIf(CType(gdvDetails.Rows(r).FindControl("txtCGG"), TextBox).Text = "", 0, CType(gdvDetails.Rows(r).FindControl("txtCGG"), TextBox).Text)) + CDec(IIf(CType(gdvDetails.Rows(r).FindControl("txtFivePer"), TextBox).Text = "", 0, CType(gdvDetails.Rows(r).FindControl("txtFivePer"), TextBox).Text))
        Catch ex As Exception
            Mass_Ingot = 0
        End Try


        T_Bath_C = ZinPotTemp


        Dim Qind As Double
        '' Qind = calc_Qind(sum_t, PI)
        Qind = calc_Qind(gdvDetails.Rows(r).Cells(16).Text) ''Changed by mamta rani discussed by sibasis as on 26-Aug2019

        ''Qind = 62848000.0063777 comented by mamta on 19th Aug19
        Qstrip = -(Qind - (calc_Qloss(Qloss_avg, duration) + calc_Qingot(Mass_Ingot, Tmelt, Tamb, Cp_Zn_l, T_Bath_C, Lmelt)))
        ''  MsgBox(Qstrip)
        Dim C As Double = calc_Constant(Mass_Coil, T_Bath_C, Qstrip)
        Try
            T_strip_C = NewtonsMethod(T_Bath_C, C, 0.001, 100) - 273
            ''  MsgBox(T_strip_C)
            gdvDetails.Rows(r).Cells(13).Text = Math.Round(T_strip_C, 0)
            Dim DeltaT As Double = T_strip_C - StripTemp
            gdvDetails.Rows(r).Cells(14).Text = Math.Round(DeltaT, 0)
            avgDt += Math.Round(DeltaT, 0)
        Catch ex As Exception

        End Try

    End Sub


    Public Function calc_Constant(ByVal CoilMass As Decimal, ByVal BathTemp As Decimal, ByVal Qstrip As Double) As Double
        Return ((Qstrip / CoilMass) + ((504.2 * (BathTemp + 273)) + ((-0.06545) * Math.Pow((BathTemp + 273), 2)) - ((-0.000005179) / (BathTemp + 273)) + ((0.00044797 / 3) * Math.Pow((BathTemp + 273), 3))))
    End Function
    Public Function NewtonsMethod(x0 As Double, c As Double, e As Double, n As Integer) As Double
        Dim i As Integer
        Dim err As Double
        Dim xn As Double
        Dim xn1 As Double
        i = 0
        err = 9999
        xn = x0
        While (err > e) And (i < n)
            xn1 = xn - Fx(xn, c) / dFx(xn)
            err = Math.Abs(xn1 - xn)
            xn = xn1
        End While
        NewtonsMethod = xn
    End Function
    Public Function Fx(x As Double, c As Double) As Double
        Fx = 504.2 * x + (-0.06545) * x * x - (-0.000005179) / x + (0.000149323) * x * x * x - c
    End Function
    Public Function dFx(x As Double) As Double
        dFx = 504.2 + (2 * -0.06545) * x + (-0.000005179) / (x * x) + (3 * 0.000149323) * x * x
    End Function

    Public Function calc_Qingot(ByVal Mass_Ingot As Double, ByVal Tmelt As Double, ByVal Tamb As Decimal, ByVal Cp_Zn_l As Decimal, ByVal Tbath As Decimal, ByVal Lmelt As Decimal) As Double
        a1 = 316.85
        b1 = 0.19116
        c1 = 1.272 * 10 ^ -6

        Dim Q1, Q2, Q3, Q As Double

        Q1 = Mass_Ingot * ((a1 * Tmelt + b1 * 0.5 * Math.Pow(Tmelt, 2) - c1 / Tmelt) - (a1 * Tamb + b1 * 0.5 * Math.Pow(Tamb, 2) - c1 / Tamb))
        Q2 = Mass_Ingot * Lmelt
        Q3 = Mass_Ingot * Cp_Zn_l * (Tbath - Tmelt)
        Q = Q1 + Q2 + Q3
        Return Q
    End Function

    Public Function calc_Qloss(ByVal Qloss_avg As Double, ByVal duration As Decimal) As Double
        Return Qloss_avg * duration * 60 * 1000
    End Function

    Public Function calc_CoilMass(ByVal Thickness As Double, ByVal Width As Double, ByVal length As Double, ByVal SteelDensity As Double) As Double ''thickness in mm,width in mm,length in m
        Return Thickness * Width * length * SteelDensity / 1000000
    End Function

    'Public Function TempStrip()
    '    Dim Funct As New Func(Of Double, Double)(Function(X As Double) (504 * T_strip_K + (-0.06545) * T_strip_K * T_strip_K - (-0.000005179) / T_strip_K + (0.000149323) * T_strip_K * T_strip_K * T_strip_K - calc_Constant(Mass_Coil, Tbath_C)))
    '    Dim Deriv As New Func(Of Double, Double)(Function(X As Double) (504.2 + (2 * -0.06545) * T_strip_K + (-0.000005179) / (Math.Pow(T_strip_K, 2) + (3 * 0.000149) * T_strip_K * T_strip_K)))

    '    Return T_strip_K = NewtonSolver(Funct, Deriv, Tbath_C, 0.001)
    'End Function

    '.........................Function for Al-Fe model.......................
    Public Function calc_Qind(ByVal Pi As Double) As Double ''Added on 19th Aug'19 by Mamta  --calc_Qind(ByVal Sum_t As Double, ByVal Pi As Double) As Double 
        Return Pi * 1000   ''Return Sum_t * Pi * 1000
    End Function
    Public Sub main(ByVal dt As DataTable, ByVal dgv As GridView, ByVal dgv_predict As GridView, ByVal potlvl As Double, ByVal arrAlNew() As Double, ByVal al_old As Decimal, ByVal fe_old As Decimal, Optional ByVal rampMode As Integer = 1, Optional ByVal targetAl As String = "")

        Dim r, count_coil As Integer
        Dim al_tot_eff1, fe_tot_eff1, al_eff_act_temp As Double
        count_coil = 0
        linespeed_factor = 0

        Dim gvCount As Integer = dgv.Rows.Count
        Dim dtCount As Integer = dt.Rows.Count
        Dim diff As Integer = gvCount - dtCount


        Dim newrow As DataRow
        For i As Integer = diff - 1 To 0 Step -1

            ',prm_cd_prod,,prm_ts_end as ,Prm_sec1_coil as ,prm_sec2_coil as width,Prm_dr_work as duration,= &
            '" ,,PRM_TAS_PRC_SCSPD as ,,,PRM_TEST_VAL_FE,PRM_TEST_VAL_AL,PRM_CD_SURF_ROUGH,PRM_CD_GRADE
            newrow = dt.NewRow
            newrow("starttime") = dgv.Rows(i).Cells(14).Text
            newrow("width") = dgv.Rows(i).Cells(1).Text
            newrow("thickness") = dgv.Rows(i).Cells(2).Text
            newrow("prm_ln_coil") = dgv.Rows(i).Cells(3).Text
            newrow("stripEntryTemp") = dgv.Rows(i).Cells(4).Text
            newrow("prm_zinc_pot_tmp") = dgv.Rows(i).Cells(5).Text
            newrow("PRM_LINE_SPEED") = dgv.Rows(i).Cells(6).Text
            newrow("prm_cd_coat") = dgv.Rows(i).Cells(7).Text
            newrow("PRM_TTC_AVG") = dgv.Rows(i).Cells(8).Text
            newrow("PRM_BTC_AVG") = dgv.Rows(i).Cells(9).Text
            newrow("prm_cd_prod") = dgv.Rows(i).Cells(13).Text
            newrow("PRM_id_coil") = dgv.Rows(i).Cells(0).Text
            newrow("PRM_TEST_VAL_AL") = dgv.Rows(i).Cells(16).Text
            newrow("PRM_TEST_VAL_FE") = dgv.Rows(i).Cells(18).Text
            newrow("PRM_CD_SURF_ROUGH") = IIf(dgv.Rows(i).Cells(13).Text = "C10", "Z", "A")
            newrow("grade") = dgv.Rows(i).Cells(28).Text
            'newrow("") = dgv.Rows(i).Cells(0).Text

            dt.Rows.InsertAt(newrow, 0)
        Next

        'newrow = dt.NewRow
        'newrow("starttime") = DateTime.Now()
        'newrow("width") =
        'newrow("thickness") =
        'newrow("prm_ln_coil") =
        'newrow("stripEntryTemp") =
        'newrow("prm_zinc_pot_tmp") =
        'newrow("PRM_LINE_SPEED") =
        'newrow("prm_cd_coat") =
        'newrow("PRM_TTC_AVG") =
        'newrow("PRM_BTC_AVG") =
        'newrow("prm_cd_prod") =
        'newrow("PRM_id_coil") = "Procesing..."
        'newrow("PRM_TEST_VAL_AL") = dgv.Rows(0).Cells(16).Text
        'newrow("PRM_TEST_VAL_FE") = dgv.Rows(0).Cells(18).Text
        'newrow("PRM_CD_SURF_ROUGH") = IIf(dgv.Rows(i).Cells(13).Text = "C10", "Z", "A")
        'newrow("grade") = dgv.Rows(i).Cells(28).Text

        dt.AcceptChanges()

        ReDim arrAlNew(dt.Rows.Count - 1)
        For r = dt.Rows.Count - 1 To 0 Step -1

            If r = dt.Rows.Count - 1 Then

                Pot_lvl_old = potlvl
            Else
                Pot_lvl_old = pot_lvl_new
            End If


            SHG = IIf(dgv.Rows(r).Cells(10).Text = "&nbsp;", 0, dgv.Rows(r).Cells(10).Text)
            Al5per = IIf(dgv.Rows(r).Cells(11).Text = "&nbsp;", 0, dgv.Rows(r).Cells(11).Text)
            CGG = IIf(dgv.Rows(r).Cells(12).Text = "&nbsp;", 0, dgv.Rows(r).Cells(12).Text)

            al_tot_eff1 = IIf(dgv.Rows(r).Cells(16).Text = "&nbsp;", 0, dgv.Rows(r).Cells(16).Text)
            fe_tot_eff1 = IIf(dgv.Rows(r).Cells(18).Text = "&nbsp;", 0, dgv.Rows(r).Cells(18).Text)
            al_eff_act_temp = 0

            If IsDBNull(dt(r)("grade")) Then
                grade = ""
            Else
                grade = dt(r)("grade")
            End If


            getData(dt, r, arrAlNew, al_old)
            'Validatedata()

            objEffectiveAlFeCalculation.Main(T_Bath_C, T_Bath_C + 273.15)
            objEffectiveAlFeCalculation.Aleffcal(al_old, fe_old)
            Al_liq = objEffectiveAlFeCalculation.Al_liq
            fe_liq = objEffectiveAlFeCalculation.Fe_liq
            ' Al_liq = Math.Round(objEffectiveAlFeCalculation.Al_liq, 4)

            calc_Zn_Drag(coat, tc, bc, StripWidth, StripLength)
            calc_inh(fe_old)
            calc_dross_new()
            calc_pot_lvl_new("coilwise")
            calc_al_fe_left(fe_old)
            calc_al_tot_new(Al_liq)
            cal_fe_tot_new(fe_old)

            ''Finding the speed factor for the last 3 coils and using this to predict the speed factor of future coils
            '--------------------------------------------------------------------------------

            If r < 3 Then
                'If grade <> "" Then
                '    line_speed_predict(grade, StripWidth, StripThickness)
                'Else
                '    LineSpeed = 100
                'End If
                line_speed_predict(grade, StripWidth, StripThickness)
                linespeed_factor = linespeed_factor + (dt(r)("PRM_LINE_SPEED") / LineSpeed)
                count_coil = count_coil + 1
                If r = 0 Then
                    linespeed_factor = linespeed_factor / count_coil
                End If
            End If

            '-------------------------------------------------------------------------------


            arrAlNew(r) = Al_tot_new
            If r >= 0 Then
                dgv.Rows(r).Cells(17).Text = Math.Round(al_old, 4)
                dgv.Rows(r).Cells(15).Text = Math.Round(pot_lvl_new, 1)
                dgv.Rows(r).Cells(19).Text = Math.Round(fe_old, 4)
                'added on 06-dec-2018
                dgv.Rows(r).Cells(21).Text = Math.Round(Zn_out * 1000, 0)
                dgv.Rows(r).Cells(22).Text = Math.Round(Al_inhi, 2)
                dgv.Rows(r).Cells(23).Text = Math.Round(Fe_dross, 2)
                dgv.Rows(r).Cells(24).Text = Math.Round(Al_dross, 2)
                dgv.Rows(r).Cells(25).Text = Math.Round(Al_liq, 3)
                dgv.Rows(r).Cells(26).Text = Math.Round(Zn_out * 1000 * Al_tot_old / 100, 2)
                If dgv.Rows(r).Cells(16).Text = "&nbsp;" Then
                    dgv.Rows(r).Cells(27).Text = 0
                Else
                    objEffectiveAlFeCalculation.Aleffcal(al_tot_eff1, fe_tot_eff1)
                    al_eff_act_temp = objEffectiveAlFeCalculation.Al_liq
                    dgv.Rows(r).Cells(27).Text = al_eff_act_temp
                End If

            End If
            al_old = Al_tot_new
            fe_old = fe_tot_new
        Next


        ''-----------------2018-12-20----------''
        ''Charging schedule
        ''------------------

        Dim al_target As Double
        Al_tot_old = Al_tot_new
        Pot_lvl_old = pot_lvl_new
        T_Bath_C = 464    'input bath temperature for furture additions
        T_bath_K = T_Bath_C + 273
        SET_C = 470
        SET_K = SET_C + 273



        '-------------loop for calculation future al and zn depletion------------
        '---------------------------------------------------------------------
        ReDim Al_depletion(dgv_predict.Rows.Count - 1)
        ReDim zn_depletion(dgv_predict.Rows.Count - 1)
        ReDim Al_depletion_rate(dgv_predict.Rows.Count - 1)
        ReDim zn_depletion_rate(dgv_predict.Rows.Count - 1)
        ReDim coil_duration(dgv_predict.Rows.Count - 1)
        ReDim line_speed_arr(dgv_predict.Rows.Count - 1)

        SHG = 0
        CGG = 0
        Al5per = 0
        objEffectiveAlFeCalculation.Main(T_Bath_C, T_Bath_C + 273.15)
        objEffectiveAlFeCalculation.Aleffcal(al_old, fe_old)
        Al_liq = objEffectiveAlFeCalculation.Al_liq
        fe_liq = objEffectiveAlFeCalculation.Fe_liq
        For sch As Integer = 0 To dgv_predict.Rows.Count - 1
            Try

                Dim lenCoat As String = dgv_predict.Rows(sch).Cells(6).Text 'dgv_predict.Rows(sch).Cells("Coat_dgv").Value
                If lenCoat.Length = 3 Then
                    CoatVal = lenCoat.ToString.Substring(1, 2) / 2
                ElseIf lenCoat.Length = 4 Then
                    CoatVal = lenCoat.ToString.Substring(1, 3) / 2
                End If

                tc = dgv_predict.Rows(sch).Cells(20).Text    'in grams/sq meter
                bc = dgv_predict.Rows(sch).Cells(20).Text   'in grams/sq meter

                If (2 * CoatVal) <= 60 Then
                    tc = CoatVal + 6    'in grams/sq meter
                    bc = CoatVal + 6   'in grams/sq meter
                End If
                If (2 * CoatVal) > 60 And (2 * CoatVal) <= 80 Then
                    tc = CoatVal + 4    'in grams/sq meter
                    bc = CoatVal + 4   'in grams/sq meter
                End If
                If (2 * CoatVal) > 80 And (2 * CoatVal) <= 90 Then
                    tc = CoatVal + 8    'in grams/sq meter
                    bc = CoatVal + 8   'in grams/sq meter
                End If
                If (2 * CoatVal) > 90 And (2 * CoatVal) <= 100 Then
                    tc = CoatVal + 2    'in grams/sq meter
                    bc = CoatVal + 2   'in grams/sq meter
                End If
                If (2 * CoatVal) > 100 And (2 * CoatVal) <= 120 Then
                    tc = CoatVal + 3    'in grams/sq meter
                    bc = CoatVal + 3   'in grams/sq meter
                End If
                If (2 * CoatVal) > 120 And (2 * CoatVal) <= 140 Then
                    tc = CoatVal + 4    'in grams/sq meter
                    bc = CoatVal + 4   'in grams/sq meter
                End If
                If (2 * CoatVal) > 140 And (2 * CoatVal) <= 150 Then
                    tc = CoatVal + 7    'in grams/sq meter
                    bc = CoatVal + 7   'in grams/sq meter
                End If
                If (2 * CoatVal) > 150 And (2 * CoatVal) <= 180 Then
                    tc = CoatVal + 6    'in grams/sq meter
                    bc = CoatVal + 6   'in grams/sq meter
                End If
                If (2 * CoatVal) > 180 And (2 * CoatVal) <= 250 Then
                    tc = CoatVal + 6    'in grams/sq meter
                    bc = CoatVal + 6   'in grams/sq meter
                End If
                If (2 * CoatVal) > 250 And (2 * CoatVal) <= 275 Then
                    tc = CoatVal + 8    'in grams/sq meter
                    bc = CoatVal + 8   'in grams/sq meter
                End If


                StripThickness = dgv_predict.Rows(sch).Cells(4).Text / 1000     ' dgv_predict.Rows(sch).Cells("Thickness_dgv").Value / 1000 ''mm to m
                StripWidth = dgv_predict.Rows(sch).Cells(3).Text / 1000            'dgv_predict.Rows(sch).Cells("Width_dgv").Value / 1000  'mm to m
                StripLength = dgv_predict.Rows(sch).Cells(5).Text                  'dgv_predict.Rows(sch).Cells("Length_dgv").Value
                prod_flag = dgv_predict.Rows(sch).Cells(7).Text                      'dgv_predict.Rows(sch).Cells("prod_dgv").Value

                If prod_flag = "C10" Then
                    prod_flag = "Z"
                End If
                If prod_flag = "C03" Then
                    prod_flag = "A"
                End If
                line_speed_predict(grade, StripWidth, StripThickness)
                coil_duration(sch) = Math.Floor(StripLength / (linespeed_factor * LineSpeed))
                line_speed_arr(sch) = linespeed_factor * LineSpeed
                calc_Zn_Drag(CoatVal, tc, bc, StripWidth, StripLength)
                zn_depletion(sch) = Zn_out * 1000                        'converting ton to kg
                cal_al_loss(sch)
                zn_depletion_rate(sch) = zn_depletion(sch) / coil_duration(sch)
                Al_depletion_rate(sch) = Al_depletion(sch) / coil_duration(sch)
                dgv_predict.Rows(sch).Cells(21).Text = Math.Round(Al_depletion_rate(sch), 3)
                dgv_predict.Rows(sch).Cells(22).Text = Math.Round(zn_depletion_rate(sch), 2)
            Catch ex As Exception

            End Try
        Next


        '--------------------------loop for ingot addition starts-------------
        Dim init_chem(), aim_chem(), recovery() As Decimal
        Dim aim_pot_level As Double = 200 * 1000
        'Dim al_initial As Double
        Dim al_initial, GA_Al, GI_Al, RD_Al, RU_Al As Double
        GA_Al = 0.125
        GI_Al = 0.185
        RD_Al = GA_Al
        RU_Al = GI_Al

        If targetAl <> "" Then
            If rampMode = 1 Then 'normal
                If CDbl(targetAl) < 0.15 Then
                    GA_Al = CDbl(targetAl)
                End If
                If CDbl(targetAl) > 0.15 Then
                    GI_Al = CDbl(targetAl)
                End If
            End If

            If rampMode = 0 Then 'rampup
                RU_Al = CDbl(targetAl)
            End If
            If rampMode = 2 Then 'rampdown
                RD_Al = CDbl(targetAl)
            End If
        End If

        If prod_flag = "Z" Then
            al_target = GI_Al
        End If
        If prod_flag = "A" Then
            al_target = GA_Al
        End If

        '-----------ramp mode
        If rampMode = 0 Then
            al_target = IIf(targetAl = "", RU_Al, CDbl(targetAl))
        ElseIf rampMode = 2 Then
            al_target = IIf(targetAl = "", RD_Al, CDbl(targetAl))
        End If

        '-------

        al_initial = Al_liq
        'al_initial = 0.125
        'al_old = 0.133
        'Al_tot_old = 0.133
        'fe_old = 0.04
        If Pot_lvl_old < 198 Then
            Pot_lvl_old = 200
        Else
            Pot_lvl_old = dgv.Rows(0).Cells(15).Text
        End If
        init_chem = {al_initial, Pot_lvl_old * 1000}    '% Al and  bath weight  (kg)
        aim_chem = {al_target, aim_pot_level}
        recovery = {100, 100}
        ReDim pred_dura_blck_1(2 * 24 * 60, 3)           '0 - duration, 1- SHG   2-CGG     3- 5AL..... for the next 48 hours the prediction is calculated
        ReDim pred_dura_blck_2(2 * 24 * 60, 3)

        pred_time_addition1 = 0
        pred_time_addition2 = 0
        nxt_pred_time_addition1 = 0
        nxt_pred_time_addition2 = 0
        Dim CGG_coil, SHG_coil, Al5per_coil As Integer
        Dim cummulative_duration As Integer
        'loop for converting into minute wise data from coil wise data
        '-------------------------------------------------------------
        cummulative_duration = 0
        cradle_status2 = "FREE"
        cradle_status1 = "FREE"
        For n As Integer = 0 To dgv_predict.Rows.Count - 1
            Try
                ' the unit for line speed is meter/min. the distance processed in half a minute equals half the line speed.
                StripLength = line_speed_arr(n) / 2
                StripThickness = dgv_predict.Rows(n).Cells(4).Text / 1000                     'dgv_predict.Rows(sch).Cells("Thickness_dgv").Value / 1000 ''mm to m
                StripWidth = Math.Round(dgv_predict.Rows(n).Cells(3).Text / 1000, 3)          'dgv_predict.Rows(sch).Cells("Width_dgv").Value / 1000  'mm to m
                prod_flag = dgv_predict.Rows(n).Cells(7).Text                                 'dgv_predict.Rows(sch).Cells("prod_dgv").Value

				'commented on 21-09-2023----since wrong values of C10 and C03 are coming in between	
                If prod_flag = "C10" Then
                    prod_flag = "Z"
                 '   al_target = GI_Al
                End If
                If prod_flag = "C03" Then
                    prod_flag = "A"
                '    al_target = GA_Al
                End If
                '-----------ramp mode
                If rampMode = 0 Then
                    al_target = IIf(targetAl = "", RU_Al, CDbl(targetAl))
                ElseIf rampMode = 2 Then
                    al_target = IIf(targetAl = "", RD_Al, CDbl(targetAl))
                End If

                '-------
                LineSpeed = line_speed_arr(n) 'line_speed_predict(grade, StripWidth, StripThickness)
                CGG_coil = 0
                SHG_coil = 0
                Al5per_coil = 0
                For x As Double = 1 To coil_duration(n) Step 0.5

                    CGG = 0
                    SHG = 0
                    Al5per = 0
                    'the array is made of 30 sec interval. but the values in the array are stored at minute interval. 
                    'the ingots can be added one(ton) by one(ton). in case there is a requirement of 2 ton addition, 
                    'first one ton addition is done, then calculated for next ton done in next 30 sec.
                    If nxt_pred_time_addition1 < (x + cummulative_duration) And Math.IEEERemainder(x, 1) = 0 Then
                        add_ingot_predict_gradient(init_chem, aim_chem, zn_depletion_rate, Al_depletion_rate, n, 1)
                        CGG_coil = CGG_coil + CGG
                        SHG_coil = SHG_coil + SHG
                        Al5per_coil = Al5per_coil + Al5per
                        If CGG + SHG + Al5per > 0 Then
                            pred_dura_blck_1(x + cummulative_duration, 1) = pred_dura_blck_1(x + cummulative_duration, 1) + SHG
                            pred_dura_blck_1(x + cummulative_duration, 2) = pred_dura_blck_1(x + cummulative_duration, 2) + CGG
                            pred_dura_blck_1(x + cummulative_duration, 3) = pred_dura_blck_1(x + cummulative_duration, 3) + Al5per
                        ElseIf CGG + SHG + Al5per = 0 Then
                            cradle_status1 = "FREE"
                        End If

                    End If

                    If nxt_pred_time_addition2 < (x + cummulative_duration) And Math.IEEERemainder(x, 1) <> 0 Then
                        add_ingot_predict_gradient(init_chem, aim_chem, zn_depletion_rate, Al_depletion_rate, n, 2)
                        CGG_coil = CGG_coil + CGG
                        SHG_coil = SHG_coil + SHG
                        Al5per_coil = Al5per_coil + Al5per
                        If CGG + SHG + Al5per > 0 Then
                            pred_dura_blck_1(x + cummulative_duration, 1) = pred_dura_blck_1(x + cummulative_duration, 1) + SHG
                            pred_dura_blck_1(x + cummulative_duration, 2) = pred_dura_blck_1(x + cummulative_duration, 2) + CGG
                            pred_dura_blck_1(x + cummulative_duration, 3) = pred_dura_blck_1(x + cummulative_duration, 3) + Al5per
                        ElseIf CGG + SHG + Al5per = 0 Then
                            cradle_status2 = "FREE"
                        End If
                    End If
                    Dim lenCoat As String = dgv_predict.Rows(n).Cells(6).Text 'dgv_predict.Rows(sch).Cells("Coat_dgv").Value
                    If lenCoat.Length = 3 Then
                        CoatVal = lenCoat.ToString.Substring(1, 2) / 2
                    ElseIf lenCoat.Length = 4 Then
                        CoatVal = lenCoat.ToString.Substring(1, 3) / 2
                    End If

                    If (2 * CoatVal) <= 60 Then
                        tc = CoatVal + 6    'in grams/sq meter
                        bc = CoatVal + 6   ' in grams/sq meter
                    End If
                    If (2 * CoatVal) > 60 And (2 * CoatVal) <= 80 Then
                        tc = CoatVal + 4    'in grams/sq meter
                        bc = CoatVal + 4   'in grams/sq meter
                    End If
                    If (2 * CoatVal) > 80 And (2 * CoatVal) <= 90 Then
                        tc = CoatVal + 8    'in grams/sq meter
                        bc = CoatVal + 8   'in grams/sq meter
                    End If
                    If (2 * CoatVal) > 90 And (2 * CoatVal) <= 100 Then
                        tc = CoatVal + 2    'in grams/sq meter
                        bc = CoatVal + 2   'in grams/sq meter
                    End If
                    If (2 * CoatVal) > 100 And (2 * CoatVal) <= 120 Then
                        tc = CoatVal + 3    'in grams/sq meter
                        bc = CoatVal + 3   'in grams/sq meter
                    End If
                    If (2 * CoatVal) > 120 And (2 * CoatVal) <= 140 Then
                        tc = CoatVal + 4    'in grams/sq meter
                        bc = CoatVal + 4   'in grams/sq meter
                    End If
                    If (2 * CoatVal) > 140 And (2 * CoatVal) <= 150 Then
                        tc = CoatVal + 7    'in grams/sq meter
                        bc = CoatVal + 7   'in grams/sq meter
                    End If
                    If (2 * CoatVal) > 150 And (2 * CoatVal) <= 180 Then
                        tc = CoatVal + 6    'in grams/sq meter
                        bc = CoatVal + 6   'in grams/sq meter
                    End If
                    If (2 * CoatVal) > 180 And (2 * CoatVal) <= 250 Then
                        tc = CoatVal + 6    'in grams/sq meter
                        bc = CoatVal + 6   'in grams/sq meter
                    End If
                    If (2 * CoatVal) > 250 And (2 * CoatVal) <= 275 Then
                        tc = CoatVal + 8    'in grams/sq meter
                        bc = CoatVal + 8   'in grams/sq meter
                    End If

                    objEffectiveAlFeCalculation.Main(T_Bath_C, T_Bath_C + 273.15)
                    objEffectiveAlFeCalculation.Aleffcal(al_old, fe_old)
                    Al_liq = objEffectiveAlFeCalculation.Al_liq
                    fe_liq = objEffectiveAlFeCalculation.Fe_liq

                    calc_Zn_Drag(CoatVal, tc, bc, StripWidth, StripLength)
                    calc_inh(fe_old)
                    calc_dross_new()
                    calc_pot_lvl_new("pred")
                    calc_al_fe_left(fe_old)
                    calc_al_tot_new(Al_liq)
                    cal_fe_tot_new(fe_old)


                    Pot_lvl_old = pot_lvl_new
                    fe_old = fe_tot_new
                    al_old = Al_tot_new
                    Al_tot_old = Al_tot_new
                    objEffectiveAlFeCalculation.Main(T_Bath_C, T_Bath_C + 273.15)
                    objEffectiveAlFeCalculation.Aleffcal(Al_tot_new, fe_tot_new)
                    Al_liq = objEffectiveAlFeCalculation.Al_liq
                    fe_liq = objEffectiveAlFeCalculation.Fe_liq

                    init_chem = {Al_liq, Pot_lvl_old * 1000}    '% Al and  bath weight  (kg)
                    aim_chem = {al_target, aim_pot_level}

                Next x
            Catch ex As Exception

            End Try  'Solver_bath_2_mat(init_chem, aim_chem, recovery)
            dgv_predict.Rows(n).Cells(14).Text = SHG_coil
            dgv_predict.Rows(n).Cells(16).Text = CGG_coil
            dgv_predict.Rows(n).Cells(15).Text = Al5per_coil
            dgv_predict.Rows(n).Cells(10).Text = Math.Round(pot_lvl_new, 1)
            dgv_predict.Rows(n).Cells(11).Text = Math.Round(Al_liq, 3)
            dgv_predict.Rows(n).Cells(12).Text = Math.Round(fe_liq, 3)
            dgv_predict.Rows(n).Cells(17).Text = Math.Round(line_speed_arr(n), 0)
            dgv_predict.Rows(n).Cells(18).Text = Math.Round(Al_tot_new, 3)
            dgv_predict.Rows(n).Cells(19).Text = Math.Round(fe_tot_new, 3)
            dgv_predict.Rows(n).Cells(8).Text = Math.Round(coil_duration(n), 0)
            cummulative_duration = cummulative_duration + coil_duration(n)
        Next

    End Sub
    'Commented on 6-11-2019
    'Public Sub main(ByVal dt As DataTable, ByVal dgv As GridView, ByVal dgv_predict As GridView, ByVal potlvl As Double, ByVal arrAlNew As Array, ByVal al_old As Decimal, ByVal fe_old As Decimal)

    '    Dim r, count_coil As Integer
    '    Dim al_tot_eff1, fe_tot_eff1, al_eff_act_temp As Double
    '    count_coil = 0
    '    linespeed_factor = 0
    '    For r = dt.Rows.Count - 1 To 0 Step -1
    '        If r = dt.Rows.Count - 1 Then
    '            Pot_lvl_old = potlvl
    '        Else
    '            Pot_lvl_old = pot_lvl_new
    '        End If


    '        SHG = IIf(dgv.Rows(r).Cells(10).Text = "&nbsp;", 0, dgv.Rows(r).Cells(10).Text)
    '        Al5per = IIf(dgv.Rows(r).Cells(11).Text = "&nbsp;", 0, dgv.Rows(r).Cells(11).Text)
    '        CGG = IIf(dgv.Rows(r).Cells(12).Text = "&nbsp;", 0, dgv.Rows(r).Cells(12).Text)

    '        al_tot_eff1 = IIf(dgv.Rows(r).Cells(16).Text = "&nbsp;", 0, dgv.Rows(r).Cells(16).Text)
    '        fe_tot_eff1 = IIf(dgv.Rows(r).Cells(18).Text = "&nbsp;", 0, dgv.Rows(r).Cells(18).Text)
    '        al_eff_act_temp = 0

    '        grade = dt(r)("grade")
    '        getData(dt, r, arrAlNew, al_old)
    '        'Validatedata()

    '        objEffectiveAlFeCalculation.Main(T_Bath_C, T_Bath_C + 273.15)
    '        objEffectiveAlFeCalculation.Aleffcal(al_old, fe_old)
    '        Al_liq = objEffectiveAlFeCalculation.Al_liq
    '        fe_liq = objEffectiveAlFeCalculation.Fe_liq
    '        ' Al_liq = Math.Round(objEffectiveAlFeCalculation.Al_liq, 4)

    '        calc_Zn_Drag(coat, tc, bc, StripWidth, StripLength)
    '        calc_inh(fe_old)
    '        calc_dross_new()
    '        calc_pot_lvl_new("coilwise")
    '        calc_al_fe_left(fe_old)
    '        calc_al_tot_new(Al_liq)
    '        cal_fe_tot_new(fe_old)

    '        ''Finding the speed factor for the last 3 coils and using this to predict the speed factor of future coils
    '        '--------------------------------------------------------------------------------

    '        If r < 3 Then
    '            line_speed_predict(grade, StripWidth, StripThickness)
    '            linespeed_factor = linespeed_factor + (dt(r)("PRM_LINE_SPEED") / LineSpeed)
    '            count_coil = count_coil + 1
    '            If r = 0 Then
    '                linespeed_factor = linespeed_factor / count_coil
    '            End If
    '        End If

    '        '-------------------------------------------------------------------------------


    '        arrAlNew(r) = Al_tot_new
    '        If r >= 0 Then
    '            dgv.Rows(r).Cells(17).Text = Math.Round(al_old, 4)
    '            dgv.Rows(r).Cells(15).Text = Math.Round(pot_lvl_new, 1)
    '            dgv.Rows(r).Cells(19).Text = Math.Round(fe_old, 4)
    '            'added on 06-dec-2018
    '            dgv.Rows(r).Cells(21).Text = Math.Round(Zn_out * 1000, 0)
    '            dgv.Rows(r).Cells(22).Text = Math.Round(Al_inhi, 2)
    '            dgv.Rows(r).Cells(23).Text = Math.Round(Fe_dross, 2)
    '            dgv.Rows(r).Cells(24).Text = Math.Round(Al_dross, 2)
    '            dgv.Rows(r).Cells(25).Text = Math.Round(Al_liq, 3)
    '            dgv.Rows(r).Cells(26).Text = Math.Round(Zn_out * 1000 * Al_tot_old / 100, 2)
    '            If dgv.Rows(r).Cells(16).Text = "&nbsp;" Then
    '                dgv.Rows(r).Cells(27).Text = 0
    '            Else
    '                objEffectiveAlFeCalculation.Aleffcal(al_tot_eff1, fe_tot_eff1)
    '                al_eff_act_temp = objEffectiveAlFeCalculation.Al_liq
    '                dgv.Rows(r).Cells(27).Text = al_eff_act_temp
    '            End If

    '        End If
    '        al_old = Al_tot_new
    '        fe_old = fe_tot_new
    '    Next


    '    ''-----------------2018-12-20----------''
    '    ''Charging schedule
    '    ''------------------

    '    Dim al_target As Double
    '    Al_tot_old = Al_tot_new
    '    Pot_lvl_old = pot_lvl_new
    '    T_Bath_C = 460
    '    T_bath_K = T_Bath_C + 273
    '    SET_C = 470
    '    SET_K = SET_C + 273



    '    '-------------loop for calculation future al and zn depletion------------
    '    '---------------------------------------------------------------------
    '    ReDim Al_depletion(dgv_predict.Rows.Count - 1)
    '    ReDim zn_depletion(dgv_predict.Rows.Count - 1)
    '    ReDim Al_depletion_rate(dgv_predict.Rows.Count - 1)
    '    ReDim zn_depletion_rate(dgv_predict.Rows.Count - 1)
    '    ReDim coil_duration(dgv_predict.Rows.Count - 1)
    '    ReDim line_speed_arr(dgv_predict.Rows.Count - 1)

    '    SHG = 0
    '    CGG = 0
    '    Al5per = 0
    '    objEffectiveAlFeCalculation.Main(T_Bath_C, T_Bath_C + 273.15)
    '    objEffectiveAlFeCalculation.Aleffcal(al_old, fe_old)
    '    Al_liq = objEffectiveAlFeCalculation.Al_liq
    '    fe_liq = objEffectiveAlFeCalculation.Fe_liq
    '    For sch As Integer = 0 To dgv_predict.Rows.Count - 1
    '        Try

    '            Dim lenCoat As String = dgv_predict.Rows(sch).Cells(6).Text 'dgv_predict.Rows(sch).Cells("Coat_dgv").Value
    '            If lenCoat.Length = 3 Then
    '                CoatVal = lenCoat.ToString.Substring(1, 2) / 2
    '            ElseIf lenCoat.Length = 4 Then
    '                CoatVal = lenCoat.ToString.Substring(1, 3) / 2
    '            End If

    '            tc = dgv_predict.Rows(sch).Cells(20).Text    'in grams/sq meter
    '            bc = dgv_predict.Rows(sch).Cells(20).Text   'in grams/sq meter

    '            If (2 * CoatVal) <= 60 Then
    '                tc = CoatVal + 6    'in grams/sq meter
    '                bc = CoatVal + 6   'in grams/sq meter
    '            End If
    '            If (2 * CoatVal) > 60 And (2 * CoatVal) <= 80 Then
    '                tc = CoatVal + 4    'in grams/sq meter
    '                bc = CoatVal + 4   'in grams/sq meter
    '            End If
    '            If (2 * CoatVal) > 80 And (2 * CoatVal) <= 90 Then
    '                tc = CoatVal + 8    'in grams/sq meter
    '                bc = CoatVal + 8   'in grams/sq meter
    '            End If
    '            If (2 * CoatVal) > 90 And (2 * CoatVal) <= 100 Then
    '                tc = CoatVal + 2    'in grams/sq meter
    '                bc = CoatVal + 2   'in grams/sq meter
    '            End If
    '            If (2 * CoatVal) > 100 And (2 * CoatVal) <= 120 Then
    '                tc = CoatVal + 3    'in grams/sq meter
    '                bc = CoatVal + 3   'in grams/sq meter
    '            End If
    '            If (2 * CoatVal) > 120 And (2 * CoatVal) <= 140 Then
    '                tc = CoatVal + 4    'in grams/sq meter
    '                bc = CoatVal + 4   'in grams/sq meter
    '            End If
    '            If (2 * CoatVal) > 140 And (2 * CoatVal) <= 150 Then
    '                tc = CoatVal + 7    'in grams/sq meter
    '                bc = CoatVal + 7   'in grams/sq meter
    '            End If
    '            If (2 * CoatVal) > 150 And (2 * CoatVal) <= 180 Then
    '                tc = CoatVal + 6    'in grams/sq meter
    '                bc = CoatVal + 6   'in grams/sq meter
    '            End If
    '            If (2 * CoatVal) > 180 And (2 * CoatVal) <= 250 Then
    '                tc = CoatVal + 6    'in grams/sq meter
    '                bc = CoatVal + 6   'in grams/sq meter
    '            End If
    '            If (2 * CoatVal) > 250 And (2 * CoatVal) <= 275 Then
    '                tc = CoatVal + 8    'in grams/sq meter
    '                bc = CoatVal + 8   'in grams/sq meter
    '            End If


    '            StripThickness = dgv_predict.Rows(sch).Cells(4).Text / 1000     ' dgv_predict.Rows(sch).Cells("Thickness_dgv").Value / 1000 ''mm to m
    '            StripWidth = dgv_predict.Rows(sch).Cells(3).Text / 1000            'dgv_predict.Rows(sch).Cells("Width_dgv").Value / 1000  'mm to m
    '            StripLength = dgv_predict.Rows(sch).Cells(5).Text                  'dgv_predict.Rows(sch).Cells("Length_dgv").Value
    '            prod_flag = dgv_predict.Rows(sch).Cells(7).Text                      'dgv_predict.Rows(sch).Cells("prod_dgv").Value

    '            If prod_flag = "C10" Then
    '                prod_flag = "Z"
    '            End If
    '            If prod_flag = "C03" Then
    '                prod_flag = "A"
    '            End If
    '            line_speed_predict(grade, StripWidth, StripThickness)
    '            coil_duration(sch) = Math.Floor(StripLength / (linespeed_factor * LineSpeed))
    '            line_speed_arr(sch) = linespeed_factor *  LineSpeed
    '            calc_Zn_Drag(CoatVal, tc, bc, StripWidth, StripLength)
    '            zn_depletion(sch) = Zn_out * 1000                        'converting ton to kg
    '            cal_al_loss(sch)
    '            zn_depletion_rate(sch) = zn_depletion(sch) / coil_duration(sch)
    '            Al_depletion_rate(sch) = Al_depletion(sch) / coil_duration(sch)
    '            dgv_predict.Rows(sch).Cells(21).Text = Math.Round(Al_depletion_rate(sch), 3)
    '            dgv_predict.Rows(sch).Cells(22).Text = Math.Round(zn_depletion_rate(sch), 2)
    '        Catch ex As Exception

    '        End Try
    '    Next


    '    '--------------------------loop for ingot addition starts-------------
    '    Dim init_chem(), aim_chem(), recovery() As Decimal
    '    Dim aim_pot_level As Double = 200 * 1000
    '    Dim al_initial As Double
    '    If prod_flag = "Z" Then
    '        al_target = 0.185
    '    End If
    '    If prod_flag = "A" Then
    '        al_target = 0.115
    '    End If
    '    al_initial = Al_liq
    '    'al_initial = 0.125
    '    'al_old = 0.133
    '    'Al_tot_old = 0.133
    '    'fe_old = 0.04
    '    Pot_lvl_old = 199
    '    init_chem = {al_initial, Pot_lvl_old * 1000}    '% Al and  bath weight  (kg)
    '    aim_chem = {al_target, aim_pot_level}
    '    recovery = {100, 100}
    '    ReDim pred_dura_blck_1(2 * 24 * 60, 3)           '0 - duration, 1- SHG   2-CGG     3- 5AL..... for the next 48 hours the prediction is calculated
    '    ReDim pred_dura_blck_2(2 * 24 * 60, 3)

    '    pred_time_addition1 = 0
    '    pred_time_addition2 = 0
    '    nxt_pred_time_addition1 = 0
    '    nxt_pred_time_addition2 = 0
    '    Dim CGG_coil, SHG_coil, Al5per_coil As Integer
    '    Dim cummulative_duration As Integer
    '    'loop for converting into minute wise data from coil wise data
    '    '-------------------------------------------------------------
    '    cummulative_duration = 0
    '    cradle_status2 = "FREE"
    '    cradle_status1 = "FREE"
    '    For n As Integer = 0 To dgv_predict.Rows.Count - 1
    '        Try
    '            ' the unit for line speed is meter/min. the distance processed in half a minute equals half the line speed.
    '            StripLength = line_speed_arr(n) / 2
    '            StripThickness = dgv_predict.Rows(n).Cells(4).Text / 1000                     'dgv_predict.Rows(sch).Cells("Thickness_dgv").Value / 1000 ''mm to m
    '            StripWidth = Math.Round(dgv_predict.Rows(n).Cells(3).Text / 1000, 3)          'dgv_predict.Rows(sch).Cells("Width_dgv").Value / 1000  'mm to m
    '            prod_flag = dgv_predict.Rows(n).Cells(7).Text                                 'dgv_predict.Rows(sch).Cells("prod_dgv").Value

    '            If prod_flag = "C10" Then
    '                prod_flag = "Z"
    '                al_target = 0.185
    '            End If
    '            If prod_flag = "C03" Then
    '                prod_flag = "A"
    '                al_target = 0.115
    '            End If
    '            LineSpeed = line_speed_arr(n) 'line_speed_predict(grade, StripWidth, StripThickness)
    '            CGG_coil = 0
    '            SHG_coil = 0
    '            Al5per_coil = 0
    '            For x As Double = 1 To coil_duration(n) Step 0.5

    '                CGG = 0
    '                SHG = 0
    '                Al5per = 0
    '                'the array is made of 30 sec interval. but the values in the array are stored at minute interval. 
    '                'the ingots can be added one(ton) by one(ton). in case there is a requirement of 2 ton addition, 
    '                'first one ton addition is done, then calculated for next ton done in next 30 sec.
    '                If nxt_pred_time_addition1 < (x + cummulative_duration) And Math.IEEERemainder(x, 1) = 0 Then
    '                    add_ingot_predict_gradient(init_chem, aim_chem, zn_depletion_rate, Al_depletion_rate, n, 1)
    '                    CGG_coil = CGG_coil + CGG
    '                    SHG_coil = SHG_coil + SHG
    '                    Al5per_coil = Al5per_coil + Al5per
    '                    If CGG + SHG + Al5per > 0 Then
    '                        pred_dura_blck_1(x + cummulative_duration, 1) = pred_dura_blck_1(x + cummulative_duration, 1) + SHG
    '                        pred_dura_blck_1(x + cummulative_duration, 2) = pred_dura_blck_1(x + cummulative_duration, 2) + CGG
    '                        pred_dura_blck_1(x + cummulative_duration, 3) = pred_dura_blck_1(x + cummulative_duration, 3) + Al5per
    '                    ElseIf CGG + SHG + Al5per = 0 Then
    '                        cradle_status1 = "FREE"
    '                    End If

    '                End If

    '                If nxt_pred_time_addition2 < (x + cummulative_duration) And Math.IEEERemainder(x, 1) <> 0 Then
    '                    add_ingot_predict_gradient(init_chem, aim_chem, zn_depletion_rate, Al_depletion_rate, n, 2)
    '                    CGG_coil = CGG_coil + CGG
    '                    SHG_coil = SHG_coil + SHG
    '                    Al5per_coil = Al5per_coil + Al5per
    '                    If CGG + SHG + Al5per > 0 Then
    '                        pred_dura_blck_1(x + cummulative_duration, 1) = pred_dura_blck_1(x + cummulative_duration, 1) + SHG
    '                        pred_dura_blck_1(x + cummulative_duration, 2) = pred_dura_blck_1(x + cummulative_duration, 2) + CGG
    '                        pred_dura_blck_1(x + cummulative_duration, 3) = pred_dura_blck_1(x + cummulative_duration, 3) + Al5per
    '                    ElseIf CGG + SHG + Al5per = 0 Then
    '                        cradle_status2 = "FREE"
    '                    End If
    '                End If
    '                Dim lenCoat As String = dgv_predict.Rows(n).Cells(6).Text 'dgv_predict.Rows(sch).Cells("Coat_dgv").Value
    '                If lenCoat.Length = 3 Then
    '                    CoatVal = lenCoat.ToString.Substring(1, 2) / 2
    '                ElseIf lenCoat.Length = 4 Then
    '                    CoatVal = lenCoat.ToString.Substring(1, 3) / 2
    '                End If

    '                If (2 * CoatVal) <= 60 Then
    '                    tc = CoatVal + 6    'in grams/sq meter
    '                    bc = CoatVal + 6   ' in grams/sq meter
    '                End If
    '                If (2 * CoatVal) > 60 And (2 * CoatVal) <= 80 Then
    '                    tc = CoatVal + 4    'in grams/sq meter
    '                    bc = CoatVal + 4   'in grams/sq meter
    '                End If
    '                If (2 * CoatVal) > 80 And (2 * CoatVal) <= 90 Then
    '                    tc = CoatVal + 8    'in grams/sq meter
    '                    bc = CoatVal + 8   'in grams/sq meter
    '                End If
    '                If (2 * CoatVal) > 90 And (2 * CoatVal) <= 100 Then
    '                    tc = CoatVal + 2    'in grams/sq meter
    '                    bc = CoatVal + 2   'in grams/sq meter
    '                End If
    '                If (2 * CoatVal) > 100 And (2 * CoatVal) <= 120 Then
    '                    tc = CoatVal + 3    'in grams/sq meter
    '                    bc = CoatVal + 3   'in grams/sq meter
    '                End If
    '                If (2 * CoatVal) > 120 And (2 * CoatVal) <= 140 Then
    '                    tc = CoatVal + 4    'in grams/sq meter
    '                    bc = CoatVal + 4   'in grams/sq meter
    '                End If
    '                If (2 * CoatVal) > 140 And (2 * CoatVal) <= 150 Then
    '                    tc = CoatVal + 7    'in grams/sq meter
    '                    bc = CoatVal + 7   'in grams/sq meter
    '                End If
    '                If (2 * CoatVal) > 150 And (2 * CoatVal) <= 180 Then
    '                    tc = CoatVal + 6    'in grams/sq meter
    '                    bc = CoatVal + 6   'in grams/sq meter
    '                End If
    '                If (2 * CoatVal) > 180 And (2 * CoatVal) <= 250 Then
    '                    tc = CoatVal + 6    'in grams/sq meter
    '                    bc = CoatVal + 6   'in grams/sq meter
    '                End If
    '                If (2 * CoatVal) > 250 And (2 * CoatVal) <= 275 Then
    '                    tc = CoatVal + 8    'in grams/sq meter
    '                    bc = CoatVal + 8   'in grams/sq meter
    '                End If

    '                objEffectiveAlFeCalculation.Main(T_Bath_C, T_Bath_C + 273.15)
    '                objEffectiveAlFeCalculation.Aleffcal(al_old, fe_old)
    '                Al_liq = objEffectiveAlFeCalculation.Al_liq
    '                fe_liq = objEffectiveAlFeCalculation.Fe_liq

    '                calc_Zn_Drag(CoatVal, tc, bc, StripWidth, StripLength)
    '                calc_inh(fe_old)
    '                calc_dross_new()
    '                calc_pot_lvl_new("pred")
    '                calc_al_fe_left(fe_old)
    '                calc_al_tot_new(Al_liq)
    '                cal_fe_tot_new(fe_old)


    '                Pot_lvl_old = pot_lvl_new
    '                fe_old = fe_tot_new
    '                al_old = Al_tot_new
    '                Al_tot_old = Al_tot_new
    '                objEffectiveAlFeCalculation.Main(T_Bath_C, T_Bath_C + 273.15)
    '                objEffectiveAlFeCalculation.Aleffcal(Al_tot_new, fe_tot_new)
    '                Al_liq = objEffectiveAlFeCalculation.Al_liq
    '                fe_liq = objEffectiveAlFeCalculation.Fe_liq

    '                init_chem = {Al_liq, Pot_lvl_old * 1000}    '% Al and  bath weight  (kg)
    '                aim_chem = {al_target, aim_pot_level}

    '            Next x
    '        Catch ex As Exception

    '        End Try  'Solver_bath_2_mat(init_chem, aim_chem, recovery)
    '        dgv_predict.Rows(n).Cells(14).Text = SHG_coil
    '        dgv_predict.Rows(n).Cells(16).Text = CGG_coil
    '        dgv_predict.Rows(n).Cells(15).Text = Al5per_coil
    '        dgv_predict.Rows(n).Cells(10).Text = Math.Round(pot_lvl_new, 1)
    '        dgv_predict.Rows(n).Cells(11).Text = Math.Round(Al_liq, 3)
    '        dgv_predict.Rows(n).Cells(12).Text = Math.Round(fe_liq, 3)
    '        dgv_predict.Rows(n).Cells(17).Text = Math.Round(line_speed_arr(n), 0)
    '        dgv_predict.Rows(n).Cells(18).Text = Math.Round(Al_tot_new, 3)
    '        dgv_predict.Rows(n).Cells(19).Text = Math.Round(fe_tot_new, 3)
    '        dgv_predict.Rows(n).Cells(8).Text = Math.Round(coil_duration(n), 0)
    '        cummulative_duration = cummulative_duration + coil_duration(n)
    '    Next

    'End Sub
    Public Sub getData(ByVal dt As DataTable, ByVal r As Integer, ByVal arrAlNew As Array, ByVal Bath_Al_old As Decimal)

        'Get Al old,Fe old,Potlvl old, Prod_flag,Top coat,bottom coat etc
        If dt(r)("prm_zinc_pot_tmp").ToString = "" Then
            T_Bath_C = 460
        Else
            T_Bath_C = dt(r)("prm_zinc_pot_tmp").ToString
        End If

        T_bath_K = T_Bath_C + 273

        If dt(r)("stripEntryTemp").ToString() = "" Then
            SET_C = 460
        Else
            SET_C = dt(r)("stripEntryTemp").ToString
        End If


        SET_K = SET_C + 273
        If r = dt.Rows.Count - 1 Then
            If dt(r)("PRM_TEST_VAL_AL").ToString = "" Then
                Al_tot_old = Bath_Al_old
            Else
                Al_tot_old = dt(r)("PRM_TEST_VAL_AL").ToString
            End If

        ElseIf r > 0 Then
            Al_tot_old = arrAlNew(r + 1)
        End If
        Dim lenCoat As String = dt(r)("prm_cd_coat").ToString.Length
        If lenCoat = 3 Then
            CoatVal = dt(r)("prm_cd_coat").ToString.Substring(1, 2) / 2
        ElseIf lenCoat = 4 Then
            CoatVal = dt(r)("prm_cd_coat").ToString.Substring(1, 3) / 2
        End If

        tc = dt(r)("PRM_TTC_AVG").ToString
        bc = dt(r)("PRM_BTC_AVG").ToString
        StripThickness = dt(r)("thickness").ToString / 1000 ''mm to m
        StripWidth = dt(r)("width").ToString / 1000  'mm to m
        StripLength = dt(r)("prm_ln_coil").ToString
        prod_flag = dt(r)("PRM_CD_SURF_ROUGH").ToString

        If dt(r)("PRM_LINE_SPEED").ToString = "" Then

            LineSpeed = 100

        Else
            LineSpeed = dt(r)("PRM_LINE_SPEED").ToString
        End If


        ''check and validate data

    End Sub
    Public Sub calc_Al_Fe_triple()
        Al_trip = 0.017 + (0.00025 * (T_Bath_C))
        T_bath_K = T_Bath_C + 273
        Delta_G = ((1.72 * ((0.1384 * T_bath_K) - 8678.4711)) + (4.43 * ((3.7924 * T_bath_K) - 9662.2839))) / (1.987 * T_bath_K)
        IntA = (4.41027195404554E+21 * (Math.Exp(Delta_G / (1))))
        IntB = (146350673298.009 * ((19.2692 - (0.0133 * T_bath_K)) ^ 1.72)) * (((8.3424 - (0.0074 * T_bath_K)) ^ 4.43))
        J_calc = (IntA / IntB) ^ 0.581395349
        Fe_trip = J_calc * (Al_trip ^ (-2.5755814))

    End Sub

    Public Sub calc_Al_Fe_effec()
        Al_trip = 0.017 + (0.00025 * (T_Bath_C))
        T_bath_K = T_Bath_C + 273
        Delta_G = ((1.72 * ((0.1384 * T_bath_K) - 8678.4711)) + (4.43 * ((3.7924 * T_bath_K) - 9662.2839))) / (1.987 * T_bath_K)
        IntA = (4.41027195404554E+21 * (Math.Exp(Delta_G / (1))))
        IntB = (146350673298.009 * ((19.2692 - (0.0133 * T_bath_K)) ^ 1.72)) * (((8.3424 - (0.0074 * T_bath_K)) ^ 4.43))
        J_calc = (IntA / IntB) ^ 0.581395349
        Fe_trip = J_calc * (Al_trip ^ (-2.5755814))
        Fe_solu = Math.Exp(17.78 - (15388 / T_bath_K))
        Dim xtemp As Double
        If (Al_tot_old < 0.134) Then   'changed on 30-nov-18
            xtemp = 3 * (0.42 * Al_tot_old) * (1 - (0.42 * Al_tot_old)) + (0.42 * Al_tot_old) * (Math.Log(0.42 * Al_tot_old)) + ((1 - (0.42 * Al_tot_old)) * (Math.Log(1 - (0.42 * Al_tot_old)))) / (1 - (0.42 * Al_tot_old))
            Fe_tot = 1.9 * Fe_solu * Math.Exp(8 * xtemp)
            'xtemp = 8 * (3 * (0.42 * Al_tot_old) * (1 - (0.42 * Al_tot_old))) + (0.42 * Al_tot_old) * (Math.Log(0.42 * Al_tot_old)) + ((1 - (0.42 * Al_tot_old)) * (Math.Log(1 - (0.42 * Al_tot_old)))) / (1 - (0.42 * Al_tot_old))
            'Fe_tot = 1.9 * Fe_solu * Math.Exp(xtemp)
        Else
            Fe_tot = Math.Sqrt((Math.Exp(32.3 - (36133 / T_bath_K))) / (Al_tot_old ^ 5))
        End If

        Al_liq = ((Fe_trip + (0.0483125 * Al_trip)) - Fe_tot + (3.25 * Al_tot_old)) / 3.3600286  '' effective Al
        'Al_liq = ((Fe_trip + (0.0483125 * Al_trip)) - Fe_tot + (3.3117161 * Al_tot_old)) / 3.3600286  '' effective Al      changed on 04-dec-2018
        fe_liq = Fe_tot - (0.8036331 * Al_tot_old) + (0.8036331 * Al_liq)  ''effective Fe


    End Sub

    Public Sub calc_Zn_Drag(ByVal coat As Double, ByVal tc As Double, ByVal bc As Double, ByVal w As Double, ByVal l As Double)
        If (Pot_Flag = "GI" Or Pot_Flag = "RS") Then
            If (coat < 50) Then
                tc = 1.1 * tc
                bc = 1.1 * bc
            Else
                tc = 1.08 * tc
                bc = 1.08 * bc
            End If
        End If
        Zn_out = (w * l * (tc + bc)) / (1000000)

    End Sub

    Public Sub calc_inh(fe_old As Double)
        SET_K = SET_C + 273
        Activation_Energy = Math.Exp(12700 / (8.314 * T_bath_K))
        Viscocity = 0.0004131 * Activation_Energy
        Fe_diffusivity = (1.38 * SET_K * 10 ^ -23) / (16.0768 * Viscocity * 10 ^ -10)
        Tot_SurfaceArea = 2 * ((StripThickness * StripLength) + (StripWidth * StripLength))               'changed on 29-11-2018
        dissolution_rate = (0.554 / (0.928 * (Viscocity ^ (1 / 6))) * ((Fe_diffusivity) ^ (2 / 3)) * Math.Sqrt(LineSpeed))
        Fe_disl = 0.14313 * Tot_SurfaceArea * (StripLength / LineSpeed) * dissolution_rate * (0.75 - fe_old)               'changed on 06-12-2018
        fe_disl_percoil = Fe_disl
        'T_inhi = 866 + (376 * Math.Log(Al_liq))


        'added on 06-12-2018
        If Al_tot_old < 0.16 Then
            T_inhi = 866 + (376 * Math.Log(Al_liq))
        Else
            T_inhi = 792 + 376 * Math.Log(Al_liq)
        End If


    End Sub

    Public Sub calc_al_fe_left(fe_old As Double)
        ''Find out the left over aluminum, iron in the zinc bath using the following formula.
        Dim Fe2Al5_percoil1 As Double = 0
        Fe2Al5_percoil1 = (Tot_SurfaceArea * T_inhi) * (10 ^ -9)


        If (prod_flag = "RS") Then
            Fe2Al5_percoil = Fe2Al5_percoil1 * 3150
        ElseIf (prod_flag = "Z") Then  'ZS'
            Fe2Al5_percoil = Fe2Al5_percoil1 * 3700
            'ElseIf (prod_flag = "A") Then  ''GA
            '    Fe2Al5_percoil = Fe2Al5_percoil1 * 4500
        ElseIf (prod_flag = "A") Then  ''GA
            Fe2Al5_percoil = Fe2Al5_percoil1 * 3700
        Else
            Fe2Al5_percoil = Fe2Al5_percoil1 * 4100


        End If

        Fe_inhi = Fe2Al5_percoil * 0.453
        Al_inhi = Fe2Al5_percoil - Fe_inhi

        fe_disl_total = ((fe_old * Pot_lvl_old * 10) + fe_disl_percoil) / (Pot_lvl_old * 10)    'in %


    End Sub

    Public Sub calc_al_tot_new(ByVal Al_liq As Double)
        '' Al_tot_new = ((Al_tot_old * Pot_lvl_old * 10) + (Al5per * 0.05 + CGG * 0.004) - Al_inhi) / (pot_lvl_new * 10)
        If Al_tot_old < 0.16 Then
            'the below is working for GA
            Al_tot_new = ((Al_tot_old * Pot_lvl_old * 10) + (Al5per * 0.05 + CGG * (cgg_al_percent / 100)) - Al_inhi) / (pot_lvl_new * 10)
        Else
            'the below is working for GI
            Al_tot_new = ((Al_tot_old * Pot_lvl_old * 10) + (Al5per * 0.05 + CGG * (cgg_al_percent / 100)) - Al_inhi - (Al_tot_old / 100 * Zn_out * 1000) - Al_dross) / (pot_lvl_new * 10)
        End If
    End Sub

    Public Sub cal_fe_tot_new(ByVal fe_old As Double)

        'fe_tot_new = ((fe_old * Pot_lvl_old * 10) + fe_disl_percoil - Fe_inhi - (fe_liq / 100 * Zn_out * 1000)) / (pot_lvl_new * 10)    'in %   changed on 04-feb-2018
        fe_tot_new = ((fe_old * Pot_lvl_old * 10) + fe_disl_percoil - (fe_liq / 100 * Zn_out * 1000)) / (pot_lvl_new * 10)    'in %   changed on 04-feb-2018
    End Sub

    Public Sub calc_pot_lvl_new(str As String)
        ''Find out the New pot level using the following formula.
        'pot_lvl_new = Pot_lvl_old + (SHG / 1000) + (CGG * 0.995 / 1000) + (Al5per * 0.95 / 1000) + (Fe2Al5_percoil / 1000) - (Dross_val / 1000) - (Zn_out / 1000)
        If str = "coilwise" Then
            If (prod_flag = "Z") Then
                Dross_val = 22
            ElseIf prod_flag = "A" Then
                Dross_val = 33
            ElseIf prod_flag = "RS" Then
                Dross_val = 58
            End If
        Else
            If (prod_flag = "Z") Then
                Dross_val = 22 / 1800
            ElseIf prod_flag = "A" Then
                Dross_val = 33 / 1800
            ElseIf prod_flag = "RS" Then
                Dross_val = 58 / 1800
            End If
        End If

        pot_lvl_new = Pot_lvl_old + (SHG + CGG * (100 - cgg_al_percent) / 100 + Al5per * 0.95) / 1000 - (Fe2Al5_percoil + Dross_val) / 1000 - Zn_out       'changed on 29-11-2018

    End Sub

    Public Sub calc_dross_new()
        Fe_dross = fe_disl_percoil
        Al_dross = Fe_dross * 0.88894


        If (Al_tot_new > 0.138) Then
            Top_dross = (Fe_dross * 2.66)
            Al_dross = 0
        Else
            Top_dross = 0
        End If

        If (Al_tot_new < 0.138) And (prod_flag = "A") Then
            Bottom_dross = (Fe_dross * 9.185245)
            Al_dross = 0
        Else
            Bottom_dross = 0
        End If

    End Sub

    Public Sub ValidateData()
        If Al_tot_old > 0.1 And Al_tot_old < 0.35 Then

        Else
            MsgBox("Invalid Values of Al")
        End If
    End Sub

    ''''''''''new functions added.....................
    Public Sub cal_al_loss(ByVal nth_coil As Integer)
        SET_K = SET_C + 273
        Activation_Energy = Math.Exp(12700 / (8.314 * T_bath_K))
        Viscocity = 0.0004131 * Activation_Energy
        Fe_diffusivity = (1.38 * SET_K * 10 ^ -23) / (16.0768 * Viscocity * 10 ^ -10)
        Tot_SurfaceArea = 2 * ((StripThickness * StripLength) + (StripWidth * StripLength))               'changed on 29-11-2018
        dissolution_rate = (0.554 / (0.928 * (Viscocity ^ (1 / 6))) * ((Fe_diffusivity) ^ (2 / 3)) * Math.Sqrt(LineSpeed))
        Fe_disl = 0.14313 * Tot_SurfaceArea * (StripLength / LineSpeed) * dissolution_rate * (0.75 - fe_tot_new)               'changed on 06-12-2018
        fe_disl_percoil = Fe_disl
        'T_inhi = 866 + (376 * Math.Log(Al_liq))

        '-----------Thickness of  inhibition layer----------------------'
        'added on 06-12-2018
        If Al_tot_old < 0.16 Then
            T_inhi = 866 + (376 * Math.Log(Al_liq))
        Else
            T_inhi = 792 + 376 * Math.Log(Al_liq)
        End If


        '---------------------Al in dross----------------'
        Fe_dross = fe_disl_percoil
        Al_dross = Fe_dross * 0.88894

        '---------------Al in inhibition layer----------------

        Dim Fe2Al5_percoil1 As Double = 0
        Fe2Al5_percoil1 = (Tot_SurfaceArea * T_inhi) * (10 ^ -9)


        If (prod_flag = "RS") Then
            Fe2Al5_percoil = Fe2Al5_percoil1 * 3150
        ElseIf (prod_flag = "Z") Then  'ZS'
            Fe2Al5_percoil = Fe2Al5_percoil1 * 3700
        ElseIf (prod_flag = "A") Then  ''GA
            Fe2Al5_percoil = Fe2Al5_percoil1 * 4500
        Else
            Fe2Al5_percoil = Fe2Al5_percoil1 * 4100


        End If

        Fe_inhi = Fe2Al5_percoil * 0.453
        Al_inhi = Fe2Al5_percoil - Fe_inhi

        If (Al_tot_new < 0.138) And (prod_flag = "A") Then

            Al_dross = 0

        End If
        Al_depletion(nth_coil) = Al_inhi + (Al_liq / 100 * Zn_out * 1000) + Al_dross
    End Sub

    Public Sub line_speed_predict(lsp_grade As String, lsp_width As Double, lsp_thickness As Double)
        Dim temperature As Integer
        Dim tph_furn, lsd, max_tph, line_speed_pred, LS1 As Double
        If lsp_grade = "CQ" Then
            temperature = 730
        End If
        If lsp_grade = "DQ" Then
            temperature = 730
        End If
        If lsp_grade = "DDQ" Then
            temperature = 800
        End If
        If lsp_grade = "EIF" Then
            temperature = 830
        End If
        If lsp_grade = "HIF" Then
            temperature = 830
        End If
        If lsp_grade = "GA" Then
            temperature = 850
        End If

        'throughput allowable by furnace
        tph_furn = 84.65387 + 32.90893 * Math.Cos(temperature * 0.0089967 + 1.6110504)   'cos to be taken in degree. radian conversion is not required
        'line speed allowable
        lsd = tph_furn * 1.51
        'max allowable thru
        max_tph = lsp_width * lsp_thickness * 60 * 150 * 7850 / 1000

        If max_tph >= tph_furn Then

            LS1 = tph_furn * 1000 / (7850 * 60 * lsp_width * lsp_thickness)
            If (LS1 * (lsp_thickness * 1000)) > lsd Then
                line_speed_pred = lsd / (lsp_thickness * 1000)
            Else
                line_speed_pred = LS1
            End If
        Else
            If (lsd / (lsp_thickness * 1000)) > 150 Then
                line_speed_pred = 150
            Else
                line_speed_pred = lsd / (lsp_thickness * 1000)
            End If
        End If
        LineSpeed = line_speed_pred

    End Sub

    Public Sub add_ingot_predict_gradient(ByVal initchem() As Decimal, ByVal aimchem() As Decimal, zn_rate() As Double, al_rate() As Double, n As Integer, cradle As Integer)

        Dim Al_grad_pred, zn_gradient_predict, duration_remaining, Al_target_initial, aim_pot_wt As Double
        aim_pot_wt = aimchem(1)
        Al_grad_pred = 0.1     'kg/min
        zn_gradient_predict = 0.3    'kg/min
        'in minutes
        melting_1_ton_dura = 19
        Dim Al_loss, zn_loss As Double   'in kg
        Dim Al_loss_duration, zn_loss_duration As Double
        Al_target_initial = (aimchem(0) - initchem(0)) / 100 * initchem(1)
        Al_loss_duration = 0
        zn_loss_duration = 0
        Al_loss = 2.5
        'If Al_target_initial > Al_loss Then

        'Else
        '    Al_loss = 2.5 - Al_target_initial
        'End If


        '---------for GI starts-----------------

        'If Al_target_initial >= Al_loss * 2 And initchem(1) <= (aim_pot_wt - 500) Then
        '    Al5per = Math.Min(8, Al_target_initial / 5)
        '    GoTo factor
        'End If

        'If Al_target_initial >= (Al_loss) And initchem(1) <= (aim_pot_wt - 500) Then
        '    CGG = 1
        '    GoTo factor
        'End If

        'If Al_target_initial >= (Al_loss) And initchem(1) > (aim_pot_wt - 500) Then
        '    Al5per = Math.Min(2, Al_target_initial / 5)
        '    GoTo factor
        'End If

        'If Al_target_initial < (Al_loss) And initchem(1) < (aim_pot_wt - 500) Then
        '    SHG = 1
        '    GoTo factor
        'End If
        '---------for GI ends-----------------

        If Al_target_initial >= Al_loss * 2 And initchem(1) <= (aim_pot_wt - 200) Then
            Al5per = Math.Min(8, Al_target_initial / 5)
            GoTo factor
        End If

        If Al_target_initial >= (Al_loss - 0.5) And initchem(1) <= (aim_pot_wt) Then
            CGG = 1
            GoTo factor
        End If

        If aimchem(0) = 0.185 Then
            If Al_target_initial >= (Al_loss) And initchem(1) > (aim_pot_wt - 500) Then
                Al5per = Math.Min(2, Al_target_initial / 5)
                GoTo factor
            End If
        End If

        If Al_target_initial < (Al_loss) And initchem(1) < (aim_pot_wt - 500) Then
            SHG = 1
            GoTo factor
        End If

        'For i As Integer = n To al_rate.Length - 1
        '    Al_loss_duration = Al_loss_duration + Al_loss / al_rate(i)
        '    zn_loss_duration = zn_loss_duration + zn_loss / zn_rate(i)
        '    If Al_loss_duration > coil_duration(i) Then

        '    End If
        '    If zn_loss_duration > coil_duration(i) Then

        '    End If
        'Next i




factor:

        If (((CGG + SHG) = 1) Or (Al5per < 10 And Al5per > 0)) And cradle = 1 Then
            nxt_pred_time_addition1 = nxt_pred_time_addition1 + melting_1_ton_dura * (CGG + SHG) + melting_1_ton_dura * Al5per / 10
            cradle_status1 = "FULL"
        ElseIf cradle_status1 = "FREE" Then
            nxt_pred_time_addition1 = nxt_pred_time_addition1 + 0.5

        End If

        If (((CGG + SHG) = 1) Or (Al5per < 10 And Al5per > 0)) And cradle = 2 Then
            nxt_pred_time_addition2 = nxt_pred_time_addition2 + melting_1_ton_dura * (CGG + SHG) + melting_1_ton_dura * Al5per / 10
            cradle_status2 = "FULL"
        ElseIf cradle_status2 = "FREE" Then
            nxt_pred_time_addition2 = nxt_pred_time_addition2 + 0.5

        End If


        CGG = CGG * 1100
        SHG = SHG * 1040
        Al5per = Math.Round(Al5per) * 105




    End Sub


    Public Function Solver_bath_3_mat(ByVal initchem() As Decimal, ByVal aimchem() As Decimal, ByVal recochem() As Decimal) As Double()

        Dim solver As New SimplexSolver()

        Dim zn_bath_weight As Double = initchem(1)

        Dim no_of_materials As Integer = 3
        Dim mat_str() As String = {"SHG", "CGG", "Alloy"}
        Dim mat_cost() As Double = {100, 80, 15}
        Dim cost As Integer
        ''Adding variables with lower and upper bounds
        '' The available ferro alloy materials are taken here

        Dim arr_mat(no_of_materials - 1) As Integer

        For i = 0 To no_of_materials - 1
            solver.AddVariable(mat_str(i), arr_mat(i))
            solver.SetBounds(arr_mat(i), 0, 25000)
        Next


        ''The elements in the ferro alloy/steel chemistry is added here
        ''Adding row identifiers
        Dim no_of_elements As Integer = 2
        Dim arr_row(no_of_elements - 1) As Integer

        Dim element_list() As String = {"Al", "Zn"}
        For J = 0 To no_of_elements - 1
            solver.AddRow(element_list(J), arr_row(J))
        Next

        solver.AddRow("cost", cost)


        ' 'Adding coefficients to the constraint rows
        Dim amt_req As Double
        Dim element_reco As Double
        Dim element_req(no_of_elements - 1) As Double

        Dim fa_composition(no_of_materials - 1, no_of_elements) As Double
        fa_composition = {{0, 100}, {cgg_al_percent, (100 - cgg_al_percent)}, {5, 95}}

        For i = 0 To no_of_materials - 1
            For J = 0 To no_of_elements - 1
                solver.SetCoefficient(arr_row(J), arr_mat(i), fa_composition(i, J) / 100)
            Next
        Next

        ''for each element

        For k As Integer = 0 To no_of_elements - 1

            If k = 0 Then
                amt_req = (aimchem(1)) * ((aimchem(k) - initchem(k) * initchem(1) / aimchem(1)) / 100)
                If amt_req < 0 Then
                    amt_req = 0
                End If
                element_reco = (recochem(k) / 100)
                element_req(k) = amt_req / element_reco
                solver.SetBounds(arr_row(k), element_req(k), element_req(k) + element_req(k) * 0.01)
            Else
                amt_req = aimchem(k) - initchem(k)
                If amt_req < 0 Then
                    amt_req = 0
                End If
                element_reco = (recochem(k) / 100)
                element_req(k) = amt_req / element_reco
                solver.SetBounds(arr_row(k), element_req(k), element_req(k) + element_req(k) * 0.01)
            End If

        Next
        'Adding cost

        ''the ferro alloy cost is added here
        For k As Integer = 0 To no_of_materials - 1
            solver.SetCoefficient(cost, arr_mat(k), mat_cost(k))
        Next

        solver.AddGoal(cost, 1, True)

        Dim solverParams As SimplexSolverParams = New SimplexSolverParams()
        solverParams.GetSensitivityReport = True
        solverParams.GetInfeasibilityReport = True
        solver.Solve(solverParams)

        Dim reportSensitivity As ILinearSolverReport = solver.GetReport(LinearSolverReportType.Sensitivity)
        If reportSensitivity IsNot Nothing Then
            Dim sensitivityReport As ILinearSolverSensitivityReport =
                TryCast(reportSensitivity, ILinearSolverSensitivityReport)
            For Each row As Integer In solver.RowIndices
                If Not solver.IsGoal(row) Then
                    Console.WriteLine("Key: " & solver.GetKeyFromIndex(row) & " Dual Value: " & sensitivityReport.GetDualValue(row).ToDouble())
                End If
            Next
        End If

        Dim arr_result(no_of_materials - 1) As Double
        Dim str As String
        Dim reportInfeasibility As ILinearSolverReport = solver.GetReport(LinearSolverReportType.Infeasibility)
        If reportInfeasibility Is Nothing Then

            'ScriptManager.RegisterStartupScript(Me.page, Me.GetType(), "Popup", "warningalert(""The model is not infeasible, so there is no infeasibility report."");", True)
            str = "The model run successfully."

            For J = 0 To no_of_materials - 1
                arr_result(J) = Math.Ceiling(solver.GetValue(arr_mat(J)).ToDouble)
            Next

            SHG = (arr_result(0) / 1000)
            CGG = (arr_result(1) / 1000)
            Al5per = (arr_result(2) / 100)
            If ((zn_bath_weight / 1000) + (SHG + CGG + Al5per)) > 202 Then
                SHG = Math.Floor(SHG)
                CGG = Math.Floor(CGG)
                Al5per = Math.Floor(Al5per)
            End If
            If ((zn_bath_weight / 1000) + (SHG + CGG + Al5per)) <= 202 Then
                SHG = Math.Ceiling(SHG)
                CGG = Math.Ceiling(CGG)
                Al5per = Math.Floor(Al5per)
            End If

            SHG = SHG * 1000
            CGG = CGG * 1000
            Al5per = Al5per * 100

        End If

        ' Console.ReadLine()



        Return arr_result
    End Function

    Public Function Solver_bath_2_mat(ByVal initchem() As Decimal, ByVal aimchem() As Decimal, ByVal recochem() As Decimal) As Double()

        Dim solver As New SimplexSolver()

        Dim zn_bath_weight As Double = initchem(1)
        Dim mat_str() As String = {"SHG", "CGG"}
        Dim no_of_materials As Integer = mat_str.Length
        SHG = 0
        CGG = 0
        Al5per = 0
        Dim mat_cost() As Double = {100, 80}
        Dim cost As Integer
        ''Adding variables with lower and upper bounds
        '' The available ferro alloy materials are taken here

        Dim arr_mat(no_of_materials - 1) As Integer

        For i = 0 To no_of_materials - 1
            solver.AddVariable(mat_str(i), arr_mat(i))
            solver.SetBounds(arr_mat(i), 0, 25000)
        Next


        ''The elements in the ferro alloy/steel chemistry is added here
        ''Adding row identifiers
        Dim no_of_elements As Integer = 2
        Dim arr_row(no_of_elements - 1) As Integer

        Dim element_list() As String = {"Al", "Zn"}
        For J = 0 To no_of_elements - 1
            solver.AddRow(element_list(J), arr_row(J))
        Next

        solver.AddRow("cost", cost)


        ' 'Adding coefficients to the constraint rows
        Dim amt_req As Double
        Dim element_reco As Double
        Dim element_req(no_of_elements - 1) As Double

        Dim fa_composition(no_of_materials - 1, no_of_elements) As Double
        fa_composition = {{0, 100}, {cgg_al_percent, (100 - cgg_al_percent)}}

        For i = 0 To no_of_materials - 1
            For J = 0 To no_of_elements - 1
                solver.SetCoefficient(arr_row(J), arr_mat(i), fa_composition(i, J) / 100)
            Next
        Next

        ''for each element

        For k As Integer = 0 To no_of_elements - 1

            If k = 0 Then
                amt_req = (aimchem(1)) * ((aimchem(k) - initchem(k) * initchem(1) / aimchem(1)) / 100)
                If amt_req < 0 Then
                    amt_req = 0
                End If
                element_reco = (recochem(k) / 100)
                element_req(k) = amt_req / element_reco
                solver.SetBounds(arr_row(k), element_req(k) - element_req(k) * 0.4, element_req(k))
            Else
                amt_req = aimchem(k) - initchem(k)
                If amt_req < 0 Then
                    amt_req = 0
                End If
                element_reco = (recochem(k) / 100)
                element_req(k) = amt_req / element_reco
                solver.SetBounds(arr_row(k), element_req(k) - element_req(k) * 0.05, element_req(k))
            End If

        Next
        'Adding cost

        ''the ferro alloy cost is added here
        For k As Integer = 0 To no_of_materials - 1
            solver.SetCoefficient(cost, arr_mat(k), mat_cost(k))
        Next

        solver.AddGoal(cost, GoalKind.Maximize, True)

        Dim solverParams As SimplexSolverParams = New SimplexSolverParams()
        solverParams.GetSensitivityReport = True
        solverParams.GetInfeasibilityReport = True
        solver.Solve(solverParams)

        Dim reportSensitivity As ILinearSolverReport = solver.GetReport(LinearSolverReportType.Sensitivity)
        If reportSensitivity IsNot Nothing Then
            Dim sensitivityReport As ILinearSolverSensitivityReport =
                TryCast(reportSensitivity, ILinearSolverSensitivityReport)
            For Each row As Integer In solver.RowIndices
                If Not solver.IsGoal(row) Then
                    Console.WriteLine("Key: " & solver.GetKeyFromIndex(row) & " Dual Value: " & sensitivityReport.GetDualValue(row).ToDouble())
                End If
            Next
        End If

        Dim arr_result(no_of_materials - 1) As Double
        Dim str As String
        Dim reportInfeasibility As ILinearSolverReport = solver.GetReport(LinearSolverReportType.Infeasibility)
        If reportInfeasibility Is Nothing Then

            'ScriptManager.RegisterStartupScript(Me.page, Me.GetType(), "Popup", "warningalert(""The model is not infeasible, so there is no infeasibility report."");", True)
            str = "The model run successfully."

            For J = 0 To no_of_materials - 1
                arr_result(J) = Math.Ceiling(solver.GetValue(arr_mat(J)).ToDouble)
            Next

            SHG = (arr_result(0) / 1000)
            CGG = (arr_result(1) / 1000)
            'Al5per = (arr_result(2) / 100)
            Dim al_model_chk, zn_pot_chk As Double
            al_model_chk = (Al_tot_old * zn_bath_weight / 100 + (Al5per * 0.05 * 100 + CGG * 1000 * cgg_al_percent / 100)) / ((zn_bath_weight + SHG * 1000 + CGG * 1000 + Al5per * 100)) * 100

            If ((zn_bath_weight / 1000) + (SHG + CGG + Al5per)) > 202 Then
                SHG = Math.Floor(SHG)
                CGG = Math.Floor(CGG)
                'Al5per = Math.Floor(Al5per)
            End If
            If ((zn_bath_weight / 1000) + (SHG + CGG + Al5per)) <= 202 Then
                SHG = Math.Round(SHG)
                CGG = Math.Round(CGG)
                'Al5per = Math.Floor(Al5per)
            End If

            SHG = SHG * 1000
            CGG = CGG * 1000
            'Al5per = Al5per * 100

        End If

        ' Console.ReadLine()



        Return arr_result
    End Function








End Class
