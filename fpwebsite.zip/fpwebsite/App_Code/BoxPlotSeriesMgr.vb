﻿Imports System.Linq
Imports System.Data

Public Class BoxPlotSeriesMgr
    Enum PlotingMode
        MeanMode
        MedianMode
    End Enum

    Public Function GetValuesForBoxPlot(ByVal ArrayName() As Decimal) 'As Double 'Hashtable
        'Dim hTable As New Hashtable()
        Dim arrbxpltparm(11) As Double
        Dim dt, str As New DataTable()
        dt.Columns.Add("ArrayValues")

        Dim sumOfItemsPerInterval As Decimal = 0
        Dim avg As Decimal = 0
        Dim median As Decimal = 0
        Dim min As Decimal = 0
        Dim max As Decimal = 0
        Dim upperQuartile As Decimal = 0
        Dim lowerQuartile As Decimal = 0
        Dim itemsPerInterval As Integer = 0
        Dim totalItems As Integer = 0
        Dim Mid1Pos As Integer = 0
        Dim Mid2Pos As Integer = 0
        Dim Mid1Val As Decimal = 0
        Dim Mid2Val As Decimal = 0
        Dim IQR As Decimal = 0
        Dim LowerBound As Decimal = 0
        Dim LowerWhisker As Decimal = 0
        Dim UpperBound As Decimal = 0
        Dim UpperWhisker As Decimal = 0
        Dim extLowerBound As Decimal = 0
        Dim extUpperBound As Decimal = 0
        Array.Sort(ArrayName)

        For i As Integer = 0 To ArrayName.Length - 1
            If ArrayName.GetValue(i) <> 0 Then
                Dim dr As DataRow = dt.NewRow()
                dr(0) = ArrayName.GetValue(i)
                dt.Rows.Add(dr)
                sumOfItemsPerInterval = sumOfItemsPerInterval + Decimal.Parse(ArrayName.GetValue(i).ToString())
            End If
        Next


        itemsPerInterval = dt.Rows.Count
        avg = sumOfItemsPerInterval / Decimal.Parse(itemsPerInterval)

        If itemsPerInterval Mod 2 = 0 Then
            Mid1Pos = itemsPerInterval / 2
            Mid2Pos = (itemsPerInterval / 2) + 1
            Mid1Val = Decimal.Parse(dt.Rows(Mid1Pos - 1)(0).ToString())
            Mid2Val = Decimal.Parse(dt.Rows(Mid2Pos - 1)(0).ToString())

            median = (Mid1Val + Mid2Val) / 2
        Else
            median = Decimal.Parse(dt.Rows(((itemsPerInterval + 1) / 2) - 1)(0).ToString())
        End If

        min = Decimal.Parse(dt.Rows(0)(0).ToString())
        max = Decimal.Parse(dt.Rows(dt.Rows.Count - 1)(0).ToString())
        lowerQuartile = Decimal.Parse(dt.Rows(((itemsPerInterval + 2) / 4) - 1)(0).ToString())
        upperQuartile = Decimal.Parse(dt.Rows((((3 * itemsPerInterval) + 2) / 4) - 1)(0).ToString())
        IQR = Decimal.Subtract(upperQuartile, lowerQuartile)
        LowerBound = lowerQuartile - (1.5 * IQR)
        UpperBound = upperQuartile + (1.5 * IQR)
        extLowerBound = lowerQuartile - (3 * IQR)
        extUpperBound = upperQuartile + (3 * IQR)
        'Dim querylw = (From lw In dt.AsEnumerable() Where lw.Field(Of Decimal)("ArrayValues") >= LowerBound Select lw Order By lw.Field(Of Decimal)("ArrayValues") Ascending Select lw).Take(1)
        'Dim queryuw = (From uw In dt.AsEnumerable() Where uw.Field(Of Decimal)("ArrayValues") <= UpperBound Select uw Order By uw.Field(Of Decimal)("ArrayValues") Descending Select uw).Take(1)
        'str = querylw.CopyToDataTable()
        'LowerWhisker = dt.Rows(0)("ArrayValues").ToString()
        'str = queryuw.CopyToDataTable()
        'UpperWhisker = dt.Rows(0)("ArrayValues").ToString()


        If min >= LowerBound Then
            LowerBound = min
        End If
        If max <= UpperBound Then
            UpperBound = max
        End If

        arrbxpltparm(0) = min
        arrbxpltparm(1) = max
        arrbxpltparm(2) = avg
        arrbxpltparm(3) = median
        arrbxpltparm(4) = lowerQuartile
        arrbxpltparm(5) = upperQuartile
        arrbxpltparm(6) = LowerWhisker
        arrbxpltparm(7) = UpperWhisker
        arrbxpltparm(8) = LowerBound
        arrbxpltparm(9) = UpperBound
        arrbxpltparm(10) = extLowerBound
        arrbxpltparm(11) = extUpperBound
        Return arrbxpltparm
        'hTable.Add("min", min)
        'hTable.Add("max", max)
        'hTable.Add("avg", avg)
        'hTable.Add("med", median)
        'hTable.Add("lql", lowerQuartile)
        'hTable.Add("uql", upperQuartile)

        'Return hTable
    End Function

    Public Function GetValuesForBoxPlot(ByVal ArrayName() As Decimal, ByVal Mode As PlotingMode) 'As Hashtable
        'Dim hTable As New Hashtable()
        Dim arrbxpltparm(5) As Double
        Dim dt As New DataTable()
        dt.Columns.Add("ArrayValues")

        Dim sumOfItemsPerInterval As Decimal = 0
        Dim avg As Decimal = 0
        Dim median As Decimal = 0
        Dim min As Decimal = 0
        Dim max As Decimal = 0
        Dim upperQuartile As Decimal = 0
        Dim lowerQuartile As Decimal = 0
        Dim itemsPerInterval As Integer = 0
        Dim totalItems As Integer = 0
        Dim Mid1Pos As Integer = 0
        Dim Mid2Pos As Integer = 0
        Dim Mid1Val As Decimal = 0
        Dim Mid2Val As Decimal = 0

        For i As Integer = 0 To ArrayName.Length - 1
            Dim dr As DataRow = dt.NewRow()
            dr(0) = ArrayName.GetValue(i)
            dt.Rows.Add(dr)
            sumOfItemsPerInterval = sumOfItemsPerInterval + Decimal.Parse(ArrayName.GetValue(i).ToString())
        Next
        itemsPerInterval = dt.Rows.Count
        avg = sumOfItemsPerInterval / Decimal.Parse(itemsPerInterval)

        If itemsPerInterval Mod 2 = 0 Then
            Mid1Pos = itemsPerInterval / 2
            Mid2Pos = (itemsPerInterval / 2) + 1
            Mid1Val = Decimal.Parse(dt.Rows(Mid1Pos - 1)(0).ToString())
            Mid2Val = Decimal.Parse(dt.Rows(Mid2Pos - 1)(0).ToString())

            median = (Mid1Val + Mid2Val) / 2
        Else
            median = Decimal.Parse(dt.Rows(((itemsPerInterval + 1) / 2) - 1)(0).ToString())
        End If
        Dim dv As DataView = dt.DefaultView
        dv.Sort = "ArrayValues"

        min = Decimal.Parse(dv(1)(0).ToString()) 'Decimal.Parse(dt.Rows(0)(0).ToString())
        max = Decimal.Parse(dv(dv.Count - 1)(0).ToString())
        lowerQuartile = Decimal.Parse(dv(((itemsPerInterval + 2) / 4) - 1)(0).ToString())
        upperQuartile = Decimal.Parse(dv((((3 * itemsPerInterval) + 2) / 4) - 1)(0).ToString())

        'hTable.Add("min", min)
        'hTable.Add("max", max)
        'If Mode = PlotingMode.MeanMode Then
        '    hTable.Add("avg", avg)
        'Else
        '    hTable.Add("med", median)
        'End If
        'hTable.Add("lql", lowerQuartile)
        'hTable.Add("uql", upperQuartile)

        'Return hTable
        arrbxpltparm(0) = min
        arrbxpltparm(1) = max
        arrbxpltparm(2) = avg
        arrbxpltparm(3) = median
        arrbxpltparm(4) = lowerQuartile
        arrbxpltparm(5) = upperQuartile
        Return arrbxpltparm
    End Function
End Class