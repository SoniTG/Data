﻿Imports Microsoft.VisualBasic
Imports System.Data
Imports OfficeOpenXml
Imports System.IO


Public Class Controller_CoilDeviation
    Dim objDataHandler As New DataHandler

    Public Function SaveAndRetrievePageHits(ByVal LoginTime As String, ByVal PageName As String) As Integer
        'Dim count As Integer = 0

        'Return count
        Dim count As Integer = 0
        Dim REFDATE As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff")

        If Not objDataHandler.CheckRecordsIn("PAGE_HIT_DTLS", "PAGE_NAME", "TIMESTAMP='" & REFDATE & "' and PAGE_NAME='" & PageName & "'") Then
            objDataHandler.RunSimpleQuery("insert into PAGE_HIT_DTLS values('" & PageName & "','" & REFDATE & "',NULL)")
        End If
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select TIMESTAMP from PAGE_HIT_DTLS where PAGE_NAME= '" & PageName & "'").Tables(0)


        count = IIf(dt.Rows.Count = 0, 0, dt.Rows.Count)
        Return count
    End Function

    Function GetCOILData(ByVal startDate As DateTime, ByVal endDate As DateTime) As DataSet
        Try
            'Dim ds As DataSet = objDataHandler.GetDataSetFromQueryAnalysis("SELECT [COIL_ID] , convert(varchar,[START_TIME],121) as START_TIME ,[COIL_THICKNESS] ,[MILL_ENTRY_TEMP] ,[SPEED_BEFORE_F1] ,[ENTRY_DS_PRESSURE],[EXIT_DS_PRESSURE] ,[FRT] , [ROLL_FORCE_F1] , [ROLL_FORCE_F2] , [ROLL_FORCE_F3] , [ROLL_FORCE_F4] , [ROLL_FORCE_F5] , [ROLL_FORCE_F6] , [QLTY_CODE]  FROM [FP_PROCESS_DATA].[dbo].[TSCR_COIL_DETAILS] where  START_TIME  between '" & startDate.ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & endDate.ToString("yyyy-MM-dd HH:mm:ss") & "' and COIL_THICKNESS = '1.60' order by [START_TIME] asc")
            '' Dim ds As DataSet = objDataHandler.GetDataSetFromQueryAnalysis("SELECT [COIL_ID] , convert(varchar,[START_TIME],113) as START_TIME ,[COIL_THICKNESS] ,[MILL_ENTRY_TEMP] ,[SPEED_BEFORE_F1] ,[ENTRY_DS_PRESSURE],[EXIT_DS_PRESSURE] ,[FRT] , [ROLL_FORCE_F1] , [ROLL_FORCE_F2] , [ROLL_FORCE_F3] , [ROLL_FORCE_F4] , [ROLL_FORCE_F5] , [ROLL_FORCE_F6] , [QLTY_CODE]  FROM [FP_PROCESS_DATA].[dbo].[TSCR_COIL_DETAILS] where  START_TIME  between '" & startDate.ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & endDate.ToString("yyyy-MM-dd HH:mm:ss") & "' and COIL_THICKNESS = '1.60'  order by [START_TIME] asc")
            Dim ds As DataSet = objDataHandler.GetDataSetFromQueryAnalysis("SELECT [COIL_ID] , convert(varchar,[START_TIME],121) as START_TIME ,[COIL_THICKNESS] ,[MILL_ENTRY_TEMP] ,[SPEED_BEFORE_F1] ,[ENTRY_DS_PRESSURE],[EXIT_DS_PRESSURE] ,[FRT] , [F1_ROLL_GAP],[F2_ROLL_GAP],[F3_ROLL_GAP] ,[F4_ROLL_GAP] ,[F5_ROLL_GAP] ,[F6_ROLL_GAP], [QLTY_CODE] , [ROLL_FORCE_F1] , [ROLL_FORCE_F2] , [ROLL_FORCE_F3] , [ROLL_FORCE_F4] , [ROLL_FORCE_F5] , [ROLL_FORCE_F6],[F1_INSTND_COOL],[F2_INSTND_COOL],[F3_INSTND_COOL]  ,[RGL_F2_TOP_OIL_WATER],[RGL_F2_BOT_OIL_WATER],[RGL_F3_TOP_OIL_WATER],[RGL_F3_BOT_OIL_WATER],[RGL_F4_TOP_OIL_WATER],[RGL_F4_BOT_OIL_WATER] FROM [FP_PROCESS_DATA].[dbo].[TSCR_COIL_DETAILS] where  START_TIME  between '" & startDate.ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & endDate.ToString("yyyy-MM-dd HH:mm:ss") & "' and COIL_THICKNESS = '1.60' order by [START_TIME] desc")

            Return ds
        Catch ex As Exception
            Throw New Exception(ex.ToString)
        End Try
    End Function
    Function GetCOILDataDEVIATION(ByVal startDate As DateTime, ByVal endDate As DateTime) As DataSet
        Try
            Dim ds As DataSet = objDataHandler.GetDataSetFromQueryAnalysis("SELECT [COIL_ID] , convert(varchar,[START_TIME],121) as START_TIME  ,[COIL_THICKNESS] ,[MILL_ENTRY_TEMP] ,[SPEED_BEFORE_F1] ,[ENTRY_DS_PRESSURE],[EXIT_DS_PRESSURE] ,[FRT] , [F1_ROLL_GAP],[F2_ROLL_GAP],[F3_ROLL_GAP] ,[F4_ROLL_GAP] ,[F5_ROLL_GAP] ,[F6_ROLL_GAP], [QLTY_CODE] , [ROLL_FORCE_F1] , [ROLL_FORCE_F2] , [ROLL_FORCE_F3] , [ROLL_FORCE_F4] , [ROLL_FORCE_F5] , [ROLL_FORCE_F6],[F1_INSTND_COOL],[F2_INSTND_COOL],[F3_INSTND_COOL]  ,[RGL_F2_TOP_OIL_WATER],[RGL_F2_BOT_OIL_WATER],[RGL_F3_TOP_OIL_WATER],[RGL_F3_BOT_OIL_WATER],[RGL_F4_TOP_OIL_WATER],[RGL_F4_BOT_OIL_WATER] FROM [FP_PROCESS_DATA].[dbo].[TSCR_COIL_DETAILS] where  START_TIME  between '" & startDate.ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & endDate.ToString("yyyy-MM-dd HH:mm:ss") & "' and COIL_THICKNESS = '1.60'  order by [START_TIME] desc")

            Return ds
        Catch ex As Exception
            Throw New Exception(ex.ToString)
        End Try
    End Function

    Function GetCOIL_Defect(ByVal startDate As DateTime, ByVal endDate As DateTime) As DataSet
        Try
            'Dim ds As DataSet = objDataHandler.GetDataSetFromQueryAnalysis("SELECT  [DATETIME],[COIL_ID],[DEFECT_TYPE],[DEFECT_TYPE_MEANING] ,[TDF_CODE] FROM [FP_PROCESS_DATA].[dbo].[TSCR_COIL_DEFECT] order by datetime desc")

            Dim ds As DataSet = objDataHandler.GetDataSetFromQueryAnalysis("SELECT convert(varchar,[DATETIME],121) as DATETIME ,[COIL_ID],[DEFECT_TYPE],[DEFECT_TYPE_MEANING] ,[TDF_CODE] FROM [FP_PROCESS_DATA].[dbo].[TSCR_COIL_DEFECT] where [DATETIME]  between '" & startDate.ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & endDate.ToString("yyyy-MM-dd HH:mm:ss") & "'  order by DATETIME desc")


            Return ds
        Catch ex As Exception
            Throw New Exception(ex.ToString)
        End Try
    End Function

    Function GetCOILDeviation_checkbox(ByVal startDate As DateTime, ByVal endDate As DateTime) As DataSet
        Try
            Dim ds As DataSet = objDataHandler.GetDataSetFromQueryAnalysis("SELECT [COIL_ID] , convert(varchar,[START_TIME],121) as START_TIME  ,[COIL_THICKNESS] ,[MILL_ENTRY_TEMP] ,[SPEED_BEFORE_F1] ,[ENTRY_DS_PRESSURE],[EXIT_DS_PRESSURE] ,[FRT] , [F1_ROLL_GAP],[F2_ROLL_GAP],[F3_ROLL_GAP] ,[F4_ROLL_GAP] ,[F5_ROLL_GAP] ,[F6_ROLL_GAP], [QLTY_CODE] , [ROLL_FORCE_F1] , [ROLL_FORCE_F2] , [ROLL_FORCE_F3] , [ROLL_FORCE_F4] , [ROLL_FORCE_F5] , [ROLL_FORCE_F6],[F1_INSTND_COOL],[F2_INSTND_COOL],[F3_INSTND_COOL]  ,[RGL_F2_TOP_OIL_WATER],[RGL_F2_BOT_OIL_WATER],[RGL_F3_TOP_OIL_WATER],[RGL_F3_BOT_OIL_WATER],[RGL_F4_TOP_OIL_WATER],[RGL_F4_BOT_OIL_WATER],[SLAB_ID] FROM [FP_PROCESS_DATA].[dbo].[TSCR_COIL_DETAILS] where  START_TIME  between '" & startDate.ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & endDate.ToString("yyyy-MM-dd HH:mm:ss") & "' and slab_id is not null   order by [START_TIME] desc")

            Return ds
        Catch ex As Exception
            Throw New Exception(ex.ToString)
        End Try
    End Function
    'Function GetCOILDeviation_checkbox(ByVal startDate As DateTime, ByVal endDate As DateTime) As DataSet
    '    Try
    '        Dim ds As DataSet = objDataHandler.GetDataSetFromQueryAnalysis("SELECT [COIL_ID] , convert(varchar,[START_TIME],121) as START_TIME  ,[COIL_THICKNESS] ,[MILL_ENTRY_TEMP] ,[SPEED_BEFORE_F1] ,[ENTRY_DS_PRESSURE],[EXIT_DS_PRESSURE] ,[FRT] , [F1_ROLL_GAP],[F2_ROLL_GAP],[F3_ROLL_GAP] ,[F4_ROLL_GAP] ,[F5_ROLL_GAP] ,[F6_ROLL_GAP], [QLTY_CODE] , [ROLL_FORCE_F1] , [ROLL_FORCE_F2] , [ROLL_FORCE_F3] , [ROLL_FORCE_F4] , [ROLL_FORCE_F5] , [ROLL_FORCE_F6],[F1_INSTND_COOL],[F2_INSTND_COOL],[F3_INSTND_COOL]  ,[RGL_F2_TOP_OIL_WATER],[RGL_F2_BOT_OIL_WATER],[RGL_F3_TOP_OIL_WATER],[RGL_F3_BOT_OIL_WATER],[RGL_F4_TOP_OIL_WATER],[RGL_F4_BOT_OIL_WATER] FROM [FP_PROCESS_DATA].[dbo].[TSCR_COIL_DETAILS] where  START_TIME  between '" & startDate.ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & endDate.ToString("yyyy-MM-dd HH:mm:ss") & "'   order by [START_TIME] desc")

    '        Return ds
    '    Catch ex As Exception
    '        Throw New Exception(ex.ToString)
    '    End Try
    'End Function

    'Function GetPerspectiveQuality_forCaster1(ByRef stdate As DateTime, ByVal endate As DateTime) As DataSet
    '    Try
    '        Dim ds As DataSet = objDataHandler.GetDataSetFromQueryAnalysis("SELECT * FROM TSCR_SLAB_DIVR where PROD_END between '" & stdate.ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & endate.ToString("yyyy-MM-dd HH:mm:ss") & "' and CASTER= 1 and slab_cut_no is not null ORDER BY PROD_END DESC")
    '        Return ds

    '    Catch ex As Exception
    '        Throw New Exception(ex.ToString)
    '    End Try
    'End Function

    'Function GetPerspectiveQuality_forCaster2(ByRef stdate As DateTime, ByVal endate As DateTime) As DataSet
    '    Try
    '        Dim ds As DataSet = objDataHandler.GetDataSetFromQueryAnalysis("SELECT * FROM TSCR_SLAB_DIVR where PROD_END between '" & stdate.ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & endate.ToString("yyyy-MM-dd HH:mm:ss") & "' and CASTER= 2 and slab_cut_no is not null ORDER BY PROD_END DESC")
    '        Return ds

    '    Catch ex As Exception
    '        Throw New Exception(ex.ToString)
    '    End Try
    'End Function

    Function SearchCOIL(ByVal filter As String) As DataSet
        Try
            ' Dim ds As DataSet = objDataHandler.GetDataSetFromQueryAnalysis("SELECT [COIL_ID] , convert(varchar,[START_TIME],121) as START_TIME ,[COIL_THICKNESS] ,[MILL_ENTRY_TEMP] ,[SPEED_BEFORE_F1] ,[ENTRY_DS_PRESSURE],[EXIT_DS_PRESSURE] ,[FRT] , [ROLL_FORCE_F1] , [ROLL_FORCE_F2] , [ROLL_FORCE_F3] , [ROLL_FORCE_F4] , [ROLL_FORCE_F5] , [ROLL_FORCE_F6] , [QLTY_CODE]  FROM [FP_PROCESS_DATA].[dbo].[TSCR_COIL_DETAILS] " & filter & " order by [START_TIME] asc")
            ' Dim ds As DataSet = objDataHandler.GetDataSetFromQueryAnalysis("SELECT [COIL_ID] , convert(varchar,[START_TIME],113) as START_TIME ,[COIL_THICKNESS] ,[MILL_ENTRY_TEMP] ,[SPEED_BEFORE_F1] ,[ENTRY_DS_PRESSURE],[EXIT_DS_PRESSURE] ,[FRT] , [ROLL_FORCE_F1] , [ROLL_FORCE_F2] , [ROLL_FORCE_F3] , [ROLL_FORCE_F4] , [ROLL_FORCE_F5] , [ROLL_FORCE_F6] , [QLTY_CODE]  FROM [FP_PROCESS_DATA].[dbo].[TSCR_COIL_DETAILS] where  START_TIME  between '" & startDate.ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & endDate.ToString("yyyy-MM-dd HH:mm:ss") & "' and COIL_THICKNESS = '1.60'  order by [START_TIME] asc")
            Dim ds As DataSet = objDataHandler.GetDataSetFromQueryAnalysis("select [TSCR_COIL_DETAILS].coil_id , convert(varchar,[START_TIME],121) as START_TIME ,[COIL_THICKNESS] ,[MILL_ENTRY_TEMP] ,[SPEED_BEFORE_F1] ,[ENTRY_DS_PRESSURE],[EXIT_DS_PRESSURE] ,[FRT] , [F1_ROLL_GAP],[F2_ROLL_GAP],[F3_ROLL_GAP] ,[F4_ROLL_GAP] ,[F5_ROLL_GAP] ,[F6_ROLL_GAP], [QLTY_CODE] , [ROLL_FORCE_F1] , [ROLL_FORCE_F2] , [ROLL_FORCE_F3] , [ROLL_FORCE_F4] , [ROLL_FORCE_F5] , [ROLL_FORCE_F6],[F1_INSTND_COOL],[F2_INSTND_COOL],[F3_INSTND_COOL]  , [RGL_F2_TOP_OIL_WATER],[RGL_F2_BOT_OIL_WATER],[RGL_F3_TOP_OIL_WATER],[RGL_F3_BOT_OIL_WATER],[RGL_F4_TOP_OIL_WATER], [RGL_F4_BOT_OIL_WATER], [DEFECT_TYPE] FROM [FP_PROCESS_DATA].[dbo].[TSCR_COIL_DETAILS] inner join [TSCR_COIL_DEFECT] on [TSCR_COIL_DETAILS].coil_id = [TSCR_COIL_DEFECT].COIL_ID " & filter & " order by [START_TIME] desc")



            Return ds
        Catch ex As Exception
            Throw New Exception(ex.ToString)
        End Try
    End Function

    Function GetSlab_Furnace(ByVal startDate As DateTime, ByVal endDate As DateTime) As DataSet
        Try
            Dim ds As DataSet = objDataHandler.GetDataSetFromQueryAnalysis("SELECT    [SLAB_ID], [FURNACE_NUM] ,convert(varchar,[SLAB_CHARGE_TIME],121) as SLAB_CHARGE_TIME, convert(varchar,[SLAB_DISCHARGE_TIME],121) as SLAB_DISCHARGE_TIME ,[SLAB_DURATION],[SLAB_ENTRY_HEAD] ,[SLAB_ENTRY_MID],[SLAB_ENTRY_TAIL],[SLAB_EXIT_HEAD] ,[SLAB_EXIT_MID] ,[SLAB_EXIT_TAIL] ,[SLAB_PYRO_HEAD] ,[SLAB_PYRO_MID]  ,[SLAB_PYRO_TAIL] FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE] WHERE [SLAB_CHARGE_TIME]  between '" & startDate.ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & endDate.ToString("yyyy-MM-dd HH:mm:ss") & "' and slab_id is not null   ORDER BY SLAB_CHARGE_TIME DESC")
            Return ds
        Catch ex As Exception
            Throw New Exception(ex.ToString)
        End Try
    End Function

    Function oradataBackupRollTop(ByVal startDate As DateTime, ByVal endDate As DateTime, ByVal stand_val As Integer) As DataTable
        Try
            ' Dim ds As DataSet = objDataHandler.GetOracleDataForRollForce("select distinct p1.slab_id,p2.description, p1.roll_id, p1.stand_id, round(p1.dia,2) as DIA, round(LENGTH,2) as LENGTH, round(p1.weight,2) as WEIGHT from roll_coils p1, roll_pos p2 where p1.roll_id=p2.roll_id and description = 'Backup Roll Top' and p1.stand_id= " & stand_val & "")
            Dim ds As DataSet = objDataHandler.GetOracleDataForRollForce(" select distinct slab_id, roll_id, stand_id, round(dia,2) as DIA, round(length,2) as LENGTH,  round(WEIGHT,2) as WEIGHT from  roll_coils where roll_pos = 0 and roll_type = 1 and stand_id =  " & stand_val & " ")
            Return ds.Tables(0)
        Catch ex As Exception
            Throw New Exception(ex.ToString)
        End Try
    End Function


    Function oradataBackupRollBottom(ByVal startDate As DateTime, ByVal endDate As DateTime, ByVal stand_val As Integer) As DataTable
        Try
            ' Dim ds As DataSet = objDataHandler.GetOracleDataForRollForce("select distinct p1.slab_id,p2.description, p1.roll_id, p1.stand_id, round(p1.dia,2) as DIA, round(LENGTH,2) as LENGTH, round(p1.weight,2) as WEIGHT from roll_coils p1, roll_pos p2 where p1.roll_id=p2.roll_id and description = 'Backup Roll Bottom' and p1.stand_id= " & stand_val & "")
            Dim ds As DataSet = objDataHandler.GetOracleDataForRollForce(" select distinct slab_id, roll_id, stand_id, round(dia,2) as DIA, round(length,2) as LENGTH,  round(WEIGHT,2) as WEIGHT from  roll_coils where roll_pos = 1 and roll_type = 1 and stand_id =  " & stand_val & " ")
            Return ds.Tables(0)
        Catch ex As Exception
            Throw New Exception(ex.ToString)
        End Try
    End Function
    Function oradataWorkRollTop(ByVal startDate As DateTime, ByVal endDate As DateTime, ByVal stand_val As Integer) As DataTable
        Try
            ' Dim ds As DataSet = objDataHandler.GetOracleDataForRollForce("select distinct p1.slab_id,p2.description, p1.roll_id, p1.stand_id, round(p1.dia,2) as DIA, round(LENGTH,2) as LENGTH, round(p1.weight,2) as WEIGHT from roll_coils p1, roll_pos p2 where p1.roll_id=p2.roll_id and description = 'Work Roll Top' and p1.stand_id= " & stand_val & "")
            Dim ds As DataSet = objDataHandler.GetOracleDataForRollForce(" select distinct slab_id, roll_id, stand_id, round(dia,2) as DIA, round(length,2) as LENGTH,  round(WEIGHT,2) as WEIGHT from  roll_coils where roll_pos = 0 and roll_type = 0 and stand_id =  " & stand_val & " ")
            Return ds.Tables(0)
        Catch ex As Exception
            Throw New Exception(ex.ToString)
        End Try
    End Function
    Function oradataWorkRollBottom(ByVal startDate As DateTime, ByVal endDate As DateTime, ByVal stand_val As Integer) As DataTable
        Try
            ' Dim ds As DataSet = objDataHandler.GetOracleDataForRollForce("select distinct p1.slab_id,p2.description, p1.roll_id, p1.stand_id, round(p1.dia,2) as DIA, round(LENGTH,2) as LENGTH, round(p1.weight,2) as WEIGHT from roll_coils p1, roll_pos p2 where p1.roll_id=p2.roll_id and description = 'Work Roll Bottom' and p1.stand_id= " & stand_val & "")
            Dim ds As DataSet = objDataHandler.GetOracleDataForRollForce(" select distinct slab_id, roll_id, stand_id, round(dia,2) as DIA, round(length,2) as LENGTH,  round(WEIGHT,2) as WEIGHT from  roll_coils where roll_pos = 1 and roll_type = 0 and stand_id =  " & stand_val & " ")
            Return ds.Tables(0)
        Catch ex As Exception
            Throw New Exception(ex.ToString)
        End Try
    End Function
 Function oradataRBD_Toolbox_TSCR(ByVal startDate As DateTime, ByVal endDate As DateTime) As DataTable
        Try
            Dim ds As DataTable = objDataHandler.GetOracleDataRBD_Toolbox(" select t2.bdecoilid as COILID, to_char(t2.endtime,'YYYY-MM-DD HH24:MI') as Prod_Date,avg(t2.length/1000) as Coil_length,avg(t2.width/1000) as Coil_width,avg(t1.class) as Defect_code,round((sum(t1.sizecd)/1000/avg(t2.width/1000)) * 100,1) as Width_Affected_pct,round((sum(t1.sizemd)/1000/avg(t2.length/1000))*100,1) as Length_Affected_pct,round((sum(t1.sizecd * t1.sizemd)/1000/1000/avg (t2.length*t2.width/1000/1000))*100,2) as Area_Affected_pct from intsisdba.t_tscr_defects t1, intsisdba.t_tscr_coils t2 where t1.coilid = t2.coilid and t1.class in ('75','76','77','104') and t2.endtime between to_date('" & startDate & "','DD-MM-YY HH24:MI') and to_date('" & endDate & "','DD-MM-YY HH24:MI') and t1.side = 0 group by  t2.bdecoilid,t2.endtime order by t2.endtime")
            Return ds
        Catch ex As Exception
            Throw New Exception(ex.ToString)
        End Try
   End Function

    Function oradataRBD_Toolbox_TSCR1(ByVal startDate As DateTime, ByVal endDate As DateTime) As DataTable
        Try
            Dim ds As DataTable = objDataHandler.GetOracleDataRBD_Toolbox(" select t2.bdecoilid as COILID, to_char(t2.endtime,'YYYY-MM-DD HH24:MI') as Prod_Date,avg(t2.length/1000) as Coil_length,avg(t2.width/1000) as Coil_width,avg(t1.class) as Defect_code,round((sum(t1.sizecd)/1000/avg(t2.width/1000)) * 100,1) as Width_Affected_pct,round((sum(t1.sizemd)/1000/avg(t2.length/1000))*100,1) as Length_Affected_pct,round((sum(t1.sizecd * t1.sizemd)/1000/1000/avg (t2.length*t2.width/1000/1000))*100,2) as Area_Affected_pct from intsisdba.t_tscr_defects t1, intsisdba.t_tscr_coils t2 where t1.coilid = t2.coilid and t1.class in ('75','76','77','104') and t2.endtime between to_date('" & startDate & "','DD-MM-YY HH24:MI') and to_date('" & endDate & "','DD-MM-YY HH24:MI') and t1.side = 1 group by  t2.bdecoilid,t2.endtime order by t2.endtime")
            Return ds
        Catch ex As Exception
            Throw New Exception(ex.ToString)
        End Try
    End Function
End Class
