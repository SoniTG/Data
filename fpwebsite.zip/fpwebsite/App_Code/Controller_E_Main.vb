﻿
Imports Microsoft.VisualBasic
Imports System.Data
Imports OfficeOpenXml
Imports System.IO


Public Class Controller_E_Main

    Dim objDataHandler As New DataHandler

    Private _iIf As String

    Public Function SaveAndRetrievePageHits(ByVal LoginTime As String, ByVal PageName As String) As Integer
        Dim count As Integer = 0
        Dim REFDATE As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff")
        If Not objDataHandler.CheckRecordsIn("PAGE_HIT_DTLS", "PAGE_NAME", "TIMESTAMP='" & REFDATE & "' and PAGE_NAME='" & PageName & "'") Then
            objDataHandler.RunSimpleQuery("insert into PAGE_HIT_DTLS values('" & PageName & "','" & REFDATE & "',NULL)")
        End If
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select TIMESTAMP from PAGE_HIT_DTLS where PAGE_NAME= '" & PageName & "'").Tables(0)

        ' Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT TIMESTAMP FROM PAGE_HIT_DTLS WHERE PAGE_NAME IN ('dashboard.aspx','lfctoolbox.aspx','Summarylfctoolbox.aspx')").Tables(0)
        count = IIf(dt.Rows.Count = 0, 0, dt.Rows.Count)
        Return count
    End Function
    Public Function GetDashboardData(ByVal TableName As String, ByVal DateColumnName As String, ByVal YValue As String, ByVal FromDate As Date, ByVal ToDate As Date, Optional ByVal filter As String = "") As DataTable
        Try
            Dim sourceTable As String = TableName
            Dim query As String = "Select " & DateColumnName & "," & YValue & " from " & sourceTable & " where   [CCS_PARAM_NAME] = 'TR_MANDREL_COL' and " & DateColumnName & " between '" & Format(FromDate, "yyyy-MM-dd HH:mm:ss") & "' and '" & Format(ToDate, "yyyy-MM-dd HH:mm:ss") & "' " & filter & " order by " & DateColumnName & " desc " & vbCrLf
            Return objDataHandler.GetDataSetFromQuery_CRM_EUIP(query).Tables(0)
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

    End Function
    Public Function GetDashboardData1(ByVal TableName As String, ByVal DateColumnName As String, ByVal YValue As String, ByVal FromDate As Date, ByVal ToDate As Date, Optional ByVal filter As String = "") As DataTable
        Try
            Dim sourceTable As String = TableName
            Dim query As String = "Select " & DateColumnName & "," & YValue & " from " & sourceTable & " where   [CCS_PARAM_NAME] = 'TR_MANDREL_EXP' and " & DateColumnName & " between '" & Format(FromDate, "yyyy-MM-dd HH:mm:ss") & "' and '" & Format(ToDate, "yyyy-MM-dd HH:mm:ss") & "' " & filter & " order by " & DateColumnName & " desc " & vbCrLf 
            Return objDataHandler.GetDataSetFromQuery_CRM_EUIP(query).Tables(0)
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

    End Function

    Public Function GetDashboardData2(ByVal TableName As String, ByVal DateColumnName As String, ByVal YValue As String, ByVal FromDate As Date, ByVal ToDate As Date, Optional ByVal filter As String = "") As DataTable
        Try
            Dim sourceTable As String = TableName
            Dim query As String = "Select " & DateColumnName & "," & YValue & " from " & sourceTable & " where   [CCS_PARAM_NAME] = 'BLT_WRAPR_OUT' and " & DateColumnName & " between '" & Format(FromDate, "yyyy-MM-dd HH:mm:ss") & "' and '" & Format(ToDate, "yyyy-MM-dd HH:mm:ss") & "' " & filter & " order by " & DateColumnName & " desc " & vbCrLf


            Return objDataHandler.GetDataSetFromQuery_CRM_EUIP(query).Tables(0)
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

    End Function
    Public Function GetDashboardData3(ByVal TableName As String, ByVal DateColumnName As String, ByVal YValue As String, ByVal FromDate As Date, ByVal ToDate As Date, Optional ByVal filter As String = "") As DataTable
        Try
            Dim sourceTable As String = TableName
            Dim query As String = "Select " & DateColumnName & "," & YValue & " from " & sourceTable & " where   [CCS_PARAM_NAME] = 'BR8_SNBR_OPN' and " & DateColumnName & " between '" & Format(FromDate, "yyyy-MM-dd HH:mm:ss") & "' and '" & Format(ToDate, "yyyy-MM-dd HH:mm:ss") & "' " & filter & " order by " & DateColumnName & " desc " & vbCrLf

            Return objDataHandler.GetDataSetFromQuery_CRM_EUIP(query).Tables(0)
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

    End Function
   
    Public Sub PlotLineChart(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal YAxisLabelName As String, Optional ByVal tickoption As String = "")
        ' Try

        LiteralName.Text = ""
        Dim min_time, max_time As String
        min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-30), "yyyy-MM-dd HH:mm")
        max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm")

        Dim xTimestampVal(), yVal() As String

        xTimestampVal = (From row In dt Select col = row(XAxisColName).ToString).ToArray
        yVal = (From row In dt Select col = row(YAxisColName).ToString).ToArray

        Dim y_min As String = Math.Floor(yVal.Min() - (yVal.Min() * 0.1))

        Dim y_max As String = Math.Floor(yVal.Max() + (yVal.Max() * 0.1))


        Dim min_t As Double = dt.Compute("min(" & YAxisColName & ")", "")
        Dim max_t As Double = dt.Compute("max(" & YAxisColName & ")", "")

        y_min = Math.Floor(min_t - (min_t * 0.1))
        y_max = Math.Floor(max_t + (max_t * 0.1))
        Dim data As String = Nothing
        Dim date_val As String = Nothing
        For I As Integer = 0 To dt.Rows.Count - 1
            data &= dt.Rows(I)("CCSA_PARAM_VAL") & ","
            date_val &= "'" & dt.Rows(I)("CCS_DATETIME") & "',"
        Next


        '' dv.Item(0)("lenseverity")
        Dim s As New StringBuilder("<script>")

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        s.Append(" var myChart = echarts.init(document.getElementById('" & ContainerName & "'));")

        s.Append("option = {")
        's.Append("title: {")
        's.Append("text: ' '")
        's.Append("},")
        's.Append("tooltip: {")
        's.Append("trigger: 'axis'")
        's.Append("},")
        's.Append("legend: {")
        's.Append("data: ['legend']")
        's.Append("},")
        's.Append("grid: {")
        's.Append("left: '3%',")
        's.Append("right: '4%',")
        's.Append("bottom: '3%',")
        's.Append("containLabel: true")
        's.Append("},")
        's.Append("toolbox: {")
        's.Append("feature: {")
        's.Append("dataZoom: {")
        's.Append("yAxisIndex: 'none'")
        's.Append("},")
        's.Append("restore: {},")
        's.Append("saveAsImage: {}")
        's.Append("}")
        's.Append("},")
        's.Append("xAxis: {")
        's.Append("type: 'category',")
        's.Append("boundaryGap: false,")
        's.Append("data: [" & date_val & "]")
        's.Append("},")
        's.Append("yAxis: {")
        's.Append("type: 'value'")
        's.Append("},")
        's.Append("series: [")
        's.Append("{")
        's.Append("type: 'line',")
        's.Append("stack: 'temp',")
        's.Append("data: [" & data & "]")
        's.Append("},")

        's.Append("]")
        's.Append("};")
        s.Append("title: {")
        s.Append("text: ''")
        s.Append("},")
        s.Append("tooltip: {")
        s.Append("trigger: 'axis'")
        s.Append("},")
        s.Append("xAxis: {")
        s.Append("data: [" & date_val & "]")
        s.Append("},")
        s.Append("yAxis: {")
        s.Append("splitLine: {")
        s.Append("show: false")
        s.Append("}")
        s.Append("},")
        s.Append("toolbox: {")
        s.Append("left: 'center',")
        s.Append("feature: {")
        s.Append("dataZoom: {")
        s.Append("yAxisIndex: 'none'")
        s.Append("},")
        s.Append("restore: {},")
        s.Append("saveAsImage: {}")
        s.Append("}")
        s.Append("},")
        s.Append("dataZoom: [{")
        s.Append("startValue: '2020-04-01'")
        s.Append("}, {")
        s.Append("type: 'inside'")
        s.Append("}],")

        s.Append("series: [")
        s.Append("{")
        s.Append("type: 'line',")
        s.Append("stack: 'temp',")
        s.Append("data: [" & data & "]")
        s.Append("},")

        s.Append("]")
        s.Append("};")

        s.Append(" myChart.setOption(option);")
        s.Append("</script>")
        LiteralName.Text = s.ToString()


        'Catch ex As Exception

        'End Try
    End Sub





    '=====================================================================
    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    ' DYNAMIC DATA (newLiveStroke)

    Public Sub PlotLineEChart(ByVal dt As DataTable, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal dtime As DateTime)
        ' Try

        LiteralName.Text = ""

        Dim data As String = Nothing
        Dim date_val As String = Nothing
        For I As Integer = 0 To dt.Rows.Count - 1
            data &= dt.Rows(I)("CCSA_PARAM_VAL") & ","
            date_val &= "'" & dt.Rows(I)("CCS_DATETIME") & "',"
        Next


        '' dv.Item(0)("lenseverity")
        Dim s As New StringBuilder("<script>")

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        s.Append(" var myChart = echarts.init(document.getElementById('" & ContainerName & "'));")

        s.Append("option = {")
        's.Append("title: {")
        's.Append("text: ' '")
        's.Append("},")
        's.Append("tooltip: {")
        's.Append("trigger: 'axis'")
        's.Append("},")
        's.Append("legend: {")
        's.Append("data: ['legend']")
        's.Append("},")
        's.Append("grid: {")
        's.Append("left: '3%',")
        's.Append("right: '4%',")
        's.Append("bottom: '3%',")
        's.Append("containLabel: true")
        's.Append("},")
        's.Append("toolbox: {")
        's.Append("feature: {")
        's.Append("dataZoom: {")
        's.Append("yAxisIndex: 'none'")
        's.Append("},")
        's.Append("restore: {},")
        's.Append("saveAsImage: {}")
        's.Append("}")
        's.Append("},")
        's.Append("xAxis: {")
        's.Append("type: 'category',")
        's.Append("boundaryGap: false,")
        's.Append("data: [" & date_val & "]")
        's.Append("},")
        's.Append("yAxis: {")
        's.Append("type: 'value'")
        's.Append("},")
        's.Append("series: [")
        's.Append("{")
        's.Append("type: 'line',")
        's.Append("stack: 'temp',")
        's.Append("data: [" & data & "]")
        's.Append("},")

        's.Append("]")
        's.Append("};")
        s.Append("title: {")
        s.Append("text: ''")
        s.Append("},")
        s.Append("tooltip: {")
        s.Append("trigger: 'axis'")
        s.Append("},")
        s.Append("xAxis: {")
        s.Append("data: [" & date_val & "]")
        s.Append("},")
        s.Append("yAxis: {")
        s.Append("splitLine: {")
        s.Append("show: false")
        s.Append("}")
        s.Append("},")
        s.Append("toolbox: {")
        s.Append("left: 'center',")
        s.Append("feature: {")
        s.Append("dataZoom: {")
        s.Append("yAxisIndex: 'none'")
        s.Append("},")
        s.Append("restore: {},")
        s.Append("saveAsImage: {}")
        s.Append("}")
        s.Append("},")
        s.Append("dataZoom: [{")
        s.Append("startValue: '" & dtime & "' ")
        s.Append("}, {")
        s.Append("type: 'inside'")
        s.Append("}],")

        s.Append("series: [")
        s.Append("{")
        s.Append("type: 'line',")
        s.Append("stack: 'temp',")
        s.Append("data: [" & data & "]")
        s.Append("},")

        s.Append("]")
        s.Append("};")

        s.Append(" myChart.setOption(option);")
        s.Append("</script>")
        LiteralName.Text = s.ToString()


        'Catch ex As Exception

        'End Try
    End Sub

    Public Function GetDynamicHeaderEXIT() As DataTable
        Try

            Return objDataHandler.GetDataSetFromQuery_CRM_EUIP(" SELECT * from [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_CGL2_STROKETIME_LIMITS] where ltrim(rtrim(CSL_SIGNAL_GROUP)) = 'Exit'  order by CSL_Seq_No").Tables(0)




        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Function

    Public Function PopulaleDynamiclineDataEXIT(ByVal FromDt As String, ByVal ToDt As String) As DataTable
        Try
            'Return objDataHandler.GetDataSetFromQuery("select [CCS_DATETIME] ,[CCS_PARAM_NAME],[CCSA_PARAM_VAL]  FROM [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_CGL2_STROKETIME_DATA]   order by [CCS_DATETIME]").Tables(0)


            ' Return objDataHandler.GetDataSetFromQuery("  select [CCS_DATETIME],[CCS_PARAM_NAME]  ,[CCSA_PARAM_VAl]   FROM [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_CGL2_STROKETIME_DATA]  where CCS_DATETIME   between '" & Convert.ToDateTime(FromDt).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(ToDt).ToString("yyyy-MM-dd HH:mm:ss") & "' order by [CCS_DATETIME]").Tables(0)

            Return objDataHandler.GetDataSetFromQuery_CRM_EUIP(" SELECT [CRM_CGL2_STROKETIME_DATA].ccs_param_name, [CRM_CGL2_STROKETIME_LIMITS].[CSL_PARAM_ALIAS], [CRM_CGL2_STROKETIME_DATA].[CCS_DATETIME],  [CRM_CGL2_STROKETIME_DATA].[CCSA_PARAM_VAL], [CRM_CGL2_STROKETIME_LIMITS].[CSL_SIGNAL_GROUP] FROM [CRM_CGL2_STROKETIME_DATA] INNER JOIN [CRM_CGL2_STROKETIME_LIMITS] ON [CRM_CGL2_STROKETIME_DATA].[CCS_PARAM_NAME]=[CRM_CGL2_STROKETIME_LIMITS].[CSL_PARAM_ALIAS] where CCS_DATETIME   between '" & Convert.ToDateTime(FromDt).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(ToDt).ToString("yyyy-MM-dd HH:mm:ss") & "' and ltrim(rtrim(CSL_SIGNAL_GROUP)) = 'Exit'  order by [CCS_DATETIME]").Tables(0)




        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Function
    Public Function GetDynamicHeaderENTRY() As DataTable
        Try

            Return objDataHandler.GetDataSetFromQuery_CRM_EUIP(" SELECT * from [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_CGL2_STROKETIME_LIMITS] where ltrim(rtrim(CSL_SIGNAL_GROUP)) = 'Entry Way1'  order by CSL_Seq_No").Tables(0)




        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Function

    Public Function PopulaleDynamiclineDataENTRY(ByVal FromDt As String, ByVal ToDt As String) As DataTable
        Try
            'Return objDataHandler.GetDataSetFromQuery("select [CCS_DATETIME] ,[CCS_PARAM_NAME],[CCSA_PARAM_VAL]  FROM [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_CGL2_STROKETIME_DATA]   order by [CCS_DATETIME]").Tables(0)


            ' Return objDataHandler.GetDataSetFromQuery("  select [CCS_DATETIME],[CCS_PARAM_NAME]  ,[CCSA_PARAM_VAl]   FROM [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_CGL2_STROKETIME_DATA]  where CCS_DATETIME   between '" & Convert.ToDateTime(FromDt).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(ToDt).ToString("yyyy-MM-dd HH:mm:ss") & "' order by [CCS_DATETIME]").Tables(0)

            Return objDataHandler.GetDataSetFromQuery_CRM_EUIP(" SELECT [CRM_CGL2_STROKETIME_DATA].ccs_param_name, [CRM_CGL2_STROKETIME_LIMITS].[CSL_PARAM_ALIAS], [CRM_CGL2_STROKETIME_DATA].[CCS_DATETIME],  [CRM_CGL2_STROKETIME_DATA].[CCSA_PARAM_VAL], [CRM_CGL2_STROKETIME_LIMITS].[CSL_SIGNAL_GROUP] FROM [CRM_CGL2_STROKETIME_DATA] INNER JOIN [CRM_CGL2_STROKETIME_LIMITS] ON [CRM_CGL2_STROKETIME_DATA].[CCS_PARAM_NAME]=[CRM_CGL2_STROKETIME_LIMITS].[CSL_PARAM_ALIAS] where CCS_DATETIME   between '" & Convert.ToDateTime(FromDt).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(ToDt).ToString("yyyy-MM-dd HH:mm:ss") & "' and LTRIM(RTRIM(CSL_SIGNAL_GROUP)) = 'Entry Way1'  order by [CCS_DATETIME]").Tables(0)




        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Function

    Public Function GetDynamicHeaderENTRY2() As DataTable
        Try

            Return objDataHandler.GetDataSetFromQuery_CRM_EUIP(" SELECT * from [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_CGL2_STROKETIME_LIMITS] where ltrim(rtrim(CSL_SIGNAL_GROUP)) = 'Entry Way2'  order by CSL_Seq_No").Tables(0)




        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Function


    Public Function PopulaleDynamiclineDataENTRYWAY2(ByVal FromDt As String, ByVal ToDt As String) As DataTable
        Try
            'Return objDataHandler.GetDataSetFromQuery("select [CCS_DATETIME] ,[CCS_PARAM_NAME],[CCSA_PARAM_VAL]  FROM [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_CGL2_STROKETIME_DATA]   order by [CCS_DATETIME]").Tables(0)


            ' Return objDataHandler.GetDataSetFromQuery("  select [CCS_DATETIME],[CCS_PARAM_NAME]  ,[CCSA_PARAM_VAl]   FROM [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_CGL2_STROKETIME_DATA]  where CCS_DATETIME   between '" & Convert.ToDateTime(FromDt).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(ToDt).ToString("yyyy-MM-dd HH:mm:ss") & "' order by [CCS_DATETIME]").Tables(0)

            Return objDataHandler.GetDataSetFromQuery_CRM_EUIP(" SELECT [CRM_CGL2_STROKETIME_DATA].ccs_param_name, [CRM_CGL2_STROKETIME_LIMITS].[CSL_PARAM_ALIAS], [CRM_CGL2_STROKETIME_DATA].[CCS_DATETIME],  [CRM_CGL2_STROKETIME_DATA].[CCSA_PARAM_VAL], [CRM_CGL2_STROKETIME_LIMITS].[CSL_SIGNAL_GROUP] FROM [CRM_CGL2_STROKETIME_DATA] INNER JOIN [CRM_CGL2_STROKETIME_LIMITS] ON [CRM_CGL2_STROKETIME_DATA].[CCS_PARAM_NAME]=[CRM_CGL2_STROKETIME_LIMITS].[CSL_PARAM_ALIAS] where CCS_DATETIME   between '" & Convert.ToDateTime(FromDt).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(ToDt).ToString("yyyy-MM-dd HH:mm:ss") & "' and ltrim(rtrim(CSL_SIGNAL_GROUP)) = 'Entry Way2'  order by [CCS_DATETIME]").Tables(0)




        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Function


    Public Function GetDynamicHeaderCOMMON() As DataTable
        Try

            Return objDataHandler.GetDataSetFromQuery_CRM_EUIP(" SELECT * from [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_CGL2_STROKETIME_LIMITS] where ltrim(rtrim(CSL_SIGNAL_GROUP)) = 'Common Way'  order by CSL_Seq_No").Tables(0)




        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Function


    Public Function PopulaleDynamiclineDataCOMMONWAY(ByVal FromDt As String, ByVal ToDt As String) As DataTable
        Try
            'Return objDataHandler.GetDataSetFromQuery("select [CCS_DATETIME] ,[CCS_PARAM_NAME],[CCSA_PARAM_VAL]  FROM [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_CGL2_STROKETIME_DATA]   order by [CCS_DATETIME]").Tables(0)


            ' Return objDataHandler.GetDataSetFromQuery("  select [CCS_DATETIME],[CCS_PARAM_NAME]  ,[CCSA_PARAM_VAl]   FROM [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_CGL2_STROKETIME_DATA]  where CCS_DATETIME   between '" & Convert.ToDateTime(FromDt).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(ToDt).ToString("yyyy-MM-dd HH:mm:ss") & "' order by [CCS_DATETIME]").Tables(0)

            Return objDataHandler.GetDataSetFromQuery_CRM_EUIP(" SELECT [CRM_CGL2_STROKETIME_DATA].ccs_param_name, [CRM_CGL2_STROKETIME_LIMITS].[CSL_PARAM_ALIAS], [CRM_CGL2_STROKETIME_DATA].[CCS_DATETIME],  [CRM_CGL2_STROKETIME_DATA].[CCSA_PARAM_VAL], [CRM_CGL2_STROKETIME_LIMITS].[CSL_SIGNAL_GROUP] FROM [CRM_CGL2_STROKETIME_DATA] INNER JOIN [CRM_CGL2_STROKETIME_LIMITS] ON [CRM_CGL2_STROKETIME_DATA].[CCS_PARAM_NAME]=[CRM_CGL2_STROKETIME_LIMITS].[CSL_PARAM_ALIAS] where CCS_DATETIME   between '" & Convert.ToDateTime(FromDt).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(ToDt).ToString("yyyy-MM-dd HH:mm:ss") & "' and ltrim(rtrim(CSL_SIGNAL_GROUP)) = 'Common Way'  order by [CCS_DATETIME]").Tables(0)




        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Function






   



    Public Function UpdateDailyReportData(ByVal Alarm_date As String, ByVal Action_Taken As String, ByVal Action_By As String, ByVal Action_On As String, ByVal Remark As String, ByVal ddlcylinder As DropDownList, ByVal subdiv As String) As Integer
        ' Dim query As String = "update [CRM_MECH_MAINT_INTERVENTION] set  ALARM_DATE = '" & Alarm_date & "' , ACTION_TAKEN = '" & Action_Taken & "' , Action_by = '" & Action_By & "' , action_on = '" & Action_On & "' , remark = '" & Remark & "' WHERE Alarm_date = '" & Alarm_date & "'"
        Dim query As String = "IF EXISTS (SELECT * FROM CRM_MECH_MAINT_INTERVENTION WHERE ALARM_DATE='" & Alarm_date & "' AND EQUIP_NAME='" & ddlcylinder.SelectedItem.Value & "') begin UPDATE [CRM_MECH_MAINT_INTERVENTION] SET   ALARM_DATE = '" & Alarm_date & "'  , ACTION_TAKEN = '" & Action_Taken & "' , Action_by = '" & Action_By & "' , action_on = '" & Action_On & "'  , remark = '" & Remark & "' where ALARM_DATE='" & Alarm_date & "' AND EQUIP_NAME='" & ddlcylinder.SelectedItem.Value & "' end else begin insert into CRM_MECH_MAINT_INTERVENTION values ('" & subdiv & "','" & ddlcylinder.SelectedItem.Value & "','" & Alarm_date & "','" & Action_Taken & "','" & Action_By & "','" & Action_On & "','" & Remark & "') end"

        Return objDataHandler.RunSimpleQueryEQUIP(query)
    End Function
    Public Function FunSubmit(ByVal SUB_DIVISION As String, ByVal EQUIP_NAME As String) As Integer
        Try
            objDataHandler.GetDataSetFromQuery_CRM_EUIP("insert into  [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_MECH_MAINT_INTERVENTION]([SUB_DIVISION],[EQUIP_NAME]) values('" & SUB_DIVISION & "','" & EQUIP_NAME & "'); " & vbCrLf)

        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

    End Function



    Public Sub PopulateCylinder(ByVal GradeDropDown As DropDownList, ByVal FromDate As String, ByVal ToDate As String)
        Try
            GradeDropDown.DataSource = objDataHandler.GetDataSetFromQuery_CRM_EUIP("SELECT distinct [CSA_PARAM_NAME]  FROM [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_CGL2_STROKETIME_ALARM] where [CSA_DATETIME] between '" & FromDate & "' and '" & ToDate & "' ORDER BY [CSA_PARAM_NAME]").Tables(0)
            GradeDropDown.DataTextField = "CSA_PARAM_NAME"
            GradeDropDown.DataValueField = "CSA_PARAM_NAME"
            GradeDropDown.DataBind()
            GradeDropDown.Items.Insert(0, "SELECT")
            GradeDropDown.SelectedIndex = 0
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try


    End Sub




    Public Sub FnGetDataFromQuery1(ByVal ddl As DropDownList)
        Try
            'ddl.DataSource = objDataHandler.GetDataSetFromQuery_CRM_EUIP("SELECT distinct SUB_DIVISION from CRM_MECH_MAINT_INTERVENTION").Tables(0)
            'ddl.DataTextField = "SUB_DIVISION"
            'ddl.DataValueField = "SUB_DIVISION"
            'ddl.DataBind()
            ddl.Items.Insert(0, "CGL2")
            ddl.Items.Insert(1, "PLTCM")

            ddl.SelectedIndex = 0
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try


    End Sub





    Public Sub PopulateDailyReportData(ByVal Query As String, ByVal gvDetails As GridView)
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery_CRM_EUIP(Query).Tables(0)
        If dt.Rows.Count > 0 Then
            gvDetails.DataSource = dt
            gvDetails.DataBind()
            gvDetails.UseAccessibleHeader = True
            gvDetails.HeaderRow.TableSection = TableRowSection.TableHeader
        End If
    End Sub








    Public Sub PopulateDetails(ByVal startdatetime As String, ByVal endDatetime As String, ByVal gdvdetail As GridView, ByVal ddl_cylinder As DropDownList)


        Dim table As New DataTable
        table.Columns.Add("ALARM_DATE")
        table.Columns.Add("ACTION_TAKEN")
        table.Columns.Add("ACTION_BY")
        table.Columns.Add("ACTION_ON")
        table.Columns.Add("REMARK")



        Dim sqlQuery As String = "  SELECT [CRM_CGL2_STROKETIME_ALARM].csa_param_name, [CRM_MECH_MAINT_INTERVENTION].[EQUIP_NAME], [CRM_CGL2_STROKETIME_ALARM].[CSA_DATETIME] as 'ALARM_DATE', ACTION_TAKEN as 'ACTION_TAKEN', ACTION_BY AS 'ACTION_BY',  ACTION_ON AS 'ACTION_ON' , REMARK AS'REMARK'     FROM [CRM_CGL2_STROKETIME_ALARM] left outer JOIN 	 [CRM_MECH_MAINT_INTERVENTION] ON [CRM_CGL2_STROKETIME_ALARM].[Csa_PARAM_NAME]=[CRM_MECH_MAINT_INTERVENTION].[EQUIP_NAME] and csa_datetime=alarm_date  where Csa_PARAM_NAME = '" & ddl_cylinder.SelectedValue & "' order by [Csa_DATETIME] desc"


        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery_CRM_EUIP(sqlQuery).Tables(0)

        If dt.Rows.Count > 0 Then
            For i As Integer = 0 To dt.Rows.Count - 1
                Dim row As DataRow = table.NewRow

                row("ALARM_DATE") = dt.Rows(i)("ALARM_DATE")

                row("ACTION_TAKEN") = dt.Rows(i)("ACTION_TAKEN")
                row("ACTION_TAKEN") = dt.Rows(i)("ACTION_TAKEN")
                row("ACTION_BY") = dt.Rows(i)("ACTION_BY")

                row("ACTION_ON") = dt.Rows(i)("ACTION_ON")
                row("REMARK") = dt.Rows(i)("REMARK")

                table.Rows.Add(row)

            Next
            gdvdetail.DataSource = table
        End If
        gdvdetail.DataBind()
        If gdvdetail.Rows.Count > 0 Then
            gdvdetail.UseAccessibleHeader = True
            gdvdetail.HeaderRow.TableSection = TableRowSection.TableHeader
        End If
    End Sub

End Class
