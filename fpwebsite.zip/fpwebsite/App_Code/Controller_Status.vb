﻿Imports Microsoft.VisualBasic
Imports System.Data
Imports OfficeOpenXml
Imports System.IO
Public Class Controller_Status
    Dim objDataHandler As New DataHandler
    ' Dim objDataHandler1 As New DataHandler_hsm
    Private _iIf As String



    Public Function IsValidDateRange(ByVal txtFrom As TextBox, ByVal txtTo As TextBox) As Boolean
        Dim var As Boolean = False
        If DateTime.Compare(txtFrom.Text, txtTo.Text) < 1 Then
            var = True
        End If
        Return var

    End Function
    'Public Function SaveAndRetrievePageHits(ByVal LoginTime As String, ByVal PageName As String) As Integer
    '    Dim count As Integer = 0
    '    If Not objDataHandler.CheckRecordsIn("PAGE_HIT_DTLS", "PAGE_NAME", "TIMESTAMP='" & LoginTime & "' and PAGE_NAME='" & PageName & "'") Then
    '        objDataHandler.RunSimpleQuery("insert into PAGE_HIT_DTLS values('" & PageName & "','" & LoginTime & "')")
    '    End If
    '    Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select TIMESTAMP from PAGE_HIT_DTLS where PAGE_NAME= '" & PageName & "'").Tables(0)

    '    ' Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT TIMESTAMP FROM PAGE_HIT_DTLS WHERE PAGE_NAME IN ('dashboard.aspx','lfctoolbox.aspx','Summarylfctoolbox.aspx')").Tables(0)
    '    count = IIf(dt.Rows.Count = 0, 0, dt.Rows.Count)
    '    Return count
    'End Function
    Public Function SaveAndRetrievePageHits(ByVal LoginTime As String, ByVal PageName As String) As Integer
        Dim count As Integer = 0
        
        Return count
    End Function

    Public Sub Populate_Status(ByVal StatusDropDown As DropDownList)
        Try
            StatusDropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct [DDT_STATUS] FROM [FP_PROCESS_DATA].[dbo].[T_DPCR_DATA_TIMELINE]  ORDER BY DDT_STATUS").Tables(0)
            StatusDropDown.DataTextField = "DDT_STATUS"
            StatusDropDown.DataValueField = "DDT_STATUS"
            StatusDropDown.DataBind()
            StatusDropDown.Items.Insert(0, "All")
            StatusDropDown.SelectedIndex = 0
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try


    End Sub

    Public Sub Populate_ProductSegment(ByVal Product_SegmentDropDown As DropDownList)
        Try
            Product_SegmentDropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct [DDT_PRODUCT_SEGMENT] FROM [FP_PROCESS_DATA].[dbo].[T_DPCR_DATA_TIMELINE]  ORDER BY DDT_PRODUCT_SEGMENT").Tables(0)
            Product_SegmentDropDown.DataTextField = "DDT_PRODUCT_SEGMENT"
            Product_SegmentDropDown.DataValueField = "DDT_PRODUCT_SEGMENT"
            Product_SegmentDropDown.DataBind()
            Product_SegmentDropDown.Items.Insert(0, "All")
            Product_SegmentDropDown.SelectedIndex = 0
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try


    End Sub

    Public Sub Populate_PendingAgency(ByVal PendingAgencyDropDown As DropDownList)
        Try
            PendingAgencyDropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct [DDT_ORIGIN_PLANT] FROM [FP_PROCESS_DATA].[dbo].[T_DPCR_DATA_TIMELINE]  ORDER BY [DDT_ORIGIN_PLANT]").Tables(0)
            PendingAgencyDropDown.DataTextField = "DDT_ORIGIN_PLANT"
            PendingAgencyDropDown.DataValueField = "DDT_ORIGIN_PLANT"
            PendingAgencyDropDown.DataBind()
            PendingAgencyDropDown.Items.Insert(0, "All")
            PendingAgencyDropDown.SelectedIndex = 0
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try


    End Sub

    Function getDataForDPCR(ByVal filter As String) As DataTable
        '       Dim q As String = "SELECT ddt_dpcr_id,datediff(DAY,DDT_LOGGED_DATE,GETDATE()) AS TARGET1_PD,(DDT_CPAG_DAYS) as CPAG_Days,datediff(DAY,DDT_CPAG_FORWARDING_DATE,GETDATE()) AS TARGET2_PD,[DDT_ORIGIN_INV_DAYS] as Origin_days,[DDT_ORIGIN_PLANT] as OriginPlant," & _
        ' " [DDT_DETECTION_INV_DAYS] as DetectionDays,[DDT_DETECTION_PLANT] as DetectionPlant,datediff(DAY,DDT_CENTRAL_PAG_SUMMARY_DATE,GETDATE()) AS TARGET4_PD,[DDT_CENTRAL_PAG_SUMMARY_DAYS] as CPAG_Summ_Days," & _
        ' " datediff(DAY,DDT_LOGGED_DATE,[DDT_CENTRAL_PAG_SUMMARY_DATE]) AS TARGET6_PD,[DDT_CLOSE_DAYS] as CloseDays,datediff(DAY,DDT_LOGGED_DATE,[DDT_CLOSE_DATE]) AS TARGET7_PD,[DDT_TOTAL_DAYS] as TotalDays" & _
        '       " FROM [FP_PROCESS_DATA].[dbo].[T_DPCR_DATA_TIMELINE]   WHERE  DatePart(Year, DDT_LOGGED_DATE) > 1990 and DATEPART(YEAR,DDT_CPAG_FORWARDING_DATE)>1990  and DATEPART(YEAR,DDT_CENTRAL_PAG_SUMMARY_DATE)>1990  and DATEPART(YEAR,[DDT_CLOSE_DATE])>1990 and DATEPART(YEAR,DDT_CENTRAL_PAG_SUMMARY_DATE)>1990 " & _
        ' " and len(DDT_CPAG_DAYS)>0 and len([DDT_ORIGIN_INV_DAYS])>0 and len([DDT_DETECTION_INV_DAYS])>0 " & _
        '" and len([DDT_CLOSE_DAYS])>0   and len([DDT_TOTAL_DAYS])>0 " & filter

        Dim q As String = "SELECT ddt_dpcr_id,datediff(DAY,DDT_LOGGED_DATE,GETDATE()) AS TARGET1_PD,(DDT_CPAG_DAYS) as CPAG_Days,CASE WHEN [DDT_ORIGIN_PLANT]=[DDT_DETECTION_PLANT] THEN  CASE WHEN DDT_ORIGIN_INV_DAYS IS NULL THEN CASE WHEN UPPER(DDT_STATUS)='QA PLANT INVESTIGATION' THEN datediff(DAY,DDT_CPAG_FORWARDING_DATE,GETDATE()) ELSE NULL END ELSE	NULL END ELSE 	CASE WHEN DDT_ORIGIN_INV_DAYS IS NULL THEN CASE WHEN UPPER(DDT_STATUS)='DETECTION PLANT INVESTIGATED' THEN datediff(DAY,DDT_CPAG_FORWARDING_DATE,GETDATE())	ELSE	NULL	END	ELSE	NULL	END END AS target2_pd_COND, CASE WHEN [DDT_ORIGIN_PLANT]<>[DDT_DETECTION_PLANT] THEN  	CASE WHEN DDT_ORIGIN_INV_DAYS IS NOT NULL THEN	CASE WHEN UPPER(DDT_STATUS)='Origin plant Investigated' THEN	datediff(DAY,DDT_CPAG_FORWARDING_DATE,GETDATE())	ELSE	NULL	END	ELSE	NULL	END ELSE  CASE WHEN DDT_ORIGIN_INV_DAYS IS NULL THEN	CASE WHEN UPPER(DDT_STATUS)='QA PLANT INVESTIGATION' THEN datediff(DAY,DDT_CPAG_FORWARDING_DATE,GETDATE()) ELSE	NULL	END	ELSE	NULL	END END AS target3_pd_COND," & _
                           " datediff(DAY,DDT_CPAG_FORWARDING_DATE,GETDATE()) AS TARGET2_PD,[DDT_ORIGIN_INV_DAYS] as Origin_days,[DDT_ORIGIN_PLANT] as OriginPlant, [DDT_DETECTION_INV_DAYS] as DetectionDays,[DDT_DETECTION_PLANT] as DetectionPlant,datediff(DAY,DDT_CENTRAL_PAG_SUMMARY_DATE,GETDATE()) AS TARGET4_PD,[DDT_CENTRAL_PAG_SUMMARY_DAYS] as CPAG_Summ_Days, datediff(DAY,DDT_LOGGED_DATE,[DDT_CENTRAL_PAG_SUMMARY_DATE]) AS TARGET6_PD,[DDT_CLOSE_DAYS] as CloseDays,datediff(DAY,DDT_LOGGED_DATE,[DDT_CLOSE_DATE]) AS TARGET7_PD,[DDT_TOTAL_DAYS] as TotalDays FROM [FP_PROCESS_DATA].[dbo].[T_DPCR_DATA_TIMELINE]   WHERE  DatePart(Year, DDT_LOGGED_DATE) > 1990 and DATEPART(YEAR,DDT_CPAG_FORWARDING_DATE)>1990  and DATEPART(YEAR,DDT_CENTRAL_PAG_SUMMARY_DATE)>1990  and DATEPART(YEAR,[DDT_CLOSE_DATE])>1990 and DATEPART(YEAR,DDT_CENTRAL_PAG_SUMMARY_DATE)>1990  and len(DDT_CPAG_DAYS)>0 and len([DDT_ORIGIN_INV_DAYS])>0 and len([DDT_DETECTION_INV_DAYS])>0  and len([DDT_CLOSE_DAYS])>0   and len([DDT_TOTAL_DAYS])>0  " & filter




        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery(q).Tables(0)
        Return dt
    End Function

End Class
