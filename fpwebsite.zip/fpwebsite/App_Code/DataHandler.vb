﻿Imports Microsoft.VisualBasic
Imports System.Data
Imports System.Data.SqlClient
Imports System.Data.OleDb
'Imports Oracle.DataAccess.Client
Imports Oracle.ManagedDataAccess.Client
Imports Google.Cloud.BigQuery.V2
Imports Google.Apis.Auth.OAuth2
Imports System.IO

Public Class DataHandler
    Dim connectionString As String = ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString
    Dim con As New SqlConnection(connectionString)

    Dim CRM_EUIP_CONNECTION As String = ConfigurationManager.ConnectionStrings("CRM_EUIP").ConnectionString
    Dim CONN_CRM_EUIP As New SqlConnection(CRM_EUIP_CONNECTION)
    Dim strConnectionString_Crcw As String = ConfigurationManager.ConnectionStrings("CRCW_Ora").ConnectionString
    Dim Oleconnection_ora_Crcw As New OleDbConnection(strConnectionString_Crcw)
    Dim connectionString_TSK As String = ConfigurationManager.ConnectionStrings("TG-GWL_TSK").ConnectionString
    Dim con_TSK As New SqlConnection(connectionString_TSK)

    Dim OleAdap As New OleDbDataAdapter
    Dim OleCom As New OleDbCommand


Public Function GetDataSetFromQueryGC1(ByVal SelectQuery As String, ByVal ColumnName() As String) As Data.DataSet
        Dim fs As New FileStream(HttpContext.Current.Server.MapPath("~") & "\svc-tskhsmviz-prod.json", FileMode.Open)        'System.AppDomain.CurrentDomain.BaseDirectory & "svc-tskhsmviz-prod.json", FileMode.Open)

        Dim project_id As String = "tsl-datalake"
        project_id = "tsl-datalake-prod"
        Dim client As BigQueryClient = BigQueryClient.Create(project_id, Google.Apis.Auth.OAuth2.GoogleCredential.FromStream(fs))


        Dim ds As New Data.DataSet
        Dim dt As New DataTable
        For i As Integer = 0 To ColumnName.Count - 1
            dt.Columns.Add(ColumnName(i))
        Next

        Try


            Dim result = client.ExecuteQuery(SelectQuery, Nothing)
            For Each Row In result
                'Response.Write(String.Format("{0} and {1}", Row.Item(0), "-") & "\n")
                dt.Rows.Add(Row.Item(0), Row.Item(1), Row.Item(2), Row.Item(3), Row.Item(4), Row.Item(5))
            Next
            ds.Tables.Add(dt)
            'Console.Read()

        Catch ex As Exception
            'CloseConnection()
            Throw New Exception(ex.ToString())
        End Try
        Return ds
    End Function

Public Function GetDataSetFromQueryGCData1(ByVal SelectQuery As String) As Data.DataSet
        Dim fs As New FileStream(HttpContext.Current.Server.MapPath("~") & "\svc-tskhsmviz-prod.json", FileMode.Open)        'System.AppDomain.CurrentDomain.BaseDirectory & "svc-tskhsmviz-prod.json", FileMode.Open)

        Dim project_id As String = "tsl-datalake"
        project_id = "tsl-datalake-prod"
        Dim client As BigQueryClient = BigQueryClient.Create(project_id, Google.Apis.Auth.OAuth2.GoogleCredential.FromStream(fs))

        'Dim jobResource = client.Service.Jobs

        Dim ds As New Data.DataSet
        Dim dt As New DataTable
        dt.TableName = "Table"
        'For i As Integer = 0 To ColumnName.Length - 1
        '    dt.Columns.Add(ColumnName(i))
        'Next
        Try
            'Dim da As New SqlDataAdapter(SelectQuery, con)
            'da.SelectCommand.CommandTimeout = 6000
            'da.Fill(ds)

            Dim result = client.ExecuteQuery(SelectQuery, Nothing)


            Dim fields As List(Of String) = New List(Of String)()

            For Each col In result.Schema.Fields
                fields.Add(col.Name)

            Next

            For i As Integer = 0 To fields.LongCount - 1
                dt.Columns.Add(fields(i))
            Next



            For Each Row In result
                'Response.Write(String.Format("{0} and {1}", Row.Item(0), "-") & "\n")
                'dt.Rows.Add(Double.Parse(Row.Item(0)), Double.Parse(Row.Item(1)))
                Dim dr As DataRow = dt.NewRow

                For i As Integer = 0 To fields.LongCount - 1
                    'dt.Columns.Add(fields(i))
                    dr(i) = Row.Item(i)



                Next
                dt.Rows.Add(dr)
                'dt.Rows.Add(Row.Item())
                'dt.Rows.Add(Row.Item())
                'dt.Rows.Add(Row.Item(0), Row.Item(1), Row.Item(2), Row.Item(3), Row.Item(4))


            Next
            ds.Tables.Add(dt)
            'Console.Read()

        Catch ex As Exception
            'CloseConnection()
            Throw New Exception(ex.ToString())
        End Try
        Return ds
    End Function



Public Function GetDataSetFromQueryGC(ByVal SelectQuery As String, ByVal ColumnName As String) As Data.DataSet
        Dim fs As New FileStream(HttpContext.Current.Server.MapPath("~") & "\svc-tskhsmviz-prod.json", FileMode.Open)        'System.AppDomain.CurrentDomain.BaseDirectory & "svc-tskhsmviz-prod.json", FileMode.Open)

        Dim project_id As String = "tsl-datalake"
        project_id = "tsl-datalake-prod"
        Dim client As BigQueryClient = BigQueryClient.Create(project_id, Google.Apis.Auth.OAuth2.GoogleCredential.FromStream(fs))

        'Dim jobResource = client.Service.Jobs

        Dim ds As New Data.DataSet
        Dim dt As New DataTable
        dt.Columns.Add(ColumnName)
        Try
            'Dim da As New SqlDataAdapter(SelectQuery, con)
            'da.SelectCommand.CommandTimeout = 6000
            'da.Fill(ds)

            Dim result = client.ExecuteQuery(SelectQuery, Nothing)
            For Each Row In result
                'Response.Write(String.Format("{0} and {1}", Row.Item(0), "-") & "\n")
                dt.Rows.Add(Row.Item(0))
            Next
            ds.Tables.Add(dt)
            'Console.Read()

        Catch ex As Exception
            'CloseConnection()
            Throw New Exception(ex.ToString())
        End Try
        Return ds
    End Function

Public Function GetDataSetFromQueryGCThickness(ByVal SelectQuery As String, ByVal ColumnName As String, ByVal ColumnName1 As String) As Data.DataSet
        Dim fs As New FileStream(HttpContext.Current.Server.MapPath("~") & "\svc-tskhsmviz-prod.json", FileMode.Open)        'System.AppDomain.CurrentDomain.BaseDirectory & "svc-tskhsmviz-prod.json", FileMode.Open)

        Dim project_id As String = "tsl-datalake"
        project_id = "tsl-datalake-prod"
        Dim client As BigQueryClient = BigQueryClient.Create(project_id, Google.Apis.Auth.OAuth2.GoogleCredential.FromStream(fs))

        'Dim jobResource = client.Service.Jobs

        Dim ds As New Data.DataSet
        Dim dt As New DataTable
        dt.TableName = "Table"
        dt.Columns.Add(ColumnName)
        dt.Columns.Add(ColumnName1)
        Try
            'Dim da As New SqlDataAdapter(SelectQuery, con)
            'da.SelectCommand.CommandTimeout = 6000
            'da.Fill(ds)

            Dim result = client.ExecuteQuery(SelectQuery, Nothing)
            For Each Row In result
                'Response.Write(String.Format("{0} and {1}", Row.Item(0), "-") & "\n")
                dt.Rows.Add(Row.Item(0), Row.Item(1))


            Next
            ds.Tables.Add(dt)
            'Console.Read()

        Catch ex As Exception
            'CloseConnection()
            Throw New Exception(ex.ToString())
        End Try
        Return ds
    End Function

Public Function GetDataSetFromQueryGCData(ByVal SelectQuery As String, ByVal ColumnName As String, ByVal ColumnName1 As String, ByVal ColumnName2 As String) As Data.DataSet
        Dim fs As New FileStream(HttpContext.Current.Server.MapPath("~") & "\svc-tskhsmviz-prod.json", FileMode.Open)        'System.AppDomain.CurrentDomain.BaseDirectory & "svc-tskhsmviz-prod.json", FileMode.Open)

        Dim project_id As String = "tsl-datalake"
        project_id = "tsl-datalake-prod"
        Dim client As BigQueryClient = BigQueryClient.Create(project_id, Google.Apis.Auth.OAuth2.GoogleCredential.FromStream(fs))

        'Dim jobResource = client.Service.Jobs

        Dim ds As New Data.DataSet
        Dim dt As New DataTable
        dt.TableName = "Table"
        dt.Columns.Add(ColumnName)
        dt.Columns.Add(ColumnName1)
        dt.Columns.Add(ColumnName2)
        Try
            'Dim da As New SqlDataAdapter(SelectQuery, con)
            'da.SelectCommand.CommandTimeout = 6000
            'da.Fill(ds)

            Dim result = client.ExecuteQuery(SelectQuery, Nothing)
            For Each Row In result
                'Response.Write(String.Format("{0} and {1}", Row.Item(0), "-") & "\n")
                'dt.Rows.Add(Double.Parse(Row.Item(0)), Double.Parse(Row.Item(1)))
                dt.Rows.Add(Row.Item(0), Row.Item(1), Row.Item(2))


            Next
            ds.Tables.Add(dt)
            'Console.Read()

        Catch ex As Exception
            'CloseConnection()
            Throw New Exception(ex.ToString())
        End Try
        Return ds
    End Function

    Private Sub CloseConnection()
        Try
            If con.State <> ConnectionState.Closed Then
                con.Close()
            End If
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

    End Sub
    Private Sub CloseConnectionCRM_EUIP()
        Try
            If CONN_CRM_EUIP.State <> ConnectionState.Closed Then
                CONN_CRM_EUIP.Close()
            End If
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

    End Sub
    Private Sub CloseConnection_TSK()
        Try
            If con_TSK.State <> ConnectionState.Closed Then
                con_TSK.Close()
            End If
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

    End Sub
    Public Function RunStoredProc(ByVal name As String, ByVal pName() As String, ByVal pVal() As String) As DataSet
        Dim ds As New DataSet
        Try
            Dim cmd As New SqlCommand()
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = con
            cmd.CommandText = name
            cmd.Parameters.Clear()
            For i As Integer = 0 To UBound(pName)
                cmd.Parameters.Add(New SqlParameter(pName(i), pVal(i)))
            Next

            Dim da As New SqlDataAdapter(cmd)
            da.Fill(ds)

        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

        Return ds
    End Function
    Public Function GetDataSetFromQueryAnalysis(ByVal SelectQuery As String) As DataSet
        Dim ds As New DataSet
        Try
            Dim da As New SqlDataAdapter(SelectQuery, con)
            da.SelectCommand.CommandTimeout = 6000
            da.Fill(ds)
        Catch ex As Exception
            CloseConnection()
            Throw New Exception(ex.ToString())
        End Try
        Return ds
    End Function
    Public Function GetDataSetFromQuery_CRM_EUIP(ByVal SelectQuery As String) As DataSet
        Dim ds As New DataSet
        Try
            Dim da As New SqlDataAdapter(SelectQuery, CONN_CRM_EUIP)
            da.SelectCommand.CommandTimeout = 10000
            da.Fill(ds)
        Catch ex As Exception
            CloseConnection()
            Throw New Exception(ex.ToString())
        End Try
        Return ds
    End Function
 Public Function Getsql_data(ByVal SelectQuery As String) As DataTable
        	Dim dt As New DataTable
        	Dim conn As String = "server=176.0.0.60\LPTGSQLDEV;database=FP_PROCESS_DATA;uid=153521;pwd=Welcome@135"
        	Dim con As New SqlConnection(conn)
        	'con.Open()
        	Dim ds As New DataTable
        	Try
            	Dim da As New SqlDataAdapter(SelectQuery, con)
            	da.SelectCommand.CommandTimeout = 10000
            	da.Fill(ds)
        	Catch ex As Exception
            	' con.Close()

        	End Try
        	Return ds
    End Function

    Public Function GetDataSetFromQuery(ByVal SelectQuery As String) As DataSet
        Dim ds As New DataSet
        Try
            Dim da As New SqlDataAdapter(SelectQuery, con)
            da.SelectCommand.CommandTimeout = 6000
            da.Fill(ds)
        Catch ex As Exception
            CloseConnection()
            Throw New Exception(ex.ToString())
        End Try
        Return ds
    End Function
    Public Function GetDataSetFromQuery_TSK(ByVal SelectQuery As String) As Data.DataSet
        Dim ds As New Data.DataSet
        Try
            Dim da As New SqlDataAdapter(SelectQuery, con_TSK)
            'da.SelectCommand.CommandTimeout = 6000
            da.Fill(ds)
        Catch ex As Exception
            CloseConnection_TSK()
            Throw New Exception(ex.ToString())
        End Try
        Return ds
    End Function
    Public Function STORE_PROCEDURE(ByVal PROCEDURE_NAME As String, ByVal F_DATE As String, ByVal T_DATE As String, Optional DTTYPE As String = "HR_START_TIME") As DataSet
        Dim ds As New DataSet
        Try
            Dim cmd As New SqlCommand()
            Dim param As SqlParameter()
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = con
            cmd.CommandText = PROCEDURE_NAME
            cmd.Parameters.Clear()
            cmd.Parameters.Add(New SqlParameter("F_DATE", F_DATE))
            cmd.Parameters.Add(New SqlParameter("T_DATE", T_DATE))
            cmd.Parameters.Add(New SqlParameter("DTTYPE", DTTYPE))
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(ds)

        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
        Return ds
    End Function
    Public Function RunSimpleQueryEQUIP(ByVal DMLQuery As String) As Integer
        Dim count As Integer = 0
        Try
            Dim cmd As New SqlCommand(DMLQuery, CONN_CRM_EUIP)
            If CONN_CRM_EUIP.State = ConnectionState.Closed Then
                CONN_CRM_EUIP.Open()
            End If
            count = cmd.ExecuteNonQuery()
        Catch ex As Exception
            CloseConnection()
            Throw New Exception(ex.ToString())
        End Try

        Return count
    End Function


    Public Function RunSimpleQuery(ByVal DMLQuery As String) As Integer
        Dim count As Integer = 0
        Try
            Dim cmd As New SqlCommand(DMLQuery, con)
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            count = cmd.ExecuteNonQuery()
        Catch ex As Exception
            CloseConnection()
            Throw New Exception(ex.ToString())
        End Try

        Return count
    End Function

    Public Function SaveAndRetrieve(ByVal DMLQuery As String, ByVal SelectQuery As String) As String
        Dim str As String = ""
        Try
            Dim cmd As New SqlCommand(DMLQuery, con)
            con.Open()
            Dim count As Integer = cmd.ExecuteNonQuery()
            If count > 0 Then
                cmd = New SqlCommand(SelectQuery, con)
                str = cmd.ExecuteScalar
            End If
        Catch ex As Exception
            CloseConnection()
            Throw New Exception(ex.ToString())
        End Try

        Return str
    End Function

    Public Function CheckRecordsIn(ByVal TableName As String, ByVal CountOnColumn As String) As Boolean
        Dim val As Boolean = False
        Try
            Dim query = "SELECT COUNT(" & CountOnColumn & ") FROM " & TableName
            Dim da As New SqlDataAdapter(query, con)
            Dim dt As New DataTable()
			da.SelectCommand.CommandTimeout=300
            da.Fill(dt)
            If Integer.Parse(dt.Rows(0)(0).ToString()) > 0 Then
                val = True
            End If
        Catch ex As Exception
            CloseConnection()
            Throw New Exception(ex.ToString())
        End Try
        Return val
    End Function

    Public Function CheckRecordsIn(ByVal TableName As String, ByVal CountOnColumn As String, ByVal Condition As String) As Boolean
        Dim val As Boolean = False
        Try
            Dim query = "SELECT COUNT(" & CountOnColumn & ") FROM " & TableName & " WHERE " & Condition
            Dim da As New SqlDataAdapter(query, con)
            Dim dt As New DataTable()
			da.SelectCommand.CommandTimeout=300
            da.Fill(dt)
            If Integer.Parse(dt.Rows(0)(0).ToString()) > 0 Then
                val = True
            End If
        Catch ex As Exception
            CloseConnection()
            Throw New Exception(ex.ToString())
        End Try
        Return val
    End Function

    Function GetOracleData(ByVal q As String) As DataTable
        'Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("ACPM_Ora").ConnectionString
        'Dim Oleconnection_ora As New OleDbConnection(strConnectionString)
        'Dim OleAdap As New OleDbDataAdapter(q, Oleconnection_ora)
        'Dim dt As New DataTable
        'OleAdap.Fill(dt)
        'Return dt

        Dim oraCon As New OracleConnection("Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=133.0.1.2)(PORT=1521))(CONNECT_DATA=(SID=crm2)));User ID=crmisptg;Password=abc#123;")
        Dim dt As New DataTable
        Dim oraCmd As New OracleCommand(q, oraCon)
        Dim oraAdap As New OracleDataAdapter(oraCmd)
        oraAdap.Fill(dt)
        Return dt

    End Function



    Function GetOracleData1(ByVal q As String) As DataSet
        'Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("ACPM_Ora").ConnectionString
        'Dim Oleconnection_ora As New OleDbConnection(strConnectionString)
        'Dim OleAdap As New OleDbDataAdapter(q, Oleconnection_ora)
        'Dim dt As New DataTable
        'OleAdap.Fill(dt)
        'Return dt

        Dim oraCon As New OracleConnection("Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=133.0.1.2)(PORT=1521))(CONNECT_DATA=(SID=crm2)));User ID=crmisptg;Password=abc#123;")
        Dim ds As New DataSet
        Dim oraCmd As New OracleCommand(q, oraCon)
        Dim oraAdap As New OracleDataAdapter(oraCmd)
        oraAdap.Fill(ds)
        Return ds

    End Function


    Function GetOracleDataForRollForce(ByVal Oraquery As String) As DataSet
        Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("TGOraServer").ConnectionString
        Dim Oleconnection_ora As New OleDbConnection(strConnectionString)
        Dim OleAdap As New OleDbDataAdapter(Oraquery, Oleconnection_ora)
        Dim ds As New DataSet
        OleAdap.Fill(ds)
        Return ds
    End Function
    Sub CloseConnection_Crcw()
        Try
            If Oleconnection_ora_Crcw.State <> ConnectionState.Closed Then
                Oleconnection_ora_Crcw.Close()
            End If
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

    End Sub

    Public Function GetDataSetFromQuery_Crcw(ByVal SelectQuery As String) As DataSet
        Dim ds As New DataSet
        Try
            'OleCom.Connection = Oleconnection_ora_Crcw
            'OleCom.CommandText = SelectQuery
            'OleAdap.SelectCommand = OleCom
            'OleAdap.Fill(ds)

            Dim con As New OracleConnection(ConfigurationManager.ConnectionStrings("CRCW_Ora1").ConnectionString)
            Dim cmd As New OracleCommand(SelectQuery, con)

            Dim adap As New OracleDataAdapter(cmd)

            adap.Fill(ds)

        Catch ex As Exception
            'CloseConnection_Crcw()
            Throw New Exception(ex.ToString())
        End Try
        Return ds
    End Function
 Function GetOracleDataRBD_Toolbox(ByVal Oraquery As String) As DataTable
        Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("TGOraServer1").ConnectionString
        Dim Oleconnection_ora As New OleDbConnection(strConnectionString)
        Dim OleAdap As New OleDbDataAdapter(Oraquery, Oleconnection_ora)
        Dim ds As New DataTable
        OleAdap.Fill(ds)
        Return ds
    End Function

    'Public Function GetDataSetFromQueryGC(ByVal SelectQuery As String) As DataSet
    '    Dim fs As New FileStream(System.AppDomain.CurrentDomain.BaseDirectory & "Bin\svc-tskhsmviz-prod.json", FileMode.Open)

    '    Dim project_id As String = "tsl-datalake"
    '    project_id = "tsl-datalake-prod"
    '    Dim client = BigQueryClient.Create(project_id, Google.Apis.Auth.OAuth2.GoogleCredential.FromStream(fs))
    '    Dim ds As New DataSet
    '    Try
    '        'Dim da As New SqlDataAdapter(SelectQuery, con)
    '        'da.SelectCommand.CommandTimeout = 6000
    '        'da.Fill(ds)
    '        Dim result = client.ExecuteQuery(SelectQuery, Nothing)
    '        For Each row In result
    '            'Console.WriteLine(String.Format("{0} and {1}", row.Item("COIL"), row.Item("FCE")))
    '        Next

    '    Catch ex As Exception
    '        CloseConnection()
    '        Throw New Exception(ex.ToString())
    '    End Try
    '    Return ds
    'End Function

End Class
Public Class DataHandlerGCP
    'Dim projectId As String = "tsl-datalake"
    'Dim credential = GoogleCredential.FromFile("D:\\Tirth1\\HSMArupSir\\fpwebsite\\js\\svc-tskhsmviz.json")
    ' Dim client = BigQueryClient.Create(projectId, credential)

    Dim project_id As String = "tsl-datalake"
    'Dim fs As New FileStream(HttpContext.Current.Server.MapPath("~") & "\js\svc-tskhsmviz.json", FileMode.Open)        'System.AppDomain.CurrentDomain.BaseDirectory & "svc-tskhsmviz-prod.json", FileMode.Open)
    'project_id = "tsl-datalake-prod"
    'Dim client As BigQueryClient = BigQueryClient.Create(project_id, Google.Apis.Auth.OAuth2.GoogleCredential.FromStream(fs))

    Public Function DataReading(qry As String)
        Dim dt As New DataTable()

        Using fs As New FileStream(HttpContext.Current.Server.MapPath("~") & "\js\svc-tskhsmviz.json", FileMode.Open)
            Dim client As BigQueryClient = BigQueryClient.Create(project_id, Google.Apis.Auth.OAuth2.GoogleCredential.FromStream(fs))

            Dim queryOptions As New QueryOptions()
            queryOptions.UseQueryCache = True
            queryOptions.Priority = QueryPriority.Interactive
            queryOptions.MaximumBytesBilled = 1000000000

            Dim results = client.ExecuteQuery(qry, parameters:=Nothing)

            For Each field In results.Schema.Fields
                dt.Columns.Add(field.Name, GetType(String))
            Next

            'For Each row In results
            '    Dim dataRow = dt.NewRow()
            '    For i = 0 To row.RawRow.F.Count - 1
            '        'If i = 120 Then
            '        '    MsgBox(i)
            '        'End If
            '        If Not row(i) Is Nothing Then
            '            dataRow(i) = row(i).ToString()
            '        Else
            '            dataRow(i) = ""
            '        End If
            '    Next
            '    'MsgBox("data Filled")
            '    dt.Rows.Add(dataRow)
            'Next

            For Each row As BigQueryRow In results
                Dim datarow = dt.NewRow()
                For i = 0 To row.RawRow.F.Count - 1
                    datarow(i) = row.RawRow.F(i).V 'row(i).ToString()
                Next
                dt.Rows.Add(datarow)
            Next

        End Using

        Return dt
    End Function
End Class
