﻿Imports Microsoft.VisualBasic
Imports System.Data
Imports System.Data.SqlClient

Public Class DataHandler_hsm
    Dim connectionString As String = ConfigurationManager.ConnectionStrings("TG-GWL_1").ConnectionString
    Dim connectionString1 As String = ConfigurationManager.ConnectionStrings("TG-GWL_2").ConnectionString

    'Dim builder As SqlConnectionStringBuilder = New SqlConnectionStringBuilder(connectionString)
    'Dim database As String = builder.InitialCatalog
    Dim con As New SqlConnection(connectionString)
    'Dim builder1 As SqlConnectionStringBuilder = New SqlConnectionStringBuilder(connectionString1)
    ' Dim database1 As String = builder1.InitialCatalog
    Dim con1 As New SqlConnection(connectionString)

    Private Sub CloseConnection()
        Try
            If con.State <> ConnectionState.Closed Then
                con.Close()
            End If
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

    End Sub
    Private Sub CloseConnection1()
        Try
            If con1.State <> ConnectionState.Closed Then
                con1.Close()
            End If
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

    End Sub
    Public Function RunStoredProc(ByVal name As String, ByVal pName() As String, ByVal pVal() As String) As DataSet
        Dim ds As New DataSet
        Try
            Dim cmd As New SqlCommand()
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = con
            cmd.CommandText = name
            cmd.Parameters.Clear()
            For i As Integer = 0 To UBound(pName)
                cmd.Parameters.Add(New SqlParameter(pName(i), pVal(i)))
            Next

            Dim da As New SqlDataAdapter(cmd)
            da.Fill(ds)

        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

        Return ds
    End Function
    Public Function GetDataSetFromQuery(ByVal SelectQuery As String) As DataSet
        Dim ds As New DataSet
        Try
            Dim da As New SqlDataAdapter(SelectQuery, con)
            da.SelectCommand.CommandTimeout = 10000
            da.Fill(ds)
        Catch ex As Exception
            CloseConnection()
            Throw New Exception(ex.ToString())
        End Try
        Return ds
    End Function
    Public Function GetDataSetFromQuery1(ByVal SelectQuery As String) As DataSet
        Dim ds As New DataSet
        Try
            Dim da As New SqlDataAdapter(SelectQuery, con1)
            da.SelectCommand.CommandTimeout = 10000
            da.Fill(ds)
        Catch ex As Exception
            CloseConnection1()
            Throw New Exception(ex.ToString())
        End Try
        Return ds
    End Function

    Public Function RunSimpleQuery(ByVal DMLQuery As String) As Integer
        Dim count As Integer = 0
        Try
            Dim cmd As New SqlCommand(DMLQuery, con)
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            count = cmd.ExecuteNonQuery()
        Catch ex As Exception
            CloseConnection()
            Throw New Exception(ex.ToString())
        End Try

        Return count
    End Function

    Public Function SaveAndRetrieve(ByVal DMLQuery As String, ByVal SelectQuery As String) As String
        Dim str As String = ""
        Try
            Dim cmd As New SqlCommand(DMLQuery, con)
            con.Open()
            Dim count As Integer = cmd.ExecuteNonQuery()
            If count > 0 Then
                cmd = New SqlCommand(SelectQuery, con)
                str = cmd.ExecuteScalar
            End If
        Catch ex As Exception
            CloseConnection()
            Throw New Exception(ex.ToString())
        End Try

        Return str
    End Function

    Public Function CheckRecordsIn(ByVal TableName As String, ByVal CountOnColumn As String) As Boolean
        Dim val As Boolean = False
        Try
            Dim query = "SELECT COUNT(" & CountOnColumn & ") FROM " & TableName
            Dim da As New SqlDataAdapter(query, con)
            Dim dt As New DataTable()
            da.Fill(dt)
            If Integer.Parse(dt.Rows(0)(0).ToString()) > 0 Then
                val = True
            End If
        Catch ex As Exception
            CloseConnection()
            Throw New Exception(ex.ToString())
        End Try
        Return val
    End Function

    Public Function CheckRecordsIn(ByVal TableName As String, ByVal CountOnColumn As String, ByVal Condition As String) As Boolean
        Dim val As Boolean = False
        Try
            Dim query = "SELECT COUNT(" & CountOnColumn & ") FROM " & TableName & " WHERE " & Condition
            Dim da As New SqlDataAdapter(query, con)
            Dim dt As New DataTable()
            da.Fill(dt)
            If Integer.Parse(dt.Rows(0)(0).ToString()) > 0 Then
                val = True
            End If
        Catch ex As Exception
            CloseConnection()
            Throw New Exception(ex.ToString())
        End Try
        Return val
    End Function
End Class
