﻿Imports System.Math
Public Class EffectiveAlFeCalculation
    ' Dim frmAl_Prediction As New frmAl_Prediction
    Dim xTemp, Fe_tot, Fe_solb, J_Calc As Double
    Public Al_trip, Fe_trip, Al_liq, Fe_liq
    Public arrAl_Liq(), arrFeZn7_Left(), arrFe2Zn5_right(), arrConode_Left(), arrConode_Right(), arrRight_conode_parallel_line() As Double
    Public dict As New Dictionary(Of Integer, Double())

    Public Sub Main(ByVal T_Bath_C, ByVal T_Bath_K)
        '' LoadVaulues()
        ''dataValidationForAl_Fe()
        'Al_trip = Al_Triple_Pnt_Calc(T_Bath_C)
        'Fe_trip = Fe_Triple_Pnt_Calc(T_Bath_K)

        ' LoadVaulues()
        'dataValidationForAl_Fe()
        Al_trip = Al_Triple_Pnt_Calc(T_Bath_C)
        Fe_trip = Fe_Triple_Pnt_Calc(T_Bath_K)

        'fill data in arrAl_liq
        Dim no_iteration As Integer
        Dim Al_increment As Double

        Dim Al_min, Al_max, Fe_min, Fe_max As Double

        Al_min = 0.08
        Al_max = 0.3
        Fe_min = 0
        Fe_max = 0.1
        no_iteration = (Al_max - Al_min) * 10000 + 1 ' changed by mamta on 21st sep'18 -- old (0.26 - 0.08) * 10000 + 1
        Al_increment = 0.0001
        ReDim Preserve arrAl_Liq(no_iteration - 1)
        ReDim Preserve arrFeZn7_Left(no_iteration - 1)
        ReDim Preserve arrConode_Right(no_iteration - 1)
        ReDim Preserve arrRight_conode_parallel_line(no_iteration - 1)
        'Filling X-axis Value
        For i As Integer = 0 To no_iteration - 1
            arrAl_Liq(i) = Round(Al_min + i * Al_increment, 4)
        Next
        'FeZn7 Left - left side of solubility curve
        For i As Integer = 0 To no_iteration - 1
            If arrAl_Liq(i) < Al_trip Then
                arrFeZn7_Left(i) = Fe_trip + 0.0483125 * Al_trip - 0.0483125 * arrAl_Liq(i)
            Else
                'ReDim Preserve arrFeZn7_Left(i - 1)
                Exit For
            End If
        Next

        If Not dict.ContainsKey(0) Then
            dict.Add(0, arrFeZn7_Left)
        End If

        'Fe2Al5 right-right side of solubility curve
        ReDim Preserve arrFe2Zn5_right(no_iteration - 1)
        For i As Integer = 0 To no_iteration - 1
            If arrAl_Liq(i) >= (Al_trip - 0.0001) Then
                arrFe2Zn5_right(i) = J_Calc * (arrAl_Liq(i) ^ (-2.5755814))

            End If
        Next
        If Not dict.ContainsKey(1) Then
            dict.Add(1, arrFe2Zn5_right)
        End If

        'Conode Left
        Dim val As Double
        ReDim Preserve arrConode_Left(no_iteration - 1)
        For i As Integer = 0 To no_iteration - 1
            If arrAl_Liq(i) >= (Al_trip - 0.0001) Then
                val = (Fe_trip - 3.3117161 * Al_trip) + 3.3117161 * arrAl_Liq(i)
                If val <= Fe_max Then 'If val <= 0.07 Then
                    arrConode_Left(i) = val
                End If

            End If
        Next
        If Not dict.ContainsKey(2) Then
            dict.Add(2, arrConode_Left)
        End If

        'Conode right
        ReDim Preserve arrConode_Right(no_iteration - 1)
        For i As Integer = 0 To no_iteration - 1
            If arrAl_Liq(i) >= (Al_trip - 0.0001) Then
                val = (Fe_trip - 0.8036331 * Al_trip) + 0.8036331 * arrAl_Liq(i)
                If val <= Fe_max Then
                    arrConode_Right(i) = val
                End If

            End If
        Next
        If Not dict.ContainsKey(3) Then
            dict.Add(3, arrConode_Right)
        End If
    End Sub
    Sub mtdEffectivAlFeCal(ByVal Al_tot_old, ByVal T_Bath_K, ByVal Al_trip, ByVal Fe_trip)

        Fe_solb = Math.Exp(17.78 - (15388 / T_Bath_K))
        If Al_tot_old < 0.134 Then
            xTemp = 3 * (0.42 * Al_tot_old) * (1 - (0.42 * Al_tot_old)) + (0.42 * Al_tot_old) * (Log(0.42 * Al_tot_old)) + ((1 - (0.42 * Al_tot_old)) * (Log(1 - (0.42 * Al_tot_old)))) / (1 - (0.42 * Al_tot_old))
            Fe_tot = 1.9 * Fe_solb * Exp(8 * xTemp)
            'xTemp = (8 * 3 * (0.42 * Al_tot_old) * (1 - (0.42 * Al_tot_old))) + ((0.42 * Al_tot_old) * (Log(0.42 * Al_tot_old))) + ((1 - (0.42 * Al_tot_old))) * (Log(1 - (0.42 * Al_tot_old)))) / (1 - (0.42 * Al_tot_old))

            'Fe_tot = 1.9 * Fe_solb * Exp(xTemp)
        Else
            Fe_tot = Sqrt((Exp(32.3 - (36133 / T_Bath_K))) / (Al_tot_old ^ 5))
        End If
        Al_liq = ((Fe_trip + (0.0483125 * Al_trip)) - Fe_tot + (3.25 * Al_tot_old)) / 3.3600286  '3.3117161
        Fe_liq = Fe_tot - (0.8036331 * Al_tot_old) + (0.8036331 * Al_liq)
    End Sub

    Function Aleffcal(ByVal Al_tot_old, ByVal Fe_tot_old)

        Dim temp1, Fe1, Fe2, Fe3, Fe4, Fetot, Altot, Altriple, err As Double
        Dim aleff, Feeff As Double
        Dim calvar As Double
        Dim temp2 As Integer



        Altot = Al_tot_old
        Fetot = Fe_tot_old 'Range("C5").Value
        Altriple = Al_trip 'Range("K3").Value
        temp2 = 0
        temp1 = Round(Al_tot_old, 4)  ' Format((Range("C4").Value), "#0.0000")
        Do While (Round(arrAl_Liq(temp2), 4) < temp1)
            If temp2 = arrAl_Liq.Length - 1 Then
                Exit Do
            End If
            temp2 = temp2 + 1
        Loop

        Fe1 = Fe_trip + 0.0483125 * Al_trip - 0.0483125 * arrAl_Liq(temp2)
        Fe2 = (Fe_trip - 3.3117161 * Al_trip) + 3.3117161 * arrAl_Liq(temp2)
        Fe3 = Fe_trip - 0.8036331 * Al_trip + 0.8036331 * arrAl_Liq(temp2)
        Fe4 = J_Calc * arrAl_Liq(temp2) ^ (-2.5755814)

        temp1 = 10
        If (Fetot >= Fe4 And Fetot <= Fe3 And Altot > Altriple) Then
            'MsgBox ("IV")
            temp2 = 0
            Do While (temp2 <= arrAl_Liq.Length - 1)
                calvar = (Fe_tot_old - 0.8036331 * Al_tot_old) + 0.8036331 * arrAl_Liq(temp2)
                If (calvar <= 0.05 And calvar > 0.002) Then
                    arrRight_conode_parallel_line(temp2) = calvar
                       err = Abs(arrRight_conode_parallel_line(temp2) - arrFe2Zn5_right(temp2))
                    If err < temp1 Then
                        temp1 = err
                        aleff = arrAl_Liq(temp2)
                        Feeff = calvar
                    End If
                End If
                temp2 = temp2 + 1
            Loop

        ElseIf (Altot >= Altriple And Fetot > Fe3 And Fetot < Fe2) Then
            'MsgBox ("II")
            Al_liq = Round(Altriple, 4)
            Fe_liq = Round(Fe_trip, 4)
            GoTo last
        ElseIf (Altot >= Altriple And Fetot > Fe2) Then
            'MsgBox ("II")
            temp2 = 0
            Do While (temp2 <= arrAl_Liq.Length - 1)
                calvar = (Fe_tot_old - 3.3117161 * Al_tot_old) + 3.3117161 * arrAl_Liq(temp2)
                If (calvar <= 0.05 And calvar > 0.002) Then
                    arrRight_conode_parallel_line(temp2) = calvar
                    err = Abs(arrRight_conode_parallel_line(temp2) - arrFeZn7_Left(temp2))
                    If err < temp1 Then
                        temp1 = err
                        aleff = arrAl_Liq(temp2)
                        Feeff = calvar
                    End If
                End If
                temp2 = temp2 + 1
            Loop

        ElseIf (Altot < Altriple And Fetot > Fe1) Then
            'MsgBox ("I")
            temp2 = 0
            Do While (temp2 <= arrAl_Liq.Length - 1)
                calvar = (Fe_tot_old - 3.3117161 * Al_tot_old) + 3.3117161 * arrAl_Liq(temp2)
                If (calvar <= 0.05 And calvar > 0.002) Then
                    arrRight_conode_parallel_line(temp2) = calvar
                    err = Abs(arrRight_conode_parallel_line(temp2) - arrFeZn7_Left(temp2))
                    If err < temp1 Then
                        temp1 = err
                        aleff = arrAl_Liq(temp2)
                        Feeff = calvar
                    End If
                End If
                temp2 = temp2 + 1
            Loop

        Else
            'MsgBox ("Invalid Values")
            GoTo last
        End If
        Al_liq = Round(aleff, 4)
        Fe_liq = Round(Feeff, 4)

last:

    End Function



    'Al triple point Calculation
    Function Al_Triple_Pnt_Calc(ByVal T_Bath_C) As Double
        Dim AlTrip As Double
        AlTrip = 0.017 + (0.00025 * T_Bath_C)
        Return AlTrip
    End Function

    'Fe triple point Calculation
    Function Fe_Triple_Pnt_Calc(ByVal T_Bath_K) As Double
        Dim FeTrip, Delta_G, Int_A, Int_B, J As Double
        'Delta_G Calculation
        Delta_G = ((1.72 * ((0.1384 * T_Bath_K) - 8678.4711)) + (4.43 * ((3.7924 * T_Bath_K) - 9662.2839))) / (1.987 * T_Bath_K)
        Int_A = (4.41027195404554E+21 * (Exp(Delta_G / (1))))
        Int_B = (146350673298.009 * ((19.2692 - (0.0133 * T_Bath_K)) ^ 1.72)) * (((8.3424 - (0.0074 * T_Bath_K)) ^ 4.43))
        J_Calc = (Int_A / Int_B) ^ 0.581395349

        FeTrip = J_Calc * (Al_trip ^ (-2.5755814))

        Return FeTrip
    End Function

End Class
