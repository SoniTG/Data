﻿Imports Microsoft.VisualBasic
Imports System.Data
Imports OfficeOpenXml
Imports System.IO
Public Class PLTCM_Controller
    Dim objDataHandler As New PLTCM_DataHandler
    Dim objDataHandler1 As New DataHandler_hsm
    Private _iIf As String

    Public Function SaveAndRetrievePageHits(ByVal LoginTime As String, ByVal PageName As String) As Integer
        Dim count As Integer = 0
        Dim REFDATE As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff")

        If Not objDataHandler.CheckRecordsIn("PAGE_HIT_DTLS", "PAGE_NAME", "TIMESTAMP='" & REFDATE & "' and PAGE_NAME='" & PageName & "'") Then
            objDataHandler.RunSimpleQuery("insert into PAGE_HIT_DTLS values('" & PageName & "','" & REFDATE & "',NULL)")
        End If
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select TIMESTAMP from PAGE_HIT_DTLS where PAGE_NAME= '" & PageName & "'").Tables(0)

        ' Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT TIMESTAMP FROM PAGE_HIT_DTLS WHERE PAGE_NAME IN ('dashboard.aspx','lfctoolbox.aspx','Summarylfctoolbox.aspx')").Tables(0)
        count = IIf(dt.Rows.Count = 0, 0, dt.Rows.Count)
        Return count
    End Function
    Function PopulateThicknessForPLTCMDetailAnalysis(ByVal FromDate As String, ByVal ToDate As String, ByVal Grade As String, ByVal TDC As String) As DataTable
        Try
            Dim filter As String = ""
            Dim dt As DataTable
            If Grade.ToLower <> "all" And Grade <> "" Then
                If Grade <> "" Then
                    filter &= " and GRADE = '" & Grade & "'"
                End If
            Else
                filter &= " and 1=1"
            End If
            If TDC.ToLower <> "all" Then
                If TDC <> "" Then
                    filter &= " and TDC_No = '" & TDC & "'"
                Else
                    filter &= " and 1=1"
                End If
            End If
            dt = objDataHandler.GetDataSetFromQuery("SELECT min(HR_THICKNESS) as Min,max(HR_THICKNESS) as Max from CRM_PLTCM_PROCESS_DATA_COILWISE where COIL_STARTTIME between '" & FromDate & "' and '" & ToDate & "' " & filter & "").Tables(0)
            Return dt
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try


    End Function
    Public Sub PopulateCoilIdForPLTCMDetailAnalysis(ByVal CheckBoxListName As CheckBoxList, ByVal FromDate As String, ByVal ToDate As String, ByVal Filter As String)
        Try
            CheckBoxListName.Items.Clear()
            ' Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT  DAUGHTER_COILID_NUM,DAUGHTER_COILID_NUM + '#' + CONVERT(VARCHAR,COIL_STARTDATETIME,120) as VALCOILID from CRM_SPM_PROCESS_DATA_COILWISE_BODY where COIL_STARTDATETIME between '" & FromDate & "' and '" & ToDate & "' and (DAUGHTER_COILID_NUM <> '0' and DAUGHTER_COILID_NUM is not null) and " & Filter & " ORDER BY COIL_STARTDATETIME").Tables(0)

            'Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT distinct(HR_COIL_ID),HR_COIL_ID + '#' + CONVERT(VARCHAR,COIL_STARTTIME,120) as VALCOILID,COIL_STARTTIME from [dbo].[CRM_PLTCM_PROCESS_DATA_COILWISE] where [COIL_STARTTIME] between '" & FromDate & "' and '" & ToDate & "' and ([HR_COIL_ID] <> '0' and [HR_COIL_ID] is not null) and   " & Filter & " ORDER BY COIL_STARTTIME").Tables(0)
            Dim dt As DataTable = objDataHandler.GetDataSetFromQuery(" SELECT  CONCAT(A.HR_COIL_ID ,'  /  ',B.CR_COIL_ID) AS HR_COIL_ID   ,A.HR_COIL_ID + '#' + CONVERT(VARCHAR,COIL_STARTTIME,120) as VALCOILID from CRM_PLTCM_PROCESS_DATA_COILWISE A RIGHT JOIN [CRM_HR_CR_RLN] B ON A.HR_COIL_ID = B.HR_COIL_ID where [COIL_STARTTIME] between '" & FromDate & "' and '" & ToDate & "' and (A.HR_COIL_ID <> '0' and A.HR_COIL_ID is not null) and   " & Filter & "  ORDER BY COIL_STARTTIME").Tables(0)
            Dim dt_remove As DataTable = objDataHandler.GetDataSetFromQuery("WITH cte AS (SELECT *,  ROW_NUMBER() OVER(PARTITION BY HR_COIL_ID ORDER BY [COIL_STARTTIME] desc) 'RowRank' FROM [FP_PROCESS_DATA].[dbo].CRM_PLTCM_PROCESS_DATA_COILWISE)  SELECT    A.HR_COIL_ID + '#' + CONVERT(VARCHAR,COIL_STARTTIME,120) as VALCOILID  from cte  A RIGHT JOIN [CRM_HR_CR_RLN] B ON    A.HR_COIL_ID = B.HR_COIL_ID   WHERE RowRank > 1 and [COIL_STARTTIME] between '" & FromDate & "' and '" & ToDate & "' ").Tables(0)
            For count As Integer = 0 To dt_remove.Rows.Count - 1
                Dim foundRow As DataRow() = dt.Select("VALCOILID = '" & dt_remove.Rows(count)(0) & "'")
                For Each row As DataRow In foundRow
                    row.Delete()
                Next
                dt.AcceptChanges()
            Next



            If dt.Rows.Count > 0 Then
                CheckBoxListName.DataSource = dt
                CheckBoxListName.DataTextField = "HR_COIL_ID"
                CheckBoxListName.DataValueField = "VALCOILID"
                CheckBoxListName.DataBind()
            End If

            'CoilId.Items.Insert(0, "All")
            'CoilId.SelectedIndex = 0
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try


    End Sub
    Public Sub LoadColumnNameForPLTCMProcessDataCoilWiseNew(ByVal CheckBoxListName As CheckBoxList, ByVal ColumnName As String, ByVal proc As String)
        Dim query As String = ""
        Dim val() As String = proc.Split(",")
        Dim filter As String = " "
        For i = 0 To val.Count - 1
            filter &= "'" & val(i) & "',"
        Next
        query = "SELECT  [Analysis_Name] as C1,[Aliyas_Name] as C2  FROM [FP_PROCESS_DATA].[dbo].[DETAILED_ANALYSIS] where [Group] in (" & filter.Substring(0, filter.Length - 1) & ") "


        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery(query).Tables(0)
        If dt.Rows.Count > 0 Then
            CheckBoxListName.DataSource = dt

            CheckBoxListName.DataTextField = "C2"
            CheckBoxListName.DataValueField = "C1"
            CheckBoxListName.DataBind()

            'For i As Integer = 0 To CheckBoxListName.Items.Count - 1

            '    CheckBoxListName.Items(i).Selected = False

            'Next
        End If

    End Sub
    Function Loadlist_detail() As DataTable
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT  distinct[Group]  FROM [FP_PROCESS_DATA].[dbo].[DETAILED_ANALYSIS] order by [Group] desc").Tables(0)

        Return dt
    End Function
    Public Sub emptyliteral(ByVal LiteralName As Literal)
        LiteralName.Text = String.Empty
    End Sub
    Public Function GetPLTCMProcessDataDetailAnalysis(ByVal TableName As String, ByVal CoilNo As String) As DataTable
        Dim query As String = ""
        Dim dt As DataTable
        Dim Coil() As String = CoilNo.Split("#")
        query = "select RAW_DATA_FILE from " & TableName & " where HR_COIL_ID = '" & Coil(0) & "' AND COIL_STARTTIME='" & Coil(1) & "'"
        dt = objDataHandler.GetDataSetFromQuery(query).Tables(0)

        Dim bytes() As Byte = dt.Rows(0)(0)
        Dim ms As New MemoryStream
        ms.Write(bytes, 0, bytes.Length)
        Dim ep As New ExcelPackage(ms)
        Return toDataTableDetailAnalysis(ep, Coil(0))
    End Function
    Public Function GetUnitForPLTCM(ByVal TableName As String, ByVal ColumnName As String) As DataTable
        Dim query As String = ""
        ColumnName = "'" & ColumnName.Replace(",", "','") & "'"
        query = "select *  from " & TableName & " where PARAMETER_NAME in(" & ColumnName & ")"
        Return objDataHandler.GetDataSetFromQuery(query).Tables(0)
    End Function
    'Public Sub PlotLineChartForPLTCMDetailAnalysis(ByVal dt As DataTable, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String, ByVal GroupByColName As String, Optional ByVal name As String = "")
    '    Try
    '        Dim lineindex As Integer = -1
    '        Dim strOverlay As String = ""
    '        Dim multiplier As Double = 1.0
    '        If name = "ENLONGATION_ACT" Then
    '            multiplier = 100
    '            lineindex = 8

    '        ElseIf YAxisColName.StartsWith("[UNIT") Then
    '            If name = "TENSION_TR" Then
    '                multiplier = 1 / (9.8 * 1000)
    '                lineindex = 21
    '            End If
    '        ElseIf name = "TENSION_TR" Then
    '            multiplier = 1 / 9.8
    '            lineindex = 21
    '        ElseIf name = "ROLLFORCE" Then
    '            multiplier = 102.0408
    '            lineindex = 25
    '        End If

    '        'For i As Integer = 0 To dt.Rows.Count - 1
    '        '    If IsDBNull(dt.Rows(i)("LTRI_PARA_MIN")) Then
    '        '        dt.Rows(i)("LTRI_PARA_MIN") = dt.Rows(i)("LTRI_PARA_MIN").ToString().Replace(vbNull, vbDecimal)
    '        '    End If
    '        'Next
    '        LiteralName.Text = ""
    '        'Dim min_time, max_time As String
    '        'min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-30), "yyyy-MM-dd HH:mm")
    '        'max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm")

    '        'Dim xTimestampVal(), yVal() As String
    '        Dim yVal() As Decimal

    '        'xTimestampVal = (From row In dt Select col = row(XAxisColName).ToString).ToArray
    '        'yVal = (From row In dt Select col = CDec(IIf(IsDBNull(row(YAxisColName)), 0, row(YAxisColName))) Where col > 0).ToArray()
    '        yVal = (From row In dt Select col = CDec(IIf(IsDBNull(row(YAxisColName)), 0, row(YAxisColName)))).ToArray()
    '        'Dim y_min As String = yVal.Min()
    '        'Dim y_max As String = yVal.Max()
    '        Dim y_min As String = yVal.Min() - (10 / 100 * Math.Abs(yVal.Min))
    '        Dim y_max As String = yVal.Max() + (10 / 100 * Math.Abs(yVal.Max))

    '        Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
    '                "$.jqplot.config.enablePlugins = true;" & vbCrLf
    '        dt.DefaultView.RowFilter = ""
    '        Dim dtGrades As DataTable = dt.DefaultView.ToTable(True, GroupByColName) 'All distinct Grades
    '        Dim dvDefault As DataView = dt.DefaultView
    '        Dim flag As Boolean = False
    '        Dim cnt As Integer = 1
    '        Dim stcnt As Integer
    '        For i As Integer = 0 To dtGrades.Rows.Count - 1
    '            js &= "var line" & (i + 1).ToString & " = ["
    '            dvDefault.RowFilter = "" & GroupByColName & "='" & dtGrades.Rows(i)(0) & "'"
    '            stcnt = cnt
    '            For j As Integer = 0 To dvDefault.Count - 1
    '                If j > 0 Then
    '                    js &= ","
    '                End If
    '                js &= "["

    '                If IsDBNull(dvDefault.Item(j)(GroupByColName)) Then
    '                    If IsDBNull(dvDefault.Item(j)(YAxisColName)) = False Then
    '                        js &= "" & dvDefault.Item(j)(YAxisColName) & ", " & "null"
    '                    Else
    '                        js &= " " & "null, null"
    '                    End If
    '                Else
    '                    If IsDBNull(dvDefault.Item(j)(YAxisColName)) = False Then
    '                        js &= cnt & "," & dvDefault.Item(j)(YAxisColName) & ",'" & dvDefault.Item(j)(GroupByColName) & "'"
    '                        cnt += 1
    '                        'js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)("CLR_TEST_VALUE") & ", 'Pot'"
    '                    End If
    '                End If
    '                js &= "]"
    '            Next

    '            If lineindex > -1 Then
    '                If YAxisColName.StartsWith("[UNIT") Then
    '                    If name = "TENSION_TR" Then
    '                        multiplier = multiplier / (dvDefault.Item(0)("Thickness") * dvDefault.Item(0)("Width"))
    '                        strOverlay &= "{horizontalLine: {name: '" & dvDefault.Item(0)(GroupByColName) & "',color: 'rgb(255,0,0)',showTooltip: true,tooltipFormatString:" & dvDefault.Item(0)(lineindex - 1) * multiplier & " ,xmin:" & stcnt & ",xmax:" & cnt - 1 & ",y:" & dvDefault.Item(0)(lineindex - 1) * multiplier & ",lineWidth:2}},"
    '                    End If
    '                ElseIf name <> "ROLLFORCE" Then
    '                    strOverlay &= "{horizontalLine: {name: '" & dvDefault.Item(0)(GroupByColName) & "',color: 'rgb(255,0,0)',showTooltip: true,tooltipFormatString:'" & dvDefault.Item(0)(lineindex - 1) * multiplier & "',xmin:" & stcnt & ",xmax:" & cnt - 1 & ",y:" & dvDefault.Item(0)(lineindex - 1) * multiplier & ",lineWidth:2}},"
    '                Else
    '                    Dim dtLim As DataTable = GetLimit(dvDefault.Item(0)("TDC"), dvDefault.Item(0)("Thickness"), dvDefault.Item(0)("Width"))
    '                    If dtLim.Rows.Count > 0 Then
    '                        Dim min As Double = dtLim.Rows(0)(0)
    '                        Dim max As Double = dtLim.Rows(0)(1)
    '                        Dim avg As Double = dtLim.Rows(0)(2)
    '                        strOverlay &= "{horizontalLine: {name: '" & dvDefault.Item(0)(GroupByColName) & "',color: 'rgb(255,140,0)',showTooltip: true,tooltipFormatString:'" & Math.Round(min * multiplier, 3) & "',xmin:" & stcnt & ",xmax:" & cnt - 1 & ",y:" & min * multiplier & ",lineWidth:2}},"
    '                        strOverlay &= "{horizontalLine: {name: '" & dvDefault.Item(0)(GroupByColName) & "1',color: 'rgb(255,0,0)',showTooltip: true,tooltipFormatString:'" & Math.Round(max * multiplier, 3) & "',xmin:" & stcnt & ",xmax:" & cnt - 1 & ",y:" & max * multiplier & ",lineWidth:2}},"
    '                        If name = "ROLLFORCE" Then
    '                            strOverlay &= "{horizontalLine: {name: '" & dvDefault.Item(0)(GroupByColName) & "1',color: 'rgb(0,128,0)',showTooltip: true,tooltipFormatString:'" & Math.Round(avg, 3) & "',xmin:" & stcnt & ",xmax:" & cnt - 1 & ",y:" & avg & ",lineWidth:2}},"
    '                        End If
    '                        If y_min < (min * multiplier) Then
    '                        Else
    '                            y_min = (min * multiplier)
    '                            y_min = y_min - (0.01 * y_min)
    '                        End If
    '                        If y_max > (max * multiplier) Then
    '                        Else
    '                            y_max = (max * multiplier)
    '                            y_max = y_max + (0.01 * y_max)
    '                        End If
    '                    End If
    '                End If

    '            End If

    '            js &= "];" & vbCrLf
    '            flag = True
    '        Next

    '        Dim strg As String = ""
    '        Dim strseries As String = ""
    '        If flag Then
    '            strg = "[line1"
    '            strseries = " {pointLabels: { show:false }, showLine:false, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 5,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>Sl No: %s</td></tr>\ <tr><td>Y Value: %s</td></tr>\ <tr><td>Coil Id: %s</td></tr>\ <tr></tr>\ </table>'}}"
    '            For i As Integer = 1 To dtGrades.Rows.Count - 1
    '                strg = strg + ",line" & i + 1
    '                strseries = strseries + ", {pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 5,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>Sl No: %s</td></tr>\ <tr><td>Y Value: %s</td></tr>\ <tr><td>Coil Id: %s</td></tr>\ <tr></tr>\ </table>'}}"
    '            Next
    '            strg &= "]"
    '        End If
    '        js &= "var seriesName = ['"
    '        Dim str As String = ""
    '        For i As Integer = 0 To dtGrades.Rows.Count - 1
    '            str &= dtGrades.Rows(i)(0).ToString().Trim() + "', '"
    '        Next
    '        str = str.Remove(str.LastIndexOf(", '"))
    '        str &= "];"
    '        js &= str
    '        js &= "opts = {" & vbCrLf &
    '        "title: '" & ChartTitle & "'," & vbCrLf &
    '        "series:[" & strseries & "]," & vbCrLf &
    '        "seriesColors: ['#4C4ED8','#EF3862','#8A1EEE','#0982EC','#0FBDE3','#043D1D','#059B11','#E1EB05','#666699','#F4ED03','#EF8355','#818181','#FFA500', '#006400','#F10000','#996633','#ECAE06','#009999','#800000','#F05904']," & vbCrLf &
    '        "axesDefaults: {" & vbCrLf &
    '        "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
    '        "tickOptions: {" & vbCrLf &
    '        "fontSize:'8pt'" & vbCrLf &
    '        "}" & vbCrLf &
    '        "}," & vbCrLf &
    '        "axes: {" & vbCrLf &
    '        "xaxis: {" & vbCrLf &
    '        "//min: " & vbCrLf &
    '        "//renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
    '        "//tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," & vbCrLf &
    '        "//tickInterval:'1 hour'," & vbCrLf &
    '        "//pad:0" & vbCrLf &
    '         "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
    '        "}," & vbCrLf &
    '        "yaxis: { " & vbCrLf &
    '        "tickOptions: { formatString: '%.4f' }," & vbCrLf &
    '        "min: " & y_min & "," & vbCrLf &
    '        "max: " & y_max & "," & vbCrLf &
    '        "autoscale:true," & vbCrLf &
    '        "label: '" & YAxisLabelName & "'," & vbCrLf &
    '        "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
    '        "}" & vbCrLf &
    '        "}," & vbCrLf &
    '        "cursor: {" & vbCrLf &
    '        "showTooltip: false," & vbCrLf &
    '        "zoom: true" & vbCrLf &
    '        "}," & vbCrLf &
    '        "animate: true," & vbCrLf &
    '        "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
    '        "canvasOverlay: {show: true,objects: [" & strOverlay & "]}," & vbCrLf &
    '        "//legend: {" & vbCrLf &
    '        "//show: true," & vbCrLf &
    '        "//location: 's'," & vbCrLf &
    '        "//labels: seriesName," & vbCrLf &
    '        "//renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
    '        "//placement: 'outsideGrid'," & vbCrLf &
    '        "//rendererOptions: {" & vbCrLf &
    '        "//numberRows: 1," & vbCrLf &
    '        "//marginTop: 10" & vbCrLf &
    '        "//}" & vbCrLf &
    '        "//}" & vbCrLf &
    '        "};" & vbCrLf &
    '        "" & PlotName & " = $.jqplot('" & ContainerName & "', " & strg & ", opts);" & vbCrLf &
    '        "</script>" & vbCrLf

    '        LiteralName.Text = js
    '    Catch ex As Exception

    '    End Try
    'End Sub


    Public Sub PlotLineChartForPLTCMDetailAnalysis(ByVal dt As DataTable, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String, ByVal GroupByColName As String, Optional ByVal name As String = "")
        Try
            Dim lineindex As Integer = -1
            Dim strOverlay As String = ""
            Dim multiplier As Double = 1.0
            If name = "ENLONGATION_ACT" Then
                multiplier = 100
                lineindex = 8

            ElseIf YAxisColName.StartsWith("[UNIT") Then
                If name = "TENSION_TR" Then
                    multiplier = 1 / (9.8 * 1000)
                    lineindex = 21
                End If
            ElseIf name = "TENSION_TR" Then
                multiplier = 1 / 9.8
                lineindex = 21
            ElseIf name = "ROLLFORCE" Then
                multiplier = 102.0408
                lineindex = 25
            End If

            'For i As Integer = 0 To dt.Rows.Count - 1
            '    If IsDBNull(dt.Rows(i)("LTRI_PARA_MIN")) Then
            '        dt.Rows(i)("LTRI_PARA_MIN") = dt.Rows(i)("LTRI_PARA_MIN").ToString().Replace(vbNull, vbDecimal)
            '    End If
            'Next
            LiteralName.Text = ""
            'Dim min_time, max_time As String
            'min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-30), "yyyy-MM-dd HH:mm")
            'max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm")

            'Dim xTimestampVal(), yVal() As String
            Dim yVal() As Decimal

            'xTimestampVal = (From row In dt Select col = row(XAxisColName).ToString).ToArray
            'yVal = (From row In dt Select col = CDec(IIf(IsDBNull(row(YAxisColName)), 0, row(YAxisColName))) Where col > 0).ToArray()
            yVal = (From row In dt Select col = CDec(IIf(IsDBNull(row(YAxisColName)), 0, row(YAxisColName)))).ToArray()
            'Dim y_min As String = yVal.Min()
            'Dim y_max As String = yVal.Max()
            Dim y_min As String = yVal.Min() - (10 / 100 * Math.Abs(yVal.Min))
            Dim y_max As String = yVal.Max() + (10 / 100 * Math.Abs(yVal.Max))

            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf
            dt.DefaultView.RowFilter = ""
            Dim dtGrades As DataTable = dt.DefaultView.ToTable(True, GroupByColName) 'All distinct Grades
            Dim dvDefault As DataView = dt.DefaultView
            Dim flag As Boolean = False
            Dim cnt As Integer = 1
            Dim stcnt As Integer
            '   Dim date_slab As String = dvDefault.Item(0)("Coil_Datetime").ToString("MM-dd-yyyy hh:mm")
            For i As Integer = 0 To dtGrades.Rows.Count - 1
                js &= "var line" & (i + 1).ToString & " = ["
                dvDefault.RowFilter = "" & GroupByColName & "='" & dtGrades.Rows(i)(0) & "'"
                stcnt = cnt
                For j As Integer = 0 To dvDefault.Count - 1
                    If j > 0 Then
                        js &= ","
                    End If
                    js &= "["

                    If IsDBNull(dvDefault.Item(j)(GroupByColName)) Then
                        If IsDBNull(dvDefault.Item(j)(YAxisColName)) = False Then
                            js &= "" & dvDefault.Item(j)(YAxisColName) & ", " & "null"
                        Else
                            js &= " " & "null, null"
                        End If
                    Else
                        If IsDBNull(dvDefault.Item(j)(YAxisColName)) = False Then
                            js &= cnt & "," & dvDefault.Item(j)(YAxisColName) & ",'" & dvDefault.Item(j)(GroupByColName) & "','" & dvDefault.Item(0)("Coil_Datetime") & "'"
                            cnt += 1
                            'js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)("CLR_TEST_VALUE") & ", 'Pot'"
                        End If
                    End If
                    js &= "]"
                Next

                If lineindex > -1 Then
                    If YAxisColName.StartsWith("[UNIT") Then
                        If name = "TENSION_TR" Then
                            multiplier = multiplier / (dvDefault.Item(0)("Thickness") * dvDefault.Item(0)("Width"))
                            strOverlay &= "{horizontalLine: {name: '" & dvDefault.Item(0)(GroupByColName) & "',color: 'rgb(255,0,0)',showTooltip: true,tooltipFormatString:" & dvDefault.Item(0)(lineindex - 1) * multiplier & " ,xmin:" & stcnt & ",xmax:" & cnt - 1 & ",y:" & dvDefault.Item(0)(lineindex - 1) * multiplier & ",lineWidth:2}},"
                        End If
                    ElseIf name <> "ROLLFORCE" Then
                        strOverlay &= "{horizontalLine: {name: '" & dvDefault.Item(0)(GroupByColName) & "',color: 'rgb(255,0,0)',showTooltip: true,tooltipFormatString:'" & dvDefault.Item(0)(lineindex - 1) * multiplier & "',xmin:" & stcnt & ",xmax:" & cnt - 1 & ",y:" & dvDefault.Item(0)(lineindex - 1) * multiplier & ",lineWidth:2}},"
                    Else
                        Dim dtLim As DataTable = GetLimit(dvDefault.Item(0)("TDC"), dvDefault.Item(0)("Thickness"), dvDefault.Item(0)("Width"))
                        If dtLim.Rows.Count > 0 Then
                            Dim min As Double = dtLim.Rows(0)(0)
                            Dim max As Double = dtLim.Rows(0)(1)
                            Dim avg As Double = dtLim.Rows(0)(2)
                            strOverlay &= "{horizontalLine: {name: '" & dvDefault.Item(0)(GroupByColName) & "',color: 'rgb(255,140,0)',showTooltip: true,tooltipFormatString:'" & Math.Round(min * multiplier, 3) & "',xmin:" & stcnt & ",xmax:" & cnt - 1 & ",y:" & min * multiplier & ",lineWidth:2}},"
                            strOverlay &= "{horizontalLine: {name: '" & dvDefault.Item(0)(GroupByColName) & "1',color: 'rgb(255,0,0)',showTooltip: true,tooltipFormatString:'" & Math.Round(max * multiplier, 3) & "',xmin:" & stcnt & ",xmax:" & cnt - 1 & ",y:" & max * multiplier & ",lineWidth:2}},"
                            If name = "ROLLFORCE" Then
                                strOverlay &= "{horizontalLine: {name: '" & dvDefault.Item(0)(GroupByColName) & "1',color: 'rgb(0,128,0)',showTooltip: true,tooltipFormatString:'" & Math.Round(avg, 3) & "',xmin:" & stcnt & ",xmax:" & cnt - 1 & ",y:" & avg & ",lineWidth:2}},"
                            End If
                            If y_min < (min * multiplier) Then
                            Else
                                y_min = (min * multiplier)
                                y_min = y_min - (0.01 * y_min)
                            End If
                            If y_max > (max * multiplier) Then
                            Else
                                y_max = (max * multiplier)
                                y_max = y_max + (0.01 * y_max)
                            End If
                        End If
                    End If

                End If

                js &= "];" & vbCrLf
                flag = True
            Next

            Dim strg As String = ""
            Dim strseries As String = ""
            If flag Then
                strg = "[line1"
                strseries = " {pointLabels: { show:false }, showLine:false, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 5,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>Sl No: %s</td></tr>\ <tr><td>Y Value: %s</td></tr>\ <tr><td>Coil Id: %s</td></tr>\  <tr><td> date_time: %s</td></tr> \<tr></tr>\ </table>'}}"
                For i As Integer = 1 To dtGrades.Rows.Count - 1
                    strg = strg + ",line" & i + 1
                    strseries = strseries + ", {pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 5,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>Sl No: %s</td></tr>\ <tr><td>Y Value: %s</td></tr>\ <tr><td>Coil Id: %s</td></tr>\ <tr><td> date_time: %s</td></tr> \ <tr></tr>\ </table>'}}"
                Next
                strg &= "]"
            End If
            js &= "var seriesName = ['"
            Dim str As String = ""
            For i As Integer = 0 To dtGrades.Rows.Count - 1
                str &= dtGrades.Rows(i)(0).ToString().Trim() + "', '"
            Next
            str = str.Remove(str.LastIndexOf(", '"))
            str &= "];"
            js &= str
            js &= "opts = {" & vbCrLf &
            "title: '" & ChartTitle & "'," & vbCrLf &
            "series:[" & strseries & "]," & vbCrLf &
            "seriesColors: ['#4C4ED8','#EF3862','#8A1EEE','#0982EC','#0FBDE3','#043D1D','#059B11','#E1EB05','#666699','#F4ED03','#EF8355','#818181','#FFA500', '#006400','#F10000','#996633','#ECAE06','#009999','#800000','#F05904']," & vbCrLf &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            "fontSize:'8pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "//min: " & vbCrLf &
            "//renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
            "//tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," & vbCrLf &
            "//tickInterval:'1 hour'," & vbCrLf &
            "//pad:0" & vbCrLf &
             "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}," & vbCrLf &
            "yaxis: { " & vbCrLf &
            "tickOptions: { formatString: '%.4f' }," & vbCrLf &
            "min: " & y_min & "," & vbCrLf &
            "max: " & y_max & "," & vbCrLf &
            "autoscale:true," & vbCrLf &
            "label: '" & YAxisLabelName & "'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "showTooltip: false," & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "animate: true," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
            "canvasOverlay: {show: true,objects: [" & strOverlay & ",{horizontalLine: {name: '0-Line',y: 0,lineWidth: 2,color: 'rgb(255, 0, 0)', shadow: false}}]}," & vbCrLf &
            "//legend: {" & vbCrLf &
            "//show: true," & vbCrLf &
            "//location: 's'," & vbCrLf &
            "//labels: seriesName," & vbCrLf &
            "//renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
            "//placement: 'outsideGrid'," & vbCrLf &
            "//rendererOptions: {" & vbCrLf &
            "//numberRows: 1," & vbCrLf &
            "//marginTop: 10" & vbCrLf &
            "//}" & vbCrLf &
            "//}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "', " & strg & ", opts);" & vbCrLf &
            "</script>" & vbCrLf

            LiteralName.Text = js
        Catch ex As Exception

        End Try
    End Sub



    Function PopulateWidthForPLTCMDetailAnalysis(ByVal FromDate As String, ByVal ToDate As String, ByVal Grade As String, ByVal TDC As String, ByVal ThicknessFrom As String, ByVal ThicknessTo As String) As DataTable
        Try
            Dim filter As String = ""
            Dim dt As DataTable
            If Grade.ToLower <> "all" Then
                If Grade <> "" Then
                    filter &= " and GRADE = '" & Grade & "'"
                Else
                    filter &= " and 1=1"
                End If
            End If
            If TDC.ToLower <> "all" Then
                If TDC <> "" Then
                    filter &= " and TDC_No = '" & TDC & "'"
                Else
                    filter &= " and 1=1"
                End If
            End If
            If ThicknessFrom And ThicknessTo <> "" Then

                filter &= "  and THICKNESS between " & ThicknessFrom & " and " & ThicknessTo & ""



            End If
            dt = objDataHandler.GetDataSetFromQuery("SELECT min(HR_WIDTH) as Min,max(HR_WIDTH) as Max from CRM_PLTCM_PROCESS_DATA_COILWISE where COIL_STARTTIME between '" & FromDate & "' and '" & ToDate & "' " & filter & "").Tables(0)

            Return dt
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try


    End Function
    Public Sub PopulateCoilIdForPLTCMDetailAnalysisCoilwise(ByVal CheckBoxListName As CheckBoxList, ByVal CoilNo As String, ByVal PROCESS_TYPE As String)

        Try
            If PROCESS_TYPE = "HR_COIL_ID" Then
                PROCESS_TYPE = "A.HR_COIL_ID = '" & CoilNo.Trim & "'"
            Else
                PROCESS_TYPE = "B.CR_COIL_ID = '" & CoilNo.Trim & "'"
            End If

            CheckBoxListName.Items.Clear()
            ' Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT  DAUGHTER_COILID_NUM,DAUGHTER_COILID_NUM + '#' + CONVERT(VARCHAR,COIL_STARTDATETIME,120) as VALCOILID from CRM_SPM_PROCESS_DATA_COILWISE_BODY where DAUGHTER_COILID_NUM LIKE '" & CoilNo & "%' and (DAUGHTER_COILID_NUM <> '0' and DAUGHTER_COILID_NUM is not null) ORDER BY COIL_STARTDATETIME").Tables(0)
            Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT  CONCAT(A.HR_COIL_ID ,'  /  ',B.CR_COIL_ID) AS HR_COIL_ID  ,A.HR_COIL_ID + '#' + CONVERT(VARCHAR,COIL_STARTTIME,120) as VALCOILID from CRM_PLTCM_PROCESS_DATA_COILWISE A RIGHT JOIN [CRM_HR_CR_RLN] B ON A.HR_COIL_ID = B.HR_COIL_ID where " & PROCESS_TYPE & "  and (A.HR_COIL_ID <> '0' and A.HR_COIL_ID is not null) ORDER BY COIL_STARTTIME desc ").Tables(0)
            Dim dt_remove As DataTable = objDataHandler.GetDataSetFromQuery("WITH cte AS (SELECT *,  ROW_NUMBER() OVER(PARTITION BY HR_COIL_ID ORDER BY [COIL_STARTTIME] desc) 'RowRank' FROM [FP_PROCESS_DATA].[dbo].CRM_PLTCM_PROCESS_DATA_COILWISE)  SELECT    A.HR_COIL_ID + '#' + CONVERT(VARCHAR,COIL_STARTTIME,120) as VALCOILID  from cte  A RIGHT JOIN [CRM_HR_CR_RLN] B ON    A.HR_COIL_ID = B.HR_COIL_ID   WHERE RowRank > 1 and " & PROCESS_TYPE & " ").Tables(0)
            For count As Integer = 0 To dt_remove.Rows.Count - 1
                Dim foundRow As DataRow() = dt.Select("VALCOILID = '" & dt_remove.Rows(count)(0) & "'")
                For Each row As DataRow In foundRow
                    row.Delete()
                Next
                dt.AcceptChanges()
            Next


            If dt.Rows.Count > 0 Then
                CheckBoxListName.DataSource = dt
                CheckBoxListName.DataTextField = "HR_COIL_ID"
                CheckBoxListName.DataValueField = "VALCOILID"
                CheckBoxListName.DataBind()
            End If

            'CoilId.Items.Insert(0, "All")
            'CoilId.SelectedIndex = 0
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try


    End Sub
    Public Function GetPLTCMEncoderData() As DataSet
        ' GetDataSetFromQuery_CRM_EUIP  CHANGES IN CONNECTION STRING RITIKA (MAMTA MA'AM)
        '  Return objDataHandler.GetDataSetFromQuery("select top 1 * from CRM_PLTCM_ENCODER_MAX order by PEM_STARTTIME desc;select * from CRM_PLTCM_LIMITS WHERE PL_ACTIVE=1 order by PL_SEQ_NO ")

        Return objDataHandler.GetDataSetFromQuery_CRM_EUIP("select top 1 * from CRM_PLTCM_ENCODER_MAX order by PEM_STARTTIME desc;select * from CRM_PLTCM_LIMITS WHERE PL_ACTIVE=1 order by PL_SEQ_NO ")

    End Function


    '---------------------------------------------------------------------------------------------------------------------------------------------------
    '---------------------------------------------------------------------------------------------------------------------------------------------------

    Public Function IsValidDateRange(ByVal txtFrom As TextBox, ByVal txtTo As TextBox) As Boolean
        Dim var As Boolean = False
        If DateTime.Compare(txtFrom.Text, txtTo.Text) < 1 Then
            var = True
        End If
        Return var

    End Function
    Public Sub LoadSubDivisions(ByVal DropDownName As DropDownList, ByVal MainDiv As String)
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select FMD_SUB_DIV_ID,FMD_SUB_DIV from FP_MASTER_DATA where FMD_MAIN_DIV='" & MainDiv & "' order by FMD_SUB_DIV_SEQ").Tables(0)
        If dt.Rows.Count > 0 Then
            DropDownName.DataSource = dt
            DropDownName.DataTextField = "FMD_SUB_DIV"
            DropDownName.DataValueField = "FMD_SUB_DIV_ID"
            DropDownName.DataBind()
        End If
    End Sub

    Public Function GetRequiredParameters(ByVal MainCat As String, ByVal SubCat As String) As DataTable
        Return objDataHandler.GetDataSetFromQuery("select FMD_TABLE_NAME,FHC_CHART_NAME,FHC_CHART_TYPE,FHC_PARAM1,FHC_PARAM2,FMD_DEFAULT_PAGE,FMD_DATE_COLUMN,FMD_DEFAULT_COLOUR_COL from FP_MASTER_DATA inner join FP_HOMEPG_CONFIG on FP_MASTER_DATA.FMD_SUB_DIV_ID = FP_HOMEPG_CONFIG.FHC_SUB_DIV_ID where FMD_MAIN_DIV='" & MainCat & "' and FMD_SUB_DIV_ID='" & SubCat & "'").Tables(0)

    End Function
    Public Function GetMenuBarHierarchy(ByVal SubCatId As String) As DataTable
        Return objDataHandler.GetDataSetFromQuery("select FMC_SUB_DIV_ID,FMC_MAIN_HEADER,FMC_CHILD_HEADER,FMC_PAGENAME from FP_MENUBAR_CONFIG where FMC_SUB_DIV_ID='" & SubCatId & "' order by FMC_SEQUENCE ").Tables(0) 'order by FMC_MAIN_HEADER desc

    End Function

    Public Function GetFilterColumnArray(ByVal TableName As String, ByVal SubDivId As String) As String()
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT FMD_FILTER_COLUMN FROM " & TableName & " where FMD_SUB_DIV_ID='" & SubDivId & "'").Tables(0)
        Dim arrFilterCols(1) As String
        If dt.Rows.Count > 0 Then
            Dim s As String = dt.Rows(0)(0)
            Dim arr() As String = s.Split(",")
            ReDim arrFilterCols(arr.Length)
            arrFilterCols = arr
        End If
        Return arrFilterCols
    End Function

    Public Sub LoadColumnsData(ByVal DropDownName As DropDownList, ByVal TableName As String, ByVal ColumnName As String, ByVal DateColumnName As String, ByVal FromDt As String, ByVal ToDate As String)
        'Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT distinct " & ColumnName & " FROM " & TableName & " where " & DateColumnName & " between '" & Convert.ToDateTime(FromDt).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(ToDate).ToString("yyyy-MM-dd HH:mm:ss") & "' and " & ColumnName & " <> '' order by " & ColumnName & "").Tables(0)
        Dim query As String = ""
        Dim TextField As String = ""
        If ColumnName = "CLR_PROCESS_LINE" Then
            query = "SELECT distinct " & ColumnName & " FROM " & TableName & " where " & DateColumnName & " between '" & Convert.ToDateTime(FromDt).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(ToDate).ToString("yyyy-MM-dd HH:mm:ss") & "' and " & ColumnName & " <> '' order by " & ColumnName & ""
            TextField = "CLR_PROCESS_LINE"
        Else
            query = "SELECT DISTINCT " & ColumnName & ",DBO.UFN_GET_PARAM_ALIAS_NAME(" & ColumnName & ") AS PARAM_TEST FROM CRM_LABTEST_RES WHERE " & ColumnName & " <>'' ORDER BY PARAM_TEST"
            TextField = "PARAM_TEST"
        End If
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery(query).Tables(0)
        If dt.Rows.Count > 0 Then
            DropDownName.DataSource = dt
            '--------------
            If TextField = "PARAM_TEST" Then
                Dim dt1 As DataTable = dt.DefaultView.ToTable(True, "PARAM_TEST")
                Dim dt2 As DataTable = dt.Clone

                For row As Integer = 0 To dt1.Rows.Count - 1
                    Dim dv As DataView = dt.DefaultView
                    dv.RowFilter = "PARAM_TEST='" & dt1.Rows(row)(0) & "'"
                    Dim str As String = ""
                    For j As Integer = 0 To dv.Count - 1
                        str &= ",'" & dv.Item(j)(0) & "'"
                    Next
                    dt2.Rows.Add(str.Substring(1), dt1.Rows(row)(0))
                    dv.RowFilter = ""
                Next
                DropDownName.DataSource = dt2
            Else
                DropDownName.DataSource = dt
            End If
            '-------------
            DropDownName.DataTextField = TextField
            DropDownName.DataValueField = ColumnName
            DropDownName.DataBind()
            'DropDownName.Items.Insert(0, "Select")
            'DropDownName.SelectedIndex = 0
        End If
        'If dt.Rows.Count > 0 Then
        '    If TextField = "PARAM_TEST" Then
        '        DropDownName.DataSource = ""
        '        DropDownName.DataBind()
        '        DropDownName.Items.Clear()
        '        For i As Integer = 0 To dt.Rows.Count - 1
        '            If Not DropDownName.Items.Contains(New ListItem(dt.Rows(i)("PARAM_TEST"))) Then
        '                DropDownName.Items.Add(dt.Rows(i)("PARAM_TEST"))
        '            End If
        '        Next
        '    Else
        '        DropDownName.DataSource = dt
        '        DropDownName.DataTextField = TextField
        '        DropDownName.DataValueField = ColumnName
        '        DropDownName.DataBind()
        '    End If


        '    'DropDownName.Items.Insert(0, "Select")
        '    'DropDownName.SelectedIndex = 0
        'End If
    End Sub

    Public Sub LoadColumnsData(ByVal DropDownName As DropDownList, ByVal TableName As String, ByVal ColumnName As String, ByVal DateColumnName As String, ByVal FromDt As String, ByVal ToDate As String, ByVal FilterVal As String)
        'Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT distinct " & ColumnName & " FROM " & TableName & " where " & DateColumnName & " between '" & Convert.ToDateTime(FromDt).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(ToDate).ToString("yyyy-MM-dd HH:mm:ss") & "' and " & ColumnName & " <> '' order by " & ColumnName & "").Tables(0)
        Dim query As String = ""
        Dim TextField As String = ""
        If ColumnName = "CLR_PROCESS_LINE" Then
            query = "SELECT distinct " & ColumnName & " FROM " & TableName & " where " & DateColumnName & " between '" & Convert.ToDateTime(FromDt).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(ToDate).ToString("yyyy-MM-dd HH:mm:ss") & "' and " & ColumnName & " <> '' order by " & ColumnName & ""
            TextField = "CLR_PROCESS_LINE"
        Else
            query = "SELECT DISTINCT " & ColumnName & ",DBO.UFN_GET_PARAM_ALIAS_NAME(" & ColumnName & ") AS PARAM_TEST FROM CRM_LABTEST_RES WHERE " & ColumnName & " <>'' and CLR_PROCESS_LINE = '" & FilterVal & "' ORDER BY PARAM_TEST"
            TextField = "PARAM_TEST"
        End If
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery(query).Tables(0)
        If dt.Rows.Count > 0 Then
            DropDownName.DataSource = dt
            '--------------
            If TextField = "PARAM_TEST" Then
                Dim dt1 As DataTable = dt.DefaultView.ToTable(True, "PARAM_TEST")
                Dim dt2 As DataTable = dt.Clone

                For row As Integer = 0 To dt1.Rows.Count - 1
                    Dim dv As DataView = dt.DefaultView
                    dv.RowFilter = "PARAM_TEST='" & dt1.Rows(row)(0) & "'"
                    Dim str As String = ""
                    For j As Integer = 0 To dv.Count - 1
                        str &= ",'" & dv.Item(j)(0) & "'"
                    Next
                    dt2.Rows.Add(str.Substring(1), dt1.Rows(row)(0))
                    dv.RowFilter = ""
                Next
                DropDownName.DataSource = dt2
            Else
                DropDownName.DataSource = dt
            End If
            '-------------
            DropDownName.DataTextField = TextField
            DropDownName.DataValueField = ColumnName
            DropDownName.DataBind()
            'DropDownName.Items.Insert(0, "Select")
            'DropDownName.SelectedIndex = 0
        End If
        'If dt.Rows.Count > 0 Then
        '    If TextField = "PARAM_TEST" Then
        '        DropDownName.DataSource = ""
        '        DropDownName.DataBind()
        '        DropDownName.Items.Clear()
        '        For i As Integer = 0 To dt.Rows.Count - 1
        '            If Not DropDownName.Items.Contains(New ListItem(dt.Rows(i)("PARAM_TEST"))) Then
        '                DropDownName.Items.Add(dt.Rows(i)("PARAM_TEST"))
        '            End If
        '        Next
        '    Else
        '        DropDownName.DataSource = dt
        '        DropDownName.DataTextField = TextField
        '        DropDownName.DataValueField = ColumnName
        '        DropDownName.DataBind()
        '    End If


        '    'DropDownName.Items.Insert(0, "Select")
        '    'DropDownName.SelectedIndex = 0
        'End If
    End Sub

    Public Sub CreateMenuBarHierarchy(ByVal SubDivId As String, ByVal LiteralName As Literal)
        Dim dt As DataTable = GetMenuBarHierarchy(SubDivId)
        If dt.Rows.Count > 0 Then
            Dim strMenu As String = ""
            Dim MainMenus() As String = (From row In dt Select col = row.Field(Of String)("FMC_MAIN_HEADER") Distinct).ToArray
            For i As Integer = 0 To MainMenus.Length - 1
                strMenu &= "<li class=""dropdown"">" & vbCrLf
                strMenu &= "<a class=""dropdown-toggle"" data-toggle=""dropdown"" href=""#"" style=""color: white;"" onmouseover=""this.style.backgroundColor='#0d5281';this.style.color='white'"" onmouseout=""this.style.backgroundColor='#007ACC';this.style.color='white'"">" & MainMenus(i) & "" & vbCrLf
                Dim x As Integer = i
                Dim query = From val In dt.AsEnumerable() Where val.Field(Of String)("FMC_MAIN_HEADER") = MainMenus(x) Select val
                Dim dtRelated As DataTable = query.CopyToDataTable()
                Dim ChildMenus() As String = (From row In dtRelated Select col = row.Field(Of String)("FMC_CHILD_HEADER") Distinct).ToArray
                Dim PageNames() As String = (From row In dtRelated Select col = row.Field(Of String)("FMC_PAGENAME") Distinct).ToArray
                If MainMenus(i) <> ChildMenus(0) Then
                    strMenu &= "<span class=""caret""></span></a>" & vbCrLf
                    strMenu &= "<ul class=""dropdown-menu"">" & vbCrLf
                    For j As Integer = 0 To ChildMenus.Length - 1
                        strMenu &= "<li><a href=" & PageNames(j) & ">" & ChildMenus(j) & "</a></li>"
                    Next
                    strMenu &= "</ul>" & vbCrLf
                Else
                    strMenu &= "</a>"
                    'strMenu = strMenu.Replace("href=""#""", "href=""" & PageNames(0) & """")
                End If
                strMenu &= "</li>" & vbCrLf
            Next
            LiteralName.Text = strMenu
        End If
    End Sub

    Public Sub CreateMenuBarHierarchyDirect(ByVal SubDivId As String, ByVal LiteralName As Literal)
        Dim dt As DataTable = GetMenuBarHierarchy(SubDivId)
        If dt.Rows.Count > 0 Then
            Dim strMenu As String = ""
            Dim MainMenus() As String = (From row In dt Select col = row.Field(Of String)("FMC_MAIN_HEADER") Distinct).ToArray
            For i As Integer = 0 To MainMenus.Length - 1

                Dim x As Integer = i
                Dim query = From val In dt.AsEnumerable() Where val.Field(Of String)("FMC_MAIN_HEADER") = MainMenus(x) Select val
                Dim dtRelated As DataTable = query.CopyToDataTable()
                Dim ChildMenus() As String = (From row In dtRelated Select col = row.Field(Of String)("FMC_CHILD_HEADER") Distinct).ToArray
                Dim PageNames() As String = (From row In dtRelated Select col = row.Field(Of String)("FMC_PAGENAME") Distinct).ToArray
                If MainMenus(i) <> ChildMenus(0) Then
                    strMenu &= "<li class=""dropdown"">" & vbCrLf
                    strMenu &= "<a class=""dropdown-toggle"" data-toggle=""dropdown"" style=""color: white;"" onmouseover=""this.style.backgroundColor='#0d5281';this.style.color='white'"" onmouseout=""this.style.backgroundColor='#007ACC';this.style.color='white'"""
                    strMenu &= "href=""#""> " & MainMenus(i) & "" & vbCrLf
                    strMenu &= "<span class=""caret""></span></a>" & vbCrLf
                    strMenu &= "<ul class=""dropdown-menu"">" & vbCrLf
                    For j As Integer = 0 To ChildMenus.Length - 1
                        strMenu &= "<li><a href=" & PageNames(j) & ">" & ChildMenus(j) & "</a></li>"
                    Next
                    strMenu &= "</ul>" & vbCrLf
                Else
                    strMenu &= "<li>" & vbCrLf
                    strMenu &= "<a style=""color: white;"" onmouseover=""this.style.backgroundColor='#0d5281';this.style.color='white'"" onmouseout=""this.style.backgroundColor='#007ACC';this.style.color='white'"""
                    strMenu &= "href=""" & PageNames(0) & """>" & MainMenus(i) & "</a>"
                    'strMenu = strMenu.Replace("href=""#""", "href=""" & PageNames(0) & """")
                End If
                strMenu &= "</li>" & vbCrLf
            Next
            LiteralName.Text = strMenu
        End If
    End Sub
    'Public Sub CreateMenuBarHierarchy(ByVal SubDivId As String, ByVal LiteralName As Literal)
    '    Dim dt As DataTable = GetMenuBarHierarchy(SubDivId)
    '    If dt.Rows.Count > 0 Then
    '        Dim strMenu As String = ""
    '        Dim MainMenus() As String = (From row In dt Select col = row.Field(Of String)("FMC_MAIN_HEADER") Distinct).ToArray
    '        For i As Integer = 0 To MainMenus.Length - 1
    '            strMenu &= "<li class=""dropdown"">" & vbCrLf
    '            'strMenu &= "<a class=""dropdown-toggle"" data-toggle=""dropdown"" href=""#"" style=""color: white;"" onmouseover=""this.style.backgroundColor='#0d5281';this.style.color='white'"" onmouseout=""this.style.backgroundColor='#007ACC';this.style.color='white'"">" & MainMenus(i) & "" & vbCrLf
    '            strMenu &= "<a style=""color: white;"" onmouseover=""this.style.backgroundColor='#0d5281';this.style.color='white'"" onmouseout=""this.style.backgroundColor='#007ACC';this.style.color='white'"""
    '            Dim x As Integer = i
    '            Dim query = From val In dt.AsEnumerable() Where val.Field(Of String)("FMC_MAIN_HEADER") = MainMenus(x) Select val
    '            Dim dtRelated As DataTable = query.CopyToDataTable()
    '            Dim ChildMenus() As String = (From row In dtRelated Select col = row.Field(Of String)("FMC_CHILD_HEADER") Distinct).ToArray
    '            Dim PageNames() As String = (From row In dtRelated Select col = row.Field(Of String)("FMC_PAGENAME") Distinct).ToArray
    '            If MainMenus(i) <> ChildMenus(0) Then
    '                strMenu &= "class=""dropdown-toggle"" data-toggle=""dropdown"" href=""#"" >" & MainMenus(i) & "" & vbCrLf & "<span class=""caret""></span></a>" & vbCrLf
    '                strMenu &= "<ul class=""dropdown-menu"">" & vbCrLf
    '                For j As Integer = 0 To ChildMenus.Length - 1
    '                    strMenu &= "<li><a href=" & PageNames(j) & ">" & ChildMenus(j) & "</a></li>"
    '                Next
    '                strMenu &= "</ul>" & vbCrLf
    '            Else
    '                strMenu &= "href=""" & PageNames(i) & """>" & MainMenus(i) & "</a>"
    '                'strMenu = strMenu.Replace("href=""#""", "href=""" & PageNames(0) & """")
    '            End If
    '            strMenu &= "</li>" & vbCrLf
    '        Next
    '        LiteralName.Text = strMenu
    '    End If
    'End Sub
    Public Function GetAllChartsData(ByVal TableName As String, ByVal DateColumnName As String, ByVal YValue As String, ByVal FromDate As Date, ByVal ToDate As Date) As DataTable
        Dim sourceTable As String = TableName

        Dim query As String = "Select " & DateColumnName & "," & YValue & " from " & sourceTable & " where " &
                    " " & DateColumnName & " between ' " & Format(FromDate, "yyyy-MM-dd HH:mm:ss") & " ' and ' " & Format(ToDate, "yyyy-MM-dd HH:mm:ss") & " ' and " & YValue & " is not null    order by " & DateColumnName & " " & vbCrLf 'and Cast_no is not Null and QltyCD is not Null

        'query &= "select USL,LSL,UCL,LCL from WRM_PROCESS_SPEC ps  join " & sourceTable & " mp on   mp.SECTION=ps.SECTION and  mp.GRADE=ps.Qlty_Code " & _
        '        "where Billet_Temp_Timestamp between ' " & Format(FromDate, "yyyy-MM-dd HH:mm:ss") & " ' and ' " & Format(ToDate, "yyyy-MM-dd HH:mm:ss") & " ' and fortype='BltTemp' " & vbCrLf

        'query &= "select USL,LSL,UCL,LCL from WRM_PROCESS_SPEC ps  join " & sourceTable & " mp on   mp.SECTION=ps.SECTION and  mp.GRADE=ps.Qlty_Code " & _
        '      "where Billet_Temp_Timestamp between ' " & Format(FromDate, "yyyy-MM-dd HH:mm:ss") & " ' and ' " & Format(ToDate, "yyyy-MM-dd HH:mm:ss") & " ' and fortype='LHT' " & vbCrLf

        'query &= "select Cast_NO from Mill_Parameter where Billet_Temp_Timestamp = (select max(Billet_Temp_Timestamp) from Mill_Parameter)"
        Return objDataHandler.GetDataSetFromQuery(query).Tables(0)
    End Function

    Public Function LoadColourColumns(ByVal TableName As String) As DataTable
        Dim query As String = "select column_name, data_type from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME='" & TableName & "' order by column_name"
        Return objDataHandler.GetDataSetFromQuery(query).Tables(0)
    End Function

    Public Function GetWetChemicalTestData(ByVal TableName As String, ByVal FromDate As String, ByVal ToDate As String, ByVal DateColumn As String, ByVal Filter As String, ByVal ColourColumn As String) As DataTable
        Dim query As String = ""
        'If Filter <> "" Then
        '    query = "select CLR_TEST_VALUE,CLR_DT_SAMPLING_DATE,ISNULL(CLR_PARAM_MIN,0) AS CLR_PARAM_MIN,CLR_PARAM_TEST," & ColourColumn & " from " & TableName & " where " & DateColumn & " between '" & FromDate & "' and '" & ToDate & "' and cast(CLR_TEST_VALUE as float)>0 and (" & Filter & ") order by CLR_DT_SAMPLING_DATE"
        'Else
        '    query = "select CLR_TEST_VALUE,CLR_DT_SAMPLING_DATE,ISNULL(CLR_PARAM_MIN,0) AS CLR_PARAM_MIN,CLR_PARAM_TEST," & ColourColumn & " from " & TableName & " where " & DateColumn & " between '" & FromDate & "' and '" & ToDate & "' and cast(CLR_TEST_VALUE as float)>0 order by CLR_DT_SAMPLING_DATE"
        'End If
        If Filter <> "" Then
            query = "SELECT CLR_TEST_VALUE,CLR_DT_SAMPLING_DATE,ISNULL(CLR_PARAM_MIN,0) AS CLR_PARAM_MIN,CLR_PARAM_TEST, ""CAMPAIGN"" = CASE WHEN CLR_TEST_VALUE > 0.15 AND CLR_TEST_VALUE <= 0.4 THEN 'ZAZS' WHEN CLR_TEST_VALUE >= 0.1 AND CLR_TEST_VALUE <= 0.15 THEN 'ZAGA' WHEN CLR_PARAM_TEST = 'ZAFE' THEN 'ZAFE' END FROM " & TableName & " WHERE " & DateColumn & " BETWEEN '" & FromDate & "' AND '" & ToDate & "' AND CLR_TEST_VALUE < 10 AND CAST(CLR_TEST_VALUE AS FLOAT)>0 AND (" & Filter & ") ORDER BY CLR_DT_SAMPLING_DATE"
        Else
            query = "SELECT CLR_TEST_VALUE,CLR_DT_SAMPLING_DATE,ISNULL(CLR_PARAM_MIN,0) AS CLR_PARAM_MIN,CLR_PARAM_TEST, ""CAMPAIGN"" = CASE WHEN CLR_TEST_VALUE > 0.15 AND CLR_TEST_VALUE <= 0.4 THEN 'ZAZS' WHEN CLR_TEST_VALUE >= 0.1 AND CLR_TEST_VALUE <= 0.15 THEN 'ZAGA' WHEN CLR_PARAM_TEST = 'ZAFE' THEN 'ZAFE' END FROM " & TableName & " WHERE " & DateColumn & " BETWEEN '" & FromDate & "' AND '" & ToDate & "' AND CLR_TEST_VALUE < 10 AND CAST(CLR_TEST_VALUE AS FLOAT)>0 ORDER BY CLR_DT_SAMPLING_DATE"
        End If
        Return objDataHandler.GetDataSetFromQuery(query).Tables(0)
    End Function

    Public Sub PlotLineChart(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String, ByVal GroupByColName As String)
        Try
            'For i As Integer = 0 To dt.Rows.Count - 1
            '    If IsDBNull(dt.Rows(i)("LTRI_PARA_MIN")) Then
            '        dt.Rows(i)("LTRI_PARA_MIN") = dt.Rows(i)("LTRI_PARA_MIN").ToString().Replace(vbNull, vbDecimal)
            '    End If
            'Next
            LiteralName.Text = ""
            Dim min_time, max_time As String
            min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-30), "yyyy-MM-dd HH:mm")
            max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm")

            'Dim xTimestampVal(), yVal() As String
            Dim yVal() As Decimal

            'xTimestampVal = (From row In dt Select col = row(XAxisColName).ToString).ToArray
            yVal = (From row In dt Select col = CDec(row(YAxisColName))).ToArray()

            'Dim y_min As String = yVal.Min()
            'Dim y_max As String = yVal.Max()
            Dim y_min As String = yVal.Min() - (10 / 100 * yVal.Min)
            Dim y_max As String = yVal.Max() + (10 / 100 * yVal.Max)

            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf
            dt.DefaultView.RowFilter = ""
            Dim dtGrades As DataTable = dt.DefaultView.ToTable(True, GroupByColName) 'All distinct Grades
            Dim dvDefault As DataView = dt.DefaultView
            Dim flag As Boolean = False
            For i As Integer = 0 To dtGrades.Rows.Count - 1
                js &= "var line" & (i + 1).ToString & " = ["
                dvDefault.RowFilter = "" & GroupByColName & "='" & dtGrades.Rows(i)(0) & "'"
                For j As Integer = 0 To dvDefault.Count - 1
                    If j > 0 Then
                        js &= ","
                    End If
                    js &= "["
                    Dim dtTime As DateTime = dvDefault.Item(j)("CLR_DT_SAMPLING_DATE")
                    If IsDBNull(dvDefault.Item(j)(GroupByColName)) Then
                        If IsDBNull(dvDefault.Item(j)("CLR_TEST_VALUE")) = False Then
                            js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)("CLR_TEST_VALUE") & ", " & "null"
                        Else
                            js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & "null, null"
                        End If
                    Else
                        If IsDBNull(dvDefault.Item(j)("CLR_TEST_VALUE")) = False Then
                            js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)("CLR_TEST_VALUE") & ", '(" & dvDefault.Item(j)(GroupByColName).ToString().Trim & ")'"
                            'js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)("CLR_TEST_VALUE") & ", 'Pot'"
                        End If
                    End If
                    js &= "]"
                Next
                js &= "];" & vbCrLf
                flag = True
            Next

            Dim strg As String = ""
            Dim strseries As String = ""
            If flag Then
                strg = "[line1"
                strseries = " {pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
                For i As Integer = 1 To dtGrades.Rows.Count - 1
                    strg = strg + ",line" & i + 1
                    strseries = strseries + ", {pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
                Next
                strg &= "]"
            End If
            js &= "var seriesName = ['"
            Dim str As String = ""
            For i As Integer = 0 To dtGrades.Rows.Count - 1
                str &= dtGrades.Rows(i)(0).ToString().Trim() + "', '"
            Next
            str = str.Remove(str.LastIndexOf(", '"))
            str &= "];"
            js &= str
            js &= "opts = {" & vbCrLf &
            "title: '" & ChartTitle & "'," & vbCrLf &
            "series:[" & strseries & "]," & vbCrLf &
            "//seriesColors: ['#FFA500']," & vbCrLf &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            "fontSize:'8pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf &
            "renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
            "tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," & vbCrLf &
            "//tickInterval:'1 hour'," & vbCrLf &
            "pad:0" & vbCrLf &
            "}," & vbCrLf &
            "yaxis: { " & vbCrLf &
            "tickOptions: { formatString: '%.3f' }," & vbCrLf &
            "min: " & y_min & "," & vbCrLf &
            "max: " & y_max & "," & vbCrLf &
            "autoscale:true," & vbCrLf &
            "label: '" & YAxisLabelName & "'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "showTooltip: false," & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "animate: true," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
            "legend: {" & vbCrLf &
            "show: true," & vbCrLf &
            "location: 's'," & vbCrLf &
            "labels: seriesName," & vbCrLf &
            "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
            "placement: 'outsideGrid'," & vbCrLf &
            "rendererOptions: {" & vbCrLf &
            "numberRows: 1," & vbCrLf &
            "marginTop: 10" & vbCrLf &
            "}" & vbCrLf &
            "}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "', " & strg & ", opts);" & vbCrLf &
            "</script>" & vbCrLf

            LiteralName.Text = js
        Catch ex As Exception

        End Try
    End Sub

    Public Sub PlotLineChartWithSecondaryYAxis(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal MinY1 As String, ByVal MaxY1 As String, ByVal MinY2 As String, ByVal MaxY2 As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal Y1AxisLabelName As String, ByVal Y2AxisLabelName As String, ByVal PriDataVarName As String, ByVal SecDataVarName As String, ByVal Y1Series As String, ByVal Y2Series As String)
        Try
            ChartTitle = ""
            Dim min_time, max_time As String
            min_time = Format(dt.Rows(0)(XAxisColName), "yyyy-MM-dd HH:mm")
            max_time = Format(dt.Rows(dt.Rows.Count - 1)(XAxisColName), "yyyy-MM-dd HH:mm")

            Dim y1_min As String = MinY1
            Dim y1_max As String = "0.400"
            Dim y2_min As String = MinY2
            Dim y2_max As String = "0.100"
            Dim arrAlTest() As String = Y1AxisLabelName.Replace("'", "").Split(",")
            Dim js = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf &
                    "var series= ['" & Y1Series & "', '" & Y2Series & "'];" & vbCrLf &
                    "var " & PriDataVarName & " = [["
            For i = 0 To dt.Rows.Count - 1
                'If dt.Rows(i)("CLR_PARAM_TEST").ToString.Contains(Y1AxisLabelName) Then
                If Y1AxisLabelName.Contains(dt.Rows(i)("CLR_PARAM_TEST")) And dt.Rows(i)("CLR_TEST_VALUE") < 1 Then
                    'If i = dt.Rows.Count - 1 Then
                    '    js &= "'" & DateTime.Parse(dt.Rows(i)("CLR_DT_SAMPLING_DATE")).ToString("yyyy-MM-dd HH:mm") & "', " & dt.Rows(i)("CLR_TEST_VALUE") & "]]; " & vbCrLf
                    'Else
                    js &= "'" & DateTime.Parse(dt.Rows(i)("CLR_DT_SAMPLING_DATE")).ToString("yyyy-MM-dd HH:mm") & "', " & dt.Rows(i)("CLR_TEST_VALUE") & "], ["
                    'End If
                End If
            Next
            'If js.Contains(", [") Then
            js = js.Remove(js.LastIndexOf(", ["))
            js &= "];" & vbCrLf
            'End If

            js &= "var " & SecDataVarName & " = [["
            For i = 0 To dt.Rows.Count - 1
                'If dt.Rows(i)("CLR_PARAM_TEST").ToString.Contains(Y2AxisLabelName) Then
                If Y2AxisLabelName.Contains(dt.Rows(i)("CLR_PARAM_TEST")) And dt.Rows(i)("CLR_TEST_VALUE") < 1 Then
                    'If i = dt.Rows.Count - 1 Then
                    '    js &= "'" & DateTime.Parse(dt.Rows(i)("CLR_DT_SAMPLING_DATE")).ToString("yyyy-MM-dd HH:mm") & "', " & dt.Rows(i)("CLR_TEST_VALUE") & "]]; " & vbCrLf
                    'Else
                    js &= "'" & DateTime.Parse(dt.Rows(i)("CLR_DT_SAMPLING_DATE")).ToString("yyyy-MM-dd HH:mm") & "', " & dt.Rows(i)("CLR_TEST_VALUE") & "], ["
                    'End If
                End If
            Next
            js = js.Remove(js.LastIndexOf(", ["))
            js &= "];" & vbCrLf

            Dim dvMean As DataView = dt.DefaultView
            dvMean.RowFilter = "CLR_PARAM_TEST IN (" & Y1AxisLabelName & ")"
            Dim dtMean As DataTable = dvMean.ToTable
            js &= "var primaryMean = [["
            For i As Integer = 0 To dtMean.Rows.Count - 1
                If i = dtMean.Rows.Count - 1 Then
                    js &= "'" & DateTime.Parse(dtMean.Rows(i)("CLR_DT_SAMPLING_DATE")).ToString("yyyy-MM-dd HH:mm") & "', " & dtMean.Rows(i)("CLR_PARAM_MIN") & "]]; " & vbCrLf
                Else
                    js &= "'" & DateTime.Parse(dtMean.Rows(i)("CLR_DT_SAMPLING_DATE")).ToString("yyyy-MM-dd HH:mm") & "', " & dtMean.Rows(i)("CLR_PARAM_MIN") & "], ["
                End If
            Next
            'Dim primaryPoint1 As String = "['" & DateTime.Parse(dtMean.Rows(0)("CLR_DT_SAMPLING_DATE")).ToString("yyyy-MM-dd HH:mm") & "', " & dtMean.Rows(0)("CLR_PARAM_MIN") & "]"
            'Dim primaryPoint2 As String = "['" & DateTime.Parse(dtMean.Rows(dtMean.Rows.Count - 1)("CLR_DT_SAMPLING_DATE")).ToString("yyyy-MM-dd HH:mm") & "', " & dtMean.Rows(dtMean.Rows.Count - 1)("CLR_PARAM_MIN") & "]"
            'js &= "var primaryMean = [" & primaryPoint1 & ", " & primaryPoint2 & "];"
            js &= vbCrLf

            dtMean.Reset()
            dt.DefaultView.RowFilter = String.Empty
            dvMean = dt.DefaultView
            dvMean.RowFilter = "CLR_PARAM_TEST IN (" & Y2AxisLabelName & ")"
            dtMean = dvMean.ToTable
            js &= "var secondaryMean = [["
            For i As Integer = 0 To dtMean.Rows.Count - 1
                If i = dtMean.Rows.Count - 1 Then
                    js &= "'" & DateTime.Parse(dtMean.Rows(i)("CLR_DT_SAMPLING_DATE")).ToString("yyyy-MM-dd HH:mm") & "', " & dtMean.Rows(i)("CLR_PARAM_MIN") & "]]; " & vbCrLf
                Else
                    js &= "'" & DateTime.Parse(dtMean.Rows(i)("CLR_DT_SAMPLING_DATE")).ToString("yyyy-MM-dd HH:mm") & "', " & dtMean.Rows(i)("CLR_PARAM_MIN") & "], ["
                End If
            Next
            'Dim secondaryPoint1 As String = "['" & DateTime.Parse(dtMean.Rows(0)("CLR_DT_SAMPLING_DATE")).ToString("yyyy-MM-dd HH:mm") & "', " & dtMean.Rows(0)("CLR_PARAM_MIN") & "]"
            'Dim secondaryPoint2 As String = "['" & DateTime.Parse(dtMean.Rows(dtMean.Rows.Count - 1)("CLR_DT_SAMPLING_DATE")).ToString("yyyy-MM-dd HH:mm") & "', " & dtMean.Rows(dtMean.Rows.Count - 1)("CLR_PARAM_MIN") & "]"
            'js &= "var secondaryMean = [" & secondaryPoint1 & ", " & secondaryPoint2 & "]"
            js &= vbCrLf

            js &= "opts = {" & vbCrLf &
            "title: '" & ChartTitle & "'," & vbCrLf &
            "series:[{pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}, {pointLabels: { show:false }, showLine: true, yaxis:'y2axis', lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}, {pointLabels: { show:false }, showLine: true, lineWidth:2, linePattern: 'dashed', showMarker: false, color: '#BA3030', highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}, {pointLabels: { show:false }, showLine: true, lineWidth:2, linePattern: 'dashed', showMarker: false, color: '#3584B2', highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}]," & vbCrLf &
            "//seriesColors: ['#FFA500', '#006400']," & vbCrLf &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            "fontSize:'8pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf &
            "renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
            "tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," & vbCrLf &
            "//tickInterval:'1 hour'," & vbCrLf &
            "pad:0" & vbCrLf &
            "}," & vbCrLf &
            "yaxis: { " & vbCrLf &
            "tickOptions: { formatString: '%.3f' }," & vbCrLf &
            "min: " & y1_min & "," & vbCrLf &
            "max: " & y1_max & "," & vbCrLf &
            "//autoscale:true," & vbCrLf &
            "label: '" & Y1Series & "'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}," & vbCrLf &
            "y2axis: { " & vbCrLf &
            "tickOptions: { formatString: '%.3f' }," & vbCrLf &
            "min: " & y2_min & "," & vbCrLf &
            "max: " & y2_max & "," & vbCrLf &
            "//autoscale:true," & vbCrLf &
            "//tickOptions:{showGridline:false}," & vbCrLf &
            "label: '" & Y2Series & "'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}, animation:true," & vbCrLf &
            "cursor: {" & vbCrLf &
            "showTooltip: false," & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "//highlighter: {  show: 'true', tooltipFormatString: '%.1f', useAxesFormatters: false }," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
            "legend: {" & vbCrLf &
            "show: true," & vbCrLf &
            "location: 's'," & vbCrLf &
            "labels: series," & vbCrLf &
            "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
            "placement: 'outsideGrid'," & vbCrLf &
            "rendererOptions: {" & vbCrLf &
            "numberRows: 1," & vbCrLf &
            "numberColumns: 2," & vbCrLf &
            "marginTop: 10" & vbCrLf &
            "}" & vbCrLf &
            "}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "', [" & PriDataVarName & ", " & SecDataVarName & ", primaryMean, secondaryMean], opts);" & vbCrLf &
            "</script>" & vbCrLf

            LiteralName.Text = js
        Catch ex As Exception

        End Try
    End Sub
    Public Sub PlotLineChartForCGL2Maint(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String, ByVal index As String)
        Try

            LiteralName.Text = ""
            Dim min_time, max_time As String
            min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-30), "yyyy-MM-dd HH:mm")
            max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm")

            'Dim xTimestampVal(), yVal() As String
            Dim yVal() As Decimal

            'xTimestampVal = (From row In dt Select col = row(XAxisColName).ToString).ToArray
            yVal = (From row In dt Select col = CDec(IIf(IsDBNull(row(YAxisColName)), 0, row(YAxisColName))) Where col > 0).ToArray()

            'Dim y_min As String = yVal.Min()
            'Dim y_max As String = yVal.Max()
            Dim y_min As String = yVal.Min() - (10 / 100 * yVal.Min)
            Dim y_max As String = yVal.Max() + (10 / 100 * yVal.Max)

            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf
            js &= "var line" & index & " = ["
            For j As Integer = 0 To dt.Rows.Count - 1
                If j > 0 Then
                    'js &= ","
                End If

                Dim dtTime As DateTime = dt.Rows(j)(XAxisColName)

                If IsDBNull(dt.Rows(j)(YAxisColName)) = False Then
                    js &= "['" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dt.Rows(j)(YAxisColName) & "],"

                End If

            Next

            js &= "];" & vbCrLf
            'Dim strg As String = ""
            'Dim strseries As String = ""
            'If flag Then
            '    strg = "[line1"
            '    strseries = " {showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"

            '    strg &= "]"
            'End If
            'js &= "var seriesName = ['"
            'Dim str As String = ""
            'For i As Integer = 0 To dtGroups.Rows.Count - 1
            '    str &= dtGroups.Rows(i)(0).ToString().Trim() + "', '"
            'Next
            'str = str.Remove(str.LastIndexOf(", '"))
            'str &= "];"
            'js &= str
            js &= "opts = {" & vbCrLf &
            "title: '" & ChartTitle & "'," & vbCrLf &
            "seriesDefaults: { showMarker:true,lineWidth: 2,markerOptions: {size: 5}, pointLabels: { show:false },color: '#4832DB', highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}," &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            "fontSize:'8pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "//min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf &
            "renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
            "tickOptions:{formatString:'%d-%b', angle: -30}," & vbCrLf &
            "tickInterval:'1 day'," & vbCrLf &
            "pad:0" & vbCrLf &
            "}," & vbCrLf &
            "yaxis: { " & vbCrLf &
            "tickOptions: { formatString: '%8.3f' }," & vbCrLf &
            "min: " & y_min & "," & vbCrLf &
            "max: " & y_max & "," & vbCrLf &
            "autoscale:true," & vbCrLf &
            "label: '" & YAxisLabelName & "'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "showTooltip: false," & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "animate: true," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)'}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "',[line" & index & "],opts);" & vbCrLf &
            "</script>" & vbCrLf

            LiteralName.Text = js
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub
    Public Sub PlotLineChartWithSecondaryYAxisCampaignwise(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal MinY1 As String, ByVal MaxY1 As String, ByVal MinY2 As String, ByVal MaxY2 As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal Y1AxisLabelName As String, ByVal Y2AxisLabelName As String, ByVal PriDataVarName As String, ByVal SecDataVarName As String, ByVal Y1Series As String, ByVal Y2Series As String)
        Try
            Dim min_time, max_time As String
            min_time = Format(dt.Rows(0)(XAxisColName), "yyyy-MM-dd HH:mm")
            max_time = Format(dt.Rows(dt.Rows.Count - 1)(XAxisColName), "yyyy-MM-dd HH:mm")

            'Dim view As DataView = dt.DefaultView
            'view.RowFilter = "CAMPAIGN <> NULL"
            'Dim dt1 As DataTable = view.Table

            For i As Integer = 0 To dt.Rows.Count - 1
                If IsDBNull(dt.Rows(i)("CAMPAIGN")) Then
                    dt.Rows(i).Delete()
                End If
            Next
            dt.AcceptChanges()

            '---------------------------Separating Data Campaignwise------------------------------------------------------------
            '-------------------------------------------------------------------------------------------------------------------
            Dim Query = From val In dt.AsEnumerable() Where
                        val.Field(Of String)("CLR_PARAM_TEST") = "ZAAL" Or
                        val.Field(Of String)("CLR_PARAM_TEST") = "ZAGA" Or
                        val.Field(Of String)("CLR_PARAM_TEST") = "ZAZS"
                        Select val Order By val.Field(Of DateTime)("CLR_DT_SAMPLING_DATE")
            Dim dtAl As DataTable
            If Query.Count > 0 Then
                dtAl = Query.CopyToDataTable()
            Else
                dtAl = dt.Clone
            End If

            Query = From val In dt.AsEnumerable() Where val.Field(Of String)("CLR_PARAM_TEST") = "ZAFE"
                    Select val Order By val.Field(Of DateTime)("CLR_DT_SAMPLING_DATE")
            Dim dtFe As DataTable
            If Query.Count > 0 Then
                dtFe = Query.CopyToDataTable()
            Else
                dtFe = dt.Clone
            End If

            Query = From val In dtAl.AsEnumerable() Where val.Field(Of Decimal)("CLR_TEST_VALUE") > 0.15 AndAlso val.Field(Of Decimal)("CLR_TEST_VALUE") <= 0.4
                    Select val Order By val.Field(Of DateTime)("CLR_DT_SAMPLING_DATE")
            Dim dtGI As DataTable
            If Query.Count > 0 Then
                dtGI = Query.CopyToDataTable() 'All the GI data.
            Else
                dtGI = dt.Clone
            End If
            Query = From val In dtAl.AsEnumerable() Where val.Field(Of Decimal)("CLR_TEST_VALUE") >= 0.1 AndAlso val.Field(Of Decimal)("CLR_TEST_VALUE") <= 0.15
                    Select val Order By val.Field(Of DateTime)("CLR_DT_SAMPLING_DATE")
            Dim dtGA As DataTable
            If Query.Count > 0 Then
                dtGA = Query.CopyToDataTable() 'All the GA data.
            Else
                dtGA = dt.Clone
            End If
            '--------------------------------------------------------------------------------------------------------------------
            '--------------------------------------------------------------------------------------------------------------------

            'Below are the temporary datatables holding false record in between two rows having time difference of 24 hours or more.
            Dim dtGI_Temp As New DataTable
            dtGI_Temp.Columns.Add("CLR_TEST_VALUE", GetType(Decimal))
            dtGI_Temp.Columns.Add("CLR_DT_SAMPLING_DATE", GetType(DateTime))
            dtGI_Temp.Columns.Add("CLR_PARAM_MIN", GetType(Decimal))
            dtGI_Temp.Columns.Add("CLR_PARAM_TEST", GetType(String))
            dtGI_Temp.Columns.Add("CAMPAIGN", GetType(String))
            For i As Integer = 0 To dtGI.Rows.Count - 1
                Dim row As DataRow = dtGI_Temp.NewRow
                row("CLR_TEST_VALUE") = dtGI.Rows(i)("CLR_TEST_VALUE")
                row("CLR_DT_SAMPLING_DATE") = DateTime.Parse(dtGI.Rows(i)("CLR_DT_SAMPLING_DATE"))
                row("CLR_PARAM_MIN") = dtGI.Rows(i)("CLR_PARAM_MIN")
                row("CLR_PARAM_TEST") = dtGI.Rows(i)("CLR_PARAM_TEST")
                row("CAMPAIGN") = dtGI.Rows(i)("CAMPAIGN")
                dtGI_Temp.Rows.Add(row)
                If i < dtGI.Rows.Count - 1 Then
                    Dim span As TimeSpan = DateTime.Parse(dtGI.Rows(i + 1)("CLR_DT_SAMPLING_DATE")).Subtract(DateTime.Parse(dtGI.Rows(i)("CLR_DT_SAMPLING_DATE")))
                    If span.TotalHours >= 24 Then
                        dtGI_Temp.Rows.Add(0, DateTime.Parse(dtGI.Rows(i)("CLR_DT_SAMPLING_DATE")).AddMinutes(10), dtGI.Rows(i)("CLR_PARAM_MIN"),
                                           dtGI.Rows(i)("CLR_PARAM_TEST"), dtGI.Rows(i)("CAMPAIGN"))
                    End If
                End If
            Next

            Dim dtGA_Temp As New DataTable
            dtGA_Temp.Columns.Add("CLR_TEST_VALUE", GetType(Decimal))
            dtGA_Temp.Columns.Add("CLR_DT_SAMPLING_DATE", GetType(DateTime))
            dtGA_Temp.Columns.Add("CLR_PARAM_MIN", GetType(Decimal))
            dtGA_Temp.Columns.Add("CLR_PARAM_TEST", GetType(String))
            dtGA_Temp.Columns.Add("CAMPAIGN", GetType(String))
            For i As Integer = 0 To dtGA.Rows.Count - 1
                Dim row As DataRow = dtGA_Temp.NewRow
                row("CLR_TEST_VALUE") = dtGA.Rows(i)("CLR_TEST_VALUE")
                row("CLR_DT_SAMPLING_DATE") = DateTime.Parse(dtGA.Rows(i)("CLR_DT_SAMPLING_DATE"))
                row("CLR_PARAM_MIN") = dtGA.Rows(i)("CLR_PARAM_MIN")
                row("CLR_PARAM_TEST") = dtGA.Rows(i)("CLR_PARAM_TEST")
                row("CAMPAIGN") = dtGA.Rows(i)("CAMPAIGN")
                dtGA_Temp.Rows.Add(row)
                If i < dtGA.Rows.Count - 1 Then
                    Dim span As TimeSpan = DateTime.Parse(dtGA.Rows(i + 1)("CLR_DT_SAMPLING_DATE")).Subtract(DateTime.Parse(dtGA.Rows(i)("CLR_DT_SAMPLING_DATE")))
                    If span.TotalHours >= 24 Then
                        dtGA_Temp.Rows.Add(0, DateTime.Parse(dtGA.Rows(i)("CLR_DT_SAMPLING_DATE")).AddMinutes(10), dtGA.Rows(i)("CLR_PARAM_MIN"),
                                           dtGA.Rows(i)("CLR_PARAM_TEST"), dtGA.Rows(i)("CAMPAIGN"))
                    End If
                End If
            Next
            '---------------------------------------END OF TEMPORARY DATATABLES----------------------------------------------
            'Dim dv As DataView = dt.DefaultView
            'dv.RowFilter = "CLR_PARAM_TEST<>'ZAAL'"
            'Dim dtCamp As DataTable = dv.ToTable
            'Dim arrParamTests() As String = (From row In dtCamp Select col = row.Field(Of String)("CLR_PARAM_TEST") Distinct).ToArray
            Dim arrParamTests() As String = (From row In dt Select col = row.Field(Of String)("CAMPAIGN") Distinct).ToArray

            Dim strAllSeriesData As String = ""
            For i As Integer = 0 To arrParamTests.Length - 1
                If arrParamTests(i) = "ZAZS" Then 'For ZAGI
                    Dim varAlSeries As String = "var line" & arrParamTests(i) & " = ["
                    For j As Integer = 0 To dtGI_Temp.Rows.Count - 1
                        If dtGI_Temp.Rows(j)("CLR_TEST_VALUE") < 1 Then
                            varAlSeries &= "['" & DateTime.Parse(dtGI_Temp.Rows(j)("CLR_DT_SAMPLING_DATE")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGI_Temp.Rows(j)("CLR_TEST_VALUE") = 0, "null", dtGI_Temp.Rows(j)("CLR_TEST_VALUE")) & ", 'ZAGI'], "
                        End If
                    Next
                    varAlSeries = varAlSeries.Remove(varAlSeries.LastIndexOf(", "))
                    varAlSeries &= "];" & vbCrLf & vbCrLf
                    strAllSeriesData &= varAlSeries
                ElseIf arrParamTests(i) = "ZAGA" Then 'For ZAGA
                    Dim varAlSeries As String = "var line" & arrParamTests(i) & " = ["
                    For j As Integer = 0 To dtGA_Temp.Rows.Count - 1
                        If dtGA_Temp.Rows(j)("CLR_TEST_VALUE") < 1 Then
                            varAlSeries &= "['" & DateTime.Parse(dtGA_Temp.Rows(j)("CLR_DT_SAMPLING_DATE")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGA_Temp.Rows(j)("CLR_TEST_VALUE") = 0, "null", dtGA_Temp.Rows(j)("CLR_TEST_VALUE")) & ", 'ZAGA'], "
                        End If
                    Next
                    varAlSeries = varAlSeries.Remove(varAlSeries.LastIndexOf(", "))
                    varAlSeries &= "];" & vbCrLf & vbCrLf
                    strAllSeriesData &= varAlSeries
                ElseIf arrParamTests(i) = "ZAFE" Then 'For ZAFE
                    Dim varFeSeries As String = "var line" & arrParamTests(i) & " = ["
                    For j As Integer = 0 To dtFe.Rows.Count - 1
                        If dtFe.Rows(j)("CLR_TEST_VALUE") < 1 And dtFe.Rows(j)("CLR_TEST_VALUE") > 0.015 Then 'Need to be checked
                            varFeSeries &= "['" & DateTime.Parse(dtFe.Rows(j)("CLR_DT_SAMPLING_DATE")).ToString("yyyy-MM-dd HH:mm") & "', " & dtFe.Rows(j)("CLR_TEST_VALUE") & ", '" & dtFe.Rows(j)("CLR_PARAM_TEST") & "'], "
                        End If
                    Next
                    varFeSeries = varFeSeries.Remove(varFeSeries.LastIndexOf(", "))
                    varFeSeries &= "];" & vbCrLf & vbCrLf
                    strAllSeriesData &= varFeSeries
                End If
            Next

            Dim strAllChartSeries As String = ""
            Dim strSeries As String = "["
            Dim strPlots As String = "["
            For i As Integer = 0 To arrParamTests.Length - 1
                If arrParamTests(i) <> "ZAFE" Then 'For ZAAL, ZAZS, ZAGA
                    Dim testName As String = ""
                    If arrParamTests(i) = "ZAZS" Then
                        testName = "GI-Al"
                    ElseIf arrParamTests(i) = "ZAGA" Then
                        testName = "GA-Al"
                    ElseIf arrParamTests(i) = "ZAAL" Then
                        testName = "AL"
                    End If
                    strSeries &= "'" & testName & "', "
                    strPlots &= "line" & arrParamTests(i) & ", "
                    Dim lineColor As String = ""
                    If arrParamTests(i) = "ZAAL" Then
                        lineColor = "#EF5304"
                    ElseIf arrParamTests(i) = "ZAGA" Then
                        lineColor = "#0B7C0B"
                    ElseIf arrParamTests(i) = "ZAZS" Then
                        lineColor = "#4832DB"
                    End If
                    strAllChartSeries &= "{pointLabels: { show:false }, showLine: true,breakOnNull: true,color: '" & lineColor & "',yaxis: 'yaxis',lineWidth: 2,markerOptions: {size: 5},highlighter: {show: true,showMarker: false,tooltipAxes: 'xy',yvalues: 2,formatString: '<table style=""height:80px; width:180px; background-color:" & lineColor & "; font-weight:bold; font-size:x-large; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td><center>%s</center></td></tr></table>'}},"
                End If
            Next
            For i As Integer = 0 To arrParamTests.Length - 1
                If arrParamTests(i) = "ZAFE" Then 'For ZAFE
                    strSeries &= "'" & IIf(arrParamTests(i) = "ZAFE", "FE", arrParamTests(i)) & "', "
                    strPlots &= "line" & arrParamTests(i) & ", "
                    strAllChartSeries &= "{pointLabels: { show:false }, showLine: true,color: '#FF0000',yaxis: 'y2axis',lineWidth: 2,markerOptions: {size: 5},highlighter: {show: true,showMarker: false,tooltipAxes: 'xy',yvalues: 2,formatString: '<table style=""height:80px; width:180px; background-color:#000000; font-weight:bold; font-size:x-large; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td><center>%s</center></td></tr></table>'}},"
                End If
            Next
            strSeries &= "'AL Min', 'FE Min'];"
            strAllChartSeries &= "{pointLabels: { show:false }, showLine: true,lineWidth: 1,linePattern: 'dashed',showMarker: false,color: '#BA3030',highlighter: {show: true,showMarker: false,tooltipAxes: 'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}},"
            strAllChartSeries &= "{pointLabels: { show:false }, showLine: true,lineWidth: 2,showMarker: false,color: '#3584B2',highlighter: {show: true,showMarker: false,tooltipAxes: 'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"

            Dim y1_min As String = MinY1
            Dim y1_max As String = "0.400"
            Dim y2_min As String = MinY2
            Dim y2_max As String = "0.100"

            Dim js = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf &
                    "var series= " & strSeries & "" & vbCrLf

            js &= strAllSeriesData & vbCrLf & vbCrLf

            Dim dvMean As DataView = dt.DefaultView
            dvMean.RowFilter = "CLR_PARAM_TEST IN (" & Y1AxisLabelName & ")"
            Dim dtMean As DataTable = dvMean.ToTable
            js &= "var primaryMean = [["
            For i As Integer = 0 To dtMean.Rows.Count - 1
                If i = dtMean.Rows.Count - 1 Then
                    js &= "'" & DateTime.Parse(dtMean.Rows(i)("CLR_DT_SAMPLING_DATE")).ToString("yyyy-MM-dd HH:mm") & "', " & dtMean.Rows(i)("CLR_PARAM_MIN") & "]]; " & vbCrLf
                Else
                    js &= "'" & DateTime.Parse(dtMean.Rows(i)("CLR_DT_SAMPLING_DATE")).ToString("yyyy-MM-dd HH:mm") & "', " & dtMean.Rows(i)("CLR_PARAM_MIN") & "], ["
                End If
            Next
            js &= vbCrLf

            dtMean.Reset()
            dt.DefaultView.RowFilter = String.Empty
            dvMean = dt.DefaultView
            dvMean.RowFilter = "CLR_PARAM_TEST IN (" & Y2AxisLabelName & ")"
            dtMean = dvMean.ToTable
            js &= "var secondaryMean = [["
            For i As Integer = 0 To dtMean.Rows.Count - 1
                If i = dtMean.Rows.Count - 1 Then
                    js &= "'" & DateTime.Parse(dtMean.Rows(i)("CLR_DT_SAMPLING_DATE")).ToString("yyyy-MM-dd HH:mm") & "', " & dtMean.Rows(i)("CLR_PARAM_MIN") & "]]; " & vbCrLf
                Else
                    js &= "'" & DateTime.Parse(dtMean.Rows(i)("CLR_DT_SAMPLING_DATE")).ToString("yyyy-MM-dd HH:mm") & "', " & dtMean.Rows(i)("CLR_PARAM_MIN") & "], ["
                End If
            Next
            js &= vbCrLf & vbCrLf

            '----------Code below is to count the number of required legends of the chart-------------
            dtMean.Reset()
            dt.DefaultView.RowFilter = String.Empty
            dvMean = dt.DefaultView
            dvMean.RowFilter = "CLR_PARAM_TEST IN (" & Y2AxisLabelName & ") AND CLR_PARAM_MIN>0"
            dtMean = dvMean.ToTable
            Dim legendCount As Integer = arrParamTests.Length + 1 'Number of campaigns plus AL Min
            If dtMean.Rows.Count > 0 Then
                legendCount = legendCount + 1 'If FE Min greater than zero present, then ONE more plus 1.
            End If
            '-----------------------------------------------------------------------------------------
            strPlots &= "primaryMean, secondaryMean]"
            js &= "opts = {" & vbCrLf &
           "title: '" & ChartTitle & "'," & vbCrLf &
           "series:[" & strAllChartSeries & "]," & vbCrLf &
           "//seriesColors: ['#FFA500', '#006400']," & vbCrLf &
           "seriesDefaults: { breakOnNull: true }," & vbCrLf &
           "axesDefaults: {" & vbCrLf &
           "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
           "tickOptions: {" & vbCrLf &
           "fontSize:'8pt'" & vbCrLf &
           "}" & vbCrLf &
           "}," & vbCrLf &
           "axes: {" & vbCrLf &
           "xaxis: {" & vbCrLf &
           "min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf &
           "renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
           "tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," & vbCrLf &
           "//tickInterval:'1 hour'," & vbCrLf &
           "pad:0" & vbCrLf &
           "}," & vbCrLf &
           "yaxis: { " & vbCrLf &
           "tickOptions: { formatString: '%.3f' }," & vbCrLf &
           "min: " & y1_min & "," & vbCrLf &
           "max: " & y1_max & "," & vbCrLf &
           "//autoscale:true," & vbCrLf &
           "label: '" & Y1Series & "'," & vbCrLf &
           "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
           "}," & vbCrLf &
           "y2axis: { " & vbCrLf &
           "tickOptions: { formatString: '%.3f' }," & vbCrLf &
           "min: " & y2_min & "," & vbCrLf &
           "max: " & y2_max & "," & vbCrLf &
           "//autoscale:true," & vbCrLf &
           "//tickOptions:{showGridline:false}," & vbCrLf &
           "label: '" & Y2Series & "'," & vbCrLf &
           "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
           "}" & vbCrLf &
           "}, animation:true," & vbCrLf &
           "cursor: {" & vbCrLf &
           "showTooltip: false," & vbCrLf &
           "zoom: true" & vbCrLf &
           "}," & vbCrLf &
           "//highlighter: {  show: 'true', tooltipFormatString: '%.1f', useAxesFormatters: false }," & vbCrLf &
           "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
           "legend: {" & vbCrLf &
           "show: true," & vbCrLf &
           "location: 's'," & vbCrLf &
           "labels: series," & vbCrLf &
           "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
           "placement: 'outsideGrid'," & vbCrLf &
           "rendererOptions: {" & vbCrLf &
           "numberRows: 1," & vbCrLf &
           "numberColumns: " & legendCount & "," & vbCrLf &
           "marginTop: 10" & vbCrLf &
           "}" & vbCrLf &
           "}" & vbCrLf &
           "};" & vbCrLf &
           "" & PlotName & " = $.jqplot('" & ContainerName & "', " & strPlots & ", opts);" & vbCrLf &
           "</script>" & vbCrLf

            LiteralName.Text = js
        Catch ex As Exception

        End Try
    End Sub

    Public Sub PlotLineChartWithSecondaryYAxisCampaignwiseEff(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal MinY1 As String, ByVal MaxY1 As String, ByVal MinY2 As String, ByVal MaxY2 As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal Y1AxisLabelName As String, ByVal Y2AxisLabelName As String, ByVal Y1Series As String, ByVal Y2Series As String)
        '---------------------------Separating Data Campaignwise------------------------------------------------------------
        '-------------------------------------------------------------------------------------------------------------------
        Dim Query = From val In dt.AsEnumerable() Where val.Field(Of String)("CZT_CAMP_AL_NEW") = "GI"
                    Select val Order By val.Field(Of DateTime)("CZT_TIMESTAMP")
        Dim dtGI As DataTable = Query.CopyToDataTable()
        Query = From val In dt.AsEnumerable() Where val.Field(Of String)("CZT_CAMP_AL_NEW") = "GA"
                Select val Order By val.Field(Of DateTime)("CZT_TIMESTAMP")
        Dim dtGA As DataTable = Query.CopyToDataTable()
        'dt contains data for FE. No need to separate.
        'Taking minimum and maximum value for the x-axis.
        Dim min_time, max_time As String
        min_time = Format(dt.Rows(0)(XAxisColName), "yyyy-MM-dd HH:mm")
        max_time = Format(dt.Rows(dt.Rows.Count - 1)(XAxisColName), "yyyy-MM-dd HH:mm")
        '---------------------------------End Of Separation------------------------------------------------------------------
        '--------------------------------------------------------------------------------------------------------------------

        'Below are the temporary datatables holding false record in between two rows having time difference of 24 hours or more.
        Dim dtGI_Temp As New DataTable
        dtGI_Temp.Columns.Add("CZT_TIMESTAMP", GetType(DateTime))
        dtGI_Temp.Columns.Add("CZT_EFF_AL", GetType(Decimal))
        dtGI_Temp.Columns.Add("CZT_EFF_FE", GetType(Decimal))
        dtGI_Temp.Columns.Add("CZT_MIN_VAL", GetType(Decimal))
        dtGI_Temp.Columns.Add("CZT_CAMP_AL", GetType(String))
        dtGI_Temp.Columns.Add("CZT_CAMP_AL_NEW", GetType(String))
        For i As Integer = 0 To dtGI.Rows.Count - 1
            Dim row As DataRow = dtGI_Temp.NewRow
            row("CZT_TIMESTAMP") = CDate(dtGI.Rows(i)("CZT_TIMESTAMP"))
            row("CZT_EFF_AL") = dtGI.Rows(i)("CZT_EFF_AL")
            row("CZT_EFF_FE") = dtGI.Rows(i)("CZT_EFF_FE")
            row("CZT_MIN_VAL") = dtGI.Rows(i)("CZT_MIN_VAL")
            row("CZT_CAMP_AL") = dtGI.Rows(i)("CZT_CAMP_AL")
            row("CZT_CAMP_AL_NEW") = dtGI.Rows(i)("CZT_CAMP_AL_NEW")
            dtGI_Temp.Rows.Add(row)
            If i < dtGI.Rows.Count - 1 Then
                Dim span As TimeSpan = DateTime.Parse(dtGI.Rows(i + 1)("CZT_TIMESTAMP")).Subtract(DateTime.Parse(dtGI.Rows(i)("CZT_TIMESTAMP")))
                If span.TotalHours >= 24 Then
                    dtGI_Temp.Rows.Add(DateTime.Parse(dtGI.Rows(i)("CZT_TIMESTAMP")).AddMinutes(10),
                                       0,
                                       dtGI.Rows(i)("CZT_EFF_FE"),
                                       dtGI.Rows(i)("CZT_MIN_VAL"),
                                       dtGI.Rows(i)("CZT_CAMP_AL"),
                                       dtGI.Rows(i)("CZT_CAMP_AL_NEW"))
                End If
            End If
        Next

        Dim dtGA_Temp As New DataTable
        dtGA_Temp.Columns.Add("CZT_TIMESTAMP", GetType(DateTime))
        dtGA_Temp.Columns.Add("CZT_EFF_AL", GetType(Decimal))
        dtGA_Temp.Columns.Add("CZT_EFF_FE", GetType(Decimal))
        dtGA_Temp.Columns.Add("CZT_MIN_VAL", GetType(Decimal))
        dtGA_Temp.Columns.Add("CZT_CAMP_AL", GetType(String))
        dtGA_Temp.Columns.Add("CZT_CAMP_AL_NEW", GetType(String))
        For i As Integer = 0 To dtGA.Rows.Count - 1
            Dim row As DataRow = dtGA_Temp.NewRow
            row("CZT_TIMESTAMP") = CDate(dtGA.Rows(i)("CZT_TIMESTAMP"))
            row("CZT_EFF_AL") = dtGA.Rows(i)("CZT_EFF_AL")
            row("CZT_EFF_FE") = dtGA.Rows(i)("CZT_EFF_FE")
            row("CZT_MIN_VAL") = dtGA.Rows(i)("CZT_MIN_VAL")
            row("CZT_CAMP_AL") = dtGA.Rows(i)("CZT_CAMP_AL")
            row("CZT_CAMP_AL_NEW") = dtGA.Rows(i)("CZT_CAMP_AL_NEW")
            dtGA_Temp.Rows.Add(row)
            If i < dtGA.Rows.Count - 1 Then
                Dim span As TimeSpan = DateTime.Parse(dtGA.Rows(i + 1)("CZT_TIMESTAMP")).Subtract(DateTime.Parse(dtGA.Rows(i)("CZT_TIMESTAMP")))
                If span.TotalHours >= 24 Then
                    dtGA_Temp.Rows.Add(DateTime.Parse(dtGA.Rows(i)("CZT_TIMESTAMP")).AddMinutes(10),
                                       0,
                                       dtGA.Rows(i)("CZT_EFF_FE"),
                                       dtGA.Rows(i)("CZT_MIN_VAL"),
                                       dtGA.Rows(i)("CZT_CAMP_AL"),
                                       dtGA.Rows(i)("CZT_CAMP_AL_NEW"))
                End If
            End If
        Next
        '---------------------------------------END OF TEMPORARY DATATABLES----------------------------------------------
        '----------------------------------------------------------------------------------------------------------------

        '----------Storing the campaigns in an array-----------------
        Dim size As Integer = 0
        Dim arrParamTests(size) As String
        If dtGA.Rows.Count > 0 Then
            arrParamTests(0) = "ZAZS"
        End If
        If dtGI.Rows.Count > 0 Then
            size = size + 1
            ReDim Preserve arrParamTests(size)
            arrParamTests(1) = "ZAGA"
        End If
        If dt.Rows.Count > 0 Then
            size = size + 1
            ReDim Preserve arrParamTests(size)
            arrParamTests(2) = "ZAFE"
        End If
        '--------------------------------------------------------------

        Dim strAllSeriesData As String = ""
        For i As Integer = 0 To arrParamTests.Length - 1
            If arrParamTests(i) = "ZAZS" Then 'For ZAGI
                Dim varAlSeries As String = "var lineE" & arrParamTests(i) & " = ["
                For j As Integer = 0 To dtGI_Temp.Rows.Count - 1
                    If dtGI_Temp.Rows(j)("CZT_EFF_AL") < 1 Then
                        varAlSeries &= "['" & CDate(dtGI_Temp.Rows(j)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGI_Temp.Rows(j)("CZT_EFF_AL") = 0, "null", dtGI_Temp.Rows(j)("CZT_EFF_AL")) & ", 'ZAGI'], "
                    End If
                Next
                varAlSeries = varAlSeries.Remove(varAlSeries.LastIndexOf(", "))
                varAlSeries &= "];" & vbCrLf & vbCrLf
                strAllSeriesData &= varAlSeries
            ElseIf arrParamTests(i) = "ZAGA" Then 'For ZAGA
                Dim varAlSeries As String = "var lineE" & arrParamTests(i) & " = ["
                For j As Integer = 0 To dtGA_Temp.Rows.Count - 1
                    If dtGA_Temp.Rows(j)("CZT_EFF_AL") < 1 Then
                        varAlSeries &= "['" & CDate(dtGA_Temp.Rows(j)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGA_Temp.Rows(j)("CZT_EFF_AL") = 0, "null", dtGA_Temp.Rows(j)("CZT_EFF_AL")) & ", 'ZAGA'], "
                    End If
                Next
                varAlSeries = varAlSeries.Remove(varAlSeries.LastIndexOf(", "))
                varAlSeries &= "];" & vbCrLf & vbCrLf
                strAllSeriesData &= varAlSeries
            ElseIf arrParamTests(i) = "ZAFE" Then 'For ZAFE
                Dim varFeSeries As String = "var lineE" & arrParamTests(i) & " = ["
                For j As Integer = 0 To dt.Rows.Count - 1
                    If dt.Rows(j)("CZT_EFF_FE") < 1 Then 'And dt.Rows(j)("CZT_EFF_FE") > 0.015 Then 'Need to be checked
                        varFeSeries &= "['" & CDate(dt.Rows(j)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dt.Rows(j)("CZT_EFF_FE") & ", 'ZAFE'], "
                    End If
                Next
                varFeSeries = varFeSeries.Remove(varFeSeries.LastIndexOf(", "))
                varFeSeries &= "];" & vbCrLf & vbCrLf
                strAllSeriesData &= varFeSeries
            End If
        Next

        Dim strAllChartSeries As String = ""
        Dim strSeries As String = "["
        Dim strPlots As String = "["
        For i As Integer = 0 To arrParamTests.Length - 1
            If arrParamTests(i) <> "ZAFE" Then 'For ZAZS, ZAGA
                Dim testName As String = ""
                If arrParamTests(i) = "ZAZS" Then
                    testName = "GI"
                ElseIf arrParamTests(i) = "ZAGA" Then
                    testName = "GA"
                End If
                strSeries &= "'" & testName & "', "
                strPlots &= "lineE" & arrParamTests(i) & ", "
                Dim lineColor As String = ""
                If arrParamTests(i) = "ZAGA" Then
                    lineColor = "#0B7C0B"
                ElseIf arrParamTests(i) = "ZAZS" Then
                    lineColor = "#4832DB"
                End If
                strAllChartSeries &= "{pointLabels: { show:false }, showLine: true,breakOnNull: true,color: '" & lineColor & "',yaxis: 'yaxis',lineWidth: 2,markerOptions: {size: 5},highlighter: {show: true,showMarker: false,tooltipAxes: 'xy',yvalues: 2,formatString: '<table style=""height:80px; width:180px; background-color:" & lineColor & "; font-weight:bold; font-size:x-large; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td><center>%s</center></td></tr></table>'}},"
            End If
        Next
        For i As Integer = 0 To arrParamTests.Length - 1
            If arrParamTests(i) = "ZAFE" Then 'For ZAFE
                strSeries &= "'" & IIf(arrParamTests(i) = "ZAFE", "FE", arrParamTests(i)) & "', "
                strPlots &= "lineE" & arrParamTests(i) & ", "
                strAllChartSeries &= "{pointLabels: { show:false }, showLine: true,color: '#000000',yaxis: 'y2axis',lineWidth: 2,markerOptions: {size: 5},highlighter: {show: true,showMarker: false,tooltipAxes: 'xy',yvalues: 2,formatString: '<table style=""height:80px; width:180px; background-color:#000000; font-weight:bold; font-size:x-large; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td><center>%s</center></td></tr></table>'}},"
            End If
        Next
        strSeries &= "'AL Min'];"
        strAllChartSeries &= "{pointLabels: { show:false }, showLine: true,lineWidth: 2,showMarker: false,color: '#BA3030',highlighter: {show: true,showMarker: false,tooltipAxes: 'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}},"
        strAllChartSeries &= "{pointLabels: { show:false }, showLine: true,lineWidth: 2,showMarker: false,color: '#3584B2',highlighter: {show: true,showMarker: false,tooltipAxes: 'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"

        Dim y1_min As String = 0
        Dim y1_max As String = 0.3
        Dim y2_min As String = 0
        Dim y2_max As String = 0.05

        Dim js = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                "$.jqplot.config.enablePlugins = true;" & vbCrLf &
                "var seriesE= " & strSeries & "" & vbCrLf

        js &= strAllSeriesData & vbCrLf & vbCrLf

        ''Below lines are commented, but important.
        'For i As Integer = 0 To arrParamTests.Length - 1
        '    If arrParamTests(i) <> "ZAFE" Then
        '        If i > 0 Then
        '            Y1AxisLabelName &= "',"
        '        End If
        '        Y1AxisLabelName &= "'" & arrParamTests(i)
        '    End If
        'Next
        'Dim dvMean As DataView = dt.DefaultView
        'dvMean.RowFilter = "CZT_CAMP_AL_NEW IN ('GI','GA')"
        'Dim dtMean As DataTable = dvMean.ToTable
        js &= "var primaryMeanE = [["
        For i As Integer = 0 To dt.Rows.Count - 1
            If i = dt.Rows.Count - 1 Then
                js &= "'" & CDate(dt.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dt.Rows(i)("CZT_MIN_VAL") & "]]; " & vbCrLf
            Else
                js &= "'" & CDate(dt.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dt.Rows(i)("CZT_MIN_VAL") & "], ["
            End If
        Next
        js &= vbCrLf & vbCrLf

        'Below lines are commented, but important.
        'dtMean.Reset()
        'dt.DefaultView.RowFilter = String.Empty
        'dvMean = dt.DefaultView
        'dvMean.RowFilter = "CLR_PARAM_TEST IN (" & Y2AxisLabelName & ")"
        'dtMean = dvMean.ToTable
        'js &= "var secondaryMean = [["
        'For i As Integer = 0 To dtFe.Rows.Count - 1
        '    If i = dtFe.Rows.Count - 1 Then
        '        js &= "'" & DateTime.Parse(dtFe.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', 0]]; " & vbCrLf
        '    Else
        '        js &= "'" & DateTime.Parse(dtFe.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', 0], ["
        '    End If
        'Next
        'js &= vbCrLf & vbCrLf

        '----------Code below is to count the number of required legends of the chart-------------
        'dtMean.Reset()
        'dt.DefaultView.RowFilter = String.Empty
        'dvMean = dt.DefaultView
        'dvMean.RowFilter = "CLR_PARAM_TEST IN (" & Y2AxisLabelName & ") AND CLR_PARAM_MIN>0"
        'dtMean = dvMean.ToTable
        Dim legendCount As Integer = arrParamTests.Length + 1 'Number of campaigns plus AL Min
        'If dtMean.Rows.Count > 0 Then
        '    legendCount = legendCount + 1 'If FE Min greater than zero present, then ONE more plus 1.
        'End If
        '-----------------------------------------------------------------------------------------
        strPlots &= "primaryMeanE]"
        ChartTitle = ""
        js &= "opts = {" & vbCrLf &
        "title: '" & ChartTitle & "'," & vbCrLf &
        "series:[" & strAllChartSeries & "]," & vbCrLf &
        "//seriesColors: ['#FFA500', '#006400']," & vbCrLf &
        "axesDefaults: {" & vbCrLf &
        "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
        "tickOptions: {" & vbCrLf &
        "fontSize:'8pt'" & vbCrLf &
        "}" & vbCrLf &
        "}," & vbCrLf &
        "axes: {" & vbCrLf &
        "xaxis: {" & vbCrLf &
        "min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf &
        "renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
        "tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," & vbCrLf &
        "//tickInterval:'1 hour'," & vbCrLf &
        "pad:0" & vbCrLf &
        "}," & vbCrLf &
        "yaxis: { " & vbCrLf &
        "tickOptions: { formatString: '%.3f' }," & vbCrLf &
        "min: " & y1_min & "," & vbCrLf &
        "max: " & y1_max & "," & vbCrLf &
        "//autoscale:true," & vbCrLf &
        "label: '" & Y1Series & "'," & vbCrLf &
        "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
        "}," & vbCrLf &
        "y2axis: { " & vbCrLf &
        "tickOptions: { formatString: '%.3f' }," & vbCrLf &
        "min: " & y2_min & "," & vbCrLf &
        "max: " & y2_max & "," & vbCrLf &
        "//autoscale:true," & vbCrLf &
        "//tickOptions:{showGridline:false}," & vbCrLf &
        "label: '" & Y2Series & "'," & vbCrLf &
        "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
        "}" & vbCrLf &
        "}, animation:true," & vbCrLf &
        "cursor: {" & vbCrLf &
        "showTooltip: false," & vbCrLf &
        "zoom: true" & vbCrLf &
        "}," & vbCrLf &
        "//highlighter: {  show: 'true', tooltipFormatString: '%.1f', useAxesFormatters: false }," & vbCrLf &
        "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
        "legend: {" & vbCrLf &
        "show: true," & vbCrLf &
        "location: 's'," & vbCrLf &
        "labels: seriesE," & vbCrLf &
        "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
        "placement: 'outsideGrid'," & vbCrLf &
        "rendererOptions: {" & vbCrLf &
        "numberRows: 1," & vbCrLf &
        "numberColumns: " & legendCount & "," & vbCrLf &
        "marginTop: 10" & vbCrLf &
        "}" & vbCrLf &
        "}" & vbCrLf &
        "};" & vbCrLf &
        "" & PlotName & " = $.jqplot('" & ContainerName & "', " & strPlots & ", opts);" & vbCrLf &
        "</script>" & vbCrLf

        LiteralName.Text = js
    End Sub

    Sub PlotBoxPlotChart(ByVal dt As DataTable, ByVal yValue As String, ByVal lit As Literal, ByVal containerName As String, ByVal PlotName As String, ByVal DataVariable As String, ByVal seriesOf As String, ByVal OutlierDataVariable As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String, ByVal AvgVarName As String)
        lit.Text = ""
        Try
            ChartTitle = ""
            Dim js = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                "var " & DataVariable & " = ["
            'Dim Series() = (From row In dt Select col = row.Field(Of String)(seriesOf) Distinct).ToArray
            Dim Series() = (From row In dt Select col = row.Field(Of Decimal)(seriesOf) Distinct).ToArray
            Dim strarr As New ArrayList
            Dim AvgData = ""
            Dim tickOptions As String = IIf(Series.Length > 8, "tickOptions:{ angle: -30 },", "")
            For i As Integer = 0 To Series.Length - 1 'MAIN LOOP
                Dim x = i
                'Dim query = From val In dt.AsEnumerable() Where val.Field(Of String)(seriesOf) = Series(x) Select val
                Dim query = From val In dt.AsEnumerable() Where val.Field(Of Decimal)(seriesOf) = Series(x) Select val
                Dim dtValue = query.CopyToDataTable()
                Dim arrYValues(dtValue.Rows.Count) As Decimal
                arrYValues = (From row In dtValue Select col = Decimal.Parse(row(Trim(yValue)).ToString()) Where col < 1).ToArray
                Array.Sort(arrYValues)
                Dim plot1 As New BoxPlotSeriesMgr
                Dim arrVal() As Double = plot1.GetValuesForBoxPlot(arrYValues)
                Dim xAxisTick As String = ""
                If dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAAL" Then
                    xAxisTick = "Eff. Al_AL"
                ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAGA" Then
                    xAxisTick = "Eff. Al_GA"
                ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAZS" Then
                    xAxisTick = "Eff. Al_GI"
                ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAFE" Then
                    xAxisTick = "Eff. Iron"
                End If
                If i = Series.Length - 1 Then
                    js &= "" &
                    "['" & xAxisTick & "', " & arrVal(4) & ", " & arrVal(1) & ", " & arrVal(8) & ", " & arrVal(5) & ", " & arrYValues.Length & "]];"

                    AvgData &= "" &
                    "['" & xAxisTick & "', " & (arrYValues.Average) & "]];"
                Else
                    js &= "" &
                    "['" & xAxisTick & "', " & arrVal(4) & ", " & arrVal(1) & ", " & arrVal(8) & ", " & arrVal(5) & ", " & arrYValues.Length & "], "

                    AvgData &= "" &
                    "['" & xAxisTick & "', " & (arrYValues.Average) & "], "
                End If

                'Making data for outliers :-
                For j = 0 To arrYValues.Length - 1
                    If arrVal(8) >= arrYValues(j) Then
                        strarr.Add("['" & xAxisTick & "'," & arrYValues(j) & "]")
                    ElseIf arrVal(9) <= arrYValues(j) Then
                        strarr.Add("['" & xAxisTick & "'," & arrYValues(j) & "]")
                    End If
                Next
            Next 'MAIN LOOP ENDS

            js &= "" & vbCrLf

            'For Average Points

            js &= "var " & AvgVarName & " = [" & AvgData
            js &= "" & vbCrLf

            js &= vbCrLf
            'Storing outliers data in as variable.
            js &= "var " & OutlierDataVariable & " = ["
            For rw As Integer = 0 To strarr.Count - 1
                If rw > 0 Then
                    js &= ","
                End If
                js &= strarr(rw)
            Next
            js &= "];" & vbCrLf

            js &= "" & vbCrLf &
                    "$(document).ready(function () {" & vbCrLf &
                            "$.jqplot.config.enablePlugins = true;" & vbCrLf &
                            "title: '" & ChartTitle & "'," & vbCrLf &
                            PlotName & " = $.jqplot('" & containerName & "', [" & DataVariable & ", " & OutlierDataVariable & ", " & AvgVarName & "], {" & vbCrLf &
                            "axesDefaults: { tickRenderer: $.jqplot.CanvasAxisTickRenderer, tickOptions: {fontSize: '8pt'}}," & vbCrLf &
                            "axes: {" & vbCrLf &
                                "xaxis: {" & vbCrLf &
                                    "renderer:$.jqplot.CategoryAxisRenderer," & vbCrLf &
                                    "label: ''," & vbCrLf &
                                    tickOptions & vbCrLf &
                                    "//tickOptions: { formatString: '%d-%m-%y' }" & vbCrLf &
                                "}," & vbCrLf &
                                "yaxis: {" & vbCrLf &
                                    "label: '" & YAxisLabelName & "'," & vbCrLf &
                                    "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
                                "}," & vbCrLf &
                            "}, animate: true, " & vbCrLf &
                            "title: '" & ChartTitle & "'," & vbCrLf &
                            "series: [" & vbCrLf &
                            "       {" & vbCrLf &
                            "           highlighter: {show: true, showMarker: false,tooltipAxes:'xy',yvalues: 5,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td style=""display: none;"">Observations: </td><td style=""display: none;"">%s</td></tr> \ <tr><td>Upper Quartile: </td><td>%s</td></tr> \ <tr><td>Maximum: </td><td>%s</td></tr> \ <tr><td>Minimum: </td><td>%s</td></tr> \ <tr><td>Lower Quartile: </td><td>%s</td></tr> \ <tr><td>No Of Data Points: </td><td>%s</td></tr> </table>' }," & vbCrLf &
                            "           renderer: $.jqplot.OHLCRenderer, rendererOptions: {" & vbCrLf &
                            "               candleStick: true, lineWidth: 2, bodyWidth: 40, wickColor: '#60A62E', upBodyColor: '#00008B', downBodyColor: '#00008B'" & vbCrLf &
                            "           }" & vbCrLf &
                            "       }," & vbCrLf &
                            "{showLine:false, markerOptions: {style: ""circle"", shadow: false, color: '#4BB2C5'}, highlighter: {show: true, showMarker: false,tooltipAxes:'xy',yvalues: 1,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td style=""display:none;"">%s</td></tr> \ <tr><td>%s</td></tr> </table>' }}," & vbCrLf &
                            "{lineWidth:1, color: '#006400', showLine: false, showMarker:true, markerOptions: { style: 'filledCircle' }, highlighter: {show: true, showMarker: false,tooltipAxes:'xy',yvalues: 1,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td style=""display:none;"">%s</td></tr> \ <tr><td>%s</td></tr> </table>' }}" & vbCrLf &
                            "]," & vbCrLf &
                            "//seriesDefaults:{pointLabels:{show:false}}," & vbCrLf &
                            "" & vbCrLf &
                            "" & vbCrLf &
                            "" & vbCrLf &
                            "cursor: {" & vbCrLf &
                            "zoom: true," & vbCrLf &
                            "show: true," & vbCrLf &
                            "}," & vbCrLf &
                            "grid: {backgroundColor: 'rgb(255,255,255)'}," & vbCrLf &
                        "});" & vbCrLf &
                    "});" & vbCrLf &
                "</script>"
            lit.Text = js
        Catch ex As Exception

        End Try
    End Sub

    Sub PlotBoxPlotChart1(ByVal dt As DataTable, ByVal yValue As String, ByVal lit As Literal, ByVal containerName As String, ByVal PlotName As String, ByVal DataVariable As String, ByVal seriesOf As String, ByVal OutlierDataVariable As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String, ByVal AvgVarName As String, ByVal Campaign As String)
        lit.Text = ""
        Try
            ChartTitle = ""
            Dim js = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                "var " & DataVariable & " = ["
            'Dim Series() = (From row In dt Select col = row.Field(Of String)(seriesOf) Distinct).ToArray
            Dim Series() = (From row In dt Select col = row.Field(Of Decimal)(seriesOf) Distinct).ToArray
            Dim strarr As New ArrayList
            Dim AvgData = ""
            Dim tickOptions As String = IIf(Series.Length > 8, "tickOptions:{ angle: -30 },", "")
            For i As Integer = 0 To Series.Length - 1 'MAIN LOOP
                Dim x = i
                'Dim query = From val In dt.AsEnumerable() Where val.Field(Of String)(seriesOf) = Series(x) Select val
                Dim query = From val In dt.AsEnumerable() Where val.Field(Of Decimal)(seriesOf) = Series(x) Select val
                Dim dtValue = query.CopyToDataTable()
                Dim arrYValues(dtValue.Rows.Count) As Decimal

                If Campaign.Contains("Aluminium") Or Campaign.Contains("Iron") Or Campaign.Contains("Aluminium,Iron") Then
                    arrYValues = (From row In dtValue Select col = Decimal.Parse(row(Trim(yValue)).ToString()) Where col < 1).ToArray
                Else
                    arrYValues = (From row In dtValue Select col = Decimal.Parse(row(Trim(yValue)).ToString())).ToArray
                End If

                Array.Sort(arrYValues)
                Dim plot1 As New BoxPlotSeriesMgr
                Dim arrVal() As Double = plot1.GetValuesForBoxPlot(arrYValues)
                Dim xAxisTick As String = ""
                If Campaign.Contains("Aluminium") Or Campaign.Contains("Iron") Or Campaign.Contains("Aluminium,Iron") Then
                    If dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAAL" Then
                        xAxisTick = "Eff. Al_AL"
                    ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAGA" Then
                        xAxisTick = "Eff. Al_GA"
                    ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAZS" Then
                        xAxisTick = "Eff. Al_GI"
                    ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAFE" Then
                        xAxisTick = "Eff. Iron"
                    End If
                Else
                    xAxisTick = Series(i)
                End If

                If i = Series.Length - 1 Then
                    js &= "" &
                    "['" & xAxisTick & "', " & arrVal(4) & ", " & arrVal(1) & ", " & arrVal(8) & ", " & arrVal(5) & ", " & arrYValues.Length & "]];"

                    AvgData &= "" &
                    "['" & xAxisTick & "', " & (arrYValues.Average) & "]];"
                Else
                    js &= "" &
                    "['" & xAxisTick & "', " & arrVal(4) & ", " & arrVal(1) & ", " & arrVal(8) & ", " & arrVal(5) & ", " & arrYValues.Length & "], "

                    AvgData &= "" &
                    "['" & xAxisTick & "', " & (arrYValues.Average) & "], "
                End If

                'Making data for outliers :-
                For j = 0 To arrYValues.Length - 1
                    If arrVal(8) >= arrYValues(j) Then
                        strarr.Add("['" & xAxisTick & "'," & arrYValues(j) & "]")
                    ElseIf arrVal(9) <= arrYValues(j) Then
                        strarr.Add("['" & xAxisTick & "'," & arrYValues(j) & "]")
                    End If
                Next
            Next 'MAIN LOOP ENDS

            js &= "" & vbCrLf

            'For Average Points

            js &= "var " & AvgVarName & " = [" & AvgData
            js &= "" & vbCrLf

            js &= vbCrLf
            'Storing outliers data in as variable.
            js &= "var " & OutlierDataVariable & " = ["
            For rw As Integer = 0 To strarr.Count - 1
                If rw > 0 Then
                    js &= ","
                End If
                js &= strarr(rw)
            Next
            js &= "];" & vbCrLf

            js &= "" & vbCrLf &
                    "$(document).ready(function () {" & vbCrLf &
                            "$.jqplot.config.enablePlugins = true;" & vbCrLf &
                            "title: '" & ChartTitle & "'," & vbCrLf &
                            PlotName & " = $.jqplot('" & containerName & "', [" & DataVariable & ", " & OutlierDataVariable & ", " & AvgVarName & "], {" & vbCrLf &
                            "axesDefaults: { tickRenderer: $.jqplot.CanvasAxisTickRenderer, tickOptions: {fontSize: '8pt'}}," & vbCrLf &
                            "axes: {" & vbCrLf &
                                "xaxis: {" & vbCrLf &
                                    "renderer:$.jqplot.CategoryAxisRenderer," & vbCrLf &
                                    "label: ''," & vbCrLf &
                                    tickOptions & vbCrLf &
                                    "//tickOptions: { formatString: '%d-%m-%y' }" & vbCrLf &
                                "}," & vbCrLf &
                                "yaxis: {" & vbCrLf &
                                    "label: '" & YAxisLabelName & "'," & vbCrLf &
                                    "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
                                "}," & vbCrLf &
                            "}, animate: true, " & vbCrLf &
                            "title: '" & ChartTitle & "'," & vbCrLf &
                            "series: [" & vbCrLf &
                            "       {" & vbCrLf &
                            "           highlighter: {show: true, showMarker: false,tooltipAxes:'xy',yvalues: 5,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td style=""display: none;"">Observations: </td><td style=""display: none;"">%s</td></tr> \ <tr><td>Upper Quartile: </td><td>%s</td></tr> \ <tr><td>Maximum: </td><td>%s</td></tr> \ <tr><td>Minimum: </td><td>%s</td></tr> \ <tr><td>Lower Quartile: </td><td>%s</td></tr> \ <tr><td>No Of Data Points: </td><td>%s</td></tr> </table>' }," & vbCrLf &
                            "           renderer: $.jqplot.OHLCRenderer, rendererOptions: {" & vbCrLf &
                            "               candleStick: true, lineWidth: 2, bodyWidth: 40, wickColor: '#60A62E', upBodyColor: '#00008B', downBodyColor: '#00008B'" & vbCrLf &
                            "           }" & vbCrLf &
                            "       }," & vbCrLf &
                            "{showLine:false, markerOptions: {style: ""circle"", shadow: false, color: '#4BB2C5'}, highlighter: {show: true, showMarker: false,tooltipAxes:'xy',yvalues: 1,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td style=""display:none;"">%s</td></tr> \ <tr><td>%s</td></tr> </table>' }}," & vbCrLf &
                            "{lineWidth:1, color: '#006400', showLine: false, showMarker:true, markerOptions: { style: 'filledCircle' }, highlighter: {show: true, showMarker: false,tooltipAxes:'xy',yvalues: 1,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td style=""display:none;"">%s</td></tr> \ <tr><td>%s</td></tr> </table>' }}" & vbCrLf &
                            "]," & vbCrLf &
                            "seriesDefaults:{pointLabels:{show:false}}," & vbCrLf &
                            "" & vbCrLf &
                            "" & vbCrLf &
                            "" & vbCrLf &
                            "cursor: {" & vbCrLf &
                            "zoom: true," & vbCrLf &
                            "show: true," & vbCrLf &
                            "}," & vbCrLf &
                            "grid: {backgroundColor: 'rgb(255,255,255)'}," & vbCrLf &
                        "});" & vbCrLf &
                    "});" & vbCrLf &
                "</script>"
            lit.Text = js
        Catch ex As Exception

        End Try
    End Sub

    Public Sub GetColumnNames(ByVal listColumnName As ListBox, ByVal tableName As String)
        listColumnName.DataSource = objDataHandler.GetDataSetFromQuery("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS  WHERE TABLE_NAME = '" & tableName & "' ").Tables(0)
        listColumnName.DataTextField = "COLUMN_NAME"
        listColumnName.DataValueField = "COLUMN_NAME"
        listColumnName.SelectedIndex = -1
        listColumnName.DataBind()
    End Sub

    'Public Sub PlotLineChartWithSecondaryYAxis(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal MinY1 As String, ByVal MaxY1 As String, ByVal MinY2 As String, ByVal MaxY2 As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal Y1AxisLabelName As String, ByVal Y2AxisLabelName As String, ByVal PriDataVarName As String, ByVal SecDataVarName As String)
    '    Try
    '        Dim min_time, max_time As String
    '        min_time = Format(dt.Rows(0)(XAxisColName), "yyyy-MM-dd HH:mm")
    '        max_time = Format(dt.Rows(dt.Rows.Count - 1)(XAxisColName), "yyyy-MM-dd HH:mm")

    '        'Dim y1Values(), y2Values() As String

    '        'xValues = (From row In dt Select col = row(XAxisColName).ToString).ToArray
    '        'y1Values = (From row In dt Select col = row(ColNameForY1)).ToArray
    '        'y2Values = (From row In dt Select col = row(ColNameForY2)).ToArray

    '        Dim y1_min As String = MinY1
    '        Dim y1_max As String = MaxY1
    '        Dim y2_min As String = MinY2
    '        Dim y2_max As String = MaxY2

    '        Dim js = "<script language='javascript' type='text/javascript'>" & vbCrLf & _
    '                "$.jqplot.config.enablePlugins = true;" & vbCrLf & _
    '                "var series= ['" & Y1AxisLabelName & "', '" & Y2AxisLabelName & "'];" & vbCrLf & _
    '                "var " & PriDataVarName & " = [["
    '        For i = 0 To dt.Rows.Count - 1
    '            If dt.Rows(i)("CLR_PARAM_TEST") = Y1AxisLabelName Then
    '                If i = dt.Rows.Count - 1 Then
    '                    js &= "'" & DateTime.Parse(dt.Rows(i)("CLR_DT_SAMPLING_DATE")).ToString("yyyy-MM-dd HH:mm") & "', " & dt.Rows(i)("CLR_TEST_VALUE") & "]]; " & vbCrLf
    '                Else
    '                    js &= "'" & DateTime.Parse(dt.Rows(i)("CLR_DT_SAMPLING_DATE")).ToString("yyyy-MM-dd HH:mm") & "', " & dt.Rows(i)("CLR_TEST_VALUE") & "], ["
    '                End If
    '            End If
    '        Next
    '        js = js.Remove(js.LastIndexOf(", ["))
    '        js &= "];" & vbCrLf

    '        js &= "var " & SecDataVarName & " = [["
    '        For i = 0 To dt.Rows.Count - 1
    '            If dt.Rows(i)("CLR_PARAM_TEST") = Y2AxisLabelName Then
    '                If i = dt.Rows.Count - 1 Then
    '                    js &= "'" & DateTime.Parse(dt.Rows(i)("CLR_DT_SAMPLING_DATE")).ToString("yyyy-MM-dd HH:mm") & "', " & dt.Rows(i)("CLR_TEST_VALUE") & "]]; " & vbCrLf
    '                Else
    '                    js &= "'" & DateTime.Parse(dt.Rows(i)("CLR_DT_SAMPLING_DATE")).ToString("yyyy-MM-dd HH:mm") & "', " & dt.Rows(i)("CLR_TEST_VALUE") & "], ["
    '                End If
    '            End If
    '        Next
    '        js = js.Remove(js.LastIndexOf(", ["))
    '        js &= "];" & vbCrLf

    '        js &= "opts = {" & vbCrLf & _
    '        "title: '" & ChartTitle & "'," & vbCrLf & _
    '        "series:[{showLine: true}, {showLine: true, yaxis:'y2axis'}]," & vbCrLf & _
    '        "//seriesColors: ['#FFA500', '#006400']," & vbCrLf & _
    '        "axesDefaults: {" & vbCrLf & _
    '        "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf & _
    '        "tickOptions: {" & vbCrLf & _
    '        "fontSize:'8pt'" & vbCrLf & _
    '        "}" & vbCrLf & _
    '        "}," & vbCrLf & _
    '        "axes: {" & vbCrLf & _
    '        "xaxis: {" & vbCrLf & _
    '        "min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf & _
    '        "renderer:$.jqplot.DateAxisRenderer," & vbCrLf & _
    '        "tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," & vbCrLf & _
    '        "//tickInterval:'1 hour'," & vbCrLf & _
    '        "pad:0" & vbCrLf & _
    '        "}," & vbCrLf & _
    '        "yaxis: { " & vbCrLf & _
    '        "tickOptions: { formatString: '%.3f' }," & vbCrLf & _
    '        "min: " & y1_min & "," & vbCrLf & _
    '        "max: " & y1_max & "," & vbCrLf & _
    '        "//autoscale:true," & vbCrLf & _
    '        "label: '" & Y1AxisLabelName & "'," & vbCrLf & _
    '        "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf & _
    '        "}," & vbCrLf & _
    '        "y2axis: { " & vbCrLf & _
    '        "tickOptions: { formatString: '%.3f' }," & vbCrLf & _
    '        "min: " & y2_min & "," & vbCrLf & _
    '        "max: " & y2_max & "," & vbCrLf & _
    '        "//autoscale:true," & vbCrLf & _
    '        "//tickOptions:{showGridline:false}," & vbCrLf & _
    '        "label: '" & Y2AxisLabelName & "'," & vbCrLf & _
    '        "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf & _
    '        "}" & vbCrLf & _
    '        "}," & vbCrLf & _
    '        "cursor: {" & vbCrLf & _
    '        "zoom: true" & vbCrLf & _
    '        "}," & vbCrLf & _
    '        "//highlighter: {  show: 'true', tooltipFormatString: '%.1f', useAxesFormatters: false }," & vbCrLf & _
    '        "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf & _
    '        "legend: {" & vbCrLf & _
    '        "show: true," & vbCrLf & _
    '        "location: 's'," & vbCrLf & _
    '        "labels: series," & vbCrLf & _
    '        "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf & _
    '        "placement: 'outsideGrid'," & vbCrLf & _
    '        "rendererOptions: {" & vbCrLf & _
    '        "numberRows: 1," & vbCrLf & _
    '        "marginTop: 10" & vbCrLf & _
    '        "}" & vbCrLf & _
    '        "}" & vbCrLf & _
    '        "};" & vbCrLf & _
    '        "" & PlotName & " = $.jqplot('" & ContainerName & "', [" & PriDataVarName & ", " & SecDataVarName & "], opts);" & vbCrLf & _
    '        "</script>" & vbCrLf

    '        LiteralName.Text = js
    '    Catch ex As Exception

    '    End Try
    'End Sub

    Public Function GetCoatingData(ByVal FromDate As String, ByVal ToDate As String) As DataTable
        Try
            Return objDataHandler.GetDataSetFromQuery("SELECT CLR_DT_SAMPLING_DATE,CLR_PARAM_TEST,CLR_TEST_VALUE FROM CRM_LABTEST_RES WHERE CLR_DT_SAMPLING_DATE BETWEEN '" & FromDate & "' AND '" & FromDate & "'").Tables(0)
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

    End Function

  
    '...............................rekha.....................................

    Public Function GetWetChemicalTestData(ByVal TableName As String, ByVal FromDate As String, ByVal ToDate As String, ByVal DateColumn As String, ByVal Filter As String) As DataTable
        Dim query As String = ""
        If Filter <> "" Then
            query = "select CLR_TEST_VALUE,CLR_DT_SAMPLING_DATE,ISNULL(CLR_PARAM_MIN,0) AS CLR_PARAM_MIN,CLR_PARAM_TEST from " & TableName & " where " & DateColumn & " between '" & FromDate & "' and '" & ToDate & "' and cast(CLR_TEST_VALUE as float)>0 and " & Filter & " order by CLR_DT_SAMPLING_DATE"
        Else
            query = "select CLR_TEST_VALUE,CLR_DT_SAMPLING_DATE,ISNULL(CLR_PARAM_MIN,0) AS CLR_PARAM_MIN,CLR_PARAM_TEST from " & TableName & " where " & DateColumn & " between '" & FromDate & "' and '" & ToDate & "' and cast(CLR_TEST_VALUE as float)>0 order by CLR_DT_SAMPLING_DATE"
        End If
        Return objDataHandler.GetDataSetFromQuery(query).Tables(0)
    End Function

    Public Sub PlotLineChart(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String)
        Try
            'For i As Integer = 0 To dt.Rows.Count - 1
            '    If IsDBNull(dt.Rows(i)("LTRI_PARA_MIN")) Then
            '        dt.Rows(i)("LTRI_PARA_MIN") = dt.Rows(i)("LTRI_PARA_MIN").ToString().Replace(vbNull, vbDecimal)
            '    End If
            'Next
            LiteralName.Text = ""
            Dim min_time, max_time As String
            min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-30), "yyyy-MM-dd HH:mm")
            max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm")

            Dim xTimestampVal(), yVal() As String

            xTimestampVal = (From row In dt Select col = row(XAxisColName).ToString).ToArray
            yVal = (From row In dt Select col = row(YAxisColName).ToString).ToArray()

            Dim y_min As String = yVal.Min()
            Dim y_max As String = yVal.Max()

            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf
            dt.DefaultView.RowFilter = ""
            Dim dtGrades As DataTable = dt.DefaultView.ToTable(True, "CLR_PARAM_MIN") 'All distinct Grades
            Dim dvDefault As DataView = dt.DefaultView
            Dim flag As Boolean = False
            For i As Integer = 0 To dtGrades.Rows.Count - 1
                js &= "var line" & (i + 1).ToString & " = ["
                dvDefault.RowFilter = "CLR_PARAM_MIN='" & dtGrades.Rows(i)(0) & "'"
                For j As Integer = 0 To dvDefault.Count - 1
                    If j > 0 Then
                        js &= ","
                    End If
                    js &= "["
                    Dim dtTime As DateTime = dvDefault.Item(j)("CLR_DT_SAMPLING_DATE")
                    If IsDBNull(dvDefault.Item(j)("CLR_PARAM_MIN")) Then
                        If IsDBNull(dvDefault.Item(j)("CLR_TEST_VALUE")) = False Then
                            js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)("CLR_TEST_VALUE") & ", " & "null"
                        Else
                            js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & "null, null"
                        End If
                    Else
                        If IsDBNull(dvDefault.Item(j)("CLR_TEST_VALUE")) = False Then
                            js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)("CLR_TEST_VALUE") & ", '(" & dvDefault.Item(j)("CLR_PARAM_MIN").ToString().Trim & ")'"
                            'js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)("CLR_TEST_VALUE") & ", 'Pot'"
                        End If
                    End If
                    js &= "]"
                Next
                js &= "];" & vbCrLf
                flag = True
            Next

            Dim strg As String = ""
            Dim strseries As String = ""
            If flag Then
                strg = "[line1"
                strseries = " {showLine:true, markerOptions:{ size: 7 }}"
                For i As Integer = 1 To dtGrades.Rows.Count - 1
                    strg = strg + ",line" & i + 1
                    strseries = strseries + ", { showLine:true, markerOptions:{ size: 7 }}"
                Next
                strg &= "]"
            End If
            js &= "var seriesName = ['"
            Dim str As String = ""
            For i As Integer = 0 To dtGrades.Rows.Count - 1
                str &= dtGrades.Rows(i)(0).ToString().Trim() + "', '"
            Next
            str = str.Remove(str.LastIndexOf(", '"))
            str &= "];"
            js &= str


            'For i = 0 To dt.Rows.Count - 1
            '    If i = xTimestampVal.Length - 1 Then
            '        js &= "'" & DateTime.Parse(xTimestampVal.GetValue(i).ToString().Trim()).ToString("yyyy-MM-dd HH:mm") & "', " & yVal.GetValue(i).ToString().Trim() & "]]; " & vbCrLf
            '    Else
            '        js &= "'" & DateTime.Parse(xTimestampVal.GetValue(i).ToString().Trim()).ToString("yyyy-MM-dd HH:mm") & "', " & yVal.GetValue(i).ToString().Trim() & "], ["
            '    End If
            'Next

            js &= "opts = {" & vbCrLf &
            "title: '" & ChartTitle & "'," & vbCrLf &
            "series:[" & strseries & "]," & vbCrLf &
            "seriesDefaults:{pointLabels:{show:false}}," & vbCrLf &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            "fontSize:'8pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf &
            "renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
            "tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," & vbCrLf &
            "//tickInterval:'1 hour'," & vbCrLf &
            "pad:0" & vbCrLf &
            "}," & vbCrLf &
            "yaxis: { " & vbCrLf &
            "tickOptions: { formatString: '%.4f' }," & vbCrLf &
            "min: " & y_min & "," & vbCrLf &
            "max: " & y_max & "," & vbCrLf &
            "autoscale:true," & vbCrLf &
            "label: '" & YAxisLabelName & "'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "//highlighter: { show: 'true', tooltipFormatString: '%.1f', useAxesFormatters: false }," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
            "legend: {" & vbCrLf &
            "show: true," & vbCrLf &
            "location: 's'," & vbCrLf &
            "labels: seriesName," & vbCrLf &
            "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
            "placement: 'outsideGrid'," & vbCrLf &
            "rendererOptions: {" & vbCrLf &
            "numberRows: 1," & vbCrLf &
            "marginTop: 10" & vbCrLf &
            "}" & vbCrLf &
            "}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "', " & strg & ", opts);" & vbCrLf &
            "</script>" & vbCrLf

            LiteralName.Text = js
        Catch ex As Exception

        End Try
    End Sub

    Public Sub PlotScatterChart(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String)
        Try
            'For i As Integer = 0 To dt.Rows.Count - 1
            '    If IsDBNull(dt.Rows(i)("LTRI_PARA_MIN")) Then
            '        dt.Rows(i)("LTRI_PARA_MIN") = dt.Rows(i)("LTRI_PARA_MIN").ToString().Replace(vbNull, vbDecimal)
            '    End If
            'Next
            LiteralName.Text = ""
            Dim min_time, max_time As String
            min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-30), "yyyy-MM-dd HH:mm")
            max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm")

            Dim xTimestampVal(), yVal() As String

            xTimestampVal = (From row In dt Select col = row(XAxisColName).ToString).ToArray
            yVal = (From row In dt Select col = row(YAxisColName).ToString).ToArray()

            Dim y_min As String = yVal.Min()
            Dim y_max As String = yVal.Max()

            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf
            dt.DefaultView.RowFilter = ""
            Dim dtGrades As DataTable = dt.DefaultView.ToTable(True, "CLR_PARAM_MIN") 'All distinct Grades
            Dim dvDefault As DataView = dt.DefaultView
            Dim flag As Boolean = False
            For i As Integer = 0 To dtGrades.Rows.Count - 1
                js &= "var line" & (i + 1).ToString & " = ["
                dvDefault.RowFilter = "CLR_PARAM_MIN='" & dtGrades.Rows(i)(0) & "'"
                For j As Integer = 0 To dvDefault.Count - 1
                    If j > 0 Then
                        js &= ","
                    End If
                    js &= "["
                    Dim dtTime As DateTime = dvDefault.Item(j)("CLR_DT_SAMPLING_DATE")
                    If IsDBNull(dvDefault.Item(j)("CLR_PARAM_MIN")) Then
                        If IsDBNull(dvDefault.Item(j)("CLR_TEST_VALUE")) = False Then
                            js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)("CLR_TEST_VALUE") & ", " & "null"
                        Else
                            js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & "null, null"
                        End If
                    Else
                        If IsDBNull(dvDefault.Item(j)("CLR_TEST_VALUE")) = False Then
                            js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)("CLR_TEST_VALUE") & ", '(" & dvDefault.Item(j)("CLR_PARAM_MIN").ToString().Trim & ")'"
                            'js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)("CLR_TEST_VALUE") & ", 'Pot'"
                        End If
                    End If
                    js &= "]"
                Next
                js &= "];" & vbCrLf
                flag = True
            Next

            Dim strg As String = ""
            Dim strseries As String = ""
            If flag Then
                strg = "[line1"
                strseries = " {showLine:false, markerOptions:{ size: 7 }}"
                For i As Integer = 1 To dtGrades.Rows.Count - 1
                    strg = strg + ",line" & i + 1
                    strseries = strseries + ", { showLine:false, markerOptions:{ size: 7 }}"
                Next
                strg &= "]"
            End If
            js &= "var seriesName = ['"
            Dim str As String = ""
            For i As Integer = 0 To dtGrades.Rows.Count - 1
                str &= dtGrades.Rows(i)(0).ToString().Trim() + "', '"
            Next
            str = str.Remove(str.LastIndexOf(", '"))
            str &= "];"
            js &= str


            'For i = 0 To dt.Rows.Count - 1
            '    If i = xTimestampVal.Length - 1 Then
            '        js &= "'" & DateTime.Parse(xTimestampVal.GetValue(i).ToString().Trim()).ToString("yyyy-MM-dd HH:mm") & "', " & yVal.GetValue(i).ToString().Trim() & "]]; " & vbCrLf
            '    Else
            '        js &= "'" & DateTime.Parse(xTimestampVal.GetValue(i).ToString().Trim()).ToString("yyyy-MM-dd HH:mm") & "', " & yVal.GetValue(i).ToString().Trim() & "], ["
            '    End If
            'Next

            js &= "opts = {" & vbCrLf &
            "title: '" & ChartTitle & "'," & vbCrLf &
            "series:[" & strseries & "]," & vbCrLf &
            "seriesDefaults:{pointLabels:{show:false}}," & vbCrLf &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            "fontSize:'8pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf &
            "renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
            "tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," & vbCrLf &
            "//tickInterval:'1 hour'," & vbCrLf &
            "pad:0" & vbCrLf &
            "}," & vbCrLf &
            "yaxis: { " & vbCrLf &
            "tickOptions: { formatString: '%.4f' }," & vbCrLf &
            "min: " & y_min & "," & vbCrLf &
            "max: " & y_max & "," & vbCrLf &
            "autoscale:true," & vbCrLf &
            "label: '" & YAxisLabelName & "'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "//highlighter: { show: 'true', tooltipFormatString: '%.1f', useAxesFormatters: false }," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
            "legend: {" & vbCrLf &
            "show: true," & vbCrLf &
            "location: 's'," & vbCrLf &
            "labels: seriesName," & vbCrLf &
            "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
            "placement: 'outsideGrid'," & vbCrLf &
            "rendererOptions: {" & vbCrLf &
            "numberRows: 1," & vbCrLf &
            "marginTop: 10" & vbCrLf &
            "}" & vbCrLf &
            "}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "', " & strg & ", opts);" & vbCrLf &
            "</script>" & vbCrLf

            LiteralName.Text = js
        Catch ex As Exception

        End Try
    End Sub
    '...............................................................

    Public Function GetAlFeData(ByVal ProcessLine As String) As DataSet
        'Return objDataHandler.GetDataSetFromQuery("SELECT TOP(2) CLR_TIMESTAMP,CLR_PROCESS_LINE,CLR_ID_COIL,CLR_SAMPLE_ID,CLR_PARAM_TEST,CLR_TEST_VALUE,CLR_UOM,CLR_DT_SAMPLING_DATE,CLR_SHIFT,CLR_PARAM_MIN,CLR_PARAM_MAX FROM CRM_LABTEST_RES WHERE CLR_PARAM_TEST IN ('ZAAL','ZAFE') AND CLR_PROCESS_LINE = '" & ProcessLine & "' ORDER BY CLR_DT_SAMPLING_DATE DESC").Tables(0)
        Return objDataHandler.GetDataSetFromQuery("SELECT TOP(1) CLR_TIMESTAMP,CLR_PROCESS_LINE,CLR_ID_COIL,CLR_SAMPLE_ID,CLR_PARAM_TEST,CLR_TEST_VALUE,CLR_UOM,CLR_DT_SAMPLING_DATE,CLR_SHIFT,CLR_PARAM_MIN,CLR_PARAM_MAX FROM CRM_LABTEST_RES WHERE CLR_PARAM_TEST IN ('ZAAL','ZAZS','ZAGA') AND CLR_PROCESS_LINE = '" & ProcessLine & "' ORDER BY CLR_DT_SAMPLING_DATE DESC " & vbCrLf & "SELECT TOP(1) CLR_TIMESTAMP,CLR_PROCESS_LINE,CLR_ID_COIL,CLR_SAMPLE_ID,CLR_PARAM_TEST,CLR_TEST_VALUE,CLR_UOM,CLR_DT_SAMPLING_DATE,CLR_SHIFT,CLR_PARAM_MIN,CLR_PARAM_MAX FROM CRM_LABTEST_RES WHERE CLR_PARAM_TEST = 'ZAFE' AND CLR_PROCESS_LINE = '" & ProcessLine & "' ORDER BY CLR_DT_SAMPLING_DATE DESC")
    End Function

    Public Function GetZnBathTrendData(ByVal StartDate As String, ByVal EndDate As String) As DataTable
        'Return objDataHandler.GetDataSetFromQuery("select CZT_EFF_AL,CZT_EFF_FE,CZT_TIMESTAMP,CZT_CAMP_AL,CZT_POT_AL,CZT_POT_FE from CGL2_ZNBATH_TREND WHERE CZT_TIMESTAMP BETWEEN '" & StartDate & "' AND '" & EndDate & "' ORDER BY CZT_TIMESTAMP").Tables(0)
        Return objDataHandler.GetDataSetFromQuery("SELECT CZT_EFF_AL,CZT_EFF_FE,CZT_TIMESTAMP,CZT_CAMP_AL,CZT_POT_AL,CZT_POT_FE,""CAMPAIGN"" = CASE WHEN CZT_EFF_AL > 0.15 AND CZT_EFF_AL <= 0.4 THEN 'GI' WHEN CZT_EFF_AL >= 0.1 AND CZT_EFF_AL <= 0.15 THEN 'GA' END, ""UCL"" = CASE WHEN CZT_EFF_AL > 0.15 AND CZT_EFF_AL <= 0.4 THEN 0.19 WHEN CZT_EFF_AL >= 0.1 AND CZT_EFF_AL <= 0.15 THEN 0.133 END, ""LCL"" = CASE WHEN CZT_EFF_AL > 0.15 AND CZT_EFF_AL <= 0.4 THEN 0.18 WHEN CZT_EFF_AL >= 0.1 AND CZT_EFF_AL <= 0.15 THEN 0.123 END FROM CGL2_ZNBATH_TREND WHERE CZT_TIMESTAMP BETWEEN '" & StartDate & "' AND '" & EndDate & "' ORDER BY CZT_TIMESTAMP").Tables(0)
    End Function
    Public Function GetWetChemicalTestData(ByVal TableName As String, ByVal FromDate As String, ByVal ToDate As String, ByVal DateColumn As String, ByVal Columnname1 As String, ByVal Columnname2 As String, ByVal Columnname3 As String) As DataTable
        'Return objDataHandler.GetDataSetFromQuery("select CZT_TIMESTAMP,CZT_EFF_AL,CZT_EFF_FE,CZT_CAMP_AL as CLR_PARAM_TEST from  " & TableName & " where " & DateColumn & " between '" & FromDate & "' and '" & ToDate & "' order by CZT_CAMP_AL").Tables(0)
        Return objDataHandler.GetDataSetFromQuery("select " & DateColumn & ", " & Columnname1 & ", " & Columnname2 & ", " & Columnname3 & " as CLR_PARAM_TEST from  " & TableName & " where " & DateColumn & " between '" & FromDate & "' and '" & ToDate & "' order by " & Columnname3 & " ").Tables(0)
    End Function
    Sub PlotBoxPlotChartForCGL2(ByVal dt As DataTable, ByVal yValue As String, ByVal lit As Literal, ByVal containerName As String, ByVal PlotName As String, ByVal DataVariable As String, ByVal seriesOf As String, ByVal OutlierDataVariable As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String, ByVal AvgVarName As String, ByVal ColCondition As String, ByVal YMin As String, ByVal YMax As String)
        lit.Text = ""
        Try
            ChartTitle = ""
            Dim js = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                "var " & DataVariable & " = ["
            'Dim Series() = (From row In dt Select col = row.Field(Of String)(seriesOf) Distinct).ToArray
            Dim Series() = (From row In dt Select col = row.Field(Of Decimal)(seriesOf) Distinct).ToArray
            Dim strarr As New ArrayList
            Dim AvgData = ""
            Dim tickOptions As String = IIf(Series.Length > 8, "tickOptions:{ angle: -30 },", "")
            For i As Integer = 0 To Series.Length - 1 'MAIN LOOP
                Dim x = i
                'Dim query = From val In dt.AsEnumerable() Where val.Field(Of String)(seriesOf) = Series(x) Select val
                Dim query = From val In dt.AsEnumerable() Where val.Field(Of Decimal)(seriesOf) = Series(x) Select val
                Dim dtValue = query.CopyToDataTable()
                Dim arrYValues(dtValue.Rows.Count) As Decimal
                arrYValues = (From row In dtValue Select col = Decimal.Parse(row(Trim(yValue)).ToString()) Where col < 1).ToArray
                Array.Sort(arrYValues)
                Dim plot1 As New BoxPlotSeriesMgr
                Dim arrVal() As Double = plot1.GetValuesForBoxPlot(arrYValues)
                Dim xAxisTick As String = ""
                If ColCondition = "Pot" Then
                    'If dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAAL" Then
                    '    xAxisTick = "Actual Al_AL"
                    'ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAFE_AL" Then
                    '    xAxisTick = "Actual Fe_AL"
                    'ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAGA" Then
                    '    xAxisTick = "Actual Al_GA"
                    'ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAFE_GA" Then
                    '    xAxisTick = "Actual Fe_GA"
                    'ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAZS" Then
                    '    xAxisTick = "Actual Al_GI"
                    'ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAFE_ZS" Then
                    '    xAxisTick = "Actual Fe_GI"
                    'End If
                    If dtValue.Rows(0)("CLR_PARAM_TEST") = "GA_AL" Then
                        xAxisTick = "Actual Al_GA"
                    ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "GA_FE" Then
                        xAxisTick = "Actual Fe_GA"
                    ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "GI_AL" Then
                        xAxisTick = "Actual Al_GI"
                    ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "GI_FE" Then
                        xAxisTick = "Actual Fe_GI"
                    End If
                ElseIf ColCondition = "Eff" Then
                    'If dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAAL" Then
                    '    xAxisTick = "Eff. Al_AL"
                    'ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAFE_AL" Then
                    '    xAxisTick = "Eff. Fe_AL"
                    'ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAGA" Then
                    '    xAxisTick = "Eff. Al_GA"
                    'ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAFE_GA" Then
                    '    xAxisTick = "Eff. Fe_GA"
                    'ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAZS" Then
                    '    xAxisTick = "Eff. Al_GI"
                    'ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAFE_ZS" Then
                    '    xAxisTick = "Eff. Fe_GI"
                    'End If
                    If dtValue.Rows(0)("CLR_PARAM_TEST") = "GA_AL" Then
                        xAxisTick = "Eff. Al_GA"
                    ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "GA_FE" Then
                        xAxisTick = "Eff. Fe_GA"
                    ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "GI_AL" Then
                        xAxisTick = "Eff. Al_GI"
                    ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "GI_FE" Then
                        xAxisTick = "Eff. Fe_GI"
                    End If
                End If

                If i = Series.Length - 1 Then
                    js &= "" &
                    "['" & xAxisTick & "', " & arrVal(4) & ", " & arrVal(1) & ", " & arrVal(8) & ", " & arrVal(5) & ", " & arrYValues.Length & "]];"

                    AvgData &= "" &
                    "['" & xAxisTick & "', " & (arrYValues.Average) & "]];"
                Else
                    js &= "" &
                    "['" & xAxisTick & "', " & arrVal(4) & ", " & arrVal(1) & ", " & arrVal(8) & ", " & arrVal(5) & ", " & arrYValues.Length & "], "

                    AvgData &= "" &
                    "['" & xAxisTick & "', " & (arrYValues.Average) & "], "
                End If

                'Making data for outliers :-
                For j = 0 To arrYValues.Length - 1
                    If arrVal(8) >= arrYValues(j) Then
                        strarr.Add("['" & xAxisTick & "'," & arrYValues(j) & "]")
                    ElseIf arrVal(9) <= arrYValues(j) Then
                        strarr.Add("['" & xAxisTick & "'," & arrYValues(j) & "]")
                    End If
                Next
            Next 'MAIN LOOP ENDS

            js &= "" & vbCrLf

            'For Average Points

            js &= "var " & AvgVarName & " = [" & AvgData
            js &= "" & vbCrLf

            js &= vbCrLf
            'Storing outliers data in as variable.
            js &= "var " & OutlierDataVariable & " = ["
            For rw As Integer = 0 To strarr.Count - 1
                If rw > 0 Then
                    js &= ","
                End If
                js &= strarr(rw)
            Next
            js &= "];" & vbCrLf

            js &= "" & vbCrLf &
                    "$(document).ready(function () {" & vbCrLf &
                            "$.jqplot.config.enablePlugins = true;" & vbCrLf &
                            "title: '" & ChartTitle & "'," & vbCrLf &
                            PlotName & " = $.jqplot('" & containerName & "', [" & DataVariable & ", " & OutlierDataVariable & ", " & AvgVarName & "], {" & vbCrLf &
                            "axesDefaults: { tickRenderer: $.jqplot.CanvasAxisTickRenderer, tickOptions: {fontSize: '8pt'}}," & vbCrLf &
                            "axes: {" & vbCrLf &
                                "xaxis: {" & vbCrLf &
                                    "renderer:$.jqplot.CategoryAxisRenderer," & vbCrLf &
                                    "label: ''," & vbCrLf &
                                    tickOptions & vbCrLf &
                                    "//tickOptions: { formatString: '%d-%m-%y' }" & vbCrLf &
                                "}," & vbCrLf &
                                "yaxis: {" & vbCrLf &
                                    "label: '" & YAxisLabelName & "'," & vbCrLf &
                                    "min: " & YMin & ", max: " & YMax & "," & vbCrLf &
                                    "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
                                "}," & vbCrLf &
                            "}, animate: true, " & vbCrLf &
                            "title: '" & ChartTitle & "'," & vbCrLf &
                            "series: [" & vbCrLf &
                            "       {" & vbCrLf &
                            "           highlighter: {show: true, showMarker: false,tooltipAxes:'xy',yvalues: 5,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td style=""display: none;"">Observations: </td><td style=""display: none;"">%s</td></tr> \ <tr><td>Upper Quartile: </td><td>%s</td></tr> \ <tr><td>Maximum: </td><td>%s</td></tr> \ <tr><td>Minimum: </td><td>%s</td></tr> \ <tr><td>Lower Quartile: </td><td>%s</td></tr> \ <tr><td>No Of Data Points: </td><td>%s</td></tr> </table>' }," & vbCrLf &
                            "           renderer: $.jqplot.OHLCRenderer, rendererOptions: {" & vbCrLf &
                            "               candleStick: true, lineWidth: 2, bodyWidth: 40, wickColor: '#60A62E', upBodyColor: '#00008B', downBodyColor: '#00008B'" & vbCrLf &
                            "           }" & vbCrLf &
                            "       }," & vbCrLf &
                            "{showLine:false, markerOptions: {style: ""circle"", shadow: false, color: '#4BB2C5'}, highlighter: {show: true, showMarker: false,tooltipAxes:'xy',yvalues: 1,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td style=""display:none;"">%s</td></tr> \ <tr><td>%s</td></tr> </table>' }}," & vbCrLf &
                            "{lineWidth:1, color: '#006400', showLine: false, showMarker:true, markerOptions: { style: 'filledCircle' }, highlighter: {show: true, showMarker: false,tooltipAxes:'xy',yvalues: 1,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td style=""display:none;"">%s</td></tr> \ <tr><td>%s</td></tr> </table>' }}" & vbCrLf &
                            "]," & vbCrLf &
                            "seriesDefaults:{pointLabels:{show:false}}," & vbCrLf &
                            "" & vbCrLf &
                            "" & vbCrLf &
                            "" & vbCrLf &
                            "cursor: {" & vbCrLf &
                            "zoom: true," & vbCrLf &
                            "show: true," & vbCrLf &
                            "}," & vbCrLf &
                            "grid: {backgroundColor: 'rgb(255,255,255)'}," & vbCrLf &
                        "});" & vbCrLf &
                    "});" & vbCrLf &
                "</script>"
            lit.Text = js
        Catch ex As Exception

        End Try
    End Sub

    Public Function GetEffectiveAlFeData(ByVal FromDate As String, ByVal ToDate As String) As DataTable
        'Dim effQuery As String = "select CZT_TIMESTAMP,CZT_EFF_AL,CZT_CAMP_AL,CZT_MIN_VAL from CGL2_ZNBATH_TREND where CZT_CAMP_AL='ZAAL' and CZT_TIMESTAMP between '" & FromDate & "' and '" & ToDate & "' order by CZT_TIMESTAMP" & vbCrLf & _
        '                         "select CZT_TIMESTAMP,CZT_EFF_AL,CZT_CAMP_AL,CZT_MIN_VAL from CGL2_ZNBATH_TREND where CZT_CAMP_AL='ZAZS' and CZT_TIMESTAMP between '" & FromDate & "' and '" & ToDate & "' order by CZT_TIMESTAMP" & vbCrLf & _
        '                         "select CZT_TIMESTAMP,CZT_EFF_AL,CZT_CAMP_AL,CZT_MIN_VAL from CGL2_ZNBATH_TREND where CZT_CAMP_AL='ZAGA' and CZT_TIMESTAMP between '" & FromDate & "' and '" & ToDate & "' order by CZT_TIMESTAMP" & vbCrLf & _
        '                         "select CZT_TIMESTAMP,CZT_EFF_FE,CZT_CAMP_AL,CZT_MIN_VAL from CGL2_ZNBATH_TREND where CZT_TIMESTAMP between '" & FromDate & "' and '" & ToDate & "' order by CZT_TIMESTAMP"

        Dim effQuery As String = "SELECT CZT_TIMESTAMP,CZT_EFF_AL,CZT_EFF_FE,CZT_MIN_VAL,CZT_CAMP_AL,""CZT_CAMP_AL_NEW"" = " & vbCrLf &
                                 "CASE" & vbCrLf &
                                 "WHEN CZT_EFF_AL > 0.15 AND CZT_EFF_AL <= 0.4 THEN 'GI'" & vbCrLf &
                                 "WHEN CZT_EFF_AL >= 0.1 AND CZT_EFF_AL <= 0.15 THEN 'GA'" & vbCrLf &
                                 "END" & vbCrLf &
                                 "FROM CGL2_ZNBATH_TREND WHERE CZT_EFF_AL > 0 AND CZT_TIMESTAMP BETWEEN '" & FromDate & "' AND '" & ToDate & "' ORDER BY CZT_TIMESTAMP"
        Return objDataHandler.GetDataSetFromQuery(effQuery).Tables(0)
    End Function



    Public Sub PlotLineChartForCGL(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String, ByVal GroupByColName As String)
        Try
            'For i As Integer = 0 To dt.Rows.Count - 1
            '    If IsDBNull(dt.Rows(i)("LTRI_PARA_MIN")) Then
            '        dt.Rows(i)("LTRI_PARA_MIN") = dt.Rows(i)("LTRI_PARA_MIN").ToString().Replace(vbNull, vbDecimal)
            '    End If
            'Next
            LiteralName.Text = ""
            Dim min_time, max_time As String
            min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-30), "yyyy-MM-dd HH:mm")
            max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm")

            'Dim xTimestampVal(), yVal() As String
            Dim yVal() As Decimal

            'xTimestampVal = (From row In dt Select col = row(XAxisColName).ToString).ToArray
            yVal = (From row In dt Select col = CDec(row(YAxisColName))).ToArray()

            'Dim y_min As String = yVal.Min()
            'Dim y_max As String = yVal.Max()
            Dim y_min As String = yVal.Min() - (10 / 100 * yVal.Min)
            Dim y_max As String = yVal.Max() + (10 / 100 * yVal.Max)

            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf
            dt.DefaultView.RowFilter = ""
            Dim dtGrades As DataTable = dt.DefaultView.ToTable(True, GroupByColName) 'All distinct Grades
            Dim dvDefault As DataView = dt.DefaultView
            Dim flag As Boolean = False
            For i As Integer = 0 To dtGrades.Rows.Count - 1
                js &= "var line" & (i + 1).ToString & " = ["
                dvDefault.RowFilter = "" & GroupByColName & "='" & dtGrades.Rows(i)(0) & "'"
                For j As Integer = 0 To dvDefault.Count - 1
                    If j > 0 Then
                        js &= ","
                    End If
                    js &= "["
                    Dim dtTime As DateTime = dvDefault.Item(j)("CLR_DT_SAMPLING_DATE")
                    If IsDBNull(dvDefault.Item(j)(GroupByColName)) Then
                        If IsDBNull(dvDefault.Item(j)("CLR_TEST_VALUE")) = False Then
                            js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)("CLR_TEST_VALUE") & ", " & "null"
                        Else
                            js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & "null, null"
                        End If
                    Else
                        If IsDBNull(dvDefault.Item(j)("CLR_TEST_VALUE")) = False Then
                            js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)("CLR_TEST_VALUE") & ", '(" & dvDefault.Item(j)(GroupByColName).ToString().Trim & ")'"
                            'js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)("CLR_TEST_VALUE") & ", 'Pot'"
                        End If
                    End If
                    js &= "]"
                Next
                js &= "];" & vbCrLf
                flag = True
            Next

            Dim strg As String = ""
            Dim strseries As String = ""
            If flag Then
                strg = "[line1"
                strseries = " {pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
                For i As Integer = 1 To dtGrades.Rows.Count - 1
                    strg = strg + ",line" & i + 1
                    strseries = strseries + ", {pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
                Next
                strg &= "]"
            End If
            js &= "var seriesName = ['"
            Dim str As String = ""
            For i As Integer = 0 To dtGrades.Rows.Count - 1
                str &= dtGrades.Rows(i)(0).ToString().Trim() + "', '"
            Next
            str = str.Remove(str.LastIndexOf(", '"))
            str &= "];"
            js &= str
            js &= "opts = {" & vbCrLf &
            "title: '" & ChartTitle & "'," & vbCrLf &
            "series:[" & strseries & "]," & vbCrLf &
            "seriesColors: ['#4C4ED8','#EF3862','#8A1EEE','#0982EC','#0FBDE3','#043D1D','#059B11','#E1EB05','#666699','#F4ED03','#EF8355','#818181','#FFA500', '#006400','#F10000','#996633','#ECAE06','#009999','#800000','#F05904']," & vbCrLf &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            "fontSize:'8pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf &
            "renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
            "tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," & vbCrLf &
            "//tickInterval:'1 hour'," & vbCrLf &
            "pad:0" & vbCrLf &
            "}," & vbCrLf &
            "yaxis: { " & vbCrLf &
            "tickOptions: { formatString: '%.3f' }," & vbCrLf &
            "min: " & y_min & "," & vbCrLf &
            "max: " & y_max & "," & vbCrLf &
            "autoscale:true," & vbCrLf &
            "label: '" & YAxisLabelName & "'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "showTooltip: false," & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "animate: true," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
            "legend: {" & vbCrLf &
            "show: true," & vbCrLf &
            "location: 's'," & vbCrLf &
            "labels: seriesName," & vbCrLf &
            "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
            "placement: 'outsideGrid'," & vbCrLf &
            "rendererOptions: {" & vbCrLf &
            "numberRows: 1," & vbCrLf &
            "marginTop: 10" & vbCrLf &
            "}" & vbCrLf &
            "}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "', " & strg & ", opts);" & vbCrLf &
            "</script>" & vbCrLf

            LiteralName.Text = js
        Catch ex As Exception

        End Try
    End Sub
    Public Function LoadDashboard(Optional ByVal stD As String = "", Optional ByVal endD As String = "") As DataSet
        Dim stDate, endDate As Date
        If stD = "" Then
            stDate = Date.Today.AddDays(-29)
            endDate = Date.Today
        Else
            stDate = Date.Parse(stD)
            endDate = Date.Parse(endD)
        End If
        Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("SELECT convert(varchar(3),datename(month,PRM_TS_END)) + '-' +  Right(cast(Year(PRM_TS_END) as varchar),2) as MY,PRM_CD_GRADE,CEILING(ROUND(SUM(PRM_MS_COIL_ACTL / 1000),0)) AS WT FROM [T_CGL_FUR_PARAM] WHERE PRM_CD_SURF_ROUGH = 'A' AND PRM_TS_END BETWEEN '" & stDate.ToString("yyyy-MM-dd") & "' AND '" & endDate.ToString("yyyy-MM-dd") & "' AND (PRM_TDC_NO LIKE 'GS%' OR PRM_TDC_NO = 'GA20') GROUP BY PRM_CD_GRADE,convert(varchar(3),datename(month,PRM_TS_END)) + '-' +  Right(cast(Year(PRM_TS_END) as varchar),2);SELECT convert(varchar(3),datename(month,PRM_TS_END)) + '-' +  Right(cast(Year(PRM_TS_END) as varchar),2) as MY,PRM_CD_GRADE,CEILING(ROUND(SUM(PRM_MS_COIL_ACTL / 1000),0)) AS WT FROM [T_CGL_FUR_PARAM] WHERE PRM_CD_SURF_ROUGH = 'A' AND PRM_TS_END BETWEEN '" & stDate.ToString("yyyy-MM-dd") & "' AND '" & endDate.ToString("yyyy-MM-dd") & "' AND (PRM_TDC_NO NOT LIKE 'GS%' OR PRM_TDC_NO <> 'GA20') GROUP BY PRM_CD_GRADE,convert(varchar(3),datename(month,PRM_TS_END)) + '-' +  Right(cast(Year(PRM_TS_END) as varchar),2);SELECT PRM_CD_SURF_ROUGH,ROUND(COUNT(*)*100/cast(sum(count(*)) over () as float),2) as perc,CEILING(ROUND(sum(PRM_MS_COIL_ACTL / 1000),2)) as tonnage FROM [T_CGL_FUR_PARAM] WHERE PRM_TS_END BETWEEN '" & stDate.ToString("yyyy-MM-dd") & "' AND '" & endDate.ToString("yyyy-MM-dd") & "' group by PRM_CD_SURF_ROUGH;SELECT convert(varchar(3),datename(month,PRM_TS_END)) + '-' +  Right(cast(Year(PRM_TS_END) as varchar),2) as MY,PRM_CD_SURF_ROUGH,ROUND(COUNT(*)*100/cast(sum(count(*)) over () as float),2) as perc,CEILING(ROUND(sum(PRM_MS_COIL_ACTL / 1000),2)) as tonnage FROM [T_CGL_FUR_PARAM] WHERE PRM_TS_END BETWEEN '" & stDate.ToString("yyyy-MM-dd") & "' AND '" & endDate.ToString("yyyy-MM-dd") & "' group by convert(varchar(3),datename(month,PRM_TS_END)) + '-' +  Right(cast(Year(PRM_TS_END) as varchar),2),PRM_CD_SURF_ROUGH;SELECT PRM_TS_END,PRM_CD_SURF_ROUGH,(PRM_MS_COIL_ACTL / 1000) AS WT FROM [T_CGL_FUR_PARAM] WHERE PRM_TS_END BETWEEN '" & stDate.ToString("yyyy-MM-dd") & "' AND '" & endDate.ToString("yyyy-MM-dd") & "' ORDER BY PRM_TS_END")
        Return ds
    End Function

    Public Function LoadDashboard_Trend(Optional ByVal stD As String = "", Optional ByVal endD As String = "") As DataSet
        Dim stDate, endDate As Date
        If stD = "" Then
            stDate = Date.Today.AddDays(-2)
            endDate = Date.Today.AddDays(1)
        Else
            stDate = Date.Parse(stD)
            endDate = Date.Parse(endD)
        End If
        Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("SELECT PRM_TS_END,PRM_HS_STRP_TMP,PRM_SNT_STRP_TMP,PRM_SS_STRP_TMP,PRM_RCF_STRP_TMP,PRM_ID_COIL,PRM_CD_SURF_ROUGH FROM [T_CGL_FUR_PARAM] WHERE PRM_TS_END BETWEEN '" & stDate.ToString("yyyy-MM-dd") & "' AND '" & endDate.ToString("yyyy-MM-dd") & "' order by PRM_TS_END;select convert(varchar(3),datename(month,PRM_TS_END)) + '-' +  Right(cast(Year(PRM_TS_END) as varchar),2) as MY,prm_ts_end,prm_line_speed,prm_elong,prm_force,prm_zinc_pot_tmp,PRM_CD_SURF_ROUGH from [T_CGL_FUR_PARAM] WHERE PRM_TS_END BETWEEN '" & stDate.ToString("yyyy-MM-dd") & "' AND '" & endDate.ToString("yyyy-MM-dd") & "' order by PRM_TS_END")
        Return ds
    End Function

    Public Function LoadCustomer(Optional ByVal stD As String = "", Optional ByVal endD As String = "") As DataSet
        Dim stDate, endDate As Date
        If stD = "" Then
            stDate = Date.Today.AddDays(-29)
            endDate = Date.Today.AddDays(1)
        Else
            stDate = Date.Parse(stD)
            endDate = Date.Parse(endD)
        End If
        Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("select distinct [PRM_CD_GRADE] from [T_CGL_FUR_PARAM] where PRM_TS_END BETWEEN '" & stDate.ToString("yyyy-MM-dd") & "' and '" & endDate.ToString("yyyy-MM-dd") & "';SELECT convert(varchar(3),datename(month,PRM_TS_END)) + '-' +  Right(cast(Year(PRM_TS_END) as varchar),2) as MY,PRM_CD_GRADE,CEILING(ROUND(SUM(PRM_MS_COIL_ACTL / 1000),0)) AS WT,PRM_MK_CUSTOMER FROM [T_CGL_FUR_PARAM] where PRM_TS_END BETWEEN '" & stDate.ToString("yyyy-MM-dd") & "' and '" & endDate.ToString("yyyy-MM-dd") & "' group by convert(varchar(3),datename(month,PRM_TS_END)) + '-' +  Right(cast(Year(PRM_TS_END) as varchar),2),PRM_CD_GRADE,PRM_MK_CUSTOMER ")
        Return ds
    End Function

    Public Function GetDataForAnalysis(ByVal TableName As String, ByVal FromDate As String, ByVal ToDate As String, ByVal DateColumn As String, ByVal ColumnName As String, ByVal Filter As String) As DataTable
        Dim query As String = ""
        query = "select PRM_TS_END,PRM_ID_COIL," & ColumnName & " from " & TableName & " where " & DateColumn & " between '" & FromDate & "' and '" & ToDate & "' and " & Filter & ""
        Return objDataHandler.GetDataSetFromQuery(query).Tables(0)
    End Function

    Public Sub PlotLineChartForAnalysis(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String, ByVal index As String)
        Try
            Dim dtTemp As DataTable = dt.Clone
            Dim DecimalVal As String = ""

            For i As Integer = 0 To dt.Rows.Count - 1

                If i < dt.Rows.Count - 1 Then
                    Dim span As TimeSpan = DateTime.Parse(dt.Rows(i + 1)("PRM_TS_END")).Subtract(DateTime.Parse(dt.Rows(i)("PRM_TS_END")))
                    If span.TotalHours >= 24 Then
                        Dim row As DataRow = dtTemp.NewRow
                        For j As Integer = 0 To dt.Columns.Count - 1
                            row(j) = dt.Rows(i)(j)
                        Next
                        dtTemp.Rows.Add(row)
                        row = dtTemp.NewRow
                        row(0) = DateTime.Parse(dt.Rows(i)("PRM_TS_END")).AddMinutes(10)
                        row(1) = "c0"
                        For j As Integer = 2 To dt.Columns.Count - 1
                            row(j) = 0
                        Next
                        dtTemp.Rows.Add(row)
                    Else
                        Dim row As DataRow = dtTemp.NewRow
                        For j As Integer = 0 To dt.Columns.Count - 1
                            row(j) = dt.Rows(i)(j)
                        Next
                        dtTemp.Rows.Add(row)
                    End If
                Else
                    Dim row As DataRow = dtTemp.NewRow
                    For j As Integer = 0 To dt.Columns.Count - 1
                        row(j) = dt.Rows(i)(j)
                    Next
                    dtTemp.Rows.Add(row)
                End If

                'Dim row As DataRow = dtTemp.NewRow
                'For j As Integer = 0 To dt.Columns.Count - 1

                '    row(j) = dt.Rows(i)(j)

                '    If i < dt.Rows.Count - 1 Then
                '        Dim span As TimeSpan = DateTime.Parse(dt.Rows(i + 1)("PRM_TS_END")).Subtract(DateTime.Parse(dt.Rows(i)("PRM_TS_END")))
                '        If span.TotalHours >= 24 Then
                '            dtTemp.Rows(i)(0) = DateTime.Parse(dt.Rows(i)("PRM_TS_END")).AddMinutes(10)
                '            dtTemp.Rows(i)(1) = dt.Rows(i)(1)
                '            If j > 1 Then
                '                dtTemp.Rows.Add(dt.Rows(i)(j))
                '            End If

                '        End If
                '    End If
                'Next

            Next
            'For j As Integer = 0 To dt.Columns.Count - 1
            '    If dt.Columns(j).ColumnName = "PRM_TEST_VALUE_UTS" Or dt.Columns(j).ColumnName = "PRM_TEST_VALUE_YS" Then
            '        DecimalVal = "%12.0f"
            '    Else
            '        DecimalVal = "%12.2f"
            '    End If

            'Next
            dt = dtTemp
            LiteralName.Text = ""
            Dim min_time, max_time As String
            min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-30), "yyyy-MM-dd HH:mm")
            max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm")

            'Dim xTimestampVal(), yVal() As String
            Dim yVal() As Decimal

            'xTimestampVal = (From row In dt Select col = row(XAxisColName).ToString).ToArray
            yVal = (From row In dt Select col = CDec(IIf(IsDBNull(row(YAxisColName)), 0, row(YAxisColName))) Where col > 0).ToArray()

            'Dim y_min As String = yVal.Min()
            'Dim y_max As String = yVal.Max()
            Dim y_min As String = yVal.Min() - (10 / 100 * yVal.Min)
            Dim y_max As String = yVal.Max() + (10 / 100 * yVal.Max)

            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf
            js &= "var line" & index & " = ["
            For j As Integer = 0 To dt.Rows.Count - 1
                If j > 0 Then
                    js &= ","
                End If
                js &= "["
                Dim dtTime As DateTime = dt.Rows(j)(XAxisColName)

                If IsDBNull(dt.Rows(j)(YAxisColName)) = False Then
                    js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dt.Rows(j)(YAxisColName) = 0, "null", dt.Rows(j)(YAxisColName)) & ", '" & dt.Rows(j)("PRM_ID_COIL") & "'"
                    'arAlSeries &= "['" & DateTime.Parse(dtGI_Temp.Rows(j)("CLR_DT_SAMPLING_DATE")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGI_Temp.Rows(j)("CLR_TEST_VALUE") = 0, "null", dtGI_Temp.Rows(j)("CLR_TEST_VALUE")) & ", 'ZAGI'], "
                Else
                    js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', null, '" & dt.Rows(j)("PRM_ID_COIL") & "'"
                End If
                js &= "]"
            Next

            js &= "];" & vbCrLf
            'Dim strg As String = ""
            'Dim strseries As String = ""
            'If flag Then
            '    strg = "[line1"
            '    strseries = " {showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"

            '    strg &= "]"
            'End If
            'js &= "var seriesName = ['"
            'Dim str As String = ""
            'For i As Integer = 0 To dtGroups.Rows.Count - 1
            '    str &= dtGroups.Rows(i)(0).ToString().Trim() + "', '"
            'Next
            'str = str.Remove(str.LastIndexOf(", '"))
            'str &= "];"
            'js &= str
            js &= "opts = {" & vbCrLf &
            "title: '" & ChartTitle & "'," & vbCrLf &
            "seriesDefaults: { showMarker:true,lineWidth: 2,markerOptions: {size: 5},breakOnNull: true, pointLabels: { show:false },color: '#4832DB', highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}," &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            "fontSize:'8pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf &
            "renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
            "tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," & vbCrLf &
            "//tickInterval:'1 hour'," & vbCrLf &
            "pad:0" & vbCrLf &
            "}," & vbCrLf &
            "yaxis: { " & vbCrLf &
            "tickOptions: { formatString: '%12.0f' }," & vbCrLf &
            "//tickOptions: { formatString: '" & DecimalVal & "' }," & vbCrLf &
            "min: " & y_min & "," & vbCrLf &
            "max: " & y_max & "," & vbCrLf &
            "autoscale:true," & vbCrLf &
            "label: '" & YAxisLabelName & "'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "showTooltip: false," & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "animate: true," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)'}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "',[line" & index & "],opts);" & vbCrLf &
            "</script>" & vbCrLf

            LiteralName.Text = js
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub
    Public Sub LoadColumnName(ByVal CheckBoxListName As CheckBoxList)
        Dim query As String = ""
        query = "select 'PRM_ZINC_POT_TMP' as C1,'Pot temp (&#176 C)' as C2 union select 'PRM_TEST_VAL_AL' as C1,'Pot Al (%)' as C2 union select 'PRM_TEST_VAL_FE' as C1,'Pot Fe (%)' as C2 union select 'PRM_FORCE' as C1,'Skin pass force(KN)' as C2 union select 'PRM_ELONG' as C1,'Skin pass Elongation' as C2 union select 'PRM_SS_STRP_TMP' as C1,'Soaking temp P2(&#176 C)' as C2 union select 'PRM_LINE_SPEED' as C1,'Speed(MPM)' as C2 union select 'PRM_SNT_STRP_TMP' as C1,'Snout temp (&#176 C)' as C2 union select 'PRM_GALV_POWER' as C1,'GA power (KW)' as C2 union select 'PRM_HS_STRP_TMP' as C1,'Heating temp P1(&#176 C)' as C2 union select 'PRM_TEST_VALUE_RB' as C1,'RB' as C2 union select 'PRM_TEST_VALUE_YS' as C1,'YS' as C2 union select 'PRM_TEST_VALUE_UTS' as C1,'UTS' as C2  union select 'PRM_TEST_VALUE_EL' as C1,'EL' as C2 union select 'PRM_TEST_VALUE_RBAR' as C1,'RBAR' as C2 union select 'PRM_TEST_VALUE_RA' as C1,'RA' as C2 union select 'PRM_TEST_VALUE_ZCQTBM' as C1,'ZCQTBM' as C2 union select 'PRM_TEST_VALUE_ZCQTTM' as C1,'ZCQTTM' as C2 union select 'PRM_TTC_AVG' as C1,'Top Coating Avg' as C2 union select 'PRM_BTC_AVG' as C1,'Bottom Coating Avg' as C2 order by C2"
        'query = "select 'PRM_SS_STRP_TMP' as C1 union select 'PRM_GALV_POWER' as C1 union select 'PRM_FORCE' as C1 union select 'PRM_ZINC_POT_TMP' as C1 union select 'PRM_LINE_SPEED' as C1"
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery(query).Tables(0)
        If dt.Rows.Count > 0 Then
            CheckBoxListName.DataSource = dt

            CheckBoxListName.DataTextField = "C2"
            CheckBoxListName.DataValueField = "C1"
            CheckBoxListName.DataBind()
            'CheckBoxListName.Items.Insert(0, "All")
            'DropDownName.Items.Insert(0, "Select")
            'DropDownName.SelectedIndex = 0
        End If

    End Sub
    Public Function CalFeDisso_Weight(ByVal StDt As String, ByVal EndDt As String) As DataTable

        'Dim dtA_EndtDate As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END  FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END BETWEEN '" & StDt & "' AND '" & EndDt & "' order by PRM_TS_END desc").Tables(0)
        'Dim EndDate As DateTime = dtA_EndtDate.Rows(0)(1)
        'Dim dtZCamp As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='Z' and PRM_TS_END <='" & EndDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END desc").Tables(0)
        'Dim ZCampDate As DateTime = dtZCamp.Rows(0)(1)
        'Dim dtA_StartDate As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END >='" & ZCampDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END ").Tables(0)
        'Dim StartDate As DateTime = dtA_StartDate.Rows(0)(1)
        Dim dtA_EndtDate As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END  FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END BETWEEN '" & StDt & "' AND '" & EndDt & "' order by PRM_TS_END desc").Tables(0)
        Dim EndDate As DateTime = dtA_EndtDate.Rows(0)(1)

        Dim cnt As Integer = 4
        Dim AEndDate As DateTime = EndDate
        Dim ZCampDate As DateTime

        'Dim dtZCamp As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='Z' and PRM_TS_END <='" & EndDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END desc").Tables(0)
        'Dim ZCampDate As DateTime = dtZCamp.Rows(0)(1)

        While True

            Dim dtZCamp As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='Z' and PRM_TS_END <='" & AEndDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END desc").Tables(0)
            ZCampDate = dtZCamp.Rows(0)(1)
            Dim dtACamp As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END <='" & ZCampDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END desc").Tables(0)
            Dim ACampDate As DateTime = dtACamp.Rows(0)(1)
            Dim dtCnt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT count(*) FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_TS_END] > '" & ACampDate.ToString("yyyy-MM-dd HH:mm:ss") & "' and PRM_TS_END <='" & ZCampDate.ToString("yyyy-MM-dd HH:mm:ss") & "'").Tables(0)
            cnt = dtCnt.Rows(0)(0)
            If cnt < 7 Then
                AEndDate = ACampDate
            Else
                Exit While
            End If
        End While
        'Dim dtA_StartDate As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END >='" & ZCampDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END ").Tables(0)
        Dim dtA_StartDate As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END >='" & ZCampDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END ").Tables(0)
        Dim StartDate As DateTime = dtA_StartDate.Rows(0)(1)
        Return objDataHandler.GetDataSetFromQuery("select  (sum(PRM_MS_COIL_ACTL))/1000 from T_CGL_FUR_PARAM where [PRM_CD_SURF_ROUGH] = 'A' and PRM_TS_END BETWEEN '" & StartDate.ToString("yyyy-MM-dd HH:mm:ss") & "' AND '" & EndDate.ToString("yyyy-MM-dd HH:mm:ss") & "'").Tables(0)
    End Function

    Public Function Cal_STRIP_FE_KG_DISSOLVED(ByVal StDt As String, ByVal EndDt As String) As DataTable
        Dim dtA_EndtDate As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END  FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END BETWEEN '" & StDt & "' AND '" & EndDt & "' order by PRM_TS_END desc").Tables(0)
        Dim EndDate As DateTime = dtA_EndtDate.Rows(0)(1)

        Dim cnt As Integer = 4
        Dim AEndDate As DateTime = EndDate
        Dim ZCampDate As DateTime

        'Dim dtZCamp As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='Z' and PRM_TS_END <='" & EndDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END desc").Tables(0)
        'Dim ZCampDate As DateTime = dtZCamp.Rows(0)(1)

        While True

            Dim dtZCamp As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='Z' and PRM_TS_END <='" & AEndDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END desc").Tables(0)
            ZCampDate = dtZCamp.Rows(0)(1)
            Dim dtACamp As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END <='" & ZCampDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END desc").Tables(0)
            Dim ACampDate As DateTime = dtACamp.Rows(0)(1)
            Dim dtCnt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT count(*) FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_TS_END] > '" & ACampDate.ToString("yyyy-MM-dd HH:mm:ss") & "' and PRM_TS_END <='" & ZCampDate.ToString("yyyy-MM-dd HH:mm:ss") & "'").Tables(0)
            cnt = dtCnt.Rows(0)(0)
            If cnt < 7 Then
                AEndDate = ACampDate
            Else
                Exit While
            End If
        End While
        'Dim dtA_StartDate As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END >='" & ZCampDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END ").Tables(0)
        Dim dtA_StartDate As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END >='" & ZCampDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END ").Tables(0)
        Dim StartDate As DateTime = dtA_StartDate.Rows(0)(1)

        'Return objDataHandler.GetDataSetFromQuery("SELECT SUM(CFD_STRIP_FE_KG_DISSOLVED),SUM(CFD_AL_REQ_FOR_DISSOLVED_FE) FROM [FP_PROCESS_DATA].[dbo].[CGL2_FE_DISSOLUTION] where CFD_TCM_PROCESS_DATE BETWEEN '" & StartDate & "' AND '" & EndDate & "'").Tables(0)
        Return objDataHandler.GetDataSetFromQuery("SELECT SUM(CFD_STRIP_FE_KG_DISSOLVED) Fe,SUM(CFD_AL_REQ_FOR_DISSOLVED_FE) Al FROM T_CGL_FUR_PARAM INNER JOIN CGL2_FE_DISSOLUTION ON T_CGL_FUR_PARAM.PRM_MESSAGE_ID=CGL2_FE_DISSOLUTION.CFD_MESSAGE_ID  where T_CGL_FUR_PARAM.PRM_TS_END BETWEEN '" & StartDate.ToString("yyyy-MM-dd HH:mm:ss") & "' AND '" & EndDate.ToString("yyyy-MM-dd HH:mm:ss") & "' group by convert(date,T_CGL_FUR_PARAM.PRM_TS_END)").Tables(0)
    End Function


    Public Function CalGANoOfDays(ByVal StDt As String, ByVal EndDt As String) As String
        Dim dtA_EndtDate As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END  FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END BETWEEN '" & StDt & "' AND '" & EndDt & "' order by PRM_TS_END desc").Tables(0)
        Dim EndDate As DateTime = dtA_EndtDate.Rows(0)(1)

        Dim cnt As Integer = 4
        Dim AEndDate As DateTime = EndDate
        Dim ZCampDate As DateTime

        'Dim dtZCamp As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='Z' and PRM_TS_END <='" & EndDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END desc").Tables(0)
        'Dim ZCampDate As DateTime = dtZCamp.Rows(0)(1)

        While True

            Dim dtZCamp As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='Z' and PRM_TS_END <='" & AEndDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END desc").Tables(0)
            ZCampDate = dtZCamp.Rows(0)(1)
            Dim dtACamp As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END <='" & ZCampDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END desc").Tables(0)
            Dim ACampDate As DateTime = dtACamp.Rows(0)(1)
            Dim dtCnt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT count(*) FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_TS_END] > '" & ACampDate.ToString("yyyy-MM-dd HH:mm:ss") & "' and PRM_TS_END <='" & ZCampDate.ToString("yyyy-MM-dd HH:mm:ss") & "'").Tables(0)
            cnt = dtCnt.Rows(0)(0)
            If cnt < 7 Then
                AEndDate = ACampDate
            Else
                Exit While
            End If
        End While
        'Dim dtA_StartDate As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END >='" & ZCampDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END ").Tables(0)
        Dim dtA_StartDate As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END >='" & ZCampDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END ").Tables(0)
        Dim StartDate As DateTime = dtA_StartDate.Rows(0)(1)
        Dim NoOfDays As String = DateDiff(DateInterval.Day, StartDate, EndDate).ToString() + 1

        Return NoOfDays
    End Function

    Sub CalGAStartEndDate(ByVal lblStart As Label, ByVal lblEnd As Label, ByVal StDt As String, ByVal EndDt As String)
        Dim dtA_EndtDate As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END  FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END BETWEEN '" & StDt & "' AND '" & EndDt & "' order by PRM_TS_END desc").Tables(0)
        Dim EndDate As DateTime = dtA_EndtDate.Rows(0)(1)

        Dim cnt As Integer = 4
        Dim AEndDate As DateTime = EndDate
        Dim ZCampDate As DateTime

        'Dim dtZCamp As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='Z' and PRM_TS_END <='" & EndDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END desc").Tables(0)
        'Dim ZCampDate As DateTime = dtZCamp.Rows(0)(1)

        While True

            Dim dtZCamp As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='Z' and PRM_TS_END <='" & AEndDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END desc").Tables(0)
            ZCampDate = dtZCamp.Rows(0)(1)
            Dim dtACamp As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END <='" & ZCampDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END desc").Tables(0)
            Dim ACampDate As DateTime = dtACamp.Rows(0)(1)
            Dim dtCnt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT count(*) FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_TS_END] > '" & ACampDate.ToString("yyyy-MM-dd HH:mm:ss") & "' and PRM_TS_END <='" & ZCampDate.ToString("yyyy-MM-dd HH:mm:ss") & "'").Tables(0)
            cnt = dtCnt.Rows(0)(0)
            If cnt < 7 Then
                AEndDate = ACampDate
            Else
                Exit While
            End If
        End While
        'Dim dtA_StartDate As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END >='" & ZCampDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END ").Tables(0)
        Dim dtA_StartDate As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END >='" & ZCampDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END ").Tables(0)
        Dim StartDate As DateTime = dtA_StartDate.Rows(0)(1)
        lblStart.Text = StartDate.ToString("dd-MM-yyyy HH:mm:ss")
        lblEnd.Text = EndDate.ToString("dd-MM-yyyy HH:mm:ss")
    End Sub

    Public Function CalChartData(ByVal StDt As String, ByVal EndDt As String) As DataSet
        Dim dtA_EndtDate As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END  FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END BETWEEN '" & StDt & "' AND '" & EndDt & "' order by PRM_TS_END desc").Tables(0)
        Dim EndDate As DateTime = dtA_EndtDate.Rows(0)(1)

        Dim cnt As Integer = 4
        Dim AEndDate As DateTime = EndDate
        Dim ZCampDate As DateTime

        'Dim dtZCamp As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='Z' and PRM_TS_END <='" & EndDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END desc").Tables(0)
        'Dim ZCampDate As DateTime = dtZCamp.Rows(0)(1)

        While True

            Dim dtZCamp As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='Z' and PRM_TS_END <='" & AEndDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END desc").Tables(0)
            ZCampDate = dtZCamp.Rows(0)(1)
            Dim dtACamp As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END <='" & ZCampDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END desc").Tables(0)
            Dim ACampDate As DateTime = dtACamp.Rows(0)(1)
            Dim dtCnt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT count(*) FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_TS_END] > '" & ACampDate.ToString("yyyy-MM-dd HH:mm:ss") & "' and PRM_TS_END <='" & ZCampDate.ToString("yyyy-MM-dd HH:mm:ss") & "'").Tables(0)
            cnt = dtCnt.Rows(0)(0)
            If cnt < 7 Then
                AEndDate = ACampDate
            Else
                Exit While
            End If
        End While
        'Dim dtA_StartDate As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END >='" & ZCampDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END ").Tables(0)
        Dim dtA_StartDate As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END >='" & ZCampDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END ").Tables(0)
        Dim StartDate As DateTime = dtA_StartDate.Rows(0)(1)
        'Return objDataHandler.GetDataSetFromQuery(" select (sum(CFD_STRIP_FE_KG_DISSOLVED)*10*1000*10*20 / (3.6*2.5*10000*7.1))  FROM T_CGL_FUR_PARAM INNER JOIN CGL2_FE_DISSOLUTION ON T_CGL_FUR_PARAM.PRM_MESSAGE_ID=CGL2_FE_DISSOLUTION.CFD_MESSAGE_ID  where T_CGL_FUR_PARAM.PRM_TS_END BETWEEN '" & StartDate.ToString("yyyy-MM-dd HH:mm:ss") & "' AND '" & EndDate.ToString("yyyy-MM-dd HH:mm:ss") & "' group by convert(date,T_CGL_FUR_PARAM.PRM_TS_END)").Tables(0)
        Return objDataHandler.GetDataSetFromQuery(" select (sum(CFD_STRIP_FE_KG_DISSOLVED)*10*1000*10*20 / (3.6*2.5*10000*7.1))  FROM T_CGL_FUR_PARAM INNER JOIN CGL2_FE_DISSOLUTION ON T_CGL_FUR_PARAM.PRM_MESSAGE_ID=CGL2_FE_DISSOLUTION.CFD_MESSAGE_ID  where T_CGL_FUR_PARAM.PRM_TS_END BETWEEN '" & StartDate.ToString("yyyy-MM-dd HH:mm:ss") & "' AND '" & EndDate.ToString("yyyy-MM-dd HH:mm:ss") & "' group by convert(date,T_CGL_FUR_PARAM.PRM_TS_END);select (sum(CFD_STRIP_FE_KG_DISSOLVED)*10)  FROM T_CGL_FUR_PARAM INNER JOIN CGL2_FE_DISSOLUTION ON T_CGL_FUR_PARAM.PRM_MESSAGE_ID=CGL2_FE_DISSOLUTION.CFD_MESSAGE_ID  where T_CGL_FUR_PARAM.PRM_TS_END BETWEEN '" & StartDate.ToString("yyyy-MM-dd HH:mm:ss") & "' AND '" & EndDate.ToString("yyyy-MM-dd HH:mm:ss") & "' group by convert(date,T_CGL_FUR_PARAM.PRM_TS_END)")
    End Function
    Sub SaveResetDateTime()
        objDataHandler.RunSimpleQuery("Insert into CGL_FUR_PARAM_RESET_DATETIME(RESET_DATE_TIME)values('" & Now.ToString("dd-MMM-yy hh:mm:ss tt") & "')")
    End Sub

    Public Function CalPreviousDross(ByVal StDt As String, ByVal EndDt As String) As Double
        Dim dtA_EndtDate As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END  FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END BETWEEN '" & StDt & "' AND '" & EndDt & "' order by PRM_TS_END desc").Tables(0)
        Dim EndDate As DateTime = dtA_EndtDate.Rows(0)(1)

        Dim cnt As Integer = 4
        Dim AEndDate As DateTime = EndDate
        Dim ZCampDate As DateTime

        'Dim dtZCamp As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='Z' and PRM_TS_END <='" & EndDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END desc").Tables(0)
        'Dim ZCampDate As DateTime = dtZCamp.Rows(0)(1)

        While True

            Dim dtZCamp As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='Z' and PRM_TS_END <='" & AEndDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END desc").Tables(0)
            ZCampDate = dtZCamp.Rows(0)(1)
            Dim dtACamp As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END <='" & ZCampDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END desc").Tables(0)
            Dim ACampDate As DateTime = dtACamp.Rows(0)(1)
            Dim dtCnt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT count(*) FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_TS_END] > '" & ACampDate.ToString("yyyy-MM-dd HH:mm:ss") & "' and PRM_TS_END <='" & ZCampDate.ToString("yyyy-MM-dd HH:mm:ss") & "'").Tables(0)
            cnt = dtCnt.Rows(0)(0)
            If cnt < 7 Then
                AEndDate = ACampDate
            Else
                Exit While
            End If
        End While
        'Dim dtA_StartDate As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END >='" & ZCampDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END ").Tables(0)
        Dim dtA_StartDate As DataTable = objDataHandler.GetDataSetFromQuery("SELECT Top 1 PRM_CD_SURF_ROUGH ,PRM_TS_END FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_CD_SURF_ROUGH] ='A' and PRM_TS_END >='" & ZCampDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by PRM_TS_END ").Tables(0)
        Dim StartDate As DateTime = dtA_StartDate.Rows(0)(1)
        Dim DtPreviousResetDate As DataTable = objDataHandler.GetDataSetFromQuery("select top 1 RESET_DATE_TIME from CGL_FUR_PARAM_RESET_DATETIME where RESET_DATE_TIME <='" & StartDate.ToString("yyyy-MM-dd HH:mm:ss") & "' order by RESET_DATE_TIME desc").Tables(0)
        If DtPreviousResetDate.Rows.Count = 0 Then
            Return 0.0
        End If
        Dim ResetDateTime As DateTime = DtPreviousResetDate.Rows(0)(0)
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT SUM(CFD_STRIP_FE_KG_DISSOLVED) Fe,SUM(CFD_AL_REQ_FOR_DISSOLVED_FE) Al FROM T_CGL_FUR_PARAM INNER JOIN CGL2_FE_DISSOLUTION ON T_CGL_FUR_PARAM.PRM_MESSAGE_ID=CGL2_FE_DISSOLUTION.CFD_MESSAGE_ID  where T_CGL_FUR_PARAM.PRM_TS_END BETWEEN '" & ResetDateTime.ToString("yyyy-MM-dd HH:mm:ss") & "' AND '" & StartDate.ToString("yyyy-MM-dd HH:mm:ss") & "' group by convert(date,T_CGL_FUR_PARAM.PRM_TS_END)").Tables(0)
        Return dt.Compute("sum(Fe)", "")
    End Function

    Public Sub PopulateGrade(ByVal GradeDropDown As DropDownList, ByVal FromDate As String, ByVal ToDate As String)
        Try
            GradeDropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct PRM_CD_GRADE from T_CGL_FUR_PARAM where PRM_TS_END between '" & FromDate & "' and '" & ToDate & "' ORDER BY PRM_CD_GRADE").Tables(0)
            GradeDropDown.DataTextField = "PRM_CD_GRADE"
            GradeDropDown.DataValueField = "PRM_CD_GRADE"
            GradeDropDown.DataBind()
            GradeDropDown.Items.Insert(0, "All")
            GradeDropDown.SelectedIndex = 0
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try


    End Sub

    Public Sub PopulateZone(ByVal GradeDropDown As DropDownList, ByVal FromDate As String, ByVal ToDate As String)
        Try
            GradeDropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct TDD_ZONE from [T_DPCR_DATA_NEW]").Tables(0)   'where TDD_POSTING_DATE between '" & FromDate & "' and '" & ToDate & "' ORDER BY TDD_ZONE").Tables(0)
            'GradeDropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct TDD_ZONE from [T_DPCR_DATA] where TDD_LOGGING_DATE between '" & FromDate & "' and '" & ToDate & "' ORDER BY TDD_ZONE").Tables(0)
            GradeDropDown.DataTextField = "TDD_ZONE"
            GradeDropDown.DataValueField = "TDD_ZONE"
            GradeDropDown.DataBind()
            GradeDropDown.Items.Insert(0, "All")
            GradeDropDown.SelectedIndex = 0
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try


    End Sub


    Public Sub PopulateProductSegment(ByVal DropDown As DropDownList, ByVal FromDate As String, ByVal ToDate As String, Optional ByVal filterbydate As Boolean = False)
        Try
            If filterbydate = False Then
                DropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct TDD_PRODUCT_SEGMENT from [T_DPCR_DATA_NEW] where TDD_POSTING_DATE between '" & FromDate & "' and '" & ToDate & "' WHERE ORDER BY TDD_PRODUCT_SEGMENT").Tables(0)
            Else
                DropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct TDD_PRODUCT_SEGMENT from [T_DPCR_DATA_NEW] ORDER BY TDD_PRODUCT_SEGMENT").Tables(0)
            End If
            DropDown.DataTextField = "TDD_PRODUCT_SEGMENT"
            DropDown.DataValueField = "TDD_PRODUCT_SEGMENT"
            DropDown.DataBind()

        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub

    Public Sub PopulateOriginPlant(ByVal DropDown As DropDownList, ByVal FromDate As String, ByVal ToDate As String, Optional ByVal filterbydate As Boolean = False)
        Try
            If filterbydate = False Then
                DropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct TDD_PLANT_NAME from [T_DPCR_DATA_NEW] where TDD_POSTING_DATE between '" & FromDate & "' and '" & ToDate & "' WHERE ORDER BY TDD_PLANT_NAME").Tables(0)
            Else
                DropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct TDD_PLANT_NAME from [T_DPCR_DATA_NEW] ORDER BY TDD_PLANT_NAME").Tables(0)
            End If
            DropDown.DataTextField = "TDD_PLANT_NAME"
            DropDown.DataValueField = "TDD_PLANT_NAME"
            DropDown.DataBind()

        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub
    Public Sub PopulateDPCRDefect(ByVal DropDown As DropDownList)
        Try

            DropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct DDC_DEFECT_CLUB as TDD_DEFECT from [T_DPCR_DEFECT_CLUBBING] ORDER BY DDC_DEFECT_CLUB").Tables(0)

            ' DropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct TDD_DEFECT from [T_DPCR_DATA_NEW] where TDD_DEFECT in (select ddc_defect from T_DPCR_DEFECT_CLUBBING where DDC_DEFECT_CLUB='" & DropDown.SelectedItem.Text & "' ) ORDER BY TDD_DEFECT").Tables(0)
            DropDown.DataTextField = "TDD_DEFECT"
            DropDown.DataValueField = "TDD_DEFECT"
            DropDown.DataBind()
            DropDown.Items.Insert(0, "All")
            DropDown.SelectedIndex = 0
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub

    'Public Sub PopulateDPCRDefect(ByVal DropDown As DropDownList)
    '    Try
    '        DropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct TDD_DEFECT from [T_DPCR_DATA_NEW] ORDER BY TDD_DEFECT").Tables(0)
    '        DropDown.DataTextField = "TDD_DEFECT"
    '        DropDown.DataValueField = "TDD_DEFECT"
    '        DropDown.DataBind()
    '        DropDown.Items.Insert(0, "All")
    '        DropDown.SelectedIndex = 0
    '    Catch ex As Exception
    '        Throw New Exception(ex.ToString())
    '    End Try
    'End Sub

    Public Sub PopulateDetectionPlant(ByVal DropDown As DropDownList, ByVal FromDate As String, ByVal ToDate As String, Optional ByVal filterbydate As Boolean = False)
        Try
            If filterbydate = False Then
                DropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct TDD_DETECTION_PLANT from [T_DPCR_DATA_NEW] where TDD_POSTING_DATE between '" & FromDate & "' and '" & ToDate & "' WHERE ORDER BY TDD_DETECTION_PLANT").Tables(0)
            Else
                DropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct TDD_DETECTION_PLANT from [T_DPCR_DATA_NEW] ORDER BY TDD_DETECTION_PLANT").Tables(0)
            End If
            DropDown.DataTextField = "TDD_DETECTION_PLANT"
            DropDown.DataValueField = "TDD_DETECTION_PLANT"
            DropDown.DataBind()

        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub
    Public Sub PopulateDPCR_Customer_Status(ByVal DropDown As DropDownList, ByVal FromDate As String, ByVal ToDate As String, Optional ByVal filterbydate As Boolean = False)
        Try
            If filterbydate = False Then
                DropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct TDD_PRIORITY_NUM from [T_DPCR_DATA_NEW] where TDD_POSTING_DATE between '" & FromDate & "' and '" & ToDate & "' and TDD_PRIORITY_NUM <> ' ' WHERE ORDER BY TDD_PRIORITY_NUM").Tables(0)
            Else
                DropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct TDD_PRIORITY_NUM from [T_DPCR_DATA_NEW] WHERE TDD_PRIORITY_NUM <> ' ' ORDER BY TDD_PRIORITY_NUM").Tables(0)
            End If
            DropDown.DataTextField = "TDD_PRIORITY_NUM"
            DropDown.DataValueField = "TDD_PRIORITY_NUM"
            DropDown.DataBind()

        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub
    Public Sub PopulateInvestigator_Name(ByVal DropDown As DropDownList, ByVal FromDate As String, ByVal ToDate As String, Optional ByVal filterbydate As Boolean = False)
        Try
            If filterbydate = False Then
                DropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct TDD_WEEK_NO from [T_DPCR_DATA_NEW] where TDD_POSTING_DATE between '" & FromDate & "' and '" & ToDate & "'AND TDD_WEEK_NO <> ' ' WHERE ORDER BY TDD_WEEK_NO").Tables(0)
            Else
                DropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct TDD_WEEK_NO from [T_DPCR_DATA_NEW]  WHERE TDD_WEEK_NO <> ' ' ORDER BY TDD_WEEK_NO").Tables(0)
            End If
            DropDown.DataTextField = "TDD_WEEK_NO"
            DropDown.DataValueField = "TDD_WEEK_NO"
            DropDown.DataBind()

        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub

    Public Sub PopulateRequester_Name(ByVal DropDown As DropDownList, ByVal FromDate As String, ByVal ToDate As String, Optional ByVal filterbydate As Boolean = False)
        Try
            If filterbydate = False Then
                DropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct TDD_REMARKS from [T_DPCR_DATA_NEW] where TDD_POSTING_DATE between '" & FromDate & "' and '" & ToDate & "' AND TDD_REMARKS <> ' '  WHERE ORDER BY TDD_REMARKS").Tables(0)
            Else
                DropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct TDD_REMARKS from [T_DPCR_DATA_NEW]  WHERE TDD_REMARKS <> ' ' ORDER BY TDD_REMARKS").Tables(0)
            End If
            DropDown.DataTextField = "TDD_REMARKS"
            DropDown.DataValueField = "TDD_REMARKS"
            DropDown.DataBind()

        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub

    Public Sub PopulateDPCRCustomer(ByVal DropDown As DropDownList, Optional ByVal zone As String = "All", Optional marketsegment As String = "All")
        Try
            Dim filter As String = ""
            If zone <> "All" Then
                filter &= " and TDC_ZONE='" & zone & "'"
            End If
            If marketsegment <> "All" Then
                filter &= " and TDC_Market_Segment='" & marketsegment & "'"
            End If
            DropDown.DataSource = objDataHandler.GetDataSetFromQuery("select distinct tdc_customer_alias,tdc_market_segment,tdc_priority_num from [T_DPCR_CUST_PRIORITY] where 1=1 " & filter & " order by tdc_market_segment,tdc_priority_num").Tables(0)
            DropDown.DataTextField = "tdc_customer_alias"
            DropDown.DataValueField = "tdc_customer_alias"
            DropDown.DataBind()
            DropDown.Items.Insert(0, "All")
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub


    Public Sub PopulateMarketSegment(ByVal MarketDropDown As DropDownList, ByVal FromDate As String, ByVal ToDate As String, Optional ByVal filterbydate As Boolean = False)
        Try
            If filterbydate = False Then
                MarketDropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct TDD_MARKET_SEGMENT from [T_DPCR_DATA_NEW] where TDD_POSTING_DATE between '" & FromDate & "' and '" & ToDate & "' ORDER BY TDD_MARKET_SEGMENT").Tables(0)
            Else
                MarketDropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct TDD_MARKET_SEGMENT from [T_DPCR_DATA_NEW] ORDER BY TDD_MARKET_SEGMENT").Tables(0)
            End If

            'MarketDropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct TDD_MARKET_VERTICAL from [T_DPCR_DATA_NEW] where TDD_LOGGING_DATE between '" & FromDate & "' and '" & ToDate & "' ORDER BY TDD_MARKET_VERTICAL").Tables(0)
            MarketDropDown.DataTextField = "TDD_MARKET_SEGMENT"
            MarketDropDown.DataValueField = "TDD_MARKET_SEGMENT"
            MarketDropDown.DataBind()
            MarketDropDown.SelectedIndex = MarketDropDown.Items.IndexOf(MarketDropDown.Items.FindByText("AUTOMOTIVE"))
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try


    End Sub

    Public Sub PopulateTdc(ByVal TdcDropDown As DropDownList, ByVal FromDate As String, ByVal ToDate As String, ByVal Grade As String)
        Try
            If Grade.ToLower = "all" Then
                TdcDropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct PRM_TDC_NO from T_CGL_FUR_PARAM where PRM_TS_END between '" & FromDate & "' and '" & ToDate & "' ORDER BY PRM_TDC_NO").Tables(0)
            Else
                TdcDropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct PRM_TDC_NO from T_CGL_FUR_PARAM where PRM_TS_END between '" & FromDate & "' and '" & ToDate & "' and PRM_CD_GRADE = '" & Grade & "' ORDER BY PRM_TDC_NO").Tables(0)

            End If

            TdcDropDown.DataTextField = "PRM_TDC_NO"
            TdcDropDown.DataValueField = "PRM_TDC_NO"
            TdcDropDown.DataBind()
            TdcDropDown.Items.Insert(0, "All")
            TdcDropDown.SelectedIndex = 0
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try


    End Sub

    Public Sub PopulateRough(ByVal RoughDropDown As DropDownList, ByVal FromDate As String, ByVal ToDate As String, ByVal Grade As String, ByVal TDC As String)
        Try
            Dim filter As String = ""
            If Grade.ToLower <> "all" Then
                filter &= " and PRM_CD_GRADE = '" & Grade & "'"
            End If
            If TDC.ToLower <> "all" Then
                filter &= "  and PRM_TDC_NO = '" & TDC & "'"
            End If
            RoughDropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct PRM_CD_SURF_ROUGH,case when PRM_CD_SURF_ROUGH = 'A' then 'GA' else 'GI' end as aname from T_CGL_FUR_PARAM where PRM_TS_END between '" & FromDate & "' and '" & ToDate & "' " & filter & " ORDER BY PRM_CD_SURF_ROUGH").Tables(0)
            RoughDropDown.DataTextField = "aname"
            RoughDropDown.DataValueField = "PRM_CD_SURF_ROUGH"
            RoughDropDown.DataBind()
            RoughDropDown.Items.Insert(0, "All")
            RoughDropDown.SelectedIndex = 0
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try


    End Sub
    Public Sub LoadColumnsDataForAll(ByVal DropDownName As DropDownList, ByVal TableName As String, ByVal ColumnName As String, ByVal DateColumnName As String, ByVal FromDt As String, ByVal ToDate As String, ByVal FilterVal As String)
        'Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT distinct " & ColumnName & " FROM " & TableName & " where " & DateColumnName & " between '" & Convert.ToDateTime(FromDt).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(ToDate).ToString("yyyy-MM-dd HH:mm:ss") & "' and " & ColumnName & " <> '' order by " & ColumnName & "").Tables(0)
        Dim query As String = ""
        Dim TextField As String = ""
        If ColumnName = "CLR_PROCESS_LINE" Then
            query = "SELECT distinct " & ColumnName & " FROM " & TableName & " where " & DateColumnName & " between '" & Convert.ToDateTime(FromDt).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(ToDate).ToString("yyyy-MM-dd HH:mm:ss") & "' and " & ColumnName & " <> '' order by " & ColumnName & ""
            TextField = "CLR_PROCESS_LINE"
        Else
            query = "SELECT DISTINCT " & ColumnName & ",DBO.UFN_GET_PARAM_ALIAS_NAME(" & ColumnName & ") AS PARAM_TEST FROM CRM_LABTEST_RES WHERE " & ColumnName & " <>'' and CLR_PROCESS_LINE in (" & FilterVal & ") ORDER BY PARAM_TEST"
            TextField = "PARAM_TEST"
        End If
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery(query).Tables(0)
        If dt.Rows.Count > 0 Then
            DropDownName.DataSource = dt
            '--------------
            If TextField = "PARAM_TEST" Then
                Dim dt1 As DataTable = dt.DefaultView.ToTable(True, "PARAM_TEST")
                Dim dt2 As DataTable = dt.Clone

                For row As Integer = 0 To dt1.Rows.Count - 1
                    Dim dv As DataView = dt.DefaultView
                    dv.RowFilter = "PARAM_TEST='" & dt1.Rows(row)(0) & "'"
                    Dim str As String = ""
                    For j As Integer = 0 To dv.Count - 1
                        str &= ",'" & dv.Item(j)(0) & "'"
                    Next
                    dt2.Rows.Add(str.Substring(1), dt1.Rows(row)(0))
                    dv.RowFilter = ""
                Next
                DropDownName.DataSource = dt2
            Else
                DropDownName.DataSource = dt
            End If
            '-------------
            DropDownName.DataTextField = TextField
            DropDownName.DataValueField = ColumnName
            DropDownName.DataBind()
            DropDownName.Items.Insert(0, "Select")
            DropDownName.SelectedIndex = 0
        End If

    End Sub
    Public Function GetDPCRPriority(ByVal market As String) As DataTable
        Dim q As String = "select min(tdc_priority_num),max(tdc_priority_num) from T_DPCR_CUST_PRIORITY where TDC_MARKET_SEGMENT='" & market & "'"
        Return objDataHandler.GetDataSetFromQuery(q).Tables(0)
    End Function


    Public Function GetDPCRData(ByVal dfrom As String, ByVal dTo As String, Optional ByVal zone As String = "All", Optional ByVal market As String = "AUTOMOTIVE", Optional ByVal fromP As Integer = 1, Optional ByVal toP As Integer = 20, Optional ByVal customer As String = "All") As DataSet
        Dim q As String = ""
        Dim cust As String = ""
        If customer <> "All" And customer <> "" Then
            cust = " and tdc_customer_alias='" & customer & "' "
        End If
        If zone = "All" Then
            '           q = "select tdd_zone,tdd_market_segment as tdd_market_vertical,DATEPART(wk, tdd_posting_date) as dbwk,count(*) as cnt" &
            '",tdd_defect as tdd_complaint,tdc_customer_alias as tdd_customer,row_number() over (partition by tdd_zone,tdd_defect,tdc_customer_alias order by tdd_zone,tdd_defect,tdc_customer_alias) as freq from T_DPCR_DATA_new inner join T_DPCR_CUST_PRIORITY on TDD_CUSTOMER=TDC_CUSTOMER and TDD_MARKET_SEGMENT=TDC_MARKET_SEGMENT where tdd_market_segment='" & market & "' and tdd_posting_date between '" & dfrom & "' and '" & dTo & "' and TDC_PRIORITY_NUM between " & fromP & " and " & toP & " " &
            '"group by tdd_zone,tdd_market_segment,DATEPART(wk, tdd_posting_date),tdd_defect,tdd_customer,tdc_customer_alias order by 1,3"
            q = "SELECT distinct TDc_CUSTOMER_ALIAS,TDC_PRIORITY_NUM,TDC_ZONE as tdd_zone,T.* FROM T_DPCR_CUST_PRIORITY LEFT OUTER JOIN (select tdc_zone as zone,tdd_market_segment as tdd_market_vertical,DATEPART(wk, tdd_posting_date) as dbwk,tdd_defect as tdd_complaint,DDC_DEFECT_CLUB,tdc_customer_alias as tdd_customer,tdd_posting_date,row_number() over(partition by tdc_zone,DDC_DEFECT_CLUB,tdc_customer_alias order by tdc_zone,DDC_DEFECT_CLUB,tdc_customer_alias,tdd_posting_date) as freq" &
 " from T_DPCR_DATA_new inner join T_DPCR_CUST_PRIORITY on TDD_CUSTOMER=TDC_CUSTOMER and TDD_MARKET_SEGMENT=TDC_MARKET_SEGMENT inner join T_DPCR_DEFECT_CLUBBING on DDC_DEFECT=tdd_defect where tdd_market_segment='" & market & "' and tdd_posting_date between '" & dfrom & "' and '" & dTo & "' and TDC_PRIORITY_NUM between " & fromP & " and " & toP & " " &
 " order by 1,6,5,7  OFFSET 0 ROWS) T ON TDC_CUSTOMER_ALIAS=TDD_CUSTOMER WHERE " &
 "TDC_MARKET_SEGMENT='" & market & "' and TDC_PRIORITY_NUM between " & fromP & " and " & toP & cust & " ORDER BY 2,3,tdd_customer,tdd_posting_date"
        Else

            '           q = "select tdc_zone as tdd_zone,tdd_market_segment as tdd_market_vertical,DATEPART(wk, tdd_posting_date) as dbwk,count(*) as cnt" &
            '",tdd_defect as tdd_complaint,tdc_customer_alias,tdc_customer_alias as tdd_customer,row_number() over (partition by tdc_zone,tdd_defect,tdc_customer_alias order by tdc_zone,tdd_defect,tdc_customer_alias) as freq from T_DPCR_DATA_new inner join T_DPCR_CUST_PRIORITY on TDD_CUSTOMER=TDC_CUSTOMER and TDD_MARKET_SEGMENT=TDC_MARKET_SEGMENT  where tdd_market_segment='" & market & "' and tdc_zone='" & zone & "' and tdd_posting_date between '" & dfrom & "' and '" & dTo & "' and TDC_PRIORITY_NUM between " & fromP & " and " & toP & " " &
            '"group by tdc_zone,tdd_market_segment,DATEPART(wk, tdd_posting_date),tdd_defect,tdc_customer_alias order by 1,3"
            q = "SELECT distinct TDc_CUSTOMER_ALIAS,TDC_PRIORITY_NUM,TDC_ZONE as tdd_zone,T.* FROM T_DPCR_CUST_PRIORITY LEFT OUTER JOIN (select tdc_zone as zone,tdd_market_segment as tdd_market_vertical,DATEPART(wk, tdd_posting_date) as dbwk,tdd_defect as tdd_complaint,DDC_DEFECT_CLUB,tdc_customer_alias as tdd_customer,tdd_posting_date,row_number() over(partition by tdc_zone,DDC_DEFECT_CLUB,tdc_customer_alias order by tdc_zone,DDC_DEFECT_CLUB,tdc_customer_alias,tdd_posting_date) as freq" &
 " from T_DPCR_DATA_new inner join T_DPCR_CUST_PRIORITY on TDD_CUSTOMER=TDC_CUSTOMER and TDD_MARKET_SEGMENT=TDC_MARKET_SEGMENT inner join T_DPCR_DEFECT_CLUBBING on DDC_DEFECT=tdd_defect where tdd_market_segment='" & market & "' and tdd_posting_date between '" & dfrom & "' and '" & dTo & "' and TDC_PRIORITY_NUM between " & fromP & " and " & toP & " " &
 " order by 1,6,5,7  OFFSET 0 ROWS) T ON TDC_CUSTOMER_ALIAS=TDD_CUSTOMER WHERE " &
     "TDC_MARKET_SEGMENT='" & market & "' and tdc_zone='" & zone & cust & "' and TDC_PRIORITY_NUM between " & fromP & " and " & toP & " ORDER BY 2,3"

        End If
        Return objDataHandler.GetDataSetFromQuery(q)
    End Function
    Public Function GetWetChemicalTestDataForAll(ByVal TableName As String, ByVal FromDate As String, ByVal ToDate As String, ByVal DateColumn As String, ByVal Filter As String, ByVal Filter1 As String) As DataTable
        Dim query As String = ""
        If Filter <> "" And Filter1 <> "" Then
            'query = "select CLR_TEST_VALUE,CLR_DT_SAMPLING_DATE,ISNULL(CLR_PARAM_MIN,0) AS CLR_PARAM_MIN,CLR_PARAM_TEST from " & TableName & " where " & DateColumn & " between '" & FromDate & "' and '" & ToDate & "' and cast(CLR_TEST_VALUE as float)>0 and CLR_PROCESS_LINE in ('" & Filter & "') and CLR_PARAM_TEST in (" & Filter1 & ")  order by CLR_DT_SAMPLING_DATE"
            'query = "select CLR_TEST_VALUE,CLR_DT_SAMPLING_DATE,ISNULL(CLR_PARAM_MIN,0) AS CLR_PARAM_MIN,CLR_PARAM_TEST,""CLR_PARAM_TEST_NEW"" = " & vbCrLf & _
            '        "CASE" & vbCrLf & _
            '        "WHEN CLR_TEST_VALUE > 0.15 AND CLR_TEST_VALUE <= 0.4 AND (CLR_PARAM_TEST='ZAAL' OR CLR_PARAM_TEST='ZAZS' OR CLR_PARAM_TEST='ZAGA') THEN 'GI'" & vbCrLf & _
            '        "WHEN CLR_TEST_VALUE >= 0.1 AND CLR_TEST_VALUE <= 0.15 AND (CLR_PARAM_TEST='ZAAL' OR CLR_PARAM_TEST='ZAZS' OR CLR_PARAM_TEST='ZAGA') THEN 'GA'" & vbCrLf & _
            '        "WHEN CLR_PARAM_TEST='ZAFE' THEN 'FE'" & vbCrLf & _
            '        "ELSE CLR_PARAM_TEST" & vbCrLf & _
            '        "END" & vbCrLf & _
            '        "from " & TableName & " where " & DateColumn & " between '" & FromDate & "' and '" & ToDate & "'" & vbCrLf & _
            '        "and cast(CLR_TEST_VALUE as float)>0 and CLR_PROCESS_LINE in ('" & Filter & "') and CLR_PARAM_TEST in (" & Filter1 & ")" & vbCrLf & _
            '        "order by CLR_DT_SAMPLING_DATE"
            query = "select CLR_TEST_VALUE,CLR_DT_SAMPLING_DATE,ISNULL(CLR_PARAM_MIN,0) AS CLR_PARAM_MIN,CLR_PARAM_TEST,""CLR_PARAM_TEST_NEW"" = " & vbCrLf &
                   "CASE" & vbCrLf &
                   "WHEN CLR_TEST_VALUE > 0.15 AND CLR_TEST_VALUE <= 0.4 AND (CLR_PARAM_TEST='ZAAL' OR CLR_PARAM_TEST='ZAZS' OR CLR_PARAM_TEST='ZAGA') THEN 'GI'" & vbCrLf &
                   "WHEN CLR_TEST_VALUE >= 0.1 AND CLR_TEST_VALUE <= 0.15 AND (CLR_PARAM_TEST='ZAAL' OR CLR_PARAM_TEST='ZAZS' OR CLR_PARAM_TEST='ZAGA') THEN 'GA'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='ZAFE' THEN 'FE'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='ZASB' THEN 'Antimony'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='CRPT' THEN 'Chromate Prepertion'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='ZAPB' THEN 'Lead'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='ALET' THEN 'ECL tank'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='ALPT' THEN 'Predeg. tank'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='SHCR' THEN 'Sheet Chromium'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='CRWT' THEN 'Working tank'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='ACIDT1' THEN 'HCL Acid T1'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='ACIDT2' THEN 'HCL Acid T2'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='ACIDT3' THEN 'HCL Acid T3'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='ACIDT4' THEN 'HCL Acid T4'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='HCLWT1' THEN 'HCL T1'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='HCLWT2' THEN 'HCL T2'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='HCLWT3' THEN 'HCL T3'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='HCLWT4' THEN 'HCL T4'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='ALTK' THEN 'Alkali tank'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='ALHW' THEN 'Hot Rinse Water'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='ZASN' THEN 'Tin'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='ALETO' THEN 'ECL Tank (Fe %)'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='ZAEAL' THEN 'Eff Aluminium'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='FE' THEN 'FE'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='ZAZN' THEN 'Zinc'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='WL' THEN 'WL'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='FET1' THEN 'Iron FE T1'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='FEWT1' THEN 'Iron FEW T1'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='FET2' THEN 'Iron FE T2'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='FEWT2' THEN 'Iron FEW T2'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='FET3' THEN 'Iron FE T3'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='FEWT3' THEN 'Iron FEW T3'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='FET4' THEN 'Iron FE T4'" & vbCrLf &
                   "WHEN CLR_PARAM_TEST='FEWT4' THEN 'Iron FEW T4'" & vbCrLf &
                   "ELSE CLR_PARAM_TEST" & vbCrLf &
                   "END" & vbCrLf &
                   "from " & TableName & " where " & DateColumn & " between '" & FromDate & "' and '" & ToDate & "'" & vbCrLf &
                   "and cast(CLR_TEST_VALUE as float)>0 and CLR_PROCESS_LINE in ('" & Filter & "') and CLR_PARAM_TEST in (" & Filter1 & ")" & vbCrLf &
                   "order by CLR_DT_SAMPLING_DATE"
        End If
        Return objDataHandler.GetDataSetFromQuery(query).Tables(0)
    End Function
    Public Sub LoadColumnsDataForAllVal(ByVal CheckBoxListName As CheckBoxList, ByVal TableName As String, ByVal ColumnName As String, ByVal DateColumnName As String, ByVal FromDt As String, ByVal ToDate As String, ByVal FilterVal As String)
        'Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT distinct " & ColumnName & " FROM " & TableName & " where " & DateColumnName & " between '" & Convert.ToDateTime(FromDt).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(ToDate).ToString("yyyy-MM-dd HH:mm:ss") & "' and " & ColumnName & " <> '' order by " & ColumnName & "").Tables(0)
        Dim query As String = ""
        Dim TextField As String = ""
        If ColumnName = "CLR_PROCESS_LINE" Then
            query = "SELECT distinct " & ColumnName & " FROM " & TableName & " where " & DateColumnName & " between '" & Convert.ToDateTime(FromDt).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(ToDate).ToString("yyyy-MM-dd HH:mm:ss") & "' and " & ColumnName & " <> '' order by " & ColumnName & ""
            TextField = "CLR_PROCESS_LINE"
        Else
            query = "SELECT DISTINCT " & ColumnName & ",DBO.UFN_GET_PARAM_ALIAS_NAME(" & ColumnName & ") AS PARAM_TEST FROM CRM_LABTEST_RES WHERE " & ColumnName & " <>'' and CLR_PROCESS_LINE in ('" & FilterVal & "') ORDER BY PARAM_TEST"
            TextField = "PARAM_TEST"
        End If
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery(query).Tables(0)
        If dt.Rows.Count > 0 Then
            CheckBoxListName.DataSource = dt
            '--------------
            If TextField = "PARAM_TEST" Then
                Dim dt1 As DataTable = dt.DefaultView.ToTable(True, "PARAM_TEST")
                Dim dt2 As DataTable = dt.Clone

                For row As Integer = 0 To dt1.Rows.Count - 1
                    Dim dv As DataView = dt.DefaultView
                    dv.RowFilter = "PARAM_TEST='" & dt1.Rows(row)(0) & "'"
                    Dim str As String = ""
                    For j As Integer = 0 To dv.Count - 1
                        str &= ",'" & dv.Item(j)(0) & "'"
                    Next
                    dt2.Rows.Add(str.Substring(1), dt1.Rows(row)(0))
                    dv.RowFilter = ""
                Next
                CheckBoxListName.DataSource = dt2
            Else
                CheckBoxListName.DataSource = dt
            End If
            '-------------
            CheckBoxListName.DataTextField = TextField
            CheckBoxListName.DataValueField = ColumnName
            CheckBoxListName.DataBind()
            'CheckBoxListName.Items.Insert(0, "All")
            'DropDownName.Items.Insert(0, "Select")
            'DropDownName.SelectedIndex = 0
        End If

    End Sub

    '.........................09-may-18..................................

    Public Sub LoadColumnNameForSPMProcessData(ByVal CheckBoxListName As CheckBoxList, ByVal ColumnName As String)
        Dim query As String = ""
        'query = "select 'C00_COILER_SPEED_SET' as C1,'C00 Coiler Speed Set' as C2 union select 'C00_COILER_SPEED_ACT' as C1,'C00 Coiler Speed Act' as C2 union " & _
        '        "select 'S11_SPEED_SET' as C1,'S11 Speed Set' as C2 union select 'S11_SPEED_ACT' as C1,'S11 Speed Act' as C2 union select 'C90_COILER_SPEED_SET' as C1," & _
        '        "'C90 Coiler Speed Set' as C2 union select 'C90_COILER_SPEED_ACT' as C1,'C90 Coiler Speed Act' as C2 union select 'ENLONGATION_SET' as C1,'Enlongation Set' " & _
        '        "as C2 union select 'ENLONGATION_ACT' as C1,'Enlongation Act' as C2 union select 'ROLLFORCE' as C1,'Rollforce' as C2 union select 'ROLLFORCE_DS' as C1," & _
        '        "'Rollforce Ds' as C2 union select 'ROLLFORCE_OS' as C1,'Rollforce Os' as C2 union select 'WORK_ROLL_BEND_POS_SET' as C1,'Work Roll Bend Pos Set' as C2 " & _
        '        "union select 'WORK_ROLL_BEND_POS_ACT' as C1,'Work Roll Bend Pos Act' as C2 union select 'WORK_ROLL_BEND_NEG_SET' as C1,'Work Roll Bend Neg Set' as C2 " & _
        '        "union select 'WORK_ROLL_BEND_NEG_ACT' as C1,'Work Roll Bend Neg Act' as C2 union select 'ROLL_GAP_DS' as C1,'Roll Gap Ds' as C2 union select 'ROLL_GAP_OS'" & _
        '        "as C1,'Roll Gap Os' as C2 union select 'TENSION_POR_ENTRY_REF' as C1,'Tension Por Entry Ref' as C2 union select 'TENSION_POS_ENTRY' as C1,'Tension Pos Entry' as" & _
        '        "C2 union select 'TENSION_TR_REF' as C1,'Tension Tr Ref' as C2 union select 'TENSION_TR' as C1,'Tension Tr' as C2"
        query = "select 'C00_COILER_SPEED_ACT' as C1,'C00 Coiler Speed Act' as C2 union select 'S11_SPEED_ACT' as C1,'S11 Speed Act' as C2 union " &
                "select 'C90_COILER_SPEED_ACT' as C1,'C90 Coiler Speed Act' as C2 union select 'ENLONGATION_SET' as C1,'Enlongation Set' " &
              "as C2 union select 'ENLONGATION_ACT' as C1,'Enlongation Act' as C2 union select 'ROLLFORCE' as C1,'Roll Force' as C2 union select 'ROLLFORCE_DS' as C1," &
              "'Roll Force DS' as C2 union select 'ROLLFORCE_OS' as C1,'Roll Force OS' as C2 union select 'WORK_ROLL_BEND_POS_SET' as C1,'Work Roll Bend Pos Set' as C2 " &
              "union select 'WORK_ROLL_BEND_POS_ACT' as C1,'Work Roll Bend Pos Act' as C2 union select 'WORK_ROLL_BEND_NEG_SET' as C1,'Work Roll Bend Neg Set' as C2 " &
              "union select 'WORK_ROLL_BEND_NEG_ACT' as C1,'Work Roll Bend Neg Act' as C2 union select 'ROLL_GAP_DS' as C1,'Roll Gap DS' as C2 union select 'ROLL_GAP_OS'" &
              "as C1,'Roll Gap OS' as C2 union select 'TENSION_POR_ENTRY_REF' as C1,'Tension Por Entry Ref' as C2 union select 'TENSION_POS_ENTRY' as C1,'Tension Pos Entry' as" &
              "C2 union select 'TENSION_TR_REF' as C1,'Tension Tr Ref' as C2 union select 'TENSION_TR' as C1,'Tension Tr' as C2" &
              " union select 'RB' as C1,'RB' as C2 union select 'YS' as C1,'YS' as C2 union select 'UTS' as C1,'UTS' as C2  union select 'EL' as C1,'EL' as C2 union select 'RBAR' as C1,'RBAR' as C2 union select 'RA' as C1,'RA' as C2 ORDER BY C2"
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery(query).Tables(0)
        If dt.Rows.Count > 0 Then
            CheckBoxListName.DataSource = dt

            CheckBoxListName.DataTextField = "C2"
            CheckBoxListName.DataValueField = "C1"
            CheckBoxListName.DataBind()
            'For i As Integer = 0 To CheckBoxListName.Items.Count - 1
            '    If CheckBoxListName.Items(i).ToString() = ColumnName Then
            '        CheckBoxListName.Items(i).Value = True
            '    End If


            'Next


            'CheckBoxListName.Items.Insert(0, "All")
            'DropDownName.Items.Insert(0, "Select")
            'DropDownName.SelectedIndex = 0
        End If

    End Sub
    Public Function GetDataForSPM(ByVal TableName As String, ByVal FromDate As String, ByVal ToDate As String, ByVal DateColumn As String, ByVal ColumnName As String, ByVal Filter As String) As DataTable
        Dim query As String = ""
        query = "select COIL_STARTDATETIME," & ColumnName & ",DAUGHTER_COILID_NUM,THICKNESS,WIDTH from " & TableName & " where " & DateColumn & " between '" & FromDate & "' and '" & ToDate & "' and " & Filter & ""
        Return objDataHandler.GetDataSetFromQuery(query).Tables(0)
    End Function
    Public Sub PlotLineChartForSPM(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String, ByVal index As String)
        Try

            LiteralName.Text = ""
            Dim min_time, max_time As String
            min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-30), "yyyy-MM-dd HH:mm")
            max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm")

            'Dim xTimestampVal(), yVal() As String
            Dim yVal() As Decimal

            'xTimestampVal = (From row In dt Select col = row(XAxisColName).ToString).ToArray
            yVal = (From row In dt Select col = CDec(IIf(IsDBNull(row(YAxisColName)), 0, row(YAxisColName))) Where col > 0).ToArray()

            'Dim y_min As String = yVal.Min()
            'Dim y_max As String = yVal.Max()
            Dim y_min As String = yVal.Min() - (10 / 100 * yVal.Min)
            Dim y_max As String = yVal.Max() + (10 / 100 * yVal.Max)

            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf
            js &= "var line" & index & " = ["
            For j As Integer = 0 To dt.Rows.Count - 1
                If j > 0 Then
                    js &= ","
                End If
                js &= "["
                Dim dtTime As DateTime = dt.Rows(j)(XAxisColName)

                If IsDBNull(dt.Rows(j)(YAxisColName)) = False Then
                    js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dt.Rows(j)(YAxisColName) & ", '" & dt.Rows(j)("DAUGHTER_COILID_NUM") & "'"
                End If
                js &= "]"
            Next

            js &= "];" & vbCrLf
            'Dim strg As String = ""
            'Dim strseries As String = ""
            'If flag Then
            '    strg = "[line1"
            '    strseries = " {showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"

            '    strg &= "]"
            'End If
            'js &= "var seriesName = ['"
            'Dim str As String = ""
            'For i As Integer = 0 To dtGroups.Rows.Count - 1
            '    str &= dtGroups.Rows(i)(0).ToString().Trim() + "', '"
            'Next
            'str = str.Remove(str.LastIndexOf(", '"))
            'str &= "];"
            'js &= str
            js &= "opts = {" & vbCrLf &
            "title: '" & ChartTitle & "'," & vbCrLf &
            "seriesDefaults: { showMarker:true,lineWidth: 2,markerOptions: {size: 5}, pointLabels: { show:false },color: '#4832DB', highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}," &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            "fontSize:'8pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf &
            "renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
            "tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," & vbCrLf &
            "//tickInterval:'1 hour'," & vbCrLf &
            "pad:0" & vbCrLf &
            "}," & vbCrLf &
            "yaxis: { " & vbCrLf &
            "tickOptions: { formatString: '%12.5f' }," & vbCrLf &
            "min: " & y_min & "," & vbCrLf &
            "max: " & y_max & "," & vbCrLf &
            "autoscale:true," & vbCrLf &
            "label: '" & YAxisLabelName & "'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "showTooltip: false," & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "animate: true," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)'}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "',[line" & index & "],opts);" & vbCrLf &
            "</script>" & vbCrLf

            LiteralName.Text = js
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub
    Public Sub PlotLineChartForBathManagement_Modified(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String, ByVal GroupByColName As String, Optional ByVal selection As String = "", Optional ByVal selectionLegend As String = "")
        Try
            'For i As Integer = 0 To dt.Rows.Count - 1
            '    If IsDBNull(dt.Rows(i)("LTRI_PARA_MIN")) Then
            '        dt.Rows(i)("LTRI_PARA_MIN") = dt.Rows(i)("LTRI_PARA_MIN").ToString().Replace(vbNull, vbDecimal)
            '    End If
            'Next
            LiteralName.Text = ""
            Dim min_time, max_time As String
            min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-30), "yyyy-MM-dd HH:mm")
            max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm")

            Dim arrSeriesColor() As String = {"#89cff0", "#4682b4", "#000080", "#f00699", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000"}
            Dim seriesColor As String = "['"
            'Dim xTimestampVal(), yVal() As String
            Dim yVal(), y2Val() As Decimal

            'xTimestampVal = (From row In dt Select col = row(XAxisColName).ToString).ToArray
            yVal = (From row In dt Select col = CDec(row(YAxisColName))).ToArray()
            y2Val = (From row In dt Select col = CDec(row(selection))).ToArray()

            'Dim y_min As String = yVal.Min()
            'Dim y_max As String = yVal.Max()
            Dim y_min As String = 445 ' yVal.Min() - (10 / 100 * yVal.Min)
            Dim y_max As String = 485 ' yVal.Max() + (10 / 100 * yVal.Max)


            Dim y2_min As String = y2Val.Min - (0.1 * y2Val.Min)
            Dim y2_max As String = y2Val.Max + (0.1 * y2Val.Max)


            If selectionLegend = "P3" Or selectionLegend = "P4" Then
                y_min = y2_min
                y_max = y2_max
            End If

            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf
            dt.DefaultView.RowFilter = ""
            'Dim dtGrades As DataTable = dt.DefaultView.ToTable(True, GroupByColName) 'All distinct Grades
            Dim dtGrades As New DataTable
            dtGrades.Columns.Add("PRM_SEC1_COIL", GetType(Integer))
            dtGrades.Rows.Add(1)
            dtGrades.Rows.Add(2)
            dtGrades.Rows.Add(3)
            dtGrades.Rows.Add(4)

            Dim dvDefault As DataView = dt.DefaultView
            Dim flag As Boolean = False
            For i As Integer = 0 To dtGrades.Rows.Count - 1
                js &= "var line" & (i + 1).ToString & " = ["
                dvDefault.RowFilter = "" & GroupByColName & "='" & dtGrades.Rows(i)(0) & "'"

                For j As Integer = 0 To dvDefault.Count - 1
                    If j > 0 Then
                        js &= ","
                    End If
                    js &= "["
                    Dim dtTime As DateTime = dvDefault.Item(j)(XAxisColName)
                    If IsDBNull(dvDefault.Item(j)(GroupByColName)) Then
                        If IsDBNull(dvDefault.Item(j)(YAxisColName)) = False Then
                            js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)(YAxisColName) & ", " & "null"
                        Else
                            js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & "null, null"
                        End If
                    Else
                        If IsDBNull(dvDefault.Item(j)(YAxisColName)) = False Then
                            js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)(YAxisColName) & ", '(" & dvDefault.Item(j)(GroupByColName).ToString().Trim & ")'"
                            'js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)("CLR_TEST_VALUE") & ", 'Pot'"
                        End If
                    End If
                    js &= "]"
                Next
                js &= "];" & vbCrLf
                flag = True
                If i > 0 Then

                    seriesColor &= ", '"
                End If
                seriesColor &= arrSeriesColor(i) & "'"
            Next

            'for y2axis
            js &= "var liney2axis=["
            For row As Integer = 0 To dt.Rows.Count - 1
                If row > 0 Then
                    js &= ","
                End If
                If IsDBNull(dt.Rows(row)(selection)) = False Then
                    js &= "['" & CDate(dt.Rows(row)(XAxisColName)).ToString("yyyy-MM-dd HH:mm") & "'," & dt.Rows(row)(selection) & "]"
                Else
                    js &= "['" & CDate(dt.Rows(row)(XAxisColName)).ToString("yyyy-MM-dd HH:mm") & "',null]"
                End If

            Next
            js &= "];" & vbCrLf

            seriesColor &= ",'" & arrSeriesColor(4) & "'"   'for y2axis

            Dim strg As String = ""
            Dim strseries As String = ""
            If flag Then
                strg = "[line1"
                strseries = " {pointLabels: { show:false }, showLine:false, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
                For i As Integer = 1 To dtGrades.Rows.Count - 1
                    strg = strg + ",line" & i + 1
                    strseries = strseries + ", {pointLabels: { show:false }, showLine:false, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
                Next
                strg &= ",liney2axis]" 'for y2axis
                strseries = strseries + ",{pointLabels: { show:false }, yaxis:'y2axis', showLine:false, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
            End If
            js &= "var seriesName = ['"
            Dim str As String = ""
            For i As Integer = 0 To dtGrades.Rows.Count - 1
                str &= dtGrades.Rows(i)(0).ToString().Trim() + "', '"
            Next
            seriesColor &= "]"
            str = str.Remove(str.LastIndexOf(", '"))
            str &= "];"
            js &= str
            js &= "opts = {" & vbCrLf &
            "title: '" & ChartTitle & "'," & vbCrLf &
            "series:[" & strseries & "]," & vbCrLf &
             "seriesColors: " & seriesColor & "," & vbCrLf &
            "//seriesColors: ['#FFA500']," & vbCrLf &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            "fontSize:'8pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf &
            "renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
            "tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," & vbCrLf &
            "//tickInterval:'1 hour'," & vbCrLf &
            "pad:0" & vbCrLf &
            "},y2axis:{tickOptions: { formatString: '%.3f' },min:" & y2_min & ",max:" & y2_max & ",numberTicks: 6,labelRenderer: $.jqplot.CanvasAxisLabelRenderer}," & vbCrLf &
            "yaxis: { " & vbCrLf &
            "tickOptions: { formatString: '%.3f' }," & vbCrLf &
            "min: " & y_min & "," & vbCrLf &
            "max: " & y_max & "," & vbCrLf &
            "autoscale:true," & vbCrLf &
            "//label: '" & YAxisLabelName & "'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "showTooltip: false," & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "animate: true," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
            " canvasOverlay: { show: true,objects: [{horizontalLine: {name: 'UCL',y: 464,lineWidth: 2,color: 'rgb(255, 0, 0)', shadow: false}},{horizontalLine: {name: 'LCL',y: 456,lineWidth: 2,color: 'rgb(255, 0, 0)', shadow: false}},{dashedHorizontalLine: {name: 'Aim', y:460, lineWidth:2, color:'rgb(133, 120, 24)',shadow: false}}]}," & vbCrLf &
            "legend: {" & vbCrLf &
            "show: true," & vbCrLf &
            "location: 's'," & vbCrLf &
            "labels: ['<0.8','<1.2','<1.6','>1.6','" & selectionLegend & "']," & vbCrLf &
            "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
            "placement: 'outsideGrid'," & vbCrLf &
            "rendererOptions: {" & vbCrLf &
            "numberRows: 1," & vbCrLf &
            "marginTop: 10" & vbCrLf &
            "}" & vbCrLf &
            "}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "', " & strg & ", opts);</script>" & vbCrLf
            ' "plot6 = $.jqplot('chartPot'," & strg & ",opts);</script>" & vbCrLf

            LiteralName.Text = js
        Catch ex As Exception

        End Try
    End Sub
    Public Sub PlotLineChartForBathManagement(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String, ByVal index As String)
        Try

            LiteralName.Text = ""
            Dim min_time, max_time As String
            min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-30), "yyyy-MM-dd HH:mm")
            max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm")

            'Dim xTimestampVal(), yVal() As String
            Dim yVal() As Decimal

            'xTimestampVal = (From row In dt Select col = row(XAxisColName).ToString).ToArray
            yVal = (From row In dt Select col = CDec(IIf(IsDBNull(row(YAxisColName)), 0, row(YAxisColName))) Where col > 0).ToArray()

            'Dim y_min As String = yVal.Min()
            'Dim y_max As String = yVal.Max()
            Dim y_min As String = 445 ' yVal.Min() - (10 / 100 * yVal.Min)
            Dim y_max As String = 485 ' yVal.Max() + (10 / 100 * yVal.Max)

            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf
            js &= "var line" & index & " = ["
            For j As Integer = 0 To dt.Rows.Count - 1
                If j > 0 Then
                    js &= ","
                End If
                js &= "["
                Dim dtTime As DateTime = dt.Rows(j)(XAxisColName)

                If IsDBNull(dt.Rows(j)(YAxisColName)) = False Then
                    js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dt.Rows(j)(YAxisColName) & ""
                End If
                js &= "]"
            Next

            js &= "];" & vbCrLf
            'Dim strg As String = ""
            'Dim strseries As String = ""
            'If flag Then
            '    strg = "[line1"
            '    strseries = " {showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"

            '    strg &= "]"
            'End If
            'js &= "var seriesName = ['"
            'Dim str As String = ""
            'For i As Integer = 0 To dtGroups.Rows.Count - 1
            '    str &= dtGroups.Rows(i)(0).ToString().Trim() + "', '"
            'Next
            'str = str.Remove(str.LastIndexOf(", '"))
            'str &= "];"
            'js &= str
            js &= "opts = {" & vbCrLf &
            "title: '" & ChartTitle & "'," & vbCrLf &
            "seriesDefaults: { showMarker:false,lineWidth: 2,markerOptions: {size: 5}, pointLabels: { show:false },color: '#4832DB', highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}," &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            "fontSize:'8pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf &
            "renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
            "tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," & vbCrLf &
            "//tickInterval:'1 hour'," & vbCrLf &
            "pad:0" & vbCrLf &
            "}," & vbCrLf &
            "yaxis: { " & vbCrLf &
            "tickOptions: { formatString: '%12d' }," & vbCrLf &
            "min: " & y_min & "," & vbCrLf &
            "max: " & y_max & "," & vbCrLf &
            "tickInterval:5," & vbCrLf &
            "label: '" & YAxisLabelName & "'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "showTooltip: false," & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "animate: true," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)'}" & vbCrLf &
            ", canvasOverlay: { show: true,objects: [{horizontalLine: {name: 'UCL',y: 464,lineWidth: 2,color: 'rgb(255, 0, 0)', shadow: false}},{horizontalLine: {name: 'LCL',y: 456,lineWidth: 2,color: 'rgb(255, 0, 0)', shadow: false}},{dashedHorizontalLine: {name: 'Aim', y:460, lineWidth:2, color:'rgb(133, 120, 24)',shadow: false}}]}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "',[line" & index & "],opts);" & vbCrLf &
            "</script>" & vbCrLf

            LiteralName.Text = js
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub

    Public Function IsAValidUser(ByVal Username As String, ByVal Password As String) As Boolean
        Try
            'Return objDataHandler.CheckRecordsIn("USER_DETAILS", "USERNAME", "USERNAME||PASSWORD='" & Username & Password & "'")
            Return objDataHandler.CheckRecordsIn("USER_DETAILS", "USERNAME", "USERNAME ='" & Username & "' and PASSWORD='" & Password & "'")
            'Return objDBTool.CheckRecordsIn("T_LPDS_USER_DTLS", "LUD_USER_ID", "LUD_USER_ID||LUD_PASSWORD||LUD_TYPE||LUD_MANF_ID='" & Username & Password & UserType & MfgId & "'")
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

    End Function

    Public Function SavePotDetails(ByVal PotNo As String, ByVal FromDate As String, ByVal ToDate As String, ByVal ChangedBy As String) As Integer
        Try
            Dim query = ""
            If ToDate Is Nothing Then
                query = "insert into CGL2_POT_INFO (POT_NO,FROM_DATE,TO_DATE,CHANGED_BY,CHANGED_ON) values('" & PotNo & "','" & FromDate & "',NULL,'" & ChangedBy & "','" & Now.ToString("dd-MMM-yy hh:mm:ss tt") & "'); " & vbCrLf
            Else
                query = "update CGL2_POT_INFO set TO_DATE='" & ToDate & "',changed_by='" & ChangedBy & "',changed_on='" & Now.ToString("dd-MMM-yy hh:mm:ss tt") & "' where to_date is null and pot_no='" & PotNo & "'"
                'query = "insert into CGL2_POT_INFO (POT_NO,FROM_DATE,TO_DATE,CHANGED_BY,CHANGED_ON) values('" & PotNo & "','" & FromDate & "','" & ToDate & "','" & ChangedBy & "','" & Now.ToString("dd-MMM-yy hh:mm:ss tt") & "'); " & vbCrLf
            End If

            Return objDataHandler.RunSimpleQuery(query)
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

    End Function

    Public Function getPotString(ByVal fromDate As String, ByVal toDate As String) As String
        Dim dt As DataTable = getPotData(fromDate, toDate)
        dt.Columns.Add("cwt", GetType(String))
        For row As Integer = 0 To dt.Rows.Count - 1
            Dim s1 As String = ""
            Dim dtTemp As DataTable = objDataHandler.GetDataSetFromQuery("select PRM_CD_SURF_ROUGH,PRM_MS_COIL_ACTL/1000 from T_CGL_FUR_PARAM where prm_ts_end between '" & CDate(dt.Rows(row)(1)).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & CDate(dt.Rows(row)(2)).ToString("yyyy-MM-dd HH:mm:ss") & "'").Tables(0)
            Dim camp As String = ""
            Dim prevcamp As String = ""
            Dim sum As Double = 0.0
            For r As Integer = 0 To dtTemp.Rows.Count - 1
                If r = 0 Then
                    camp = dtTemp.Rows(r)(0)
                    prevcamp = dtTemp.Rows(r)(0)
                End If

label1:
                If dtTemp.Rows(r)(0) = camp Then
                    sum += dtTemp.Rows(r)(1)
                Else
                    'skip 4 campains
                    Dim idx As Integer = r
                    If dtTemp.Rows.Count - r > 4 Then
                        Dim newcamp As String = dtTemp.Rows(r)(0)
                        Dim newsum As Double = 0
                        Dim cnt As Integer = 0
                        For n = r To dtTemp.Rows.Count - 1
                            If newcamp = dtTemp.Rows(n)(0) Then
                                newsum += dtTemp.Rows(r)(1)
                                cnt += 1
                                If cnt > 4 Then

                                    prevcamp = camp
                                    camp = newcamp
                                    r = r - 1
                                    Exit For
                                End If
                            Else
                                sum = sum + newsum
                                prevcamp = camp
                                r = n
                                GoTo label1
                            End If
                        Next
                    Else
                        prevcamp = camp
                    End If

                    'end of skip 4 campains
                    If sum > 0 Then
                        s1 &= "\ <tr><td>" & IIf(prevcamp = "A", "GA", "ZS") & ": " & Math.Ceiling(sum) & " T</td></tr>"
                        sum = 0.0
                        ' camp = dtTemp.Rows(r)(0)
                    End If
                End If
            Next
            If sum > 0 Then
                s1 &= "\ <tr><td>" & IIf(camp = "A", "GA", "ZS") & ": " & Math.Ceiling(sum) & " T</td></tr>"
            End If

            'For c As Integer = 0 To dtTemp.Rows.Count - 1
            '    s1 &= "\ <tr><td>" & IIf(dtTemp.Rows(c)(0) = "A", "GA", "ZS") & ": " & dtTemp.Rows(c)(1) & " T</td></tr>"
            'Next
            dt.Rows(row)("cwt") = s1
        Next
        Dim s As New StringBuilder("")
        s.Append("<script>$(function () {var overlayObjects = [")
        For row As Integer = 0 To dt.Rows.Count - 1
            If row > 0 Then
                s.Append(",")
            End If
            If (dt.Rows(row)("POT_NO") = "POT1") Then
                's.Append("{rectangle: {xmin: new Date(""" & DateTime.Parse(dt.Rows(row)("FROM_DATE")).ToString("dd-MMM-yyyy HH:mm:ss") & """), xmax: new Date(""" & DateTime.Parse(dt.Rows(row)("TO_DATE")).ToString("dd-MMM-yyyy HH:mm:ss") & """),ymin: 0.370, ymax: 0.400,xminOffset: ""0px"", xmaxOffset: ""0px"", yminOffset: ""0px"", ymaxOffset: ""0px"",color: ""rgba(255, 192, 0, 0.5)"", showTooltip: true, tooltipFormatString: ""POT1: " & dt.Rows(row)("tonnage") & " T, " & DateTime.Parse(dt.Rows(row)("FROM_DATE")).ToString("dd-MMM-yyyy HH:mm:ss") & """}}")
                s.Append("{rectangle: {xmin: new Date(""" & DateTime.Parse(dt.Rows(row)("FROM_DATE")).ToString("dd-MMM-yyyy HH:mm:ss") & """), xmax: new Date(""" & DateTime.Parse(dt.Rows(row)("TO_DATE")).ToString("dd-MMM-yyyy HH:mm:ss") & """),ymin: 0.370, ymax: 0.400,xminOffset: ""0px"", xmaxOffset: ""0px"", yminOffset: ""0px"", ymaxOffset: ""0px"",color: ""rgba(255, 192, 0, 0.5)"",tooltipLocation:""se"",tooltipOffset : 30, showTooltip: true,tooltipFormatString: '<table style=""height:80px; width:180px;background-color:#FCDF7F; border-color: #FCDF7F;  font-weight:bold; font-size:large; color:black;font-size:small; border-radius: 15px;"" class=""jqplot-highlighter""> \ <tr><td>POT1: " & dt.Rows(row)("tonnage") & " T</td></tr>" & dt.Rows(row)("cwt") & "\ <tr><td>" & DateTime.Parse(dt.Rows(row)("FROM_DATE")).ToString("dd-MMM-yyyy HH:mm") & "</td></tr></table>'}}")
            ElseIf (dt.Rows(row)("POT_NO") = "POT2") Then
                's.Append("{rectangle: {xmin: new Date(""" & DateTime.Parse(dt.Rows(row)("FROM_DATE")).ToString("dd-MMM-yyyy HH:mm:ss") & """), xmax: new Date(""" & DateTime.Parse(dt.Rows(row)("TO_DATE")).ToString("dd-MMM-yyyy HH:mm:ss") & """),ymin: 0.370, ymax: 0.400,xminOffset: ""0px"", xmaxOffset: ""0px"", yminOffset: ""0px"", ymaxOffset: ""0px"",color: ""rgba(146, 208, 80, 0.5)"", showTooltip: true, tooltipFormatString: ""POT2: " & dt.Rows(row)("tonnage") & " T, " & DateTime.Parse(dt.Rows(row)("FROM_DATE")).ToString("dd-MMM-yyyy HH:mm:ss") & """}}")
                s.Append("{rectangle: {xmin: new Date(""" & DateTime.Parse(dt.Rows(row)("FROM_DATE")).ToString("dd-MMM-yyyy HH:mm:ss") & """), xmax: new Date(""" & DateTime.Parse(dt.Rows(row)("TO_DATE")).ToString("dd-MMM-yyyy HH:mm:ss") & """),ymin: 0.370, ymax: 0.400,xminOffset: ""0px"", xmaxOffset: ""0px"", yminOffset: ""0px"", ymaxOffset: ""0px"",color: ""rgba(146, 208, 80, 0.5)"",tooltipLocation:""se"",tooltipOffset :30, showTooltip: true, tooltipFormatString: '<table style=""height:80px; width:180px;background-color:#CBE7A2; border-color: #CBE7A2; font-weight:bold; font-size:large; color:black;font-size:small; border-radius: 15px;"" class=""jqplot-highlighter""> \ <tr><td>POT2: " & dt.Rows(row)("tonnage") & " T</td></tr>" & dt.Rows(row)("cwt") & "\ <tr><td>" & DateTime.Parse(dt.Rows(row)("FROM_DATE")).ToString("dd-MMM-yyyy HH:mm") & "</td></tr></table>'}}")
            End If


        Next
        s.Append("];plot1.plugins.canvasOverlay = new $.jqplot.CanvasOverlay({show: true,objects: overlayObjects});plot1.replot();});</script>")
        Return s.ToString
    End Function

    Public Function getPotStringOverlayForPotTemp(ByVal fromDate As String, ByVal toDate As String, ByVal ymin As Double, ByVal ymax As Double) As String

        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select grp,prm_cd_surf_rough,min(prm_ts_end) as mindate,max(prm_ts_end) as maxdate from (" &
  " select prm_ts_end,prm_cd_surf_rough,row_number() OVER (order by prm_ts_end)-row_number() over (partition by prm_cd_surf_rough order by prm_ts_end) as grp" &
  " FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where prm_ts_end between '" & fromDate & "' and '" & toDate & "' " &
  ") T group by prm_cd_surf_rough,grp order by 3").Tables(0)

        Dim dtGrade As DataTable = objDataHandler.GetDataSetFromQuery("select grp,prm_cd_grade,min(prm_ts_end) as mindate,max(prm_ts_end) as maxdate from (" &
  " select prm_ts_end,prm_cd_grade,row_number() OVER (order by prm_ts_end)-row_number() over (partition by prm_cd_grade order by prm_ts_end) as grp" &
  " FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where prm_ts_end between '" & fromDate & "' and '" & toDate & "' " &
  ") T group by prm_cd_grade,grp order by 3").Tables(0)

        Dim s As New StringBuilder("")
        s.Append("<script>var overlayObjectsPotTemp = [")
        Dim booldata As Boolean = False
        For row As Integer = 0 To dt.Rows.Count - 1
            If row > 0 Then
                s.Append(",")
            End If
            If (dt.Rows(row)("prm_cd_surf_rough") = "A") Then
                's.Append("{rectangle: {xmin: new Date(""" & DateTime.Parse(dt.Rows(row)("FROM_DATE")).ToString("dd-MMM-yyyy HH:mm:ss") & """), xmax: new Date(""" & DateTime.Parse(dt.Rows(row)("TO_DATE")).ToString("dd-MMM-yyyy HH:mm:ss") & """),ymin: 0.370, ymax: 0.400,xminOffset: ""0px"", xmaxOffset: ""0px"", yminOffset: ""0px"", ymaxOffset: ""0px"",color: ""rgba(255, 192, 0, 0.5)"", showTooltip: true, tooltipFormatString: ""POT1: " & dt.Rows(row)("tonnage") & " T, " & DateTime.Parse(dt.Rows(row)("FROM_DATE")).ToString("dd-MMM-yyyy HH:mm:ss") & """}}")
                s.Append("{rectangle: {xmin: new Date(""" & DateTime.Parse(dt.Rows(row)("mindate")).ToString("dd-MMM-yyyy HH:mm:ss") & """), xmax: new Date(""" & DateTime.Parse(dt.Rows(row)("maxdate")).ToString("dd-MMM-yyyy HH:mm:ss") & """),ymin: 482, ymax: 485,xminOffset: ""0px"", xmaxOffset: ""0px"", yminOffset: ""0px"", ymaxOffset: ""0px"",color: ""rgba(255, 192, 0, 0.5)"",tooltipLocation:""se"",tooltipOffset : 30, showTooltip: true,tooltipFormatString: '<table style=""height:40px; width:180px;background-color:#FCDF7F; border-color: #FCDF7F;  font-weight:bold; font-size:large; color:black;font-size:small; border-radius: 15px;"" class=""jqplot-highlighter""> \ <tr><td>Campaign: " & dt.Rows(row)("prm_cd_surf_rough") & "</td></tr></table>'}}")
            ElseIf (dt.Rows(row)("prm_cd_surf_rough") = "Z") Then
                's.Append("{rectangle: {xmin: new Date(""" & DateTime.Parse(dt.Rows(row)("FROM_DATE")).ToString("dd-MMM-yyyy HH:mm:ss") & """), xmax: new Date(""" & DateTime.Parse(dt.Rows(row)("TO_DATE")).ToString("dd-MMM-yyyy HH:mm:ss") & """),ymin: 0.370, ymax: 0.400,xminOffset: ""0px"", xmaxOffset: ""0px"", yminOffset: ""0px"", ymaxOffset: ""0px"",color: ""rgba(146, 208, 80, 0.5)"", showTooltip: true, tooltipFormatString: ""POT2: " & dt.Rows(row)("tonnage") & " T, " & DateTime.Parse(dt.Rows(row)("FROM_DATE")).ToString("dd-MMM-yyyy HH:mm:ss") & """}}")
                s.Append("{rectangle: {xmin: new Date(""" & DateTime.Parse(dt.Rows(row)("mindate")).ToString("dd-MMM-yyyy HH:mm:ss") & """), xmax: new Date(""" & DateTime.Parse(dt.Rows(row)("maxdate")).ToString("dd-MMM-yyyy HH:mm:ss") & """),ymin: 482, ymax: 485,xminOffset: ""0px"", xmaxOffset: ""0px"", yminOffset: ""0px"", ymaxOffset: ""0px"",color: ""rgba(146, 208, 80, 0.5)"",tooltipLocation:""se"",tooltipOffset :30, showTooltip: true, tooltipFormatString: '<table style=""height:40px; width:180px;background-color:#CBE7A2; border-color: #CBE7A2; font-weight:bold; font-size:large; color:black;font-size:small; border-radius: 15px;"" class=""jqplot-highlighter""> \ <tr><td>Campaign: " & dt.Rows(row)("prm_cd_surf_rough") & "</td></tr></table>'}}")
            End If

            booldata = True
        Next

        For row As Integer = 0 To dtGrade.Rows.Count - 1
            If booldata Then s.Append(",")
            If row > 0 Then
                s.Append(",")
            End If
            Dim c As String = "rgba(72, 169, 166, 0.8)"   ', "", "", "
            If dtGrade.Rows(row)("prm_cd_grade") = "EIF" Or dtGrade.Rows(row)("prm_cd_grade") = "HIF" Then
                c = "rgba(16, 57, 0, 0.5)"
            ElseIf dtGrade.Rows(row)("prm_cd_grade") = "CQ" Or dtGrade.Rows(row)("prm_cd_grade") = "DQ" Then
                c = "rgba(163, 50, 11, 0.5)"
            ElseIf dtGrade.Rows(row)("prm_cd_grade") = "HSQ" Then
                c = "rgba(230, 175, 46, 0.5)"
            End If
            s.Append("{rectangle: {xmin: new Date(""" & DateTime.Parse(dtGrade.Rows(row)("mindate")).ToString("dd-MMM-yyyy HH:mm:ss") & """), xmax: new Date(""" & DateTime.Parse(dtGrade.Rows(row)("maxdate")).ToString("dd-MMM-yyyy HH:mm:ss") & """),ymin: 445, ymax: 448,xminOffset: ""0px"", xmaxOffset: ""0px"", yminOffset: ""0px"", ymaxOffset: ""0px"",color: """ & c & """,tooltipLocation:""se"",tooltipOffset : 30, showTooltip: true,tooltipFormatString: '<table style=""height:40px; width:180px;background-color:#FCDF7F; border-color: #FCDF7F;  font-weight:bold; font-size:large; color:black;font-size:small; border-radius: 15px;"" class=""jqplot-highlighter""> \ <tr><td>Grade: " & dtGrade.Rows(row)("prm_cd_grade") & " </td></tr></table>'}}")
        Next
        s.Append("];</script>")
        Return s.ToString
    End Function

    Public Function GetPotTempData_Modified(ByVal fromDate As String, ByVal toDate As String) As DataTable
        Try
            Dim query = "SELECT PRM_TS_END,PRM_ZINC_POT_TMP,CASE WHEN PRM_SEC1_COIL<0.8 THEN 1 WHEN PRM_SEC1_COIL<1.2 THEN 2 WHEN PRM_SEC1_COIL<1.6 THEN 3 ELSE 4 END AS PRM_SEC1_COIL,PRM_RCF_STRP_TMP,PRM_SNT_STRP_TMP,PRM_SEC1_COIL*PRM_SEC2_COIL AS TW,PRM_TPOH_ACTL FROM T_CGL_FUR_PARAM WHERE PRM_TS_END BETWEEN '" & fromDate & "' AND '" & toDate & "' and PRM_ZINC_POT_TMP is not null ORDER BY PRM_TS_END"
            Dim dt As New DataTable
            dt = objDataHandler.GetDataSetFromQuery(query).Tables(0)
            Return dt
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Function

    Public Function GetPotTempData(ByVal fromDate As String, ByVal toDate As String) As DataTable
        Try
            Dim query = "SELECT PRM_TS_END,PRM_ZINC_POT_TMP,PRM_SEC1_COIL FROM T_CGL_FUR_PARAM WHERE PRM_TS_END BETWEEN '" & fromDate & "' AND '" & toDate & "' and PRM_ZINC_POT_TMP is not null ORDER BY PRM_TS_END"
            Dim dt As New DataTable
            dt = objDataHandler.GetDataSetFromQuery(query).Tables(0)
            Return dt
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Function

    Public Function getPotData(ByVal fromDate As String, ByVal toDate As String) As DataTable
        Try
            Dim dt As New DataTable
            Dim query = "SELECT [POT_NO],[FROM_DATE],ISNULL([TO_DATE],'" & toDate & "') AS [TO_DATE],(select CEILING(ROUND(sum(PRM_MS_COIL_ACTL)/1000,0)) from  [T_CGL_FUR_PARAM] where PRM_TS_END between t2.from_date and ISNULL(t2.[TO_DATE],'" & toDate & "') ) as tonnage FROM [CGL2_POT_INFO] t2 where from_date >= '" & fromDate & "' and ISNULL([TO_DATE],'" & toDate & "')<= '" & toDate & "' order by FROM_DATE"
            dt = objDataHandler.GetDataSetFromQuery(query).Tables(0)
            For rows As Integer = dt.Rows.Count - 1 To 0 Step -1
                If CDate(dt.Rows(rows)(1)) > CDate(dt.Rows(rows)(2)) Then
                    dt.Rows.RemoveAt(rows)
                End If
            Next
            If dt.Rows.Count > 0 Then
                Dim from_date As DateTime = dt.Rows(dt.Rows.Count - 1)(1)
                Dim to_date As DateTime = dt.Rows(dt.Rows.Count - 1)(2)
                'upper 
                query = "SELECT * FROM  [CGL2_POT_INFO] WHERE FROM_DATE < '" & DateTime.Parse(dt.Rows(0)(1)).ToString("yyyy-MM-dd HH:mm:ss") & "' order by from_date desc"
                Dim dtTemp1 As DataTable = objDataHandler.GetDataSetFromQuery(query).Tables(0)
                If dtTemp1.Rows.Count > 0 Then
                    If dtTemp1.Rows(0)(2) > DateTime.Parse(fromDate) Then
                        Dim potNo As String = dtTemp1.Rows(0)(0)
                        query = "select CEILING(ROUND(sum(PRM_MS_COIL_ACTL)/1000,0)) from  [T_CGL_FUR_PARAM] where PRM_TS_END between '" & fromDate & "' and '" & DateTime.Parse(dt.Rows(0)(1)).ToString("yyyy-MM-dd HH:mm:ss") & "'"
                        Dim wt As Double = objDataHandler.GetDataSetFromQuery(query).Tables(0).Rows(0)(0)
                        dt.Rows.Add(potNo, DateTime.Parse(fromDate), DateTime.Parse(dt.Rows(0)(1)), wt)
                        dt.AcceptChanges()
                    End If
                End If
                'end of upper


                'lower
                query = "SELECT * FROM  [CGL2_POT_INFO] WHERE FROM_DATE >= '" & to_date.ToString("yyyy-MM-dd HH:mm:ss") & "' order by from_date"
                Dim dtTemp As DataTable = objDataHandler.GetDataSetFromQuery(query).Tables(0)
                If dtTemp.Rows.Count > 0 Then 'we are interested in first row only
                    If dtTemp.Rows(0)(1) < DateTime.Parse(toDate) Then
                        Dim potNo As String = dtTemp.Rows(0)(0)
                        from_date = dtTemp.Rows(0)(1)
                        to_date = DateTime.Parse(toDate)
                        query = "select CEILING(ROUND(sum(PRM_MS_COIL_ACTL)/1000,0)) from  [T_CGL_FUR_PARAM] where PRM_TS_END between '" & from_date.ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & to_date.ToString("yyyy-MM-dd HH:mm:ss") & "'"
                        Dim wt As Double = objDataHandler.GetDataSetFromQuery(query).Tables(0).Rows(0)(0)
                        dt.Rows.Add(potNo, DateTime.Parse(from_date), DateTime.Parse(to_date), wt)
                        dt.AcceptChanges()
                    End If

                End If
                'end of lower
            Else
                query = "SELECT TOP 1 [POT_NO],FROM_DATE,isnull(to_date,'" & toDate & "') as TO_DATE FROM  [CGL2_POT_INFO] WHERE FROM_DATE < '" & fromDate & "' order by from_date desc"
                dt = objDataHandler.GetDataSetFromQuery(query).Tables(0)
                If dt.Rows.Count > 0 Then
                    If DateTime.Parse(dt.Rows(0)("to_date")).Equals(DateTime.Parse(toDate)) Then
                        query = "select CEILING(ROUND(sum(PRM_MS_COIL_ACTL)/1000,0))  as tonnage from  [T_CGL_FUR_PARAM] where PRM_TS_END between '" & fromDate & "' and '" & toDate & "'"
                    Else
                        query = "select CEILING(ROUND(sum(PRM_MS_COIL_ACTL)/1000,0))  as tonnage from  [T_CGL_FUR_PARAM] where PRM_TS_END between '" & fromDate & "' and '" & DateTime.Parse(dt.Rows(0)("to_date")).ToString("yyyy-MM-dd HH:mm:ss") & "'"
                    End If

                    Dim tonnage As Double = objDataHandler.GetDataSetFromQuery(query).Tables(0).Rows(0)(0)
                    dt.Columns.Add("tonnage", GetType(Double))
                    dt.Rows(0)("tonnage") = tonnage
                    dt.Rows(0)("from_date") = DateTime.Parse(fromDate)
                    dt.AcceptChanges()
                End If
            End If
            Return dt
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Function

    Public Function getLastPotData() As DataTable
        Try
            Dim query = "SELECT top 1 * from CGL2_POT_INFO order by from_date desc"
            Return objDataHandler.GetDataSetFromQuery(query).Tables(0)
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Function
    Public Sub PopulateGradeForPLTCM(ByVal GradeDropDown As DropDownList, ByVal FromDate As String, ByVal ToDate As String)
        Try
            GradeDropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct GRADE from CRM_SPM_PROCESS_DATA_COILWISE_BODY where COIL_STARTDATETIME between '" & FromDate & "' and '" & ToDate & "' and (GRADE <> '0' and GRADE is not null) ORDER BY GRADE").Tables(0)
            GradeDropDown.DataTextField = "GRADE"
            GradeDropDown.DataValueField = "GRADE"
            GradeDropDown.DataBind()
            GradeDropDown.Items.Insert(0, "All")
            GradeDropDown.SelectedIndex = 0
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try


    End Sub
    Public Sub PopulateThicknessForSPM(ByVal ThicknessDropDown As DropDownList, ByVal FromDate As String, ByVal ToDate As String, ByVal Grade As String)
        Try
            Dim filter As String = ""
            If Grade.ToLower <> "all" Then
                If Grade <> "" Then
                    filter &= " and GRADE = '" & Grade & "'"
                End If

            End If
            ThicknessDropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct THICKNESS from CRM_SPM_PROCESS_DATA_COILWISE_BODY where COIL_STARTDATETIME between '" & FromDate & "' and '" & ToDate & "' " & filter & " ORDER BY THICKNESS").Tables(0)
            ThicknessDropDown.DataTextField = "THICKNESS"
            ThicknessDropDown.DataValueField = "THICKNESS"
            ThicknessDropDown.DataBind()
            'ThicknessDropDown.Items.Insert(0, "All")
            ThicknessDropDown.SelectedIndex = -1
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try


    End Sub
    Public Sub PopulateWidthForSPM(ByVal RoughDropDown As DropDownList, ByVal FromDate As String, ByVal ToDate As String, ByVal Grade As String, ByVal Thickness As String)
        Try
            Dim filter As String = ""
            If Grade.ToLower <> "all" Then
                If Grade <> "" Then
                    filter &= " and GRADE = '" & Grade & "'"
                End If
            End If
            If Thickness.ToLower <> "all" Then
                If Thickness <> "" Then
                    filter &= "  and THICKNESS in (" & Thickness & ")"
                End If


            End If
            RoughDropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct WIDTH from CRM_SPM_PROCESS_DATA_COILWISE_BODY where COIL_STARTDATETIME between '" & FromDate & "' and '" & ToDate & "' " & filter & " ORDER BY WIDTH").Tables(0)
            RoughDropDown.DataTextField = "WIDTH"
            RoughDropDown.DataValueField = "WIDTH"
            RoughDropDown.DataBind()
            'RoughDropDown.Items.Insert(0, "All")
            'RoughDropDown.SelectedIndex = 0
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try


    End Sub
    Public Sub PopulateCoilIdForSPM(ByVal CoilId As DropDownList, ByVal FromDate As String, ByVal ToDate As String, ByVal Grade As String, ByVal Thickness As String, ByVal Width As String)
        Try
            Dim filter As String = ""
            If Grade.ToLower <> "all" Then
                If Grade <> "" Then
                    filter &= " and GRADE = '" & Grade & "'"
                End If
            End If
            If Thickness.ToLower <> "all" Then
                If Thickness <> "" Then
                    filter &= "  and THICKNESS in (" & Thickness & ")"
                End If
                'filter &= "  and THICKNESS = '" & Thickness & "'"
            End If
            If Width.ToLower <> "all" Then
                If Width <> "" Then
                    filter &= "  and WIDTH in (" & Width & ")"
                End If

            End If
            CoilId.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct DAUGHTER_COILID_NUM from CRM_SPM_PROCESS_DATA_COILWISE_BODY where COIL_STARTDATETIME between '" & FromDate & "' and '" & ToDate & "' " & filter & " and (DAUGHTER_COILID_NUM <> '0' and DAUGHTER_COILID_NUM is not null) ORDER BY DAUGHTER_COILID_NUM").Tables(0)
            CoilId.DataTextField = "DAUGHTER_COILID_NUM"
            CoilId.DataValueField = "DAUGHTER_COILID_NUM"
            CoilId.DataBind()
            'CoilId.Items.Insert(0, "All")
            'CoilId.SelectedIndex = 0
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try


    End Sub
    Public Function GetDataForDescriptiveAnalysis(ByVal TableName As String, ByVal FromDate As String, ByVal ToDate As String, ByVal DateColumn As String, ByVal Filter As String) As DataTable
        Dim query As String = ""
        query = "select PRM_ID_COIL,isnull(PRM_TEST_VALUE_YS,0) as PRM_TEST_VALUE_YS,isnull(PRM_TEST_VALUE_UTS,0) as PRM_TEST_VALUE_UTS,PRM_CD_GRADE,isnull(PRM_ELONG,0) as PRM_ELONG,isnull((PRM_FORCE/1000),0) as PRM_FORCE,isnull(PRM_TEST_VALUE_YS,0) as PRM_TEST_VALUE_YS ,isnull(PRM_TEST_PARA_VAL_C,0) as PRM_TEST_PARA_VAL_C,isnull(PRM_TEST_VALUE_RBAR,0) as PRM_TEST_VALUE_RBAR from " & TableName & " where " & DateColumn & " between '" & FromDate & "' and '" & ToDate & "' and " & Filter & ""
        Return objDataHandler.GetDataSetFromQuery(query).Tables(0)
    End Function
    Public Sub PlotScatterChartForDescAnalysisYS(ByVal dt As DataTable, ByVal XValue As String, ByVal YValue As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal XaxisName As String, YaxisName As String)

        Try
            Dim js As String = ""
            Dim xVal(), yVal() As Decimal
            xVal = (From row In dt.AsEnumerable().Where(Function(r) r.Field(Of Decimal)(XValue) > 0) Select col = CDec(row(Trim(XValue)))).ToArray
            yVal = (From row In dt.AsEnumerable().Where(Function(r) r.Field(Of Decimal)(YValue) > 0) Select col = CDec(row(Trim(YValue)))).ToArray
            Dim xmin = xVal.Min() - 10
            Dim xmax = xVal.Max() + 10
            Dim ymin = yVal.Min() - 10
            Dim ymax = yVal.Max() + 10
            xVal = Nothing
            yVal = Nothing
            Dim arrGrades() As String = (From row In dt Select col = row.Field(Of String)("PRM_CD_GRADE") Distinct).ToArray()
            Dim arrSeriesColor() As String = {"#021277", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000"}
            Dim series As String = ""
            Dim legend As String = "var series = ['"
            Dim seriesColor As String = "['"
            Dim chartSeries As String = "[{"
            js = "<script language='javascript' type='text/javascript'>" & vbCrLf &
               "$(document).ready(function(){" & vbCrLf &
               "$.jqplot.config.enablePlugins = true;" & vbCrLf

            For i As Integer = 0 To arrGrades.Length - 1
                Dim x = i
                Dim xValues() As Decimal = (From row In dt.AsEnumerable().Where(Function(r) r.Field(Of String)("PRM_CD_GRADE") = arrGrades(x)) Select col = CDec(row(XValue))).ToArray
                Dim yValues() As Decimal = (From row In dt.AsEnumerable().Where(Function(r) r.Field(Of String)("PRM_CD_GRADE") = arrGrades(x)) Select col = CDec(row(YValue))).ToArray
                js &= "var data" & i & " = [["
                For j As Integer = 0 To xValues.Length - 1
                    If j = xValues.Length - 1 Then
                        js &= xValues.GetValue(j).ToString().Trim() & ", " & yValues.GetValue(j).ToString().Trim() & ", '" & arrGrades(i) & "']]; " & vbCrLf
                    Else
                        js &= xValues.GetValue(j).ToString().Trim() & ", " & yValues.GetValue(j).ToString().Trim() & ", '" & arrGrades(i) & "'], ["
                    End If
                Next
                If i > 0 Then
                    legend &= ", '"
                    seriesColor &= ", '"
                    series &= ", "
                    chartSeries &= ", {"
                End If
                legend &= arrGrades(i) & "'"
                seriesColor &= arrSeriesColor(i) & "'"
                series &= "data" & i
                chartSeries &= "neighborThreshold: 0, showLine:false, showMarker:true}"
            Next
            legend &= "];"
            seriesColor &= "]"
            chartSeries &= ",{showLine:true, showMarker:false}],"

            js &= vbCrLf & "var line = [[" & xmin & "," & xmax & "],[" & ymin & "," & ymax & "]];" & vbCrLf
            js &= legend & vbCrLf
            js &= "opts = {" & vbCrLf &
            "//title: 'Billet temp Versus Laying Head Temp'," & vbCrLf &
            "seriesDefaults:{pointLabels:{show:false}}," & vbCrLf &
            "series: " & chartSeries & vbCrLf &
            "seriesColors: " & seriesColor & "," & vbCrLf &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
           "tickOptions: {" & vbCrLf &
           "fontSize:'10pt'," & vbCrLf &
            "textColor: '#000000 '," & vbCrLf &
           "}" & vbCrLf &
           "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "tickOptions:{" & vbCrLf &
           "formatString:  '%.0f'," & vbCrLf &
            "textColor: '#000000 '," & vbCrLf &
             "}, " & vbCrLf &
              "label: '" & XaxisName & "'," & vbCrLf &
               "labelOptions: {" & vbCrLf &
            "textColor: '#000000 '," & vbCrLf &
               "}," & vbCrLf &
             "min: " & xmin & "," & vbCrLf &
            "max: " & xmax & "," & vbCrLf &
            "}," & vbCrLf &
            "yaxis: {" & vbCrLf &
             "tickOptions:{" & vbCrLf &
             "formatString:  '%.0f'," & vbCrLf &
            "textColor: '#000000 '," & vbCrLf &
             "}, " & vbCrLf &
             "label: '" & YaxisName & "'," & vbCrLf &
              "labelOptions: {" & vbCrLf &
            "textColor: '#000000 '," & vbCrLf &
               "}," & vbCrLf &
             "labelRenderer: $.jqplot.CanvasAxisLabelRenderer," & vbCrLf &
            "//pad:1" & vbCrLf &
             "min: " & ymin & "," & vbCrLf &
            "max: " & ymax & "," & vbCrLf &
             "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "//show: true, " & vbCrLf &
            "zoom: true, " & vbCrLf &
            "//followMouse: true," & vbCrLf &
            "//showTooltip: true, " & vbCrLf &
             "}," & vbCrLf &
             "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
            "legend: {" & vbCrLf &
            "show: true," & vbCrLf &
            "location: 's'," & vbCrLf &
            "labels: series," & vbCrLf &
            "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
            "placement: 'outsideGrid'," & vbCrLf &
            "rendererOptions: {" & vbCrLf &
            "numberRows: 1," & vbCrLf &
            "marginTop: 10" & vbCrLf &
            "}" & vbCrLf &
            "}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "', [" & series & "], opts);" & vbCrLf &
            "});" & vbCrLf &
            "</script>" & vbCrLf
            LiteralName.Text = js
        Catch ex As Exception
            ex.ToString()
        End Try

    End Sub
    Public Sub PlotScatterChartForDescAnalysisForce(ByVal dt As DataTable, ByVal XValue As String, ByVal YValue As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal XaxisName As String, YaxisName As String)

        Try
            Dim js As String = ""
            Dim xVal(), yVal() As Decimal
            xVal = (From row In dt.AsEnumerable().Where(Function(r) r.Field(Of Decimal)(XValue) > 0) Select col = CDec(row(Trim(XValue)))).ToArray
            yVal = (From row In dt.AsEnumerable().Where(Function(r) r.Field(Of Decimal)(YValue) > 0) Select col = CDec(row(Trim(YValue)))).ToArray
            Dim xmin = xVal.Min()
            Dim xmax = xVal.Max()
            Dim ymin = yVal.Min()
            Dim ymax = yVal.Max()
            xVal = Nothing
            yVal = Nothing
            Dim arrGrades() As String = (From row In dt Select col = row.Field(Of String)("PRM_CD_GRADE") Distinct).ToArray()
            Dim arrSeriesColor() As String = {"#021277", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000"}
            Dim series As String = ""
            Dim legend As String = "var series = ['"
            Dim seriesColor As String = "['"
            Dim chartSeries As String = "[{"
            js = "<script language='javascript' type='text/javascript'>" & vbCrLf &
               "$(document).ready(function(){" & vbCrLf &
               "$.jqplot.config.enablePlugins = true;" & vbCrLf

            For i As Integer = 0 To arrGrades.Length - 1
                Dim x = i
                Dim xValues() As Decimal = (From row In dt.AsEnumerable().Where(Function(r) r.Field(Of String)("PRM_CD_GRADE") = arrGrades(x)) Select col = CDec(row(XValue))).ToArray
                Dim yValues() As Decimal = (From row In dt.AsEnumerable().Where(Function(r) r.Field(Of String)("PRM_CD_GRADE") = arrGrades(x)) Select col = CDec(row(YValue))).ToArray
                js &= "var data" & i & " = [["
                For j As Integer = 0 To xValues.Length - 1
                    If j = xValues.Length - 1 Then
                        js &= xValues.GetValue(j).ToString().Trim() & ", " & yValues.GetValue(j).ToString().Trim() & ", '" & arrGrades(i) & "']]; " & vbCrLf
                    Else
                        js &= xValues.GetValue(j).ToString().Trim() & ", " & yValues.GetValue(j).ToString().Trim() & ", '" & arrGrades(i) & "'], ["
                    End If
                Next
                If i > 0 Then
                    legend &= ", '"
                    seriesColor &= ", '"
                    series &= ", "
                    chartSeries &= ", {"
                End If
                legend &= arrGrades(i) & "'"
                seriesColor &= arrSeriesColor(i) & "'"
                series &= "data" & i
                chartSeries &= "neighborThreshold: 0, showLine:false, showMarker:true}"
            Next
            legend &= "];"
            seriesColor &= "]"
            chartSeries &= ",{showLine:true, showMarker:false}],"

            js &= vbCrLf & "var line = [[" & xmin & "," & xmax & "],[" & ymin & "," & ymax & "]];" & vbCrLf
            js &= legend & vbCrLf
            js &= "opts = {" & vbCrLf &
            "//title: 'Billet temp Versus Laying Head Temp'," & vbCrLf &
            "seriesDefaults:{pointLabels:{show:false}}," & vbCrLf &
            "series: " & chartSeries & vbCrLf &
            "seriesColors: " & seriesColor & "," & vbCrLf &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
           "tickOptions: {" & vbCrLf &
           "fontSize:'10pt'," & vbCrLf &
            "textColor: '#000000 '," & vbCrLf &
           "}" & vbCrLf &
           "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "tickOptions:{" & vbCrLf &
           "formatString:  '%.2f'," & vbCrLf &
            "textColor: '#000000 '," & vbCrLf &
             "}, " & vbCrLf &
              "label: '" & XaxisName & "'," & vbCrLf &
               "labelOptions: {" & vbCrLf &
            "textColor: '#000000 '," & vbCrLf &
               "}," & vbCrLf &
             "min: " & xmin & "," & vbCrLf &
            "max: " & xmax & "," & vbCrLf &
            "}," & vbCrLf &
            "yaxis: {" & vbCrLf &
             "tickOptions:{" & vbCrLf &
             "formatString:  '%.2f'," & vbCrLf &
            "textColor: '#000000 '," & vbCrLf &
             "}, " & vbCrLf &
             "label: '" & YaxisName & "'," & vbCrLf &
              "labelOptions: {" & vbCrLf &
            "textColor: '#000000 '," & vbCrLf &
               "}," & vbCrLf &
             "labelRenderer: $.jqplot.CanvasAxisLabelRenderer," & vbCrLf &
            "//pad:1" & vbCrLf &
             "min: " & ymin & "," & vbCrLf &
            "max: " & ymax & "," & vbCrLf &
             "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "//show: true, " & vbCrLf &
            "zoom: true, " & vbCrLf &
            "//followMouse: true," & vbCrLf &
            "//showTooltip: true, " & vbCrLf &
             "}," & vbCrLf &
             "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
            "legend: {" & vbCrLf &
            "show: true," & vbCrLf &
            "location: 's'," & vbCrLf &
            "labels: series," & vbCrLf &
            "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
            "placement: 'outsideGrid'," & vbCrLf &
            "rendererOptions: {" & vbCrLf &
            "numberRows: 1," & vbCrLf &
            "marginTop: 10" & vbCrLf &
            "}" & vbCrLf &
            "}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "', [" & series & "], opts);" & vbCrLf &
            "});" & vbCrLf &
            "</script>" & vbCrLf
            LiteralName.Text = js
        Catch ex As Exception
            ex.ToString()
        End Try

    End Sub
    Public Sub PlotScatterChartForDescAnalysisCarbon(ByVal dt As DataTable, ByVal XValue As String, ByVal YValue As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal XaxisName As String, YaxisName As String)

        Try
            Dim js As String = ""
            Dim xVal(), yVal() As Decimal
            xVal = (From row In dt.AsEnumerable().Where(Function(r) r.Field(Of Decimal)(XValue) > 0) Select col = CDec(row(Trim(XValue)))).ToArray
            yVal = (From row In dt.AsEnumerable().Where(Function(r) r.Field(Of Decimal)(YValue) > 0) Select col = CDec(row(Trim(YValue)))).ToArray
            Dim xmin = xVal.Min() - (xVal.Min() * 0.1)
            Dim xmax = xVal.Max() + (xVal.Max() * 0.1)
            Dim ymin = yVal.Min() - (yVal.Min() * 0.1)
            Dim ymax = yVal.Max() + (yVal.Max() * 0.1)
            xVal = Nothing
            yVal = Nothing
            Dim arrGrades() As String = (From row In dt Select col = row.Field(Of String)("PRM_CD_GRADE") Distinct).ToArray()
            Dim arrSeriesColor() As String = {"#021277", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000"}
            Dim series As String = ""
            Dim legend As String = "var series = ['"
            Dim seriesColor As String = "['"
            Dim chartSeries As String = "[{"
            js = "<script language='javascript' type='text/javascript'>" & vbCrLf &
               "$(document).ready(function(){" & vbCrLf &
               "$.jqplot.config.enablePlugins = true;" & vbCrLf

            For i As Integer = 0 To arrGrades.Length - 1
                Dim x = i
                Dim xValues() As Decimal = (From row In dt.AsEnumerable().Where(Function(r) r.Field(Of String)("PRM_CD_GRADE") = arrGrades(x)) Select col = CDec(row(XValue))).ToArray
                Dim yValues() As Decimal = (From row In dt.AsEnumerable().Where(Function(r) r.Field(Of String)("PRM_CD_GRADE") = arrGrades(x)) Select col = CDec(row(YValue))).ToArray
                js &= "var data" & i & " = [["
                For j As Integer = 0 To xValues.Length - 1
                    If j = xValues.Length - 1 Then
                        js &= xValues.GetValue(j).ToString().Trim() & ", " & yValues.GetValue(j).ToString().Trim() & ", '" & arrGrades(i) & "']]; " & vbCrLf
                    Else
                        js &= xValues.GetValue(j).ToString().Trim() & ", " & yValues.GetValue(j).ToString().Trim() & ", '" & arrGrades(i) & "'], ["
                    End If
                Next
                If i > 0 Then
                    legend &= ", '"
                    seriesColor &= ", '"
                    series &= ", "
                    chartSeries &= ", {"
                End If
                legend &= arrGrades(i) & "'"
                seriesColor &= arrSeriesColor(i) & "'"
                series &= "data" & i
                chartSeries &= "neighborThreshold: 0, showLine:false, showMarker:true}"
            Next
            legend &= "];"
            seriesColor &= "]"
            chartSeries &= ",{showLine:true, showMarker:false}],"

            js &= vbCrLf & "var line = [[" & xmin & "," & xmax & "],[" & ymin & "," & ymax & "]];" & vbCrLf
            js &= legend & vbCrLf
            js &= "opts = {" & vbCrLf &
            "//title: 'Billet temp Versus Laying Head Temp'," & vbCrLf &
            "seriesDefaults:{pointLabels:{show:false}}," & vbCrLf &
            "series: " & chartSeries & vbCrLf &
            "seriesColors: " & seriesColor & "," & vbCrLf &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
           "tickOptions: {" & vbCrLf &
           "fontSize:'10pt'," & vbCrLf &
            "textColor: '#000000 '," & vbCrLf &
           "}" & vbCrLf &
           "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "tickOptions:{" & vbCrLf &
           "formatString:  '%.3f'," & vbCrLf &
            "textColor: '#000000 '," & vbCrLf &
             "}, " & vbCrLf &
              "label: '" & XaxisName & "'," & vbCrLf &
               "labelOptions: {" & vbCrLf &
            "textColor: '#000000 '," & vbCrLf &
               "}," & vbCrLf &
             "min: " & xmin & "," & vbCrLf &
            "max: " & xmax & "," & vbCrLf &
            "}," & vbCrLf &
            "yaxis: {" & vbCrLf &
             "tickOptions:{" & vbCrLf &
             "formatString:  '%.0f'," & vbCrLf &
            "textColor: '#000000 '," & vbCrLf &
             "}, " & vbCrLf &
             "label: '" & YaxisName & "'," & vbCrLf &
              "labelOptions: {" & vbCrLf &
            "textColor: '#000000 '," & vbCrLf &
               "}," & vbCrLf &
             "labelRenderer: $.jqplot.CanvasAxisLabelRenderer," & vbCrLf &
            "//pad:1" & vbCrLf &
             "min: " & ymin & "," & vbCrLf &
            "max: " & ymax & "," & vbCrLf &
             "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "//show: true, " & vbCrLf &
            "zoom: true, " & vbCrLf &
            "//followMouse: true," & vbCrLf &
            "//showTooltip: true, " & vbCrLf &
             "}," & vbCrLf &
             "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
            "legend: {" & vbCrLf &
            "show: true," & vbCrLf &
            "location: 's'," & vbCrLf &
            "labels: series," & vbCrLf &
            "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
            "placement: 'outsideGrid'," & vbCrLf &
            "rendererOptions: {" & vbCrLf &
            "numberRows: 1," & vbCrLf &
            "marginTop: 10" & vbCrLf &
            "}" & vbCrLf &
            "}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "', [" & series & "], opts);" & vbCrLf &
            "});" & vbCrLf &
            "</script>" & vbCrLf
            LiteralName.Text = js
        Catch ex As Exception
            LiteralName.Text = ""
            ex.ToString()
        End Try

    End Sub
    Public Sub PlotLineChartForSPMCoil(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String, ByVal GroupByColName As String)
        Try
            'For i As Integer = 0 To dt.Rows.Count - 1
            '    If IsDBNull(dt.Rows(i)("LTRI_PARA_MIN")) Then
            '        dt.Rows(i)("LTRI_PARA_MIN") = dt.Rows(i)("LTRI_PARA_MIN").ToString().Replace(vbNull, vbDecimal)
            '    End If
            'Next
            LiteralName.Text = ""
            Dim min_time, max_time As String
            min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-30), "yyyy-MM-dd HH:mm")
            max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm")

            Dim arrSeriesColor() As String = {"#021277", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000"}
            Dim seriesColor As String = "['"
            'Dim xTimestampVal(), yVal() As String
            Dim yVal() As Decimal

            'xTimestampVal = (From row In dt Select col = row(XAxisColName).ToString).ToArray
            yVal = (From row In dt Select col = CDec(row(YAxisColName))).ToArray()

            'Dim y_min As String = yVal.Min()
            'Dim y_max As String = yVal.Max()
            Dim y_min As String = yVal.Min() - (10 / 100 * yVal.Min)
            Dim y_max As String = yVal.Max() + (10 / 100 * yVal.Max)

            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf
            dt.DefaultView.RowFilter = ""
            Dim dtGrades As DataTable = dt.DefaultView.ToTable(True, GroupByColName) 'All distinct Grades
            Dim dvDefault As DataView = dt.DefaultView
            Dim flag As Boolean = False
            For i As Integer = 0 To dtGrades.Rows.Count - 1
                js &= "var line" & (i + 1).ToString & " = ["
                dvDefault.RowFilter = "" & GroupByColName & "='" & dtGrades.Rows(i)(0) & "'"
                For j As Integer = 0 To dvDefault.Count - 1
                    If j > 0 Then
                        js &= ","
                    End If
                    js &= "["
                    Dim dtTime As DateTime = dvDefault.Item(j)(XAxisColName)
                    If IsDBNull(dvDefault.Item(j)(GroupByColName)) Then
                        If IsDBNull(dvDefault.Item(j)(YAxisColName)) = False Then
                            js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)(YAxisColName) & ", " & "null"
                        Else
                            js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & "null, null"
                        End If
                    Else
                        If IsDBNull(dvDefault.Item(j)(YAxisColName)) = False Then
                            js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)(YAxisColName) & ", '(" & dvDefault.Item(j)(GroupByColName).ToString().Trim & ")'"
                            'js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)("CLR_TEST_VALUE") & ", 'Pot'"
                        End If
                    End If
                    js &= "]"
                Next
                js &= "];" & vbCrLf
                flag = True
                If i > 0 Then

                    seriesColor &= ", '"
                End If
                seriesColor &= arrSeriesColor(i) & "'"
            Next

            Dim strg As String = ""
            Dim strseries As String = ""
            If flag Then
                strg = "[line1"
                strseries = " {pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
                For i As Integer = 1 To dtGrades.Rows.Count - 1
                    strg = strg + ",line" & i + 1
                    strseries = strseries + ", {pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
                Next
                strg &= "]"
            End If
            js &= "var seriesName = ['"
            Dim str As String = ""
            For i As Integer = 0 To dtGrades.Rows.Count - 1
                str &= dtGrades.Rows(i)(0).ToString().Trim() + "', '"
            Next
            seriesColor &= "]"
            str = str.Remove(str.LastIndexOf(", '"))
            str &= "];"
            js &= str
            js &= "opts = {" & vbCrLf &
            "title: '" & ChartTitle & "'," & vbCrLf &
            "series:[" & strseries & "]," & vbCrLf &
             "seriesColors: " & seriesColor & "," & vbCrLf &
            "//seriesColors: ['#FFA500']," & vbCrLf &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            "fontSize:'8pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf &
            "renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
            "tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," & vbCrLf &
            "//tickInterval:'1 hour'," & vbCrLf &
            "pad:0" & vbCrLf &
            "}," & vbCrLf &
            "yaxis: { " & vbCrLf &
            "tickOptions: { formatString: '%.3f' }," & vbCrLf &
            "min: " & y_min & "," & vbCrLf &
            "max: " & y_max & "," & vbCrLf &
            "autoscale:true," & vbCrLf &
            "//label: '" & YAxisLabelName & "'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "showTooltip: false," & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "animate: true," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
            "legend: {" & vbCrLf &
            "show: true," & vbCrLf &
            "location: 's'," & vbCrLf &
            "labels: seriesName," & vbCrLf &
            "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
            "placement: 'outsideGrid'," & vbCrLf &
            "rendererOptions: {" & vbCrLf &
            "numberRows: 1," & vbCrLf &
            "marginTop: 10" & vbCrLf &
            "}" & vbCrLf &
            "}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "', " & strg & ", opts);" & vbCrLf &
            "</script>" & vbCrLf

            LiteralName.Text = js
        Catch ex As Exception

        End Try
    End Sub

    Public Function GetDataForDescriptiveAnalysisSPM(ByVal TableName As String, ByVal FromDate As String, ByVal ToDate As String, ByVal DateColumn As String, ByVal Filter As String) As DataTable
        Dim query As String = ""
        If Filter <> "" Then
            'query = "select DAUGHTER_COILID_NUM,isnull(ROLLFORCE_DS,0) as ROLLFORCE_DS,isnull(ROLLFORCE_OS,0) as ROLLFORCE_OS,GRADE,isnull(YS,0) as YS,isnull(UTS,0) as UTS,isnull(TENSION_POS_ENTRY,0) as TENSION_POS_ENTRY ,isnull(TENSION_TR,0) as TENSION_TR  from " & TableName & " where " & DateColumn & " between '" & FromDate & "' and '" & ToDate & "' and (GRADE <> '0' and GRADE is not null) and " & Filter & ""
            query = "select DAUGHTER_COILID_NUM,isnull(ROLLFORCE * 102.0408,0) as ROLLFORCE,isnull(ENLONGATION_ACT*100,0) as ENLONGATION,GRADE,isnull(YS,0) as YS,isnull(UTS,0) as UTS,convert(date,COIL_STARTDATETIME) as STDATE,convert(char(3),DATENAME(month,COIL_STARTDATETIME)) + '' + convert(varchar,datepart(yy,COIL_STARTDATETIME)) as STDATE1,convert(char(3),DATENAME(week,COIL_STARTDATETIME)) as STDATE2 from " & TableName & " where " & DateColumn & " between '" & FromDate & "' and '" & ToDate & "' and (GRADE <> '0' and GRADE is not null) and " & Filter & " order by STDATE"
        Else
            'query = "select DAUGHTER_COILID_NUM,isnull(ROLLFORCE_DS,0) as ROLLFORCE_DS,isnull(ROLLFORCE_OS,0) as ROLLFORCE_OS,GRADE,isnull(YS,0) as YS,isnull(UTS,0) as UTS,isnull(TENSION_POS_ENTRY,0) as TENSION_POS_ENTRY ,isnull(TENSION_TR,0) as TENSION_TR from " & TableName & " where " & DateColumn & " between '" & FromDate & "' and '" & ToDate & "' and (GRADE <> '0' and GRADE is not null)"
            query = "select DAUGHTER_COILID_NUM,isnull(ROLLFORCE * 102.0408,0) as ROLLFORCE,isnull(ENLONGATION_ACT*100,0) as ENLONGATION,GRADE,isnull(YS,0) as YS,isnull(UTS,0) as UTS,convert(date,COIL_STARTDATETIME) as STDATE,convert(char(3),DATENAME(month,COIL_STARTDATETIME)) + '' + convert(varchar,datepart(yy,COIL_STARTDATETIME)) as STDATE1,convert(char(3),DATENAME(week,COIL_STARTDATETIME)) as STDATE2 from " & TableName & " where " & DateColumn & " between '" & FromDate & "' and '" & ToDate & "' and (GRADE <> '0' and GRADE is not null) order by STDATE"
        End If

        Return objDataHandler.GetDataSetFromQuery(query).Tables(0)
    End Function
    Public Sub PlotScatterChartForDescAnalysisSPMDSOS(ByVal dt As DataTable, ByVal XValue As String, ByVal YValue As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal XaxisName As String, YaxisName As String)

        Try
            Dim js As String = ""
            Dim xVal(), yVal() As Decimal
            Dim decimalVal As String = ""
            If XValue = "ENLONGATION" Then
                decimalVal = "%.2f"
            Else
                decimalVal = "%.0f"
            End If
            xVal = (From row In dt.AsEnumerable().Where(Function(r) r.Field(Of Decimal)(XValue) > 0) Select col = CDec(row(Trim(XValue)))).ToArray
            yVal = (From row In dt.AsEnumerable().Where(Function(r) r.Field(Of Decimal)(YValue) > 0) Select col = CDec(row(Trim(YValue)))).ToArray
            Dim xmin = xVal.Min() - (xVal.Min() * 0.1)
            Dim xmax = xVal.Max() + (xVal.Max() * 0.1)
            Dim ymin = yVal.Min() - (yVal.Min() * 0.1)
            Dim ymax = yVal.Max() + (yVal.Max() * 0.1)
            xVal = Nothing
            yVal = Nothing
            Dim arrGrades() As String = (From row In dt Select col = row.Field(Of String)("GRADE") Distinct).ToArray()
            Dim arrSeriesColor() As String = {"#021277", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000"}
            Dim series As String = ""
            Dim legend As String = "var series = ['"
            Dim seriesColor As String = "['"
            Dim chartSeries As String = "[{"
            js = "<script language='javascript' type='text/javascript'>" & vbCrLf &
               "$(document).ready(function(){" & vbCrLf &
               "$.jqplot.config.enablePlugins = true;" & vbCrLf

            For i As Integer = 0 To arrGrades.Length - 1
                Dim x = i
                Dim xValues() As Decimal = (From row In dt.AsEnumerable().Where(Function(r) r.Field(Of String)("GRADE") = arrGrades(x)) Select col = CDec(row(XValue))).ToArray
                Dim yValues() As Decimal = (From row In dt.AsEnumerable().Where(Function(r) r.Field(Of String)("GRADE") = arrGrades(x)) Select col = CDec(row(YValue))).ToArray
                js &= "var data" & i & " = [["
                For j As Integer = 0 To xValues.Length - 1
                    If j = xValues.Length - 1 Then
                        js &= xValues.GetValue(j).ToString().Trim() & ", " & yValues.GetValue(j).ToString().Trim() & ", '" & arrGrades(i) & "']]; " & vbCrLf
                    Else
                        js &= xValues.GetValue(j).ToString().Trim() & ", " & yValues.GetValue(j).ToString().Trim() & ", '" & arrGrades(i) & "'], ["
                    End If
                Next
                If i > 0 Then
                    legend &= ", '"
                    seriesColor &= ", '"
                    series &= ", "
                    chartSeries &= ", {"
                End If
                legend &= arrGrades(i) & "'"
                seriesColor &= arrSeriesColor(i) & "'"
                series &= "data" & i
                chartSeries &= "neighborThreshold: 0, showLine:false, showMarker:true}"
            Next
            legend &= "];"
            seriesColor &= "]"
            chartSeries &= ",{showLine:true, showMarker:false}],"

            js &= vbCrLf & "var line = [[" & xmin & "," & xmax & "],[" & ymin & "," & ymax & "]];" & vbCrLf
            js &= legend & vbCrLf
            js &= "opts = {" & vbCrLf &
            "//title: 'Billet temp Versus Laying Head Temp'," & vbCrLf &
            "seriesDefaults:{pointLabels:{show:false}}," & vbCrLf &
            "series: " & chartSeries & vbCrLf &
            "seriesColors: " & seriesColor & "," & vbCrLf &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
           "tickOptions: {" & vbCrLf &
           "fontSize:'10pt'," & vbCrLf &
            "textColor: '#000000 '," & vbCrLf &
           "}" & vbCrLf &
           "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "tickOptions:{" & vbCrLf &
           "formatString: '" & decimalVal & "'," & vbCrLf &
            "textColor: '#000000 '," & vbCrLf &
             "}, " & vbCrLf &
              "label: '" & XaxisName & "'," & vbCrLf &
               "labelOptions: {" & vbCrLf &
            "textColor: '#000000 '," & vbCrLf &
               "}," & vbCrLf &
             "min: " & xmin & "," & vbCrLf &
            "max: " & xmax & "," & vbCrLf &
            "}," & vbCrLf &
            "yaxis: {" & vbCrLf &
             "tickOptions:{" & vbCrLf &
             "formatString: '" & decimalVal & "'," & vbCrLf &
            "textColor: '#000000 '," & vbCrLf &
             "}, " & vbCrLf &
             "label: '" & YaxisName & "'," & vbCrLf &
              "labelOptions: {" & vbCrLf &
            "textColor: '#000000 '," & vbCrLf &
               "}," & vbCrLf &
             "labelRenderer: $.jqplot.CanvasAxisLabelRenderer," & vbCrLf &
            "//pad:1" & vbCrLf &
             "min: " & ymin & "," & vbCrLf &
            "max: " & ymax & "," & vbCrLf &
             "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "//show: true, " & vbCrLf &
            "zoom: true, " & vbCrLf &
            "//followMouse: true," & vbCrLf &
            "//showTooltip: true, " & vbCrLf &
             "}," & vbCrLf &
             "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
            "legend: {" & vbCrLf &
            "show: true," & vbCrLf &
            "location: 's'," & vbCrLf &
            "labels: series," & vbCrLf &
            "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
            "placement: 'outsideGrid'," & vbCrLf &
            "rendererOptions: {" & vbCrLf &
            "numberRows: 1," & vbCrLf &
            "marginTop: 10" & vbCrLf &
            "}" & vbCrLf &
            "}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "', [" & series & "], opts);" & vbCrLf &
            "});" & vbCrLf &
            "</script>" & vbCrLf
            LiteralName.Text = js
        Catch ex As Exception
            ex.ToString()
        End Try

    End Sub

    Public Function LoadQuality(Optional ByVal stD As String = "", Optional ByVal endD As String = "", Optional ByVal holdID As String = "All") As DataSet
        Dim stDate, endDate As Date
        If stD = "" Then
            stDate = Date.Today.AddDays(-29)
            endDate = Date.Today
        Else
            stDate = Date.Parse(stD)
            endDate = Date.Parse(endD)
        End If
        Dim filter As String = ""
        If holdID <> "All" Then
            filter = " AND CHC_HOLD_ID=" & holdID & " "
        End If
        Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("select distinct PRM_CD_GRADE from [T_CGL_FUR_PARAM] order by prm_cd_grade desc; select PRM_CD_GRADE,[CHC_HOLD_DESC],COUNT(CHC_HOLD_DESC) as totcount,CEILING(ROUND(SUM(PRM_MS_COIL_ACTL / 1000),0)) AS WT,[CHC_HOLD_ID] FROM [T_CGL_FUR_PARAM]  inner join [COIL_HOLD_CODES] on PRM_CD_RSN_HOLD=[CHC_HOLD_ID] where PRM_TS_END BETWEEN '" & stDate.ToString("yyyy-MM-dd") & "' AND '" & endDate.ToString("yyyy-MM-dd") & "' " & filter & " group by PRM_CD_GRADE,[CHC_HOLD_DESC],[CHC_HOLD_ID];select PRM_CD_GRADE,PRM_TEST_VALUE_YS,PRM_TEST_VALUE_UTS from [T_CGL_FUR_PARAM] where PRM_TS_END BETWEEN '" & stDate.ToString("yyyy-MM-dd") & "' AND '" & endDate.ToString("yyyy-MM-dd") & "' and PRM_TEST_VALUE_UTS is not null and PRM_TEST_VALUE_YS is not null;select PRM_TTC_AVG,PRM_BTC_AVG,PRM_CD_GRADE from T_CGL_FUR_PARAM where PRM_TS_END BETWEEN '" & stDate.ToString("yyyy-MM-dd") & "' AND '" & endDate.ToString("yyyy-MM-dd") & "' and PRM_TTC_AVG is not null and PRM_BTC_AVG is not null")
        Return ds
    End Function


    'Public Sub EffectiveAlAndFe(ByVal dt As DataTable, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String)
    '    Try
    '        Dim query = From val In dt.AsEnumerable() Where val.Field(Of String)("CAMPAIGN") = "GI" Select val Order By val.Field(Of DateTime)("CZT_TIMESTAMP")
    '        Dim dtGI As DataTable = query.CopyToDataTable
    '        query = From val In dt.AsEnumerable() Where val.Field(Of String)("CAMPAIGN") = "GA" Select val Order By val.Field(Of DateTime)("CZT_TIMESTAMP")
    '        Dim dtGA As DataTable = query.CopyToDataTable

    '        'Below are the temporary datatables holding false record in between two rows having time difference of 24 hours or more.
    '        Dim dtGI_Temp As New DataTable
    '        dtGI_Temp.Columns.Add("CZT_EFF_AL", GetType(Decimal))
    '        dtGI_Temp.Columns.Add("CZT_EFF_FE", GetType(Decimal))
    '        dtGI_Temp.Columns.Add("CZT_TIMESTAMP", GetType(DateTime))
    '        dtGI_Temp.Columns.Add("CZT_CAMP_AL", GetType(String))
    '        dtGI_Temp.Columns.Add("CZT_POT_AL", GetType(Decimal))
    '        dtGI_Temp.Columns.Add("CZT_POT_FE", GetType(Decimal))
    '        dtGI_Temp.Columns.Add("CAMPAIGN", GetType(String))
    '        dtGI_Temp.Columns.Add("UCL", GetType(Decimal))
    '        dtGI_Temp.Columns.Add("LCL", GetType(Decimal))
    '        For i As Integer = 0 To dtGI.Rows.Count - 1
    '            Dim row As DataRow = dtGI_Temp.NewRow
    '            row("CZT_EFF_AL") = dtGI.Rows(i)("CZT_EFF_AL")
    '            row("CZT_EFF_FE") = dtGI.Rows(i)("CZT_EFF_FE")
    '            row("CZT_TIMESTAMP") = CDate(dtGI.Rows(i)("CZT_TIMESTAMP"))
    '            row("CZT_CAMP_AL") = dtGI.Rows(i)("CZT_CAMP_AL")
    '            row("CZT_POT_AL") = dtGI.Rows(i)("CZT_POT_AL")
    '            row("CZT_POT_FE") = dtGI.Rows(i)("CZT_POT_FE")
    '            row("CAMPAIGN") = dtGI.Rows(i)("CAMPAIGN")
    '            row("UCL") = dtGI.Rows(i)("UCL")
    '            row("LCL") = dtGI.Rows(i)("LCL")
    '            dtGI_Temp.Rows.Add(row)
    '            If i < dtGI.Rows.Count - 1 Then
    '                Dim span As TimeSpan = DateTime.Parse(dtGI.Rows(i + 1)("CZT_TIMESTAMP")).Subtract(DateTime.Parse(dtGI.Rows(i)("CZT_TIMESTAMP")))
    '                If span.TotalHours >= 24 Then
    '                    dtGI_Temp.Rows.Add(dtGI.Rows(i)("CZT_EFF_AL"), dtGI.Rows(i)("CZT_EFF_FE"), CDate(dtGI.Rows(i)("CZT_TIMESTAMP")).AddMinutes(10),
    '                                       dtGI.Rows(i)("CZT_CAMP_AL"), dtGI.Rows(i)("CZT_POT_AL"), dtGI.Rows(i)("CZT_POT_FE"), dtGI.Rows(i)("CAMPAIGN"), 0, 0)
    '                End If
    '            End If
    '        Next

    '        Dim dtGA_Temp As New DataTable
    '        dtGA_Temp.Columns.Add("CZT_EFF_AL", GetType(Decimal))
    '        dtGA_Temp.Columns.Add("CZT_EFF_FE", GetType(Decimal))
    '        dtGA_Temp.Columns.Add("CZT_TIMESTAMP", GetType(DateTime))
    '        dtGA_Temp.Columns.Add("CZT_CAMP_AL", GetType(String))
    '        dtGA_Temp.Columns.Add("CZT_POT_AL", GetType(Decimal))
    '        dtGA_Temp.Columns.Add("CZT_POT_FE", GetType(Decimal))
    '        dtGA_Temp.Columns.Add("CAMPAIGN", GetType(String))
    '        dtGA_Temp.Columns.Add("UCL", GetType(Decimal))
    '        dtGA_Temp.Columns.Add("LCL", GetType(Decimal))
    '        For i As Integer = 0 To dtGA.Rows.Count - 1
    '            Dim row As DataRow = dtGA_Temp.NewRow
    '            row("CZT_EFF_AL") = dtGA.Rows(i)("CZT_EFF_AL")
    '            row("CZT_EFF_FE") = dtGA.Rows(i)("CZT_EFF_FE")
    '            row("CZT_TIMESTAMP") = CDate(dtGA.Rows(i)("CZT_TIMESTAMP"))
    '            row("CZT_CAMP_AL") = dtGA.Rows(i)("CZT_CAMP_AL")
    '            row("CZT_POT_AL") = dtGA.Rows(i)("CZT_POT_AL")
    '            row("CZT_POT_FE") = dtGA.Rows(i)("CZT_POT_FE")
    '            row("CAMPAIGN") = dtGA.Rows(i)("CAMPAIGN")
    '            row("UCL") = dtGA.Rows(i)("UCL")
    '            row("LCL") = dtGA.Rows(i)("LCL")
    '            dtGA_Temp.Rows.Add(row)
    '            If i < dtGA.Rows.Count - 1 Then
    '                Dim span As TimeSpan = DateTime.Parse(dtGA.Rows(i + 1)("CZT_TIMESTAMP")).Subtract(DateTime.Parse(dtGA.Rows(i)("CZT_TIMESTAMP")))
    '                If span.TotalHours >= 24 Then
    '                    dtGA_Temp.Rows.Add(dtGA.Rows(i)("CZT_EFF_AL"), dtGA.Rows(i)("CZT_EFF_FE"), CDate(dtGA.Rows(i)("CZT_TIMESTAMP")).AddMinutes(10),
    '                                       dtGA.Rows(i)("CZT_CAMP_AL"), dtGA.Rows(i)("CZT_POT_AL"), dtGA.Rows(i)("CZT_POT_FE"), dtGA.Rows(i)("CAMPAIGN"), 0, 0)
    '                End If
    '            End If
    '        Next
    '        '---------------------------------------END OF TEMPORARY DATATABLES----------------------------------------------

    '        'Dim giUclDataPoints As String = "var GI_UCL = [['" & CDate(dtGI.Rows(0)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGI.Rows(0)("UCL") & "], ['" & CDate(dtGI.Rows(dtGI.Rows.Count - 1)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGI.Rows(dtGI.Rows.Count - 1)("UCL") & "]];"
    '        Dim giUclDataPoints As String = "var GI_UCL = [["
    '        For i As Integer = 0 To dtGI_Temp.Rows.Count - 1
    '            If i = dtGI_Temp.Rows.Count - 1 Then
    '                giUclDataPoints &= "'" & CDate(dtGI_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGI_Temp.Rows(i)("UCL") = 0, "null", dtGI_Temp.Rows(i)("UCL")) & "]];"
    '            Else
    '                giUclDataPoints &= "'" & CDate(dtGI_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGI_Temp.Rows(i)("UCL") = 0, "null", dtGI_Temp.Rows(i)("UCL")) & "], ["
    '            End If
    '        Next
    '        'Dim giLclDataPoints As String = "var GI_LCL = [['" & CDate(dtGI_Temp.Rows(0)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGI_Temp.Rows(0)("LCL") & "], ['" & CDate(dtGI_Temp.Rows(dtGI_Temp.Rows.Count - 1)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGI_Temp.Rows(dtGI_Temp.Rows.Count - 1)("LCL") & "]];"
    '        Dim giLclDataPoints As String = "var GI_LCL = [["
    '        For i As Integer = 0 To dtGI_Temp.Rows.Count - 1
    '            If i = dtGI_Temp.Rows.Count - 1 Then
    '                giLclDataPoints &= "'" & CDate(dtGI_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGI_Temp.Rows(i)("LCL") = 0, "null", dtGI_Temp.Rows(i)("LCL")) & "]];"
    '            Else
    '                giLclDataPoints &= "'" & CDate(dtGI_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGI_Temp.Rows(i)("LCL") = 0, "null", dtGI_Temp.Rows(i)("LCL")) & "], ["
    '            End If
    '        Next
    '        'Dim gaUclDataPoints As String = "var GA_UCL = [['" & CDate(dtGA.Rows(0)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGA.Rows(0)("UCL") & "], ['" & CDate(dtGA.Rows(dtGA.Rows.Count - 1)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGA.Rows(dtGA.Rows.Count - 1)("UCL") & "]];"
    '        Dim gaUclDataPoints As String = "var GA_UCL = [["
    '        For i As Integer = 0 To dtGA_Temp.Rows.Count - 1
    '            If i = dtGA_Temp.Rows.Count - 1 Then
    '                gaUclDataPoints &= "'" & CDate(dtGA_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGA_Temp.Rows(i)("UCL") = 0, "null", dtGA_Temp.Rows(i)("UCL")) & "]];"
    '            Else
    '                gaUclDataPoints &= "'" & CDate(dtGA_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGA_Temp.Rows(i)("UCL") = 0, "null", dtGA_Temp.Rows(i)("UCL")) & "], ["
    '            End If
    '        Next
    '        'Dim gaLclDataPoints As String = "var GA_LCL = [['" & CDate(dtGA_Temp.Rows(0)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGA_Temp.Rows(0)("LCL") & "], ['" & CDate(dtGA_Temp.Rows(dtGA_Temp.Rows.Count - 1)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGA_Temp.Rows(dtGA_Temp.Rows.Count - 1)("LCL") & "]];"
    '        Dim gaLclDataPoints As String = "var GA_LCL = [["
    '        For i As Integer = 0 To dtGA_Temp.Rows.Count - 1
    '            If i = dtGA_Temp.Rows.Count - 1 Then
    '                gaLclDataPoints &= "'" & CDate(dtGA_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGA_Temp.Rows(i)("LCL") = 0, "null", dtGA_Temp.Rows(i)("LCL")) & "]];"
    '            Else
    '                gaLclDataPoints &= "'" & CDate(dtGA_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGA_Temp.Rows(i)("LCL") = 0, "null", dtGA_Temp.Rows(i)("LCL")) & "], ["
    '            End If
    '        Next

    '        Dim min_time, max_time As String
    '        min_time = Format(dt.Rows(0)("CZT_TIMESTAMP"), "yyyy-MM-dd HH:mm")
    '        max_time = Format(dt.Rows(dt.Rows.Count - 1)("CZT_TIMESTAMP"), "yyyy-MM-dd HH:mm")

    '        Dim xTimestampVal(), y1EffectiveAlVal(), y2EffectiveFe() As String

    '        xTimestampVal = (From row In dt Select col = row("CZT_TIMESTAMP").ToString).ToArray

    '        y1EffectiveAlVal = (From row In dt Select col = row("CZT_EFF_AL").ToString).ToArray()
    '        y2EffectiveFe = (From row In dt Select col = row("CZT_EFF_FE").ToString).ToArray()




    '        'Dim Al_min As String = 0 'As per the Excel file.
    '        'Dim Al_max As String = 0.35 'As per the Excel file.
    '        'Dim Fe_min As String = 0 'As per the Excel file.
    '        'Dim Fe_max As String = 0.07 'As per the Excel file.
    '        Dim Al_min As String = 0 'Changed by mamta on 11-Jan-2018
    '        Dim Al_max As String = 0.3 'Changed by mamta on 11-Jan-2018
    '        Dim Fe_min As String = 0 'Changed by mamta on 11-Jan-2018
    '        Dim Fe_max As String = 0.05 'Changed by mamta on 11-Jan-2018

    '        Dim js = "<script language='javascript' type='text/javascript'>" & vbCrLf & _
    '                "$(document).ready(function(){" & vbCrLf & _
    '                "$.jqplot.config.enablePlugins = true;" & vbCrLf & _
    '                "var series= ['Effective Aluminium', 'Effective Iron', 'GI Limits', 'GA Limits']" & vbCrLf & _
    '                "var data1 = [["
    '        For i = 0 To dt.Rows.Count - 1
    '            If i = xTimestampVal.Length - 1 Then
    '                js &= "'" & DateTime.Parse(xTimestampVal.GetValue(i).ToString().Trim()).ToString("yyyy-MM-dd HH:mm") & "', " & y1EffectiveAlVal.GetValue(i).ToString().Trim() & "]]; " & vbCrLf
    '            Else
    '                js &= "'" & DateTime.Parse(xTimestampVal.GetValue(i).ToString().Trim()).ToString("yyyy-MM-dd HH:mm") & "', " & y1EffectiveAlVal.GetValue(i).ToString().Trim() & "], ["
    '            End If
    '        Next


    '        js &= "var data2 = [["
    '        For i = 0 To dt.Rows.Count - 1
    '            If i = xTimestampVal.Length - 1 Then
    '                js &= "'" & DateTime.Parse(xTimestampVal.GetValue(i).ToString().Trim()).ToString("yyyy-MM-dd HH:mm") & "', " & y2EffectiveFe.GetValue(i).ToString().Trim() & "]]; " & vbCrLf
    '            Else
    '                js &= "'" & DateTime.Parse(xTimestampVal.GetValue(i).ToString().Trim()).ToString("yyyy-MM-dd HH:mm") & "', " & y2EffectiveFe.GetValue(i).ToString().Trim() & "], ["
    '            End If
    '        Next

    '        js &= vbCrLf & vbCrLf & giLclDataPoints & vbCrLf & vbCrLf & giUclDataPoints & vbCrLf & vbCrLf & gaLclDataPoints & vbCrLf & vbCrLf & gaUclDataPoints & vbCrLf & vbCrLf

    '        Dim EffAl_Series As String = "{pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:80px; width:180px; background-color:#0D5CA5; font-weight:bold; font-size:x-large; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td><center>%s</center></td></tr></table>'}}"
    '        Dim EffFe_Series As String = "{pointLabels: { show:false }, showLine: true, yaxis:'y2axis', lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:80px; width:180px; background-color:#BC2318; font-weight:bold; font-size:x-large; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td><center>%s</center></td></tr></table>'}}"
    '        Dim GI_Limit_Series As String = "{pointLabels:{show:!1},showLine:!0,lineWidth:2,breakOnNull: true,linePattern:'dashed',showMarker:!1,color:'#00FF19',highlighter:{show:!0,showMarker:!1,tooltipAxes:'xy',yvalues:2,formatString:'<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
    '        Dim GA_Limit_Series As String = "{pointLabels:{show:!1},showLine:!0,lineWidth:2,breakOnNull: true,linePattern:'dashed',showMarker:!1,color:'#000000',highlighter:{show:!0,showMarker:!1,tooltipAxes:'xy',yvalues:2,formatString:'<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"

    '        js &= "opts = {" & vbCrLf & _
    '        "//title: 'Calculated Effective Al & Fe'," & vbCrLf & _
    '        "series:[" & EffAl_Series & ", " & EffFe_Series & ", " & GI_Limit_Series & ", " & GI_Limit_Series & ", " & GA_Limit_Series & ", " & GA_Limit_Series & "]," & vbCrLf & _
    '        "seriesColors: ['#0D5CA5', '#BC2318']," & vbCrLf & _
    '        "axesDefaults: {" & vbCrLf & _
    '        "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf & _
    '        "tickOptions: {" & vbCrLf & _
    '        "fontSize:'8pt'" & vbCrLf & _
    '        "}" & vbCrLf & _
    '        "}," & vbCrLf & _
    '        "axes: {" & vbCrLf & _
    '        "xaxis: {" & vbCrLf & _
    '        "min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf & _
    '        "renderer:$.jqplot.DateAxisRenderer," & vbCrLf & _
    '        "tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," & vbCrLf & _
    '        "//tickInterval:'1 hour'," & vbCrLf & _
    '        "pad:0" & vbCrLf & _
    '        "}," & vbCrLf & _
    '        "yaxis: { " & vbCrLf & _
    '        "tickOptions: { formatString: '%.3f' }," & vbCrLf & _
    '        "min: " & Al_min & "," & vbCrLf & _
    '        "max: " & Al_max & "," & vbCrLf & _
    '        "//autoscale:true," & vbCrLf & _
    '        "label: '% Effective Al'," & vbCrLf & _
    '        "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf & _
    '        "}," & vbCrLf & _
    '        "y2axis: { " & vbCrLf & _
    '        "tickOptions: { formatString: '%.3f' }," & vbCrLf & _
    '        "min: " & Fe_min & "," & vbCrLf & _
    '        "max: " & Fe_max & "," & vbCrLf & _
    '        "//autoscale:true," & vbCrLf & _
    '        "//tickOptions:{showGridline:false}," & vbCrLf & _
    '        "label: '% Effective Fe'," & vbCrLf & _
    '        "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf & _
    '        "}" & vbCrLf & _
    '        "}," & vbCrLf & _
    '        "cursor: {" & vbCrLf & _
    '        "zoom: true" & vbCrLf & _
    '        "}," & vbCrLf & _
    '        "//highlighter: { show: 'true', tooltipFormatString: '%.1f', useAxesFormatters: false }," & vbCrLf & _
    '        "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf & _
    '        "legend: {" & vbCrLf & _
    '        "show: true," & vbCrLf & _
    '        "location: 's'," & vbCrLf & _
    '        "labels: series," & vbCrLf & _
    '        "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf & _
    '        "placement: 'outsideGrid'," & vbCrLf & _
    '        "rendererOptions: {" & vbCrLf & _
    '        "numberRows: 1," & vbCrLf & _
    '        "numberColumns: 2," & vbCrLf & _
    '        "marginTop: 10" & vbCrLf & _
    '        "}" & vbCrLf & _
    '        "}" & vbCrLf & _
    '        "};" & vbCrLf & _
    '       "" & PlotName & "  = $.jqplot('" & ContainerName & "',[data1, data2, GI_UCL, GI_LCL, GA_UCL, GA_LCL], opts);" & vbCrLf & _
    '        "});" & vbCrLf & _
    '        "</script>" & vbCrLf

    '        LiteralName.Text = js
    '    Catch ex As Exception

    '    End Try
    'End Sub
    Public Function PopulateCoilData(ByVal FromDt As String, ByVal ToDt As String, ByVal Filter As String) As DataTable
        Try
            If Filter = "" Then
                Filter = " 1=1"
            End If
            Return objDataHandler.GetDataSetFromQuery("SELECT  DAUGHTER_COILID_NUM as [Coil ID], cast(ROUND(THICKNESS,2) as float) as THICKNESS , ceiling(WIDTH*1000) as WIDTH, cast(ROUND(YS,2) as float) as YS,'' as [YS Testing],cast(ROUND(RB,2) as float) as RB ,TDC_No as TDC  " & vbCrLf &
       ", cast(ROUND(C90_COILER_SPEED_ACT * 60,2) as float) as [C90 COILERSPEED ACT (m/min)],cast(ROUND(ENLONGATION_SET * 100,2) as float) as [Elongation Set (%)] ,cast(ROUND(ENLONGATION_ACT * 100,2) as float) as [Elongation Act (%)], cast(ROUND(ROLLFORCE * 102.0408,2) as float) as [ROLLFORCE (Tonne)],cast(ROUND(T1.[Avg] * 102.0408,2) as float) as [ROLLFORCE SKU AVG (Tonne)],cast(ROUND(T1.[Avg] * 102.0408 + T1.[Avg] * 102.0408 * 20/100 ,2) as float) as [ROLLFORCE SKU U LIMIT (Tonne)] " & vbCrLf &
       ", cast(ROUND(ROLLFORCE_DS * 102.0408,2) as float) as [ROLLFORCE DS (Tonne)], cast(ROUND(ROLLFORCE_OS * 102.0408,2) as float) as [ROLLFORCE OS (Tonne)], cast(ROUND(TENSION_POR_ENTRY_REF,2) as float) as [TENSION POR ENTRY REF (Tonne)]  " & vbCrLf &
       ", cast(ROUND(TENSION_POS_ENTRY,2) as float) as [TENSION POS ENTRY (Tonne)], cast(ROUND(TENSION_TR_REF,2) as float) as [TENSION TR REF (Tonne)], cast(ROUND(TENSION_TR,2) as float) as [TENSION TR (Tonne)] " & vbCrLf &
       ", cast(ROUND(TENSION_POR_ENTRY_REF * 1000/(9.8*1000*thickness*width),4) as float) as [UNIT TENSION POR ENTRY REF (Kg)]" & vbCrLf &
       ", cast(ROUND(TENSION_POS_ENTRY * 1000/(9.8*1000*thickness*width),4) as float) as [UNIT TENSION POS ENTRY (Kg)]" & vbCrLf &
       ", cast(ROUND(TENSION_TR_REF * 1000/(9.8*1000*thickness*width),4) as float) as [UNIT TENSION TR REF (Kg)]" & vbCrLf &
       ", cast(ROUND(TENSION_TR * 1000/(9.8*1000*thickness*width),4) as float) as [UNIT TENSION TR (Kg)],cast(ROUND(WORK_ROLL_BEND_POS_SET * 102.0408,3) as float) as [WORK ROLL BEND POS SET (Tonne)],cast(ROUND(WORK_ROLL_BEND_POS_ACT * 102.0408,3) as float) as [WORK ROLL BEND POS ACT (Tonne)]" & vbCrLf &
       ",  cast(ROUND(WORK_ROLL_BEND_NEG_SET * 102.0408,3) as float) as [WORK ROLL BEND NEG SET (Tonne)],cast(ROUND(WORK_ROLL_BEND_NEG_ACT * 102.0408,3) as float) as [WORK ROLL BEND NEG ACT (Tonne)], cast(ROUND(YS1,2) as float) as [YS1 (Mpa)], cast(ROUND(YS2,2) as float) as [YS2 (Mpa)], cast(ROUND(YS3,2) as float) as [YS3 (Mpa)]" & vbCrLf &
       " FROM  CRM_SPM_PROCESS_DATA_COILWISE_BODY T left outer join CRM_SPM_Cutoff T1 on T.TDC_No = T1.TDC and ( THICKNESS > Thickness_min  and THICKNESS <= Thickness_max and  WIDTH*1000 > Width_min  and WIDTH*1000 <= Width_max)  where COIL_STARTDATETIME between '" & Convert.ToDateTime(FromDt).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(ToDt).ToString("yyyy-MM-dd HH:mm:ss") & "' and " & Filter & "").Tables(0)

            '       Return objDataHandler.GetDataSetFromQuery("SELECT  MOTHER_COIL_ID, DAUGHTER_COILID_TEXT , DAUGHTER_COILID_NUM , GRADE , THICKNESS , WIDTH , YS , COIL_STARTDATETIME " & vbCrLf & _
            '", C00_COILER_SPEED_SET, C00_COILER_SPEED_ACT, S11_SPEED_SET, S11_SPEED_ACT, C90_COILER_SPEED_SET, C90_COILER_SPEED_ACT, ENLONGATION_SET, ENLONGATION_ACT, ROLLFORCE " & vbCrLf & _
            '", ROLLFORCE_DS, ROLLFORCE_OS, WORK_ROLL_BEND_POS_SET, WORK_ROLL_BEND_POS_ACT, WORK_ROLL_BEND_NEG_SET,WORK_ROLL_BEND_NEG_ACT, ROLL_GAP_DS, ROLL_GAP_OS, TENSION_POR_ENTRY_REF  " & vbCrLf & _
            '", TENSION_POS_ENTRY, TENSION_TR_REF, TENSION_TR FROM  CRM_SPM_PROCESS_DATA_COILWISE_BODY where COIL_STARTDATETIME between '" & Convert.ToDateTime(FromDt).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(ToDt).ToString("yyyy-MM-dd HH:mm:ss") & "' and " & Filter & "").Tables(0)



        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Function
    Public Sub HideGridViewColumns(ByVal GridViewName As GridView)
        GridViewName.Columns(0).Visible = False
        GridViewName.Columns(1).Visible = False
        GridViewName.Columns(3).Visible = False
        GridViewName.Columns(6).Visible = False
        GridViewName.Columns(7).Visible = False
        GridViewName.Columns(8).Visible = False
        GridViewName.Columns(10).Visible = False
        GridViewName.Columns(12).Visible = False
        GridViewName.Columns(14).Visible = False
        GridViewName.Columns(19).Visible = False
        GridViewName.Columns(22).Visible = False
    End Sub
    Public Function GetProcessDataCutOff() As DataTable
        Dim Query As String = "SELECT  * FROM  CRM_SPM_PROCESS_DATA_CUTOFF "
        Return objDataHandler.GetDataSetFromQuery(Query).Tables(0)
    End Function
    Public Function GetSPMProcessData(ByVal TableName As String, ByVal CoilNo As String, ByVal coildate As String) As DataTable
        Dim query As String = ""
        Dim dt As DataTable
        query = "select RAW_DATA_FILE from " & TableName & " where DAUGHTER_COILID_NUM = '" & CoilNo & "' and coil_startdatetime='" & coildate & "'"
        dt = objDataHandler.GetDataSetFromQuery(query).Tables(0)
        Dim bytes() As Byte = dt.Rows(0)(0)
        Dim ms As New MemoryStream
        ms.Write(bytes, 0, bytes.Length)
        Dim ep As New ExcelPackage(ms)
        Return toDataTable(ep)
    End Function
    Function toDataTable(ByRef ep As ExcelPackage) As DataTable
        Dim workSheet As ExcelWorksheet = ep.Workbook.Worksheets.First()
        Dim table As New DataTable
        For i As Integer = 0 To workSheet.Dimension.End.Column - 4
            Dim s = workSheet.Cells(1, i + 1).Text
            If s = "" Then
                s = "C" & i
            End If
            table.Columns.Add(s)
        Next

        'For Each firstRowCell In workSheet.Cells(1, 1, 1, workSheet.Dimension.End.Column - 3)
        '    'If firstRowCell.Text = "" Then
        '    '    table.Columns.Add("C" & i)
        '    '    i += 1
        '    'Else
        '    table.Columns.Add(firstRowCell.Text)
        '    'End If

        'Next
        table.Columns.Add("file")
        table.Columns.Add("slabid")
        For rowNumber As Integer = 2 To workSheet.Dimension.End.Row
            If workSheet.Cells(rowNumber, 5).Text = "" Then
                Exit For
            End If
            Dim row = workSheet.Cells(rowNumber, 1, rowNumber, workSheet.Dimension.End.Column - 3)
            Dim newRow = table.NewRow()
            For Each cell In row
                newRow(cell.Start.Column - 1) = cell.Text
            Next

            table.Rows.Add(newRow)
        Next

        Return table
    End Function
    Public Sub PlotLineChartForSPMCoilWise(ByVal dt As DataTable, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String, ByVal index As String)
        Try

            LiteralName.Text = ""
            'Dim min_time, max_time As String
            'min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-30), "yyyy-MM-dd HH:mm")
            'max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm")

            'Dim xTimestampVal(), yVal() As String
            Dim yVal() As Decimal

            'xTimestampVal = (From row In dt Select col = row(XAxisColName).ToString).ToArray
            'yVal = (From row In dt Select col = CDec(IIf(IsDBNull(row(YAxisColName)), 0, row(YAxisColName))) Where col > 0).ToArray()
            yVal = (From row In dt Select col = CDec(IIf(IsDBNull(row(YAxisColName)), 0, row(YAxisColName)))).ToArray()

            'Dim y_min As String = yVal.Min()
            'Dim y_max As String = yVal.Max()
            Dim y_min As String = yVal.Min() - (10 / 100 * Math.Abs(yVal.Min))
            Dim y_max As String = yVal.Max() + (10 / 100 * Math.Abs(yVal.Max))

            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf
            js &= "var line" & index & " = ["
            For j As Integer = 0 To dt.Rows.Count - 1
                If j > 0 Then
                    js &= ","
                End If
                'js &= "["
                'Dim dtTime As DateTime = dt.Rows(j)(XAxisColName)

                If IsDBNull(dt.Rows(j)(YAxisColName)) = False Then
                    js &= "" & dt.Rows(j)(YAxisColName) & ""
                End If
                'js &= "]"
            Next

            js &= "];" & vbCrLf
            'Dim strg As String = ""
            'Dim strseries As String = ""
            'If flag Then
            '    strg = "[line1"
            '    strseries = " {showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"

            '    strg &= "]"
            'End If
            'js &= "var seriesName = ['"
            'Dim str As String = ""
            'For i As Integer = 0 To dtGroups.Rows.Count - 1
            '    str &= dtGroups.Rows(i)(0).ToString().Trim() + "', '"
            'Next
            'str = str.Remove(str.LastIndexOf(", '"))
            'str &= "];"
            'js &= str
            js &= "opts = {" & vbCrLf &
            "title: '" & ChartTitle & "'," & vbCrLf &
            "seriesDefaults: { showMarker:true,lineWidth: 2,markerOptions: {size: 5}, pointLabels: { show:false },color: '#4832DB', highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr>\ </table>'}}," &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            "fontSize:'8pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "//min: " & vbCrLf &
            "//renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
            "//tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," & vbCrLf &
             "//tickOptions:{formatString:'%12.0f'}," & vbCrLf &
            "//tickInterval:'1 hour'," & vbCrLf &
            "//pad:0," & vbCrLf &
              "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}," & vbCrLf &
            "yaxis: { " & vbCrLf &
            "tickOptions: { formatString: '%12.3f' }," & vbCrLf &
            "min: " & y_min & "," & vbCrLf &
            "max: " & y_max & "," & vbCrLf &
            "autoscale:true," & vbCrLf &
            "label: '" & YAxisLabelName & "'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "showTooltip: false," & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "animate: true," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)'}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "',[line" & index & "],opts);" & vbCrLf &
            "</script>" & vbCrLf

            LiteralName.Text = js
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub
    Public Sub LoadColumnNameForSPMProcessDataCoilWise(ByVal CheckBoxListName As CheckBoxList, ByVal ColumnName As String)
        Dim query As String = ""
        'query = "select 'C00_COILER_SPEED_SET' as C1,'C00 Coiler Speed Set' as C2 union select 'C00_COILER_SPEED_ACT' as C1,'C00 Coiler Speed Act' as C2 union " & _
        '        "select 'S11_SPEED_SET' as C1,'S11 Speed Set' as C2 union select 'S11_SPEED_ACT' as C1,'S11 Speed Act' as C2 union select 'C90_COILER_SPEED_SET' as C1," & _
        '        "'C90 Coiler Speed Set' as C2 union select 'C90_COILER_SPEED_ACT' as C1,'C90 Coiler Speed Act' as C2 union select 'ENLONGATION_SET' as C1,'Enlongation Set' " & _
        '        "as C2 union select 'ENLONGATION_ACT' as C1,'Enlongation Act' as C2 union select 'ROLLFORCE' as C1,'Rollforce' as C2 union select 'ROLLFORCE_DS' as C1," & _
        '        "'Rollforce Ds' as C2 union select 'ROLLFORCE_OS' as C1,'Rollforce Os' as C2 union select 'WORK_ROLL_BEND_POS_SET' as C1,'Work Roll Bend Pos Set' as C2 " & _
        '        "union select 'WORK_ROLL_BEND_POS_ACT' as C1,'Work Roll Bend Pos Act' as C2 union select 'WORK_ROLL_BEND_NEG_SET' as C1,'Work Roll Bend Neg Set' as C2 " & _
        '        "union select 'WORK_ROLL_BEND_NEG_ACT' as C1,'Work Roll Bend Neg Act' as C2 union select 'ROLL_GAP_DS' as C1,'Roll Gap Ds' as C2 union select 'ROLL_GAP_OS'" & _
        '        "as C1,'Roll Gap Os' as C2 union select 'TENSION_POR_ENTRY_REF' as C1,'Tension Por Entry Ref' as C2 union select 'TENSION_POS_ENTRY' as C1,'Tension Pos Entry' as" & _
        '        "C2 union select 'TENSION_TR_REF' as C1,'Tension Tr Ref' as C2 union select 'TENSION_TR' as C1,'Tension Tr' as C2"

        'query = "select 'C00_COILER_SPEED_ACT' as C1,'C00 Coiler Speed Act' as C2 union " & _
        query = " select 'S11_SPEED_ACT' as C1,'S11 Speed Act' as C2 union " &
               " select 'S11_SPEED_ACT' as C1,'S11 Speed Act' as C2 union " &
               " select 'C90_COILER_SPEED_ACT' as C1,'C90 Coiler Speed Act' as C2  " &
               " union select 'ENLONGATION_ACT' as C1,'Enlongation Act' as C2 union select 'ROLLFORCE' as C1,'Rollforce' as C2 union select 'ROLLFORCE_DS' as C1," &
               "'Rollforce Ds' as C2 union select 'ROLLFORCE_OS' as C1,'Rollforce Os' as C2 union select 'WORK_ROLL_BEND_POS_SET' as C1,'Work Roll Bend Pos Set' as C2 " &
               "union select 'WORK_ROLL_BEND_POS_ACT' as C1,'Work Roll Bend Pos Act' as C2 union select 'WORK_ROLL_BEND_NEG_SET' as C1,'Work Roll Bend Neg Set' as C2 " &
               "union select 'WORK_ROLL_BEND_NEG_ACT' as C1,'Work Roll Bend Neg Act' as C2 union select 'ROLL_GAP_DS' as C1,'Roll Gap Ds' as C2 union select 'ROLL_GAP_OS'" &
               "as C1,'Roll Gap Os' as C2 union select 'TENSION_POR_ENTRY_REF' as C1,'Tension Por Entry Ref' as C2 union select 'TENSION_POR_ENTRY' as C1,'Tension Por Entry' as" &
               "C2 union select 'TENSION_TR_REF' as C1,'Tension Tr Ref' as C2 union select 'TENSION_TR' as C1,'Tension Tr' as C2 " &
         "union select 'UNIT_TENSION_POR_ENTRY_REF' as C1,'Unit Tension Por Entry Ref' as C2 union select 'UNIT_TENSION_POR_ENTRY' as C1,'Unit Tension Por Entry' as C2 " &
              " union select 'UNIT_TENSION_TR_REF' as C1,'Unit Tension Tr Ref' as C2 union select 'UNIT_TENSION_TR' as C1,'Unit Tension Tr' as C2 "
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery(query).Tables(0)
        If dt.Rows.Count > 0 Then
            CheckBoxListName.DataSource = dt

            CheckBoxListName.DataTextField = "C2"
            CheckBoxListName.DataValueField = "C1"
            CheckBoxListName.DataBind()
            For i As Integer = 0 To CheckBoxListName.Items.Count - 1
                If CheckBoxListName.Items(i).ToString().Trim.ToLower = ColumnName.Trim.ToLower Then
                    CheckBoxListName.Items(i).Selected = True
                End If


            Next


            'CheckBoxListName.Items.Insert(0, "All")
            'DropDownName.Items.Insert(0, "Select")
            'DropDownName.SelectedIndex = 0
        End If

    End Sub
    ''''''''''''''''''Thermal acpm  19-july-18.......................
    Public Sub PopulateAcpmData(ByVal startdatetime As String, ByVal endDatetime As String, ByVal gdvdetail As GridView, ByVal val As String)

        '---------------------- ingot addition details-------------
        Dim dt_additional_data As DataTable = objDataHandler.GetDataSetFromQuery("SELECT  [CIA_TIMESTAMP] ,[CIA_CGG],[CIA_SHG] ,[CIA_5ALPER],[CIA_CGG_WT],[CIA_SHG_WT],[CIA_5ALPER_WT] FROM [FP_PROCESS_DATA].[dbo].[CGL2_INGOT_ADDITION] " &
              " Where CIA_TIMESTAMP between '" & startdatetime & "' AND '" & endDatetime & "' ORDER BY CIA_TIMESTAMP desc").Tables(0)


        If val = "ThermalModel" Then

            Dim table As New DataTable
            table.Columns.Add("CoilId")
            table.Columns.Add("StartTime")
            table.Columns.Add("Prodcd")
            table.Columns.Add("Duration")
            table.Columns.Add("Thickness")
            table.Columns.Add("Width")
            table.Columns.Add("ZnPotTemp")
            table.Columns.Add("TS_Act")
            table.Columns.Add("TS_Calc")
            table.Columns.Add("∆T")
            table.Columns.Add("Ʃ∆T")
            table.Columns.Add("IndexNo")
            table.Columns.Add("Inductor")
            table.Columns.Add("cgg")
            table.Columns.Add("shg")
            table.Columns.Add("al5")
            table.Columns.Add("In1", GetType(Double))
            table.Columns.Add("In2", GetType(Double))

            Dim sqlQuery As String = "SELECT PRM_id_coil,prm_cd_prod,prm_cd_coat,prm_ts_end as starttime,Prm_sec1_coil as thickness,prm_sec2_coil as width,Prm_dr_work as duration,prm_snt_strp_tmp as stripEntryTemp,prm_zinc_pot_tmp,prm_ln_coil FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] " &
                " Where prm_ts_end between '" & startdatetime & "' AND '" & endDatetime & "' ORDER BY prm_ts_end desc"
            Dim dt As DataTable = objDataHandler.GetDataSetFromQuery(sqlQuery).Tables(0)

            '---------------------- ingot addition start-------------

            'Dim dt_additional_data As DataTable = objDataHandler.GetDataSetFromQuery("SELECT  [CIA_TIMESTAMP] ,[CIA_CGG],[CIA_SHG] ,[CIA_5ALPER] FROM [FP_PROCESS_DATA].[dbo].[CGL2_INGOT_ADDITION] " &
            '    " Where CIA_TIMESTAMP between '" & startdatetime & "' AND '" & endDatetime & "' ORDER BY CIA_TIMESTAMP desc").Tables(0)

            'Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT PRM_ID_COIL,PRM_SEC2_COIL,PRM_SEC1_COIL,PRM_LN_COIL,PRM_SNT_STRP_TMP,PRM_ZINC_POT_TMP,PRM_LINE_SPEED,PRM_DR_WORK,PRM_TTC_AVG,PRM_BTC_AVG,PRM_CD_COAT,PRM_TS_END FROM T_CGL_FUR_PARAM  where PRM_TS_END between '" & strFromDate & "' and '" & strToDate & "'").Tables(0)
            Dim add_time, coil_time_1, coil_time_2 As Date
            If dt.Rows.Count > 0 Then
                For i As Integer = 0 To dt.Rows.Count - 1
                    Dim row As DataRow = table.NewRow
                    row("IndexNo") = i
                    row("CoilId") = dt.Rows(i)("PRM_id_coil")
                    row("StartTime") = dt.Rows(i)("starttime")
                    row("Prodcd") = (dt.Rows(i)("prm_cd_prod"))
                    row("Duration") = dt.Rows(i)("duration")
                    row("Thickness") = Math.Round(dt.Rows(i)("thickness"), 2)
                    row("Width") = Convert.ToInt32(dt.Rows(i)("width"))

                    row("ZnPotTemp") = dt.Rows(i)("prm_zinc_pot_tmp")
                    row("TS_Act") = dt.Rows(i)("stripEntryTemp")


                    If i > 0 Then
                        coil_time_1 = dt(i - 1)("starttime")
                        coil_time_2 = dt(i)("starttime")
                        For ia As Integer = 0 To dt_additional_data.Rows.Count - 1
                            add_time = dt_additional_data(ia)("CIA_TIMESTAMP")
                            If coil_time_1 > add_time And coil_time_2 < add_time Then
                                row("shg") = dt_additional_data(ia)("CIA_SHG") * 1030 ' dgvALFeModel.Rows(j - 1).Cells("ColSHG2").Value + sqldt_addn(i)("CIA_SHG") * 1000
                                row("al5") = dt_additional_data(ia)("CIA_5ALPER") * 100 ' dgvALFeModel.Rows(j - 1).Cells("Col5Per2").Value + sqldt_addn(i)("CIA_5ALPER") * 100
                                row("cgg") = dt_additional_data(ia)("CIA_CGG") * 1100 ' dgvALFeModel.Rows(j - 1).Cells("ColCGG2").Value + sqldt_addn(i)("CIA_CGG") * 1000
                                Exit For
                            End If
                        Next
                    End If

                    Dim dt1 As DataTable = objDataHandler.GetDataSetFromQuery("SELECT [CPI_FROM_DATE],[CPI_TO_DATE],[CPI_IN1_POWER_AVG],[CPI_IN2_POWER_AVG],[CPI_POT_NAME],[CPI_POT_ABBR] FROM [FP_PROCESS_DATA].[dbo].[T_CGL2_POT_IBA] " &
        " Where [CPI_FROM_DATE] between '" & startdatetime & "' AND '" & endDatetime & "' and [CPI_STATUS] = 1 ORDER BY CPI_FROM_DATE desc").Tables(0) ''prm_rcf_strp_tmp

                    Dim induc_start_time, induc_stop_time, coil_time, coil_time_prev As DateTime
                    Dim induct_dur As TimeSpan
                    Dim induct_power_avg, induc_low_mode_avg As Double
                    induc_low_mode_avg = 70
                    row("Inductor") = induc_low_mode_avg
                    'For j As Integer = 0 To dt.Rows.Count - 2
                    coil_time = dt(i)("starttime")
                    Try
                        coil_time_prev = dt(i + 1)("starttime")
                        For k As Integer = 0 To dt1.Rows.Count - 1
                            induc_start_time = dt1(k)("CPI_FROM_DATE")
                            induc_stop_time = dt1(k)("CPI_TO_DATE")
                            row("In1") = dt1(k)("CPI_IN1_POWER_AVG")
                            row("In2") = dt1(k)("CPI_IN2_POWER_AVG")

                            ' conditions for inductor and coil start  , I-inductor, C-coil, S-start, E-end
                            '1.               CS      IS       CE         IE
                            '2.      IS       CS      IE       CE
                            '3.      IS       CS                          IE       CE

                            If (coil_time_prev < induc_start_time And coil_time < induc_stop_time And induc_start_time < coil_time) Then
                                induct_dur = (coil_time - induc_start_time)
                                induct_power_avg = (dt1(k)("CPI_IN1_POWER_AVG") + dt1(k)("CPI_IN2_POWER_AVG"))
                                induct_power_avg = (induct_power_avg * (induct_dur.Minutes) + (dt(i)("duration") - induct_dur.Minutes) * induc_low_mode_avg) / (dt(i)("duration"))
                                'dgvCoilData.Rows(j + 1).Cells(14).Value = Math.Floor(induct_power_avg)
                                row("Inductor") = Math.Floor(induct_power_avg)
                            End If
                            If (coil_time_prev > induc_start_time And coil_time > induc_stop_time And coil_time_prev < induc_stop_time) Then
                                induct_dur = (induc_stop_time - coil_time_prev)
                                induct_power_avg = (dt1(k)("CPI_IN1_POWER_AVG") + dt1(k)("CPI_IN2_POWER_AVG"))
                                induct_power_avg = (induct_power_avg * (induct_dur.Minutes) + (dt(i)("duration") - induct_dur.Minutes) * induc_low_mode_avg) / (dt(i)("duration"))
                                'dgvCoilData.Rows(j + 1).Cells(14).Value = Math.Floor(induct_power_avg)
                                row("Inductor") = Math.Floor(induct_power_avg)
                            End If
                            If (coil_time_prev > induc_start_time And coil_time < induc_stop_time) Then
                                induct_dur = (coil_time - coil_time_prev)
                                induct_power_avg = (dt1(k)("CPI_IN1_POWER_AVG") + dt1(k)("CPI_IN2_POWER_AVG"))
                                'induct_power_avg = (induct_power_avg * (induct_dur.Minutes) + (dt(i + 1)("duration") - induct_dur.Minutes) * induc_low_mode_avg) / (dt(i + 1)("duration"))
                                'dgvCoilData.Rows(j + 1).Cells(14).Value = Math.Floor(induct_power_avg)
                                row("Inductor") = Math.Floor(induct_power_avg)
                            End If


                        Next
                    Catch ex As Exception

                    End Try


                    ' Next



                    table.Rows.Add(row)
                Next
                gdvdetail.DataSource = table
                gdvdetail.DataBind()
                If gdvdetail.Rows.Count > 0 Then
                    gdvdetail.UseAccessibleHeader = True
                    gdvdetail.HeaderRow.TableSection = TableRowSection.TableHeader
                End If
            End If

        ElseIf val = "Al-Fe Model" Then

            Dim table As New DataTable
            table.Columns.Add("CoilId")
            table.Columns.Add("Width")
            table.Columns.Add("Thickness")
            table.Columns.Add("Length")
            table.Columns.Add("SET")
            table.Columns.Add("BathTemp")
            table.Columns.Add("LineSpeed")
            'table.Columns.Add("Duration")
            table.Columns.Add("Coat")
            table.Columns.Add("TopCoat")
            table.Columns.Add("BottomCoat")
            table.Columns.Add("PrmCdProd")
            table.Columns.Add("TestvaAl")
            table.Columns.Add("TestVaFe")
            ' table.Columns.Add("CoatCode")
            table.Columns.Add("StartTime")
            table.Columns.Add("IndexNo")
            table.Columns.Add("Inductor")
            table.Columns.Add("SHG")
            table.Columns.Add("AlPer")
            table.Columns.Add("CGG")
            table.Columns.Add("grade")


            Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT PRM_id_coil,prm_cd_prod,prm_cd_coat,prm_ts_end as starttime,Prm_sec1_coil as thickness,prm_sec2_coil as width,Prm_dr_work as duration,prm_snt_strp_tmp as stripEntryTemp," &
                 " prm_zinc_pot_tmp,prm_ln_coil,PRM_TAS_PRC_SCSPD as PRM_LINE_SPEED,PRM_TTC_AVG,PRM_BTC_AVG,PRM_TEST_VAL_FE,PRM_TEST_VAL_AL,PRM_CD_SURF_ROUGH,prm_cd_grade FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] " &
                  " Where prm_ts_end between '" & startdatetime & "' AND '" & endDatetime & "' ORDER BY prm_ts_end desc").Tables(0)

            'fill AL & Fe value if blank
            If dt.Rows.Count > 1 Then
                For r As Integer = dt.Rows.Count - 2 To 0 Step -1
                    If dt.Rows(r)("PRM_TEST_VAL_FE").ToString = "" Then
                        dt.Rows(r)("PRM_TEST_VAL_FE") = dt.Rows(r + 1)("PRM_TEST_VAL_FE")
                        dt.Rows(r)("PRM_TEST_VAL_AL") = dt.Rows(r + 1)("PRM_TEST_VAL_AL")
                    End If
                Next
            End If

            Dim add_time, coil_time_1, coil_time_2 As Date

            If dt.Rows.Count > 0 Then
                Dim lastTime As DateTime = CDate(dt.Rows(0)("starttime"))
                Dim allab As Double = dt.Rows(0)("PRM_TEST_VAL_AL")
                Dim felab As Double = dt.Rows(0)("PRM_TEST_VAL_FE")
                'Dim dtOra As DataTable = objDataHandler.GetOracleData("select lgc_id_coil, to_char(lgc_ts_end,'YYYY-MM-DD HH24:MI:SS') as lgc_ts_end,pdl_id_coil, pdl_sec1_coil,pdl_sec2_coil,pdl_ln_coil,pdl_grd_steel,pdl_cd_prod,pdl_cd_coat,pdl_tp_coat_amt,pdl_bt_coat_amt,pdl_proc_speed from v_pr_data_ip_cg2, v_cg2_galv_coil where lgc_id_moth_coil = pdl_id_coil and lgc_ts_end > TO_DATE('" & lastTime.ToString("dd-MMM-yyyy HH:mm:ss") & "','DD-MON-YYYY HH24:MI:SS') order by lgc_ts_end desc")

                'Dim dtOra1 As DataTable = objDataHandler.GetOracleData("select distinct lgc_id_coil, to_char(lgc_ts_end,'YYYY-MM-DD HH24:MI:SS') as lgc_ts_end,pdl_id_coil, pdl_sec1_coil,pdl_sec2_coil,lgc_ln_coil,pdl_grd_steel,pdl_cd_prod,pdl_cd_coat,pdl_tp_coat_amt,pdl_bt_coat_amt,pdl_proc_speed,lgc_cd_grade from v_pr_data_ip_cg2, v_cg2_galv_coil where lgc_id_moth_coil = pdl_id_coil and lgc_ts_end > TO_DATE('" & lastTime.ToString("dd-MMM-yyyy HH:mm:ss") & "','DD-MON-YYYY HH24:MI:SS') order by lgc_ts_end desc")
                Dim dtOra As DataTable = objDataHandler.GetOracleData("select cgd_id_coil as id_coil, to_char(cgd_ts_end,'YYYY-MM-DD HH24:MI:SS') as ts_end, cgd_snt_strp_tmp as Entry_temp, cgd_zinc_pot_tmp as Zn_Bath_tmp, cgd_sec1_coil as thickness, cgd_width as width, cgd_ln_coil as coil_ln, cgd_cd_prod as cd_prod, cgd_ttc_avg as tp_avg, cgd_btc_avg as bt_avg, cgd_tas_prc_scspd as linespd, cgd_cd_grade as cd_grade from crmcg2.t_cg2_daughter_rpt  where cgd_ts_end > TO_DATE('" & lastTime.ToString("dd-MMM-yyyy HH:mm:ss") & "','DD-MON-YYYY HH24:MI:SS') order by ts_end desc")

                'table--> crmcg2.t_cg2_daughter_rpt_....., , cgd_work_dur, , cgd_cd_qlty, ,  , , 
                '-------------------------------------------------------------------------
                'This loop for the current processing coil.
                If dtOra.Rows.Count = 0 Then
                    Dim row_online As DataRow = table.NewRow
                    Dim duration As TimeSpan
                    duration = DateTime.Now() - CDate(dt.Rows(0)("starttime"))
                    row_online("CoilId") = "Under process..."
                    row_online("Width") = Convert.ToInt32(dt.Rows(0)("width"))
                    row_online("Thickness") = Math.Round(dt.Rows(0)("thickness"), 1)
                    row_online("Length") = dt.Rows(0)("PRM_LINE_SPEED").ToString * duration.Minutes
                    row_online("SET") = dt.Rows(0)("stripEntryTemp")
                    row_online("BathTemp") = dt.Rows(0)("PRM_ZINC_POT_TMP")

                    If dt.Rows(0)("PRM_LINE_SPEED").ToString = "" Then
                        row_online("LineSpeed") = 100
                    Else
                        row_online("LineSpeed") = Convert.ToInt32(dt.Rows(0)("PRM_LINE_SPEED"))
                    End If
                    'row("Duration") = dt.Rows(i)("duration")
                    row_online("Coat") = dt.Rows(0)("prm_cd_coat")
                    row_online("TopCoat") = dt.Rows(0)("PRM_TTC_AVG")
                    row_online("BottomCoat") = dt.Rows(0)("PRM_BTC_AVG")
                    row_online("PrmCdProd") = dt.Rows(0)("prm_cd_prod")
                    row_online("StartTime") = CDate(DateTime.Now()).ToString("dd-MMM-yyyy HH:mm:ss")
                    row_online("TestvaAl") = dt.Rows(0)("PRM_TEST_VAL_AL")
                    row_online("TestVaFe") = dt.Rows(0)("PRM_TEST_VAL_FE")
                    row_online("grade") = dt.Rows(0)("prm_cd_grade")

                    coil_time_1 = DateTime.Now()
                    coil_time_2 = CDate(dt.Rows(0)("starttime"))
                    For ia As Integer = 0 To dt_additional_data.Rows.Count - 1
                        add_time = dt_additional_data(ia)("CIA_TIMESTAMP")
                        If coil_time_1 > add_time And coil_time_2 < add_time Then
                            'row1("SHG") = dt_additional_data(ia)("CIA_SHG") * 1030
                            'row1("AlPer") = dt_additional_data(ia)("CIA_5ALPER") * 100
                            'row1("CGG") = dt_additional_data(ia)("CIA_CGG") * 1100
                            row_online("SHG") = If(dt_additional_data(ia)("CIA_SHG_WT").ToString <> "", dt_additional_data(ia)("CIA_SHG_WT"), dt_additional_data(ia)("CIA_SHG") * 1030)
                            row_online("AlPer") = If(dt_additional_data(ia)("CIA_5ALPER_WT").ToString <> "", dt_additional_data(ia)("CIA_5ALPER_WT"), dt_additional_data(ia)("CIA_5ALPER") * 100)
                            row_online("CGG") = If(dt_additional_data(ia)("CIA_CGG_WT").ToString <> "", dt_additional_data(ia)("CIA_CGG_WT"), dt_additional_data(ia)("CIA_CGG") * 1030)
                            Exit For
                        End If
                    Next
                    table.Rows.Add(row_online)
                End If
                If dtOra.Rows.Count > 0 Then
                    Dim row_online As DataRow = table.NewRow
                    Dim duration As TimeSpan
                    duration = DateTime.Now() - CDate(dtOra.Rows(0)("ts_end"))
                    row_online("TestvaAl") = allab
                    row_online("TestVaFe") = felab
                    row_online("CoilId") = "Under process..."
                    row_online("Width") = Convert.ToInt32(dtOra.Rows(0)("width"))
                    row_online("Thickness") = Math.Round(dtOra.Rows(0)("thickness"), 1)
                    row_online("Length") = dt.Rows(0)("PRM_LINE_SPEED").ToString * duration.Minutes
                    row_online("SET") = dtOra.Rows(0)("Entry_temp")
                    row_online("BathTemp") = dtOra.Rows(0)("Zn_Bath_tmp")
                    row_online("LineSpeed") = dtOra.Rows(0)("linespd")
                    row_online("Coat") = dt.Rows(0)("prm_cd_coat").ToString
                    row_online("TopCoat") = dtOra.Rows(0)("tp_avg")
                    row_online("BottomCoat") = dtOra.Rows(0)("bt_avg")
                    row_online("PrmCdProd") = dtOra.Rows(0)("cd_prod")
                    row_online("StartTime") = CDate(DateTime.Now()).ToString("dd-MMM-yyyy HH:mm:ss")
                    row_online("grade") = dtOra.Rows(0)("cd_grade")

                    coil_time_1 = DateTime.Now()
                    coil_time_2 = CDate(dtOra.Rows(0)("ts_end"))
                    For ia As Integer = 0 To dt_additional_data.Rows.Count - 1
                        add_time = dt_additional_data(ia)("CIA_TIMESTAMP")
                        If coil_time_1 > add_time And coil_time_2 < add_time Then
                            'row1("SHG") = dt_additional_data(ia)("CIA_SHG") * 1030
                            'row1("AlPer") = dt_additional_data(ia)("CIA_5ALPER") * 100
                            'row1("CGG") = dt_additional_data(ia)("CIA_CGG") * 1100
                            row_online("SHG") = If(dt_additional_data(ia)("CIA_SHG_WT").ToString <> "", dt_additional_data(ia)("CIA_SHG_WT"), dt_additional_data(ia)("CIA_SHG") * 1030)
                            row_online("AlPer") = If(dt_additional_data(ia)("CIA_5ALPER_WT").ToString <> "", dt_additional_data(ia)("CIA_5ALPER_WT"), dt_additional_data(ia)("CIA_5ALPER") * 100)
                            row_online("CGG") = If(dt_additional_data(ia)("CIA_CGG_WT").ToString <> "", dt_additional_data(ia)("CIA_CGG_WT"), dt_additional_data(ia)("CIA_CGG") * 1030)
                            Exit For
                        End If
                    Next


                    table.Rows.Add(row_online)
                End If



                '--------------------------------------------------------------------------

                'This loop is the recent processed coils, where the sql data base gets updated after 1 hour.

                For i As Integer = 0 To dtOra.Rows.Count - 1
                    Dim row1 As DataRow = table.NewRow

                    row1("TestvaAl") = allab
                    row1("TestVaFe") = felab

                    row1("CoilId") = dtOra.Rows(i)("id_coil")
                    row1("Width") = Convert.ToInt32(dtOra.Rows(i)("width"))
                    row1("Thickness") = Math.Round(dtOra.Rows(i)("thickness"), 1)
                    row1("Length") = dtOra.Rows(i)("coil_ln")
                    row1("SET") = dtOra.Rows(i)("Entry_temp")
                    row1("BathTemp") = dtOra.Rows(i)("Zn_Bath_tmp")

                    If dtOra.Rows(i)("linespd").ToString = "" Then
                        row1("LineSpeed") = 100

                    Else
                        row1("LineSpeed") = Convert.ToInt32(dtOra.Rows(i)("linespd"))
                    End If

                    'row1("Duration") = dt.Rows(i)("duration")
                    row1("Coat") = dt.Rows(0)("prm_cd_coat").ToString
                    row1("TopCoat") = dtOra.Rows(i)("tp_avg")
                    row1("BottomCoat") = dtOra.Rows(i)("bt_avg")

                    'row("CoatCode") = dt.Rows(i)("prm_cd_coat")
                    row1("PrmCdProd") = dtOra.Rows(i)("cd_prod")
                    row1("StartTime") = CDate(dtOra.Rows(i)("ts_end")).ToString("dd-MMM-yyyy HH:mm:ss")
                    'row1("TestvaAl") = dt.Rows(i)("PRM_TEST_VAL_AL")
                    'row1("TestVaFe") = dt.Rows(i)("PRM_TEST_VAL_FE")
                    row1("grade") = dtOra.Rows(i)("cd_grade")

                    If i > 0 And i < (dtOra.Rows.Count - 1) Then
                        coil_time_1 = dtOra(i)("ts_end")
                        coil_time_2 = dtOra(i + 1)("ts_end")
                        For ia As Integer = 0 To dt_additional_data.Rows.Count - 1
                            add_time = dt_additional_data(ia)("CIA_TIMESTAMP")
                            If coil_time_1 > add_time And coil_time_2 < add_time Then
                                'row1("SHG") = dt_additional_data(ia)("CIA_SHG") * 1030
                                'row1("AlPer") = dt_additional_data(ia)("CIA_5ALPER") * 100
                                'row1("CGG") = dt_additional_data(ia)("CIA_CGG") * 1100
                                row1("SHG") = If(dt_additional_data(ia)("CIA_SHG_WT").ToString <> "", dt_additional_data(ia)("CIA_SHG_WT"), dt_additional_data(ia)("CIA_SHG") * 1030)
                                row1("AlPer") = If(dt_additional_data(ia)("CIA_5ALPER_WT").ToString <> "", dt_additional_data(ia)("CIA_5ALPER_WT"), dt_additional_data(ia)("CIA_5ALPER") * 100)
                                row1("CGG") = If(dt_additional_data(ia)("CIA_CGG_WT").ToString <> "", dt_additional_data(ia)("CIA_CGG_WT"), dt_additional_data(ia)("CIA_CGG") * 1030)
                                Exit For
                            End If
                        Next
                    End If
                    If (dtOra.Rows.Count - 1) = i Then
                        coil_time_1 = dtOra(i)("ts_end")
                        coil_time_2 = dt(0)("starttime")
                        For ia As Integer = 0 To dt_additional_data.Rows.Count - 1
                            add_time = dt_additional_data(ia)("CIA_TIMESTAMP")
                            If coil_time_1 > add_time And coil_time_2 < add_time Then
                                'row1("SHG") = dt_additional_data(ia)("CIA_SHG") * 1030
                                'row1("AlPer") = dt_additional_data(ia)("CIA_5ALPER") * 100
                                'row1("CGG") = dt_additional_data(ia)("CIA_CGG") * 1100
                                row1("SHG") = If(dt_additional_data(ia)("CIA_SHG_WT").ToString <> "", dt_additional_data(ia)("CIA_SHG_WT"), dt_additional_data(ia)("CIA_SHG") * 1030)
                                row1("AlPer") = If(dt_additional_data(ia)("CIA_5ALPER_WT").ToString <> "", dt_additional_data(ia)("CIA_5ALPER_WT"), dt_additional_data(ia)("CIA_5ALPER") * 100)
                                row1("CGG") = If(dt_additional_data(ia)("CIA_CGG_WT").ToString <> "", dt_additional_data(ia)("CIA_CGG_WT"), dt_additional_data(ia)("CIA_CGG") * 1030)
                                Exit For
                            End If
                        Next
                    End If
                    table.Rows.Add(row1)
                Next



                For i As Integer = 0 To dt.Rows.Count - 1
                    Dim row As DataRow = table.NewRow
                    ' row("IndexNo") = i
                    row("CoilId") = dt.Rows(i)("PRM_id_coil")
                    row("Width") = Convert.ToInt32(dt.Rows(i)("width"))
                    row("Thickness") = Math.Round(dt.Rows(i)("thickness"), 1)
                    row("Length") = dt.Rows(i)("PRM_LN_COIL")
                    row("SET") = dt.Rows(i)("stripEntryTemp")
                    row("BathTemp") = dt.Rows(i)("PRM_ZINC_POT_TMP")

                    If dt.Rows(i)("PRM_LINE_SPEED").ToString = "" Then
                        row("LineSpeed") = 100
                    Else
                        row("LineSpeed") = Convert.ToInt32(dt.Rows(i)("PRM_LINE_SPEED"))
                    End If
                    'row("Duration") = dt.Rows(i)("duration")
                    row("Coat") = dt.Rows(i)("prm_cd_coat")
                    row("TopCoat") = dt.Rows(i)("PRM_TTC_AVG")
                    row("BottomCoat") = dt.Rows(i)("PRM_BTC_AVG")

                    'row("CoatCode") = dt.Rows(i)("prm_cd_coat")
                    row("PrmCdProd") = dt.Rows(i)("prm_cd_prod")
                    row("StartTime") = CDate(dt.Rows(i)("starttime")).ToString("dd-MMM-yyyy HH:mm:ss")
                    row("TestvaAl") = dt.Rows(i)("PRM_TEST_VAL_AL")
                    row("TestVaFe") = dt.Rows(i)("PRM_TEST_VAL_FE")
                    row("grade") = dt.Rows(i)("prm_cd_grade")

                    '---------------ingot addition start---------------

                    If i >= 0 And i <= dt.Rows.Count - 2 Then
                        'coil_time_1 = dt(i - 1)("starttime")
                        'coil_time_2 = dt(i)("starttime")

                        coil_time_1 = dt(i)("starttime")
                        coil_time_2 = dt(i + 1)("starttime")

                        For ia As Integer = 0 To dt_additional_data.Rows.Count - 1
                            add_time = dt_additional_data(ia)("CIA_TIMESTAMP")
                            If coil_time_1 > add_time And coil_time_2 < add_time Then
                                'row("SHG") = dt_additional_data(ia)("CIA_SHG") * 1030
                                'row("AlPer") = dt_additional_data(ia)("CIA_5ALPER") * 100
                                'row("CGG") = dt_additional_data(ia)("CIA_CGG") * 1100
                                row("SHG") = If(dt_additional_data(ia)("CIA_SHG_WT").ToString <> "", dt_additional_data(ia)("CIA_SHG_WT"), dt_additional_data(ia)("CIA_SHG") * 1030)
                                row("AlPer") = If(dt_additional_data(ia)("CIA_5ALPER_WT").ToString <> "", dt_additional_data(ia)("CIA_5ALPER_WT"), dt_additional_data(ia)("CIA_5ALPER") * 100)
                                row("CGG") = If(dt_additional_data(ia)("CIA_CGG_WT").ToString <> "", dt_additional_data(ia)("CIA_CGG_WT"), dt_additional_data(ia)("CIA_CGG") * 1030)
                                Exit For
                            End If
                        Next
                    End If

                    '-------------------ingot addition end ------------------

                    table.Rows.Add(row)
                Next
                gdvdetail.DataSource = table
                gdvdetail.DataBind()
                If gdvdetail.Rows.Count > 0 Then
                    gdvdetail.UseAccessibleHeader = True
                    gdvdetail.HeaderRow.TableSection = TableRowSection.TableHeader
                End If
            End If


        End If
    End Sub

    'Public Sub PopulateAcpmData(ByVal startdatetime As String, ByVal endDatetime As String, ByVal gdvdetail As GridView, ByVal val As String)

    '    If val = "ThermalModel" Then

    '        Dim table As New DataTable
    '        table.Columns.Add("CoilId")
    '        table.Columns.Add("StartTime")
    '        table.Columns.Add("Prodcd")
    '        table.Columns.Add("Duration")
    '        table.Columns.Add("Thickness")
    '        table.Columns.Add("Width")
    '        table.Columns.Add("ZnPotTemp")
    '        table.Columns.Add("TS_Act")
    '        table.Columns.Add("TS_Calc")
    '        table.Columns.Add("∆T")
    '        table.Columns.Add("Ʃ∆T")
    '        table.Columns.Add("IndexNo")
    '        table.Columns.Add("Inductor")
    '        table.Columns.Add("cgg")
    '        table.Columns.Add("shg")
    '        table.Columns.Add("al5")
    '        table.Columns.Add("In1")
    '        table.Columns.Add("In2")

    '        Dim sqlQuery As String = "SELECT PRM_id_coil,prm_cd_prod,prm_cd_coat,prm_ts_end as starttime,Prm_sec1_coil as thickness,prm_sec2_coil as width,Prm_dr_work as duration,prm_snt_strp_tmp as stripEntryTemp,prm_zinc_pot_tmp,prm_ln_coil FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] " &
    '            " Where prm_ts_end between '" & startdatetime & "' AND '" & endDatetime & "' ORDER BY prm_ts_end desc"
    '        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery(sqlQuery).Tables(0)

    '        '---------------------- ingot addition start-------------

    '        Dim dt_additional_data As DataTable = objDataHandler.GetDataSetFromQuery("SELECT  [CIA_TIMESTAMP] ,[CIA_CGG],[CIA_SHG] ,[CIA_5ALPER] FROM [FP_PROCESS_DATA].[dbo].[CGL2_INGOT_ADDITION] " &
    '            " Where CIA_TIMESTAMP between '" & startdatetime & "' AND '" & endDatetime & "' ORDER BY CIA_TIMESTAMP desc").Tables(0)

    '        'Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT PRM_ID_COIL,PRM_SEC2_COIL,PRM_SEC1_COIL,PRM_LN_COIL,PRM_SNT_STRP_TMP,PRM_ZINC_POT_TMP,PRM_LINE_SPEED,PRM_DR_WORK,PRM_TTC_AVG,PRM_BTC_AVG,PRM_CD_COAT,PRM_TS_END FROM T_CGL_FUR_PARAM  where PRM_TS_END between '" & strFromDate & "' and '" & strToDate & "'").Tables(0)
    '        Dim add_time, coil_time_1, coil_time_2 As Date
    '        If dt.Rows.Count > 0 Then
    '            For i As Integer = 0 To dt.Rows.Count - 1
    '                Dim row As DataRow = table.NewRow
    '                row("IndexNo") = i
    '                row("CoilId") = dt.Rows(i)("PRM_id_coil")
    '                row("StartTime") = dt.Rows(i)("starttime")
    '                row("Prodcd") = (dt.Rows(i)("prm_cd_prod"))
    '                row("Duration") = dt.Rows(i)("duration")
    '                row("Thickness") = Math.Round(dt.Rows(i)("thickness"), 2)
    '                row("Width") = Convert.ToInt32(dt.Rows(i)("width"))

    '                row("ZnPotTemp") = dt.Rows(i)("prm_zinc_pot_tmp")
    '                row("TS_Act") = dt.Rows(i)("stripEntryTemp")


    '                If i > 0 Then
    '                    coil_time_1 = dt(i - 1)("starttime")
    '                    coil_time_2 = dt(i)("starttime")
    '                    For ia As Integer = 0 To dt_additional_data.Rows.Count - 1
    '                        add_time = dt_additional_data(ia)("CIA_TIMESTAMP")
    '                        If coil_time_1 > add_time And coil_time_2 < add_time Then
    '                            row("shg") = dt_additional_data(ia)("CIA_SHG") * 1030 ' dgvALFeModel.Rows(j - 1).Cells("ColSHG2").Value + sqldt_addn(i)("CIA_SHG") * 1000
    '                            row("al5") = dt_additional_data(ia)("CIA_5ALPER") * 100 ' dgvALFeModel.Rows(j - 1).Cells("Col5Per2").Value + sqldt_addn(i)("CIA_5ALPER") * 100
    '                            row("cgg") = dt_additional_data(ia)("CIA_CGG") * 1100 ' dgvALFeModel.Rows(j - 1).Cells("ColCGG2").Value + sqldt_addn(i)("CIA_CGG") * 1000
    '                            Exit For
    '                        End If
    '                    Next
    '                End If

    '                Dim dt1 As DataTable = objDataHandler.GetDataSetFromQuery("SELECT [CPI_FROM_DATE],[CPI_TO_DATE],[CPI_IN1_POWER_AVG],[CPI_IN2_POWER_AVG],[CPI_POT_NAME],[CPI_POT_ABBR] FROM [FP_PROCESS_DATA].[dbo].[T_CGL2_POT_IBA] " &
    '    " Where [CPI_FROM_DATE] between '" & startdatetime & "' AND '" & endDatetime & "' and [CPI_STATUS] = 1 ORDER BY CPI_FROM_DATE desc").Tables(0) ''prm_rcf_strp_tmp

    '                Dim induc_start_time, induc_stop_time, coil_time, coil_time_prev As DateTime
    '                Dim induct_dur As TimeSpan
    '                Dim induct_power_avg, induc_low_mode_avg As Double
    '                induc_low_mode_avg = 70
    '                row("Inductor") = induc_low_mode_avg
    '                'For j As Integer = 0 To dt.Rows.Count - 2
    '                coil_time = dt(i)("starttime")
    '                Try
    '                    coil_time_prev = dt(i + 1)("starttime")
    '                    For k As Integer = 0 To dt1.Rows.Count - 1
    '                        induc_start_time = dt1(k)("CPI_FROM_DATE")
    '                        induc_stop_time = dt1(k)("CPI_TO_DATE")
    '                        row("In1") = dt1(k)("CPI_IN1_POWER_AVG")
    '                        row("In2") = dt1(k)("CPI_IN2_POWER_AVG")

    '                        ' conditions for inductor and coil start  , I-inductor, C-coil, S-start, E-end
    '                        '1.               CS      IS       CE         IE
    '                        '2.      IS       CS      IE       CE
    '                        '3.      IS       CS                          IE       CE

    '                        If (coil_time_prev < induc_start_time And coil_time < induc_stop_time And induc_start_time < coil_time) Then
    '                            induct_dur = (coil_time - induc_start_time)
    '                            induct_power_avg = (dt1(k)("CPI_IN1_POWER_AVG") + dt1(k)("CPI_IN2_POWER_AVG"))
    '                            induct_power_avg = (induct_power_avg * (induct_dur.Minutes) + (dt(i)("duration") - induct_dur.Minutes) * induc_low_mode_avg) / (dt(i)("duration"))
    '                            'dgvCoilData.Rows(j + 1).Cells(14).Value = Math.Floor(induct_power_avg)
    '                            row("Inductor") = Math.Floor(induct_power_avg)
    '                        End If
    '                        If (coil_time_prev > induc_start_time And coil_time > induc_stop_time And coil_time_prev < induc_stop_time) Then
    '                            induct_dur = (induc_stop_time - coil_time_prev)
    '                            induct_power_avg = (dt1(k)("CPI_IN1_POWER_AVG") + dt1(k)("CPI_IN2_POWER_AVG"))
    '                            induct_power_avg = (induct_power_avg * (induct_dur.Minutes) + (dt(i)("duration") - induct_dur.Minutes) * induc_low_mode_avg) / (dt(i)("duration"))
    '                            'dgvCoilData.Rows(j + 1).Cells(14).Value = Math.Floor(induct_power_avg)
    '                            row("Inductor") = Math.Floor(induct_power_avg)
    '                        End If
    '                        If (coil_time_prev > induc_start_time And coil_time < induc_stop_time) Then
    '                            induct_dur = (coil_time - coil_time_prev)
    '                            induct_power_avg = (dt1(k)("CPI_IN1_POWER_AVG") + dt1(k)("CPI_IN2_POWER_AVG"))
    '                            'induct_power_avg = (induct_power_avg * (induct_dur.Minutes) + (dt(i + 1)("duration") - induct_dur.Minutes) * induc_low_mode_avg) / (dt(i + 1)("duration"))
    '                            'dgvCoilData.Rows(j + 1).Cells(14).Value = Math.Floor(induct_power_avg)
    '                            row("Inductor") = Math.Floor(induct_power_avg)
    '                        End If


    '                    Next
    '                Catch ex As Exception

    '                End Try


    '                ' Next



    '                table.Rows.Add(row)
    '            Next
    '            gdvdetail.DataSource = table
    '            gdvdetail.DataBind()
    '            If gdvdetail.Rows.Count > 0 Then
    '                gdvdetail.UseAccessibleHeader = True
    '                gdvdetail.HeaderRow.TableSection = TableRowSection.TableHeader
    '            End If
    '        End If

    '    ElseIf val = "Al-Fe Model" Then

    '        Dim table As New DataTable
    '        table.Columns.Add("CoilId")
    '        table.Columns.Add("Width")
    '        table.Columns.Add("Thickness")
    '        table.Columns.Add("Length")
    '        table.Columns.Add("SET")
    '        table.Columns.Add("BathTemp")
    '        table.Columns.Add("LineSpeed")
    '        'table.Columns.Add("Duration")
    '        table.Columns.Add("Coat")
    '        table.Columns.Add("TopCoat")
    '        table.Columns.Add("BottomCoat")
    '        table.Columns.Add("PrmCdProd")
    '        table.Columns.Add("TestvaAl")
    '        table.Columns.Add("TestVaFe")
    '        ' table.Columns.Add("CoatCode")
    '        table.Columns.Add("StartTime")
    '        table.Columns.Add("IndexNo")
    '        table.Columns.Add("Inductor")
    '        table.Columns.Add("SHG")
    '        table.Columns.Add("AlPer")
    '        table.Columns.Add("CGG")


    '        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT PRM_id_coil,prm_cd_prod,prm_cd_coat,prm_ts_end as starttime,Prm_sec1_coil as thickness,prm_sec2_coil as width,Prm_dr_work as duration,prm_snt_strp_tmp as stripEntryTemp," &
    '             " prm_zinc_pot_tmp,prm_ln_coil,PRM_TAS_PRC_SCSPD as PRM_LINE_SPEED,PRM_TTC_AVG,PRM_BTC_AVG,PRM_TEST_VAL_FE,PRM_TEST_VAL_AL,PRM_CD_SURF_ROUGH FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] " &
    '              " Where prm_ts_end between '" & startdatetime & "' AND '" & endDatetime & "' ORDER BY prm_ts_end desc").Tables(0)

    '        'fill AL & Fe value if blank
    '        If dt.Rows.Count > 1 Then
    '            For r As Integer = dt.Rows.Count - 2 To 0 Step -1
    '                If dt.Rows(r)("PRM_TEST_VAL_FE").ToString = "" Then
    '                    dt.Rows(r)("PRM_TEST_VAL_FE") = dt.Rows(r + 1)("PRM_TEST_VAL_FE")
    '                    dt.Rows(r)("PRM_TEST_VAL_AL") = dt.Rows(r + 1)("PRM_TEST_VAL_AL")
    '                End If
    '            Next
    '        End If

    '        '---------------inductor start------------------'
    '        Dim dt1 As DataTable = objDataHandler.GetDataSetFromQuery("SELECT [CPI_FROM_DATE],[CPI_TO_DATE],[CPI_IN1_POWER_AVG],[CPI_IN2_POWER_AVG],[CPI_POT_NAME],[CPI_POT_ABBR] FROM [FP_PROCESS_DATA].[dbo].[T_CGL2_POT_IBA] " &
    '                " Where [CPI_FROM_DATE] between '" & startdatetime & "' AND '" & endDatetime & "' and [CPI_POT_NAME] = 'POT1' ORDER BY CPI_FROM_DATE desc").Tables(0) ''prm_rcf_strp_tmp

    '        Dim induc_start_time, induc_stop_time, coil_time, coil_time_prev As DateTime
    '        Dim induct_dur As TimeSpan
    '        Dim induct_power_avg, induc_low_mode_avg As Double
    '        induc_low_mode_avg = 35
    '        '---------------inductor end---------------------


    '        '---------------------- ingot addition start-------------

    '        Dim dt_additional_data As DataTable = objDataHandler.GetDataSetFromQuery("SELECT  [CIA_TIMESTAMP] ,[CIA_CGG],[CIA_SHG] ,[CIA_5ALPER] FROM [FP_PROCESS_DATA].[dbo].[CGL2_INGOT_ADDITION] " &
    '            " Where CIA_TIMESTAMP between '" & startdatetime & "' AND '" & endDatetime & "' ORDER BY CIA_TIMESTAMP desc").Tables(0)
    '        'If dt_additional_data.Rows.Count > 0 Then
    '        '    For ia As Integer = 0 To dt_additional_data.Rows.Count - 1
    '        '        row("SHG") = dt_additional_data(ia)("CIA_SHG")
    '        '        row("AlPer") = dt_additional_data(ia)("CIA_5ALPER")
    '        '        row("CGG") = dt_additional_data(ia)("CIA_CGG")

    '        '    Next
    '        'End If

    '        'dgvALFeModel.Rows(SqlDt.Rows.Count - 1).Cells("ColCalAl").Value = txtbathAl.Text
    '        'dgvALFeModel.Rows(SqlDt.Rows.Count - 1).Cells("ColCalFe").Value = txtBathFe.Text
    '        Dim add_time, coil_time_1, coil_time_2 As Date

    '        '--------------------ingot addition end loop------------------


    '        If dt.Rows.Count > 0 Then
    '            For i As Integer = 0 To dt.Rows.Count - 1
    '                Dim row As DataRow = table.NewRow
    '                ' row("IndexNo") = i
    '                row("CoilId") = dt.Rows(i)("PRM_id_coil")
    '                row("Width") = Convert.ToInt32(dt.Rows(i)("width"))
    '                row("Thickness") = Math.Round(dt.Rows(i)("thickness"), 1)
    '                row("Length") = dt.Rows(i)("PRM_LN_COIL")
    '                row("SET") = dt.Rows(i)("stripEntryTemp")
    '                row("BathTemp") = dt.Rows(i)("PRM_ZINC_POT_TMP")

    '                If dt.Rows(i)("PRM_LINE_SPEED").ToString = "" Then
    '                    row("LineSpeed") = 100

    '                Else
    '                    row("LineSpeed") = Convert.ToInt32(dt.Rows(i)("PRM_LINE_SPEED"))
    '                End If

    '                'row("Duration") = dt.Rows(i)("duration")
    '                row("Coat") = dt.Rows(i)("prm_cd_coat")
    '                row("TopCoat") = dt.Rows(i)("PRM_TTC_AVG")
    '                row("BottomCoat") = dt.Rows(i)("PRM_BTC_AVG")

    '                'row("CoatCode") = dt.Rows(i)("prm_cd_coat")
    '                row("PrmCdProd") = dt.Rows(i)("prm_cd_prod")
    '                row("StartTime") = CDate(dt.Rows(i)("starttime")).ToString("dd-MMM-yyyy HH:mm:ss")
    '                row("TestvaAl") = dt.Rows(i)("PRM_TEST_VAL_AL")
    '                row("TestVaFe") = dt.Rows(i)("PRM_TEST_VAL_FE")


    '                '----------inductor start loop---------------
    '                'If i <= dt.Rows.Count - 2 Then
    '                '    coil_time = dt(i)("starttime")
    '                '    coil_time_prev = dt(i + 1)("starttime")
    '                '    For k As Integer = 0 To dt1.Rows.Count - 1
    '                '        induc_start_time = dt1(k)("CPI_FROM_DATE")
    '                '        induc_stop_time = dt1(k)("CPI_TO_DATE")

    '                '        If (coil_time_prev < induc_start_time And coil_time > induc_stop_time) Or (coil_time > induc_start_time And coil_time_prev < induc_stop_time) Then
    '                '            induct_dur = (induc_stop_time - induc_start_time)
    '                '            induct_power_avg = (dt1(k)("CPI_IN1_POWER_AVG") + dt1(k)("CPI_IN2_POWER_AVG")) / 2
    '                '            induct_power_avg = (induct_power_avg * (induct_dur.Minutes) + (dt(i + 1)("duration") - induct_dur.Minutes) * induc_low_mode_avg) / (dt(i + 1)("duration"))
    '                '            'dgvALFeModel.Rows(j + 1).Cells(20).Value = Math.Floor(induct_power_avg)
    '                '            row("Inductor") = Math.Floor(induct_power_avg)
    '                '        Else
    '                '            'dgvALFeModel.Rows(j + 1).Cells(20).Value = induc_low_mode_avg
    '                '            row("Inductor") = induc_low_mode_avg
    '                '        End If
    '                '    Next
    '                'End If
    '                '---------------inductor end loop------------------



    '                '---------------ingot addition start---------------

    '                If i > 0 Then
    '                    coil_time_1 = dt(i - 1)("starttime")
    '                    coil_time_2 = dt(i)("starttime")
    '                    For ia As Integer = 0 To dt_additional_data.Rows.Count - 1
    '                        add_time = dt_additional_data(ia)("CIA_TIMESTAMP")
    '                        If coil_time_1 > add_time And coil_time_2 < add_time Then
    '                            row("SHG") = dt_additional_data(ia)("CIA_SHG") * 1030 ' dgvALFeModel.Rows(j - 1).Cells("ColSHG2").Value + sqldt_addn(i)("CIA_SHG") * 1000
    '                            row("AlPer") = dt_additional_data(ia)("CIA_5ALPER") * 100 ' dgvALFeModel.Rows(j - 1).Cells("Col5Per2").Value + sqldt_addn(i)("CIA_5ALPER") * 100
    '                            row("CGG") = dt_additional_data(ia)("CIA_CGG") * 1100 ' dgvALFeModel.Rows(j - 1).Cells("ColCGG2").Value + sqldt_addn(i)("CIA_CGG") * 1000
    '                            Exit For
    '                        End If
    '                    Next
    '                End If

    '                '-------------------ingot addition end ------------------




    '                table.Rows.Add(row)
    '            Next
    '            gdvdetail.DataSource = table
    '            gdvdetail.DataBind()
    '            If gdvdetail.Rows.Count > 0 Then
    '                gdvdetail.UseAccessibleHeader = True
    '                gdvdetail.HeaderRow.TableSection = TableRowSection.TableHeader
    '            End If
    '        End If


    '    End If
    'End Sub

    Public Function GetAdditionalData(ByVal startdatetime As String, ByVal endDatetime As String) As DataTable
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT  [CIA_TIMESTAMP] ,[CIA_CGG],[CIA_SHG] ,[CIA_5ALPER] FROM [FP_PROCESS_DATA].[dbo].[CGL2_INGOT_ADDITION] " &
        " Where CIA_TIMESTAMP between '" & startdatetime & "' AND '" & endDatetime & "' ORDER BY CIA_TIMESTAMP desc").Tables(0)

        Return dt
    End Function
    Public Function GetStartTime(ByVal startdatetime As String, ByVal endDatetime As String) As DataTable

        Dim sqlQuery1 As String = "SELECT top 6 [CZT_TIMESTAMP] ,[CZT_POT_AL],[CZT_POT_FE] ,[CZT_POT_TEMP] FROM [FP_PROCESS_DATA].[dbo].[CGL2_ZNBATH_TREND] " &
           " Where CZT_TIMESTAMP between '" & startdatetime & "' AND '" & endDatetime & "' order by 1 desc"
        Dim dt1 As DataTable = objDataHandler.GetDataSetFromQuery(sqlQuery1).Tables(0)

        Dim sqlQuery As String = "SELECT top 6 [CZT_TIMESTAMP] ,[CZT_POT_AL],[CZT_POT_FE] ,[CZT_POT_TEMP] FROM [FP_PROCESS_DATA].[dbo].[CGL2_ZNBATH_TREND] " &
           " Where CZT_TIMESTAMP between '" & startdatetime & "' AND '" & endDatetime & "' order by 1 desc"
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery(sqlQuery).Tables(0)
        Return dt
    End Function
    Public Function GetDataForAcpmThermalGalvBath(ByVal startdatetime As String, ByVal endDatetime As String) As DataTable
        Dim sqlQuery As String = "SELECT PRM_id_coil,prm_cd_prod,prm_cd_coat,prm_ts_end as starttime,Prm_sec1_coil as thickness,prm_sec2_coil as width,Prm_dr_work as duration,prm_snt_strp_tmp as stripEntryTemp," &
         " prm_zinc_pot_tmp,prm_ln_coil,PRM_TAS_PRC_SCSPD as PRM_LINE_SPEED,PRM_TTC_AVG,PRM_BTC_AVG,PRM_TEST_VAL_FE,PRM_TEST_VAL_AL,PRM_CD_SURF_ROUGH,PRM_CD_GRADE as grade FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] " &
            " Where prm_ts_end between '" & startdatetime & "' AND '" & endDatetime & "' ORDER BY prm_ts_end desc"
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery(sqlQuery).Tables(0)
        Return dt
    End Function

    Public Function GetIngotForAlFe(ByVal startdate As String, ByVal enddate As String) As DataTable

        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT * FROM [FP_PROCESS_DATA].[dbo].[cgl2_ingot_addition]  where Cia_TIMESTAMP between '" & startdate & "' and '" & enddate & "'  ").Tables(0)
        Return dt
    End Function

    Public Function GetZnBathTrendForAcpm(ByVal startdate As String, ByVal enddate As String) As DataTable

        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT CZT_POT_AL,  CZT_EFF_AL,CZT_TIMESTAMP,CZT_POT_FE FROM [FP_PROCESS_DATA].[dbo].[CGL2_ZNBATH_TREND]  where CZT_TIMESTAMP between '" & startdate & "' and '" & enddate & "'  ").Tables(0)
        Return dt
    End Function
    Public Function GetZnBathTrendForAcpm_ALEFF(ByVal proc_date As String) As DataTable

        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT top 1 [PRM_ZINC_POT_TMP],abs(datediff(SECOND,[PRM_TS_END],'" & proc_date & "' )) ,[PRM_TS_END] " &
                                                                 " FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where [PRM_TS_END] > DATEADD(DAY,-1,'" & proc_date & "') " &
                                                                 " order by abs(datediff(SECOND,[PRM_TS_END],'" & proc_date & "')) asc ").Tables(0)
        Return dt
    End Function
    Public Sub PlotLineChartForThermaAcpm_GalvBathThermalModel(ByVal Xaxis() As String, ByVal StAct() As String, ByVal StCalc() As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal val As String)
        Try

            Dim min_time, max_time As String

            Dim Al_min As String = 0 'Changed by mamta on 11-Jan-2018
            Dim Al_max As String = 0.3 'Changed by mamta on 11-Jan-2018
            Dim Fe_min As String = 0 'Changed by mamta on 11-Jan-2018
            Dim Fe_max As String = 0.05 'Changed by mamta on 11-Jan-2018



            Dim data1 As String = "var data1=["
            Dim data2 As String = "var data2=["

            For i = 0 To Xaxis.Length - 1
                If i > 0 Then
                    data1 &= ","
                    data2 &= ","
                End If
                data1 &= "['" & CDate(Xaxis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & IIf(StAct(i) = "&nbsp;", "", StAct(i)) & "]"
                ' data1 &= "['" & CDate(Xaxis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & IIf(String.IsNullOrEmpty(StAct(i)), "0", StAct(i)) & "]"
                data2 &= "['" & CDate(Xaxis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & IIf(StCalc(i) = "&nbsp;", "", StCalc(i)) & "]"


            Next
            data1 &= "];"
            data2 &= "];"

            Dim s, s1 As String
            If val = "Al-Fe" Then

                s = "Al(Act)"
                s1 = "Al(Calc)"
            Else
                s = "Strip Temp(Act)"
                s1 = "Strip Temp(Cacl)"


            End If


            Dim Series As String = "{pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#0D5CA5; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td><center>%s</center></td></tr></table>'}}"
            Dim Series1 As String = "{pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#BC2318; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td><center>%s</center></td></tr></table>'}}"

            Dim js = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$(document).ready(function(){" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf &
                    "var series= ['" & s & "', '" & s1 & "']" & vbCrLf &
                    data1 & vbCrLf & data2 & vbCrLf &
            "opts = {" & vbCrLf &
            "//title: 'Calculated Effective Al & Fe'," & vbCrLf &
            "series:[" & Series & ", " & Series1 & "]," & vbCrLf &
            "seriesColors: ['#0D5CA5', '#BC2318']," & vbCrLf &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            "fontSize:'8pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "//min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf &
            "renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
            "tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," & vbCrLf &
            "//tickInterval:'1 hour'," & vbCrLf &
            "pad:0" & vbCrLf &
            "}," & vbCrLf &
            "yaxis: {min:400,max:520,numberTicks:9, " & vbCrLf &
            "tickOptions: { formatString: '%d' }," & vbCrLf &
            "//min: " & Al_min & "," & vbCrLf &
            "//max: " & Al_max & "," & vbCrLf &
            "//autoscale:true," & vbCrLf &
            "//label: '% Effective Al'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "//highlighter: { show: 'true', tooltipFormatString: '%.1f', useAxesFormatters: false }," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
            "legend: {" & vbCrLf &
            "show: true," & vbCrLf &
            "location: 's'," & vbCrLf &
            "labels: series," & vbCrLf &
            "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
            "placement: 'outsideGrid'," & vbCrLf &
            "rendererOptions: {" & vbCrLf &
            "numberRows: 1," & vbCrLf &
            "numberColumns: 2," & vbCrLf &
            "marginTop: 10" & vbCrLf &
            "}" & vbCrLf &
            "}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "',[data1, data2], opts);" & vbCrLf &
            "});" & vbCrLf &
            "</script>" & vbCrLf

            LiteralName.Text = js
        Catch ex As Exception

        End Try
    End Sub
    Public Sub PlotLineChartForThermaAcpm(ByVal Xaxis() As String, ByVal X1axis() As String, ByVal X2axis() As String, ByVal StAct() As String, ByVal StCalc() As String, ByVal StCalcAl_total_Pred() As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal val As String)
        Try

            Dim min_time, max_time As String

            Dim Al_min As String = 0 'Changed by mamta on 11-Jan-2018
            Dim Al_max As String = 0.3 'Changed by mamta on 11-Jan-2018
            Dim Fe_min As String = 0 'Changed by mamta on 11-Jan-2018
            Dim Fe_max As String = 0.05 'Changed by mamta on 11-Jan-2018



            Dim data1 As String = "var data1=["
            Dim data2 As String = "var data2=["
            Dim data3 As String = "var data3=["

            'For i = 0 To Xaxis.Length - 1
            '    If i > 0 Then
            '        data1 &= ","
            '        data2 &= ","
            '    End If
            '    data1 &= "['" & CDate(Xaxis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & IIf(StAct(i) = "&nbsp;", "", StAct(i)) & "]"
            '    ' data1 &= "['" & CDate(Xaxis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & IIf(String.IsNullOrEmpty(StAct(i)), "0", StAct(i)) & "]"
            '    data2 &= "['" & CDate(Xaxis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & IIf(StCalc(i) = "&nbsp;", "", StCalc(i)) & "]"


            'Next
            'data1 &= "];"
            'data2 &= "];"


            For i = 0 To X1axis.Length - 1
                If i > 0 Then
                    data1 &= ","
                    ' data2 &= ","
                End If

                data1 &= "['" & CDate(X1axis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & IIf(String.IsNullOrEmpty(StAct(i)), "0", StAct(i)) & "]"


            Next
            data1 &= "];"

            For i = 0 To Xaxis.Length - 1
                If i > 0 Then
                    ' data1 &= ","
                    data2 &= ","
                End If

                data2 &= "['" & CDate(Xaxis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & IIf(String.IsNullOrEmpty(StCalc(i)), "0", StCalc(i)) & "]"

            Next




            data2 &= "];"


            For i = 0 To X2axis.Length - 1
                If i > 0 Then
                    ' data1 &= ","
                    data3 &= ","
                End If

                data3 &= "['" & CDate(X2axis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & IIf(String.IsNullOrEmpty(StCalcAl_total_Pred(i)), "0", StCalcAl_total_Pred(i)) & "]"

            Next


            data3 &= "];"

            Dim s, s1, s2 As String
            If val = "Al-Fe" Then

                s = "Al(Act)"
                s1 = "Al(Calc)"
                s2 = "Al_Tot(Pred)"
            Else
                s = "Strip Temp(Act)"
                s1 = "Strip Temp(Cacl)"
                s2 = ""

            End If


            Dim Series As String = "{pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#0D5CA5; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td>Al(Act):<td><td><center>%s</center></td></tr></table>'}}"
            Dim Series1 As String = "{pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#BC2318; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td>Al(Calc):<td><td><center>%s</center></td></tr></table>'}}"
            Dim Series2 As String = "{pointLabels: { show:false }, showLine:true, lineWidth: 1,linePattern: 'dashed',showMarker: false, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#BC2318; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td>Al_tot(Pred):<td><td><center>%s</center></td></tr></table>'}}"

            Dim js = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$(document).ready(function(){" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf &
                    "var series= ['" & s & "', '" & s1 & "','" & s2 & "']" & vbCrLf &
                    data1 & vbCrLf & data2 & vbCrLf & data3 & vbCrLf &
            "opts = {" & vbCrLf &
            "//title: 'Calculated Effective Al & Fe'," & vbCrLf &
            "series:[" & Series & ", " & Series1 & "," & Series2 & "]," & vbCrLf &
            "seriesColors: ['#0D5CA5', '#BC2318','#BC2318']," & vbCrLf &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            "fontSize:'8pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "//min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf &
            "renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
            "tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," & vbCrLf &
            "//tickInterval:'1 hour'," & vbCrLf &
            "pad:0" & vbCrLf &
            "}," & vbCrLf &
            "yaxis: { " & vbCrLf &
            "tickOptions: { formatString: '%.3f' }," & vbCrLf &
            "//min: " & Al_min & "," & vbCrLf &
            "//max: " & Al_max & "," & vbCrLf &
            "//autoscale:true," & vbCrLf &
            "label: 'Al Total'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "//highlighter: { show: 'true', tooltipFormatString: '%.1f', useAxesFormatters: false }," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
            "legend: {" & vbCrLf &
            "show: true," & vbCrLf &
            "location: 's'," & vbCrLf &
            "labels: series," & vbCrLf &
            "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
            "placement: 'outsideGrid'," & vbCrLf &
            "rendererOptions: {" & vbCrLf &
            "numberRows: 1," & vbCrLf &
            "numberColumns: 6," & vbCrLf &
            "marginTop: 10" & vbCrLf &
            "}" & vbCrLf &
            "}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "',[data1, data2, data3], opts);" & PlotName & ".resetZoom();" & vbCrLf &
            "});" & vbCrLf &
            "</script>" & vbCrLf

            LiteralName.Text = js
        Catch ex As Exception

        End Try
    End Sub
    Public Sub PlotLineChartForThermaAcpm2_Modified(ByVal Xaxis() As String, ByVal X1axis() As String, ByVal X2axis() As String, ByVal X3axis() As String, ByVal StAct() As String, ByVal StCalc() As String, ByVal SHG() As Double, ByVal CGG() As Double, ByVal AlPer() As Double, ByVal Al_Pred() As String, ByVal SHGFirstGrid() As String, ByVal CggFirstGrid() As String, ByVal AlPerFirstGrid() As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal val As String, ByRef hf1 As HiddenField, ByRef hf2 As HiddenField, ByRef hf3 As HiddenField, Optional ByVal newseries(,) As String = Nothing)
        Try

            Dim min_time, max_time As String

            Dim Al_min As String = 0
            Dim Al_max As String = 0.3
            Dim Fe_min As String = 0
            Dim Fe_max As String = 0.05


            Dim data1 As String = "["
            Dim data2 As String = "["
            Dim data3 As String = "["
            Dim data4 As String = "["
            Dim data5 As String = "["
            Dim data6 As String = "["
            Dim data7 As String = "["
            Dim data8 As String = "["
            Dim data9 As String = "["

            For i = 0 To X1axis.Length - 1
                If i > 0 Then
                    data1 &= ","
                    ' data2 &= ","
                End If

                data1 &= "['" & CDate(X1axis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & IIf(String.IsNullOrEmpty(StAct(i)), "0", StAct(i)) & "]"



            Next
            data1 &= "]"


            For i = 0 To Xaxis.Length - 1
                'If i > 0 Then
                '    ' data1 &= ","
                '    data2 &= ","
                'End If

                data2 &= "['" & CDate(Xaxis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & IIf(String.IsNullOrEmpty(StCalc(i)), "0", StCalc(i)) & "],"
                If newseries Is Nothing Then
                    If SHGFirstGrid(i) <> "&nbsp;" And SHGFirstGrid(i) <> "0" Then

                        data7 &= "['" & CDate(Xaxis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & SHGFirstGrid(i) / 1000 & "],"
                    End If
                    If CggFirstGrid(i) <> "&nbsp;" And CggFirstGrid(i) <> "0" Then

                        data8 &= "['" & CDate(Xaxis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & CggFirstGrid(i) / 1000 & "],"
                    End If
                    If AlPerFirstGrid(i) <> "&nbsp;" And AlPerFirstGrid(i) <> "0" Then
                        data9 &= "['" & CDate(Xaxis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & AlPerFirstGrid(i) / 1000 & "],"
                    End If
                End If
            Next

            If Not newseries Is Nothing Then
                ' HttpContext.Current.Response.Write(data7)
                For j As Integer = 0 To newseries.GetUpperBound(0)
                    If newseries(j, 1) <> "0" Then
                        data7 &= "['" & newseries(j, 0) & "'," & newseries(j, 1) / 1000 & "],"
                    End If
                    If newseries(j, 2) <> "0" Then
                        data8 &= "['" & newseries(j, 0) & "'," & newseries(j, 2) / 1000 & "],"
                    End If
                    If newseries(j, 3) <> "0" Then
                        data9 &= "['" & newseries(j, 0) & "'," & newseries(j, 3) / 1000 & "],"
                    End If
                Next
            End If


            data2 &= "]"
            data7 &= "]"
            data8 &= "]"
            data9 &= "]"

            For i = 0 To X3axis.Length - 1
                'If i > 0 Then
                '    data3 &= ","
                '    data4 &= ","
                '    data5 &= ","
                'End If
                If SHG(i) <> 0 Then
                    data3 &= "['" & CDate(X3axis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & SHG(i) / 1000 & "],"
                End If
                If CGG(i) <> 0 Then

                    data4 &= "['" & CDate(X3axis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & CGG(i) / 1000 & "],"
                End If
                If AlPer(i) <> 0 Then
                    data5 &= "['" & CDate(X3axis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & AlPer(i) / 1000 & "],"
                End If
                'data6 &= "['" & CDate(X3axis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & IIf(String.IsNullOrEmpty(Al_Pred(i)), "0", Al_Pred(i)) & "],"

            Next




            data3 &= "]"
            data4 &= "]"
            data5 &= "]"

            For i = 0 To X2axis.Length - 1
                If i > 0 Then
                    data6 &= ","
                    ' data2 &= ","
                End If

                data6 &= "['" & CDate(X2axis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & IIf(String.IsNullOrEmpty(Al_Pred(i)), "0", Al_Pred(i)) & "]"



            Next

            data6 &= "]"

            Dim s, s1, s2, s3, s4, s5, s6, s7, s8 As String
            If val = "Al-Fe" Then

                s = "AlEffective(Act)"
                s1 = "AlEffective(Calc)"
                s2 = "SHG"
                s3 = "CGG"
                s4 = "Al"
                s5 = "Al_Pred"
                s6 = "SHG"
                s7 = "CGG"
                s8 = "Al"
            Else
                s = "Strip Temp(Act)"
                s1 = "Strip Temp(Cacl)"
                s2 = ""
                s3 = ""
                s4 = ""
                s5 = ""
                s6 = ""
                s7 = ""
                s8 = ""
            End If


            Dim Series As String = "{pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#0D5CA5; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td>AlEffe(Act):<td><center>%s</center></td></tr></table>'}}"
            Dim Series1 As String = "{pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#BC2318; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td>AlEffe(Calc):<td><td><center>%s</center></td></tr></table>'}}"
            Dim Series2 As String = "{pointLabels: { show:false }, showLine:false, lineWidth:2, yaxis: 'y2axis', markerOptions:{ size: 14,style:'filleddiamond' }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#ff0000; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td>Shg:<td><td>%s</td></tr></table>'}}"
            Dim Series3 As String = "{pointLabels: { show:false }, showLine:false, lineWidth:2, yaxis: 'y2axis', markerOptions:{ size: 10,style:'filledSquare' }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#339900; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td>Cgg:<td><td>%s</td></tr></table>'}}"
            Dim Series4 As String = "{pointLabels: { show:false }, showLine:false, lineWidth:2, yaxis: 'y2axis', markerOptions:{ size: 14,style:'filledCircle' }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#ffcc00; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td>Alloy:<td><td>%s</td></tr></table>'}}"
            Dim Series5 As String = "{pointLabels: { show:false }, showLine:true, lineWidth: 1,linePattern: 'dashed',showMarker: false, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#BC2318; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td>Al_Pred:<td><td><center>%s</center></td></tr></table>'}}"
            Dim Series6 As String = "{pointLabels: { show:false }, showLine:false, lineWidth:2, yaxis: 'y2axis', markerOptions:{ size: 16,style:'diamond' }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#ff0000; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td>Shg:<td><td>%s</td></tr></table>'}}"
            Dim Series7 As String = "{pointLabels: { show:false }, showLine:false, lineWidth:2, yaxis: 'y2axis', markerOptions:{ size: 10,style:'square' }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#339900; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td>Cgg:<td><td>%s</td></tr></table>'}}"
            Dim Series8 As String = "{pointLabels: { show:false }, showLine:false, lineWidth:2, yaxis: 'y2axis', markerOptions:{ size: 10,style:'circle' }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#ffcc00; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td>Alloy:<td><td>%s</td></tr></table>'}}"

            hf1.Value = "[" & data1 & "," & data2 & "," & data3 & "," & data4 & "," & data5 & "," & data6 & "," & data7 & "," & data8 & "," & "]"
            hf2.Value = "['" & s & "', '" & s1 & "','" & s2 & "','" & s3 & "','" & s4 & "','" & s5 & "','" & s6 & "','" & s7 & "','" & s8 & "']"


            'Dim js = "<script language='javascript' type='text/javascript'>" & vbCrLf &
            '        "$(document).ready(function(){" & vbCrLf &
            '        "$.jqplot.config.enablePlugins = true;" & vbCrLf &
            '        "var series= ['" & s & "', '" & s1 & "','" & s2 & "','" & s3 & "','" & s4 & "','" & s5 & "','" & s6 & "','" & s7 & "','" & s8 & "']" & vbCrLf &
            '        data1 & vbCrLf & data2 & vbCrLf & data3 & vbCrLf & data4 & vbCrLf & data5 & vbCrLf & data6 & vbCrLf & data7 & vbCrLf & data8 & vbCrLf & data9 & vbCrLf &
            '"opts = {" & vbCrLf &
            '"//title: 'Calculated Effective Al & Fe'," & vbCrLf &
            '"series:[" & Series & ", " & Series1 & "," & Series2 & "," & Series3 & "," & Series4 & "," & Series5 & "," & Series6 & "," & Series7 & "," & Series8 & "]," & vbCrLf &
            '"seriesColors: ['#0D5CA5', '#BC2318','#ff0000','#339900','#ffcc00','#BC2318','#ff0000','#339900','#ffcc00']," & vbCrLf &
            '"axesDefaults: {" & vbCrLf &
            '"tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            '"tickOptions: {" & vbCrLf &
            '"fontSize:'8pt'" & vbCrLf &
            '"}" & vbCrLf &
            '"}," & vbCrLf &
            '"axes: {" & vbCrLf &
            '"xaxis: {" & vbCrLf &
            '"//min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf &
            '"renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
            '"tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," & vbCrLf &
            '"//tickInterval:'1 hour'," & vbCrLf &
            '"pad:0" & vbCrLf &
            '"}," & vbCrLf &
            '"yaxis: { " & vbCrLf &
            '"tickOptions: { formatString: '%.3f' }," & vbCrLf &
            '"//min: " & Al_min & "," & vbCrLf &
            '"//max: " & Al_max & "," & vbCrLf &
            '"//autoscale:true," & vbCrLf &
            '"label: 'Al Effe(%)'," & vbCrLf &
            '"labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            '"}," & vbCrLf &
            '"y2axis: { " & vbCrLf &
            '"//tickOptions: { formatString: '%.3f' }," & vbCrLf &
            '"//min: 0," & vbCrLf &
            '"//max: 10," & vbCrLf &
            '"//autoscale:true," & vbCrLf &
            '"tickOptions:{showTickMarks:false}," & vbCrLf &
            '"//label: ''," & vbCrLf &
            '"labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            '"}" & vbCrLf &
            '"}, " & vbCrLf &
            ' "cursor: {" & vbCrLf &
            '"zoom: true" & vbCrLf &
            '"}," & vbCrLf &
            '"//highlighter: { show: 'true', tooltipFormatString: '%.1f', useAxesFormatters: false }," & vbCrLf &
            '"grid: {backgroundColor:  'rgb(255,255,255)',drawGridlines:false}," & vbCrLf &
            '"legend: {" & vbCrLf &
            '"show: true," & vbCrLf &
            '"location: 's'," & vbCrLf &
            '"labels: series," & vbCrLf &
            '"renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
            '"placement: 'outsideGrid'," & vbCrLf &
            '"rendererOptions: {" & vbCrLf &
            '"numberRows: 1," & vbCrLf &
            '"numberColumns: 10," & vbCrLf &
            '"marginTop: 10" & vbCrLf &
            '"}" & vbCrLf &
            '"}" & vbCrLf &
            '"};" & vbCrLf &
            '"" & PlotName & " = $.jqplot('" & ContainerName & "',[data1, data2,data3,data4,data5,data6,data7,data8,data9], opts);" & vbCrLf &
            '"});" & vbCrLf &
            '"</script>" & vbCrLf

            'LiteralName.Text = js
        Catch ex As Exception
            Throw New Exception(ex.Message.ToString)
        End Try
    End Sub
    Public Sub PlotLineChartForThermaAcpm1(ByVal Xaxis() As String, ByVal X1axis() As String, ByVal StAct() As String, ByVal StCalc() As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal val As String)
        Try

            Dim min_time, max_time As String

            Dim Al_min As String = 0 'Changed by mamta on 11-Jan-2018
            Dim Al_max As String = 0.3 'Changed by mamta on 11-Jan-2018
            Dim Fe_min As String = 0 'Changed by mamta on 11-Jan-2018
            Dim Fe_max As String = 0.05 'Changed by mamta on 11-Jan-2018



            Dim data1 As String = "var data1=["
            Dim data2 As String = "var data2=["

            For i = 0 To X1axis.Length - 1
                If i > 0 Then
                    data1 &= ","
                    ' data2 &= ","
                End If

                data1 &= "['" & CDate(X1axis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & IIf(String.IsNullOrEmpty(StAct(i)), "0", StAct(i)) & "]"


            Next
            data1 &= "];"

            For i = 0 To Xaxis.Length - 1
                If i > 0 Then
                    ' data1 &= ","
                    data2 &= ","
                End If

                data2 &= "['" & CDate(Xaxis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & IIf(String.IsNullOrEmpty(StCalc(i)), "0", StCalc(i)) & "]"

            Next




            data2 &= "];"

            Dim s, s1 As String
            If val = "Al-Fe" Then
                If ContainerName = "container1" Then
                    s = "Al(Act)"
                    s1 = "Al(Calc)"
                Else
                    s = "AlEffective(Act)"
                    s1 = "AlEffective(Calc)"
                End If

            Else
                s = "Strip Temp(Act)"
                s1 = "Strip Temp(Cacl)"


            End If


            Dim Series As String = "{pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#0D5CA5; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td><center>%s</center></td></tr></table>'}}"
            Dim Series1 As String = "{pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#BC2318; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td><center>%s</center></td></tr></table>'}}"

            Dim js = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$(document).ready(function(){" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf &
                    "var series= ['" & s & "', '" & s1 & "']" & vbCrLf &
                    data1 & vbCrLf & data2 & vbCrLf &
            "opts = {" & vbCrLf &
            "//title: 'Calculated Effective Al & Fe'," & vbCrLf &
            "series:[" & Series & ", " & Series1 & "]," & vbCrLf &
            "seriesColors: ['#0D5CA5', '#BC2318']," & vbCrLf &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            "fontSize:'8pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "//min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf &
            "renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
            "tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," & vbCrLf &
            "//tickInterval:'1 hour'," & vbCrLf &
            "pad:0" & vbCrLf &
            "}," & vbCrLf &
            "yaxis: { " & vbCrLf &
            "//tickOptions: { formatString: '%.3f' }," & vbCrLf &
            "//min: " & Al_min & "," & vbCrLf &
            "//max: " & Al_max & "," & vbCrLf &
            "//autoscale:true," & vbCrLf &
            "//label: '% Effective Al'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "//highlighter: { show: 'true', tooltipFormatString: '%.1f', useAxesFormatters: false }," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
            "legend: {" & vbCrLf &
            "show: true," & vbCrLf &
            "location: 's'," & vbCrLf &
            "labels: series," & vbCrLf &
            "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
            "placement: 'outsideGrid'," & vbCrLf &
            "rendererOptions: {" & vbCrLf &
            "numberRows: 1," & vbCrLf &
            "numberColumns: 2," & vbCrLf &
            "marginTop: 10" & vbCrLf &
            "}" & vbCrLf &
            "}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "',[data1, data2], opts);" & vbCrLf &
            "});" & vbCrLf &
            "</script>" & vbCrLf

            LiteralName.Text = js
        Catch ex As Exception
            Throw New Exception(ex.Message.ToString)
        End Try
    End Sub
    Public Sub PlotLineChartForThermaAcpm2(ByVal Xaxis() As String, ByVal X1axis() As String, ByVal X2axis() As String, ByVal X3axis() As String, ByVal StAct() As String, ByVal StCalc() As String, ByVal SHG() As Double, ByVal CGG() As Double, ByVal AlPer() As Double, ByVal Al_Pred() As String, ByVal SHGFirstGrid() As String, ByVal CggFirstGrid() As String, ByVal AlPerFirstGrid() As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal val As String, Optional ByVal newseries(,) As String = Nothing)
        Try

            Dim min_time, max_time As String

            Dim Al_min As String = 0
            Dim Al_max As String = 0.3
            Dim Fe_min As String = 0
            Dim Fe_max As String = 0.05


            Dim data1 As String = "var data1=["
            Dim data2 As String = "var data2=["
            Dim data3 As String = "var data3=["
            Dim data4 As String = "var data4=["
            Dim data5 As String = "var data5=["
            Dim data6 As String = "var data6=["
            Dim data7 As String = "var data7=["
            Dim data8 As String = "var data8=["
            Dim data9 As String = "var data9=["

            For i = 0 To X1axis.Length - 1
                If i > 0 Then
                    data1 &= ","
                    ' data2 &= ","
                End If

                data1 &= "['" & CDate(X1axis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & IIf(String.IsNullOrEmpty(StAct(i)), "0", StAct(i)) & "]"



            Next
            data1 &= "];"


            For i = 0 To Xaxis.Length - 1
                'If i > 0 Then
                '    ' data1 &= ","
                '    data2 &= ","
                'End If

                data2 &= "['" & CDate(Xaxis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & IIf(String.IsNullOrEmpty(StCalc(i)), "0", StCalc(i)) & "],"
                If newseries Is Nothing Then
                    If SHGFirstGrid(i) <> "&nbsp;" And SHGFirstGrid(i) <> "0" Then

                        data7 &= "['" & CDate(Xaxis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & SHGFirstGrid(i) / 1000 & "],"
                    End If
                    If CggFirstGrid(i) <> "&nbsp;" And CggFirstGrid(i) <> "0" Then

                        data8 &= "['" & CDate(Xaxis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & CggFirstGrid(i) / 1000 & "],"
                    End If
                    If AlPerFirstGrid(i) <> "&nbsp;" And AlPerFirstGrid(i) <> "0" Then
                        data9 &= "['" & CDate(Xaxis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & AlPerFirstGrid(i) / 1000 & "],"
                    End If
                End If



            Next
            If Not newseries Is Nothing Then
                ' HttpContext.Current.Response.Write(data7)
                For j As Integer = 0 To newseries.GetUpperBound(0)
                    If newseries(j, 1) <> "0" Then
                        data7 &= "['" & newseries(j, 0) & "'," & newseries(j, 1) / 1000 & "],"
                    End If
                    If newseries(j, 2) <> "0" Then
                        data8 &= "['" & newseries(j, 0) & "'," & newseries(j, 2) / 1000 & "],"
                    End If
                    If newseries(j, 3) <> "0" Then
                        data9 &= "['" & newseries(j, 0) & "'," & newseries(j, 3) / 1000 & "],"
                    End If
                Next
            End If





            data2 &= "];"
            data7 &= "];"
            data8 &= "];"
            data9 &= "];"

            For i = 0 To X3axis.Length - 1
                'If i > 0 Then
                '    data3 &= ","
                '    data4 &= ","
                '    data5 &= ","
                'End If
                If SHG(i) <> 0 Then
                    data3 &= "['" & CDate(X3axis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & SHG(i) / 1000 & "],"
                End If
                If CGG(i) <> 0 Then

                    data4 &= "['" & CDate(X3axis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & CGG(i) / 1000 & "],"
                End If
                If AlPer(i) <> 0 Then
                    data5 &= "['" & CDate(X3axis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & AlPer(i) / 1000 & "],"
                End If
                'data6 &= "['" & CDate(X3axis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & IIf(String.IsNullOrEmpty(Al_Pred(i)), "0", Al_Pred(i)) & "],"

            Next




            data3 &= "];"
            data4 &= "];"
            data5 &= "];"

            For i = 0 To X2axis.Length - 1
                If i > 0 Then
                    data6 &= ","
                    ' data2 &= ","
                End If

                data6 &= "['" & CDate(X2axis(i)).ToString("yyyy-MM-dd HH:mm") & "'," & IIf(String.IsNullOrEmpty(Al_Pred(i)), "0", Al_Pred(i)) & "]"



            Next

            data6 &= "];"

            Dim s, s1, s2, s3, s4, s5, s6, s7, s8 As String
            If val = "Al-Fe" Then

                s = "AlEffective(Act)"
                s1 = "AlEffective(Calc)"
                s2 = "SHG"
                s3 = "CGG"
                s4 = "Al"
                s5 = "Al_Pred"
                s6 = "SHG"
                s7 = "CGG"
                s8 = "Al"
            Else
                s = "Strip Temp(Act)"
                s1 = "Strip Temp(Cacl)"
                s2 = ""
                s3 = ""
                s4 = ""
                s5 = ""
                s6 = ""
                s7 = ""
                s8 = ""
            End If


            Dim Series As String = "{pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#0D5CA5; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td>AlEffe(Act):<td><center>%s</center></td></tr></table>'}}"
            Dim Series1 As String = "{pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#BC2318; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td>AlEffe(Calc):<td><td><center>%s</center></td></tr></table>'}}"
            Dim Series2 As String = "{pointLabels: { show:false }, showLine:false, lineWidth:2, yaxis: 'y2axis', markerOptions:{ size: 14,style:'filleddiamond' }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#ff0000; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td>Shg:<td><td>%s</td></tr></table>'}}"
            Dim Series3 As String = "{pointLabels: { show:false }, showLine:false, lineWidth:2, yaxis: 'y2axis', markerOptions:{ size: 10,style:'filledSquare' }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#339900; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td>Cgg:<td><td>%s</td></tr></table>'}}"
            Dim Series4 As String = "{pointLabels: { show:false }, showLine:false, lineWidth:2, yaxis: 'y2axis', markerOptions:{ size: 14,style:'filledCircle' }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#ffcc00; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td>Alloy:<td><td>%s</td></tr></table>'}}"
            Dim Series5 As String = "{pointLabels: { show:false }, showLine:true, lineWidth: 1,linePattern: 'dashed',showMarker: false, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#BC2318; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td>Al_Pred:<td><td><center>%s</center></td></tr></table>'}}"
            Dim Series6 As String = "{pointLabels: { show:false }, showLine:false, lineWidth:2, yaxis: 'y2axis', markerOptions:{ size: 16,style:'diamond' }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#ff0000; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td>Shg:<td><td>%s</td></tr></table>'}}"
            Dim Series7 As String = "{pointLabels: { show:false }, showLine:false, lineWidth:2, yaxis: 'y2axis', markerOptions:{ size: 10,style:'square' }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#339900; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td>Cgg:<td><td>%s</td></tr></table>'}}"
            Dim Series8 As String = "{pointLabels: { show:false }, showLine:false, lineWidth:2, yaxis: 'y2axis', markerOptions:{ size: 10,style:'circle' }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#ffcc00; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td>Alloy:<td><td>%s</td></tr></table>'}}"



            Dim js = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$(document).ready(function(){" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf &
                    "var series= ['" & s & "', '" & s1 & "','" & s2 & "','" & s3 & "','" & s4 & "','" & s5 & "','" & s6 & "','" & s7 & "','" & s8 & "']" & vbCrLf &
                    data1 & vbCrLf & data2 & vbCrLf & data3 & vbCrLf & data4 & vbCrLf & data5 & vbCrLf & data6 & vbCrLf & data7 & vbCrLf & data8 & vbCrLf & data9 & vbCrLf &
            "opts = {" & vbCrLf &
            "//title: 'Calculated Effective Al & Fe'," & vbCrLf &
            "series:[" & Series & ", " & Series1 & "," & Series2 & "," & Series3 & "," & Series4 & "," & Series5 & "," & Series6 & "," & Series7 & "," & Series8 & "]," & vbCrLf &
            "seriesColors: ['#0D5CA5', '#BC2318','#ff0000','#339900','#ffcc00','#BC2318','#ff0000','#339900','#ffcc00']," & vbCrLf &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            "fontSize:'8pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "//min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf &
            "renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
            "tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," & vbCrLf &
            "//tickInterval:'1 hour'," & vbCrLf &
            "pad:0" & vbCrLf &
            "}," & vbCrLf &
            "yaxis: { " & vbCrLf &
            "tickOptions: { formatString: '%.3f' }," & vbCrLf &
            "//min: " & Al_min & "," & vbCrLf &
            "//max: " & Al_max & "," & vbCrLf &
            "//autoscale:true," & vbCrLf &
            "label: 'Al Effe(%)'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}," & vbCrLf &
            "y2axis: { " & vbCrLf &
            "//tickOptions: { formatString: '%.3f' }," & vbCrLf &
            "//min: 0," & vbCrLf &
            "//max: 10," & vbCrLf &
            "//autoscale:true," & vbCrLf &
            "tickOptions:{showTickMarks:false}," & vbCrLf &
            "label: 'Ingot Weight (Ton)'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}, " & vbCrLf &
             "cursor: {" & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "//highlighter: { show: 'true', tooltipFormatString: '%.1f', useAxesFormatters: false }," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)',drawGridlines:false}," & vbCrLf &
            "legend: {" & vbCrLf &
            "show: true," & vbCrLf &
            "location: 's'," & vbCrLf &
            "labels: series," & vbCrLf &
            "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
            "placement: 'outsideGrid'," & vbCrLf &
            "rendererOptions: {" & vbCrLf &
            "numberRows: 1," & vbCrLf &
            "numberColumns: 10," & vbCrLf &
            "marginTop: 10" & vbCrLf &
            "}" & vbCrLf &
            "}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "',[data1, data2,data3,data4,data5,data6,data7,data8,data9], opts);" & vbCrLf &
            "});" & vbCrLf &
            "</script>" & vbCrLf

            LiteralName.Text = js
        Catch ex As Exception
            Throw New Exception(ex.Message.ToString)
        End Try
    End Sub
    Public Function GetSurfRough(ByVal firstDatetime As String) As DataTable
        Return objDataHandler.GetDataSetFromQuery("Select top(1) PRM_CD_SURF_ROUGH FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] Where prm_ts_end < '" & firstDatetime & "' order by prm_ts_end desc ").Tables(0)
    End Function
 
 
    Function toDataTableDetailAnalysis(ByRef ep As ExcelPackage, ByVal Coil As String) As DataTable
        Dim workSheet As ExcelWorksheet = ep.Workbook.Worksheets.First()
        Dim table As New DataTable
        For i As Integer = 0 To workSheet.Dimension.End.Column - 1
            Dim s = workSheet.Cells(1, i + 1).Text
            If s = "" Then
                s = "C" & i
            End If
            table.Columns.Add(s)
        Next

        'For Each firstRowCell In workSheet.Cells(1, 1, 1, workSheet.Dimension.End.Column - 3)
        '    'If firstRowCell.Text = "" Then
        '    '    table.Columns.Add("C" & i)
        '    '    i += 1
        '    'Else
        '    table.Columns.Add(firstRowCell.Text)
        '    'End If

        'Next
        table.Columns.Add("file")
        table.Columns.Add("slabid")
        'table.Columns.Add("tdc")
        Dim C As Integer = workSheet.Cells.End.Column

        For rowNumber As Integer = 2 To C 'workSheet.Dimension.End.Row--- CHANGED BY AKHIL ON 16/JAN/2020 AS SAID BY MAMTA,TO GET COMPLETE DATA
            'If workSheet.Cells(rowNumber, 7).Text = "" Then
            '    Exit For
            'End If
            Dim row = workSheet.Cells(rowNumber, 1, rowNumber, workSheet.Dimension.End.Column)
            Dim newRow = table.NewRow()
            For Each cell In row
                newRow(cell.Start.Column - 1) = cell.Text
            Next
            'newRow(workSheet.Dimension.End.Column - 1)
            table.Rows.Add(newRow)
        Next
        'table.Rows(0)("tdc") = TDC
        Return table
    End Function
    'Public Sub PlotLineChartForSPMDetailAnalysis(ByVal dt As DataTable, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String, ByVal GroupByColName As String, Optional ByVal name As String = "")
    '     Try
    '         Dim lineindex As Integer = -1
    '         Dim strOverlay As String = ""
    '         Dim multiplier As Double = 1.0
    '         If name = "ENLONGATION_ACT" Then
    '             multiplier = 100
    '             lineindex = 8

    '         ElseIf YAxisColName.StartsWith("[UNIT") Then
    '             If name = "TENSION_TR" Then
    '                 multiplier = 1 / (9.8 * 1000)
    '                 lineindex = 21
    '             End If
    '         ElseIf name = "TENSION_TR" Then
    '             multiplier = 1 / 9.8
    '             lineindex = 21
    '         ElseIf name = "ROLLFORCE" Then
    '             multiplier = 102.0408
    '             lineindex = 25
    '         End If

    '         'For i As Integer = 0 To dt.Rows.Count - 1
    '         '    If IsDBNull(dt.Rows(i)("LTRI_PARA_MIN")) Then
    '         '        dt.Rows(i)("LTRI_PARA_MIN") = dt.Rows(i)("LTRI_PARA_MIN").ToString().Replace(vbNull, vbDecimal)
    '         '    End If
    '         'Next
    '         LiteralName.Text = ""
    '         'Dim min_time, max_time As String
    '         'min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-30), "yyyy-MM-dd HH:mm")
    '         'max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm")

    '         'Dim xTimestampVal(), yVal() As String
    '         Dim yVal() As Decimal

    '         'xTimestampVal = (From row In dt Select col = row(XAxisColName).ToString).ToArray
    '         'yVal = (From row In dt Select col = CDec(IIf(IsDBNull(row(YAxisColName)), 0, row(YAxisColName))) Where col > 0).ToArray()
    '         yVal = (From row In dt Select col = CDec(IIf(IsDBNull(row(YAxisColName)), 0, row(YAxisColName)))).ToArray()
    '         'Dim y_min As String = yVal.Min()
    '         'Dim y_max As String = yVal.Max()
    '         Dim y_min As String = yVal.Min() - (10 / 100 * Math.Abs(yVal.Min))
    '         Dim y_max As String = yVal.Max() + (10 / 100 * Math.Abs(yVal.Max))

    '         Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf & _
    '                 "$.jqplot.config.enablePlugins = true;" & vbCrLf
    '         dt.DefaultView.RowFilter = ""
    '         Dim dtGrades As DataTable = dt.DefaultView.ToTable(True, GroupByColName) 'All distinct Grades
    '         Dim dvDefault As DataView = dt.DefaultView
    '         Dim flag As Boolean = False
    '         Dim cnt As Integer = 1
    '         Dim stcnt As Integer
    '         For i As Integer = 0 To dtGrades.Rows.Count - 1
    '             js &= "var line" & (i + 1).ToString & " = ["
    '             dvDefault.RowFilter = "" & GroupByColName & "='" & dtGrades.Rows(i)(0) & "'"
    '             stcnt = cnt
    '             For j As Integer = 0 To dvDefault.Count - 1
    '                 If j > 0 Then
    '                     js &= ","
    '                 End If
    '                 js &= "["

    '                 If IsDBNull(dvDefault.Item(j)(GroupByColName)) Then
    '                     If IsDBNull(dvDefault.Item(j)(YAxisColName)) = False Then
    '                         js &= "" & dvDefault.Item(j)(YAxisColName) & ", " & "null"
    '                     Else
    '                         js &= " " & "null, null"
    '                     End If
    '                 Else
    '                     If IsDBNull(dvDefault.Item(j)(YAxisColName)) = False Then
    '                         js &= cnt & "," & dvDefault.Item(j)(YAxisColName) & ",'" & dvDefault.Item(j)(GroupByColName) & "'" & ",'" & dvDefault.Item(j)("Thickness") & "'" & ",'" & dvDefault.Item(j)("Width") * 1000 & "'" & ",'" & dvDefault.Item(0)("tdc") & "'"
    '                         cnt += 1
    '                         'js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)("CLR_TEST_VALUE") & ", 'Pot'"
    '                     End If
    '                 End If
    '                 js &= "]"
    '             Next

    '             If lineindex > -1 Then
    '                 If YAxisColName.StartsWith("[UNIT") Then
    '                     If name = "TENSION_TR" Then
    '                         multiplier = multiplier / (dvDefault.Item(0)("Thickness") * dvDefault.Item(0)("Width"))
    '                         strOverlay &= "{horizontalLine: {name: '" & dvDefault.Item(0)(GroupByColName) & "',color: 'rgb(255,0,0)',showTooltip: true,tooltipFormatString:" & dvDefault.Item(0)(lineindex - 1) * multiplier & " ,xmin:" & stcnt & ",xmax:" & cnt - 1 & ",y:" & dvDefault.Item(0)(lineindex - 1) * multiplier & ",lineWidth:2}},"
    '                     End If
    '                 ElseIf name <> "ROLLFORCE" Then
    '                     strOverlay &= "{horizontalLine: {name: '" & dvDefault.Item(0)(GroupByColName) & "',color: 'rgb(255,0,0)',showTooltip: true,tooltipFormatString:'" & dvDefault.Item(0)(lineindex - 1) * multiplier & "',xmin:" & stcnt & ",xmax:" & cnt - 1 & ",y:" & dvDefault.Item(0)(lineindex - 1) * multiplier & ",lineWidth:2}},"
    '                 Else
    '                     Dim dtLim As DataTable = GetLimit(dvDefault.Item(0)("TDC"))
    '                     If dtLim.Rows.Count > 0 Then
    '                         Dim min As Double = dtLim.Rows(0)(0)
    '                         Dim max As Double = dtLim.Rows(0)(1)
    '                         strOverlay &= "{horizontalLine: {name: '" & dvDefault.Item(0)(GroupByColName) & "',color: 'rgb(255,0,0)',showTooltip: true,tooltipFormatString:'" & Math.Round(min * multiplier, 3) & "',xmin:" & stcnt & ",xmax:" & cnt - 1 & ",y:" & min * multiplier & ",lineWidth:2}},"
    '                         strOverlay &= "{horizontalLine: {name: '" & dvDefault.Item(0)(GroupByColName) & "1',color: 'rgb(255,0,0)',showTooltip: true,tooltipFormatString:'" & Math.Round(max * multiplier, 3) & "',xmin:" & stcnt & ",xmax:" & cnt - 1 & ",y:" & max * multiplier & ",lineWidth:2}},"
    '                     End If
    '                 End If

    '             End If

    '             js &= "];" & vbCrLf
    '             flag = True
    '         Next

    '         Dim strg As String = ""
    '         Dim strseries As String = ""
    '         If flag Then
    '             strg = "[line1"
    '             strseries = " {pointLabels: { show:false }, showLine:false, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 5,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>Sl No: %s</td></tr>\ <tr><td>Y Value: %s</td></tr>\ <tr><td>Coil Id: %s</td></tr>\ <tr><td>Thickness: %s</td></tr>\ <tr><td>Width: %s</td></tr>\ <tr><td>TDC: %s</td></tr>\ </table>'}}"
    '             For i As Integer = 1 To dtGrades.Rows.Count - 1
    '                 strg = strg + ",line" & i + 1
    '                 strseries = strseries + ", {pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 5,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>Sl No: %s</td></tr>\ <tr><td>Y Value: %s</td></tr>\ <tr><td>Coil Id: %s</td></tr>\ <tr><td>Thickness: %s</td></tr>\ <tr><td>Width: %s</td></tr>\ <tr><td>TDC: %s</td></tr>\ </table>'}}"
    '             Next
    '             strg &= "]"
    '         End If
    '         js &= "var seriesName = ['"
    '         Dim str As String = ""
    '         For i As Integer = 0 To dtGrades.Rows.Count - 1
    '             str &= dtGrades.Rows(i)(0).ToString().Trim() + "', '"
    '         Next
    '         str = str.Remove(str.LastIndexOf(", '"))
    '         str &= "];"
    '         js &= str
    '         js &= "opts = {" & vbCrLf & _
    '         "title: '" & ChartTitle & "'," & vbCrLf & _
    '         "series:[" & strseries & "]," & vbCrLf & _
    '         "seriesColors: ['#4C4ED8','#EF3862','#8A1EEE','#0982EC','#0FBDE3','#043D1D','#059B11','#E1EB05','#666699','#F4ED03','#EF8355','#818181','#FFA500', '#006400','#F10000','#996633','#ECAE06','#009999','#800000','#F05904']," & vbCrLf & _
    '         "axesDefaults: {" & vbCrLf & _
    '         "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf & _
    '         "tickOptions: {" & vbCrLf & _
    '         "fontSize:'8pt'" & vbCrLf & _
    '         "}" & vbCrLf & _
    '         "}," & vbCrLf & _
    '         "axes: {" & vbCrLf & _
    '         "xaxis: {" & vbCrLf & _
    '         "//min: " & vbCrLf & _
    '         "//renderer:$.jqplot.DateAxisRenderer," & vbCrLf & _
    '         "//tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," & vbCrLf & _
    '         "//tickInterval:'1 hour'," & vbCrLf & _
    '         "//pad:0" & vbCrLf & _
    '          "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf & _
    '         "}," & vbCrLf & _
    '         "yaxis: { " & vbCrLf & _
    '         "tickOptions: { formatString: '%.5f' }," & vbCrLf & _
    '         "min: " & y_min & "," & vbCrLf & _
    '         "max: " & y_max & "," & vbCrLf & _
    '         "autoscale:true," & vbCrLf & _
    '         "label: '" & YAxisLabelName & "'," & vbCrLf & _
    '         "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf & _
    '         "}" & vbCrLf & _
    '         "}," & vbCrLf & _
    '         "cursor: {" & vbCrLf & _
    '         "showTooltip: false," & vbCrLf & _
    '         "zoom: true" & vbCrLf & _
    '         "}," & vbCrLf & _
    '         "animate: true," & vbCrLf & _
    '         "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf & _
    '         "canvasOverlay: {show: true,objects: [" & strOverlay & "]}," & vbCrLf & _
    '         "//legend: {" & vbCrLf & _
    '         "//show: true," & vbCrLf & _
    '         "//location: 's'," & vbCrLf & _
    '         "//labels: seriesName," & vbCrLf & _
    '         "//renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf & _
    '         "//placement: 'outsideGrid'," & vbCrLf & _
    '         "//rendererOptions: {" & vbCrLf & _
    '         "//numberRows: 1," & vbCrLf & _
    '         "//marginTop: 10" & vbCrLf & _
    '         "//}" & vbCrLf & _
    '         "//}" & vbCrLf & _
    '         "};" & vbCrLf & _
    '         "" & PlotName & " = $.jqplot('" & ContainerName & "', " & strg & ", opts);" & vbCrLf & _
    '         "</script>" & vbCrLf

    '         LiteralName.Text = js
    '     Catch ex As Exception

    '     End Try
    ' End Sub
    
    Function PopulateThicknessForPLTCMDetailAnalysis(ByVal FromDate As String, ByVal ToDate As String, ByVal Grade As String) As DataTable
        Try
            Dim filter As String = ""
            Dim dt As DataTable
            If Grade.ToLower <> "all" And Grade <> "" Then
                If Grade <> "" Then
                    filter &= " and GRADE = '" & Grade & "'"
                End If
            Else
                filter &= " and 1=1"
            End If
            dt = objDataHandler.GetDataSetFromQuery("SELECT min(THICKNESS) as Min,max(THICKNESS) as Max from CRM_SPM_PROCESS_DATA_COILWISE_BODY where COIL_STARTDATETIME between '" & FromDate & "' and '" & ToDate & "' " & filter & "").Tables(0)
            Return dt
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try


    End Function
    Function PopulateWidthForPLTCMDetailAnalysis(ByVal FromDate As String, ByVal ToDate As String, ByVal Grade As String, ByVal ThicknessFrom As String, ByVal ThicknessTo As String) As DataTable
        Try
            Dim filter As String = ""
            Dim dt As DataTable
            If Grade.ToLower <> "all" Then
                If Grade <> "" Then
                    filter &= " and GRADE = '" & Grade & "'"
                End If
            End If
            If ThicknessFrom And ThicknessTo <> "" Then

                filter &= "  and THICKNESS between " & ThicknessFrom & " and " & ThicknessTo & ""



            End If
            dt = objDataHandler.GetDataSetFromQuery("SELECT min(WIDTH) as Min,max(WIDTH) as Max from CRM_SPM_PROCESS_DATA_COILWISE_BODY where COIL_STARTDATETIME between '" & FromDate & "' and '" & ToDate & "' " & filter & "").Tables(0)

            Return dt
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try


    End Function
    Public Sub LoadColumnNameForSPMCoilDetail(ByVal CheckBoxListName As CheckBoxList, ByVal ColumnName As String)
        Dim query As String = ""
        'query = "select 'C00_COILER_SPEED_SET' as C1,'C00 Coiler Speed Set' as C2 union select 'C00_COILER_SPEED_ACT' as C1,'C00 Coiler Speed Act' as C2 union " & _
        '        "select 'S11_SPEED_SET' as C1,'S11 Speed Set' as C2 union select 'S11_SPEED_ACT' as C1,'S11 Speed Act' as C2 union select 'C90_COILER_SPEED_SET' as C1," & _
        '        "'C90 Coiler Speed Set' as C2 union select 'C90_COILER_SPEED_ACT' as C1,'C90 Coiler Speed Act' as C2 union select 'ENLONGATION_SET' as C1,'Enlongation Set' " & _
        '        "as C2 union select 'ENLONGATION_ACT' as C1,'Enlongation Act' as C2 union select 'ROLLFORCE' as C1,'Rollforce' as C2 union select 'ROLLFORCE_DS' as C1," & _
        '        "'Rollforce Ds' as C2 union select 'ROLLFORCE_OS' as C1,'Rollforce Os' as C2 union select 'WORK_ROLL_BEND_POS_SET' as C1,'Work Roll Bend Pos Set' as C2 " & _
        '        "union select 'WORK_ROLL_BEND_POS_ACT' as C1,'Work Roll Bend Pos Act' as C2 union select 'WORK_ROLL_BEND_NEG_SET' as C1,'Work Roll Bend Neg Set' as C2 " & _
        '        "union select 'WORK_ROLL_BEND_NEG_ACT' as C1,'Work Roll Bend Neg Act' as C2 union select 'ROLL_GAP_DS' as C1,'Roll Gap Ds' as C2 union select 'ROLL_GAP_OS'" & _
        '        "as C1,'Roll Gap Os' as C2 union select 'TENSION_POR_ENTRY_REF' as C1,'Tension Por Entry Ref' as C2 union select 'TENSION_POS_ENTRY' as C1,'Tension Pos Entry' as" & _
        '        "C2 union select 'TENSION_TR_REF' as C1,'Tension Tr Ref' as C2 union select 'TENSION_TR' as C1,'Tension Tr' as C2"
        query = "select 'C90_COILER_SPEED_ACT' as C1,'Speed' as C2 union select 'ENLONGATION_SET' as C1,'Elongation Set' " &
              "as C2 union select 'ENLONGATION_ACT' as C1,'Elongation Act' as C2 union select 'ROLLFORCE' as C1,'Roll Force' as C2 union select 'ROLLFORCE_DS' as C1," &
              "'Roll Force DS' as C2 union select 'ROLLFORCE_OS' as C1,'Roll Force OS' as C2 union select 'WORK_ROLL_BEND_POS_SET' as C1,'Work Roll Bend Pos Set' as C2 " &
              "union select 'WORK_ROLL_BEND_POS_ACT' as C1,'Work Roll Bend Pos Act' as C2 union select 'WORK_ROLL_BEND_NEG_SET' as C1,'Work Roll Bend Neg Set' as C2 " &
              "union select 'WORK_ROLL_BEND_NEG_ACT' as C1,'Work Roll Bend Neg Act' as C2 union select 'ROLL_GAP_DS' as C1,'Roll Gap DS' as C2 union select 'ROLL_GAP_OS'" &
              "as C1,'Roll Gap OS' as C2 union select 'TENSION_POR_ENTRY_REF' as C1,'Tension Por Entry Ref' as C2 union select 'TENSION_POS_ENTRY' as C1,'Tension Por Entry' as" &
              "C2 union select 'TENSION_TR_REF' as C1,'Tension Tr Ref' as C2 union select 'TENSION_TR' as C1,'Tension Tr' as C2 " &
              "union select 'UNIT_TENSION_POR_ENTRY_REF' as C1,'Unit Tension Por Entry Ref' as C2 union select 'UNIT_TENSION_POS_ENTRY' as C1,'Unit Tension Por Entry' as C2 " &
              " union select 'UNIT_TENSION_TR_REF' as C1,'Unit Tension Tr Ref' as C2 union select 'UNIT_TENSION_TR' as C1,'Unit Tension Tr' as C2 ORDER BY C2"
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery(query).Tables(0)
        If dt.Rows.Count > 0 Then
            CheckBoxListName.DataSource = dt

            CheckBoxListName.DataTextField = "C2"
            CheckBoxListName.DataValueField = "C1"
            CheckBoxListName.DataBind()
            'For i As Integer = 0 To CheckBoxListName.Items.Count - 1
            '    If CheckBoxListName.Items(i).ToString() = ColumnName Then
            '        CheckBoxListName.Items(i).Value = True
            '    End If


            'Next


            'CheckBoxListName.Items.Insert(0, "All")
            'DropDownName.Items.Insert(0, "Select")
            'DropDownName.SelectedIndex = 0
        End If

    End Sub
 
    Public Sub PopulateTdcForPLTCM(ByVal TdcDropDown As DropDownList, ByVal FromDate As String, ByVal ToDate As String, ByVal Grade As String)
        Try
            Dim filter As String = ""
            If Grade.ToLower <> "all" Then
                If Grade <> "" Then
                    filter &= " and GRADE = '" & Grade & "'"
                End If
            End If
            TdcDropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT distinct TDC_No from CRM_SPM_PROCESS_DATA_COILWISE_BODY where COIL_STARTDATETIME between '" & FromDate & "' and '" & ToDate & "' and (TDC_No <> '0' and TDC_No is not null and TDC_No <> '') " & filter & " order by TDC_No").Tables(0)
            TdcDropDown.DataTextField = "TDC_No"
            TdcDropDown.DataValueField = "TDC_No"
            TdcDropDown.DataBind()
            TdcDropDown.Items.Insert(0, "All")
            TdcDropDown.SelectedIndex = 0
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try


    End Sub
  
  
    Public Function LoadPOTStatus(ByVal stD As String, ByVal endD As String) As DataSet
        Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("SELECT PRM_MESSAGE_ID,PRM_ID_COIL,PRM_CD_SURF_ROUGH,PRM_ZINC_POT_TMP,PRM_TS_END,PRM_TCM_PROCESS_DATE FROM T_CGL_FUR_PARAM WHERE PRM_TS_END BETWEEN '" & stD & "' AND '" & endD & "' ORDER BY PRM_TS_END")
        Return ds
    End Function
    Public Sub LoadColumnNameForAnalysisLabView(ByVal CheckBoxListName As CheckBoxList)
        Dim query As String = ""
        query = "select 'PRM_TEST_VALUE_RB' as C1,'RB' as C2 union select 'PRM_TEST_VALUE_YS' as C1,'YS' as C2 union select 'PRM_TEST_VALUE_UTS' as C1,'UTS' as C2  union select 'PRM_TEST_VALUE_EL' as C1,'EL' as C2 union select 'PRM_TEST_VALUE_RBAR' as C1,'RBAR' as C2 union select 'PRM_TEST_VALUE_RA' as C1,'RA' as C2  order by C2"
        'query = "select 'PRM_SS_STRP_TMP' as C1 union select 'PRM_GALV_POWER' as C1 union select 'PRM_FORCE' as C1 union select 'PRM_ZINC_POT_TMP' as C1 union select 'PRM_LINE_SPEED' as C1"
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery(query).Tables(0)
        If dt.Rows.Count > 0 Then
            CheckBoxListName.DataSource = dt

            CheckBoxListName.DataTextField = "C2"
            CheckBoxListName.DataValueField = "C1"
            CheckBoxListName.DataBind()
            'CheckBoxListName.Items.Insert(0, "All")
            'DropDownName.Items.Insert(0, "Select")
            'DropDownName.SelectedIndex = 0
        End If

    End Sub
    Public Sub LoadColumnNameForSPMCoilDetailLabView(ByVal CheckBoxListName As CheckBoxList, ByVal ColumnName As String)
        Dim query As String = ""
        'query = "select 'C00_COILER_SPEED_SET' as C1,'C00 Coiler Speed Set' as C2 union select 'C00_COILER_SPEED_ACT' as C1,'C00 Coiler Speed Act' as C2 union " & _
        '        "select 'S11_SPEED_SET' as C1,'S11 Speed Set' as C2 union select 'S11_SPEED_ACT' as C1,'S11 Speed Act' as C2 union select 'C90_COILER_SPEED_SET' as C1," & _
        '        "'C90 Coiler Speed Set' as C2 union select 'C90_COILER_SPEED_ACT' as C1,'C90 Coiler Speed Act' as C2 union select 'ENLONGATION_SET' as C1,'Enlongation Set' " & _
        '        "as C2 union select 'ENLONGATION_ACT' as C1,'Enlongation Act' as C2 union select 'ROLLFORCE' as C1,'Rollforce' as C2 union select 'ROLLFORCE_DS' as C1," & _
        '        "'Rollforce Ds' as C2 union select 'ROLLFORCE_OS' as C1,'Rollforce Os' as C2 union select 'WORK_ROLL_BEND_POS_SET' as C1,'Work Roll Bend Pos Set' as C2 " & _
        '        "union select 'WORK_ROLL_BEND_POS_ACT' as C1,'Work Roll Bend Pos Act' as C2 union select 'WORK_ROLL_BEND_NEG_SET' as C1,'Work Roll Bend Neg Set' as C2 " & _
        '        "union select 'WORK_ROLL_BEND_NEG_ACT' as C1,'Work Roll Bend Neg Act' as C2 union select 'ROLL_GAP_DS' as C1,'Roll Gap Ds' as C2 union select 'ROLL_GAP_OS'" & _
        '        "as C1,'Roll Gap Os' as C2 union select 'TENSION_POR_ENTRY_REF' as C1,'Tension Por Entry Ref' as C2 union select 'TENSION_POS_ENTRY' as C1,'Tension Pos Entry' as" & _
        '        "C2 union select 'TENSION_TR_REF' as C1,'Tension Tr Ref' as C2 union select 'TENSION_TR' as C1,'Tension Tr' as C2"
        query = "select 'YS' as C1,'YS' as C2 union select 'UTS' as C1,'UTS' " &
              "as C2 union select 'RA' as C1,'RA' as C2 union select 'RB' as C1,'RB' as C2 union select 'RBAR' as C1," &
              "'RBAR' as C2 union select 'EL' as C1,'EL' as C2  ORDER BY C2"
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery(query).Tables(0)
        If dt.Rows.Count > 0 Then
            CheckBoxListName.DataSource = dt

            CheckBoxListName.DataTextField = "C2"
            CheckBoxListName.DataValueField = "C1"
            CheckBoxListName.DataBind()
            'For i As Integer = 0 To CheckBoxListName.Items.Count - 1
            '    If CheckBoxListName.Items(i).ToString() = ColumnName Then
            '        CheckBoxListName.Items(i).Value = True
            '    End If


            'Next


            'CheckBoxListName.Items.Insert(0, "All")
            'DropDownName.Items.Insert(0, "Select")
            'DropDownName.SelectedIndex = 0
        End If

    End Sub
    Public Function LoadBathMgmtRejectionData(ByVal stD As String, ByVal endD As String) As DataSet
        Dim dayone As String = New DateTime(Today.Year, Today.Month, 1).ToString("yyyy-MM-dd 06:00:00")
        Dim yest As String = DateTime.Now.ToString("yyyy-MM-dd 06:00:00")
        Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("select * from openquery(crm_oracle,'select sum(ccl_MS_PIECE_ACTL),to_char(CHR_TS_RELEASE,''YYYY-MM-DD'') from CRMDBA.t_COIL_HOLD_RLS a JOIN CRMDBA.T_COLD_COIL b On b.ccl_ID_coil = a.CHR_ID_COIL AND CHR_CD_RSN_HOLD = CHR_CD_FNL_DECSN JOIN CRMDBA.T_CODES c ON CHR_CD_FNL_DECSN=cd_value where CHR_Remarks  In (''DownGraded-M'',''Diverted-M'') AND  CHR_TS_RELEASE >= ''" & stD & "'' AND CHR_TS_RELEASE<= ''" & endD & "'' ANd CD_type=''C0015'' group by to_char(CHR_TS_RELEASE,''YYYY-MM-DD'') order by 2');select * from openquery(crm_oracle,'select sum(ccl_MS_PIECE_ACTL) as wt,cd_desc from CRMDBA.t_COIL_HOLD_RLS a JOIN CRMDBA.T_COLD_COIL b On b.ccl_ID_coil = a.CHR_ID_COIL AND CHR_CD_RSN_HOLD = CHR_CD_FNL_DECSN JOIN CRMDBA.T_CODES c ON CHR_CD_FNL_DECSN=cd_value where CHR_Remarks  In (''DownGraded-M'',''Diverted-M'') AND  CHR_TS_RELEASE >= ''" & DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd 06:00:00") & "'' AND CHR_TS_RELEASE<= ''" & DateTime.Now.ToString("yyyy-MM-dd 06:00:00") & "'' ANd CD_type=''C0015'' group by cd_desc order by 1 desc');select * from openquery(crm_oracle,'select sum(ccl_MS_PIECE_ACTL) as wt,cd_desc from CRMDBA.t_COIL_HOLD_RLS a JOIN CRMDBA.T_COLD_COIL b On b.ccl_ID_coil = a.CHR_ID_COIL AND CHR_CD_RSN_HOLD = CHR_CD_FNL_DECSN JOIN CRMDBA.T_CODES c ON CHR_CD_FNL_DECSN=cd_value where CHR_Remarks  In (''DownGraded-M'',''Diverted-M'') AND  CHR_TS_RELEASE >= ''" & dayone & "'' AND CHR_TS_RELEASE<= ''" & yest & "'' ANd CD_type=''C0015'' group by cd_desc order by 1 desc')")
        Return ds
    End Function


    Function GetLFCData(ByVal st As String, ByVal en As String, ByVal casterno As Integer) As DataSet
        Try
            '' Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("SELECT DISTINCT HEAT_ID,PROD_START_DATETIME,PROD_END_DATETIME,HEAT_ID+'#'+CONVERT(VARCHAR(19),PROD_START_DATETIME,120)+'#'+CONVERT(VARCHAR(19),PROD_END_DATETIME,120) as VALCOL FROM TSCR_LFC_CAL_DATA WHERE PROD_START_DATETIME>='" & st & "' AND PROD_END_DATETIME<='" & en & "' AND CASTER=" & casterno & "")

            Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("SELECT * FROM (SELECT DISTINCT HEAT_ID,PROD_START_DATETIME,PROD_END_DATETIME,HEAT_ID+'#'+CONVERT(VARCHAR(19),PROD_START_DATETIME,120)+'#'+CONVERT(VARCHAR(19),PROD_END_DATETIME,120) as VALCOL,(SELECT COUNT(*) FROM TSCR_SLAB_MASTER WHERE TSM_PROD_START>=PROD_START_DATETIME AND TSM_PROD_END<=PROD_END_DATETIME AND TSM_DEVICE_KEY=" & 12 + casterno & " AND  TSM_SLAB_ID LIKE '%' + SUBSTRING(HEAT_ID,2,5) + '%')  AS CNT FROM TSCR_LFC_CAL_DATA WHERE PROD_START_DATETIME>='" & st & "' AND PROD_END_DATETIME<='" & en & "' AND CASTER=" & casterno & ") T WHERE CNT>0  order by HEAT_ID ASC")

            Return ds
        Catch ex As Exception
            Throw New Exception(ex.ToString)
        End Try
    End Function
    Function GetLFCData1(ByVal casterno As Integer) As DataSet
        Try
            Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("SELECT HEAT_ID,PROD_START_DATETIME,PROD_END_DATETIME FROM TSCR_LFC_CAL_DATA WHERE PROD_START_DATETIME=(select max(PROD_START_DATETIME) FROM [TSCR_LFC_CAL_DATA] where (CASTER=" & casterno & "))")


            Return ds
        Catch ex As Exception
            Throw New Exception(ex.ToString)
        End Try
    End Function
    Function GetSummaryLFCChartData(ByVal st As String, ByVal en As String, ByVal casterno As Integer) As DataSet
        Try
            Dim DEVICE_KEY As String = IIf(casterno = 1, "13", "14")
            Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("SELECT LFC_TIMESTAMP,REMARKS, SUBSTRING(REMARKS,PATINDEX('%[0-9]%', REMARKS),(CASE WHEN PATINDEX('%[^0-9]%', STUFF(REMARKS, 1, (PATINDEX('%[0-9]%', REMARKS) - 1), '')) = 0 THEN LEN(REMARKS) ELSE (PATINDEX('%[^0-9]%', STUFF(REMARKS, 1, (PATINDEX('%[0-9]%', REMARKS) - 1), ''))) - 1 END )) AS RESULT,[LFC_FROM_TAIL] as LFC_TAIL,HEAT_ID FROM TSCR_LFC_CAL_DATA WHERE [CASTER]=" & casterno & " and LFC_TIMESTAMP BETWEEN '" & CDate(st).AddMinutes(-10).ToString("yyyy-MM-dd HH:mm:ss") & "' AND '" & CDate(en).AddMinutes(10).ToString("yyyy-MM-dd HH:mm:ss") & "'ORDER BY LFC_TIMESTAMP ASC  ;SELECT TSM_SLAB_ID, TSM_PROD_START,TSM_PROD_END,TSM_DEVICE_KEY,TSR_SLAB_WIDTH,TSR_SLAB_GRADE FROM TSCR_SLAB_MASTER inner join TSCR_SLAB_RAW on TSCR_SLAB_MASTER.TSM_SLAB_ID=TSCR_SLAB_RAW.TSR_SLAB_ID WHERE [TSM_DEVICE_KEY]='" & DEVICE_KEY & "' AND TSM_PROD_START>='" & CDate(st).AddMinutes(-10).ToString("yyyy-MM-dd HH:mm:ss") & "' AND TSM_PROD_END<='" & CDate(en).AddMinutes(10).ToString("yyyy-MM-dd HH:mm:ss") & "'  ORDER BY  TSM_PROD_START ASC")

            Return ds
        Catch ex As Exception
            Throw New Exception(ex.ToString)
        End Try
    End Function
    Function GetLFCChartData(ByVal st As String, ByVal en As String, ByVal heatid As String, ByVal casterno As Integer) As DataSet
        Try
            Dim DEVICE_KEY As String = IIf(casterno = 1, "13", "14")
            Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("SELECT LFC_TIMESTAMP,REMARKS, SUBSTRING(REMARKS,PATINDEX('%[0-9]%', REMARKS),(CASE WHEN PATINDEX('%[^0-9]%', STUFF(REMARKS, 1, (PATINDEX('%[0-9]%', REMARKS) - 1), '')) = 0 THEN LEN(REMARKS) ELSE (PATINDEX('%[^0-9]%', STUFF(REMARKS, 1, (PATINDEX('%[0-9]%', REMARKS) - 1), ''))) - 1 END )) AS RESULT,[LFC_FROM_TAIL] as LFC_TAIL FROM TSCR_LFC_CAL_DATA WHERE [CASTER]=" & casterno & " AND HEAT_ID='" & heatid & "';SELECT TSM_SLAB_ID, TSM_PROD_START,TSM_PROD_END,TSM_DEVICE_KEY,TSR_SLAB_WIDTH,TSR_SLAB_GRADE FROM TSCR_SLAB_MASTER inner join TSCR_SLAB_RAW on TSCR_SLAB_MASTER.TSM_SLAB_ID=TSCR_SLAB_RAW.TSR_SLAB_ID WHERE [TSM_DEVICE_KEY]='" & DEVICE_KEY & "' AND TSM_PROD_START>='" & CDate(st).AddMinutes(-10).ToString("yyyy-MM-dd HH:mm:ss") & "' AND TSM_PROD_END<='" & CDate(en).AddMinutes(10).ToString("yyyy-MM-dd HH:mm:ss") & "'  AND TSM_SLAB_ID LIKE '%" & heatid.Substring(1) & "%'")

            Return ds
        Catch ex As Exception
            Throw New Exception(ex.ToString)
        End Try
    End Function
    'Function GetLFCCSLABID(ByVal st As String, ByVal en As String, ByVal heatid As String, ByVal casterno As Integer) As DataSet
    '    Try
    '        Dim DEVICE_KEY As String = IIf(casterno = 1, "13", "14")
    '        Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("SELECT TSM_SLAB_ID,TSM_PROD_START,TSM_PROD_END FROM TSCR_SLAB_MASTER WHERE [TSM_DEVICE_KEY]='" & DEVICE_KEY & "' AND TSM_PROD_START>='" & st & "' AND TSM_PROD_END<='" & en & "' AND TSM_SLAB_ID LIKE '%" & heatid.Substring(1) & "%'")
    '        Return ds
    '    Catch ex As Exception
    '        Throw New Exception(ex.ToString)
    '    End Try
    'End Function



    Public Function LoadBathMgmtRejectionData_Seconds(ByVal stD As String, ByVal endD As String) As DataSet
        Dim dayone As String = New DateTime(Today.Year, Today.Month, 1).ToString("yyyy-MM-dd 06:00:00")
        Dim yest As String = DateTime.Now.ToString("yyyy-MM-dd 06:00:00")
        Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("select * from openquery(crm_oracle,'select sum(ccl_MS_PIECE_ACTL),to_char(CHR_TS_RELEASE,''YYYY-MM-DD'') from CRMDBA.t_COIL_HOLD_RLS a JOIN CRMDBA.T_COLD_COIL b On b.ccl_ID_coil = a.CHR_ID_COIL AND CHR_CD_RSN_HOLD = CHR_CD_FNL_DECSN JOIN CRMDBA.T_CODES c ON CHR_CD_FNL_DECSN=cd_value where CHR_Remarks  In (''Seconds-M'') AND  CHR_TS_RELEASE >= ''" & stD & "'' AND CHR_TS_RELEASE<= ''" & endD & "'' ANd CD_type=''C0015'' group by to_char(CHR_TS_RELEASE,''YYYY-MM-DD'') order by 2');select * from openquery(crm_oracle,'select sum(ccl_MS_PIECE_ACTL) as wt,cd_desc from CRMDBA.t_COIL_HOLD_RLS a JOIN CRMDBA.T_COLD_COIL b On b.ccl_ID_coil = a.CHR_ID_COIL AND CHR_CD_RSN_HOLD = CHR_CD_FNL_DECSN JOIN CRMDBA.T_CODES c ON CHR_CD_FNL_DECSN=cd_value where CHR_Remarks  In (''Seconds-M'') AND  CHR_TS_RELEASE >= ''" & DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd 06:00:00") & "'' AND CHR_TS_RELEASE<= ''" & DateTime.Now.ToString("yyyy-MM-dd 06:00:00") & "'' ANd CD_type=''C0015'' group by cd_desc order by 1 desc');select * from openquery(crm_oracle,'select sum(ccl_MS_PIECE_ACTL) as wt,cd_desc from CRMDBA.t_COIL_HOLD_RLS a JOIN CRMDBA.T_COLD_COIL b On b.ccl_ID_coil = a.CHR_ID_COIL AND CHR_CD_RSN_HOLD = CHR_CD_FNL_DECSN JOIN CRMDBA.T_CODES c ON CHR_CD_FNL_DECSN=cd_value where CHR_Remarks  In (''Seconds-M'') AND  CHR_TS_RELEASE >= ''" & dayone & "'' AND CHR_TS_RELEASE<= ''" & yest & "'' ANd CD_type=''C0015'' group by cd_desc order by 1 desc')")
        Return ds
    End Function
 

    Function GetDPCRVizOne(ByVal filter As String) As DataSet
        Dim q As String = "select [TDD_SERVICE_ORDER_ID],TDC_CUSTOMER_ALIAS as Customer," &
 "[Name/ Severity/ End Component/ End Customer] = STUFF((" &
    "Select N'# ' + [TDD_ISSUE_DETAILING1] FROM [T_DPCR_DATA_NEW] " &
    "WHERE [TDD_SERVICE_ORDER_ID]= x.[TDD_SERVICE_ORDER_ID] " &
    "ORDER BY [TDD_SERVICE_ORDER_ID] " &
    "FOR XML PATH(''), TYPE).value(N'.[1]', N'nvarchar(max)'), 1, 2, N'')," &
 "[Position/ Bandwidth (Random/ Continuous)/ Magnitude] = STUFF(( " &
    "Select N'# ' + [TDD_ISSUE_DETAILING2] FROM [T_DPCR_DATA_NEW] " &
    "WHERE TDD_SERVICE_ORDER_ID= x.TDD_SERVICE_ORDER_ID " &
    "ORDER BY TDD_SERVICE_ORDER_ID " &
    "FOR XML PATH(''), TYPE).value(N'.[1]', N'nvarchar(max)'), 1, 2, N''), " &
 "[SPC/ CAPA/ Backend Information] = STUFF(( " &
    "SELECT N'# ' + [TDD_ISSUE_DETAILING3] FROM [T_DPCR_DATA_NEW] " &
    "WHERE TDD_SERVICE_ORDER_ID= x.TDD_SERVICE_ORDER_ID " &
    "ORDER BY TDD_SERVICE_ORDER_ID " &
    "FOR XML PATH(''), TYPE).value(N'.[1]', N'nvarchar(max)'), 1, 2, N''), " &
        "[Suggestion/ Competitor/ Wayforward] = STUFF(( " &
    "SELECT N'# ' + [TDD_ISSUE_DETAILING4] FROM [T_DPCR_DATA_NEW] " &
    "WHERE TDD_SERVICE_ORDER_ID= x.TDD_SERVICE_ORDER_ID " &
    "ORDER BY TDD_SERVICE_ORDER_ID " &
    "FOR XML PATH(''), TYPE).value(N'.[1]', N'nvarchar(max)'), 1, 2, N''), " &
        "[HE/ TE/ Body/ Top/ Bottom/ Top & Bottom] = STUFF(( " &
    "SELECT N'# ' + [TDD_ISSUE_DETAILING5] FROM [T_DPCR_DATA_NEW] " &
    "WHERE TDD_SERVICE_ORDER_ID= x.TDD_SERVICE_ORDER_ID " &
    "ORDER BY TDD_SERVICE_ORDER_ID " &
    "FOR XML PATH(''), TYPE).value(N'.[1]', N'nvarchar(max)'), 1, 2, N''), " &
        "[OPI:Findings] = STUFF(( " &
    "SELECT N'# ' + [TDD_OPI_FINDINGS] FROM [T_DPCR_DATA_NEW] " &
    "WHERE TDD_SERVICE_ORDER_ID= x.TDD_SERVICE_ORDER_ID " &
    "ORDER BY TDD_SERVICE_ORDER_ID " &
    "FOR XML PATH(''), TYPE).value(N'.[1]', N'nvarchar(max)'), 1, 2, N''), " &
        "[OPI:Action Initiated 1] = STUFF(( " &
    "SELECT N'# ' + [TDD_OPI_ACTION_INIT1] FROM [T_DPCR_DATA_NEW] " &
    "WHERE TDD_SERVICE_ORDER_ID= x.TDD_SERVICE_ORDER_ID " &
    "ORDER BY TDD_SERVICE_ORDER_ID " &
    "FOR XML PATH(''), TYPE).value(N'.[1]', N'nvarchar(max)'), 1, 2, N''), " &
        "[OPI:Action Initiated 2] = STUFF(( " &
    "SELECT N'# ' + [TDD_OPI_ACTION_INIT2] FROM [T_DPCR_DATA_NEW] " &
    "WHERE TDD_SERVICE_ORDER_ID= x.TDD_SERVICE_ORDER_ID " &
    "ORDER BY TDD_SERVICE_ORDER_ID " &
    "FOR XML PATH(''), TYPE).value(N'.[1]', N'nvarchar(max)'), 1, 2, N''), " &
        "[OPI:Action Plan 1] = STUFF(( " &
    "SELECT N'# ' + [TDD_OPI_ACTION_PLAN1] FROM [T_DPCR_DATA_NEW] " &
    "WHERE TDD_SERVICE_ORDER_ID= x.TDD_SERVICE_ORDER_ID " &
    "ORDER BY TDD_SERVICE_ORDER_ID " &
    "FOR XML PATH(''), TYPE).value(N'.[1]', N'nvarchar(max)'), 1, 2, N''), " &
        "[OPI:Action Plan 2] = STUFF(( " &
    "SELECT N'# ' + [TDD_OPI_ACTION_PLAN2] FROM [T_DPCR_DATA_NEW] " &
    "WHERE TDD_SERVICE_ORDER_ID= x.TDD_SERVICE_ORDER_ID " &
    "ORDER BY TDD_SERVICE_ORDER_ID " &
    "FOR XML PATH(''), TYPE).value(N'.[1]', N'nvarchar(max)'), 1, 2, N''), " &
        "[DPI:Findings] = STUFF(( " &
    "SELECT N'# ' + [TDD_DPI_FINDINGS] FROM [T_DPCR_DATA_NEW] " &
    "WHERE TDD_SERVICE_ORDER_ID= x.TDD_SERVICE_ORDER_ID " &
    "ORDER BY TDD_SERVICE_ORDER_ID " &
    "FOR XML PATH(''), TYPE).value(N'.[1]', N'nvarchar(max)'), 1, 2, N''), " &
        "[DPI:Action Initiated 1] = STUFF(( " &
    "SELECT N'# ' + [TDD_DPI_ACTION_INIT1] FROM [T_DPCR_DATA_NEW] " &
    "WHERE TDD_SERVICE_ORDER_ID= x.TDD_SERVICE_ORDER_ID " &
    "ORDER BY TDD_SERVICE_ORDER_ID " &
    "FOR XML PATH(''), TYPE).value(N'.[1]', N'nvarchar(max)'), 1, 2, N''), " &
        "[DPI:Action Initiated 2] = STUFF(( " &
    "SELECT N'# ' + [TDD_DPI_ACTION_INIT2] FROM [T_DPCR_DATA_NEW] " &
    "WHERE TDD_SERVICE_ORDER_ID= x.TDD_SERVICE_ORDER_ID " &
    "ORDER BY TDD_SERVICE_ORDER_ID " &
    "FOR XML PATH(''), TYPE).value(N'.[1]', N'nvarchar(max)'), 1, 2, N''), " &
        "[DPI:Action Plan 1] = STUFF(( " &
    "SELECT N'# ' + [TDD_DPI_ACTION_PLAN1] FROM [T_DPCR_DATA_NEW] " &
    "WHERE TDD_SERVICE_ORDER_ID= x.TDD_SERVICE_ORDER_ID " &
    "ORDER BY TDD_SERVICE_ORDER_ID " &
    "FOR XML PATH(''), TYPE).value(N'.[1]', N'nvarchar(max)'), 1, 2, N''), " &
        "[DPI:Action Plan 2] = STUFF(( " &
    "SELECT N'# ' + [TDD_DPI_ACTION_PLAN2] FROM [T_DPCR_DATA_NEW] " &
    "WHERE TDD_SERVICE_ORDER_ID= x.TDD_SERVICE_ORDER_ID " &
    "ORDER BY TDD_SERVICE_ORDER_ID " &
    "FOR XML PATH(''), TYPE).value(N'.[1]', N'nvarchar(max)'), 1, 2, N''), " &
    "[DPCR Current Status] = STUFF(( " &
    "SELECT N'# ' + [TDD_PRIORITY_NUM] FROM [T_DPCR_DATA_NEW] " &
    "WHERE TDD_SERVICE_ORDER_ID= x.TDD_SERVICE_ORDER_ID " &
    "ORDER BY TDD_SERVICE_ORDER_ID " &
    "FOR XML PATH(''), TYPE).value(N'.[1]', N'nvarchar(max)'), 1, 2, N''), " &
    "[Investigator Name] = STUFF(( " &
    "SELECT N'# ' + [TDD_WEEK_NO] FROM [T_DPCR_DATA_NEW] " &
    "WHERE TDD_SERVICE_ORDER_ID= x.TDD_SERVICE_ORDER_ID " &
    "ORDER BY TDD_SERVICE_ORDER_ID " &
     "FOR XML PATH(''), TYPE).value(N'.[1]', N'nvarchar(max)'), 1, 2, N''), " &
    "[Requester Name] = STUFF(( " &
    "SELECT N'# ' + [tdd_remarks] FROM [T_DPCR_DATA_NEW] " &
    "WHERE TDD_SERVICE_ORDER_ID= x.TDD_SERVICE_ORDER_ID " &
    "ORDER BY TDD_SERVICE_ORDER_ID " &
    "FOR XML PATH(''), TYPE).value(N'.[1]', N'nvarchar(max)'), 1, 2, N'') " &
      " FROM (SELECT * FROM [T_DPCR_DATA_NEW] inner join [T_DPCR_CUST_PRIORITY] on tdc_customer=tdd_customer and TDC_MARKET_SEGMENT=tdd_market_segment WHERE 1=1 " & filter & ") as x " &
  "group by TDD_SERVICE_ORDER_ID,TDC_CUSTOMER_ALIAS"

        Dim ds As DataSet = objDataHandler.GetDataSetFromQuery(q)
        Return ds
    End Function
    Public Function DPCRViz1(ByVal dtFrom As String, ByVal dtTo As String, ByVal region As String, ByVal productsegment As String) As DataTable
        Dim filter As String = ""
        If region <> "All" Then
            filter &= " AND tdc_zone='" & region & "'"
        End If
        If productsegment <> "All" Then
            filter &= " AND TDD_PRODUCT_SEGMENT='" & productsegment & "'"
        End If
        Dim q As String = "select *,ISNULL([AUTOMOTIVE],0)+ISNULL([BPRS],0)+ISNULL([IPPE],0) as Total from (SELECT TDD_PRODUCT_SEGMENT as [Product Segment],TDC_ZONE as [Region],TDD_MARKET_SEGMENT as [Market Segment],COUNT(*) AS MAGNITUDE FROM [T_DPCR_DATA_NEW] inner join [T_DPCR_CUST_PRIORITY] on tdd_customer=tdc_customer where 1=1 " & filter & " and tdd_posting_date between '" & dtFrom & "' and '" & dtTo & "' group by TDD_PRODUCT_SEGMENT,TDC_ZONE,TDD_MARKET_SEGMENT ) as sourcetable PIVOT(SUM([magnitude])  FOR [Market Segment] IN([AUTOMOTIVE],[BPRS],[IPPE])) AS PivotTable order by 1,2"
        Return objDataHandler.GetDataSetFromQuery(q).Tables(0)
    End Function

    Public Function DPCRViz2(ByVal dtFrom As String, ByVal dtTo As String, ByVal market As String) As DataTable
        Dim q As String = "SELECT convert(varchar(10),tdd_posting_date,103) as Date,tdd_service_order_id as DPCR#,tdc_customer_alias as Customer,tdd_plant_name as [Origin Plant],tdd_detection_plant as [Detection Plant],tdd_defect as Defect FROM [T_DPCR_DATA_NEW] inner join [T_DPCR_CUST_PRIORITY] on tdd_customer=tdc_customer where tdd_market_segment='" & market & "' and tdd_posting_date between '" & dtFrom & "' and '" & dtTo & "' and tdc_priority_num between 1 and 16"
        Return objDataHandler.GetDataSetFromQuery(q).Tables(0)
    End Function

    Public Function DPCRViz3(ByVal dtFrom As String, ByVal dtTo As String, ByVal originplant As String, ByVal productsegment As String) As DataTable
        Dim filter As String = ""
        If originplant <> "All" Then
            filter &= " AND tdd_plant_name='" & originplant & "'"
        End If
        If productsegment <> "All" Then
            filter &= " AND TDD_PRODUCT_SEGMENT='" & productsegment & "'"
        End If
        Dim q As String = "SELECT convert(varchar(10),tdd_posting_date,103) as Date,tdd_service_order_id as DPCR#,tdd_detection_plant as [Detection Plant],tdd_defect as Defect,tdd_product_segment as [Product Segment],tdd_issue_detailing1 as Sev FROM [T_DPCR_DATA_NEW] inner join [T_DPCR_CUST_PRIORITY] on tdd_customer=tdc_customer where 1=1 " & filter & " and tdd_posting_date between '" & dtFrom & "' and '" & dtTo & "'"
        Return objDataHandler.GetDataSetFromQuery(q).Tables(0)
    End Function

    Public Function DPCRViz4(ByVal dtFrom As String, ByVal dtTo As String, ByVal detectionplant As String, ByVal productsegment As String) As DataTable
        Dim filter As String = ""
        If detectionplant <> "All" Then
            filter &= " AND TDD_DETECTION_PLANT='" & detectionplant & "'"
        End If
        If productsegment <> "All" Then
            filter &= " AND TDD_PRODUCT_SEGMENT='" & productsegment & "'"
        End If
        Dim q As String = "SELECT convert(varchar(10),tdd_posting_date,103) as Date,tdd_service_order_id as DPCR#,tdd_plant_name as [Origin Plant],tdd_defect as Defect,tdd_product_segment as [Product Segment],tdd_issue_detailing1 as Sev FROM [T_DPCR_DATA_NEW] inner join [T_DPCR_CUST_PRIORITY] on tdd_customer=tdc_customer where 1=1 " & filter & " and tdd_posting_date between '" & dtFrom & "' and '" & dtTo & "'"
        Return objDataHandler.GetDataSetFromQuery(q).Tables(0)
    End Function


    '.........................Ingot addition...........
    Public Function SaveIngotAddition(ByVal datetime As String, ByVal cgg As String, ByVal shg As String, ByVal AlPer As String, ByVal Dross As String, ByVal Cgg_wt As String, ByVal Shg_wt As String, ByVal Alper_wt As String, ByVal Dross_wt As String) As Integer
        Try


            Return objDataHandler.RunSimpleQuery("INSERT INTO CGL2_INGOT_ADDITION(CIA_TIMESTAMP,CIA_CGG,CIA_SHG,CIA_5ALPER,CIA_DROSS,CIA_CGG_WT,CIA_SHG_WT,CIA_5ALPER_WT,CIA_DROSS_WT) VALUES('" & datetime & "','" & cgg & "','" & shg & "','" & AlPer & "','" & Dross & "','" & Cgg_wt & "','" & Shg_wt & "','" & Alper_wt & "','" & Dross_wt & "')")
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Function

    Public Function UpdateIngotAddition(ByVal datetime As String, ByVal cgg As String, ByVal shg As String, ByVal AlPer As String, ByVal Dross As String, ByVal Weight As String) As Integer
        Try
            Return objDataHandler.RunSimpleQuery("UPDATE CGL2_INGOT_ADDITION SET CIA_CGG='" & cgg & "',CIA_SHG='" & shg & "',CIA_5ALPER='" & AlPer & "',CIA_DROSS='" & Dross & "',CIA_DROSS_WT='" & Weight & "' WHERE CIA_TIMESTAMP='" & datetime & "'")

        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Function

    Public Sub PopulateIngotDetails(ByVal startdatetime As String, ByVal endDatetime As String, ByVal gdvdetail As GridView)


        Dim table As New DataTable
        table.Columns.Add("Datetime")
        table.Columns.Add("Shift")
        table.Columns.Add("CGG")
        table.Columns.Add("SHG")
        table.Columns.Add("AlPer")
        table.Columns.Add("Dross")
        table.Columns.Add("Weight")



        Dim sqlQuery As String = " select CIA_TIMESTAMP,CIA_CGG,CIA_SHG,CIA_5ALPER,CIA_DROSS,CIA_DROSS_WT FROM [FP_PROCESS_DATA].[dbo].[CGL2_INGOT_ADDITION] Where CIA_TIMESTAMP between '" & startdatetime & "' AND '" & endDatetime & "' ORDER BY CIA_TIMESTAMP desc"
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery(sqlQuery).Tables(0)

        If dt.Rows.Count > 0 Then
            For i As Integer = 0 To dt.Rows.Count - 1
                Dim row As DataRow = table.NewRow

                row("Datetime") = dt.Rows(i)("CIA_TIMESTAMP")
                ' row("Shift") = dt.Rows(i)("starttime")
                row("CGG") = (dt.Rows(i)("CIA_CGG"))
                row("SHG") = dt.Rows(i)("CIA_SHG")
                row("AlPer") = dt.Rows(i)("CIA_5ALPER")
                row("Dross") = dt.Rows(i)("CIA_DROSS")
                row("Weight") = dt.Rows(i)("CIA_DROSS")

                Dim dattime As DateTime = dt.Rows(i)("CIA_TIMESTAMP")

                Dim time As String = dattime.ToString("HH:mm:ss")


                If time >= "06:00:00" And time < "14:00:00" Then

                    row("Shift") = "A"
                ElseIf time >= "14:00:00" And time < "22:00:00" Then

                    row("Shift") = "B"

                Else

                    row("Shift") = "C"
                End If


                table.Rows.Add(row)
            Next
            gdvdetail.DataSource = table
        End If
        gdvdetail.DataBind()
        If gdvdetail.Rows.Count > 0 Then
            gdvdetail.UseAccessibleHeader = True
            gdvdetail.HeaderRow.TableSection = TableRowSection.TableHeader
        End If
    End Sub



    Public Sub PopulateMonthlyCon(ByVal month As Integer, ByVal cgg As Label, ByVal shg As Label, ByVal Alper As Label, ByVal Dross As Label)
        Dim dt As DataTable
        Dim Countcgg As Integer = 0
        Dim Countshg As Integer = 0
        Dim CountAl As Integer = 0
        Dim CountDross As Integer = 0


        Dim startDate As DateTime = New DateTime(Now.Year, month, 1, 6, 0, 0)
        Dim endDate As DateTime = startDate.AddMonths(1).AddDays(-1)

        dt = objDataHandler.GetDataSetFromQuery(" select CIA_CGG,CIA_SHG,CIA_5ALPER ,CIA_DROSS FROM [FP_PROCESS_DATA].[dbo].[CGL2_INGOT_ADDITION] Where CIA_TIMESTAMP between '" & startDate.ToString("yyyy-MM-dd HH:mm:ss") & "' AND '" & endDate.ToString("yyyy-MM-dd HH:mm:ss") & "'").Tables(0)
        For i As Integer = 0 To dt.Rows.Count - 1
            Dim t1, t2, t3, t4 As Integer

            t1 = dt.Rows(i)("CIA_CGG")
            t2 = dt.Rows(i)("CIA_SHG")
            t3 = dt.Rows(i)("CIA_5ALPER")
            t4 = dt.Rows(i)("CIA_DROSS")
            Countcgg = Countcgg + t1
            Countshg = Countshg + t2
            CountAl = CountAl + t3
            CountDross = CountDross + t4
        Next
        cgg.Text = Countcgg
        shg.Text = Countshg
        Alper.Text = CountAl
        Dross.Text = CountDross

    End Sub

    Public Sub DeleteIngot(ByVal datetime As String)
        objDataHandler.RunSimpleQuery("Delete from [FP_PROCESS_DATA].[dbo].[CGL2_INGOT_ADDITION] where CIA_TIMESTAMP='" & datetime & "'  ")
    End Sub

    Public Function Getingotaddition(ByVal startdatetime As String, ByVal endDatetime As String) As DataTable
        ' Return objDataHandler.GetDataSetFromQuery("select CIA_TIMESTAMP,CIA_CGG,CIA_SHG,CIA_5ALPER FROM [FP_PROCESS_DATA].[dbo].[CGL2_INGOT_ADDITION] Where CIA_TIMESTAMP between '" & startdatetime & "' AND '" & endDatetime & "' order by CIA_TIMESTAMP  ").Tables(0)
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select dateadd(DAY,0, datediff(day,0, CIA_TIMESTAMP)) as DATE from [FP_PROCESS_DATA].[dbo].[CGL2_INGOT_ADDITION] Where CIA_TIMESTAMP between '" & startdatetime & "' AND '" & endDatetime & "' group by dateadd(DAY,0, datediff(day,0, CIA_TIMESTAMP))").Tables(0)
        Dim dt1 As DataTable = objDataHandler.GetDataSetFromQuery("select sum(CIA_CGG) as CGG,sum(CIA_SHG) as SHG, sum(CIA_5ALPER) as AL5PER,sum(CIA_DROSS) as DROSS FROM [FP_PROCESS_DATA].[dbo].[CGL2_INGOT_ADDITION] Where CIA_TIMESTAMP between '" & startdatetime & "' AND '" & endDatetime & "'  group by datepart(day,dateadd(hour,-6,CIA_TIMESTAMP)) ").Tables(0)

        Dim dt_SecondSheet As New DataTable
        dt_SecondSheet.Columns.Add("TIMESTAMP")
        dt_SecondSheet.Columns.Add("CGG", GetType(Double))
        dt_SecondSheet.Columns.Add("SHG", GetType(Double))
        dt_SecondSheet.Columns.Add("AL5PER", GetType(Double))
        dt_SecondSheet.Columns.Add("DROSS", GetType(Double))

        For i As Integer = 0 To dt1.Rows.Count - 1
            Dim row As DataRow = dt_SecondSheet.NewRow
            row("TIMESTAMP") = dt.Rows(i)("DATE")
            row("CGG") = dt1.Rows(i)("CGG")
            row("SHG") = dt1.Rows(i)("SHG")
            row("AL5PER") = dt1.Rows(i)("AL5PER")
            row("DROSS") = dt1.Rows(i)("DROSS")

            dt_SecondSheet.Rows.Add(row)


        Next

        Return dt_SecondSheet


    End Function

    Public Function ExportExcelIngot(ByVal startdatetime As String, ByVal endDatetime As String) As DataSet
        'Dim dayone As String = New DateTime(Today.Year, Today.Month, 1).ToString("yyyy-MM-dd 06:00:00")
        'Dim nextday As String = DateTime.Now.ToString("yyyy-MM-dd 06:00:00")

        Dim dayone As DateTime = CDate(startdatetime)
        Dim nextday As DateTime = CDate(endDatetime)



        Dim sqlQuery As String = " select CIA_TIMESTAMP as TIMESTAMP,CIA_CGG as CGG,CIA_SHG as SHG,CIA_5ALPER as AL5PER,CIA_DROSS as DROSS FROM [FP_PROCESS_DATA].[dbo].[CGL2_INGOT_ADDITION] Where CIA_TIMESTAMP between '" & startdatetime & "' AND '" & endDatetime & "' ORDER BY CIA_TIMESTAMP desc ;"
        sqlQuery &= " select  sum(CIA_CGG)*1.09553086419753 as CGG,sum(CIA_SHG)*1.04465882352941 as SHG,sum(CIA_5ALPER)*0.09988 as AL5PER,sum(CIA_DROSS)*0.7202 as DROSS from [FP_PROCESS_DATA].[dbo].[CGL2_INGOT_ADDITION] Where CIA_TIMESTAMP between '" & startdatetime & "' AND '" & endDatetime & "' group by datepart(day,dateadd(hour,-6,CIA_TIMESTAMP)); "
        sqlQuery &= "Select  sum([PRM_MS_COIL_ACTL])/1000 as production_C,  sum([PRM_LN_COIL]*[PRM_SEC2_COIL]/1000) as SA_F," &
            " sum((cast(substring(prm_cd_coat,2,3) as decimal)+4) * ([PRM_LN_COIL]*[PRM_SEC2_COIL]/1000))/1000000 as zn_on_strip_G,avg([PRM_TTC_AVG]+[PRM_BTC_AVG]) as avg_zn_strip_M,  sum(([PRM_TTC_AVG]+[PRM_BTC_AVG]) * ([PRM_LN_COIL]*[PRM_SEC2_COIL]/1000) /1000000) as zn_strip_N " &
        "FROM [FP_PROCESS_DATA].[dbo].[T_CGL_FUR_PARAM] where prm_ts_end > '" & dayone.ToString("yyyy-MM-dd 06:00:00") & "' and prm_ts_end < '" & nextday.ToString("yyyy-MM-dd 06:00:00") & "' group by datepart(day,dateadd(hour,-6,prm_ts_end)) ; "
        sqlQuery &= "select dateadd(DAY,0, datediff(day,0, CIA_TIMESTAMP)) as DATE from [FP_PROCESS_DATA].[dbo].[CGL2_INGOT_ADDITION] Where CIA_TIMESTAMP between '" & startdatetime & "' AND '" & endDatetime & "' group by dateadd(DAY,0, datediff(day,0, CIA_TIMESTAMP));"
        sqlQuery &= "select * from CGL2_INGOT_ADDITION_SHIFT WHERE CIAS_TIMESTAMP between '" & dayone.ToString("yyyy-MM-dd 00:00:00") & "' and '" & nextday.ToString("yyyy-MM-dd 00:00:00") & "' "



        Return objDataHandler.GetDataSetFromQuery(sqlQuery)

    End Function




    Public Sub PlotBarChart(ByVal dt As DataTable, ByVal LiteralName As Literal, ByVal containername As String, ByVal plotname As String)
        Dim s As New StringBuilder("<script>")
        Dim sname As String = "["
        Dim dname As String = ""
        Dim line1, line2, line3 As String
        line1 = "var line1=["
        line2 = "var line2=["
        line3 = "var line3=["
        dname &= "line1,line2,line3"
        ' s.Append("var data = [")

        'sname = ""
        For i = 0 To dt.Rows.Count - 1

            If i > 0 Then
                line1 = line1 & "," : line2 = line2 & "," : line3 = line3 & "," : sname &= ","
            End If
            line1 &= dt.Rows(i)("CIA_CGG")
            line2 &= dt.Rows(i)("CIA_SHG")
            line3 &= dt.Rows(i)("CIA_5ALPER")
            's.Append("[" & dt.Rows(i)("CIA_CGG") & "," & dt.Rows(i)("CIA_SHG") & "," & dt.Rows(i)("CIA_5ALPER") & "]")
            sname &= "'" & CDate(dt.Rows(i)("CIA_TIMESTAMP")).ToString("dd-MM-yy HH:mm") & "'"
        Next
        line1 &= "];" : line2 &= "];" : line3 &= "];" : sname &= "];"
        s.Append(line1 & line2 & line3)

        s.Append("var ticks = " & sname & "")
        s.Append(" " & plotname & " = $.jqplot('" & containername & "', [" & dname & "],{")
        s.Append("seriesDefaults: {renderer: $.jqplot.BarRenderer,rendererOptions:{barMargin:2,barPadding: -35 ,barWidth: 15 },")
        s.Append("pointLabels:{show:true}},axesDefaults: {tickRenderer: $.jqplot.CanvasAxisTickRenderer , tickOptions: { fontSize:'8pt' ,angle: -30} },axes: { xaxis:{renderer: $.jqplot.CategoryAxisRenderer,ticks: ticks,tickOptions:{formatString:'%d-%b %H:%M', angle: -30}},yaxis:{label: 'No of Ingots',labelRenderer: $.jqplot.CanvasAxisLabelRenderer}},")
        s.Append("seriesColors: ['#3393FF','#D6514D','#ffcc66'],")
        s.Append("legend:{labels:['CGG','SHG','5%Al'],renderer: $.jqplot.EnhancedLegendRenderer,show:true,  rendererOptions: {numberRows:1},location:'s', placement:'outsideGrid'}")
        s.Append("}); </script>")
        LiteralName.Text = s.ToString

    End Sub

    Public Sub PlotLineChartForIngotAddition(ByVal dt As DataTable, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String)
        Try

            Dim min_time, max_time As String

            Dim Al_min As String = 0
            Dim Al_max As String = 0.3
            Dim Fe_min As String = 0
            Dim Fe_max As String = 0.05


            Dim data1 As String = "var data1=["
            Dim data2 As String = "var data2=["
            Dim data3 As String = "var data3=["
            Dim data4 As String = "var data4=["

            If dt.Rows.Count > 0 Then


                For i As Integer = 0 To dt.Rows.Count - 1
                    'If i > 0 Then
                    '    data3 &= ","
                    '    data4 &= ","
                    '    data5 &= ","
                    'End If
                    'If dt.Rows(i)("SHG") <> 0 Then
                    data1 &= "['" & CDate(dt.Rows(i)("TIMESTAMP")).ToString("yyyy-MM-dd") & "'," & dt.Rows(i)("SHG") & "],"
                    'End If
                    'If dt.Rows(i)("CGG") <> 0 Then

                    data2 &= "['" & CDate(dt.Rows(i)("TIMESTAMP")).ToString("yyyy-MM-dd") & "'," & dt.Rows(i)("CGG") & "],"
                    'End If
                    'If dt.Rows(i)("AL5PER") <> 0 Then
                    data3 &= "['" & CDate(dt.Rows(i)("TIMESTAMP")).ToString("yyyy-MM-dd") & "'," & dt.Rows(i)("AL5PER") & "],"
                    'End If
                    'If dt.Rows(i)("DROSS") <> 0 Then
                    data4 &= "['" & CDate(dt.Rows(i)("TIMESTAMP")).ToString("yyyy-MM-dd") & "'," & dt.Rows(i)("DROSS") & "],"
                    'End If


                Next
            End If



            data1 &= "];"
            data2 &= "];"
            data3 &= "];"
            data4 &= "];"

            Dim s1, s2, s3, s4 As String

            s1 = "Shg"
            s2 = "Cgg"
            s3 = "Al5%"
            s4 = "Dross"


            Dim Series1 As String = "{pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#0D5CA5; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td>Shg:<td><center>%s</center></td></tr></table>'}}"
            Dim Series2 As String = "{pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#BC2318; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td>Cgg:<td><td><center>%s</center></td></tr></table>'}}"
            Dim Series3 As String = "{pointLabels: { show:false }, showLine:true, lineWidth:2,  markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#ff0000; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td>Al5%:<td><td>%s</td></tr></table>'}}"
            Dim Series4 As String = "{pointLabels: { show:false }, showLine:true, lineWidth:2,  markerOptions:{ size: 5}, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:50px; width:100px; background-color:#339900; font-weight:bold; font-size:small; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td>Dross:<td><td>%s</td></tr></table>'}}"



            Dim js = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$(document).ready(function(){" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf &
                    "var series= ['" & s1 & "','" & s2 & "','" & s3 & "','" & s4 & "']" & vbCrLf &
                    data1 & vbCrLf & data2 & vbCrLf & data3 & vbCrLf & data4 & vbCrLf &
            "opts = {" & vbCrLf &
            "//title: 'Calculated Effective Al & Fe'," & vbCrLf &
            "series:[ " & Series1 & "," & Series2 & "," & Series3 & "," & Series4 & "]," & vbCrLf &
            "seriesColors: ['#0D5CA5', '#BC2318','#ff0000','#339900']," & vbCrLf &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            "fontSize:'8pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "//min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf &
            "renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
            "tickOptions:{formatString:'%d-%b', angle: -30}," & vbCrLf &
            "//tickInterval:'1 hour'," & vbCrLf &
            "pad:0" & vbCrLf &
             "}," & vbCrLf &
             "yaxis: { " & vbCrLf &
            "//tickOptions: { formatString: '%.3f' }," & vbCrLf &
            "//min: " & Al_min & "," & vbCrLf &
            "//max: " & Al_max & "," & vbCrLf &
            "//autoscale:true," & vbCrLf &
            "//label: 'Al Total'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "//highlighter: { show: 'true', tooltipFormatString: '%.1f', useAxesFormatters: false }," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)',drawGridlines:false}," & vbCrLf &
            "legend: {" & vbCrLf &
            "show: true," & vbCrLf &
            "location: 's'," & vbCrLf &
            "labels: series," & vbCrLf &
            "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
            "placement: 'outsideGrid'," & vbCrLf &
            "rendererOptions: {" & vbCrLf &
            "numberRows: 1," & vbCrLf &
            "numberColumns: 10," & vbCrLf &
            "marginTop: 10" & vbCrLf &
            "}" & vbCrLf &
            "}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "',[data1,data2,data3,data4], opts);" & vbCrLf &
            "});" & vbCrLf &
            "</script>" & vbCrLf

            LiteralName.Text = js
        Catch ex As Exception
            Throw New Exception(ex.Message.ToString)
        End Try
    End Sub

    Public Function InsertIngotAdditionShift(ByVal datetime As String, ByVal yesterdayshift As String, ByVal todayshiftg As String) As Integer
        Try
            Dim count As Boolean = False
            count = objDataHandler.CheckRecordsIn("CGL2_INGOT_ADDITION_SHIFT", "CIAS_TIMESTAMP", "CIAS_TIMESTAMP='" & datetime & "'")
            If Not count Then


                Return objDataHandler.RunSimpleQuery("INSERT INTO CGL2_INGOT_ADDITION_SHIFT(CIAS_TIMESTAMP,CIAS_YESTERDAY_SHIFT,CIAS_TODAY_SHIFT,CIAS_CGG_OPENING_STK,CIAS_SHG_OPENING_STK,CIAS_AL_OPENING_STK,CIAS_DROSS_OPENING_STK,CIAS_CGG_RECEIVING_ENTRY,CIAS_SHG_RECEIVING_ENTRY,CIAS_AL_RECEIVING_ENTRY,CIAS_DROSS_RECEIVING_ENTRY) VALUES('" & datetime & "','" & yesterdayshift & "','" & todayshiftg & "',0,0,0,0,0,0,0,0)")
            End If
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Function
    Public Function UpdateIngotAdditionShift(ByVal datetime As String, ByVal yesterdayshift As String, ByVal todayshiftg As String) As Integer
        Try
            Return objDataHandler.RunSimpleQuery("UPDATE CGL2_INGOT_ADDITION_SHIFT SET CIAS_YESTERDAY_SHIFT='" & yesterdayshift & "',CIAS_TODAY_SHIFT='" & todayshiftg & "'  WHERE CIAS_TIMESTAMP='" & datetime & "'")

        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Function
    'Public Function UpdateIngotAdditionShiftOpeningstok(ByVal datetime As String, ByVal cggop As String, ByVal shgop As String, ByVal alop As String, ByVal drossop As String, ByVal cggrec As String, ByVal shgrec As String, ByVal alrec As String, ByVal drossrec As String) As Integer
    '    Try
    '        Return objDataHandler.RunSimpleQuery("UPDATE CGL2_INGOT_ADDITION_SHIFT SET CIAS_CGG_OPENING_STK='" & cggop & "',CIAS_SHG_OPENING_STK='" & shgop & "', CIAS_AL_OPENING_STK='" & alop & "',CIAS_DROSS_OPENING_STK='" & drossop & "',CIAS_CGG_RECEIVING_ENTRY='" & cggrec & "',CIAS_SHG_RECEIVING_ENTRY='" & shgrec & "',CIAS_AL_RECEIVING_ENTRY='" & alrec & "' ,CIAS_DROSS_RECEIVING_ENTRY='" & drossrec & "' WHERE CIAS_TIMESTAMP='" & datetime & "'")

    '    Catch ex As Exception
    '        Throw New Exception(ex.ToString())
    '    End Try
    'End Function

    Public Function InsertIngotAdditionOpeningStk(ByVal datetime As String, ByVal cggop As String, ByVal shgop As String, ByVal alop As String, ByVal drossop As String, ByVal cggrec As String, ByVal shgrec As String, ByVal alrec As String, ByVal drossrec As String, ByVal val As String) As Integer
        Try
            If val = "Opening" Then
                Return objDataHandler.RunSimpleQuery("INSERT INTO CGL2_INGOT_ADDITION_STK(CIAS_TIMESTAMP,CIAS_CGG_OPENING_STK,CIAS_SHG_OPENING_STK,CIAS_AL_OPENING_STK,CIAS_DROSS_OPENING_STK,CIAS_CGG_RECEIVING_ENTRY,CIAS_SHG_RECEIVING_ENTRY,CIAS_AL_RECEIVING_ENTRY,CIAS_DROSS_RECEIVING_ENTRY) VALUES('" & datetime & "','" & cggop & "','" & shgop & "','" & alop & "','" & drossop & "',0,0,0,0)")

            ElseIf val = "Receiving" Then
                Return objDataHandler.RunSimpleQuery("INSERT INTO CGL2_INGOT_ADDITION_STK(CIAS_TIMESTAMP,CIAS_CGG_OPENING_STK,CIAS_SHG_OPENING_STK,CIAS_AL_OPENING_STK,CIAS_DROSS_OPENING_STK,CIAS_CGG_RECEIVING_ENTRY,CIAS_SHG_RECEIVING_ENTRY,CIAS_AL_RECEIVING_ENTRY,CIAS_DROSS_RECEIVING_ENTRY) VALUES('" & datetime & "',0,0,0,0,'" & cggrec & "','" & shgrec & "','" & alrec & "','" & drossrec & "')")
            End If



        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Function
    Public Function GetOpeningStock() As DataSet


        Dim sqlQuery As String = " select top 1 [CIAS_TIMESTAMP],[CIAS_CGG_OPENING_STK],[CIAS_SHG_OPENING_STK],[CIAS_AL_OPENING_STK],[CIAS_DROSS_OPENING_STK] FROM [FP_PROCESS_DATA].[dbo].[CGL2_INGOT_ADDITION_STK] where [CIAS_CGG_OPENING_STK] <>0 order by CIAS_TIMESTAMP desc  ;"
        sqlQuery &= " select top 1 [CIAS_TIMESTAMP],[CIAS_CGG_RECEIVING_ENTRY],[CIAS_SHG_RECEIVING_ENTRY],[CIAS_AL_RECEIVING_ENTRY],[CIAS_DROSS_RECEIVING_ENTRY] FROM [FP_PROCESS_DATA].[dbo].[CGL2_INGOT_ADDITION_STK] where [CIAS_CGG_RECEIVING_ENTRY] <>0 order by CIAS_TIMESTAMP desc;"
        sqlQuery &= " select sum(CIAS_CGG_RECEIVING_ENTRY) as CIAS_CGG_RECEIVING_ENTRY , sum(CIAS_SHG_RECEIVING_ENTRY) as CIAS_SHG_RECEIVING_ENTRY, sum(CIAS_AL_RECEIVING_ENTRY) as CIAS_AL_RECEIVING_ENTRY, sum(CIAS_DROSS_RECEIVING_ENTRY) as CIAS_DROSS_RECEIVING_ENTRY FROM [FP_PROCESS_DATA].[dbo].[CGL2_INGOT_ADDITION_STK] group by format(CIAS_TIMESTAMP,'MM.yyyy')"

        Return objDataHandler.GetDataSetFromQuery(sqlQuery)



    End Function

    Public Sub LoadData(ByVal GridView1 As GridView, ByVal ms As String, ByVal zo As String, ByVal cu As String)
        Dim dt As DataTable
        Dim filter As String = ""
        If zo <> "All" Then
            filter &= " AND TDC_ZONE='" & zo & "' "
        End If
        If cu <> "" Then
            filter &= " AND TDC_CUSTOMER LIKE '%" & cu & "%'"
        End If

        dt = objDataHandler.GetDataSetFromQuery("SELECT [TDC_CUSTOMER],[TDC_CUSTOMER_ALIAS],[TDC_ZONE],[TDC_PRIORITY_NUM] FROM T_DPCR_CUST_PRIORITY WHERE TDC_MARKET_SEGMENT='" & ms & "' " & filter & " order by TDC_PRIORITY_NUM").Tables(0)


        If dt.Rows.Count > 0 Then
            GridView1.DataSource = dt
            GridView1.DataBind()

            GridView1.ShowHeaderWhenEmpty = True
            GridView1.UseAccessibleHeader = True
            GridView1.HeaderRow.TableSection = TableRowSection.TableHeader
        End If
    End Sub
    Public Sub UpdatePriority(ByVal query As String)
        objDataHandler.RunSimpleQuery(query)
    End Sub


    Public Sub UpdateZone(ByVal query1 As String)
        objDataHandler.RunSimpleQuery(query1)
    End Sub

    Public Sub deleteZone(ByVal query2 As String)
        objDataHandler.RunSimpleQuery(query2)
    End Sub
    Sub InsertCustomer(ByVal markersegment As String, ByVal zone As String, ByVal cname As String, ByVal calias As String, ByVal priority As String)
        Dim q As String = "INSERT INTO T_DPCR_CUST_PRIORITY VALUES('" & markersegment & "','" & cname & "','" & priority & "','" & calias & "','" & zone & "')"
        objDataHandler.RunSimpleQuery(q)
    End Sub

    Public Function GetHsmdata(ByVal startdate As String, ByVal enddate As String, ByVal filtervalue As String) As DataTable
        Dim strDateTime As DateTime = CDate(startdate)
        Dim enddatetime As DateTime = CDate(enddate)
        Dim d1 As DateTime = Convert.ToDateTime(("12:00:00"))
        Dim d2 As DateTime = Convert.ToDateTime(("23:59:59"))
        Dim dt As DataTable
        If strDateTime < d1 Or enddatetime > d2 Then
            dt = objDataHandler1.GetDataSetFromQuery("select LogDate + ' ' +LogTime as Logdatetime,MaxValue FROM [MonitoringSystemDB].[dbo].[BwAnalogTable] where LogDate + ' ' +LogTime between '" & strDateTime.ToString("yy/MM/dd HH:mm:ss").Replace("-", "/") & "' and '" & enddatetime.ToString("yy/MM/dd HH:mm:ss").Replace("-", "/") & "' and TagName='" & filtervalue & "' ").Tables(0)
        Else
            dt = objDataHandler1.GetDataSetFromQuery1("select LogDate + ' ' +LogTime as Logdatetime,MaxValue FROM [dbtestDB].[dbo].[AnalogTempTable] where LogDate + ' ' +LogTime between '" & strDateTime.ToString("yy/MM/dd HH:mm:ss").Replace("-", "/") & "' and '" & enddatetime.ToString("yy/MM/dd HH:mm:ss").Replace("-", "/") & "' and TagName='" & filtervalue & "' ").Tables(0)
        End If
        Return dt
        ' Return objDataHandler.GetDataSetFromQuery("select LogDate + '' +LogTime as Logdatetime,MaxValue FROM [MonitoringSystemDB].[dbo].[BwAnalogTable] where LogDate + '' +LogTime between '" & startdate & "' and '" & enddate & "' and TagName='" & filtervalue & "' ").Tables(0)
    End Function


    Public Sub PlotLineChart(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal YAxisLabelName As String)
        ' Try

        LiteralName.Text = ""
        Dim min_time, max_time As String
        min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-30), "yyyy-MM-dd HH:mm:ss")
        max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm:ss")

        Dim xTimestampVal(), yVal() As String

        xTimestampVal = (From row In dt Select col = row(XAxisColName).ToString).ToArray
        yVal = (From row In dt Select col = row(YAxisColName).ToString).ToArray()

        Dim y_min As String = "0" 'yVal.Min() - (yVal.Min() * 0.1)

        Dim y_max As String = yVal.Max() + (yVal.Max() * 0.1)

        Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                "$.jqplot.config.enablePlugins = true;" & vbCrLf
        dt.DefaultView.RowFilter = ""
        'Dim dtGrades As DataTable = dt.DefaultView.ToTable(True, "CLR_PARAM_MIN") 'All distinct Grades
        'Dim dvDefault As DataView = dt.DefaultView
        Dim flag As Boolean = False
        js &= "var line  = ["
        For j As Integer = 0 To dt.Rows.Count - 1

            'dvDefault.RowFilter = "CLR_PARAM_MIN='" & dt.Rows(i)(0) & "'"

            If j > 0 Then
                js &= ","
            End If
            js &= "["
            Dim dtTime As DateTime = dt.Rows(j)(XAxisColName)

            If IsDBNull(dt.Rows(j)(YAxisColName)) = False Then
                js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm:ss") & "', " & dt.Rows(j)(YAxisColName)
            Else
                js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm:ss") & "', " & "null"
            End If


            js &= "]"


        Next
        js &= "];" & vbCrLf
        flag = True
        Dim strg As String = ""
        Dim strseries As String = ""
        If flag Then
            strg = "[line]"
            strseries = " {showLine:true, markerOptions:{ size: 2 }}"
            'For i As Integer = 1 To dt.Rows.Count - 1
            '    strg = strg + ",line" & i + 1
            '    strseries = strseries + ", { showLine:true, markerOptions:{ size: 7 }}"
            'Next
            'strg &= "]"
        End If
        'js &= "var seriesName = ['"
        'Dim str As String = "Motor load"
        ''For i As Integer = 0 To dt.Rows.Count - 1
        ''    str &= dt.Rows(i)(0).ToString().Trim() + "', '"
        ''Next
        ''str = str.Remove(str.LastIndexOf(", '"))
        'str &= "'];"
        'js &= str

        js &= "var seriesName = ['"
        Dim str As String = "Motor load"
        'For i As Integer = 0 To dt.Rows.Count - 1
        '    str &= dt.Rows(i)(0).ToString().Trim() + "', '"
        'Next
        'str = str.Remove(str.LastIndexOf(", '"))
        str &= "'];"
        js &= str

        'For i = 0 To dt.Rows.Count - 1
        '    If i = xTimestampVal.Length - 1 Then
        '        js &= "'" & DateTime.Parse(xTimestampVal.GetValue(i).ToString().Trim()).ToString("yyyy-MM-dd HH:mm") & "', " & yVal.GetValue(i).ToString().Trim() & "]]; " & vbCrLf
        '    Else
        '        js &= "'" & DateTime.Parse(xTimestampVal.GetValue(i).ToString().Trim()).ToString("yyyy-MM-dd HH:mm") & "', " & yVal.GetValue(i).ToString().Trim() & "], ["
        '    End If
        'Next

        js &= "opts = {" & vbCrLf &
        "series:[" & strseries & "]," & vbCrLf &
        "seriesColors: ['#33ccff']," & vbCrLf &
        "seriesDefaults:{pointLabels:{show:false}}," & vbCrLf &
        "axesDefaults: {" & vbCrLf &
        "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
        "tickOptions: {" & vbCrLf &
        "fontSize:'8pt'" & vbCrLf &
        "}" & vbCrLf &
        "}," & vbCrLf &
        "axes: {" & vbCrLf &
        "xaxis: {" & vbCrLf &
        "//min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf &
        "renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
        "tickOptions:{formatString:'%H:%M', angle: -30}," & vbCrLf &
        "//tickInterval:'1 hour'," & vbCrLf &
        "pad:0" & vbCrLf &
        "}," & vbCrLf &
        "yaxis: { " & vbCrLf &
        "tickOptions: { formatString: '%.2f' }," & vbCrLf &
        "min: 0," & vbCrLf &
        "max: 250," & vbCrLf &
        "autoscale:true," & vbCrLf &
        "label: 'Motor Load'," & vbCrLf &
        "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
        "}" & vbCrLf &
        "}," & vbCrLf &
        "canvasOverlay: { show: 'true', objects: [{horizontalLine: {name: 'pebbles', y: 150,lineWidth:3,xOffset: 0,color: 'rgb(255, 0, 0)',shadow: false}}]}," & vbCrLf &
        "cursor: {" & vbCrLf &
        "zoom: true" & vbCrLf &
        "}," & vbCrLf &
        "//highlighter: { show: 'true', tooltipFormatString: '%.1f', useAxesFormatters: false }," & vbCrLf &
        "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
        "legend: {" & vbCrLf &
        "show: true," & vbCrLf &
        "location: 's'," & vbCrLf &
        "labels: seriesName," & vbCrLf &
        "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
        "placement: 'outsideGrid'," & vbCrLf &
        "rendererOptions: {" & vbCrLf &
        "numberRows: 1," & vbCrLf &
        "marginTop: 10" & vbCrLf &
        "}" & vbCrLf &
        "}" & vbCrLf &
        "};" & vbCrLf &
        "" & PlotName & " = $.jqplot('" & ContainerName & "', " & strg & ", opts);" & vbCrLf &
        "</script>" & vbCrLf

        LiteralName.Text = js

        'Catch ex As Exception

        'End Try
    End Sub

    Public Function IsAValidUserForDpcr(ByVal type As String, ByVal Username As String, ByVal Password As String) As Boolean
        Try
            If type = "dpcr" Then
                'Return objDataHandler.CheckRecordsIn("USER_DETAILS", "USERNAME", "USERNAME||PASSWORD='" & Username & Password & "'")
                Return objDataHandler.CheckRecordsIn("USER_DETAILS", "USERNAME", "USERNAME ='" & Username & "' and PASSWORD='" & Password & "'")
            End If
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

    End Function
    Public Function GetLimit(ByVal TdcNo As String, ByVal Thickness As Double, ByVal Width As Double) As DataTable
        Dim query As String = ""
        query = "select Avg - (Avg*Percent_limit/100) as min, Avg + (Avg * Percent_limit/100) as max,Avg * 102.0408 as Avg  from CRM_SPM_Cutoff where TDC = '" & TdcNo & "' and " & Thickness & " > Thickness_min and " & Thickness & " <= Thickness_max and " & Width * 1000 & " > Width_min and " & Width * 1000 & " <= Width_max"
        Return objDataHandler.GetDataSetFromQuery(query).Tables(0)
    End Function
    
    Sub BoxPlotForDescAnalSPM(ByVal dt As DataTable, ByVal yValue As String, ByVal lit As Literal, ByVal containerName As String, ByVal PlotName As String, ByVal DataVariable As String, ByVal seriesOf As String, ByVal OutlierDataVariable As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String, ByVal AvgVarName As String, ByVal ColCondition As String, ByVal YMin As String, ByVal YMax As String)
        lit.Text = ""
        Try
            ChartTitle = ""
            Dim js = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                "var " & DataVariable & " = ["
            'Dim Series() = (From row In dt Select col = row.Field(Of String)(seriesOf) Distinct).ToArray
            Dim Series() = (From row In dt Select col = row.Field(Of Date)(seriesOf) Distinct).ToArray
            Dim strarr As New ArrayList
            Dim AvgData = ""
            Dim tickOptions As String = IIf(Series.Length > 8, "tickOptions:{ angle: -30 },", "")
            For i As Integer = 0 To Series.Length - 1 'MAIN LOOP
                Dim sd As DateTime = DateTime.Parse(Series(i))
                Dim x = i
                'Dim query = From val In dt.AsEnumerable() Where val.Field(Of String)(seriesOf) = Series(x) Select val
                Dim query = From val In dt.AsEnumerable() Where val.Field(Of Date)(seriesOf) = Series(x) Select val
                Dim dtValue = query.CopyToDataTable()
                Dim arrYValues(dtValue.Rows.Count) As Decimal
                'arrYValues = (From row In dtValue Select col = Decimal.Parse(row(Trim(yValue)).ToString())).ToArray
                arrYValues = (From row In dtValue Where row("STDATE") = sd Select col = Decimal.Parse(row(Trim(yValue)).ToString())).ToArray
                Array.Sort(arrYValues)
                Dim plot1 As New BoxPlotSeriesMgr
                Dim arrVal() As Double = plot1.GetValuesForBoxPlot(arrYValues)
                Dim xAxisTick As String = dtValue.Rows(0)("STDATE")
                'If ColCondition = "Pot" Then
                '    'If dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAAL" Then
                '    '    xAxisTick = "Actual Al_AL"
                '    'ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAFE_AL" Then
                '    '    xAxisTick = "Actual Fe_AL"
                '    'ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAGA" Then
                '    '    xAxisTick = "Actual Al_GA"
                '    'ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAFE_GA" Then
                '    '    xAxisTick = "Actual Fe_GA"
                '    'ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAZS" Then
                '    '    xAxisTick = "Actual Al_GI"
                '    'ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAFE_ZS" Then
                '    '    xAxisTick = "Actual Fe_GI"
                '    'End If
                '    If dtValue.Rows(0)("CLR_PARAM_TEST") = "GA_AL" Then
                '        xAxisTick = "Actual Al_GA"
                '    ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "GA_FE" Then
                '        xAxisTick = "Actual Fe_GA"
                '    ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "GI_AL" Then
                '        xAxisTick = "Actual Al_GI"
                '    ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "GI_FE" Then
                '        xAxisTick = "Actual Fe_GI"
                '    End If
                'ElseIf ColCondition = "Eff" Then
                '    'If dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAAL" Then
                '    '    xAxisTick = "Eff. Al_AL"
                '    'ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAFE_AL" Then
                '    '    xAxisTick = "Eff. Fe_AL"
                '    'ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAGA" Then
                '    '    xAxisTick = "Eff. Al_GA"
                '    'ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAFE_GA" Then
                '    '    xAxisTick = "Eff. Fe_GA"
                '    'ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAZS" Then
                '    '    xAxisTick = "Eff. Al_GI"
                '    'ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "ZAFE_ZS" Then
                '    '    xAxisTick = "Eff. Fe_GI"
                '    'End If
                '    If dtValue.Rows(0)("CLR_PARAM_TEST") = "GA_AL" Then
                '        xAxisTick = "Eff. Al_GA"
                '    ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "GA_FE" Then
                '        xAxisTick = "Eff. Fe_GA"
                '    ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "GI_AL" Then
                '        xAxisTick = "Eff. Al_GI"
                '    ElseIf dtValue.Rows(0)("CLR_PARAM_TEST") = "GI_FE" Then
                '        xAxisTick = "Eff. Fe_GI"
                '    End If
                'End If

                If i = Series.Length - 1 Then
                    js &= "" &
                    "['" & xAxisTick & "', " & arrVal(4) & ", " & arrVal(1) & ", " & arrVal(8) & ", " & arrVal(5) & ", " & arrYValues.Length & "]];"

                    AvgData &= "" &
                    "['" & xAxisTick & "', " & (arrYValues.Average) & "]];"
                Else
                    js &= "" &
                    "['" & xAxisTick & "', " & arrVal(4) & ", " & arrVal(1) & ", " & arrVal(8) & ", " & arrVal(5) & ", " & arrYValues.Length & "], "

                    AvgData &= "" &
                    "['" & xAxisTick & "', " & (arrYValues.Average) & "], "
                End If

                'Making data for outliers :-
                For j = 0 To arrYValues.Length - 1
                    If arrVal(8) >= arrYValues(j) Then
                        strarr.Add("['" & xAxisTick & "'," & arrYValues(j) & "]")
                    ElseIf arrVal(9) <= arrYValues(j) Then
                        strarr.Add("['" & xAxisTick & "'," & arrYValues(j) & "]")
                    End If
                Next
            Next 'MAIN LOOP ENDS

            js &= "" & vbCrLf

            'For Average Points

            js &= "var " & AvgVarName & " = [" & AvgData
            js &= "" & vbCrLf

            js &= vbCrLf
            'Storing outliers data in as variable.
            js &= "var " & OutlierDataVariable & " = ["
            For rw As Integer = 0 To strarr.Count - 1
                If rw > 0 Then
                    js &= ","
                End If
                js &= strarr(rw)
            Next
            js &= "];" & vbCrLf

            js &= "" & vbCrLf &
                    "$(document).ready(function () {" & vbCrLf &
                            "$.jqplot.config.enablePlugins = true;" & vbCrLf &
                            "title: '" & ChartTitle & "'," & vbCrLf &
                            PlotName & " = $.jqplot('" & containerName & "', [" & DataVariable & ", " & OutlierDataVariable & ", " & AvgVarName & "], {" & vbCrLf &
                            "axesDefaults: { tickRenderer: $.jqplot.CanvasAxisTickRenderer, tickOptions: {fontSize: '8pt'}}," & vbCrLf &
                            "axes: {" & vbCrLf &
                                "xaxis: {" & vbCrLf &
                                    "renderer:$.jqplot.CategoryAxisRenderer," & vbCrLf &
                                    "label: ''," & vbCrLf &
                                    tickOptions & vbCrLf &
                                    "//tickOptions: { formatString: '%d-%m-%y' }" & vbCrLf &
                                "}," & vbCrLf &
                                "yaxis: {" & vbCrLf &
                                    "label: '" & YAxisLabelName & "'," & vbCrLf &
                                    "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
                                "}," & vbCrLf &
                            "}, animate: true, " & vbCrLf &
                            "title: '" & ChartTitle & "'," & vbCrLf &
                            "series: [" & vbCrLf &
                            "       {" & vbCrLf &
                            "           highlighter: {show: true, showMarker: false,tooltipAxes:'xy',yvalues: 5,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td style=""display: none;"">Observations: </td><td style=""display: none;"">%s</td></tr> \ <tr><td>Upper Quartile: </td><td>%s</td></tr> \ <tr><td>Maximum: </td><td>%s</td></tr> \ <tr><td>Minimum: </td><td>%s</td></tr> \ <tr><td>Lower Quartile: </td><td>%s</td></tr> \ <tr><td>No Of Data Points: </td><td>%s</td></tr> </table>' }," & vbCrLf &
                            "           renderer: $.jqplot.OHLCRenderer, rendererOptions: {" & vbCrLf &
                            "               candleStick: true, lineWidth: 2, bodyWidth: 40, wickColor: '#60A62E', upBodyColor: '#00008B', downBodyColor: '#00008B'" & vbCrLf &
                            "           }" & vbCrLf &
                            "       }," & vbCrLf &
                            "{showLine:false, markerOptions: {style: ""circle"", shadow: false, color: '#4BB2C5'}, highlighter: {show: true, showMarker: false,tooltipAxes:'xy',yvalues: 1,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td style=""display:none;"">%s</td></tr> \ <tr><td>%s</td></tr> </table>' }}," & vbCrLf &
                            "{lineWidth:1, color: '#006400', showLine: false, showMarker:true, markerOptions: { style: 'filledCircle' }, highlighter: {show: true, showMarker: false,tooltipAxes:'xy',yvalues: 1,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td style=""display:none;"">%s</td></tr> \ <tr><td>%s</td></tr> </table>' }}" & vbCrLf &
                            "]," & vbCrLf &
                            "seriesDefaults:{pointLabels:{show:false}}," & vbCrLf &
                            "" & vbCrLf &
                            "" & vbCrLf &
                            "" & vbCrLf &
                            "cursor: {" & vbCrLf &
                            "zoom: true," & vbCrLf &
                            "show: true," & vbCrLf &
                            "}," & vbCrLf &
                            "grid: {backgroundColor: 'rgb(255,255,255)'}," & vbCrLf &
                        "});" & vbCrLf &
                    "});" & vbCrLf &
                "</script>"
            lit.Text = js
        Catch ex As Exception

        End Try
    End Sub

    Sub BoxPlotForDescAnalSPM_Month(ByVal dt As DataTable, ByVal yValue As String, ByVal lit As Literal, ByVal containerName As String, ByVal PlotName As String, ByVal DataVariable As String, ByVal seriesOf As String, ByVal OutlierDataVariable As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String, ByVal AvgVarName As String, ByVal ColCondition As String, ByVal YMin As String, ByVal YMax As String)
        lit.Text = ""
        Try
            ChartTitle = ""
            Dim js = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                "var " & DataVariable & " = ["
            'Dim Series() = (From row In dt Select col = row.Field(Of String)(seriesOf) Distinct).ToArray
            Dim Series() = (From row In dt Select col = row.Field(Of String)(seriesOf) Distinct).ToArray
            Dim strarr As New ArrayList
            Dim AvgData = ""
            Dim tickOptions As String = IIf(Series.Length > 8, "tickOptions:{ angle: -30 },", "")
            For i As Integer = 0 To Series.Length - 1 'MAIN LOOP
                Dim sd As String = (Series(i))
                Dim x = i
                'Dim query = From val In dt.AsEnumerable() Where val.Field(Of String)(seriesOf) = Series(x) Select val
                Dim query = From val In dt.AsEnumerable() Where val.Field(Of String)(seriesOf) = Series(x) Select val
                Dim dtValue = query.CopyToDataTable()
                Dim arrYValues(dtValue.Rows.Count) As Decimal
                'arrYValues = (From row In dtValue Select col = Decimal.Parse(row(Trim(yValue)).ToString())).ToArray
                arrYValues = (From row In dtValue Where row("STDATE1") = sd Select col = Decimal.Parse(row(Trim(yValue)).ToString())).ToArray
                Array.Sort(arrYValues)
                Dim plot1 As New BoxPlotSeriesMgr
                Dim arrVal() As Double = plot1.GetValuesForBoxPlot(arrYValues)
                Dim xAxisTick As String = dtValue.Rows(0)("STDATE1")

                If i = Series.Length - 1 Then
                    js &= "" &
                    "['" & xAxisTick & "', " & arrVal(4) & ", " & arrVal(1) & ", " & arrVal(8) & ", " & arrVal(5) & ", " & arrYValues.Length & "]];"

                    AvgData &= "" &
                    "['" & xAxisTick & "', " & (arrYValues.Average) & "]];"
                Else
                    js &= "" &
                    "['" & xAxisTick & "', " & arrVal(4) & ", " & arrVal(1) & ", " & arrVal(8) & ", " & arrVal(5) & ", " & arrYValues.Length & "], "

                    AvgData &= "" &
                    "['" & xAxisTick & "', " & (arrYValues.Average) & "], "
                End If

                'Making data for outliers :-
                For j = 0 To arrYValues.Length - 1
                    If arrVal(8) >= arrYValues(j) Then
                        strarr.Add("['" & xAxisTick & "'," & arrYValues(j) & "]")
                    ElseIf arrVal(9) <= arrYValues(j) Then
                        strarr.Add("['" & xAxisTick & "'," & arrYValues(j) & "]")
                    End If
                Next
            Next 'MAIN LOOP ENDS

            js &= "" & vbCrLf

            'For Average Points

            js &= "var " & AvgVarName & " = [" & AvgData
            js &= "" & vbCrLf

            js &= vbCrLf
            'Storing outliers data in as variable.
            js &= "var " & OutlierDataVariable & " = ["
            For rw As Integer = 0 To strarr.Count - 1
                If rw > 0 Then
                    js &= ","
                End If
                js &= strarr(rw)
            Next
            js &= "];" & vbCrLf

            js &= "" & vbCrLf &
                    "$(document).ready(function () {" & vbCrLf &
                            "$.jqplot.config.enablePlugins = true;" & vbCrLf &
                            "title: '" & ChartTitle & "'," & vbCrLf &
                            PlotName & " = $.jqplot('" & containerName & "', [" & DataVariable & ", " & OutlierDataVariable & ", " & AvgVarName & "], {" & vbCrLf &
                            "axesDefaults: { tickRenderer: $.jqplot.CanvasAxisTickRenderer, tickOptions: {fontSize: '8pt'}}," & vbCrLf &
                            "axes: {" & vbCrLf &
                                "xaxis: {" & vbCrLf &
                                    "renderer:$.jqplot.CategoryAxisRenderer," & vbCrLf &
                                    "label: ''," & vbCrLf &
                                    tickOptions & vbCrLf &
                                    "//tickOptions: { formatString: '%d-%m-%y' }" & vbCrLf &
                                "}," & vbCrLf &
                                "yaxis: {" & vbCrLf &
                                    "label: '" & YAxisLabelName & "'," & vbCrLf &
                                    "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
                                "}," & vbCrLf &
                            "}, animate: true, " & vbCrLf &
                            "title: '" & ChartTitle & "'," & vbCrLf &
                            "series: [" & vbCrLf &
                            "       {" & vbCrLf &
                            "           highlighter: {show: true, showMarker: false,tooltipAxes:'xy',yvalues: 5,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td style=""display: none;"">Observations: </td><td style=""display: none;"">%s</td></tr> \ <tr><td>Upper Quartile: </td><td>%s</td></tr> \ <tr><td>Maximum: </td><td>%s</td></tr> \ <tr><td>Minimum: </td><td>%s</td></tr> \ <tr><td>Lower Quartile: </td><td>%s</td></tr> \ <tr><td>No Of Data Points: </td><td>%s</td></tr> </table>' }," & vbCrLf &
                            "           renderer: $.jqplot.OHLCRenderer, rendererOptions: {" & vbCrLf &
                            "               candleStick: true, lineWidth: 2, bodyWidth: 40, wickColor: '#60A62E', upBodyColor: '#00008B', downBodyColor: '#00008B'" & vbCrLf &
                            "           }" & vbCrLf &
                            "       }," & vbCrLf &
                            "{showLine:false, markerOptions: {style: ""circle"", shadow: false, color: '#4BB2C5'}, highlighter: {show: true, showMarker: false,tooltipAxes:'xy',yvalues: 1,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td style=""display:none;"">%s</td></tr> \ <tr><td>%s</td></tr> </table>' }}," & vbCrLf &
                            "{lineWidth:1, color: '#006400', showLine: false, showMarker:true, markerOptions: { style: 'filledCircle' }, highlighter: {show: true, showMarker: false,tooltipAxes:'xy',yvalues: 1,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td style=""display:none;"">%s</td></tr> \ <tr><td>%s</td></tr> </table>' }}" & vbCrLf &
                            "]," & vbCrLf &
                            "seriesDefaults:{pointLabels:{show:false}}," & vbCrLf &
                            "" & vbCrLf &
                            "" & vbCrLf &
                            "" & vbCrLf &
                            "cursor: {" & vbCrLf &
                            "zoom: true," & vbCrLf &
                            "show: true," & vbCrLf &
                            "}," & vbCrLf &
                            "grid: {backgroundColor: 'rgb(255,255,255)'}," & vbCrLf &
                        "});" & vbCrLf &
                    "});" & vbCrLf &
                "</script>"
            lit.Text = js
        Catch ex As Exception

        End Try
    End Sub
    Sub BoxPlotForDescAnalSPM_Week(ByVal dt As DataTable, ByVal yValue As String, ByVal lit As Literal, ByVal containerName As String, ByVal PlotName As String, ByVal DataVariable As String, ByVal seriesOf As String, ByVal OutlierDataVariable As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String, ByVal AvgVarName As String, ByVal ColCondition As String, ByVal YMin As String, ByVal YMax As String)
        lit.Text = ""
        Try
            ChartTitle = ""
            Dim js = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                "var " & DataVariable & " = ["
            'Dim Series() = (From row In dt Select col = row.Field(Of String)(seriesOf) Distinct).ToArray
            Dim Series() = (From row In dt Select col = row.Field(Of String)(seriesOf) Distinct).ToArray
            Dim strarr As New ArrayList
            Dim AvgData = ""
            Dim tickOptions As String = IIf(Series.Length > 8, "tickOptions:{ angle: -30 },", "")
            For i As Integer = 0 To Series.Length - 1 'MAIN LOOP
                Dim sd As String = (Series(i))
                Dim x = i
                'Dim query = From val In dt.AsEnumerable() Where val.Field(Of String)(seriesOf) = Series(x) Select val
                Dim query = From val In dt.AsEnumerable() Where val.Field(Of String)(seriesOf) = Series(x) Select val
                Dim dtValue = query.CopyToDataTable()
                Dim arrYValues(dtValue.Rows.Count) As Decimal
                'arrYValues = (From row In dtValue Select col = Decimal.Parse(row(Trim(yValue)).ToString())).ToArray
                arrYValues = (From row In dtValue Where row("STDATE2") = sd Select col = Decimal.Parse(row(Trim(yValue)).ToString())).ToArray
                Array.Sort(arrYValues)
                Dim plot1 As New BoxPlotSeriesMgr
                Dim arrVal() As Double = plot1.GetValuesForBoxPlot(arrYValues)
                Dim xAxisTick As String = "Week " & dtValue.Rows(0)("STDATE2")

                If i = Series.Length - 1 Then
                    js &= "" &
                    "['" & xAxisTick & "', " & arrVal(4) & ", " & arrVal(1) & ", " & arrVal(8) & ", " & arrVal(5) & ", " & arrYValues.Length & "]];"

                    AvgData &= "" &
                    "['" & xAxisTick & "', " & (arrYValues.Average) & "]];"
                Else
                    js &= "" &
                    "['" & xAxisTick & "', " & arrVal(4) & ", " & arrVal(1) & ", " & arrVal(8) & ", " & arrVal(5) & ", " & arrYValues.Length & "], "

                    AvgData &= "" &
                    "['" & xAxisTick & "', " & (arrYValues.Average) & "], "
                End If

                'Making data for outliers :-
                For j = 0 To arrYValues.Length - 1
                    If arrVal(8) >= arrYValues(j) Then
                        strarr.Add("['" & xAxisTick & "'," & arrYValues(j) & "]")
                    ElseIf arrVal(9) <= arrYValues(j) Then
                        strarr.Add("['" & xAxisTick & "'," & arrYValues(j) & "]")
                    End If
                Next
            Next 'MAIN LOOP ENDS

            js &= "" & vbCrLf

            'For Average Points

            js &= "var " & AvgVarName & " = [" & AvgData
            js &= "" & vbCrLf

            js &= vbCrLf
            'Storing outliers data in as variable.
            js &= "var " & OutlierDataVariable & " = ["
            For rw As Integer = 0 To strarr.Count - 1
                If rw > 0 Then
                    js &= ","
                End If
                js &= strarr(rw)
            Next
            js &= "];" & vbCrLf

            js &= "" & vbCrLf &
                    "$(document).ready(function () {" & vbCrLf &
                            "$.jqplot.config.enablePlugins = true;" & vbCrLf &
                            "title: '" & ChartTitle & "'," & vbCrLf &
                            PlotName & " = $.jqplot('" & containerName & "', [" & DataVariable & ", " & OutlierDataVariable & ", " & AvgVarName & "], {" & vbCrLf &
                            "axesDefaults: { tickRenderer: $.jqplot.CanvasAxisTickRenderer, tickOptions: {fontSize: '8pt'}}," & vbCrLf &
                            "axes: {" & vbCrLf &
                                "xaxis: {" & vbCrLf &
                                    "renderer:$.jqplot.CategoryAxisRenderer," & vbCrLf &
                                    "label: ''," & vbCrLf &
                                    tickOptions & vbCrLf &
                                    "//tickOptions: { formatString: '%d-%m-%y' }" & vbCrLf &
                                "}," & vbCrLf &
                                "yaxis: {" & vbCrLf &
                                    "label: '" & YAxisLabelName & "'," & vbCrLf &
                                    "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
                                "}," & vbCrLf &
                            "}, animate: true, " & vbCrLf &
                            "title: '" & ChartTitle & "'," & vbCrLf &
                            "series: [" & vbCrLf &
                            "       {" & vbCrLf &
                            "           highlighter: {show: true, showMarker: false,tooltipAxes:'xy',yvalues: 5,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td style=""display: none;"">Observations: </td><td style=""display: none;"">%s</td></tr> \ <tr><td>Upper Quartile: </td><td>%s</td></tr> \ <tr><td>Maximum: </td><td>%s</td></tr> \ <tr><td>Minimum: </td><td>%s</td></tr> \ <tr><td>Lower Quartile: </td><td>%s</td></tr> \ <tr><td>No Of Data Points: </td><td>%s</td></tr> </table>' }," & vbCrLf &
                            "           renderer: $.jqplot.OHLCRenderer, rendererOptions: {" & vbCrLf &
                            "               candleStick: true, lineWidth: 2, bodyWidth: 40, wickColor: '#60A62E', upBodyColor: '#00008B', downBodyColor: '#00008B'" & vbCrLf &
                            "           }" & vbCrLf &
                            "       }," & vbCrLf &
                            "{showLine:false, markerOptions: {style: ""circle"", shadow: false, color: '#4BB2C5'}, highlighter: {show: true, showMarker: false,tooltipAxes:'xy',yvalues: 1,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td style=""display:none;"">%s</td></tr> \ <tr><td>%s</td></tr> </table>' }}," & vbCrLf &
                            "{lineWidth:1, color: '#006400', showLine: false, showMarker:true, markerOptions: { style: 'filledCircle' }, highlighter: {show: true, showMarker: false,tooltipAxes:'xy',yvalues: 1,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td style=""display:none;"">%s</td></tr> \ <tr><td>%s</td></tr> </table>' }}" & vbCrLf &
                            "]," & vbCrLf &
                            "seriesDefaults:{pointLabels:{show:false}}," & vbCrLf &
                            "" & vbCrLf &
                            "" & vbCrLf &
                            "" & vbCrLf &
                            "cursor: {" & vbCrLf &
                            "zoom: true," & vbCrLf &
                            "show: true," & vbCrLf &
                            "}," & vbCrLf &
                            "grid: {backgroundColor: 'rgb(255,255,255)'}," & vbCrLf &
                        "});" & vbCrLf &
                    "});" & vbCrLf &
                "</script>"
            lit.Text = js
        Catch ex As Exception

        End Try
    End Sub
    Function GetYsUtsData(ByVal CoilId As String) As DataTable
        Try
            Dim dt As DataTable
            dt = objDataHandler.GetDataSetFromQuery("SELECT YS,UTS from CRM_SPM_PROCESS_DATA_COILWISE_BODY where DAUGHTER_COILID_NUM = '" & CoilId & "' ").Tables(0)
            Return dt
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try


    End Function
    Public Function GetBafCutOff() As DataTable
        Dim Query As String = "select * from BAF_LIMITS"
        Return objDataHandler.GetDataSetFromQuery(Query).Tables(0)
    End Function
    Public Function GetBafData(ByVal Filter As String) As DataTable
        Dim Query As String = "Select distinct STR_ID_STACK As StackID, STR_CYCLE As Cycle,ROUND(STR_TMINV_RESTAB/3600,2) As Interruption,STR_TM_HEATING_ST As StackingTime, STR_TM_COOLING_ST," & vbCrLf &
       "STR_TM_DESTACKING As DestackingTime, ROUND(STR_TMINV_RAMP/3600,2) As RampUp,ROUND(STR_DR_MX_TP_SEG/60,2) AS SoakingTime,STR_TOT_H2_CONSP As H2Consumption," & vbCrLf &
       "STR_RECIPE As Recipe,STR_TP_MX_SET_PT AS SoakingTemp, STR_ID_HEAT_HOOD As HHNo,STR_ID_BASE AS BaseId, STR_ID_COOL_HOOD As CoolingHoodNo,STR_TOT_N2_CONSP AS N2Consumption,STR_MS_TOT_COILS/1000 As StackWeight," & vbCrLf &
       "cast(STR_TM_EVENT11 - STR_TM_EVENT10 as numeric(10,2)) * 24 As HHCoolingTime,ROUND(cast(STR_TM_EVENT10 - STR_TM_EVENT9 as numeric(10,2)) * 24  - STR_TMINV_RAMP/3600 - STR_DR_MX_TP_SEG/60 - STR_TMINV_RESTAB/3600,2) AS ControlledHeating,cast(STR_TM_EVENT16 - STR_TM_EVENT15 as numeric(10,2)) * 24 As CoolingHoodTime,cast(STR_TM_EVENT16 - STR_TM_EVENT15 as numeric(10,2)) * 24 As BypassCoolingTime," & vbCrLf &
       "ANC_POSITION AS Position, CCL_ID_COIL As CoilId,CCL_SHAPE_GRADE, CCL_SURFACE_GRADE as SurGrade,ANC_GRD_STEEL as Grade, CCL_TDC_AIM As TDC,CCL_TDC_ACTL, CCL_SEC1 As Thickness, CCL_SEC2 As Width,SPL_ODIA AS OD,ROUND(((1 - FHC_SEC1_CR_COIL / FHC_SEC1_HR_COIL1) * 100),2) As TCMReduction," & vbCrLf &
       "STS_TS_SPLY_COMPL AS MNBayPostECL,LTR_TEST_VALUE  as EL, LTR_SEQ_SAMPLE" & vbCrLf &
        " as RA,'' AS mnbaypreeclage,STS_NO_CCSU AS ccsuno,cast(SPL_TM_ROLL_ST - STR_TM_DESTACKING as numeric(10,0))* 24 AS ccsuage,'' AS H2Segment, '' AS H2Segmentwise, '' AS ys, '' AS uts,FHC_LN_CR_COIL/ 1000 AS TCMRollLength,STR_H2_CONSP1/10 as STR_H2_CONSP1,STR_H2_CONSP2/10 as STR_H2_CONSP2" & vbCrLf &
        ",STR_H2_CONSP3/10 as STR_H2_CONSP3,STR_H2_CONSP4/10 as STR_H2_CONSP4,STR_H2_CONSP5/10 as STR_H2_CONSP5,ROUND(STR_H2_CONSP1/NULLIF(cast(STR_TM_PURGE_ST2 - STR_TM_PURGE_ST1 as numeric(10,2))* 24,0),2) as H2Consp10,ROUND(STR_H2_CONSP2/NULLIF(cast(STR_TM_PURGE_ST3 - STR_TM_PURGE_ST2 as numeric(10,2))* 24,0),2) as H2Consp11,ROUND(STR_H2_CONSP3/NULLIF(cast(STR_TM_PURGE_ST4 - STR_TM_PURGE_ST3 as numeric(10,2))* 24,0),2) as H2Consp12,ROUND(STR_H2_CONSP4/NULLIF(cast(STR_TM_PURGE_ST5 - STR_TM_PURGE_ST4 as numeric(10,2))* 24,0),2) as H2Consp13,ROUND(STR_H2_CONSP5/NULLIF(cast(STR_TM_PURGE_ST6 - STR_TM_PURGE_ST5 as numeric(10,2))* 24,0),2) as H2Consp14" & vbCrLf &
        ",STR_TM_PURGE_ST1,STR_TM_PURGE_ST2,STR_TM_PURGE_ST3,STR_TM_PURGE_ST4,STR_TM_PURGE_ST5,STR_TM_PURGE_ST6" & vbCrLf &
      "  From T_BAF_DETAILS " & vbCrLf &
        "" & Filter & ""
        Return objDataHandler.GetDataSetFromQuery(Query).Tables(0)

    End Function

    Public Function GetDataForSFMonitoring(ByVal FromDate As String, ByVal ToDate As String) As DataTable
        Dim query As String = ""
        query = "select distinct T.[PSM_HR_COIL_ID],T.[PSM_SF_RATIO],T1.[PTCI_GRADE],T1.[PTCI_DATETIME],T2.[HR_WIDTH] from [dbo].[CRM_PLTCM_SPEEDFACTOR_MONOTOTING] T inner join [dbo].[CRM_PLTCM_TCM_COIL_INFO] T1 on T.[PSM_HR_COIL_ID] = T1.[PTCI_COIL_ID] inner join[dbo].[CRM_HR_CR_RLN] T2 on T.[PSM_HR_COIL_ID] = T2.[HR_COIL_ID] where T1.[PTCI_DATETIME] between '" & FromDate & "'  and '" & ToDate & "' order by T1.[PTCI_DATETIME] "
        'query = "select DAUGHTER_COILID_NUM,isnull(ROLLFORCE * 102.0408,0) as ROLLFORCE,isnull(ENLONGATION_ACT*100,0) as ENLONGATION,GRADE,isnull(YS,0) as YS,isnull(UTS,0) as UTS,convert(date,COIL_STARTDATETIME) as STDATE,convert(char(3),DATENAME(month,COIL_STARTDATETIME)) + '' + convert(varchar,datepart(yy,COIL_STARTDATETIME)) as STDATE1,convert(char(3),DATENAME(week,COIL_STARTDATETIME)) as STDATE2 from TableName where DateColumn between '" & FromDate & "' and '" & ToDate & "' and (GRADE <> '0' and GRADE is not null) order by STDATE"


        Return objDataHandler.GetDataSetFromQuery(query).Tables(0)
    End Function

    Public Sub PlotLineChartForSFMonitoring(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String, ByVal GroupByColName As String)
        Try

            LiteralName.Text = ""
            Dim min_time, max_time As String
            min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-30), "yyyy-MM-dd HH:mm")
            max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm")

            'Dim xTimestampVal(), yVal() As String
            Dim yVal() As Decimal
            'xTimestampVal = (From row In dt Select col = row(XAxisColName).ToString).ToArray
            yVal = (From row In dt Select col = CDec(row(YAxisColName))).ToArray()

            'Dim y_min As String = yVal.Min()
            'Dim y_max As String = yVal.Max()
            Dim y_min As String = yVal.Min() - (10 / 100 * yVal.Min)
            Dim y_max As String = yVal.Max() + (10 / 100 * yVal.Max)

            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf
            dt.DefaultView.RowFilter = ""
            Dim dtGrades As DataTable = dt.DefaultView.ToTable(True, GroupByColName) 'All distinct Grades
            Dim dvDefault As DataView = dt.DefaultView
            Dim flag As Boolean = False
            For i As Integer = 0 To dtGrades.Rows.Count - 1
                js &= "var line" & (i + 1).ToString & " = ["
                dvDefault.RowFilter = "" & GroupByColName & "='" & dtGrades.Rows(i)(0) & "'"
                For j As Integer = 0 To dvDefault.Count - 1
                    If j > 0 Then
                        js &= ","
                    End If
                    js &= "["
                    Dim dtTime As DateTime = dvDefault.Item(j)("PTCI_DATETIME")
                    If IsDBNull(dvDefault.Item(j)(GroupByColName)) Then
                        If IsDBNull(dvDefault.Item(j)("PSM_SF_RATIO")) = False Then
                            js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)("PSM_SF_RATIO") & ", " & "null"
                        Else
                            js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & "null, null"
                        End If
                    Else
                        If IsDBNull(dvDefault.Item(j)("PSM_SF_RATIO")) = False Then
                            js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)("PSM_SF_RATIO") & ", '(" & dvDefault.Item(j)(GroupByColName).ToString().Trim & ")'"
                            'js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)("CLR_TEST_VALUE") & ", 'Pot'"
                        End If
                    End If
                    js &= "]"
                Next
                js &= "];" & vbCrLf
                flag = True
            Next

            Dim strg As String = ""
            Dim strseries As String = ""
            If flag Then
                strg = "[line1"
                strseries = " {pointLabels: { show:true }, showLine:false, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
                For i As Integer = 1 To dtGrades.Rows.Count - 1
                    strg = strg + ",line" & i + 1
                    strseries = strseries + ", {pointLabels: { show:true }, showLine:false, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
                Next
                strg &= "]"
            End If
            js &= "var seriesName = ['"
            Dim str As String = ""
            For i As Integer = 0 To dtGrades.Rows.Count - 1
                str &= dtGrades.Rows(i)(0).ToString().Trim() + "', '"
            Next
            str = str.Remove(str.LastIndexOf(", '"))
            str &= "];"
            js &= str
            js &= "opts = {" & vbCrLf &
            "title: '" & ChartTitle & "'," & vbCrLf &
            "series:[" & strseries & "]," & vbCrLf &
            "//seriesColors: ['#FFA500']," & vbCrLf &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            "fontSize:'8pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf &
            "renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
            "tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," & vbCrLf &
            "//tickInterval:'1 hour'," & vbCrLf &
            "pad:0" & vbCrLf &
            "}," & vbCrLf &
            "yaxis: { " & vbCrLf &
            "tickOptions: { formatString: '%.3f' }," & vbCrLf &
            "min: " & y_min & "," & vbCrLf &
            "max: " & y_max & "," & vbCrLf &
            "autoscale:true," & vbCrLf &
            "label: '" & YAxisLabelName & "'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "showTooltip: false," & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "animate: true," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
            "legend: {" & vbCrLf &
            "show: true," & vbCrLf &
            "location: 's'," & vbCrLf &
            "labels: seriesName," & vbCrLf &
            "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
            "placement: 'outsideGrid'," & vbCrLf &
            "rendererOptions: {" & vbCrLf &
            "numberRows: 1," & vbCrLf &
            "marginTop: 10" & vbCrLf &
            "}" & vbCrLf &
            "}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "', " & strg & ", opts);" & vbCrLf &
            "</script>" & vbCrLf

            LiteralName.Text = js
        Catch ex As Exception

        End Try
    End Sub

    Public Sub PlotChartForSFMonitoring(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String, ByVal GroupByColName As String, Optional ByVal selection As String = "", Optional ByVal selectionLegend As String = "")
        Try

            LiteralName.Text = ""
            Dim min_time, max_time As String
            min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-30), "yyyy-MM-dd HH:mm")
            max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm")

            Dim arrSeriesColor() As String = {"#89cff0", "#4682b4", "#000080", "#f00699", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000"}
            Dim seriesColor As String = "['"
            'Dim xTimestampVal(), yVal() As String
            Dim yVal() As Decimal

            'xTimestampVal = (From row In dt Select col = row(XAxisColName).ToString).ToArray
            yVal = (From row In dt Select col = CDec(row(YAxisColName))).ToArray()

            'Dim y_min As String = yVal.Min()
            'Dim y_max As String = yVal.Max()
            Dim y_min As String = yVal.Min() - (10 / 100 * yVal.Min)
            Dim y_max As String = yVal.Max() + (10 / 100 * yVal.Max)

            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf
            dt.DefaultView.RowFilter = ""
            Dim dtGrades As DataTable = dt.DefaultView.ToTable(True, GroupByColName) 'All distinct Grades
            Dim legend As String = ""
            Dim dvDefault As DataView = dt.DefaultView
            Dim flag As Boolean = False
            For i As Integer = 0 To dtGrades.Rows.Count - 1
                legend &= ",'" & dtGrades.Rows(i)(0) & "'"
                js &= "var line" & (i + 1).ToString & " = ["
                dvDefault.RowFilter = "" & GroupByColName & "='" & dtGrades.Rows(i)(0) & "'"

                For j As Integer = 0 To dvDefault.Count - 1
                    If j > 0 Then
                        js &= ","
                    End If
                    js &= "["
                    Dim dtTime As DateTime = dvDefault.Item(j)(XAxisColName)
                    If IsDBNull(dvDefault.Item(j)(GroupByColName)) Then
                        If IsDBNull(dvDefault.Item(j)(YAxisColName)) = False Then
                            js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)(YAxisColName) & ", " & "null"
                        Else
                            js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & "null, null"
                        End If
                    Else
                        If IsDBNull(dvDefault.Item(j)(YAxisColName)) = False Then
                            'js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)(YAxisColName) & ", '(" & dvDefault.Item(j)(GroupByColName).ToString().Trim & ")'"
                            'js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)(YAxisColName) & ", '" & dvDefault.Item(j)(GroupByColName).ToString().Trim & "', '" & dvDefault.Item(j)("PSM_HR_COIL_ID").ToString().Trim & "'"
                            js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)(YAxisColName) & ", '" & dvDefault.Item(j)(GroupByColName).ToString().Trim & "', '" & dvDefault.Item(j)("PSM_HR_COIL_ID").ToString().Trim & "'"



                        End If
                    End If
                    js &= "]"
                Next
                js &= "];" & vbCrLf
                flag = True
                If i > 0 Then

                    seriesColor &= ", '"
                End If
                seriesColor &= arrSeriesColor(i) & "'"
            Next


            Dim strg As String = ""
            Dim strseries As String = ""
            If flag Then
                strg = "[line1"
                strseries = " {pointLabels: { show:true }, showLine:false, lineWidth:2, markerOptions:{ size: 10 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 3,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
                For i As Integer = 1 To dtGrades.Rows.Count - 1
                    strg = strg + ",line" & i + 1
                    strseries = strseries + ", {pointLabels: { show:true }, showLine:false, lineWidth:2, markerOptions:{ size: 10 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 3,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
                Next
                strg &= "]"
                'strseries = strseries + ",{pointLabels: { show:false }, yaxis:'y2axis', showLine:false, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
            End If
            js &= "var seriesName = ['"
            Dim str As String = ""
            For i As Integer = 0 To dtGrades.Rows.Count - 1
                str &= dtGrades.Rows(i)(0).ToString().Trim() + "', '"
            Next
            seriesColor &= "]"
            str = str.Remove(str.LastIndexOf(", '"))
            str &= "];"
            js &= str
            js &= "opts = {" & vbCrLf &
            "title: '" & ChartTitle & "'," & vbCrLf &
            "series:[" & strseries & "]," & vbCrLf &
             "seriesColors: " & seriesColor & "," & vbCrLf &
            "//seriesColors: ['#FFA500']," & vbCrLf &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            "fontSize:'8pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf &
            "renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
            "tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," & vbCrLf &
            "//tickInterval:'1 hour'," & vbCrLf &
            "label:'CR Width (mm)'," & vbCrLf &
            "pad:0" & vbCrLf &
            "}," & vbCrLf &
            "yaxis: { " & vbCrLf &
            "tickOptions: { formatString: '%.3f' }," & vbCrLf &
            "min: " & y_min & "," & vbCrLf &
            "max: " & y_max & "," & vbCrLf &
            "autoscale:true," & vbCrLf &
            "label: '" & YAxisLabelName & "'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "showTooltip: false," & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "animate: true," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
            "legend: {" & vbCrLf &
            "show: true," & vbCrLf &
            "location: 's'," & vbCrLf &
            "labels: [" & legend.Substring(1) & "]," & vbCrLf &
            "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
            "placement: 'outsideGrid'," & vbCrLf &
            "rendererOptions: {" & vbCrLf &
            "numberRows: 1," & vbCrLf &
            "marginTop: 10" & vbCrLf &
            "}" & vbCrLf &
            "}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "', " & strg & ", opts);</script>" & vbCrLf


            LiteralName.Text = js
        Catch ex As Exception

        End Try
    End Sub

    Public Sub PlotScatterChartForSFMonitoring(ByVal dt As DataTable, ByVal XValue As String, ByVal YValue As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal XaxisName As String, YaxisName As String)

        Try
            Dim js As String = ""
            Dim xVal(), yVal() As Decimal
            Dim decimalVal As String = ""
            'If XValue = "ENLONGATION" Then
            '    decimalVal = "%.2f"
            'Else
            decimalVal = "%.0f"
            'End If
            xVal = (From row In dt.AsEnumerable().Where(Function(r) r.Field(Of Decimal)(XValue) > 0) Select col = CDec(row(Trim(XValue)))).ToArray
            yVal = (From row In dt.AsEnumerable().Where(Function(r) r.Field(Of Decimal)(YValue) > 0) Select col = CDec(row(Trim(YValue)))).ToArray
            Dim xmin = xVal.Min() - (xVal.Min() * 0.1)
            Dim xmax = xVal.Max() + (xVal.Max() * 0.1)
            Dim ymin = yVal.Min() - (yVal.Min() * 0.1)
            Dim ymax = yVal.Max() + (yVal.Max() * 0.1)
            xVal = Nothing
            yVal = Nothing
            Dim arrGrades() As String = (From row In dt Select col = row.Field(Of String)("PTCI_GRADE") Distinct).ToArray()
            Dim arrSeriesColor() As String = {"#021277", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#021277", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000", "#021277", "#a100ff", "#ff00a5", "#d5d811", "#048e0d", "#996633", "#666699", "#009999", "#800000", "#FF9900", "#ff0000"}
            'Dim arrSeriesColor() As String = {"#0000FF", "#00FF00", "#FFFF00", "#00FFFF", "#FF00FF", "#800000", "#808000", "#00FFFF", "#4682B4", "#00BFFF", "#1E90FF", "#4169E1", "#BA55D3", "#DDA0DD", "#A0522D", "#CD853F", "#BC8F8F", "#708090", "#B0C4DE", "#4B0082", "#48D1CC", "#008B8B", "#8FBC8F", "#DC143C", "#FF6347", "#F08080", "#E9967A", "#FFA500", "#B8860B", "#BDB76B", "#F0E68C", "#9ACD32", "#7CFC00", "#008B8B"}
            Dim series As String = ""
            Dim legend As String = "var series = ['"
            Dim seriesColor As String = "['"
            Dim chartSeries As String = "[{"
            js = "<script language='javascript' type='text/javascript'>" & vbCrLf &
               "$(document).ready(function(){" & vbCrLf &
               "$.jqplot.config.enablePlugins = true;" & vbCrLf

            For i As Integer = 0 To arrGrades.Length - 1
                Dim x = i
                Dim xValues() As Decimal = (From row In dt.AsEnumerable().Where(Function(r) r.Field(Of String)("PTCI_GRADE") = arrGrades(x)) Select col = CDec(row(XValue))).ToArray
                Dim yValues() As Decimal = (From row In dt.AsEnumerable().Where(Function(r) r.Field(Of String)("PTCI_GRADE") = arrGrades(x)) Select col = CDec(row(YValue))).ToArray
                Dim coilId() As String = (From row In dt.AsEnumerable().Where(Function(r) r.Field(Of String)("PTCI_GRADE") = arrGrades(x)) Select col = CStr(row("PSM_HR_COIL_ID"))).ToArray

                js &= "var data" & i & " = [["
                For j As Integer = 0 To xValues.Length - 1
                    If j = xValues.Length - 1 Then
                        js &= xValues.GetValue(j).ToString().Trim() & ", " & yValues.GetValue(j).ToString().Trim() & ", '" & arrGrades(i) & "','" & coilId.GetValue(j).ToString().Trim & "']]; " & vbCrLf
                    Else
                        js &= xValues.GetValue(j).ToString().Trim() & ", " & yValues.GetValue(j).ToString().Trim() & ", '" & arrGrades(i) & "','" & coilId.GetValue(j).ToString().Trim & "'], ["
                    End If
                Next
                If i > 0 Then
                    legend &= ", '"
                    seriesColor &= ", '"
                    series &= ", "
                    chartSeries &= ", {"
                End If
                legend &= arrGrades(i) & "'"
                seriesColor &= arrSeriesColor(i) & "'"
                series &= "data" & i
                chartSeries &= "neighborThreshold: 0, showLine:false, showMarker:true}"
            Next
            legend &= "];"
            seriesColor &= "]"
            chartSeries &= ",{showLine:true, showMarker:false}],"

            js &= vbCrLf & "var line = [[" & xmin & "," & xmax & "],[" & ymin & "," & ymax & "]];" & vbCrLf
            js &= legend & vbCrLf
            js &= "opts = {" & vbCrLf &
            "//title: 'Billet temp Versus Laying Head Temp'," & vbCrLf &
            "seriesDefaults:{neighborThreshold: 0, showLine:false, showMarker:true,pointLabels:{show:true}, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 3,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>Width</td> <td>%s</td></tr>\ <tr><td>Speed</td> <td>%s</td></tr>\ <tr><td>Grade</td> <td>%s</td></tr>\ <tr><td>Id</td> <td>%s</td></tr></table>'}}," & vbCrLf &
            "seriesColors: " & seriesColor & "," & vbCrLf &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
           "tickOptions: {" & vbCrLf &
           "fontSize:'10pt'," & vbCrLf &
            "textColor: '#000000 '," & vbCrLf &
           "}" & vbCrLf &
           "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "tickOptions:{" & vbCrLf &
           "formatString: '" & decimalVal & "'," & vbCrLf &
            "textColor: '#000000 '," & vbCrLf &
             "}, " & vbCrLf &
              "label: '" & XaxisName & "'," & vbCrLf &
               "labelOptions: {" & vbCrLf &
            "textColor: '#000000 '," & vbCrLf &
               "}," & vbCrLf &
             "min: " & xmin & "," & vbCrLf &
            "max: " & xmax & "," & vbCrLf &
            "}," & vbCrLf &
            "yaxis: {" & vbCrLf &
             "tickOptions:{" & vbCrLf &
             "formatString: '" & decimalVal & "'," & vbCrLf &
            "textColor: '#000000 '," & vbCrLf &
             "}, " & vbCrLf &
             "label: '" & YaxisName & "'," & vbCrLf &
              "labelOptions: {" & vbCrLf &
            "textColor: '#000000 '," & vbCrLf &
               "}," & vbCrLf &
             "labelRenderer: $.jqplot.CanvasAxisLabelRenderer," & vbCrLf &
            "//pad:1" & vbCrLf &
             "min: " & ymin & "," & vbCrLf &
            "max: " & ymax & "," & vbCrLf &
             "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "//show: true, " & vbCrLf &
            "zoom: true, " & vbCrLf &
            "//followMouse: true," & vbCrLf &
            "//showTooltip: true, " & vbCrLf &
             "}," & vbCrLf &
             "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
            "legend: {" & vbCrLf &
            "show: true," & vbCrLf &
            "location: 's'," & vbCrLf &
            "labels: series," & vbCrLf &
            "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
            "placement: 'outsideGrid'," & vbCrLf &
            "rendererOptions: {" & vbCrLf &
            "numberRows: 1," & vbCrLf &
            "marginTop: 10" & vbCrLf &
            "}" & vbCrLf &
            "}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "', [" & series & "], opts);" & vbCrLf &
            "});" & vbCrLf &
            "</script>" & vbCrLf
            LiteralName.Text = js
        Catch ex As Exception
            ex.ToString()
        End Try

    End Sub
    'Public Sub PlotChartForPLTCMDashboard(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String)
    '    Try
    '        LiteralName.Text = ""
    '        'Dim min_time, max_time As String
    '        'min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-30), "yyyy-MM-dd HH:mm")
    '        'max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm")
    '        Dim yVal() As Decimal
    '        yVal = (From row In dt Select col = CDec(row(YAxisColName))).ToArray()

    '        'Dim y_min As String = yVal.Min()
    '        'Dim y_max As String = yVal.Max()
    '        'Dim y_min As String = yVal.Min() - (10 / 100 * yVal.Min)
    '        'Dim y_max As String = yVal.Max() + (10 / 100 * yVal.Max)
    '        Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf & _
    '             "$.jqplot.config.enablePlugins = true;" & vbCrLf
    '        js &= "var line1 = ["
    '        For i As Integer = 0 To dt.Rows.Count - 1
    '            js &= "['" & dt.Rows(i)("COIL_DATE") & "'," & dt.Rows(i)("CR_COIL_WT") & "],"

    '        Next
    '        js &= "];"
    '        js &= "var line2 = ["
    '        For i As Integer = 0 To dt.Rows.Count - 1
    '            js &= "['" & dt.Rows(i)("COIL_DATE") & "'," & dt.Rows(i)("CR_COIL_ID") & "],"

    '        Next
    '        js &= "];"

    '        js &= "var " & PlotName & " = $.jqplot('" & ContainerName & "', [line1, line2], {"
    '        js &= "series:[{renderer:$.jqplot.BarRenderer}, {yaxis:'y2axis'}],"
    '        js &= "axesDefaults: {  tickRenderer: $.jqplot.CanvasAxisTickRenderer ,tickOptions: {  angle: 30 }},"
    '        js &= "axes: {"
    '        js &= "xaxis: { renderer: $.jqplot.CategoryAxisRenderer },"
    '        js &= "x2axis: { renderer: $.jqplot.CategoryAxisRenderer },"
    '        js &= "yaxis: { autoscale:true },"
    '        js &= " y2axis: { autoscale:true }"
    '        js &= "}});"
    '        js &= "</script>"
    '        LiteralName.Text = js

    '    Catch ex As Exception

    '    End Try

    'End Sub
    Public Sub PlotChartForPLTCMDashboardBar(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String)
        Try
            LiteralName.Text = ""
            'Dim min_time, max_time As String
            'min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-30), "yyyy-MM-dd HH:mm")
            'max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm")
            Dim yVal() As Decimal
            yVal = (From row In dt Select col = CDec(row(YAxisColName))).ToArray()

            'Dim y_min As String = yVal.Min()
            'Dim y_max As String = yVal.Max()
            'Dim y_min As String = yVal.Min() - (10 / 100 * yVal.Min)
            'Dim y_max As String = yVal.Max() + (10 / 100 * yVal.Max)
            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                 "$.jqplot.config.enablePlugins = true;" & vbCrLf
            js &= "var line1 = ["
            For i As Integer = 0 To dt.Rows.Count - 1
                js &= "['" & dt.Rows(i)("COIL_DATE") & "'," & dt.Rows(i)("CR_COIL_WT") & "],"

            Next
            js &= "];"
            'js &= "var line2 = ["
            'For i As Integer = 0 To dt.Rows.Count - 1
            '    js &= "['" & dt.Rows(i)("COIL_DATE") & "'," & dt.Rows(i)("CR_COIL_ID") & "],"

            'Next
            'js &= "];"

            js &= "var " & PlotName & " = $.jqplot('" & ContainerName & "', [line1], {"
            js &= "series:[{renderer:$.jqplot.BarRenderer}],"
            js &= "axesDefaults: {  tickRenderer: $.jqplot.CanvasAxisTickRenderer ,tickOptions: {  angle: 30  }},"
            js &= "seriesColors:['#0B62A4'],"
            js &= "axes: {"
            js &= "xaxis: { renderer: $.jqplot.CategoryAxisRenderer },"
            js &= "x2axis: { renderer: $.jqplot.CategoryAxisRenderer },"
            js &= "yaxis: { tickOptions:{formatString:  '%.0f'},autoscale:true,label:'Tonne',labelRenderer: $.jqplot.CanvasAxisLabelRenderer },"
            js &= "}});"
            js &= "</script>"
            LiteralName.Text = js

        Catch ex As Exception

        End Try

    End Sub
    Public Sub PlotChartForPLTCMDashboardLine(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String)
        Try
            LiteralName.Text = ""
            'Dim min_time, max_time As String
            'min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-30), "yyyy-MM-dd HH:mm")
            'max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm")
            Dim yVal() As Decimal
            yVal = (From row In dt Select col = CDec(row(YAxisColName))).ToArray()

            'Dim y_min As String = yVal.Min()
            'Dim y_max As String = yVal.Max()
            'Dim y_min As String = yVal.Min() - (10 / 100 * yVal.Min)
            'Dim y_max As String = yVal.Max() + (10 / 100 * yVal.Max)
            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                 "$.jqplot.config.enablePlugins = true;" & vbCrLf
            js &= "var line1 = ["
            For i As Integer = 0 To dt.Rows.Count - 1
                js &= "['" & dt.Rows(i)("COIL_DATE") & "'," & dt.Rows(i)("CR_COIL_ID") & "],"

            Next
            js &= "];"
            'js &= "var line2 = ["
            'For i As Integer = 0 To dt.Rows.Count - 1
            '    js &= "['" & dt.Rows(i)("COIL_DATE") & "'," & dt.Rows(i)("CR_COIL_ID") & "],"

            'Next
            'js &= "];"

            js &= "var " & PlotName & " = $.jqplot('" & ContainerName & "', [line1], {"
            js &= "series:[{}],"
            js &= "axesDefaults: {  tickRenderer: $.jqplot.CanvasAxisTickRenderer ,tickOptions: {  angle: 30   }},"
            js &= "seriesColors:['#0B62A4'],"
            js &= "axes: {"
            js &= "xaxis: { renderer: $.jqplot.CategoryAxisRenderer },"
            js &= "x2axis: { renderer: $.jqplot.CategoryAxisRenderer },"
            js &= "yaxis: { autoscale:true,  label:'Count',labelRenderer: $.jqplot.CanvasAxisLabelRenderer },"
            js &= "}});"
            js &= "</script>"
            LiteralName.Text = js

        Catch ex As Exception

        End Try

    End Sub
    Public Sub PlotChartForPLTCMDashboardStack(ByVal dt As DataTable, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String)
        Try
            LiteralName.Text = ""
            'Dim min_time, max_time As String
            'min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-30), "yyyy-MM-dd HH:mm")
            'max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm")
            'Dim yVal() As Decimal
            'yVal = (From row In dt Select col = CDec(row(YAxisColName))).ToArray()
            'Dim y_min As String = yVal.Min()
            'Dim y_max As String = yVal.Max()
            'Dim y_min As String = yVal.Min() - (10 / 100 * yVal.Min)
            'Dim y_max As String = yVal.Max() + (10 / 100 * yVal.Max)
            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                 "$.jqplot.config.enablePlugins = true;" & vbCrLf
            Dim ticks As String = "["
            Dim line1, line2, line3 As String
            line1 &= "["
            line2 &= "["
            line3 &= "["
            For i As Integer = 0 To dt.Rows.Count - 1
                If i > 0 Then
                    ticks &= ","
                    line1 &= ","
                    line2 &= ","
                    line3 &= ","
                End If
                ticks &= "'" & dt.Rows(i)("arrdate") & "'"
                line1 &= dt.Rows(i)("plt1")
                line2 &= dt.Rows(i)("plt2")
                line3 &= dt.Rows(i)("plt3")

            Next
            ticks &= "]"
            line1 &= "]"
            line2 &= "]"
            line3 &= "]"

            js &= "var ticks=" & ticks & ";"
            js &= "var pl1=" & line1 & ";"
            js &= "var pl2=" & line2 & ";"
            js &= "var pl3=" & line3 & ";"

            js &= "var " & PlotName & " = $.jqplot('" & ContainerName & "', [pl1,pl2,pl3], {"
            js &= " stackSeries: true,captureRightClick: true,"
            js &= "seriesDefaults:{renderer:$.jqplot.BarRenderer, rendererOptions: {barMargin: 30,highlightMouseDown: true},pointLabels: {show: true}},"
            js &= "  axesDefaults: { tickRenderer: $.jqplot.CanvasAxisTickRenderer, tickOptions: {  angle: 30,fontSize:   '10pt' } },"
            js &= "seriesColors:['#0B62A4','#7A92A3','#4DA74D'],"
            js &= "axes: {"
            js &= "xaxis: { renderer: $.jqplot.CategoryAxisRenderer,ticks: " & ticks & "  },"
            js &= "yaxis: { padMin: 0,label:'Count',labelRenderer: $.jqplot.CanvasAxisLabelRenderer },"
            js &= "},legend: {show: true, location: 's',labels:['TSCR','HSM','TSK'],renderer: $.jqplot.EnhancedLegendRenderer,placement:  'outside',placement: 'outsideGrid',rendererOptions:{numberColumns:3}}});"
            js &= "</script>"
            LiteralName.Text = js

        Catch ex As Exception

        End Try

    End Sub

    Public Function PopulatePltcmCylinderData(ByVal FromDt As String, ByVal ToDt As String) As DataTable
        Try
            Return objDataHandler.GetDataSetFromQuery("select CPCT_START_TIME,CPCT_CPC3_CYL_DEV_5PNTS as Cylinder3,CPCT_CPC3_STRIP_DEV_5PNTS as Strip3,CPCT_CPC4_CYL_DEV_5PNTS as Cylinder4,CPCT_CPC4_STRIP_DEV_5PNTS as Strip4, " & vbCrLf &
                                                      "CPCT_CPC5_CYL_DEV_5PNTS as Cylinder5,CPCT_CPC5_STRIP_DEV_5PNTS as Strip5,CPCT_CPC6_CYL_DEV_5PNTS as Cylinder6,CPCT_CPC6_STRIP_DEV_5PNTS as Strip6,CPCT_CPC7_CYL_DEV_5PNTS as Cylinder7,CPCT_CPC7_STRIP_DEV_5PNTS as Strip7 from CRM_PLTCM_CPC_TREND where CPCT_START_TIME between '" & Convert.ToDateTime(FromDt).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(ToDt).ToString("yyyy-MM-dd HH:mm:ss") & "' order by CPCT_START_TIME").Tables(0)
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Function
    Sub BoxPlotForPltcmCylinder(ByVal dt As DataTable, ByVal lit As Literal, ByVal containerName As String, ByVal PlotName As String, ByVal ChartTitle As String)
        lit.Text = ""
        Try
            ChartTitle = ""
            Dim ticks As String = "["
            Dim line1, line2 As String
            line1 &= "["
            line2 &= "["

            For i As Integer = 0 To dt.Rows.Count - 1
                If i > 0 Then
                    ticks &= ","
                    line1 &= ","
                    line2 &= ","

                End If
                ticks &= "'" & dt.Rows(i)("CPCT_START_TIME") & "'"
                Dim tmpCyl() As String = dt.Rows(i)("Cylinder6").ToString.Split(",")
                line1 &= "[" & tmpCyl(0) & "," & tmpCyl(4) & "," & tmpCyl(3) & "," & tmpCyl(5) & "," & tmpCyl(1) & "]"

                Dim tmpStrip() As String = dt.Rows(i)("Strip6").ToString.Split(",")
                line2 &= "[" & tmpStrip(0) & "," & tmpStrip(4) & "," & tmpStrip(3) & "," & tmpStrip(5) & "," & tmpStrip(1) & "]"

            Next
            ticks &= "]"
            line1 &= "]"
            line2 &= "]"
            Dim js = "<script language='javascript' type='text/javascript'>"
            js &= "var ticks=" & ticks & ";"
            js &= "var pl1=" & line1 & ";"
            js &= "var pl2=" & line2 & ";"




            js &= "option = { title: {text:'" & ChartTitle & "',left: 'center',},toolbox:{feature:{dataZoom:{}}}, legend: { y: '10%', data: ['Cylinder', 'Strip']}, tooltip: {trigger:    'item',axisPointer: {type:       'shadow'}},grid: {left:       '10%',top:'20%',right:      '10%',bottom: '15%'}, xAxis: {"
            js &= "type:       'category',   data:ticks, boundaryGap: true, nameGap: 30, splitArea: { show: true}, axisLabel: {formatter:  ' {value}'}, splitLine: {show: false}}, yAxis: {type:       'value',name:'Value',splitArea: {show: false}},"
            js &= " dataZoom: [{type:       'inside',start: 0,end: 20},{show: true,height: 20,type:       'slider',top:        '90%',xAxisIndex: [0],start: 0,end: 20}],"
            js &= " series: [{name:       'Cylinder',type:       'boxplot', data: pl1,tooltip: {formatter: formatter}},{name:'Strip',type:       'boxplot', data: pl2,tooltip: {formatter: formatter}}]};"
            js &= "function formatter(param) {return ['upper: ' + param.data[5],'Q3: ' + param.data[4],'median: ' + param.data[3],'Q1: ' + param.data[2],'lower: ' + param.data[1]].join('<br/>')}"
            js &= "var " & PlotName & " = echarts.init(document.getElementById('" & containerName & "'));" & PlotName & ".setOption(option);"
            js &= "</script>"
            lit.Text = js
        Catch ex As Exception

        End Try
    End Sub

    Public Sub LoadColumnNameForCRMDailayManagement1(ByVal DropDownName As DropDownList, ByVal TableName As String, ByVal ColumnName As String, ByVal DateColumnName As String, ByVal FromDt As String, ByVal ToDate As String, ByVal FilterVal As String)
        'Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT distinct " & ColumnName & " FROM " & TableName & " where " & DateColumnName & " between '" & Convert.ToDateTime(FromDt).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(ToDate).ToString("yyyy-MM-dd HH:mm:ss") & "' and " & ColumnName & " <> '' order by " & ColumnName & "").Tables(0)
        Dim query As String = ""
        Dim TextField As String = ""
        If ColumnName = "CLR_PARAM_TEST" Then
            query = "SELECT DISTINCT CLR_PARAM_TEST,DBO.UFN_GET_PARAM_ALIAS_NAME(CLR_PARAM_TEST) AS PARAM_TEST FROM [FP_PROCESS_DATA].[dbo].[CRM_LABTEST_RES]  where CLR_PARAM_TEST IN ('CRWT','SHCR','ALET','ALPT') AND CLR_PROCESS_LINE='L' AND [CLR_DT_SAMPLING_DATE]  between '" & Convert.ToDateTime(FromDt).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(ToDate).ToString("yyyy-MM-dd HH:mm:ss") & "' and CLR_PARAM_TEST <> '' union select 'PRM_DS_ELEC_CUR' as C1,'ECL rectifier Current' as C2 union select 'PRM_TEST_VALUE_FEGA' as C1,'Sheet Fe in GA' as C2 union select 'PRM_SS_STRP_TMP' as C1,'Soaking Temperature' as C2 union select 'PRM_ELONG' as C1,'SPM Elongation' as C2 union select 'PRM_ZINC_POT_TMP' as C1,'Zinc Pot Temperature' as C2"
            TextField = "CLR_PARAM_TEST"
        Else
            query = "SELECT DISTINCT CLR_PARAM_TEST,DBO.UFN_GET_PARAM_ALIAS_NAME(ALIAS) AS PARAM_TEST FROM [FP_PROCESS_DATA].[dbo].[CRM_LABTEST_RES]" & ColumnName & " <>'' and CLR_PARAM_TEST in (" & FilterVal & ") ORDER BY PARAM_TEST"
            TextField = "PARAM_TEST"
        End If
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery(query).Tables(0)
        If dt.Rows.Count > 0 Then
            DropDownName.DataSource = dt
            '--------------
            If TextField = "PARAM_TEST" Then
                Dim dt1 As DataTable = dt.DefaultView.ToTable(True, "PARAM_TEST")
                Dim dt2 As DataTable = dt.Clone

                For row As Integer = 0 To dt1.Rows.Count - 1
                    Dim dv As DataView = dt.DefaultView
                    dv.RowFilter = "PARAM_TEST='" & dt1.Rows(row)(0) & "'"
                    Dim str As String = ""
                    For j As Integer = 0 To dv.Count - 1
                        str &= ",'" & dv.Item(j)(0) & "'"
                    Next
                    dt2.Rows.Add(str.Substring(1), dt1.Rows(row)(0))
                    dv.RowFilter = ""
                Next
                DropDownName.DataSource = dt2
            Else
                DropDownName.DataSource = dt
            End If
            '-------------
            DropDownName.DataTextField = "PARAM_TEST"
            DropDownName.DataValueField = ColumnName
            DropDownName.DataBind()
            DropDownName.Items.Insert(0, "Select")
            DropDownName.SelectedIndex = 0
        End If
    End Sub

    Public Function GetDataForCRMDailyReport(ByVal TableName As String, ByVal DateColumnName As String, ByVal YValue As String, ByVal FromDate As Date, ByVal ToDate As Date, ByVal ylimit1 As String, ByVal ylimit2 As String) As DataTable
        Dim query As String = "Select CLR_DT_SAMPLING_DATE,CLR_ID_COIL,CLR_TEST_VALUE from [FP_PROCESS_DATA].[dbo].[CRM_LABTEST_RES] where CLR_PROCESS_LINE IN('G','L') and CLR_DT_SAMPLING_DATE between '" & Format(FromDate, "yyyy-MM-dd HH:mm:ss") & "' and '" & Format(ToDate, "yyyy-MM-dd HH:mm:ss") & "' and " & YValue & " = '" & ylimit2 & "' order by CLR_DT_SAMPLING_DATE " & vbCrLf
        Return objDataHandler.GetDataSetFromQuery(query).Tables(0)
    End Function
    Public Function GetDataForCRMDailyReportECLTank(ByVal TableName As String, ByVal DateColumnName As String, ByVal YValue As String, ByVal FromDate As Date, ByVal ToDate As Date, ByVal ylimit1 As String, ByVal ylimit2 As String) As DataTable
        Dim query As String = "Select CLR_DT_SAMPLING_DATE,CLR_ID_COIL,CLR_TEST_VALUE from [FP_PROCESS_DATA].[dbo].[CRM_LABTEST_RES] where CLR_PROCESS_LINE IN('G','L') and CLR_DT_SAMPLING_DATE between '" & Format(FromDate, "yyyy-MM-dd HH:mm:ss") & "' and '" & Format(ToDate, "yyyy-MM-dd HH:mm:ss") & "' and " & YValue & " = '" & ylimit2 & "' order by CLR_DT_SAMPLING_DATE " & vbCrLf
        Return objDataHandler.GetDataSetFromQuery(query).Tables(0)
    End Function

    Public Function GetDataForCRMDailyReportChromateTank(ByVal TableName As String, ByVal DateColumnName As String, ByVal YValue As String, ByVal FromDate As Date, ByVal ToDate As Date, ByVal ylimit1 As String, ByVal ylimit2 As String) As DataTable
        Dim query As String = "Select CR.CLR_DT_SAMPLING_DATE,CR.CLR_ID_COIL,CR.CLR_TEST_VALUE from CRM_LABTEST_RES CR INNER JOIN T_CGL_FUR_PARAM TC ON CR.CLR_ID_COIL=TC.PRM_ID_COIL  WHERE CR.CLR_PROCESS_LINE='L' AND TC.PRM_CD_PROD='C10' AND CLR_DT_SAMPLING_DATE between '" & Format(FromDate, "yyyy-MM-dd HH:mm:ss") & "' and '" & Format(ToDate, "yyyy-MM-dd HH:mm:ss") & "' and " & YValue & " = '" & ylimit2 & "' order by CLR_DT_SAMPLING_DATE " & vbCrLf
        Return objDataHandler.GetDataSetFromQuery(query).Tables(0)
    End Function

    Public Function GetDataForCRMDailyReportSheetChromium(ByVal TableName As String, ByVal DateColumnName As String, ByVal YValue As String, ByVal FromDate As Date, ByVal ToDate As Date, ByVal ylimit1 As String, ByVal ylimit2 As String) As DataTable
        Dim query As String = "Select CR.CLR_DT_SAMPLING_DATE,CR.CLR_ID_COIL,TC.PRM_ID_COIL,CR.CLR_TEST_VALUE from CRM_LABTEST_RES CR INNER JOIN T_CGL_FUR_PARAM TC ON TC.PRM_ID_COIL LIKE CONCAT('%',CR.CLR_ID_COIL,'%') AND CR.CLR_ID_COIL=TC.PRM_ID_COIL WHERE CR.CLR_PROCESS_LINE='L' AND TC.PRM_TDC_NO IN('GA14','GAF3','GA04','GA15') AND CR.CLR_DT_SAMPLING_DATE between '" & Format(FromDate, "yyyy-MM-dd HH:mm:ss") & "' and '" & Format(ToDate, "yyyy-MM-dd HH:mm:ss") & "' and " & YValue & " = '" & ylimit2 & "' order by CR.CLR_DT_SAMPLING_DATE " & vbCrLf
        Return objDataHandler.GetDataSetFromQuery(query).Tables(0)
    End Function
    Public Function GetDataForCRMDailyReportInFeGA(ByVal TableName As String, ByVal FromDate As String, ByVal ToDate As String, ByVal DateColumn As String, ByVal ColumnName As String, ByVal Filter As String) As DataTable
        Dim query As String = "select PRM_TS_END,PRM_ID_COIL," & ColumnName & " from " & TableName & " where " & DateColumn & " between '" & FromDate & "' and '" & ToDate & "' and " & Filter & " and " & ColumnName & " is not null"
        Return objDataHandler.GetDataSetFromQuery(query).Tables(0)
    End Function

    Public Sub PlotLineChartForCRMDailyReport(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal YAxisLabelName As String, ByVal usl As Double, ByVal lsl As Double, ByVal avg As Double, ByVal ucl As Double, ByVal lcl As Double)
        Try
            If dt.Rows.Count > 0 Then

                LiteralName.Text = ""
                Dim min_time, max_time As String
                min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-3), "yyyy-MM-dd HH:mm:ss")
                max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(3), "yyyy-MM-dd HH:mm:ss")

                Dim xTimestampVal(), yVal() As String

                xTimestampVal = (From row In dt Select col = row(XAxisColName).ToString).ToArray
                yVal = (From row In dt Select col = row(YAxisColName).ToString).ToArray()

                Dim y_min As String = yVal.Min() - (yVal.Min() * 0.1)

                Dim y_max As String = yVal.Max() + (yVal.Max() * 0.1)

                Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                        "$.jqplot.config.enablePlugins = true;" & vbCrLf
                dt.DefaultView.RowFilter = ""
                Dim flag As Boolean = False
                js &= "var Limit_line  = ["
                Dim standev As Double = 0.0
                'If dt.Rows.Count <> 0 Then
                Dim sum As Integer = 0

                For j As Integer = 0 To dt.Rows.Count - 1

                    sum = sum + dt.Rows(j)(YAxisColName)

                    If j > 0 Then
                        js &= ","
                    End If
                    js &= "["
                    Dim dtTime As DateTime = dt.Rows(j)(XAxisColName)

                    If IsDBNull(dt.Rows(j)(YAxisColName)) = False Then
                        js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm:ss") & "', " & dt.Rows(j)(YAxisColName)
                    Else
                        js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm:ss") & "', " & "null"
                    End If
                    js &= "]"

                Next
                avg = sum / dt.Rows.Count
                For i As Integer = 0 To dt.Rows.Count - 1
                    standev += Math.Pow(dt.Rows(i)(YAxisColName) - avg, 2)
                Next
                standev = Math.Sqrt(standev / dt.Rows.Count)
                lcl = avg - (3 * standev)
                ucl = avg + (3 * standev)
                Dim val1 As Double = 0.0
                Dim val2 As Double = 0.0


                val1 = (ucl - avg) / (3 * standev)
                val2 = (avg - lcl) / (3 * standev)
                Dim Cpk As Double = 0.0
                Cpk = Math.Min(val1, val2)
                'End If

                js &= "];" & vbCrLf
                js &= "var AVG_line=[['" & CDate(dt.Rows(0)(XAxisColName)).ToString("yyyy-MM-dd HH:mm:ss") & "'," & avg & "],['" & CDate(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).ToString("yyyy-MM-dd HH:mm:ss") & "'," & avg & "]];" & vbCrLf
                js &= "var USL_line=[['" & CDate(dt.Rows(0)(XAxisColName)).ToString("yyyy-MM-dd HH:mm:ss") & "'," & usl & "],['" & CDate(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).ToString("yyyy-MM-dd HH:mm:ss") & "'," & usl & "]];" & vbCrLf
                js &= "var LSL_line=[['" & CDate(dt.Rows(0)(XAxisColName)).ToString("yyyy-MM-dd HH:mm:ss") & "'," & lsl & "],['" & CDate(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).ToString("yyyy-MM-dd HH:mm:ss") & "'," & lsl & "]];" & vbCrLf
                js &= "var UCL_line=[['" & CDate(dt.Rows(0)(XAxisColName)).ToString("yyyy-MM-dd HH:mm:ss") & "'," & ucl & "],['" & CDate(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).ToString("yyyy-MM-dd HH:mm:ss") & "'," & ucl & "]];" & vbCrLf
                js &= "var LCL_line=[['" & CDate(dt.Rows(0)(XAxisColName)).ToString("yyyy-MM-dd HH:mm:ss") & "'," & lcl & "],['" & CDate(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).ToString("yyyy-MM-dd HH:mm:ss") & "'," & lcl & "]];" & vbCrLf
                flag = True
                Dim strg As String = ""
                Dim strseries As String = ""
                If flag Then
                    strg = "[Limit_line,AVG_line, USL_line,LSL_line,UCL_line,LCL_line]"
                    strseries = "{showLine:true, lineWidth:1, markerOptions:{ size: 4,show:true}, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}},"
                    strseries &= "{showLine:true,lineWidth:2, markerOptions:{ size: 2}, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}},"
                    strseries &= "{showLine:true, lineWidth:2, markerOptions:{ size: 2}, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}},"
                    strseries &= "{showLine:true, lineWidth:2, markerOptions:{ size: 2}, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}},"
                    strseries &= "{showLine:true, lineWidth:2, markerOptions:{ size: 2}, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:##FF4500; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}},"
                    strseries &= "{showLine:true, lineWidth:2, markerOptions:{ size: 2}, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:##FF4500; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
                    'For i As Integer = 1 To dt.Rows.Count - 1
                    '    strg = strg + ",line" & i + 1
                    '    strseries = strseries + ", { showLine:true, markerOptions:{ size: 7 }}"
                    'Next
                    'strg &= "]"
                End If
                js &= "var seriesName = ['Chart"
                Dim str As String = YAxisLabelName
                str &= "','Average','USL','LSL','UCL','LCL'];"
                js &= str
                js &= "opts = { " & vbCrLf &
                "series:[" & strseries & "]," & vbCrLf &
                "seriesColors: ['#0000FF','#228B22','#ff0000','#ff0000','	#FFFF00','#FFFF00']," & vbCrLf &
                "seriesDefaults:{pointLabels:{show:false}}," & vbCrLf &
                "axesDefaults: {" & vbCrLf &
                "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
                "tickOptions: {" & vbCrLf &
                "fontSize:'8pt'" & vbCrLf &
                "}" & vbCrLf &
                "}," & vbCrLf &
                "axes: {" & vbCrLf &
                "xaxis: {" & vbCrLf &
                "min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf &
                "renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
                "tickOptions:{formatString:'%d-%b %H:%M:%S', angle: -30}," & vbCrLf &
                "//tickInterval:'5 sec'," & vbCrLf &
                "pad:0" & vbCrLf &
                "}," & vbCrLf &
                "yaxis: { " & vbCrLf &
                "tickOptions: { formatString: '%12.0f' }," & vbCrLf &
                "min: " & lsl & "," & vbCrLf &
                "max: " & usl & "," & vbCrLf &
                "autoscale:true," & vbCrLf &
                "label: '" & YAxisLabelName & "'," & vbCrLf &
                "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
                "}" & vbCrLf &
                "}," & vbCrLf &
                "cursor: {" & vbCrLf &
                "zoom: true" & vbCrLf &
                "}," & vbCrLf &
                "//highlighter: { show: 'true', tooltipFormatString: '%.1f', useAxesFormatters: false }," & vbCrLf &
                "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
                "legend: {" & vbCrLf &
                "show: true," & vbCrLf &
                "fontSize: '10pt'," & vbCrLf &
                "location: 's'," & vbCrLf &
                "labels: seriesName," & vbCrLf &
                "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
                "placement: 'outsideGrid'," & vbCrLf &
                "rendererOptions: {" & vbCrLf &
                "numberRows: 1," & vbCrLf &
                "marginTop: 0" & vbCrLf &
                "}" & vbCrLf &
                "}" & vbCrLf &
                "};" & vbCrLf &
                 "" & PlotName & " = $.jqplot('" & ContainerName & "'," & strg & ", opts);" & vbCrLf &
                "</script>" & vbCrLf
                LiteralName.Text = js

            Else
                LiteralName.Text = ""
            End If
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub

    Public Sub PlotLineChartForCRMDailyReportInFeGA(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal YAxisLabelName As String, ByVal usl As Double, ByVal lsl As Double, ByVal avg As Double, ByVal ucl As Double, ByVal lcl As Double)
        Try
            Dim dtTemp As DataTable = dt.Clone
            Dim DecimalVal As String = ""

            For i As Integer = 0 To dt.Rows.Count - 1

                If i < dt.Rows.Count - 1 Then
                    Dim span As TimeSpan = DateTime.Parse(dt.Rows(i + 1)("PRM_TS_END")).Subtract(DateTime.Parse(dt.Rows(i)("PRM_TS_END")))
                    If span.TotalHours >= 24 Then
                        Dim row As DataRow = dtTemp.NewRow
                        For j As Integer = 0 To dt.Columns.Count - 1
                            row(j) = dt.Rows(i)(j)
                        Next
                        dtTemp.Rows.Add(row)
                        row = dtTemp.NewRow
                        row(0) = DateTime.Parse(dt.Rows(i)("PRM_TS_END")).AddMinutes(10)
                        row(1) = "c0"
                        For j As Integer = 2 To dt.Columns.Count - 1
                            row(j) = 0
                        Next
                        dtTemp.Rows.Add(row)
                    Else
                        Dim row As DataRow = dtTemp.NewRow
                        For j As Integer = 0 To dt.Columns.Count - 1
                            row(j) = dt.Rows(i)(j)
                        Next
                        dtTemp.Rows.Add(row)
                    End If
                Else
                    Dim row As DataRow = dtTemp.NewRow
                    For j As Integer = 0 To dt.Columns.Count - 1
                        row(j) = dt.Rows(i)(j)
                    Next
                    dtTemp.Rows.Add(row)
                End If

            Next

            dt = dtTemp
            LiteralName.Text = ""
            Dim min_time, max_time As String
            min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-3), "yyyy-MM-dd HH:mm:ss")
            max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(3), "yyyy-MM-dd HH:mm:ss")

            Dim xTimestampVal() As String
            Dim yVal() As Double

            xTimestampVal = (From row In dt Select col = row(XAxisColName).ToString).ToArray
            yVal = (From row In dt Select col = Convert.ToDouble(row(YAxisColName))).ToArray()

            Dim y_min As String = yVal.Min() - (yVal.Min() * 0.1)

            Dim y_max As String = yVal.Max() + (yVal.Max() * 0.1)
            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf
            dt.DefaultView.RowFilter = ""
            Dim flag As Boolean = False
            js &= "var Limit_line  = ["
            Dim standev As Double = 0.0
            'If dt.Rows.Count <> 0 Then
            Dim sum As Integer = 0

            For j As Integer = 0 To dt.Rows.Count - 1

                sum = sum + dt.Rows(j)(YAxisColName)

                If j > 0 Then
                    js &= ","
                End If
                js &= "["
                Dim dtTime As DateTime = dt.Rows(j)(XAxisColName)

                If IsDBNull(dt.Rows(j)(YAxisColName)) = False Then
                    js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm:ss") & "', " & dt.Rows(j)(YAxisColName)
                Else
                    js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm:ss") & "', " & "null"
                End If
                js &= "]"

            Next
            avg = sum / dt.Rows.Count
            For i As Integer = 0 To dt.Rows.Count - 1
                standev += Math.Pow(dt.Rows(i)(YAxisColName) - avg, 2)
            Next

            standev = Math.Sqrt(standev / dt.Rows.Count)
            lcl = avg - (3 * standev)
            ucl = avg + (3 * standev)
            Dim val1 As Double = 0.0
            Dim val2 As Double = 0.0
            val1 = ((ucl - avg) / (3 * standev))
            val2 = ((avg - lcl) / (3 * standev))
            Dim Cpk As Double = 0.0
            Cpk = Math.Min(val1, val2)
            'End If
            js &= "];" & vbCrLf
            js &= "var AVG_line=[['" & CDate(dt.Rows(0)(XAxisColName)).ToString("yyyy-MM-dd HH:mm:ss") & "'," & avg & "],['" & CDate(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).ToString("yyyy-MM-dd HH:mm:ss") & "'," & avg & "]];" & vbCrLf
            js &= "var USL_line=[['" & CDate(dt.Rows(0)(XAxisColName)).ToString("yyyy-MM-dd HH:mm:ss") & "'," & usl & "],['" & CDate(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).ToString("yyyy-MM-dd HH:mm:ss") & "'," & usl & "]];" & vbCrLf
            js &= "var LSL_line=[['" & CDate(dt.Rows(0)(XAxisColName)).ToString("yyyy-MM-dd HH:mm:ss") & "'," & lsl & "],['" & CDate(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).ToString("yyyy-MM-dd HH:mm:ss") & "'," & lsl & "]];" & vbCrLf
            js &= "var UCL_line=[['" & CDate(dt.Rows(0)(XAxisColName)).ToString("yyyy-MM-dd HH:mm:ss") & "'," & ucl & "],['" & CDate(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).ToString("yyyy-MM-dd HH:mm:ss") & "'," & ucl & "]];" & vbCrLf
            js &= "var LCL_line=[['" & CDate(dt.Rows(0)(XAxisColName)).ToString("yyyy-MM-dd HH:mm:ss") & "'," & lcl & "],['" & CDate(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).ToString("yyyy-MM-dd HH:mm:ss") & "'," & lcl & "]];" & vbCrLf
            flag = True
            Dim strg As String = ""
            Dim strseries As String = ""
            If flag Then
                strg = "[Limit_line,AVG_line, USL_line,LSL_line,UCL_line,LCL_line]"
                strseries = "{showLine:true, lineWidth:1, markerOptions:{ size: 4,show:true}, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}},"
                strseries &= "{showLine:true,lineWidth:2, markerOptions:{ size: 2}, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}},"
                strseries &= "{showLine:true, lineWidth:2, markerOptions:{ size: 2}, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}},"
                strseries &= "{showLine:true, lineWidth:2, markerOptions:{ size: 2}, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}},"
                strseries &= "{showLine:true, lineWidth:2, markerOptions:{ size: 2}, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:##FF4500; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}},"
                strseries &= "{showLine:true, lineWidth:2, markerOptions:{ size: 2}, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:##FF4500; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
                'For i As Integer = 1 To dt.Rows.Count - 1
                '    strg = strg + ",line" & i + 1
                '    strseries = strseries + ", { showLine:true, markerOptions:{ size: 7 }}"
                'Next
                'strg &= "]"
            End If
            js &= "var seriesName = ['Chart"
            Dim str As String = YAxisLabelName
            str &= "','Average','UCL','LCL','USL','LSL'];"
            js &= str
            js &= "opts = {" & vbCrLf &
            "series:[" & strseries & "]," & vbCrLf &
            "seriesColors: ['#0000FF','#228B22','#ff0000','#ff0000','	#FFFF00','#FFFF00']," & vbCrLf &
            "seriesDefaults:{pointLabels:{show:false}}," & vbCrLf &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            "fontSize:'8pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: { " & vbCrLf &
            "renderer: $.jqplot.CategoryAxisRenderer," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer," & vbCrLf &
            "min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf &
            "renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
            "tickOptions:{formatString:'%d-%b %H:%M:%S', angle: -30}," & vbCrLf &
            "//tickInterval:'5 sec'," & vbCrLf &
            "pad:0" & vbCrLf &
            "}," & vbCrLf &
            "yaxis: { " & vbCrLf &
            "tickOptions: { formatString: '%12.0f' }," & vbCrLf &
            "min: " & lsl & "," & vbCrLf &
            "max: " & usl & "," & vbCrLf &
            "autoscale:true," & vbCrLf &
            "label: '" & YAxisLabelName & "'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "//highlighter: { show: 'true', tooltipFormatString: '%.1f', useAxesFormatters: false }," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
            "legend: {" & vbCrLf &
            "show: true," & vbCrLf &
            "fontSize: '10pt'," & vbCrLf &
            "location: 's'," & vbCrLf &
            "labels: seriesName," & vbCrLf &
            "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
            "placement: 'outsideGrid'," & vbCrLf &
            "rendererOptions: {" & vbCrLf &
            "numberRows: 1," & vbCrLf &
            "marginTop: 0" & vbCrLf &
            "}" & vbCrLf &
            "}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "'," & strg & ", opts);" & vbCrLf &
            "</script>" & vbCrLf
            LiteralName.Text = js
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub


    Public Sub PopulateGradeForCRMDailyReport(ByVal GradeDropDown As DropDownList, ByVal FromDate As String, ByVal ToDate As String)
        Try
            GradeDropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT DISTINCT TC.PRM_CD_GRADE FROM  CRM_LABTEST_RES CR INNER JOIN T_CGL_FUR_PARAM TC ON CR.CLR_ID_COIL=TC.PRM_ID_COIL  WHERE  CR.CLR_PROCESS_LINE='L' AND TC.PRM_TS_END between  '" & FromDate & "' AND '" & ToDate & "' AND TC.PRM_CD_GRADE <> '0' AND TC.PRM_CD_GRADE IS NOT NULL ORDER BY TC.PRM_CD_GRADE").Tables(0)
            GradeDropDown.DataTextField = "PRM_CD_GRADE"
            GradeDropDown.DataValueField = "PRM_CD_GRADE"
            GradeDropDown.DataBind()
            GradeDropDown.Items.Insert(0, "All")
            GradeDropDown.SelectedIndex = 0
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try


    End Sub
    Public Sub PopulateTdcForCRMDailyReport(ByVal TdcDropDown As DropDownList, ByVal FromDate As String, ByVal ToDate As String, ByVal Grade As String)
        Try
            If Grade.ToLower = "all" Then
                TdcDropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT DISTINCT TC.PRM_TDC_NO FROM  CRM_LABTEST_RES CR INNER JOIN T_CGL_FUR_PARAM TC ON CR.CLR_ID_COIL=TC.PRM_ID_COIL  WHERE CR.CLR_PROCESS_LINE='L' AND TC.PRM_TS_END between '" & FromDate & "' and '" & ToDate & "' ORDER BY TC.PRM_TDC_NO").Tables(0)
            Else
                TdcDropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT DISTINCT TC.PRM_TDC_NO FROM  CRM_LABTEST_RES CR INNER JOIN T_CGL_FUR_PARAM TC ON CR.CLR_ID_COIL=TC.PRM_ID_COIL  WHERE CR.CLR_PROCESS_LINE='L' AND TC.PRM_TS_END between '" & FromDate & "' and '" & ToDate & "' and TC.PRM_CD_GRADE = '" & Grade & "' ORDER BY PRM_TDC_NO").Tables(0)

            End If

            TdcDropDown.DataTextField = "PRM_TDC_NO"
            TdcDropDown.DataValueField = "PRM_TDC_NO"
            TdcDropDown.DataBind()
            TdcDropDown.Items.Insert(0, "All")
            TdcDropDown.SelectedIndex = 0
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub

    'Public Sub PopulateRoughForCRMDailyReport(ByVal RoughDropDown As DropDownList, ByVal FromDate As String, ByVal ToDate As String, ByVal Grade As String, ByVal TDC As String)
    '    Try
    '        Dim filter As String = ""
    '        If Grade.ToLower <> "all" Then
    '            filter &= " and PRM_CD_GRADE = '" & Grade & "'"
    '        End If
    '        If TDC.ToLower <> "all" Then
    '            filter &= "  and PRM_TDC_NO = '" & TDC & "'"
    '        End If
    '        RoughDropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT DISTINCT TC.PRM_CD_SURF_ROUGH,case when TC.PRM_CD_SURF_ROUGH = 'A' then 'GA' else 'GI' end as NAME FROM  CRM_LABTEST_RES CR INNER JOIN T_CGL_FUR_PARAM TC ON CR.CLR_ID_COIL=TC.PRM_ID_COIL WHERE CR.CLR_PROCESS_LINE='L' AND TC.PRM_TS_END between '" & FromDate & "' and '" & ToDate & "' " & filter & " ORDER BY TC.PRM_CD_SURF_ROUGH").Tables(0)
    '        RoughDropDown.DataTextField = "NAME"
    '        RoughDropDown.DataValueField = "PRM_CD_SURF_ROUGH"
    '        RoughDropDown.DataBind()
    '        RoughDropDown.Items.Insert(0, "All")
    '        RoughDropDown.SelectedIndex = 0
    '    Catch ex As Exception
    '        Throw New Exception(ex.ToString())
    '    End Try
    'End Sub

    Public Sub PopulateThicknessForCRMDailyReport(ByVal ThicknessDropDown As DropDownList, ByVal FromDate As String, ByVal ToDate As String, ByVal Grade As String, ByVal TDC As String)
        Try
            Dim filter As String = ""
            If Grade.ToLower <> "all" Then
                filter &= " and PRM_CD_GRADE = '" & Grade & "'"
            End If
            If TDC.ToLower <> "all" Then
                filter &= "  and PRM_TDC_NO = '" & TDC & "'"
            End If
            'If Rough.ToLower <> "all" Then
            '    filter &= "  and PRM_CD_SURF_ROUGH = '" & Rough & "'"
            'End If
            ThicknessDropDown.DataSource = objDataHandler.GetDataSetFromQuery("SELECT DISTINCT TC.PRM_SEC1_COIL FROM  CRM_LABTEST_RES CR INNER JOIN T_CGL_FUR_PARAM TC ON CR.CLR_ID_COIL=TC.PRM_ID_COIL  WHERE CR.CLR_PROCESS_LINE='L' AND PRM_TS_END between '" & FromDate & "' and '" & ToDate & "'" & filter & " ORDER BY TC.PRM_SEC1_COIL").Tables(0)
            ThicknessDropDown.DataTextField = "PRM_SEC1_COIL"
            ThicknessDropDown.DataValueField = "PRM_SEC1_COIL"
            ThicknessDropDown.DataBind()
            ThicknessDropDown.Items.Insert(0, "All")
            ThicknessDropDown.SelectedIndex = 0
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub
    'Public Function GetCgl2MainTBMData(ByVal Filter As String) As DataTable
    '    Dim Query As String = "select CCT_SL_NO,CCT_LIFE,CCT_RESET_ON,CCT_EQUIPMENT_NAME,dateadd(month,CCT_LIFE,CCT_RESET_ON) as DueDate from CRM_CGL2_TBM " & Filter & ""
    '    Return objDataHandler.GetDataSetFromQuery(Query).Tables(0)
    'End Function
    Public Function GetCgl2MainTBMData() As DataTable
        Dim Query As String = "select CCT_SL_NO,CCT_LIFE,CCT_RESET_ON,CCT_EQUIPMENT_NAME,dateadd(month,CCT_LIFE,CCT_RESET_ON) as DueDate from CRM_CGL2_TBM "
        Return objDataHandler.GetDataSetFromQuery(Query).Tables(0)
    End Function
    Public Sub LoadEquipmentName(ByVal DropDownName As DropDownList)
        Dim query As String = ""
        query = "select distinct CCT_SL_NO,CCT_EQUIPMENT_NAME from CRM_CGL2_TBM"
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery(query).Tables(0)
        If dt.Rows.Count > 0 Then
            DropDownName.DataSource = dt
            DropDownName.DataTextField = "CCT_EQUIPMENT_NAME"
            DropDownName.DataValueField = "CCT_SL_NO"
            DropDownName.DataBind()
            DropDownName.Items.Add("Other")
            DropDownName.Items.Insert(0, "Select")
            'DropDownName.Items.Insert(DropDownName.Items.Count, "Other")
            'DropDownName.SelectedIndex = 0
        Else
            DropDownName.Items.Insert(0, "Select")
            DropDownName.Items.Add("Other")
        End If

    End Sub
    Enum FormAction
        Insert
        Update
    End Enum
    Public Function SaveEquipmentDetails(ByVal EquipmentName As String, ByVal Life As String, ByVal Reseton As String, ByVal Resetby As String, ByVal Action As FormAction, Optional ByVal SlNo As Integer = -1) As Integer
        Dim query = ""
        If Action = FormAction.Insert Then

            ','" & Now.ToString("dd-MMM-yy hh:mm:ss tt") & "'
            query &= "insert into CRM_CGL2_TBM (CCT_EQUIPMENT_NAME,CCT_LIFE,CCT_RESET_ON,CCT_RESET_BY) values('" & EquipmentName & "','" & Life & "','" & Reseton & "','" & Resetby & "'); " & vbCrLf

        Else
            query = "update CRM_CGL2_TBM set CCT_EQUIPMENT_NAME = '" & EquipmentName & "', CCT_LIFE ='" & Life & "',CCT_RESET_ON= '" & Reseton & "',CCT_RESET_BY = '" & Resetby & "' where CCT_SL_NO = " & SlNo & ""
        End If
        Return objDataHandler.RunSimpleQuery(query)
    End Function
    Public Function UpdateResetDate(ByVal slno As Integer) As Integer
        Dim query = ""
        'query = "update CRM_CGL2_TBM set CCT_RESET_ON = CONVERT (date, GETDATE()) where CCT_SL_NO = " & slno & ""
        query = "update CRM_CGL2_TBM set CCT_RESET_ON = GETDATE() where CCT_SL_NO = " & slno & ""
        Return objDataHandler.RunSimpleQuery(query)
    End Function
    Public Function SaveEquipmentResetDetails(ByVal SlNo As Integer, ByVal Life As String, ByVal Reseton As String) As Integer
        Dim query = ""
        ','" & Now.ToString("dd-MMM-yy hh:mm:ss tt") & "'
        query &= "insert into CRM_CGL2_TBM_RESET (CCTR_SL_NO,CCTR_PREV_LIFE,CCTR_PREV_RESET_DATE) values(" & SlNo & ", DATEDIFF(month, '" & Reseton & "' , GETDATE()),'" & Reseton & "'); " & vbCrLf
        Return objDataHandler.RunSimpleQuery(query)
    End Function
    Public Function GetDataForInspection(ByVal FromDate As String, ByVal ToDate As String) As DataTable
        Dim query As String = ""
        'query = "select substring([date create],1,9) as dateCreate,sum([defect length]) as defect, count([Daughter Coil]) as coil,sum([defect length])/count([Daughter Coil]) as TotalDefect  from CAPL_INSP where [date create] between '" & FromDate & "' and '" & ToDate & "' group by substring([date create],1,9) order by cast(substring([date create],1,9) as date)"
        'query = "select cast(date_create as date) as dateCreate,surface,sum(defect_length) as defect, count(Daughter_Coil) as coil,cast(cast(sum(defect_length) as numeric(8,3))/cast(count(Daughter_Coil) as numeric(8,3)) as numeric(8,3)) as TotalDefect  from CAPL_INSP_NEW where date_create between '" & FromDate & "' and '" & CDate(ToDate).AddDays(1).ToString("yyyy-MM-dd") & "' and (Surface = 'B' or surface='T')  group by cast(date_create as date),surface order by cast(date_create as date)"
        query = "select cast(date_create as date) as dateCreate,surface,sum(defect_length) as defect, count(Daughter_Coil) as coil,cast(cast(sum(defect_length) as numeric(8,3))/cast(count(Daughter_Coil) as numeric(8,3)) as numeric(8,3)) as TotalDefect  from CAPL_INSP_NEW where date_create between '" & FromDate & "' and '" & ToDate & "' and (Surface = 'B' or surface='T')  group by cast(date_create as date),surface order by cast(date_create as date)"
        Return objDataHandler.GetDataSetFromQuery(query).Tables(0)
    End Function

    Public Sub PlotLineChartForInspection(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String, ByVal index As String)
        Try

            LiteralName.Text = ""
            Dim min_time, max_time As String
            min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-30), "yyyy-MM-dd HH:mm")
            max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm")

            'Dim xTimestampVal(), yVal() As String
            Dim yVal() As Decimal

            'xTimestampVal = (From row In dt Select col = row(XAxisColName).ToString).ToArray
            yVal = (From row In dt Select col = CDec(IIf(IsDBNull(row(YAxisColName)), 0, row(YAxisColName))) Where col > 0).ToArray()

            'Dim y_min As String = yVal.Min()
            'Dim y_max As String = yVal.Max()
            Dim y_min As String = yVal.Min() - (10 / 100 * yVal.Min)
            Dim y_max As String = yVal.Max() + (10 / 100 * yVal.Max)

            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf
            js &= "var line" & index & " = ["
            For j As Integer = 0 To dt.Rows.Count - 1
                If j > 0 Then
                    'js &= ","
                End If

                Dim dtTime As DateTime = dt.Rows(j)(XAxisColName)

                If IsDBNull(dt.Rows(j)(YAxisColName)) = False Then
                    js &= "['" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dt.Rows(j)(YAxisColName) & "],"

                End If

            Next

            js &= "];" & vbCrLf
            'Dim strg As String = ""
            'Dim strseries As String = ""
            'If flag Then
            '    strg = "[line1"
            '    strseries = " {showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"

            '    strg &= "]"
            'End If
            'js &= "var seriesName = ['"
            'Dim str As String = ""
            'For i As Integer = 0 To dtGroups.Rows.Count - 1
            '    str &= dtGroups.Rows(i)(0).ToString().Trim() + "', '"
            'Next
            'str = str.Remove(str.LastIndexOf(", '"))
            'str &= "];"
            'js &= str
            js &= "opts = {" & vbCrLf &
            "title: '" & ChartTitle & "'," & vbCrLf &
            "seriesDefaults: { showMarker:true,lineWidth: 2,markerOptions: {size: 5}, pointLabels: { show:false },color: '#4832DB', highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}," &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            "fontSize:'8pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "//min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf &
            "renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
            "tickOptions:{formatString:'%d-%b', angle: -30}," & vbCrLf &
            "tickInterval:'1 day'," & vbCrLf &
            "pad:0" & vbCrLf &
            "}," & vbCrLf &
            "yaxis: { " & vbCrLf &
            "tickOptions: { formatString: '%8.3f' }," & vbCrLf &
            "min: " & y_min & "," & vbCrLf &
            "max: " & y_max & "," & vbCrLf &
            "autoscale:true," & vbCrLf &
            "label: '" & YAxisLabelName & "'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "showTooltip: false," & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "animate: true," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)'}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "',[line" & index & "],opts);" & vbCrLf &
            "</script>" & vbCrLf

            LiteralName.Text = js
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub
    Public Sub PlotLineChartForInsp(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String, ByVal GroupByColName As String)
        Try
            'For i As Integer = 0 To dt.Rows.Count - 1
            '    If IsDBNull(dt.Rows(i)("LTRI_PARA_MIN")) Then
            '        dt.Rows(i)("LTRI_PARA_MIN") = dt.Rows(i)("LTRI_PARA_MIN").ToString().Replace(vbNull, vbDecimal)
            '    End If
            'Next
            LiteralName.Text = ""
            Dim min_time, max_time As String
            min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-0), "yyyy-MM-dd HH:mm")
            max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm")

            'Dim xTimestampVal(), yVal() As String
            Dim yVal() As Decimal

            'xTimestampVal = (From row In dt Select col = row(XAxisColName).ToString).ToArray
            yVal = (From row In dt Select col = CDec(row(YAxisColName))).ToArray()

            'Dim y_min As String = yVal.Min()
            'Dim y_max As String = yVal.Max()
            Dim y_min As String = yVal.Min() - (10 / 100 * yVal.Min)
            Dim y_max As String = yVal.Max() + (10 / 100 * yVal.Max)

            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf
            dt.DefaultView.RowFilter = ""
            Dim dtGrades As DataTable = dt.DefaultView.ToTable(True, GroupByColName) 'All distinct Grades
            Dim dvDefault As DataView = dt.DefaultView
            Dim flag As Boolean = False
            For i As Integer = 0 To dtGrades.Rows.Count - 1
                js &= "var line" & (i + 1).ToString & " = ["
                dvDefault.RowFilter = "" & GroupByColName & "='" & dtGrades.Rows(i)(0) & "'"
                For j As Integer = 0 To dvDefault.Count - 1
                    If j > 0 Then
                        js &= ","
                    End If
                    js &= "["
                    Dim dtTime As DateTime = dvDefault.Item(j)("dateCreate")
                    If IsDBNull(dvDefault.Item(j)(GroupByColName)) Then
                        If IsDBNull(dvDefault.Item(j)("TotalDefect")) = False Then
                            js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)("TotalDefect") & ", " & "null"
                        Else
                            js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & "null, null"
                        End If
                    Else
                        If IsDBNull(dvDefault.Item(j)("TotalDefect")) = False Then
                            js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)("TotalDefect") & ", '(" & dvDefault.Item(j)(GroupByColName).ToString().Trim & ")'"
                            'js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)("CLR_TEST_VALUE") & ", 'Pot'"
                        End If
                    End If
                    js &= "]"
                Next
                js &= "];" & vbCrLf
                flag = True
            Next

            Dim strg As String = ""
            Dim strseries As String = ""
            If flag Then
                strg = "[line1"
                strseries = " {pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
                For i As Integer = 1 To dtGrades.Rows.Count - 1
                    strg = strg + ",line" & i + 1
                    strseries = strseries + ", {pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
                Next
                strg &= "]"
            End If
            js &= "var seriesName = ['"
            Dim str As String = ""
            For i As Integer = 0 To dtGrades.Rows.Count - 1
                str &= dtGrades.Rows(i)(0).ToString().Trim() + "', '"
            Next
            str = str.Remove(str.LastIndexOf(", '"))
            str &= "];"
            js &= str
            js &= "opts = {" & vbCrLf &
            "title: '" & ChartTitle & "'," & vbCrLf &
            "series:[" & strseries & "]," & vbCrLf &
            "//seriesColors: ['#FFA500']," & vbCrLf &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            "fontSize:'8pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf &
            "renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
            "tickOptions:{formatString:'%d-%b', angle: -30}," & vbCrLf &
            "tickInterval:'24 hour'," & vbCrLf &
            "pad:0" & vbCrLf &
            "}," & vbCrLf &
            "yaxis: { " & vbCrLf &
            "tickOptions: { formatString: '%.3f' }," & vbCrLf &
            "min: " & y_min & "," & vbCrLf &
            "max: " & y_max & "," & vbCrLf &
            "autoscale:true," & vbCrLf &
            "label: '" & YAxisLabelName & "'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "showTooltip: false," & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "animate: true," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
            "legend: {" & vbCrLf &
            "show: true," & vbCrLf &
            "location: 's'," & vbCrLf &
            "labels: seriesName," & vbCrLf &
            "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
            "placement: 'outsideGrid'," & vbCrLf &
            "rendererOptions: {" & vbCrLf &
            "numberRows: 1," & vbCrLf &
            "marginTop: 10" & vbCrLf &
            "}" & vbCrLf &
            "}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "', " & strg & ", opts);" & vbCrLf &
            "</script>" & vbCrLf

            LiteralName.Text = js
        Catch ex As Exception

        End Try
    End Sub
    Public Function GetDataForInspectionByLength(ByVal FromDate As String, ByVal ToDate As String, ByVal DefectName As String, ByVal Surface As String) As DataTable
        Dim query As String = ""
        query = "  select distinct date_create as dateCreate,Daughter_Coil,surface,Length_Coil,Defect_St_Length,Defect_End_Length,cast((cast(Defect_St_Length as numeric(8,4)) * 100/Length_Coil) as numeric(8,4)) as DefectStart,cast((cast(Defect_End_Length as numeric(8,4)) * 100/Length_Coil) as numeric(8,4)) as DefectEnd,severity from CAPL_INSP_NEW where date_create between '" & FromDate & "' and '" & ToDate & "' and Defect_Name = '" & DefectName & "' and  Surface = '" & Surface & "' order by date_create desc"
        Return objDataHandler.GetDataSetFromQuery(query).Tables(0)
    End Function
    Sub DrawHeatChartForInsDefByLen(ByVal dt As DataTable, ByVal LiteralName As Literal, ByVal ContainerName As String, Optional ByVal title As String = "", Optional ByVal indx As Integer = 0)
        Try

            Dim s As New StringBuilder("<script>")
            Dim dtDist As DataTable = dt.DefaultView.ToTable(True, "dateCreate")
            s.Append("var hours" & indx & " = ['0-5', '5-10', '10-15', '15-20', '20-25', '25-30', '30-35','35-40','40-45','45-50', '50-55', '55-60', '60-65', '65-70', '70-75', '75-80','80-85','85-90','90-95','95-100'];")
            s.Append("var days" & indx & " = [")
            For i As Integer = 0 To dtDist.Rows.Count - 1
                If i > 0 Then
                    s.Append(",")
                End If
                s.Append("'" & CDate(dtDist.Rows(i)("dateCreate")).ToString("dd:MM:yy HH:mm") & "'")
            Next
            s.Append("];")
            s.Append("var data" & indx & "1 = [")
            Dim dv As DataView = dt.DefaultView
            For row As Integer = 0 To dtDist.Rows.Count - 1
                If row > 0 Then
                    s.Append(",")
                End If
                dv.RowFilter = "dateCreate='" & dtDist.Rows(row)(0) & "'"
                For k As Integer = 0 To 19
                    If k > 0 Then
                        s.Append(",")
                    End If
                    Dim val As Integer = 6
                    Dim minval As Integer = k * 5
                    Dim maxval As Integer = minval + 5
                    For l As Integer = 0 To dv.Count - 1
                        ' If (dv(l)(6) >= minval And dv.Item(l)(6) <= maxval) Then
                        If (dv(l)(6) <= minval And dv.Item(l)(7) >= minval) OrElse (dv(l)(6) <= maxval And dv.Item(l)(7) >= maxval) Then
                            val = dv.Item(l)("severity")
                        End If
                    Next
                    s.Append("[" & (row) & "," & (k) & "," & val & ",'" & dv.Item(0)(1) & "']")
                Next

                dv.RowFilter = ""
            Next


            s.Append("];")
            s.Append("data" & indx & " = data" & indx & "1.map(function (item) {return [item[1], item[0], item[2] || '-'];});")
            s.Append("option = {title: {text:       '" & title & "',left:       'center'},toolbox: {feature: {dataZoom: { }}},tooltip: {show:true,position:   'top', formatter: function (params) {var s = params.data[2];if (s==6){s=0;} var i = params.data[1]*20 + params.data[0]; return 'Coil ID: ' + data" & indx & "1[i][3] + '<br/>' + 'Severity: ' + s;}},animation: false,grid: {height:'80%',x:'15%',y:'10%'},xAxis: {type:'category',data: hours" & indx & ",splitArea: {show: true}, name: 'Length in percentage',nameLocation: 'center', nameGap: 20},yAxis: {type:'category',data: days" & indx & ",splitArea: {show: true}},visualMap: {show:false, min: 1, max: 6,range:[1,5],calculable: true,orient:'horizontal',left:'center',bottom:'15%',outOfRange: {color:'#70A03D'}}, series: [{name:'Defect Inspection',type:'heatmap',data: data" & indx & ",label: {normal: {show: false}},itemStyle: {emphasis: {shadowBlur: 10,shadowColor:'rgba(0, 0, 0, 0.5)'}}}]};")
            s.Append("var myChart" & indx & " = echarts.init(document.getElementById('" & ContainerName & "'));")
            s.Append("myChart" & indx & ".setOption(option);")
            s.Append("window.onresize = function() { myChart" & indx & ".resize();};")
            s.Append("</script>")
            'Lit1.Text = s.ToString()
            LiteralName.Text = s.ToString()
            'lblmsg.Text = "Show temperature data of last 1 month"


        Catch ex As Exception
            'lblerror.Text = ex.ToString
            'Lit1.Text = " "
            LiteralName.Text = ""
        End Try
    End Sub
    Public Function GetDataForInspectionByWidth(ByVal FromDate As String, ByVal ToDate As String, ByVal DefectName As String, ByVal Surface As String, Optional ByVal Severity As String = "1,2,3,4,5", Optional ByVal grade As String = "", Optional ByVal tdcno As String = "") As DataTable
        Dim query As String = ""
        'query = "  select distinct date_create as dateCreate,Daughter_Coil,surface,Defect_St_Width,Defect_End_Width,severity from RCL_INSP_NEW where date_create between '" & FromDate & "' and '" & ToDate & "' and Defect_Name in (" & DefectName & ") and  Surface = '" & Surface & "' and severity in (" & Severity & ") order by date_create desc"
        query = "  select t.*,t1.severity from (select distinct date_create as dateCreate,Daughter_Coil,surface,Defect_St_Width,Defect_End_Width from RCL_INSP_NEW where date_create between '" & FromDate & "' and '" & ToDate & "' and Defect_Name in (" & DefectName & ") and  Surface = '" & Surface & "' and severity in (" & Severity & ") and grade in (" & grade & ") and tdc_no in (" & tdcno & ")) T left outer join (SELECT [Daughter_Coil],Sum([Defect_Length]) as Severity,Defect_St_Width,Defect_End_Width FROM rcl_insp_new  where date_create between '" & FromDate & "' and '" & ToDate & "' and Defect_Name in (" & DefectName & ") and  Surface = '" & Surface & "' and severity in (" & Severity & ")  and grade in (" & grade & ") and tdc_no in (" & tdcno & ") Group by [Daughter_Coil], Defect_St_Width,Defect_End_Width) T1 on T.Daughter_coil=T1.Daughter_coil and T.Defect_St_Width=t1.Defect_St_Width and t.Defect_End_Width=t1.Defect_End_Width order by t.datecreate desc"
        Return objDataHandler.GetDataSetFromQuery(query).Tables(0)
    End Function
    Sub DrawHeatChartForInsDefByWidth(ByVal dt As DataTable, ByVal LiteralName As Literal, ByVal ContainerName As String, Optional ByVal title As String = "", Optional ByVal indx As Integer = 0, Optional defectName As String = "", Optional grade As String = "", Optional tdcno As String = "")
        Try

            Dim s As New StringBuilder("<script>")
            Dim maxperc As Integer = dt.Compute("max(severity)", "")
            Dim dtDist As DataTable = dt.DefaultView.ToTable(True, "dateCreate")
            s.Append("var hours" & indx & " = ['OS', 'OSC', 'C', 'DSC', 'DS'];")
            s.Append("var days" & indx & " = [")
            For i As Integer = 0 To dtDist.Rows.Count - 1
                If i > 0 Then
                    s.Append(",")
                End If
                s.Append("'" & CDate(dtDist.Rows(i)("dateCreate")).ToString("dd:MM:yy HH:mm") & "'")
            Next
            s.Append("];")
            s.Append("var data" & indx & "1 = [")
            Dim dv As DataView = dt.DefaultView
            For row As Integer = 0 To dtDist.Rows.Count - 1
                If row > 0 Then
                    s.Append(",")
                End If
                dv.RowFilter = "dateCreate='" & dtDist.Rows(row)(0) & "'"
                For k As Integer = 0 To 4
                    If k > 0 Then
                        s.Append(",")
                    End If
                    Dim val As Integer = 6
                    'Dim minval As Integer = k * 5
                    'Dim maxval As Integer = minval + 5
                    Dim minval As Integer = k * 1 + 1
                    Dim maxval As Integer = minval + 1
                    For l As Integer = 0 To dv.Count - 1
                        ' If (dv(l)(6) >= minval And dv.Item(l)(6) <= maxval) Then
                        If (dv(l)(3) <= minval And dv.Item(l)(4) >= minval) Then
                            Dim temp As Integer = dv.Item(l)("severity")
                            Dim perc As Double = temp * 100 / maxperc
                            If perc > 75 Then
                                val = 3
                            ElseIf perc > 50 And perc <= 75 Then
                                val = 2
                            Else
                                val = 1
                            End If
                            'val = dv.Item(l)("severity")
                        End If
                    Next
                    s.Append("[" & (row) & "," & (k) & "," & val & ",'" & dv.Item(0)(1) & "']")
                Next

                dv.RowFilter = ""
            Next

            s.Append("];")
            s.Append("data" & indx & " = data" & indx & "1.map(function (item) {return [item[1], item[0], item[2] || '-'];});")
            s.Append("option = {title: {text:       '" & title & "',left:       'center'},toolbox: {feature: {dataZoom: { }}},tooltip: {show:true,position:   'top', formatter: function (params) {var s = params.data[2];var def='';if (s==6){def='No defect';} else if (s==1){def='0-50%'} else if (s==2){def='50-75%'} else {def='>75%'} var i = params.data[1]*5 + params.data[0]; return 'Coil ID: ' + data" & indx & "1[i][3] + '<br/>' + 'Defect Length Sum Range: ' + def;}},animation: false,grid: {height:'80%',x:'15%',y:'10%'},xAxis: {type:'category',data: hours" & indx & ",splitArea: {show: true}, name: 'Width',nameLocation: 'center', nameGap: 20},yAxis: {type:'category',data: days" & indx & ",splitArea: {show: true}},visualMap: {show:false, min: 1, max: 4,range:[1,3],inRange:{color:['#ffff00','#ffa500','#ff0000']},calculable: true,orient:'horizontal',left:'center',bottom:'15%',outOfRange: {color:'#70A03D'}}, series: [{name:'Defect Inspection',type:'heatmap',data: data" & indx & ",label: {normal: {show: false}},itemStyle: {emphasis: {shadowBlur: 10,shadowColor:'rgba(0, 0, 0, 0.5)'}}}]};")
            s.Append("var myChart" & indx & " = echarts.init(document.getElementById('" & ContainerName & "'));")
            s.Append("myChart" & indx & ".setOption(option);myChart" & indx & ".on('click',function(params){var i = params.data[1]*5 + params.data[0];var coilid=data" & indx & "1[i][3];window.open('Inspection_ByWidth_sub_chart.aspx?subparam=' + escape(coilid), '_blank', 'toolbar=no,location=no,directories=no,status=no,scrollbars=yes,resizable=no,top=100,left=200,width=800,height=400')});")
            s.Append("window.onresize = function() { myChart" & indx & ".resize();};")
            s.Append("</script>")
            'Lit1.Text = s.ToString()
            LiteralName.Text = s.ToString()
            'lblmsg.Text = "Show temperature data of last 1 month"


        Catch ex As Exception
            'lblerror.Text = ex.ToString
            'Lit1.Text = " "
            LiteralName.Text = ""
        End Try
    End Sub
    'Public Function GetLimit(ByVal TdcNo As String, ByVal Thickness As Double, ByVal Width As Double) As DataTable
    '    Dim query As String = ""
    '    query = "select Avg - (Avg*Percent_limit/100) as min, Avg + (Avg * Percent_limit/100) as max,Avg * 102.0408 as Avg  from CRM_SPM_Cutoff where TDC = '" & TdcNo & "' and " & Thickness & " > Thickness_min and " & Thickness & " <= Thickness_max and " & Width * 1000 & " > Width_min and " & Width * 1000 & " <= Width_max"
    '    Return objDataHandler.GetDataSetFromQuery(query).Tables(0)
    'End Function
    Public Function GetLimitForCRMDaily(ByVal ParamName As String) As DataTable
        Dim query As String = ""
        query = "select * from CRM_Daily_Management where Parameter = '" & ParamName & "'"
        Return objDataHandler.GetDataSetFromQuery(query).Tables(0)
    End Function
    Public Function UpdateLimitForDaily(ByVal min As Double, ByVal max As Double, ByVal param As String) As Integer
        Dim query As String = ""
        query = "update CRM_Daily_Management set LSL = " & min & ",USL = " & max & ",Updated_On = getdate() where Parameter = '" & param & "'"
        Return objDataHandler.RunSimpleQuery(query)

    End Function
End Class
