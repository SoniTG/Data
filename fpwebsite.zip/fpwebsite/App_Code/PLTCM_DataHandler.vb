﻿
Imports Microsoft.VisualBasic
Imports System.Data
Imports System.Data.SqlClient
Imports System.Data.OleDb
' Imports Oracle.ManagedDataAccess.Client
Public Class PLTCM_DataHandler
    Dim connectionString As String = ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString
    Dim con As New SqlConnection(connectionString)

    Dim CRM_EUIP_CONNECTION As String = ConfigurationManager.ConnectionStrings("CRM_EUIP").ConnectionString
    Dim CONN_CRM_EUIP As New SqlConnection(CRM_EUIP_CONNECTION)
    Private Sub CloseConnection()
        Try
            If con.State <> ConnectionState.Closed Then
                con.Close()
            End If
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

    End Sub
    Private Sub CloseConnectionCRM_EUIP()
        Try
            If CONN_CRM_EUIP.State <> ConnectionState.Closed Then
                CONN_CRM_EUIP.Close()
            End If
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

    End Sub
    Public Function RunStoredProc(ByVal name As String, ByVal pName() As String, ByVal pVal() As String) As DataSet
        Dim ds As New DataSet
        Try
            Dim cmd As New SqlCommand()
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = con
            cmd.CommandText = name
            cmd.Parameters.Clear()
            For i As Integer = 0 To UBound(pName)
                cmd.Parameters.Add(New SqlParameter(pName(i), pVal(i)))
            Next

            Dim da As New SqlDataAdapter(cmd)
            da.Fill(ds)

        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

        Return ds
    End Function
    Public Function GetDataSetFromQuery_CRM_EUIP(ByVal SelectQuery As String) As DataSet
        Dim ds As New DataSet
        Try
            Dim da As New SqlDataAdapter(SelectQuery, CONN_CRM_EUIP)
            da.SelectCommand.CommandTimeout = 10000
            da.Fill(ds)
        Catch ex As Exception
            CloseConnection()
            Throw New Exception(ex.ToString())
        End Try
        Return ds
    End Function
    Public Function GetDataSetFromQuery(ByVal SelectQuery As String) As DataSet
        Dim ds As New DataSet
        Try
            Dim da As New SqlDataAdapter(SelectQuery, con)
            da.SelectCommand.CommandTimeout = 10000
            da.Fill(ds)
        Catch ex As Exception
            CloseConnection()
            Throw New Exception(ex.ToString())
        End Try
        Return ds
    End Function

    Public Function RunSimpleQuery(ByVal DMLQuery As String) As Integer
        Dim count As Integer = 0
        Try
            Dim cmd As New SqlCommand(DMLQuery, con)
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            count = cmd.ExecuteNonQuery()
        Catch ex As Exception
            CloseConnection()
            Throw New Exception(ex.ToString())
        End Try

        Return count
    End Function

    Public Function SaveAndRetrieve(ByVal DMLQuery As String, ByVal SelectQuery As String) As String
        Dim str As String = ""
        Try
            Dim cmd As New SqlCommand(DMLQuery, con)
            con.Open()
            Dim count As Integer = cmd.ExecuteNonQuery()
            If count > 0 Then
                cmd = New SqlCommand(SelectQuery, con)
                str = cmd.ExecuteScalar
            End If
        Catch ex As Exception
            CloseConnection()
            Throw New Exception(ex.ToString())
        End Try

        Return str
    End Function

    Public Function CheckRecordsIn(ByVal TableName As String, ByVal CountOnColumn As String) As Boolean
        Dim val As Boolean = False
        Try
            Dim query = "SELECT COUNT(" & CountOnColumn & ") FROM " & TableName
            Dim da As New SqlDataAdapter(query, con)
            Dim dt As New DataTable()
            da.Fill(dt)
            If Integer.Parse(dt.Rows(0)(0).ToString()) > 0 Then
                val = True
            End If
        Catch ex As Exception
            CloseConnection()
            Throw New Exception(ex.ToString())
        End Try
        Return val
    End Function

    Public Function CheckRecordsIn(ByVal TableName As String, ByVal CountOnColumn As String, ByVal Condition As String) As Boolean
        Dim val As Boolean = False
        Try
            Dim query = "SELECT COUNT(" & CountOnColumn & ") FROM " & TableName & " WHERE " & Condition
            Dim da As New SqlDataAdapter(query, con)
            Dim dt As New DataTable()
            da.Fill(dt)
            If Integer.Parse(dt.Rows(0)(0).ToString()) > 0 Then
                val = True
            End If
        Catch ex As Exception
            CloseConnection()
            Throw New Exception(ex.ToString())
        End Try
        Return val
    End Function
    Function GetOracleData(ByVal q As String) As DataTable
        'Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("ACPM_Ora").ConnectionString
        'Dim Oleconnection_ora As New OleDbConnection(strConnectionString)
        'Dim OleAdap As New OleDbDataAdapter(q, Oleconnection_ora)
        'Dim dt As New DataTable
        'OleAdap.Fill(dt)
        'Return dt

        'Dim oraCon As New OracleConnection("Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=133.0.1.2)(PORT=1521))(CONNECT_DATA=(SID=crm2)));User ID=crmisptg;Password=abc#123;")
        'Dim dt As New DataTable
       ' Dim oraCmd As New OracleCommand(q, oraCon)
        'Dim oraAdap As New OracleDataAdapter(oraCmd)
       ' oraAdap.Fill(dt)
       ' Return dt

    End Function
End Class
