﻿'Imports Microsoft.Office.Interop.Excel
Imports System.Data
Imports System.Data.OleDb
Imports System.IO
Imports iTextSharp.text
Imports iTextSharp.text.pdf
'Imports OxyPlot
'Imports OxyPlot.Annotations
'Imports OxyPlot.Series
'Imports OxyPlot.WindowsForms

Public Class PLTCM_TSJ_Schedule
    'Dim objexcel As New Microsoft.Office.Interop.Excel.Application
    'Dim objworkbook As Microsoft.Office.Interop.Excel.Workbook
    'Dim objsheet As Microsoft.Office.Interop.Excel.Worksheet
    Dim strConnectionString As String = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=133.0.1.2)(PORT=1521))(CONNECT_DATA=(SID=crm2)));User ID=crmisptg;Password=abc#123;Unicode=True; Provider=MSDAORA" 'OraOLEDB.Oracle
    Dim Oleconnection_ora As New OleDb.OleDbConnection(strConnectionString)
    Dim oleAdap As New OleDbDataAdapter
    Dim ds As New DataSet
    Public dt, ww_dt As New System.Data.DataTable
    Dim oleCom As New OleDbCommand
    Dim dt1 As DataTable

    Public dtbSorted As New System.Data.DataTable
    Dim no_of_coils As Integer
    Dim campaign_tonnage As Double = 3000
    Dim hr_thick_delta(), cr_thick_delta(), cr_width_delta(), hr_weight(), YP_HR_delta(), penalty_score() As Double
    Dim cr_thick_range, cr_width_range, sum_tonnage, running_tonnage As Double
    Dim nth_coil As Integer = 0
    Dim cr_wid_min, cr_wid_max, cr_thk_min, cr_thk_max, hr_thk_min, hr_thk_max, YP_HR_max, YP_HR_min As Double
    Dim no_of_campaigns_req As Integer
    Dim dvw_sort As New DataView
    Dim campaign_volume(), req_camp_volume() As Double
    Dim first_campaign_vol As Double

    Public Function GetData(ByVal Filter As String) As DataTable
        CloseConnection()
        Oleconnection_ora.Open()
        ds.Clear()
        dt.Clear()
        Dim OraQuery As String = ""
        Dim skinpanel_tdc_str As String = "'CA04', 'CA06', 'CA08', 'CA10', 'CA62', 'ED08', 'FD07', 'GA20', 'GS01', 'GS02', 'GS03', 'GS04', 'GS05', 'GS12', 'GS20', 'HS03', 'HS04', 'IS02', 'LT20', 'MU04', 'MU16', 'NS02', 'NS07', 'TE05', 'TE09', 'TO01', 'TEM0', 'GDZ9', 'GDY9'"
        If Filter = "SkinPanel" Then
            OraQuery = "select pdm_id_pc_ukey,PDM_ID_CR_COIL,PDM_CD_STATUS,PDM_GRADE_STEEL As CR_GRADE,PDM_SEC1_HR as HRTHK,PDM_SEC2_HR as HRWDT, PDM_SEC1_CR_AIM/1000 as CRTHK,PDM_YIELD_POINT as YP_AIM, PDM_TDC_NO as CR_TDC, " &
" PDM_MS_HR_COIL/1000 As HRWT,PDM_LN_HR,PDM_SEC2_AFTR_TRIM As CRWDT,PDM_HR_TDC,PDM_CD_TRIMMER,PDM_ACT_NEXT_PROC,PDM_NM_CUST,PDM_HR_QLTY,PDM_HR_HARDNESS,PDM_ID_PDI " &
" from V_PR_DATA_IP_PCM where (pdm_cd_status like 'WC%' or pdm_cd_status like 'WS%') and (pdm_tdc_no in (" & skinpanel_tdc_str & ")) order by pdm_id_pdi asc"
        End If

        OraQuery = "select pdm_id_pc_ukey,PDM_ID_CR_COIL,PDM_CD_STATUS,PDM_GRADE_STEEL As CR_GRADE,PDM_SEC1_HR as HRTHK,PDM_SEC2_HR as HRWDT, PDM_SEC1_CR_AIM/1000 as CRTHK,PDM_YIELD_POINT as YP_AIM, PDM_TDC_NO as CR_TDC, " &
" PDM_MS_HR_COIL/1000 As HRWT,PDM_LN_HR,PDM_SEC2_AFTR_TRIM As CRWDT,PDM_HR_TDC,PDM_CD_TRIMMER,PDM_ACT_NEXT_PROC,PDM_NM_CUST,PDM_HR_QLTY,PDM_HR_HARDNESS,PDM_ID_PDI " &
" from V_PR_DATA_IP_PCM where (pdm_cd_status like 'WC%' or pdm_cd_status like 'WS%') and (pdm_tdc_no not in (" & skinpanel_tdc_str & ")) order by pdm_id_pdi asc"

        '   " Select   _TDC,PDM_CD_TRIMMER,PDM_ACT_NEXT_PROC "
        '   " Select  PDM_ID_PDI,PDM_ID_CR_COIL,PDM_CD_STATUS,PDM_GRADE_STEEL,PDM_SEC1_HR As HRTHK,PDM_SEC2_HR As HRWDT, PDM_SEC1_CR_AIM/1000 As CRTHK,PDM_YIELD_POINT As YP_AIM, PDM_TDC_NO,PDM_MS_HR_COIL As CRWT,PDM_LN_HR,PDM_SEC2_AFTR_TRIM As CRWDT,PDM_HR_TDC,PDM_CD_TRIMMER,PDM_ACT_NEXT_PROC "

        Ora_selectquery(OraQuery)
        oleAdap.Fill(ds)
        dt = ds.Tables(0)
        Return dt
    End Function



    Sub CloseConnection()
        Try
            If Oleconnection_ora.State <> ConnectionState.Closed Then
                Oleconnection_ora.Close()
            End If
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub
    Public Function Ora_selectquery(ByVal strselect As String) As OleDbDataAdapter
        oleCom.Connection = Oleconnection_ora
        oleCom.CommandText = strselect
        oleAdap.SelectCommand = oleCom
        Return oleAdap
    End Function
    Sub Main()
        'E:\scheduled task\Programs to be scheduled\Scheduled in TASK\test\pltcm schdule
        Dim filepath As String = "E:\scheduled task\Programs to be scheduled\Scheduled in TASK\test\pltcm schdule\input.xlsx"
        Dim total_rows As Integer = 0
        Dim tot_col As Integer = 0
        Dim datatable As New System.Data.DataTable
        Dim temptable As New System.Data.DataTable
        Dim col_name As String = ""
        'Dim dvw As New DataView
        Dim Filter As String = "" '"SkinPanel"
        Try
            '----------------oracle db region-------------
            'comment or uncomment the below section for excel based  and also Imports Microsoft.Office.Interop.Excel
            dt1 = GetData(Filter)
            datatable = dt1
            '------------------------------------------------


            '----------------excel data region-------------------------------
            '--------------------Raw data fetching --------------------------
            'comment or uncomment the below section for excel based  and also Imports Microsoft.Office.Interop.Excel

            'objworkbook = objexcel.Workbooks.Open(filepath)
            ''objsheet = objworkbook.Sheets("testdata")
            'objsheet = objworkbook.Sheets("t_16octB")
            'total_rows = objsheet.UsedRange.Rows.Count
            'tot_col = objsheet.UsedRange.Columns.Count

            'For i As Integer = 1 To tot_col
            '    col_name = objsheet.Cells(1, i).value
            '    If col_name = "CRWDT" Or col_name = "YP_AIM" Or col_name = "CRTHK" Or col_name = "CRWDT" Or col_name = "CRWT" Or col_name = "HRTHK" Or col_name = "HRWDT" Then
            '        datatable.Columns.Add(col_name, GetType(Double))
            '    Else
            '        datatable.Columns.Add(col_name, GetType(String))
            '    End If
            'Next

            'For i As Integer = 0 To total_rows - 2
            '    Dim row As DataRow = datatable.NewRow()
            '    For j As Integer = 0 To tot_col - 1
            '        row(j) = objsheet.Cells(i + 2, j + 1).value
            '    Next
            '    datatable.Rows.Add(row)
            'Next

            'objworkbook.Close()
            'objexcel.Quit()

            'GC.Collect()
            'GC.WaitForPendingFinalizers()
            'GC.Collect()
            'GC.WaitForPendingFinalizers()

            '-------------------------------------

            datatable.Columns.Add("Penalty", GetType(Double))
            datatable.Columns.Add("Campaign", GetType(String))
            datatable.Columns.Add("SNo", GetType(Integer))
            datatable.Columns.Add("PenaltyAct", GetType(Double))
            datatable.Columns.Add("CRWDTPenal", GetType(Double))

            '-------------------Finding penalty score for each coil based on thickness and width --------------------------
            'dataset.Sort(New Sortbyvalue)
            no_of_coils = datatable.Rows.Count - 1
            ReDim hr_thick_delta(no_of_coils), cr_thick_delta(no_of_coils), cr_width_delta(no_of_coils), hr_weight(no_of_coils), YP_HR_delta(no_of_coils), penalty_score(no_of_coils)
            sum_tonnage = 0
            running_tonnage = 0

            '------initialise coils preferred width > 1500, HR thickness  3 to 3.5, Cr thickness 0.9 to 1.3
            For t As Integer = 0 To datatable.Rows.Count - 1
                If (datatable.Rows(t)("HRTHK") > 3 And datatable.Rows(t)("HRTHK") < 3.5) And (datatable.Rows(t)("CRTHK") > 0.9 And datatable.Rows(t)("CRTHK") < 1.3) And datatable.Rows(t)("CRWDT") > 1500 Then
                    datatable.Rows(t)("Penalty") = -1
                Else
                    datatable.Rows(t)("Penalty") = 0
                End If
            Next t
            '--------------------width wise sorting --------------------------
            dvw_sort = datatable.DefaultView
            dvw_sort.RowFilter = "PDM_CD_STATUS = 'WW'"
            ww_dt = dvw_sort.ToTable()
            dvw_sort.RowFilter = "PDM_CD_STATUS = 'WC' or PDM_CD_STATUS = 'WS' "
            dvw_sort.Sort = "CRWDT DESC, Penalty ASC"

            dtbSorted = dvw_sort.ToTable()

            total_rows = dtbSorted.Rows.Count
            tot_col = dtbSorted.Columns.Count
            Dim avail_ton As String = dtbSorted.Compute("Sum(HRWT)/1000", "")
            Console.WriteLine("Total tonnage available for scheduling: {0}", avail_ton)

            temptable = dtbSorted

            ' each time one coil is compared with other coils for compactability based on constraints
            ' once the coil is found then that coil is linked with the previous and not considered for further sequencing
            ' Total_run -- values lower than total_run will not be considered for further sequencing
            ' nth coil is the coil from which the comparing is done from nth coil to last coil                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
            ' penalty score is added for each constraint is not meeting the requirement
            ' Finally, when sorted, the lowest score with zero needs to be placed for sequencing

            For k As Integer = 0 To dtbSorted.Rows.Count - 1
                hr_thick_delta(k) = dtbSorted.Rows(k)("HRTHK")
                cr_thick_delta(k) = dtbSorted.Rows(k)("CRTHK")
                cr_width_delta(k) = dtbSorted.Rows(k)("CRWDT")
                YP_HR_delta(k) = dtbSorted.Rows(k)("YP_AIM")
                hr_weight(k) = dtbSorted.Rows(k)("HRWT")
                dtbSorted.Rows(k)("Penalty") = 0
            Next

            sum_tonnage = hr_weight.Sum()
            first_campaign_vol = campaign_tonnage
            ' first_campaign_vol = 800
            no_of_campaigns_req = Math.Ceiling((sum_tonnage) / campaign_tonnage) - 1
            no_of_campaigns_req = 0

            Dim overall_camp_penalty(no_of_coils) As Double

            ReDim campaign_volume(no_of_campaigns_req)
            ReDim req_camp_volume(no_of_campaigns_req)
            For i As Integer = 0 To no_of_campaigns_req
                If i = 0 Then
                    req_camp_volume(i) = first_campaign_vol
                ElseIf i <> 0 And i < no_of_campaigns_req Then
                    req_camp_volume(i) = campaign_tonnage
                ElseIf i >= no_of_campaigns_req Then
                    req_camp_volume(i) = sum_tonnage - i * campaign_tonnage
                End If
            Next
            'Math.DivRem(nth_coil, (no_of_campaigns_req * 2), remainder)   ' 2 is multilied as every time 2 rows are compared



            'This is to normalise the values for calculating the penalty score. Else absolute values will initiate issue
            cr_wid_min = cr_width_delta.Min()
            cr_wid_max = cr_width_delta.Max()
            hr_thk_min = hr_thick_delta.Min()
            hr_thk_max = hr_thick_delta.Max()
            cr_thk_min = cr_thick_delta.Min()
            cr_thk_max = cr_thick_delta.Max()
            YP_HR_max = YP_HR_delta.Max()
            YP_HR_min = YP_HR_delta.Min()

            Dim pair_coil As Integer = 0
            Dim campaign As Integer = 0
            Dim secondloop_count As Integer = 1
            Dim thirdloop_count As Integer = 0
            Dim high_width_coils_count As Integer = 0
            Dim min_width_selection As Integer = 1500
            ' min_width_selection = ww_dt.Rows(ww_dt.Rows.Count - 1)("HRWDT")

            '--------start-------pdf making -----------
            'Dim pdffilepath As String = AppDomain.CurrentDomain.BaseDirectory & "widthTrend-" & DateTime.Now.AddDays(-1).ToString("dd-MMM") & ".pdf"
            'Dim sw As New FileStream(pdffilepath, FileMode.Create)
            'Dim pdfDoc As New Document(iTextSharp.text.PageSize.A4.Rotate(), 5.0F, 5.0F, 5.0F, 0.0F)
            'Dim writer As PdfWriter = PdfWriter.GetInstance(pdfDoc, sw)
            'pdfDoc.Open()
            '----------

			Dim table_no As Integer = 0
            For start_coil_id As Integer = 0 To 0
                Console.WriteLine("------------------{0}-------------", start_coil_id)
                For m_wid As Integer = 0 To dtbSorted.Rows.Count - 1

                    ''we are sorting according to width. (descending)
                    ' 'ex-->1540...1540...1540...1540...1540...1500...1500...1500...1320...1310...1290...
                    'm_wid = 0 --> starting default value would be coil 0..then sorting-->prepare schedule
                    'm_wid = 1 --> startng default value would be coil 1..then sorting-->prepare schedule
                    'm_wid = n --> startng default value would be coil n..then sorting-->prepare schedule
                    'this will continue untill the starting width is above the min_width_selection, eg. 1540 mm width

                    ReDim penalty_score(no_of_coils)

                    'If m_wid = 0 Or m_wid = 4 Or m_wid = 9 Or m_wid = 13 Then
                    '    MsgBox("hi")
                    'End If

                    '------start--------
                    '-----------this condition to check whether suficinet coils are available in high width
                    ' here atleast 10 high width coils are needed... if min_width_selection is 10-->then atleast coils with width >1500 should be 10
                    'else it will reduce the min_width_selection to less than 1500
                    If m_wid = dtbSorted.Rows.Count - 1 Then
                        If (dtbSorted.Rows.Count - 1 - high_width_coils_count) < 10 Then
                            m_wid = 0
                            min_width_selection = min_width_selection - 120
                            high_width_coils_count = 0
                        End If
                    End If

                    'we are sorting according to width. (descending)
                    ' 'ex-->1540...1540...1540...1540...1540...1500...1500...1500...1320...1310...1290...
                    'We need to start always with higher coil widthso if a lower coil width comes in the starting say 1320.. we need not schedule as in practical lower widths are not preferred.
                    '-----
                    If temptable.Rows(m_wid)("CRWDT") <= min_width_selection Then
                        high_width_coils_count = high_width_coils_count + 1
                        Continue For
                    End If
                    '----------------end-----------------


                    overall_camp_penalty(m_wid) = -999
                    temptable.Rows(m_wid)("Penalty") = (no_of_coils) * -1


                    dtbSorted = temptable
                    dvw_sort = dtbSorted.DefaultView
                    dvw_sort.Sort = "Penalty ASC"
                    'dvw_sort.Sort = " CRWDTPenal ASC"
                    dtbSorted = dvw_sort.ToTable()
                    dtbSorted.Rows(0)("Campaign") = 0
                    dtbSorted.Rows(0)("PenaltyAct") = 0
                    nth_coil = 0
                    pair_coil = 0
                    secondloop_count = 1
                    thirdloop_count = 0

                    'assigning the dt to arrya as sorting is done above
                    assign_dt_to_array()


                    'this loop is to calculate the penalty for each coil with the sequenced coil
                    While nth_coil < no_of_coils
                        Try

                            pair_coil = pair_coil + 1
                            '-----------first loop conditions----------------------
                            If pair_coil = 1 And nth_coil <= (no_of_campaigns_req * 2 + 1) Then
                                min_penalty_method(nth_coil, nth_coil)
                                pair_coil = 0
                                dtbSorted.Rows(nth_coil)("Campaign") = campaign

                                campaign = campaign + 1
                                nth_coil = nth_coil + 1

                                dvw_sort = dtbSorted.DefaultView
                                dvw_sort.Sort = "Penalty ASC"
                                'dvw_sort.Sort = " CRWDTPenal ASC"
                                dtbSorted = dvw_sort.ToTable()

                                'assigning the dt to arrya as sorting is done above
                                assign_dt_to_array()

                                dtbSorted.Rows(nth_coil)("Penalty") = (no_of_coils - nth_coil) * -1
                                dtbSorted.Rows(nth_coil)("Campaign") = campaign
                                If campaign > no_of_campaigns_req Then
                                    campaign = 0
                                    If (nth_coil - 1) = (no_of_campaigns_req * 2 + 1) Then
                                        dtbSorted.Rows(nth_coil)("Penalty") = 0
                                        dtbSorted.Rows(nth_coil)("Campaign") = -1
                                        nth_coil = nth_coil - 1
                                    End If
                                End If
                            End If


                            '------------Second loop conditions-----------------------------
                            If nth_coil > (no_of_campaigns_req * 2) And nth_coil <= (no_of_campaigns_req * 2) + no_of_campaigns_req + 1 Then
                                min_penalty_method(nth_coil, secondloop_count)
                                secondloop_count = secondloop_count + 2
                                dtbSorted.Rows(nth_coil)("Campaign") = campaign
                                campaign = campaign + 1
                                If campaign > no_of_campaigns_req Then
                                    campaign = 0
                                    'If (nth_coil - 1) = (no_of_campaigns_req * 2 + no_of_campaigns_req + 1) Then
                                    '    dtbSorted.Rows(nth_coil)("Penalty") = 0
                                    '    dtbSorted.Rows(nth_coil)("Campaign") = ""
                                    '    nth_coil = nth_coil - 1
                                    'End If
                                End If
                            End If

                            '-----------Third loop conditions------------------------------
                            If nth_coil > (no_of_campaigns_req * 2) + no_of_campaigns_req + 1 Then
                                min_penalty_method(nth_coil, (nth_coil - no_of_campaigns_req))
                                dtbSorted.Rows(nth_coil)("Campaign") = campaign
                                campaign = campaign + 1
                                cal_running_tonnage_campaignwise()
                                If campaign > no_of_campaigns_req Then
                                    campaign = 0
                                End If
                                Dim count_chk As Integer = 0
                                For chk_vol As Integer = 0 To no_of_campaigns_req
                                    If campaign_volume(chk_vol) > campaign_tonnage Then
                                        count_chk = count_chk + 1
                                    End If
                                Next
                                If count_chk = no_of_campaigns_req + 1 Then
                                    Console.WriteLine("-----------Scheduling done-----------")
                                    Exit While
                                End If
                            End If

                        Catch ex As Exception
                        End Try
                    End While

                    dvw_sort.Sort = "Campaign desc, SNo ASC"

                    dtbSorted = dvw_sort.ToTable()
                    check_for_abnormality()
                    dtbSorted.TableName = table_no
                    table_no = table_no + 1
                    ds.Tables.Add(dtbSorted)
                    Dim penalty_sum As Double = 0
                    For k As Integer = 0 To dtbSorted.Rows.Count - 1
                        If IsDBNull(dtbSorted.Rows(k)("Campaign")) Then

                        ElseIf dtbSorted.Rows(k)("Campaign") >= 0 And (IsDBNull(dtbSorted.Rows(k)("PenaltyAct")) = False) Then
                            penalty_sum = penalty_sum + dtbSorted.Rows(k)("PenaltyAct")
                        End If
                        dtbSorted.Rows(k)("Penalty") = 0
                        temptable.Rows(k)("Penalty") = 0
                    Next
                    overall_camp_penalty(m_wid) = Math.Round(penalty_sum, 3)
                    If penalty_sum < 800 Then
                        Console.WriteLine("penalty < 800 --> {0}     last score   :  {1} ", m_wid, overall_camp_penalty(m_wid))
                    End If
                    Console.WriteLine("{0}     last score   :  {1} ", m_wid, overall_camp_penalty(m_wid))

                    '#Region "Charts"


                    '                    pdfDoc.NewPage()
                    '                    'Dim table1 As New PdfPTable(2)
                    '                    'Dim intTblWidth() As Integer = {4, 4}
                    '                    Dim table1 As New PdfPTable(1)
                    '                    Dim intTblWidth() As Integer = {4}

                    '                    table1.SetWidths(intTblWidth)
                    '                    'table1.DefaultCell.Border = Rectangle.NO_BORDER
                    '                    table1.WidthPercentage = 100
                    '                    table1.SpacingBefore = 10

                    '                    Dim model As New PlotModel
                    '                    model.Title = "width"
                    '                    model.TitleFont = iTextSharp.text.Font.FontFamily.COURIER
                    '                    model.TitleFont = iTextSharp.text.Font.BOLD
                    '                    model.TitleFontSize = 20
                    '                    Dim LineSeries As New OxyPlot.Series.LineSeries()
                    '                    Dim lineSeries1 As New OxyPlot.Series.LineSeries()

                    '                    For k As Integer = 0 To dtbSorted.Rows.Count - 1
                    '                        LineSeries.Points.Add(New OxyPlot.DataPoint(k, Convert.ToDouble(dtbSorted.Rows(k)("CRWDT"))))
                    '                    Next k
                    '                    LineSeries.StrokeThickness = 2
                    '                    LineSeries.Color = OxyPlot.OxyColor.FromRgb(0, 0, 0)
                    '                    LineSeries.LineStyle = LineStyle.None
                    '                    LineSeries.MarkerType = MarkerType.Circle
                    '                    LineSeries.MarkerFill = OxyPlot.OxyColor.FromArgb(200, 0, 0, 0) 'OxyColors.Purple
                    '                    LineSeries.MarkerSize = 2
                    '                    model.Axes.Add(New OxyPlot.Axes.LinearAxis With {
                    '                          .Position = OxyPlot.Axes.AxisPosition.Left,
                    '                          .Title = "check",
                    '                          .TextColor = OxyPlot.OxyColors.Black,
                    '                          .Font = iTextSharp.text.Font.BOLD,
                    '                          .TitleFont = iTextSharp.text.Font.FontFamily.COURIER,
                    '                          .Key = "leftaxis",
                    '                          .IntervalLength = 20,
                    '                          .FontSize = 16
                    '                    })

                    '                    LineSeries.YAxisKey = "leftaxis"
                    '                    model.Series.Add(LineSeries)
                    '                    model.Background = OxyColors.White


                    '                    Dim ms As New System.IO.MemoryStream

                    '                    Dim obj As New PngExporter
                    '                    obj.Export(model, ms)

                    '                    obj.ExportToFile(model, "E:\scheduled task\Programs to be scheduled\Scheduled in TASK\test\pltcm schdule\pltcm_schdule\pltcm_schdule\bin\Debug\test.png")

                    '                    Dim b() As Byte = ms.ToArray

                    '                    Dim img As Image = Image.GetInstance(b)
                    '                    Dim cell6 = New PdfPCell(img, True)
                    '                    cell6.Padding = 10
                    '                    cell6.HorizontalAlignment = iTextSharp.text.Element.ALIGN_CENTER

                    '                    Dim imgname As String
                    '                    Dim color As BaseColor
                    '                    table1.AddCell(cell6)

                    '                    pdfDoc.Add(table1)

                    '#End Region


                    '--------end-------pdf making -----------


                    '----------
                Next m_wid
                'pdfDoc.Close()
                Dim min_val As Double = Double.MaxValue
                For Each element As Double In overall_camp_penalty
                    If element > 0 Then
                        min_val = Math.Min(min_val, element)
                    End If
                Next

                Dim splitpoint = overall_camp_penalty.ToList.IndexOf(min_val)
                ww_dt.Merge(ds.Tables(splitpoint))
                'ww_dt.Merge(ds.Tables(1))

            Next start_coil_id

            'objworkbook.SaveAs(IO.Path.GetDirectoryName(Diagnostics.Process.GetCurrentProcess().MainModule.FileName) & "\" & IIf(arrCoilID(i) = "0", arrCoilIDText(i), arrCoilID(i)) & "_" & i & ".xlsx")

            ' Now find the rows which got deviated ( score > 900)
            ' between these two rows another coil shuld be inserted so that the deviation is removed (> 900 score)
            ' Find the values where there are atleast two consequtive 0
            ' Filter those by removing the first 0, i.e, if row 10 penalty is 0 and row 11 penalty is 0, consider only row 11
            ' from this list find the row or coil which can be combined with the coil getting deviated so that the score becomes < 900
            ' repeat for all the deviation coils



        Catch ex As Exception


        End Try
    End Sub

    Sub assign_dt_to_array()
        For k As Integer = 0 To dtbSorted.Rows.Count - 1
            hr_thick_delta(k) = dtbSorted.Rows(k)("HRTHK")
            cr_thick_delta(k) = dtbSorted.Rows(k)("CRTHK")
            cr_width_delta(k) = dtbSorted.Rows(k)("CRWDT")
            YP_HR_delta(k) = dtbSorted.Rows(k)("YP_AIM")
            hr_weight(k) = dtbSorted.Rows(k)("HRWT")
            'dtbSorted.Rows(k)("Campaign") = -1
        Next
    End Sub
    Sub min_penalty_method(ByRef nth_coil As Integer, ByVal compare_coil_int As Integer)

        Dim hr_thick_diff_norm, cr_thick_diff_norm, cr_wid_diff_norm, yp_hr_diff_norm As Double
        Dim curr_coil_spd_cal, nxt_coil_spd_cal As Double
        Dim coil_wid_ref As Double = cr_width_delta(compare_coil_int)
        Dim thickness_jump1 As Double = 0
        Dim thickness_jump2 As Double = 0
        Try
            For i As Integer = nth_coil + 1 To dtbSorted.Rows.Count - 1
                cr_thick_range = 0
                cr_width_range = 0
                running_tonnage = running_tonnage + hr_weight(nth_coil)

                '----more penalty to CR_wid----this is to maintain the coffin schedule
                ' else there might be coils with low-high-low-high which is not desirable

                hr_thick_diff_norm = 1 * Math.Abs((hr_thick_delta(compare_coil_int) - hr_thk_min) / (hr_thk_max - hr_thk_min) - (hr_thick_delta(i) - hr_thk_min) / (hr_thk_max - hr_thk_min))
                cr_thick_diff_norm = 1 * Math.Abs((cr_thick_delta(compare_coil_int) - cr_thk_min) / (cr_thk_max - cr_thk_min) - (cr_thick_delta(i) - cr_thk_min) / (cr_thk_max - cr_thk_min))
                yp_hr_diff_norm = 1 * Math.Abs((YP_HR_delta(compare_coil_int) - YP_HR_min) / (YP_HR_max - YP_HR_min) - (YP_HR_delta(i) - YP_HR_min) / (YP_HR_max - YP_HR_min))

                '1. Tuning parameter --> 2.5
                cr_wid_diff_norm = (2.5) * Math.Abs((cr_width_delta(compare_coil_int) - cr_wid_min) / (cr_wid_max - cr_wid_min) - (cr_width_delta(i) - cr_wid_min) / (cr_wid_max - cr_wid_min))

                '2. Tuning parameter --> compare_coil_int * 0.05
                'cr_wid_diff_norm = (3.5 + compare_coil_int * 0.05) * Math.Abs((cr_width_delta(compare_coil_int) - cr_wid_min) / (cr_wid_max - cr_wid_min) - (cr_width_delta(i) - cr_wid_min) / (cr_wid_max - cr_wid_min))


                'constraint-- hr thickness jump 30% or 1 mm allowed
                thickness_jump1 = Math.Abs((hr_thick_delta(compare_coil_int) - hr_thick_delta(i)) / (hr_thick_delta(compare_coil_int))) * 100
                thickness_jump2 = Math.Abs(hr_thick_delta(compare_coil_int) - hr_thick_delta(i))
                If thickness_jump1 > 30 Or thickness_jump2 > 1 Then
                    penalty_score(i) = penalty_score(i) + 999 + hr_thick_diff_norm
                Else
                    penalty_score(i) = penalty_score(i) + hr_thick_diff_norm
                End If

                'constraint -- CR thickness jump --> based on CR thickness jump is allowed. Higher the thickness higher jump allowed
                cr_thick_range = cr_thick_limit_fn(cr_thick_delta(compare_coil_int), cr_thick_delta(i))
                If Math.Abs(cr_thick_delta(compare_coil_int) - cr_thick_delta(i)) > cr_thick_range Then
                    penalty_score(i) = penalty_score(i) + 999 + cr_thick_diff_norm
                Else
                    penalty_score(i) = penalty_score(i) + cr_thick_diff_norm
                End If

                'contraint -- CR width jump --> depends on CR thickness--> higher the thickness higher is the jump allowed (120 for <0.6 or 150 mm)
                cr_width_range = cr_width_limit_fn(cr_thick_delta(compare_coil_int), cr_thick_delta(i))
                If Math.Abs(cr_width_delta(compare_coil_int) - cr_width_delta(i)) > cr_width_range Then
                    penalty_score(i) = penalty_score(i) + 999 + cr_wid_diff_norm
                Else
                    If cr_width_delta(compare_coil_int) - cr_width_delta(i) < 0 Then
                        penalty_score(i) = penalty_score(i) + 100 + cr_wid_diff_norm
                    Else
                        penalty_score(i) = penalty_score(i) + cr_wid_diff_norm
                    End If

                End If

                ' constraint - HR --- Yield point--max 10 jump
                If Math.Abs(YP_HR_delta(compare_coil_int) - YP_HR_delta(i)) > 10 Then
                    penalty_score(i) = penalty_score(i) + 999 + yp_hr_diff_norm
                Else
                    penalty_score(i) = penalty_score(i) + yp_hr_diff_norm
                End If


                '3. Tuning parameter --> 0.25
                'Constraint--penalty for repeated  same HR thickness -- this Is to give more importance to variable speed 
                'If compare_coil_int > 10 Then
                '    If hr_thick_delta(compare_coil_int) = hr_thick_delta(i) And hr_thick_delta(compare_coil_int - 2) = hr_thick_delta(i) Then
                '        penalty_score(i) = penalty_score(i) + 0.5
                '    End If
                'End If

                'TWO constraints-- penalty for repeated  same CR thickness -- this is to give more importance to variable speed 
                'CR thickness should not be on lower side <0.8 mm during the start of the mill
                'So penalty to be given for coils with thickness < 0.8 mm
                If compare_coil_int <= 5 Then
                    If cr_thick_delta(i) < 0.8 Then
                        penalty_score(i) = penalty_score(i) + 5
                    End If
                Else
                    If cr_thick_delta(compare_coil_int) = cr_thick_delta(i) Then
                        penalty_score(i) = penalty_score(i) + 0.5
                    End If
                End If



                'constraint-- TPOH--420 is the max
                'curr_coil_spd_cal = cal_speed(dtbSorted.Rows(compare_coil_int)("CR_TDC"), dtbSorted.Rows(compare_coil_int)("CR_GRADE"))
                'nxt_coil_spd_cal = cal_speed(dtbSorted.Rows(i)("CR_TDC"), dtbSorted.Rows(i)("CR_GRADE"))


                dtbSorted.Rows(i)("Penalty") = penalty_score(i) '+ Math.Abs(cr_width_delta(i) - cr_width_delta(compare_coil_int))
                'dtbSorted.Rows(i)("CRWDTPenal") = Math.Abs(cr_width_delta(i) - cr_width_delta(compare_coil_int)) + penalty_score(i)


            Next

            'If cr_width_delta(compare_coil_int) < 1280 Then
            '    For p As Integer = nth_coil To dtbSorted.Rows.Count - 1
            '        If (cr_width_delta(p) - cr_width_delta(compare_coil_int) < 0) And dtbSorted.Rows(p)("Penalty") < 800 Then
            '            dtbSorted.Rows(p)("Penalty") = -1 * (cr_width_delta(p) - cr_width_delta(compare_coil_int)) + dtbSorted.Rows(p)("Penalty")
            '        End If
            '    Next p
            'End If
            dvw_sort = dtbSorted.DefaultView
            dvw_sort.Sort = " Penalty ASC"


            'while making schedule--->after each comparision, the penalty is added to coils if the width is not in decreasing order
            Dim temp_penalty As Double = 0
            For k As Integer = 0 To dtbSorted.Rows.Count - 1
                If (coil_wid_ref - dvw_sort(k)("CRWDT")) >= 0 Then
                    temp_penalty = coil_wid_ref - dvw_sort(k)("CRWDT")
                Else
                    temp_penalty = 300
                End If
                If dvw_sort(k)("Penalty") < 0 Then
                    dvw_sort(k)("CRWDTPenal") = dvw_sort(k)("Penalty")
                Else
                    dvw_sort(k)("CRWDTPenal") = dvw_sort(k)("Penalty") + temp_penalty
                End If
            Next
            dvw_sort.Sort = " CRWDTPenal ASC"

            dtbSorted = dvw_sort.ToTable()
            nth_coil = nth_coil + 1
            dtbSorted.Rows(nth_coil)("PenaltyAct") = Math.Round(dtbSorted.Rows(nth_coil)("Penalty"), 1)
            dtbSorted.Rows(nth_coil)("Penalty") = (no_of_coils - nth_coil) * -1
            penalty_score(nth_coil) = 0


            'Math.DivRem(nth_coil, no_of_campaigns_req * 2, remainder)


        Catch ex As Exception
        End Try

        Try
            For m As Integer = nth_coil + 1 To dtbSorted.Rows.Count - 1
                dtbSorted.Rows(m)("Penalty") = 0
                penalty_score(m) = 0
            Next
        Catch ex As Exception
        End Try

        running_tonnage = 0

        'After sorting assign the values again to the array as the older values are interchagned due to sorting
        For k As Integer = 0 To dtbSorted.Rows.Count - 1
            hr_thick_delta(k) = dtbSorted.Rows(k)("HRTHK")
            cr_thick_delta(k) = dtbSorted.Rows(k)("CRTHK")
            cr_width_delta(k) = dtbSorted.Rows(k)("CRWDT")
            YP_HR_delta(k) = dtbSorted.Rows(k)("YP_AIM")
            hr_weight(k) = dtbSorted.Rows(k)("HRWT")
            dtbSorted.Rows(k)("SNo") = k
        Next


    End Sub

    Sub check_for_abnormality()
        Try


            For m As Integer = 0 To dtbSorted.Rows.Count - 2

                If IsDBNull(dtbSorted.Rows(m)("PenaltyAct")) = False Then
                    If dtbSorted.Rows(m)("PenaltyAct") > 999 Then
                        Dim compare_coil_int As Integer = m
                        Dim count_exception As Integer = 0
                        Dim cr_thick_range1, cr_thick_range2, thickness_jump1, thickness_jump2, thickness_jump1_1, thickness_jump2_1 As Double
                        Dim cr_width_range1, cr_width_range2 As Double
                        Try


                            For n = 0 To dtbSorted.Rows.Count - 2
                                Try


                                    'constraint-- hr thickness jump 30% or 1 mm allowed
                                    'constraint-- hr thickness jump 30% or 1 mm allowed
                                    thickness_jump1 = Math.Abs((hr_thick_delta(compare_coil_int) - hr_thick_delta(n)) / (hr_thick_delta(compare_coil_int))) * 100
                                    thickness_jump2 = Math.Abs(hr_thick_delta(compare_coil_int) - hr_thick_delta(n))
                                    thickness_jump1_1 = Math.Abs((hr_thick_delta(compare_coil_int) - hr_thick_delta(n + 1)) / (hr_thick_delta(compare_coil_int))) * 100
                                    thickness_jump2_1 = Math.Abs(hr_thick_delta(compare_coil_int) - hr_thick_delta(n + 1))
                                    If thickness_jump1 > 30 Or thickness_jump2 > 1 Or thickness_jump1_1 > 30 Or thickness_jump2_1 > 1 Then

                                    Else
                                        count_exception = count_exception + 1
                                    End If

                                    'constraint -- CR thickness jump --> based on CR thickness jump is allowed. Higher the thickness higher jump allowed
                                    cr_thick_range1 = cr_thick_limit_fn(cr_thick_delta(compare_coil_int), cr_thick_delta(n))
                                    cr_thick_range2 = cr_thick_limit_fn(cr_thick_delta(compare_coil_int), cr_thick_delta(n + 1))
                                    If Math.Abs(cr_thick_delta(compare_coil_int) - cr_thick_delta(n)) > cr_thick_range And Math.Abs(cr_thick_delta(compare_coil_int) - cr_thick_delta(n + 1)) > cr_thick_range Then

                                    Else
                                        count_exception = count_exception + 1
                                    End If

                                    'contraint -- CR width jump --> depends on CR thickness--> higher the thickness higher is the jump allowed (120 for <0.6 or 150 mm)
                                    cr_width_range1 = cr_width_limit_fn(cr_thick_delta(compare_coil_int), cr_thick_delta(n))
                                    cr_width_range2 = cr_width_limit_fn(cr_thick_delta(compare_coil_int), cr_thick_delta(n + 1))
                                    If Math.Abs(cr_width_delta(compare_coil_int) - cr_width_delta(n)) > cr_width_range And Math.Abs(cr_width_delta(compare_coil_int) - cr_width_delta(n + 1)) > cr_width_range Then

                                    Else
                                        count_exception = count_exception + 1
                                    End If

                                    ' constraint - HR --- Yield point--max 10 jump
                                    If Math.Abs(YP_HR_delta(compare_coil_int) - YP_HR_delta(n)) > 10 And Math.Abs(YP_HR_delta(compare_coil_int) - YP_HR_delta(n + 1)) > 10 Then

                                    Else
                                        count_exception = count_exception + 1
                                    End If
                                Catch ex As Exception

                                End Try
                            Next n
                        Catch ex As Exception

                        End Try
                    End If
                End If
            Next m
        Catch ex As Exception

        End Try
    End Sub
    Function cal_speed(ByVal tdc As String, ByVal grade As String) As Double

        'The below constraints as as on 24-jul-2023---
        ''these needs to be updated when ever there are changes
        'DQ  220
        'CQ  220
        'EAL 185
        'BHS 180
        'DDQ 215
        'HIF And CA10    120
        'HIF And Not CA10    205
        'HSQ And CA18    120
        'HSQ And Not CA18    205
        'EIF And MU04, TE05, CA04, CA06, CA08, GS series, GDY9, GDZ9, GA20, GHM0, TEM0	120
        'EIF And Not MU04, TE05, CA04, CA06, CA08, GS series, GDY9, GDZ9, GA20, GHM0, TEM0	180
        Dim TDC_EIF() As String = {"MU04", "TE05", "CA04", "CA06", "CA08", "GDY9", "GDZ9", "GA20", "GHM0", "TEM0", "GS"}
        Dim TDC_HIF() As String = {"CA18"}
        Dim TDC_HSQ() As String = {"CA10"}
        Dim speed As Double = 0
        If grade = "CQ" Then
            speed = 120
        End If
        If grade = "DQ" Then
            speed = 220
        End If
        If grade = "EAL" Then
            speed = 185
        End If
        If grade = "BHS" Then
            speed = 180
        End If
        If grade = "DDQ" Then
            speed = 215
        End If
        If grade = "HIF" Then
            If TDC_HIF.Contains(tdc) Then
                speed = 120
            Else
                speed = 205
            End If
        End If
        If grade = "HSQ" Then
            If TDC_HSQ.Contains(tdc) Then
                speed = 120
            Else
                speed = 205
            End If
        End If
        If grade = "EIF" Then
            If TDC_EIF.Contains(tdc) Then
                speed = 120
            Else
                speed = 205
            End If
        End If

        Return speed

    End Function


    Sub cal_running_tonnage_campaignwise()
        Try
            Dim sum_ton As Double = 0
            For cam_int As Integer = 0 To no_of_campaigns_req
                sum_ton = 0
                For i As Integer = 0 To dtbSorted.Rows.Count - 1
                    If IsDBNull(dtbSorted.Rows(i)("Campaign")) Then

                    ElseIf dtbSorted.Rows(i)("Campaign") <> "" Then
                        If cam_int = dtbSorted.Rows(i)("Campaign") Then
                            sum_ton = sum_ton + dtbSorted.Rows(i)("HRWT")
                        End If
                    End If
                    'If dtbSorted.Rows(i)("PenaltyAct") > 900 Then
                    '    Console.WriteLine(" scheduled tonnage  :  {0} ", sum_ton)
                    '    Exit For
                    'End If
                Next
                campaign_volume(cam_int) = sum_ton
            Next
        Catch ex As Exception

        End Try


    End Sub

    Function cr_thick_limit_fn(prev_val As Double, next_val As Double) As Double
        Dim diff, allowed_delta As Double
        diff = Math.Abs(next_val - prev_val)
        If (prev_val < 0.4) Then
            allowed_delta = 0.06
        ElseIf prev_val < 0.6 Then
            allowed_delta = 0.15
        ElseIf prev_val < 0.8 Then
            allowed_delta = 0.25
        ElseIf prev_val < 1.2 Then
            allowed_delta = 0.35
        ElseIf prev_val < 1.8 Then
            allowed_delta = 0.45
        ElseIf prev_val >= 1.8 Then
            allowed_delta = 0.65
        End If
        Return allowed_delta
    End Function
    Function cr_width_limit_fn(prev_val As Double, next_val As Double) As Double
        Dim diff, allowed_delta As Double
        diff = Math.Abs(next_val - prev_val)
        If (prev_val <= 0.6) Then
            allowed_delta = 120
        Else
            allowed_delta = 150
        End If

        Return allowed_delta
    End Function

End Class
