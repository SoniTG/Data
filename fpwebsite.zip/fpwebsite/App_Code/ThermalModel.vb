﻿Imports Microsoft.VisualBasic
Imports System.Data
Imports System.Data.SqlClient
Public Class ThermalModel
    Dim Qstrip As Double
    Dim Mass_Ingot, Mass_Coil, Tmelt, Tamb, Cp_Zn_l, Tbath_C, Tbath_K, sum_t, duration, PI, T_strip_K, T_strip_C As Decimal
    Dim a1, b1, c1, Lmelt, Qloss_avg, SteelDensity As Double
    'Public Sub main(ByVal sqldt As DataTable, ByVal r As Integer, ByVal dgvCoilData As GridView)
    '    Qloss_avg = 185 ''KW
    '    SteelDensity = 7850
    '    Tmelt = 420 + 273
    '    Tamb = 40 + 273
    '    Lmelt = 111884.4
    '    Cp_Zn_l = 479.5

    '    duration = sqldt(r)(6)
    '    Dim coil_len As Double = sqldt(r)(9)
    '    Mass_Coil = calc_CoilMass(dgvCoilData.Rows(r).Cells(4).Value, dgvCoilData.Rows(r).Cells(5).Value, coil_len, SteelDensity)
    '    Mass_Ingot = dgvCoilData.Rows(r).Cells(6).Value + dgvCoilData.Rows(r).Cells(7).Value + dgvCoilData.Rows(r).Cells(8).Value

    '    Tbath_C = dgvCoilData.Rows(r).Cells(9).Value

    '    '---------------Testing----------------
    '    'duration = 18
    '    'Mass_Coil = calc_CoilMass(0.8, 1520, 1385, SteelDensity)
    '    'Mass_Ingot = 0
    '    'Tbath_C = 466
    '    'Qstrip = -(0 - (calc_Qloss(Qloss_avg, duration) + calc_Qingot(Mass_Ingot, Tmelt, Tamb, Cp_Zn_l, Tbath_C)))
    '    '--------------End Testing-----------------
    '    Dim Qind As Double
    '    ''Qind= calc_Qind(sum_t, PI)
    '    Qind = 62848000.0063777
    '    Qstrip = -(Qind - (calc_Qloss(Qloss_avg, duration) + calc_Qingot(Mass_Ingot, Tmelt, Tamb, Cp_Zn_l, Tbath_C)))
    '    ''  MsgBox(Qstrip)
    '    Dim C As Double = calc_Constant(Mass_Coil, Tbath_C)
    '    T_strip_C = NewtonsMethod(Tbath_C, C, 0.001, 100) - 273
    '    ''  MsgBox(T_strip_C)
    '    dgvCoilData.Rows(r).Cells(11).Value = Math.Round(T_strip_C, 0)
    '    dgvCoilData.Rows(r).Cells(12).Value = dgvCoilData.Rows(r).Cells(11).Value - dgvCoilData.Rows(r).Cells(10).Value

    'End Sub
    'Public Function TempStrip()
    '    Dim Funct As New Func(Of Double, Double)(Function(X As Double) (504 * T_strip_K + (-0.06545) * T_strip_K * T_strip_K - (-0.000005179) / T_strip_K + (0.000149323) * T_strip_K * T_strip_K * T_strip_K - calc_Constant(Mass_Coil, Tbath_C)))
    '    Dim Deriv As New Func(Of Double, Double)(Function(X As Double) (504.2 + (2 * -0.06545) * T_strip_K + (-0.000005179) / (Math.Pow(T_strip_K, 2) + (3 * 0.000149) * T_strip_K * T_strip_K)))

    '    Return T_strip_K = NewtonSolver(Funct, Deriv, Tbath_C, 0.001)
    'End Function
    Public Function calc_Constant(ByVal CoilMass As Decimal, ByVal BathTemp As Decimal, ByVal Qstrip As Double) As Double
        Return ((Qstrip / CoilMass) + ((504.2 * (BathTemp + 273)) + ((-0.06545) * Math.Pow((BathTemp + 273), 2)) - ((-0.000005179) / (BathTemp + 273)) + ((0.00044797 / 3) * Math.Pow((BathTemp + 273), 3))))
    End Function

    ''Private Function NewtonSolver(ByVal Funct As Func(Of Double, Double), ByVal Derivative As Func(Of Double, Double), ByVal Init As Double) As Double
    'Private Function NewtonSolver(ByVal Funct As Func(Of Double, Double), ByVal Derivative As Func(Of Double, Double), ByVal tbath As Decimal, ByVal Init As Double) As Double

    '    'Dim Xn As Double = tbath
    '    'Dim Iteration As Integer = 0
    '    'Dim err As Double = 9999
    '    'Dim xn1 As Double

    '    'Do While err > 0.001 And Iteration < 100

    '    '    xn1 = Xn - (Funct(Xn) / Derivative(Xn))
    '    '    err = Math.Abs(xn1 - Xn)
    '    '    Xn = xn1
    '    '    Iteration += 1
    '    'Loop

    '    Dim i As Integer
    '    Dim err As Double
    '    Dim xn As Double
    '    Dim xn1 As Double
    '    i = 0
    '    err = 9999
    '    Xn = x0
    '    While (err > e) And (i < n)
    '        xn1 = Xn - Fx(Xn, c) / dFx(Xn)
    '        err = Abs(xn1 - Xn)
    '        Xn = xn1
    'Wend
    'NewtonsMethod = Xn

    '    Return Xn
    'End Function
    Public Function NewtonsMethod(x0 As Double, c As Double, e As Double, n As Integer) As Double
        Dim i As Integer
        Dim err As Double
        Dim xn As Double
        Dim xn1 As Double
        i = 0
        err = 9999
        xn = x0
        While (err > e) And (i < n)
            xn1 = xn - Fx(xn, c) / dFx(xn)
            err = Math.Abs(xn1 - xn)
            xn = xn1
        End While
        NewtonsMethod = xn
    End Function
    Public Function Fx(x As Double, c As Double) As Double
        Fx = 504.2 * x + (-0.06545) * x * x - (-0.000005179) / x + (0.000149323) * x * x * x - c
    End Function
    Public Function dFx(x As Double) As Double
        dFx = 504.2 + (2 * -0.06545) * x + (-0.000005179) / (x * x) + (3 * 0.000149323) * x * x
    End Function

    ''declare constant
    ''Qingot = Q1+Q2+Q3
    ''Q1 = MZn* {(a1 * Tmelt+ b1*0.5*Tmelt^ 2-c1/Tmelt)-(a1*Tamb+b1*0.5*Tamb^2-c1/Tamb)}
    ''Q2 = MZn*Lmelt
    ''Q3 = MZn*Cp(Zn_l)*(Tbath - Tmelt)

    '' a1= 316.85 J/KgK, b1= 0.19116 J/KgK^2, c1=1.272*10^-6 J/Kg

    Public Function calc_Qingot(ByVal Mass_Ingot As Double, ByVal Tmelt As Double, ByVal Tamb As Decimal, ByVal Cp_Zn_l As Decimal, ByVal Tbath As Decimal, ByVal Lmelt As Decimal) As Double
        a1 = 316.85
        b1 = 0.19116
        c1 = 1.272 * 10 ^ -6

        Dim Q1, Q2, Q3, Q As Double

        Q1 = Mass_Ingot * ((a1 * Tmelt + b1 * 0.5 * Math.Pow(Tmelt, 2) - c1 / Tmelt) - (a1 * Tamb + b1 * 0.5 * Math.Pow(Tamb, 2) - c1 / Tamb))
        Q2 = Mass_Ingot * Lmelt
        Q3 = Mass_Ingot * Cp_Zn_l * (Tbath - Tmelt)
        Q = Q1 + Q2 + Q3
        Return Q
    End Function

    Public Function calc_Qloss(ByVal Qloss_avg As Double, ByVal duration As Decimal) As Double
        Return Qloss_avg * duration * 60 * 1000
    End Function

    'Public Function calc_Qind(Sum_t, Pi)
    '    Return Sum_t * Pi * 1000
    'End Function

    Public Function calc_CoilMass(ByVal Thickness As Double, ByVal Width As Double, ByVal length As Double, ByVal SteelDensity As Double) As Double ''thickness in mm,width in mm,length in m
        Return Thickness * Width * length * SteelDensity / 1000000
    End Function


End Class
