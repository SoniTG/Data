﻿Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.Data
Imports System.Data.OleDb
Imports System.Web.Script.Services
Imports IBAFILESLib
Imports System.IO
Imports System.Linq
Imports System.Collections.ObjectModel
Imports System.Data.SqlClient
Imports System.Web.Script.Serialization

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
' <System.Web.Script.Services.ScriptService()> _
<WebService(Namespace:="http://tempuri.org/")> _
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
<ScriptService()>
Public Class controller1
    Inherits System.Web.Services.WebService
    Dim objController As New Controller
    <WebMethod(EnableSession:=True)>
    Public Function selectedval(ByVal custid As String) As String
        Dim vala As String = custid
        Dim sep() As String = vala.Split(",")
        Dim pagename As String = sep(0)
        Dim id As String = sep(1)

        Dim tab As DataTable = objController.selected_data(pagename, id)
        Dim FMD_MAIN_DIV As String = tab.Rows(0)("FMD_MAIN_DIV")
        Dim FMD_SUB_DIV As String = tab.Rows(0)("FMD_SUB_DIV")
        Dim FMC_MAIN_HEADER As String = tab.Rows(0)("FMC_MAIN_HEADER")
        Dim FMC_CHILD_HEADER As String = tab.Rows(0)("FMC_CHILD_HEADER")
        Dim FMC_PAGENAME As String = tab.Rows(0)("FMC_PAGENAME")
        Dim FMD_DEFAULT_PAGE As String = tab.Rows(0)("FMD_DEFAULT_PAGE")
        Dim FMD_SUB_DIV_ID As String = tab.Rows(0)("FMD_SUB_DIV_ID")
        If FMD_MAIN_DIV = "CRM" Then
            Try
                System.Web.HttpContext.Current.Session("SelectVal") = Convert.ToString(FMD_SUB_DIV)
                Dim val As Boolean = False
                'Dim dt As DataTable = objController.GetRequiredParameters("CRM", ddlcrmsubcat.SelectedValue)
                Dim dt As DataTable
                'If  System.Web.HttpContext.Current.Session("SelectVal") <> "CGL" Then
                '    dt = objController.GetRequiredParameters("CRM", "3")
                'Else
                dt = objController.GetRequiredParameters("CRM", FMD_SUB_DIV_ID)
                'End If

                If dt.Rows.Count > 0 Then
                    System.Web.HttpContext.Current.Session("ChartDetails") = dt
                    System.Web.HttpContext.Current.Session("TableName") = dt.Rows(0)("FMD_TABLE_NAME")
                    System.Web.HttpContext.Current.Session("DateColumn") = dt.Rows(0)("FMD_DATE_COLUMN")
                    ' System.Web.HttpContext.Current.Session("ChartName") = dt.Rows(0)(1)
                    ' System.Web.HttpContext.Current.Session("ChartType") = dt.Rows(0)(2)
                    ' System.Web.HttpContext.Current.Session("XValue") = dt.Rows(0)(3)
                    System.Web.HttpContext.Current.Session("XValueColumn") = dt.Rows(0)("FHC_PARAM1")
                    System.Web.HttpContext.Current.Session("YValueColumn") = dt.Rows(0)("FHC_PARAM2")
                    System.Web.HttpContext.Current.Session("DefaultPage") = dt.Rows(0)("FMD_DEFAULT_PAGE")
                    System.Web.HttpContext.Current.Session("DefaultColourCol") = dt.Rows(0)("FMD_DEFAULT_COLOUR_COL")
                    val = True
                End If
                'Dim dt1 As DataTable = objController.GetMenuBarHierarchy(ddlcrmsubcat.SelectedValue)
                Dim dt1 As DataTable
                'If  System.Web.HttpContext.Current.Session("SelectVal") <> "CGL" Then
                '    dt1 = objController.GetMenuBarHierarchy("3")
                'Else
                dt1 = objController.GetMenuBarHierarchy(FMD_SUB_DIV_ID)
                'End If

                If dt1.Rows.Count > 0 Then
                    System.Web.HttpContext.Current.Session("SubDivId") = dt1.Rows(0)(0)
                    System.Web.HttpContext.Current.Session("MainHeader") = dt1.Rows(0)(1)
                    System.Web.HttpContext.Current.Session("ChildHeader") = dt1.Rows(0)(2)
                    System.Web.HttpContext.Current.Session("PageName") = dt1.Rows(0)(3)
                    val = True
                Else
                    val = False
                End If
                If val Then
                    System.Web.HttpContext.Current.Session("LoginTime") = Now.ToString("dd-MMM-yyyy HH:mm:ss")

                    System.Web.HttpContext.Current.Session("Department") = FMD_SUB_DIV
                    Return FMC_PAGENAME
                    'Response.Redirect("Default.aspx")
                End If


            Catch ex As Exception
                Throw ex
                'objController.LogIssue( System.Web.HttpContext.Current.Session("username"), ex.ToString(), System.IO.Path.GetFileName(Request.Path))
                'UserMsgBoxError("Error has been logged. Please contact solution provider.")
            End Try

        ElseIf FMD_MAIN_DIV = "HSM" Then

            Try

                System.Web.HttpContext.Current.Session("SelectVal") = FMD_SUB_DIV
                Dim val As Boolean = False
                'Dim dt As DataTable = objController.GetRequiredParameters("CRM", ddlcrmsubcat.SelectedValue)
                Dim dt As DataTable
                'If  System.Web.HttpContext.Current.Session("SelectVal") <> "CGL" Then
                '    dt = objController.GetRequiredParameters("CRM", "3")
                'Else
                dt = objController.GetRequiredParameters("HSM", FMD_SUB_DIV_ID)
                'End If

                If dt.Rows.Count > 0 Then
                    System.Web.HttpContext.Current.Session("ChartDetails") = dt
                    System.Web.HttpContext.Current.Session("TableName") = dt.Rows(0)("FMD_TABLE_NAME")
                    System.Web.HttpContext.Current.Session("DateColumn") = dt.Rows(0)("FMD_DATE_COLUMN")
                    ' System.Web.HttpContext.Current.Session("ChartName") = dt.Rows(0)(1)
                    ' System.Web.HttpContext.Current.Session("ChartType") = dt.Rows(0)(2)
                    ' System.Web.HttpContext.Current.Session("XValue") = dt.Rows(0)(3)
                    System.Web.HttpContext.Current.Session("XValueColumn") = dt.Rows(0)("FHC_PARAM1")
                    System.Web.HttpContext.Current.Session("YValueColumn") = dt.Rows(0)("FHC_PARAM2")
                    System.Web.HttpContext.Current.Session("DefaultPage") = dt.Rows(0)("FMD_DEFAULT_PAGE")
                    System.Web.HttpContext.Current.Session("DefaultColourCol") = dt.Rows(0)("FMD_DEFAULT_COLOUR_COL")
                    val = True
                End If
                'Dim dt1 As DataTable = objController.GetMenuBarHierarchy(ddlcrmsubcat.SelectedValue)
                Dim dt1 As DataTable
                'If  System.Web.HttpContext.Current.Session("SelectVal") <> "CGL" Then
                '    dt1 = objController.GetMenuBarHierarchy("3")
                'Else
                dt1 = objController.GetMenuBarHierarchy(FMD_SUB_DIV_ID)
                'End If

                If dt1.Rows.Count > 0 Then
                    System.Web.HttpContext.Current.Session("SubDivId") = dt1.Rows(0)(0)
                    System.Web.HttpContext.Current.Session("MainHeader") = dt1.Rows(0)(1)
                    System.Web.HttpContext.Current.Session("ChildHeader") = dt1.Rows(0)(2)
                    System.Web.HttpContext.Current.Session("PageName") = dt1.Rows(0)(3)
                    val = True
                Else
                    val = False
                End If
                If val Then
                    System.Web.HttpContext.Current.Session("LoginTime") = Now.ToString("dd-MMM-yyyy HH:mm:ss")
                    System.Web.HttpContext.Current.Session("Department") = FMD_SUB_DIV
                    Return FMC_PAGENAME
                    'Response.Redirect("Default.aspx")
                End If

            Catch ex As Exception
                'objController.LogIssue( System.Web.HttpContext.Current.Session("username"), ex.ToString(), System.IO.Path.GetFileName(Request.Path))
                ' UserMsgBoxError("Error has been logged. Please contact solution provider.")
            End Try


        ElseIf FMD_MAIN_DIV = "LD2" Then

            Try

                System.Web.HttpContext.Current.Session("SelectVal") = FMD_SUB_DIV
                Dim val As Boolean = False
                'Dim dt As DataTable = objController.GetRequiredParameters("CRM", ddlcrmsubcat.SelectedValue)
                Dim dt As DataTable
                'If  System.Web.HttpContext.Current.Session("SelectVal") <> "CGL" Then
                '    dt = objController.GetRequiredParameters("CRM", "3")
                'Else
                dt = objController.GetRequiredParameters("LD2", FMD_SUB_DIV_ID)
                'End If

                If dt.Rows.Count > 0 Then
                    System.Web.HttpContext.Current.Session("ChartDetails") = dt
                    System.Web.HttpContext.Current.Session("TableName") = dt.Rows(0)("FMD_TABLE_NAME")
                    System.Web.HttpContext.Current.Session("DateColumn") = dt.Rows(0)("FMD_DATE_COLUMN")
                    ' System.Web.HttpContext.Current.Session("ChartName") = dt.Rows(0)(1)
                    ' System.Web.HttpContext.Current.Session("ChartType") = dt.Rows(0)(2)
                    ' System.Web.HttpContext.Current.Session("XValue") = dt.Rows(0)(3)
                    System.Web.HttpContext.Current.Session("XValueColumn") = dt.Rows(0)("FHC_PARAM1")
                    System.Web.HttpContext.Current.Session("YValueColumn") = dt.Rows(0)("FHC_PARAM2")
                    System.Web.HttpContext.Current.Session("DefaultPage") = dt.Rows(0)("FMD_DEFAULT_PAGE")
                    System.Web.HttpContext.Current.Session("DefaultColourCol") = dt.Rows(0)("FMD_DEFAULT_COLOUR_COL")
                    val = True
                End If
                'Dim dt1 As DataTable = objController.GetMenuBarHierarchy(ddlcrmsubcat.SelectedValue)
                Dim dt1 As DataTable
                'If  System.Web.HttpContext.Current.Session("SelectVal") <> "CGL" Then
                '    dt1 = objController.GetMenuBarHierarchy("3")
                'Else
                dt1 = objController.GetMenuBarHierarchy(FMD_SUB_DIV_ID)
                'End If

                If dt1.Rows.Count > 0 Then
                    System.Web.HttpContext.Current.Session("SubDivId") = dt1.Rows(0)(0)
                    System.Web.HttpContext.Current.Session("MainHeader") = dt1.Rows(0)(1)
                    System.Web.HttpContext.Current.Session("ChildHeader") = dt1.Rows(0)(2)
                    System.Web.HttpContext.Current.Session("PageName") = dt1.Rows(0)(3)
                    val = True
                Else
                    val = False
                End If
                If val Then
                    System.Web.HttpContext.Current.Session("LoginTime") = Now.ToString("dd-MMM-yyyy HH:mm:ss")
                    Return FMC_PAGENAME
                    'Response.Redirect("Default.aspx")
                End If

            Catch ex As Exception
                'objController.LogIssue( System.Web.HttpContext.Current.Session("username"), ex.ToString(), System.IO.Path.GetFileName(Request.Path))
                'UserMsgBoxError("Error has been logged. Please contact solution provider.")
            End Try

        ElseIf FMD_MAIN_DIV = "LD3" Then

            Try

                System.Web.HttpContext.Current.Session("SelectVal") = FMD_SUB_DIV
                Dim val As Boolean = False
                Dim dt As DataTable = objController.GetRequiredParameters("LD3", FMD_SUB_DIV_ID)
                If dt.Rows.Count > 0 Then
                    System.Web.HttpContext.Current.Session("ChartDetails") = dt
                    System.Web.HttpContext.Current.Session("TableName") = dt.Rows(0)("FMD_TABLE_NAME")
                    System.Web.HttpContext.Current.Session("DateColumn") = dt.Rows(0)("FMD_DATE_COLUMN")
                    System.Web.HttpContext.Current.Session("XValueColumn") = dt.Rows(0)("FHC_PARAM1")
                    System.Web.HttpContext.Current.Session("YValueColumn") = dt.Rows(0)("FHC_PARAM2")
                    System.Web.HttpContext.Current.Session("DefaultPage") = dt.Rows(0)("FMD_DEFAULT_PAGE")
                    System.Web.HttpContext.Current.Session("DefaultColourCol") = dt.Rows(0)("FMD_DEFAULT_COLOUR_COL")
                    val = True
                End If
                Dim dt1 As DataTable = objController.GetMenuBarHierarchy(FMD_SUB_DIV_ID)
                If dt1.Rows.Count > 0 Then
                    System.Web.HttpContext.Current.Session("SubDivId") = dt1.Rows(0)(0)
                    System.Web.HttpContext.Current.Session("MainHeader") = dt1.Rows(0)(1)
                    System.Web.HttpContext.Current.Session("ChildHeader") = dt1.Rows(0)(2)
                    System.Web.HttpContext.Current.Session("PageName") = dt1.Rows(0)(3)
                    val = True
                Else
                    val = False
                End If
                If val Then
                    System.Web.HttpContext.Current.Session("LoginTime") = Now.ToString("dd-MMM-yyyy HH:mm:ss")
                    System.Web.HttpContext.Current.Session("Department") = FMD_SUB_DIV
                    Return FMC_PAGENAME
                End If

            Catch ex As Exception
                'objController.LogIssue( System.Web.HttpContext.Current.Session("username"), ex.ToString(), System.IO.Path.GetFileName(Request.Path))
                'UserMsgBoxError("Error has been logged. Please contact solution provider.")
            End Try

        ElseIf FMD_MAIN_DIV = "RCL" Then
	ElseIf FMD_MAIN_DIV = "TSK" Then
            Try

                System.Web.HttpContext.Current.Session("SelectVal") = FMD_SUB_DIV
                Dim val As Boolean = False
                'Dim dt As DataTable = objController.GetRequiredParameters("CRM", ddlcrmsubcat.SelectedValue)
                Dim dt As DataTable

                'Dim dt1 As DataTable = objController.GetMenuBarHierarchy(ddlcrmsubcat.SelectedValue)
                Dim dt1 As DataTable
                'If  System.Web.HttpContext.Current.Session("SelectVal") <> "CGL" Then
                '    dt1 = objController.GetMenuBarHierarchy("3")
                'Else
                dt1 = objController.GetMenuBarHierarchy(FMD_SUB_DIV_ID)
                'End If

                If dt1.Rows.Count > 0 Then
                    System.Web.HttpContext.Current.Session("SubDivId") = dt1.Rows(0)(0)
                    System.Web.HttpContext.Current.Session("MainHeader") = dt1.Rows(0)(1)
                    System.Web.HttpContext.Current.Session("ChildHeader") = dt1.Rows(0)(2)
                    System.Web.HttpContext.Current.Session("PageName") = dt1.Rows(0)(3)
                    val = True
                Else
                    val = False
                End If
                If val Then
                    System.Web.HttpContext.Current.Session("LoginTime") = Now.ToString("dd-MMM-yyyy HH:mm:ss")
                    Return FMC_PAGENAME
                    'Response.Redirect("Default.aspx")
                End If

            Catch ex As Exception
                'objController.LogIssue( System.Web.HttpContext.Current.Session("username"), ex.ToString(), System.IO.Path.GetFileName(Request.Path))
                'UserMsgBoxError("Error has been logged. Please contact solution provider.")
            End Try
        End If
        Return FMC_PAGENAME

    End Function

    <WebMethod()>
    Public Sub FnPLTCMSubChart(ByVal subid As String)
        Dim maxValue As String = "0.0"
        Dim maxLimit As String = "0.0"
        Dim ret As String = "["
        Dim xaxis As String = "["
        ' Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString

        ' Changes in connection string by Ritika(MAMTA Ma'am)
        Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("CRM_EUIP").ConnectionString

        Using sqlCon = New SqlConnection(strConnectionString)
            Using sqlDa = New SqlDataAdapter("SELECT [PL_SL_NO],PL_MAX_LIMIT FROM [CRM_PLTCM_LIMITS] WHERE RTRIM(LTRIM([PL_ALIAS]))='" & subid.Trim & "';SELECT TOP 48 *  FROM [CRM_PLTCM_ENCODER_MAX] ORDER BY PEM_STARTTIME DESC", sqlCon)
                Dim ds As New DataSet
                sqlDa.Fill(ds)
                If ds.Tables(0).Rows.Count > 0 Then
                    Dim cnt As Integer = ds.Tables(0).Rows(0)(0)
                    maxLimit = ds.Tables(0).Rows(0)(1)
                    maxValue = maxLimit
                    For i As Integer = 0 To ds.Tables(1).Rows.Count - 1
                        If i > 0 Then
                            ret &= ","
                            xaxis &= ","
                        End If
                        Dim signalval As String = ""
                        If ds.Tables(1).Rows(i)("PEM_SPD_STDDEV_MAX").ToString.Contains(",") Then
                            signalval = ds.Tables(1).Rows(i)("PEM_SPD_STDDEV_MAX").ToString.Split(",")(cnt - 1)
                        Else
                            signalval = "0"
                        End If

                        ret &= signalval
                        If Convert.ToDouble(signalval) > maxValue Then maxValue = Convert.ToDouble(signalval)
                        xaxis &= "'" & CDate(ds.Tables(1).Rows(i)("PEM_STARTTIME")).ToString("MM-dd HH:mm") & "'"
                    Next
                End If
            End Using
        End Using
        ret &= "]"
        xaxis &= "]"
        Context.Response.Write(ret & "~" & xaxis & "~" & maxLimit & "~" & maxValue)
    End Sub
    <WebMethod()>
    Public Sub FnCGL2SubChart(ByVal subid As String)
        Dim maxValue As String = "0.0"
        Dim maxLimit As String = "0.0"
        Dim ret As String = "["
        Dim xaxis As String = "["
        'Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString

        ' Changes in connection string by Ritika(MAMTA Ma'am)
        Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("CRM_EUIP").ConnectionString


        Using sqlCon = New SqlConnection(strConnectionString)
            Using sqlDa = New SqlDataAdapter("SELECT [CL_SL_NO],CL_MAX_LIMIT FROM [CRM_CGL2_ENCODER_LIMITS] WHERE RTRIM(LTRIM([CL_ALIAS]))='" & subid.Trim & "';SELECT TOP 48 *  FROM [CRM_CGL2_ENCODER_MAX] ORDER BY CEM_STARTTIME DESC", sqlCon)
                Dim ds As New DataSet
                sqlDa.Fill(ds)
                If ds.Tables(0).Rows.Count > 0 Then
                    Dim cnt As Integer = ds.Tables(0).Rows(0)(0)
                    maxLimit = ds.Tables(0).Rows(0)(1)
                    maxValue = maxLimit
                    For i As Integer = 0 To ds.Tables(1).Rows.Count - 1
                        If i > 0 Then
                            ret &= ","
                            xaxis &= ","
                        End If
                        Dim signalval As String = "0"
                        Try
                            signalval = ds.Tables(1).Rows(i)("CEM_SPD_STDDEV_MAX").ToString.Split(",")(cnt - 1)
                        Catch ex As Exception

                        End Try

                        ret &= signalval
                        If Convert.ToDouble(signalval) > maxValue Then maxValue = Convert.ToDouble(signalval)
                        xaxis &= "'" & CDate(ds.Tables(1).Rows(i)("CEM_STARTTIME")).ToString("MM-dd HH:mm") & "'"
                    Next
                End If
            End Using
        End Using
        ret &= "]"
        xaxis &= "]"
        Context.Response.Write(ret & "~" & xaxis & "~" & maxLimit & "~" & maxValue)
    End Sub

    <WebMethod()>
    Public Sub FnGetPageHits()
        Dim count As Integer = 0
        Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString
        Using dt = New DataTable
            Using sqlCon = New SqlConnection(strConnectionString)
                Using sqlDa = New SqlDataAdapter("SELECT TIMESTAMP FROM PAGE_HIT_DTLS WHERE PAGE_NAME IN ('dashboardP.aspx','dashboardQ.aspx','lfcnalysis.aspx','slivernalysis.aspx','trendanalysis.aspx')", sqlCon)
                    sqlDa.Fill(dt)
                    count = IIf(dt.Rows.Count = 0, 0, dt.Rows.Count)
                End Using
            End Using
        End Using
        Context.Response.Write(count)
    End Sub

    <WebMethod()>
    Public Sub FnSavePageHits(ByVal LoginTime As String, ByVal PageName As String)
        Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString
        Using sqlCon = New SqlConnection(strConnectionString)
            Using sqlCmd = New SqlCommand("INSERT INTO PAGE_HIT_DTLS VALUES('" & PageName & "','" & LoginTime & "')", sqlCon)
                sqlCon.Open()
                sqlCmd.ExecuteNonQuery()
                sqlCmd.Clone()
            End Using
        End Using
    End Sub

    <WebMethod()>
    Public Sub FnPieCaster1(ByVal FromDate As String, ByVal ToDate As String)
        Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("IPQSDB").ConnectionString
        Using oleCon = New OleDbConnection(strConnectionString)
            Dim dtCaster1Data As New DataTable
            Using oleDa = New OleDbDataAdapter("SELECT CC_STEELGRADE2, COUNT(CC_STEELGRADE2) AS COUNT FROM CC_HEAT_MASTER INNER JOIN CCC_HEAT_RAW ON CC_HEAT_MASTER.PRODUCTION_KEY=CCC_HEAT_RAW.HEAT_ID_MSG6 WHERE DEVICE_KEY='11' AND TO_CHAR (DATETIME, 'YYYY-MM-DD HH24:MI:SS')>='" & FromDate & "' AND TO_CHAR (DATE_MSG6_CREATE, 'YYYY-MM-DD HH24:MI:SS')<='" & ToDate & "' GROUP BY CC_STEELGRADE2", oleCon)
                oleDa.Fill(dtCaster1Data)
            End Using
            'Making Caster 1 data points.
            Dim caster1DataPoints As String = ""
            For i As Integer = 0 To dtCaster1Data.Rows.Count - 1
                If i > 0 Then
                    caster1DataPoints &= ", "
                End If
                caster1DataPoints &= "{value: " & dtCaster1Data.Rows(i)("COUNT") & ", name: '" & dtCaster1Data.Rows(i)("CC_STEELGRADE2") & "'}"
            Next
            Dim js As String = "<script id='scriptCaster1Pie' language='javascript' type='text/javascript'>" & vbCrLf & _
                                        "var chart = document.getElementById('container1');" & vbCrLf & _
                                        "var myChart = echarts.init(chart);" & vbCrLf & _
                                        "option = {" & vbCrLf & _
                                        "    title: {" & vbCrLf & _
                                        "       text: ''," & vbCrLf & _
                                        "       subtext: ''," & vbCrLf & _
                                        "       x: 'center'" & vbCrLf & _
                                        "    }," & vbCrLf & _
                                        "    tooltip: {" & vbCrLf & _
                                        "        trigger: 'item'," & vbCrLf & _
                                        "        formatter: '{a} <br/>{b} : {c} ({d}%)'" & vbCrLf & _
                                        "    }," & vbCrLf & _
                                        "    legend: {" & vbCrLf & _
                                        "        show: false," & vbCrLf & _
                                        "        x: 'center'," & vbCrLf & _
                                        "        y: 'bottom'," & vbCrLf & _
                                        "        data: ['rose1', 'rose2', 'rose3', 'rose4', 'rose5', 'rose6', 'rose7', 'rose8', 'rose9', 'rose10', 'rose11', 'rose12', 'rose13', 'rose14', 'rose15', 'rose16']" & vbCrLf & _
                                        "    }," & vbCrLf & _
                                        "    toolbox: {" & vbCrLf & _
                                        "        show: true," & vbCrLf & _
                                        "        feature: {" & vbCrLf & _
                                        "            mark: {" & vbCrLf & _
                                        "                show: false" & vbCrLf & _
                                        "            }," & vbCrLf & _
                                        "            dataView: {" & vbCrLf & _
                                        "                show: true," & vbCrLf & _
                                        "                readOnly: false" & vbCrLf & _
                                        "            }," & vbCrLf & _
                                        "            magicType: {" & vbCrLf & _
                                        "                show: false," & vbCrLf & _
                                        "                type: ['pie', 'funnel']" & vbCrLf & _
                                        "            }," & vbCrLf & _
                                        "            restore: {" & vbCrLf & _
                                        "                show: false" & vbCrLf & _
                                        "            }," & vbCrLf & _
                                        "            saveAsImage: {" & vbCrLf & _
                                        "                show: true" & vbCrLf & _
                                        "            }" & vbCrLf & _
                                        "        }" & vbCrLf & _
                                        "    }," & vbCrLf & _
                                        "    calculable: true," & vbCrLf & _
                                        "    series: [{" & vbCrLf & _
                                        "       name: 'CASTER 1'," & vbCrLf & _
                                        "       type: 'pie'," & vbCrLf & _
                                        "            radius: [20, 160]," & vbCrLf & _
                                        "            center: ['50%', '50%']," & vbCrLf & _
                                        "            roseType: 'radius'," & vbCrLf & _
                                        "            width: '40%', // for funnel" & vbCrLf & _
                                        "            max: 40, // for funnel" & vbCrLf & _
                                        "            itemStyle: {" & vbCrLf & _
                                        "                normal: {" & vbCrLf & _
                                        "                    label: {" & vbCrLf & _
                                        "                        show: true" & vbCrLf & _
                                        "                    }," & vbCrLf & _
                                        "                    labelLine: {" & vbCrLf & _
                                        "                        show: true" & vbCrLf & _
                                        "                    }" & vbCrLf & _
                                        "                }," & vbCrLf & _
                                        "                emphasis: {" & vbCrLf & _
                                        "                    label: {" & vbCrLf & _
                                        "                        show: false" & vbCrLf & _
                                        "                    }," & vbCrLf & _
                                        "                    labelLine: {" & vbCrLf & _
                                        "                        show: false" & vbCrLf & _
                                        "                    }" & vbCrLf & _
                                        "                }" & vbCrLf & _
                                        "            }," & vbCrLf & _
                                        "            data: [" & caster1DataPoints & "]" & vbCrLf & _
                                        "        }" & vbCrLf & _
                                        "    ]" & vbCrLf & _
                                        "};" & vbCrLf & _
                                        "myChart.setOption(option);" & vbCrLf & _
                                        "</script>"
            Context.Response.Write(js)
        End Using
    End Sub

    <WebMethod()>
    Public Sub FnPieCaster2(ByVal FromDate As String, ByVal ToDate As String)
        Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("IPQSDB").ConnectionString
        Using oleCon = New OleDbConnection(strConnectionString)
            Dim dtCaster2Data As New DataTable
            Using oleDa = New OleDbDataAdapter("SELECT CC_STEELGRADE2, COUNT(CC_STEELGRADE2) AS COUNT FROM CC_HEAT_MASTER INNER JOIN CCC_HEAT_RAW ON CC_HEAT_MASTER.PRODUCTION_KEY=CCC_HEAT_RAW.HEAT_ID_MSG6 WHERE DEVICE_KEY='12' AND TO_CHAR (DATETIME, 'YYYY-MM-DD HH24:MI:SS')>='" & FromDate & "' AND TO_CHAR (DATE_MSG6_CREATE, 'YYYY-MM-DD HH24:MI:SS')<='" & ToDate & "' GROUP BY CC_STEELGRADE2", oleCon)
                oleDa.Fill(dtCaster2Data)
            End Using
            'Making Caster 2 data points.
            Dim caster2DataPoints As String = ""
            For i As Integer = 0 To dtCaster2Data.Rows.Count - 1
                If i > 0 Then
                    caster2DataPoints &= ", "
                End If
                caster2DataPoints &= "{value: " & dtCaster2Data.Rows(i)("COUNT") & ", name: '" & dtCaster2Data.Rows(i)("CC_STEELGRADE2") & "'}"
            Next
            Dim js As String = "<script id='scriptCaster2Pie' language='javascript' type='text/javascript'>" & vbCrLf & _
                                        "var chart = document.getElementById('container2');" & vbCrLf & _
                                        "var myChart = echarts.init(chart);" & vbCrLf & _
                                        "option = {" & vbCrLf & _
                                        "    title: {" & vbCrLf & _
                                        "    text: ''," & vbCrLf & _
                                        "    subtext: ''," & vbCrLf & _
                                        "    x: 'center'" & vbCrLf & _
                                        "    }," & vbCrLf & _
                                        "    tooltip: {" & vbCrLf & _
                                        "        trigger: 'item'," & vbCrLf & _
                                        "        formatter: '{a} <br/>{b} : {c} ({d}%)'" & vbCrLf & _
                                        "    }," & vbCrLf & _
                                        "    legend: {" & vbCrLf & _
                                        "        show: false," & vbCrLf & _
                                        "x: 'center'," & vbCrLf & _
                                        "y: 'bottom'," & vbCrLf & _
                                        "        data: ['rose1', 'rose2', 'rose3', 'rose4', 'rose5', 'rose6', 'rose7', 'rose8', 'rose9', 'rose10', 'rose11', 'rose12', 'rose13', 'rose14', 'rose15', 'rose16']" & vbCrLf & _
                                        "    }," & vbCrLf & _
                                        "    toolbox: {" & vbCrLf & _
                                        "        show: true," & vbCrLf & _
                                        "        feature: {" & vbCrLf & _
                                        "            mark: {" & vbCrLf & _
                                        "                show: false" & vbCrLf & _
                                        "            }," & vbCrLf & _
                                        "            dataView: {" & vbCrLf & _
                                        "                show: true," & vbCrLf & _
                                        "                readOnly: false" & vbCrLf & _
                                        "            }," & vbCrLf & _
                                        "            magicType: {" & vbCrLf & _
                                        "                show: false," & vbCrLf & _
                                        "                type: ['pie', 'funnel']" & vbCrLf & _
                                        "            }," & vbCrLf & _
                                        "            restore: {" & vbCrLf & _
                                        "                show: false" & vbCrLf & _
                                        "            }," & vbCrLf & _
                                        "            saveAsImage: {" & vbCrLf & _
                                        "                show: true" & vbCrLf & _
                                        "            }" & vbCrLf & _
                                        "        }" & vbCrLf & _
                                        "    }," & vbCrLf & _
                                        "    calculable: true," & vbCrLf & _
                                        "    series: [{" & vbCrLf & _
                                        "name: 'CASTER 2'," & vbCrLf & _
                                        "type: 'pie'," & vbCrLf & _
                                        "            radius: [20, 160]," & vbCrLf & _
                                        "            center: ['50%', '50%']," & vbCrLf & _
                                        "roseType: 'area'," & vbCrLf & _
                                        "x: '50%', // for funnel" & vbCrLf & _
                                        "            max: 40, // for funnel" & vbCrLf & _
                                        "sort: 'ascending', // for funnel          " & vbCrLf & _
                                        "            data: [" & caster2DataPoints & "]" & vbCrLf & _
                                        "        }" & vbCrLf & _
                                        "    ]" & vbCrLf & _
                                        "};" & vbCrLf & _
                                        "myChart.setOption(option);" & vbCrLf & _
                                        "</script>"
            Context.Response.Write(js)
        End Using
    End Sub

    Function GetRawData(ByVal FromDate As String, ByVal ToDate As String, ByVal Caster As String, ByVal ColumnName As String) As DataTable
        Dim dt As New DataTable
        Try
            Using sqlCon = New SqlConnection(ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString)
                'Dim c As String = IIf(Caster = "11", "1", "2")
                Using sqlAdapter As New SqlDataAdapter("SELECT " & ColumnName & ", TID_TIMESTAMP FROM TSCR_IBA_DATA WHERE " & ColumnName & " > 0 AND TID_CASTER='" & Caster & "' AND TID_TIMESTAMP BETWEEN '" & CDate(FromDate).ToString("yyyy-MM-dd HH:mm:ss") & "' AND '" & CDate(ToDate).ToString("yyyy-MM-dd HH:mm:ss") & "' ORDER BY TID_TIMESTAMP", sqlCon)
                    sqlAdapter.Fill(dt)
                End Using
            End Using
        Catch ex As Exception

        End Try
        Return dt
    End Function

    Function GetDataFor(ByVal FromDate As String, ByVal ToDate As String, ByVal Caster As String, ByVal ColumnName As String) As Hashtable
        Dim hTbl As New Hashtable
        Try
            Using sqlCon = New SqlConnection(ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString)
                Dim c As String = IIf(Caster = "11", "1", "2")
                Using sqlAdapter As New SqlDataAdapter("SELECT " & ColumnName & " FROM TSCR_IBA_DATA WHERE " & ColumnName & ">0 AND TID_CASTER='" & c & "' AND TID_TIMESTAMP BETWEEN '" & CDate(FromDate).ToString("yyyy-MM-dd HH:mm:ss") & "' AND '" & CDate(ToDate).ToString("yyyy-MM-dd HH:mm:ss") & "' ORDER BY TID_TIMESTAMP", sqlCon)
                    Using dt As New DataTable
                        sqlAdapter.Fill(dt)
                        If dt.Rows.Count > 0 Then
                            Dim arralldata(dt.Rows.Count - 1) As Decimal
                            For i As Short = 0 To dt.Rows.Count - 1
                                arralldata(i) = dt.Rows(i)(ColumnName)
                            Next
                            If arralldata.Length > 0 Then
                                Dim arr() = arralldata
                                Dim arrTemp() As Decimal = New BoxPlotSeriesMgr().GetValuesForBoxPlot(arr)
                                hTbl.Add("lq", arrTemp(4))
                                hTbl.Add("max", arrTemp(1))
                                hTbl.Add("lb", arrTemp(8))
                                hTbl.Add("uq", arrTemp(5))
                                hTbl.Add("avg", arrTemp(2))
                                Dim arrOutliers As New ArrayList
                                For i = 0 To arralldata.Length - 1
                                    'If arralldata(i) > 0 Then
                                    If arrTemp(8) >= arralldata(i) Then
                                        arrOutliers.Add(arralldata(i))
                                    ElseIf arrTemp(9) <= arralldata(i) Then
                                        arrOutliers.Add(arralldata(i))
                                    End If
                                    'End If
                                Next
                                hTbl.Add("outliers", arrOutliers)
                            End If
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception

        End Try
        Return hTbl
    End Function

    <WebMethod()>
    Public Sub FnBoxPlot(ByVal FromDate As String, ByVal ToDate As String, ByVal ContainerName As String, ByVal ScriptName As String, ByVal Caster As String, ByVal PlotName As String, ByVal YValueColumn As String)
        Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString
        Using sqlCon = New SqlConnection(strConnectionString)
            Dim arrListAllGrades As New ArrayList
            Dim dt As New DataTable
            Using sqlDa = New SqlDataAdapter("SELECT CC_STEELGRADE2, PRODUCTION_START_DATETIME, PRODUCTION_END_DATETIME, DEVICE_KEY FROM TSCR_CC_HEAT_MASTER INNER JOIN TSCR_CCC_HEAT_RAW ON TSCR_CC_HEAT_MASTER.PRODUCTION_KEY=TSCR_CCC_HEAT_RAW.HEAT_ID_MSG6 WHERE DEVICE_KEY='" & Caster & "' AND DATETIME >= '" & FromDate & "' AND DATE_MSG6_CREATE <= '" & ToDate & "' ORDER BY CC_STEELGRADE2, PRODUCTION_START_DATETIME", sqlCon)
                sqlDa.Fill(dt)
            End Using
            Dim dtGradewiseData As New DataTable
            dtGradewiseData.Columns.Add("grade")
            dtGradewiseData.Columns.Add("start")
            dtGradewiseData.Columns.Add("end")
            Dim start As String = ""
            Dim lastgrade As String = ""
            For i As Int16 = 0 To dt.Rows.Count - 1
                If start = "" Then
                    start = dt.Rows(i)("PRODUCTION_START_DATETIME")
                End If
                If lastgrade = "" Then
                    lastgrade = dt.Rows(i)("CC_STEELGRADE2")
                End If
                If i < dt.Rows.Count - 1 Then
                    If dt.Rows(i + 1)("CC_STEELGRADE2") <> dt.Rows(i)("CC_STEELGRADE2") Then
                        Dim dr As DataRow = dtGradewiseData.NewRow
                        dr("grade") = dt.Rows(i)("CC_STEELGRADE2")
                        dr("start") = start
                        start = ""
                        dr("end") = dt.Rows(i)("PRODUCTION_END_DATETIME")
                        dtGradewiseData.Rows.Add(dr)
                    Else
                        Dim span As TimeSpan = CDate(dt.Rows(i + 1)("PRODUCTION_START_DATETIME")).Subtract(CDate(dt.Rows(i)("PRODUCTION_START_DATETIME")))
                        If span.TotalMinutes > 90 Then
                            Dim dr As DataRow = dtGradewiseData.NewRow
                            dr("grade") = dt.Rows(i)("CC_STEELGRADE2")
                            dr("start") = start
                            start = ""
                            dr("end") = dt.Rows(i)("PRODUCTION_END_DATETIME")
                            dtGradewiseData.Rows.Add(dr)
                        End If
                    End If
                    lastgrade = ""
                ElseIf i = dt.Rows.Count - 1 Then
                    Dim dr As DataRow = dtGradewiseData.NewRow
                    dr("grade") = lastgrade
                    dr("start") = start
                    start = ""
                    lastgrade = ""
                    dr("end") = dt.Rows(i)("PRODUCTION_END_DATETIME")
                    dtGradewiseData.Rows.Add(dr)
                End If
            Next

            Dim arrDistinctGrade() As String = (From row In dtGradewiseData Select col = row.Field(Of String)("grade") Distinct).ToArray
            dtGradewiseData.Columns.Add("lowerQ")
            dtGradewiseData.Columns.Add("max")
            dtGradewiseData.Columns.Add("lowerB")
            dtGradewiseData.Columns.Add("upperQ")
            dtGradewiseData.Columns.Add("avg")
            'Dim arrAllOutliers As New ArrayList

            'Dim htOutliers As New Hashtable
            Dim dataPoints As String = "var boxplot = ["
            Dim outlierPoints As String = "var outlier = ["
            Dim averagePoints As String = "var average = ["
            For i As Int16 = 0 To dtGradewiseData.Rows.Count - 1
                Dim ht As Hashtable = GetDataFor(dtGradewiseData.Rows(i)("start"), dtGradewiseData.Rows(i)("end"), Caster, YValueColumn)
                If ht.Count > 0 Then
                    dtGradewiseData.Rows(i)("lowerQ") = ht("lq")
                    dtGradewiseData.Rows(i)("max") = ht("max")
                    dtGradewiseData.Rows(i)("lowerB") = ht("lb")
                    dtGradewiseData.Rows(i)("upperQ") = ht("uq")
                    dtGradewiseData.Rows(i)("avg") = Math.Round(CDec(ht("avg")), 2, MidpointRounding.AwayFromZero)
                    If i > 0 Then
                        dataPoints &= ", "
                        averagePoints &= ", "
                    End If
                    dataPoints &= "['" & arrDistinctGrade(i) & "', " & ht("lq") & ", " & ht("max") & ", " & ht("lb") & ", " & ht("uq") & "]"
                    averagePoints &= "['" & arrDistinctGrade(i) & "', " & Math.Round(CDec(ht("avg")), 2, MidpointRounding.AwayFromZero) & "]"
                    Dim arrOutliers As ArrayList = ht("outliers")
                    For j As Short = 0 To arrOutliers.Count - 1
                        If j > 0 Then
                            outlierPoints &= ", "
                        End If
                        outlierPoints &= "['" & dtGradewiseData.Rows(i)("grade") & "', " & arrOutliers(j) & "]"
                    Next
                End If
            Next
            dataPoints &= "];"
            outlierPoints &= "];"
            averagePoints &= "];"

            Dim boxPlotProperties As String = "{renderer: $.jqplot.OHLCRenderer, rendererOptions: {candleStick: true, lineWidth: 2, bodyWidth: 40, wickColor: '#60A62E', upBodyColor: '#00008B', downBodyColor: '#00008B'}, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 5,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td style=""display: none;"">Grade:</td><td style=""display: none;"">%s</td></tr> \ <tr><td>Lower Quartile </td><td>:</td><td>%#.2f</td></tr> \ <tr><td>Maximum </td><td>:</td><td>%#.2f</td></tr> \ <tr><td>Minimum </td><td>:</td><td>%#.2f</td></tr> \ <tr><td>Upper Quartile </td><td>:</td><td>%#.2f</td></tr></table>'}}"
            Dim outlierProperties As String = "{showLine:false, markerOptions: {style: 'circle', shadow: false, color: '#4BB2C5'}, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 1,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td style=""display:none;"">%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
            Dim averageProperties As String = "{lineWidth:0, color: '#006400', showLine: false, showTooltip: false, showMarker:true, markerOptions: { style: 'filledCircle' }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td style=""display: none;"">%s</td><td>Average</td><td>:</td><td>%s</td></tr></table>'}}"
            Dim tickAngle As String = IIf(dtGradewiseData.Rows.Count > 8, ", angle: -30", "")
            Dim YAxisLabel As String = ""
            If YValueColumn = "TID_AVERAGE_SPEED" Then
                YAxisLabel = "Cast Speed (m/min)"
            ElseIf YValueColumn = "TID_MLF" Then
                YAxisLabel = "Mould Level"
            End If

            Dim js As String = "<script id='" & ScriptName & "' language='javascript' type='text/javascript'>" & vbCrLf & _
                               "$.jqplot.config.enablePlugins = true;" & vbCrLf & _
                               dataPoints & vbCrLf & outlierPoints & vbCrLf & averagePoints & vbCrLf & _
                               PlotName & " = $.jqplot('" & ContainerName & "', [boxplot,outlier,average],{" & vbCrLf & _
                               "axesDefaults: { tickRenderer: $.jqplot.CanvasAxisTickRenderer, tickOptions: {fontSize: '8pt'" & tickAngle & "}}," & vbCrLf & _
                               "axes: { autoscale: false," & vbCrLf & _
                               "xaxis: {" & vbCrLf & _
                               "renderer:$.jqplot.CategoryAxisRenderer," & vbCrLf & _
                               "label: 'Grades'," & vbCrLf & _
                               "}," & vbCrLf & _
                               "yaxis: {" & vbCrLf & _
                               "" & vbCrLf & _
                               "label: '" & YAxisLabel & "'," & vbCrLf & _
                               "labelRenderer: $.jqplot.CanvasAxisLabelRenderer," & vbCrLf & _
                               "tickOptions: { formatString: '%.2f' }" & vbCrLf & _
                               "}," & vbCrLf & _
                               "}, animate: true, " & vbCrLf & _
                               "title: ''," & vbCrLf & _
                               "series: [" & boxPlotProperties & "," & outlierProperties & "," & averageProperties & "]," & vbCrLf & _
                               "seriesDefaults: {pointLabels: { show:false }}," & vbCrLf & _
                               "seriesColors: ['#00008B', '#4BB2C5','#006400','#FF0000','#D220D8','#D220D8']," & vbCrLf & _
                               "cursor: {" & vbCrLf & _
                               "zoom: false," & vbCrLf & _
                               "}," & vbCrLf & _
                               "noDataIndicator: { show: true, indicator: 'Sorry, no data found.' }," & vbCrLf & _
                               "//legend:{show:true,placement: 'outsideGrid',rendererOptions: {numberRows: 1, marginTop: 10 }, location: 's', labels: ['Actual','Outliers','Average'], renderer: $.jqplot.EnhancedLegendRenderer }," & vbCrLf & _
                               "grid: {backgroundColor: 'rgb(255,255,255)'}" & vbCrLf & _
                               "});" & vbCrLf & _
                               "</script>"
            Context.Response.Write(js)
        End Using
    End Sub

    <WebMethod()>
    Public Sub FnBoxPlotData(ByVal FromDate As String, ByVal ToDate As String, ByVal Caster As String, ByVal YValueColumn As String)
        Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString
        Using sqlCon = New SqlConnection(strConnectionString)
            Dim arrListAllGrades As New ArrayList
            Dim dt As New DataTable
            Using sqlDa = New SqlDataAdapter("SELECT CC_STEELGRADE2, PRODUCTION_START_DATETIME, PRODUCTION_END_DATETIME, DEVICE_KEY FROM TSCR_CC_HEAT_MASTER INNER JOIN TSCR_CCC_HEAT_RAW ON TSCR_CC_HEAT_MASTER.PRODUCTION_KEY=TSCR_CCC_HEAT_RAW.HEAT_ID_MSG6 WHERE DEVICE_KEY='" & Caster & "' AND DATETIME >= '" & FromDate & "' AND DATE_MSG6_CREATE <= '" & ToDate & "' ORDER BY CC_STEELGRADE2, PRODUCTION_START_DATETIME", sqlCon)
                sqlDa.Fill(dt)
            End Using
            Dim dtGradewiseData As New DataTable
            dtGradewiseData.Columns.Add("grade")
            dtGradewiseData.Columns.Add("start")
            dtGradewiseData.Columns.Add("end")
            Dim start As String = ""
            Dim lastgrade As String = ""
            For i As Int16 = 0 To dt.Rows.Count - 1
                If start = "" Then
                    start = dt.Rows(i)("PRODUCTION_START_DATETIME")
                End If
                If lastgrade = "" Then
                    lastgrade = dt.Rows(i)("CC_STEELGRADE2")
                End If
                If i < dt.Rows.Count - 1 Then
                    If dt.Rows(i + 1)("CC_STEELGRADE2") <> dt.Rows(i)("CC_STEELGRADE2") Then
                        Dim dr As DataRow = dtGradewiseData.NewRow
                        dr("grade") = dt.Rows(i)("CC_STEELGRADE2")
                        dr("start") = start
                        start = ""
                        dr("end") = dt.Rows(i)("PRODUCTION_END_DATETIME")
                        dtGradewiseData.Rows.Add(dr)
                    Else
                        Dim span As TimeSpan = CDate(dt.Rows(i + 1)("PRODUCTION_START_DATETIME")).Subtract(CDate(dt.Rows(i)("PRODUCTION_START_DATETIME")))
                        If span.TotalMinutes > 90 Then
                            Dim dr As DataRow = dtGradewiseData.NewRow
                            dr("grade") = dt.Rows(i)("CC_STEELGRADE2")
                            dr("start") = start
                            start = ""
                            dr("end") = dt.Rows(i)("PRODUCTION_END_DATETIME")
                            dtGradewiseData.Rows.Add(dr)
                        End If
                    End If
                    lastgrade = ""
                ElseIf i = dt.Rows.Count - 1 Then
                    Dim dr As DataRow = dtGradewiseData.NewRow
                    dr("grade") = lastgrade
                    dr("start") = start
                    start = ""
                    lastgrade = ""
                    dr("end") = dt.Rows(i)("PRODUCTION_END_DATETIME")
                    dtGradewiseData.Rows.Add(dr)
                End If
            Next
            Dim count As SByte = dtGradewiseData.Rows.Count
            Dim strGrades As String = dtGradewiseData.AsEnumerable().Select(Function(col) col.Field(Of Object)("grade")).Aggregate(Function(s1, s2) String.Concat(s1, ",", s2))
            Dim strRawData As String = ""
            For i As Int16 = 0 To dtGradewiseData.Rows.Count - 1
                If i > 0 Then
                    strRawData &= "@"
                End If
                strRawData &= String.Join(",", GetDataFor1(dtGradewiseData.Rows(i)("start"), dtGradewiseData.Rows(i)("end"), Caster, YValueColumn))
            Next
            Dim strAllData = count & "@" & strGrades & "@" & strRawData
            Context.Response.Write(strAllData)
        End Using
    End Sub

    Function GetDataFor1(ByVal FromDate As String, ByVal ToDate As String, ByVal Caster As String, ByVal ColumnName As String) As Decimal()
        Dim arr() As Decimal = {}
        Try
            Using sqlCon = New SqlConnection(ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString)
                Dim c As String = IIf(Caster = "11", "1", "2")
                Using sqlAdapter As New SqlDataAdapter("SELECT " & ColumnName & " FROM TSCR_IBA_DATA WHERE " & ColumnName & ">0 AND TID_CASTER='" & c & "' AND TID_TIMESTAMP BETWEEN '" & CDate(FromDate).ToString("yyyy-MM-dd HH:mm:ss") & "' AND '" & CDate(ToDate).ToString("yyyy-MM-dd HH:mm:ss") & "' ORDER BY TID_TIMESTAMP", sqlCon)
                    Using dt As New DataTable
                        sqlAdapter.Fill(dt)
                        If dt.Rows.Count > 0 Then
                            arr = (From val In dt.AsEnumerable() Select val.Field(Of Decimal)(ColumnName) Distinct).ToArray
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception

        End Try
        Return arr
    End Function

    <WebMethod()>
    Public Sub FnStdDevLineNew(ByVal FromDate As String, ByVal ToDate As String, ByVal ContainerName As String, ByVal ScriptName As String, ByVal Caster As String, ByVal PlotName As String, ByVal YValueColumn As String)
        Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString
        Dim strSeriesNames As String = ""
        Dim strRawSeriesNames As String = ""
        Dim strDataArrays As String = ""
        Dim strRawDataArrays As String = ""
        Dim strLegendLabels As String = ""
        Dim strSlabIdSeriesProperties As String = ""
        Dim strChartSeriesProperties As String = ""
        Dim strRawSeriesProperties As String = ""
        Dim seriesMax As Double = 0
        Dim strAllVerticalLines As String = ""
        Dim strAllVerticalLinesSeriesNames As String = ""
        Dim strDashedVerticalLine As String = ""
        Dim totalHeat As Short = 0
        Dim strNoDataAttribute As String = ""
        Dim HasAnyData As Boolean = False
        'Dim arrThickness As New ArrayList
        Using sqlCon = New SqlConnection(strConnectionString)
            Dim arrListAllGrades As New ArrayList
            Dim tblHeat As New DataTable
            Dim iCaster As String = IIf(Caster = "1", "11", "12")
            Using sqlDa = New SqlDataAdapter("SELECT HEAT_ID_MSG6 AS HEAT_ID,DATETIME AS START_TIME, DATE_MSG6_CREATE AS END_TIME, DEVICE_KEY FROM TSCR_CCC_HEAT_RAW INNER JOIN TSCR_CC_HEAT_MASTER ON TSCR_CCC_HEAT_RAW.HEAT_ID_MSG6=TSCR_CC_HEAT_MASTER.PRODUCTION_KEY WHERE DATETIME >= '" & FromDate & "' AND DATE_MSG6_CREATE <= '" & ToDate & "' AND DEVICE_KEY = '" & iCaster & "'", sqlCon)
                sqlDa.Fill(tblHeat)
            End Using
            totalHeat = tblHeat.Rows.Count
            If tblHeat.Rows.Count > 0 Then
                strLegendLabels = "'" & tblHeat.AsEnumerable().Select(Function(col) col.Field(Of String)("HEAT_ID")).Aggregate(Function(s1, s2) String.Concat(s1, "','", s2)) & "'"
            End If
            For i As Short = 0 To tblHeat.Rows.Count - 1
                If i > 0 Then
                    strChartSeriesProperties &= ","
                    strSeriesNames &= ","
                    strRawSeriesNames &= ","
                    strRawSeriesProperties &= ","
                End If
                strChartSeriesProperties &= "{showLine: true, yaxis:'y2axis', lineWidth: 2, pointLabels: { show:false }, showTooltip: false, showMarker:true, markerOptions: { style: 'filledCircle', size: 6 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td style=""display: none;"">%s</td><td>Standard Deviation</td><td>:</td><td>%s</td></tr></table>'}}"
                strRawSeriesProperties &= "{showLine: true, lineWidth: 2, pointLabels: { show:false }, showTooltip: false, showMarker:false, markerOptions: { style: 'filledCircle', size: 6 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 1,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>%s</td><td>,</td><td>&nbsp;</td><td>%s</td></tr></table>'}}"
                Dim dtStart As DateTime = CDate(tblHeat.Rows(i)("START_TIME")).AddMinutes(-10) 'Subracting 10 minutes, as discussed with Arup.
                Dim dtEnd As DateTime = tblHeat.Rows(i)("END_TIME")
                iCaster = IIf(Caster = "1", "13", "14")
                Dim tblSlab As New DataTable
                Using sqlDa = New SqlDataAdapter("SELECT TSM_SLAB_ID AS SLAB_ID,TSM_PROD_START AS PROD_START,TSM_PROD_END AS PROD_END,TSR_SLAB_THICKNESS AS THICKNESS FROM TSCR_SLAB_MASTER INNER JOIN TSCR_SLAB_RAW ON TSCR_SLAB_MASTER.TSM_SLAB_ID=TSCR_SLAB_RAW.TSR_SLAB_ID WHERE TSM_PROD_START >= '" & dtStart.ToString("yyyy-MM-dd HH:mm:ss") & "' AND TSM_PROD_END <= '" & dtEnd.ToString("yyyy-MM-dd HH:mm:ss") & "' AND TSM_DEVICE_KEY='" & iCaster & "'", sqlCon)
                    sqlDa.Fill(tblSlab)
                End Using
                If tblSlab.Rows.Count > 0 Then
                    Dim dvTemp As DataView = tblSlab.DefaultView
                    dvTemp.Sort = "PROD_START ASC"
                    tblSlab = dvTemp.ToTable
                    Dim heatIdPattern As String = tblHeat.Rows(i)("HEAT_ID").ToString().Substring(1)
                    dvTemp.RowFilter = ""
                    dvTemp = Nothing
                    dvTemp = tblSlab.DefaultView
                    dvTemp.RowFilter = "SLAB_ID LIKE '%" & heatIdPattern & "%'"
                    tblSlab = dvTemp.ToTable
                    If tblSlab.Rows.Count > 0 Then
                        Dim strProdStart As String = tblSlab.Rows(0)("PROD_START")
                        Dim strProdEnd As String = tblSlab.Rows(tblSlab.Rows.Count - 1)("PROD_END")
                        Dim dtRaw As DataTable = GetRawData(strProdStart, strProdEnd, Caster, YValueColumn)
                        If dtRaw.Rows.Count > 0 Then
                            HasAnyData = True
                        End If
                        Dim dtrawtemp As DataTable = dtRaw.DefaultView.ToTable(True, YValueColumn, "TID_TIMESTAMP")
                        Dim rawCoordinates As String = ""
                        For j As Integer = 0 To dtrawtemp.Rows.Count - 1
                            If j > 0 Then
                                rawCoordinates &= ", "
                            End If
                            rawCoordinates &= "['" & CDate(dtrawtemp.Rows(j)("TID_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm:ss") & "', " & dtrawtemp.Rows(j)(YValueColumn) & "]"
                        Next
                        strRawDataArrays &= "var rline" & (i + 1) & " = [" & rawCoordinates & "];" & vbCrLf & vbCrLf
                        strRawSeriesNames &= "rline" & (i + 1)
                        strSeriesNames &= "line" & (i + 1)
                        strDataArrays &= "var line" & (i + 1) & " = ["
                        Dim coordinates As String = ""
                        For j As Integer = 0 To dtRaw.Rows.Count - 1 Step 30
                            Dim stddev As Double = 0
                            Dim sum As Double = 0
                            Dim hasSetOfThirty As Boolean = True
                            For k As Integer = j To (j + 29)
                                If k = dtRaw.Rows.Count Then
                                    sum = 0
                                    hasSetOfThirty = False
                                    Exit For
                                End If
                                sum = sum + CDbl(dtRaw.Rows(k)(YValueColumn))
                            Next
                            If hasSetOfThirty Then
                                Dim avg As Double = sum / 30
                                sum = 0
                                Dim xValue As String = ""
                                For k As Integer = j To (j + 29)
                                    sum = sum + ((CDbl(dtRaw.Rows(k)(YValueColumn)) - avg) * (CDbl(dtRaw.Rows(k)(YValueColumn)) - avg))
                                    xValue = CDate(dtRaw.Rows(k)("TID_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm:ss")
                                Next
                                stddev = Math.Sqrt(sum / 29)
                                If stddev > seriesMax Then
                                    seriesMax = stddev
                                End If
                                If j > 0 Then
                                    coordinates &= ", "
                                End If
                                coordinates &= "['" & xValue & "', " & stddev & "]"
                            End If
                        Next
                        strDataArrays &= coordinates & "];" & vbCrLf & vbCrLf
                        For j As Short = 0 To tblSlab.Rows.Count - 1
                            'If Not arrThickness.Contains(tblSlab.Rows(j)("THICKNESS")) Then
                            '    arrThickness.Add(tblSlab.Rows(j)("THICKNESS"))
                            'End If
                            If j > 0 Then
                                strDashedVerticalLine &= ","
                            End If
                            If i > 0 Then
                                If j > 0 Then
                                    strDashedVerticalLine = strDashedVerticalLine.Remove(strDashedVerticalLine.LastIndexOf(","))
                                End If
                                strDashedVerticalLine &= ","
                            End If
                            strDashedVerticalLine &= "{dashedVerticalLine: { name: '" & tblSlab.Rows(j)("SLAB_ID") & "', x: new Date('" & CDate(tblSlab.Rows(j)("PROD_START")).ToString("yyyy-MM-dd HH:mm:ss") & "'), lineWidth: 1, yOffset: '14', color: 'rgba(7, 17, 29, 0.49)', shadow: false, showTooltip: true, tooltipFormatString:'<table style=""background-color:#77F486; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>Slab Id</td><td>:</td><td>&nbsp;</td><td>" & tblSlab.Rows(j)("SLAB_ID") & "</td></tr></table>' }}"
                        Next
                    End If
                End If
            Next
        End Using
        Dim strThickness As String = ""
        'If arrThickness.Count > 0 Then
        '    strThickness = String.Join(",", arrThickness.ToArray)
        'End If
        Dim series As String = ""
        'If strChartSeriesProperties <> "" Then
        '    series = strChartSeriesProperties
        '    If strSlabIdSeriesProperties <> "" Then
        '        series &= "," & strSlabIdSeriesProperties
        '    End If
        '    If strRawSeriesProperties <> "" Then
        '        series &= "," & strRawSeriesProperties
        '    End If
        'End If
        If strRawSeriesProperties <> "" Then
            series = strRawSeriesProperties
            If strSlabIdSeriesProperties <> "" Then
                series &= "," & strSlabIdSeriesProperties
            End If
            If strChartSeriesProperties <> "" Then
                series &= "," & strChartSeriesProperties
            End If
        End If
        If Not HasAnyData Then
            strNoDataAttribute = "noDataIndicator: { show: false, indicator: 'Sorry, no data found.' },"
        End If
        strSeriesNames = strSeriesNames.Replace(",,", ",")
        strRawSeriesNames = strRawSeriesNames.Replace(",,", ",")
        seriesMax = seriesMax + seriesMax * 0.1
        Dim y2AxisLabel As String = IIf(YValueColumn = "TID_AVERAGE_SPEED", "Cast Speed (m/min)", "Mould Level (%)")
        Dim js As String = "<script id='" & ScriptName & "' language='javascript' type='text/javascript'>" & vbCrLf & _
                           "$.jqplot.config.enablePlugins = true;" & vbCrLf & _
                           strDataArrays & vbCrLf & vbCrLf & strRawDataArrays & vbCrLf & vbCrLf & _
                           PlotName & " = $.jqplot('" & ContainerName & "', [" & strRawSeriesNames & "," & strSeriesNames & "], {" & vbCrLf & _
                           "axesDefaults: { tickRenderer: $.jqplot.CanvasAxisTickRenderer, tickOptions: {fontSize: '8pt', showGridline: false}, useSeriesColor:true}," & vbCrLf & _
                           "seriesDefaults: {pointLabels: { show:false }, markerOptions: { shadow: false }}," & vbCrLf & _
                           "axes: {" & vbCrLf & _
                           "xaxis: {" & vbCrLf & _
                           "tickOptions:{formatString:'%d-%b %H:%M:%S', angle: -30}," & vbCrLf & _
                           "renderer:$.jqplot.DateAxisRenderer," & vbCrLf & _
                           "label: ''," & vbCrLf & _
                           "}," & vbCrLf & _
                           "yaxis: {" & vbCrLf & _
                           "//min: 0," & vbCrLf & _
                           "//max: " & seriesMax & "," & vbCrLf & _
                           "//tickOptions:{formatString:'%.4f'}," & vbCrLf & _
                           "label: '" & y2AxisLabel & "'," & vbCrLf & _
                           "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf & _
                           "}," & vbCrLf & _
                           "y2axis: { " & vbCrLf & _
                           "min: 0," & vbCrLf & _
                           "max: " & seriesMax & "," & vbCrLf & _
                           "tickOptions: { formatString: '%.4f' }," & vbCrLf & _
                           "label: 'Standard Deviation'," & vbCrLf & _
                           "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf & _
                           "}" & vbCrLf & _
                           "}, animate: true, " & vbCrLf & _
                           "title: ''," & vbCrLf & _
                           "series: [" & series & "]," & vbCrLf & _
                           "cursor: {" & vbCrLf & _
                           "zoom: true, showTooltip: false" & vbCrLf & _
                           "}," & vbCrLf & _
                           strNoDataAttribute & vbCrLf & _
                           "canvasOverlay: {show: true, objects: [" & strDashedVerticalLine & "]}," & vbCrLf & _
                           "legend:{show:true,placement: 'outsideGrid', rendererOptions: {numberColumns: " & totalHeat & ", marginTop: 10 }, location: 's', labels: [" & strLegendLabels & "," & strLegendLabels & "], renderer: $.jqplot.EnhancedLegendRenderer }," & vbCrLf & _
                           "grid: {backgroundColor: 'rgb(255,255,255)'}" & vbCrLf & _
                           "});" & vbCrLf & _
                           "</script>" & strThickness
        Context.Response.Write(js)
    End Sub

    Function GetRawMlfStdDevData(ByVal FromDate As String, ByVal ToDate As String, ByVal Caster As String, ByVal Connection As SqlConnection) As DataTable
        Dim tbl As New DataTable
        Using sqlAdapter As New SqlDataAdapter("SELECT TMS_MLF_TIMESTAMP, TMS_MLF_STD_DEV FROM TSCR_MLF_STDDEV WHERE TMS_MLF_TIMESTAMP BETWEEN '" & FromDate & "' AND '" & ToDate & "' AND TMS_CASTER='" & Caster & "'", Connection)
            sqlAdapter.Fill(tbl)
        End Using
        Return tbl
    End Function

    <WebMethod()>
    Public Sub FnMlfStdDevPlot(ByVal FromDate As String, ByVal ToDate As String, ByVal Caster As String, ByVal ContainerName As String, ByVal ScriptName As String, ByVal PlotName As String)
        Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString
        Dim strDashedVerticalLine As String = ""
        Dim dictRedPoints As New Dictionary(Of String, Decimal)
        Dim dictYellowPoints As New Dictionary(Of String, Decimal)
        Dim strBlankDots As String = "var blank = ["
        Dim slabIdPresent As Boolean = False
        Using sqlCon = New SqlConnection(strConnectionString)
            Dim tblHeat As New DataTable
            Dim iCaster As String = IIf(Caster = "1", "11", "12")
            Using sqlDa = New SqlDataAdapter("SELECT HEAT_ID_MSG6 AS HEAT_ID,DATETIME AS START_TIME, DATE_MSG6_CREATE AS END_TIME, DEVICE_KEY FROM TSCR_CCC_HEAT_RAW INNER JOIN TSCR_CC_HEAT_MASTER ON TSCR_CCC_HEAT_RAW.HEAT_ID_MSG6=TSCR_CC_HEAT_MASTER.PRODUCTION_KEY WHERE DATETIME >= '" & FromDate & "' AND DATE_MSG6_CREATE <= '" & ToDate & "' AND DEVICE_KEY = '" & iCaster & "'", sqlCon)
                sqlDa.Fill(tblHeat)
            End Using
            If tblHeat.Rows.Count > 0 Then
                For i As Short = 0 To tblHeat.Rows.Count - 1
                    Dim dtStart As DateTime = CDate(tblHeat.Rows(i)("START_TIME")).AddMinutes(-10) 'Subracting 10 minutes, as discussed with Arup.
                    Dim dtEnd As DateTime = tblHeat.Rows(i)("END_TIME")
                    iCaster = IIf(Caster = "1", "13", "14")
                    Dim tblSlab As New DataTable
                    Using sqlDa = New SqlDataAdapter("SELECT TSM_SLAB_ID AS SLAB_ID,TSM_PROD_START AS PROD_START,TSM_PROD_END AS PROD_END,TSR_SLAB_THICKNESS AS THICKNESS FROM TSCR_SLAB_MASTER INNER JOIN TSCR_SLAB_RAW ON TSCR_SLAB_MASTER.TSM_SLAB_ID=TSCR_SLAB_RAW.TSR_SLAB_ID WHERE TSM_PROD_START >= '" & dtStart.ToString("yyyy-MM-dd HH:mm:ss") & "' AND TSM_PROD_END <= '" & dtEnd.ToString("yyyy-MM-dd HH:mm:ss") & "' AND TSM_DEVICE_KEY='" & iCaster & "'", sqlCon)
                        sqlDa.Fill(tblSlab)
                    End Using
                    If tblSlab.Rows.Count > 0 Then
                        If Not slabIdPresent Then
                            slabIdPresent = True
                        End If
                        Dim dvTemp As DataView = tblSlab.DefaultView
                        dvTemp.Sort = "PROD_START ASC"
                        tblSlab = dvTemp.ToTable
                        Dim heatIdPattern As String = tblHeat.Rows(i)("HEAT_ID").ToString().Substring(1)
                        dvTemp.RowFilter = ""
                        dvTemp = Nothing
                        dvTemp = tblSlab.DefaultView
                        dvTemp.RowFilter = "SLAB_ID LIKE '%" & heatIdPattern & "%'"
                        tblSlab = dvTemp.ToTable
                        If tblSlab.Rows.Count > 0 Then
                            Dim strStart As String = CDate(tblSlab.Rows(0)("PROD_START")).ToString("yyyy-MM-dd HH:mm:ss")
                            Dim strEnd As String = CDate(tblSlab.Rows(tblSlab.Rows.Count - 1)("PROD_END")).ToString("yyyy-MM-dd HH:mm:ss")
                            Dim tblRaw As DataTable = GetRawMlfStdDevData(strStart, strEnd, Caster, sqlCon)
                            For j As Integer = 0 To tblRaw.Rows.Count - 1
                                If CDec(tblRaw.Rows(j)("TMS_MLF_STD_DEV")) > 0.8 And CDec(tblRaw.Rows(j)("TMS_MLF_STD_DEV")) < 1 Then
                                    If Not dictYellowPoints.Keys.Contains(tblRaw.Rows(j)("TMS_MLF_TIMESTAMP")) Then
                                        dictYellowPoints.Add(tblRaw.Rows(j)("TMS_MLF_TIMESTAMP"), tblRaw.Rows(j)("TMS_MLF_STD_DEV"))
                                    End If
                                ElseIf CDec(tblRaw.Rows(j)("TMS_MLF_STD_DEV")) > 1 Then
                                    If Not dictRedPoints.Keys.Contains(tblRaw.Rows(j)("TMS_MLF_TIMESTAMP")) Then
                                        dictRedPoints.Add(tblRaw.Rows(j)("TMS_MLF_TIMESTAMP"), tblRaw.Rows(j)("TMS_MLF_STD_DEV"))
                                    End If
                                End If
                            Next
                            For j As Short = 0 To tblSlab.Rows.Count - 1
                                If j > 0 Then
                                    strDashedVerticalLine &= ","
                                    strBlankDots &= ","
                                End If
                                If i > 0 Then
                                    If j > 0 Then
                                        strDashedVerticalLine = strDashedVerticalLine.Remove(strDashedVerticalLine.LastIndexOf(","))
                                        strBlankDots = strBlankDots.Remove(strBlankDots.LastIndexOf(","))
                                    End If
                                    strDashedVerticalLine &= ","
                                    strBlankDots &= ","
                                End If
                                strDashedVerticalLine &= "{dashedVerticalLine: { name: '" & tblSlab.Rows(j)("SLAB_ID") & "', x: new Date('" & CDate(tblSlab.Rows(j)("PROD_START")).ToString("yyyy-MM-dd HH:mm:ss") & "'), lineWidth: 1, yOffset: '14', color: 'rgba(7, 17, 29, 0.49)', shadow: false, showTooltip: true, tooltipFormatString:'<table style=""background-color:#77F486; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>Slab Id</td><td>:</td><td>&nbsp;</td><td>" & tblSlab.Rows(j)("SLAB_ID") & "</td></tr></table>' }}"
                                strBlankDots &= "['" & CDate(tblSlab.Rows(j)("PROD_START")) & "', 0]"
                            Next
                        End If
                    End If
                Next
            End If
        End Using
        strBlankDots &= "];"
        Dim strXMinMax As String = "min: '" & FromDate & "', max: '" & ToDate & "',"
        'If dictYellowPoints.Count > 0 Or dictRedPoints.Count > 0 Then
        '    strXMinMax = "min: '" & FromDate & "', max: '" & ToDate & "',"
        'End If

        Dim strYellowDataArray As String = "var lineYellow = ["
        Dim k As Integer = 0
        For Each timestamp As String In dictYellowPoints.Keys
            If k > 0 Then
                strYellowDataArray &= ", "
            End If
            strYellowDataArray &= "['" & timestamp & "', " & dictYellowPoints.Item(timestamp) & "]"
            k = k + 1
        Next
        strYellowDataArray &= "];"
        Dim strRedDataArray As String = "var lineRed = ["
        k = 0
        For Each timestamp As String In dictRedPoints.Keys
            If k > 0 Then
                strRedDataArray &= ", "
            End If
            strRedDataArray &= "['" & timestamp & "', " & dictRedPoints.Item(timestamp) & "]"
            k = k + 1
        Next
        strRedDataArray &= "];"

        Dim noDataIndicator As String = ""
        If Not slabIdPresent Then
            noDataIndicator = "noDataIndicator: { show: true, indicator: 'No data found.' },"
            strXMinMax = ""
        Else
            strDashedVerticalLine &= ",{horizontalLine: { name: '1',y: 1,lineWidth: 2,xOffset: 0,color: 'rgb(89, 198, 154)',shadow: false, showTooltip: true, tooltipFormatString:'<table style=""background-color:#E84FBA; color: #FFFFFF; font-family: verdana; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>Cut-off line for Sliver (1.0)</td></tr></table>'}},{horizontalLine: { name: '0.8',y: 0.8,lineWidth: 2,xOffset: 0,color: 'rgb(89, 198, 154)',shadow: false, showTooltip: true, tooltipFormatString:'<table style=""background-color:#E84FBA; color: #FFFFFF; font-family: verdana; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>Cut-off line for Warning (0.8)</td></tr></table>'}}"
        End If

        Dim strDataArrays As String = strYellowDataArray & vbCrLf & vbCrLf & strRedDataArray & vbCrLf & vbCrLf
        Dim strDataVariables As String = "lineYellow, lineRed"
        Dim strSeriesColours As String = "'#FFB30F', '#FF0000'"
        Dim strDefaultProperties As String = "pointLabels: { show:false }, showLine: false, showTooltip: false, showMarker:true, markerOptions: { shadow: false, showLine: false, style: 'filledCircle', size: 6 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 1,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>%s</td><td>,</td><td>&nbsp;</td><td>%s</td></tr></table>'}"
        Dim strLegends As String = "legend:{show:true, placement: 'outsideGrid', rendererOptions: {marginTop: 10, numberRows: 1 }, textColor: '#000000', fontSize: '12px', location: 's', labels: ['Warning','Sliver'], renderer: $.jqplot.EnhancedLegendRenderer },"
        If dictYellowPoints.Count = 0 And dictRedPoints.Count = 0 Then
            strDataArrays &= strBlankDots & vbCrLf & vbCrLf
            strDataVariables = "blank"
            strSeriesColours = "'#FFFFFF'"
            strDefaultProperties = "pointLabels: { show:false }, markerOptions: { shadow: false }, showLine: false, lineWidth: 0, showTooltip: false, showMarker:false, highlighter: {show: false,showMarker: false,tooltipAxes:'xy',yvalues: 1,formatString: '<table style=""display: none; background-color:#FFFDBF; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>%s</td><td>,</td><td>&nbsp;</td><td>%s</td></tr></table>'}"
            strLegends = ""
        End If

        Dim js As String = "<script id='" & ScriptName & "' language='javascript' type='text/javascript'>" & vbCrLf & _
                           "$.jqplot.config.enablePlugins = true;" & vbCrLf & _
                           strDataArrays & _
                           PlotName & " = $.jqplot('" & ContainerName & "', [" & strDataVariables & "], {" & vbCrLf & _
                           "axesDefaults: { tickRenderer: $.jqplot.CanvasAxisTickRenderer, tickOptions: {textColor: '#000000', fontSize: '9pt', showGridline: false}}," & vbCrLf & _
                           "seriesDefaults: {" & strDefaultProperties & "}," & vbCrLf & _
                           "seriesColors:[" & strSeriesColours & "]," & vbCrLf & _
                           "axes: {" & vbCrLf & _
                           "xaxis: {" & vbCrLf & _
                           strXMinMax & _
                           "tickOptions:{formatString:'%d-%b %H:%M:%S', angle: -30}," & vbCrLf & _
                           "renderer:$.jqplot.DateAxisRenderer," & vbCrLf & _
                           "label: ''" & vbCrLf & _
                           "}," & vbCrLf & _
                           "yaxis: {" & vbCrLf & _
                           "min: 0.7," & vbCrLf & _
                           "labelOptions: {textColor: '#000000'}," & vbCrLf & _
                           "label: 'Standard Deviation'," & vbCrLf & _
                           "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf & _
                           "}" & vbCrLf & _
                           "}," & vbCrLf & _
                           "animate: true," & vbCrLf & _
                           "title: ''," & vbCrLf & _
                           "cursor: {" & vbCrLf & _
                           "zoom: true, showTooltip: false" & vbCrLf & _
                           "}," & vbCrLf & _
                           noDataIndicator & vbCrLf & _
                           "canvasOverlay: {show: true, objects: [" & strDashedVerticalLine & "]}," & vbCrLf & _
                           strLegends & vbCrLf & _
                           "grid: {backgroundColor: 'rgb(255,255,255)'}" & vbCrLf & _
                           "});" & vbCrLf & _
                           "</script>"
        Context.Response.Write(js)
    End Sub

    Function GetRawCastSpeedChangeData(ByVal FromDate As String, ByVal ToDate As String, ByVal Caster As String, ByVal Connection As SqlConnection) As DataTable
        Dim tbl As New DataTable
        Using sqlAdapter As New SqlDataAdapter("SELECT TCC_CSPEED_TIMESTAMP, TCC_CSPEED_CHANGERATE FROM TSCR_CSPEED_CHANGERATE WHERE TCC_CSPEED_TIMESTAMP BETWEEN '" & FromDate & "' AND '" & ToDate & "' AND TCC_CASTER='" & Caster & "'", Connection)
            sqlAdapter.Fill(tbl)
        End Using
        Return tbl
    End Function

    Function GetRawSenDepthData(ByVal FromDate As String, ByVal ToDate As String, ByVal Caster As String, ByVal Connection As SqlConnection) As DataTable
        Dim tbl As New DataTable
        Using sqlAdapter As New SqlDataAdapter("SELECT TSD_TIMESTAMP, TSD_SEN_DEPTH, TSD_FILENAME FROM TSCR_SEN_DEPTH WHERE TSD_TIMESTAMP BETWEEN '" & FromDate & "' AND '" & ToDate & "' AND TSD_CASTER='" & Caster & "'", Connection)
            sqlAdapter.Fill(tbl)
        End Using
        Return tbl
    End Function

    <WebMethod()>
    Public Sub FnCastSpeedChangePlot(ByVal FromDate As String, ByVal ToDate As String, ByVal Caster As String, ByVal ContainerName As String, ByVal ScriptName As String, ByVal PlotName As String)
        Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString
        Dim strDashedVerticalLine As String = ""
        Dim dictRedPoints As New Dictionary(Of String, Decimal)
        Dim strBlankDots As String = "var blank = ["
        Dim slabIdPresent As Boolean = False
        Using sqlCon = New SqlConnection(strConnectionString)
            Dim tblHeat As New DataTable
            Dim iCaster As String = IIf(Caster = "1", "11", "12")
            Using sqlDa = New SqlDataAdapter("SELECT HEAT_ID_MSG6 AS HEAT_ID,DATETIME AS START_TIME, DATE_MSG6_CREATE AS END_TIME, DEVICE_KEY FROM TSCR_CCC_HEAT_RAW INNER JOIN TSCR_CC_HEAT_MASTER ON TSCR_CCC_HEAT_RAW.HEAT_ID_MSG6=TSCR_CC_HEAT_MASTER.PRODUCTION_KEY WHERE DATETIME >= '" & FromDate & "' AND DATE_MSG6_CREATE <= '" & ToDate & "' AND DEVICE_KEY = '" & iCaster & "'", sqlCon)
                sqlDa.Fill(tblHeat)
            End Using
            If tblHeat.Rows.Count > 0 Then
                For i As Short = 0 To tblHeat.Rows.Count - 1
                    Dim dtStart As DateTime = CDate(tblHeat.Rows(i)("START_TIME")).AddMinutes(-10) 'Subracting 10 minutes, as discussed with Arup.
                    Dim dtEnd As DateTime = tblHeat.Rows(i)("END_TIME")
                    iCaster = IIf(Caster = "1", "13", "14")
                    Dim tblSlab As New DataTable
                    Using sqlDa = New SqlDataAdapter("SELECT TSM_SLAB_ID AS SLAB_ID,TSM_PROD_START AS PROD_START,TSM_PROD_END AS PROD_END,TSR_SLAB_THICKNESS AS THICKNESS FROM TSCR_SLAB_MASTER INNER JOIN TSCR_SLAB_RAW ON TSCR_SLAB_MASTER.TSM_SLAB_ID=TSCR_SLAB_RAW.TSR_SLAB_ID WHERE TSM_PROD_START >= '" & dtStart.ToString("yyyy-MM-dd HH:mm:ss") & "' AND TSM_PROD_END <= '" & dtEnd.ToString("yyyy-MM-dd HH:mm:ss") & "' AND TSM_DEVICE_KEY='" & iCaster & "'", sqlCon)
                        sqlDa.Fill(tblSlab)
                    End Using
                    If tblSlab.Rows.Count > 0 Then
                        If Not slabIdPresent Then
                            slabIdPresent = True
                        End If
                        Dim dvTemp As DataView = tblSlab.DefaultView
                        dvTemp.Sort = "PROD_START ASC"
                        tblSlab = dvTemp.ToTable
                        Dim heatIdPattern As String = tblHeat.Rows(i)("HEAT_ID").ToString().Substring(1)
                        dvTemp.RowFilter = ""
                        dvTemp = Nothing
                        dvTemp = tblSlab.DefaultView
                        dvTemp.RowFilter = "SLAB_ID LIKE '%" & heatIdPattern & "%'"
                        tblSlab = dvTemp.ToTable
                        If tblSlab.Rows.Count > 0 Then
                            Dim strStart As String = CDate(tblSlab.Rows(0)("PROD_START")).ToString("yyyy-MM-dd HH:mm:ss")
                            Dim strEnd As String = CDate(tblSlab.Rows(tblSlab.Rows.Count - 1)("PROD_END")).ToString("yyyy-MM-dd HH:mm:ss")
                            Dim tblRaw As DataTable = GetRawCastSpeedChangeData(strStart, strEnd, Caster, sqlCon)
                            tblRaw = tblRaw.DefaultView.ToTable(True)
                            For j As Integer = 0 To tblRaw.Rows.Count - 1
                                If Not dictRedPoints.Keys.Contains(tblRaw.Rows(j)("TCC_CSPEED_TIMESTAMP")) Then
                                    dictRedPoints.Add(tblRaw.Rows(j)("TCC_CSPEED_TIMESTAMP"), tblRaw.Rows(j)("TCC_CSPEED_CHANGERATE"))
                                End If
                            Next
                            For j As Short = 0 To tblSlab.Rows.Count - 1
                                If j > 0 Then
                                    strDashedVerticalLine &= ","
                                    strBlankDots &= ","
                                End If
                                If i > 0 Then
                                    If j > 0 Then
                                        strDashedVerticalLine = strDashedVerticalLine.Remove(strDashedVerticalLine.LastIndexOf(","))
                                        strBlankDots = strBlankDots.Remove(strBlankDots.LastIndexOf(","))
                                    End If
                                    strDashedVerticalLine &= ","
                                    strBlankDots &= ","
                                End If
                                strDashedVerticalLine &= "{dashedVerticalLine: { name: '" & tblSlab.Rows(j)("SLAB_ID") & "', x: new Date('" & CDate(tblSlab.Rows(j)("PROD_START")).ToString("yyyy-MM-dd HH:mm:ss") & "'), lineWidth: 1, yOffset: '14', color: 'rgba(7, 17, 29, 0.49)', shadow: false, showTooltip: true, tooltipFormatString:'<table style=""background-color:#77F486; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>Slab Id</td><td>:</td><td>&nbsp;</td><td>" & tblSlab.Rows(j)("SLAB_ID") & "</td></tr></table>' }}"
                                strBlankDots &= "['" & CDate(tblSlab.Rows(j)("PROD_START")) & "', 0]"
                            Next
                        End If
                    End If
                Next
            End If
        End Using
        strBlankDots &= "];"
        Dim strXMinMax As String = "min: '" & FromDate & "', max: '" & ToDate & "',"
        'If dictRedPoints.Count > 0 Then
        '    strXMinMax = "min: '" & FromDate & "', max: '" & ToDate & "',"
        'End If
        Dim k As Integer = 0
        Dim strRedDataArray As String = "var lineRed = ["
        For Each timestamp As String In dictRedPoints.Keys
            If k > 0 Then
                strRedDataArray &= ", "
            End If
            strRedDataArray &= "['" & timestamp & "', " & dictRedPoints.Item(timestamp) & "]"
            k = k + 1
        Next
        strRedDataArray &= "];"

        Dim noDataIndicator As String = ""
        If Not slabIdPresent Then
            noDataIndicator = "noDataIndicator: { show: true, indicator: 'No data found.' },"
            strXMinMax = ""
        End If

        Dim strDataArrays As String = strRedDataArray & vbCrLf & vbCrLf
        Dim strDataVariables As String = "lineRed"
        Dim strSeriesColours As String = "'#FF0000'"
        Dim strDefaultProperties As String = "pointLabels: { show:false }, showLine: false, lineWidth: 2, showTooltip: false, showMarker:true, markerOptions: { shadow: false, style: 'filledCircle', size: 6 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 1,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>%s</td><td>,</td><td>&nbsp;</td><td>%s</td></tr></table>'}"
        Dim strLegends As String = "legend:{show:true, seriesToggle: false, placement: 'outsideGrid', rendererOptions: {marginTop: 10, numberRows: 1 }, textColor: '#000000', fontSize: '12px', location: 's', labels: ['Speed change rate greater than 0.20 m/min'], renderer: $.jqplot.EnhancedLegendRenderer },"
        If dictRedPoints.Count = 0 Then
            strDataArrays &= strBlankDots & vbCrLf & vbCrLf
            strDataVariables = "blank"
            strSeriesColours = "'#FFFFFF'"
            strDefaultProperties = "pointLabels: { show:false }, markerOptions: { shadow: false }, showLine: false, lineWidth: 0, showTooltip: false, showMarker:false, highlighter: {show: false,showMarker: false,tooltipAxes:'xy',yvalues: 1,formatString: '<table style=""display: none; background-color:#FFFDBF; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>%s</td><td>,</td><td>&nbsp;</td><td>%s</td></tr></table>'}"
            strLegends = ""
        End If

        'Dim strDefaultProperties As String = "pointLabels: { show:false }, shadow: false, showLine: false, lineWidth: 2, showTooltip: false, showMarker:true, markerOptions: { style: 'filledCircle', size: 6 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 1,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>%s</td><td>,</td><td>&nbsp;</td><td>%s</td></tr></table>'}"
        Dim js As String = "<script id='" & ScriptName & "' language='javascript' type='text/javascript'>" & vbCrLf & _
                           "$.jqplot.config.enablePlugins = true;" & vbCrLf & _
                           strDataArrays & _
                           PlotName & " = $.jqplot('" & ContainerName & "', [" & strDataVariables & "], {" & vbCrLf & _
                           "axesDefaults: { tickRenderer: $.jqplot.CanvasAxisTickRenderer, tickOptions: {textColor: '#000000', fontSize: '9pt', showGridline: false}}," & vbCrLf & _
                           "seriesDefaults: {" & strDefaultProperties & "}," & vbCrLf & _
                           "seriesColors:[" & strSeriesColours & "]," & vbCrLf & _
                           "axes: {" & vbCrLf & _
                           "xaxis: {" & vbCrLf & _
                           strXMinMax & _
                           "tickOptions:{formatString:'%d-%b %H:%M:%S', angle: -30}," & vbCrLf & _
                           "renderer:$.jqplot.DateAxisRenderer," & vbCrLf & _
                           "label: ''" & vbCrLf & _
                           "}," & vbCrLf & _
                           "yaxis: {" & vbCrLf & _
                           "//tickOptions:{formatString:'%.4f'}," & vbCrLf & _
                           "labelOptions: {textColor: '#000000'}," & vbCrLf & _
                           "label: 'Speed Change Rate (m/sq min)'," & vbCrLf & _
                           "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf & _
                           "}" & vbCrLf & _
                           "}," & vbCrLf & _
                           "animate: true," & vbCrLf & _
                           "title: ''," & vbCrLf & _
                           "cursor: {" & vbCrLf & _
                           "zoom: true, showTooltip: false" & vbCrLf & _
                           "}," & vbCrLf & _
                           noDataIndicator & vbCrLf & _
                           "canvasOverlay: {show: true, objects: [" & strDashedVerticalLine & "]}," & vbCrLf & _
                           strLegends & vbCrLf & _
                           "grid: {backgroundColor: 'rgb(255,255,255)'}" & vbCrLf & _
                           "});" & vbCrLf & _
                           "</script>"
        Context.Response.Write(js)
    End Sub

    '<WebMethod()>
    'Public Sub FnCaAlRatioPlot(ByVal FromDate As String, ByVal ToDate As String, ByVal Caster As String, ByVal ContainerName As String, ByVal ScriptName As String, ByVal PlotName As String)
    '    Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("LPTGSQLDEV").ConnectionString
    '    Dim strDataArrayRed As String = "var dataRed = ["
    '    Dim strDataArrayGreen As String = "var dataGreen = ["
    '    Dim strTicksAngle As String = ""
    '    Dim strDataVariables As String = "dataRed, dataGreen"
    '    Dim strSeriesColours As String = "'#FF0000', '#14CE30'"
    '    Dim strLegends As String = "legend: {show: true, placement: 'outsideGrid', rendererOptions: {marginTop: 10, numberRows: 1 }, textColor: '#000000', fontSize: '12px', location: 's', labels: ['Critical','Normal'], renderer: $.jqplot.EnhancedLegendRenderer },"
    '    Dim strLegendShow As String = "true"
    '    Using sqlCon = New SqlConnection(strConnectionString)
    '        Dim tblHeat As New DataTable
    '        Dim iCaster As String = IIf(Caster = "1", "11", "12")
    '        Using sqlDa = New SqlDataAdapter("SELECT DISTINCT HEAT_ID_MSG6 AS HEAT_ID,DATETIME AS START_TIME, DATE_MSG6_CREATE AS END_TIME, DEVICE_KEY, (LF_ANA_CA/LF_ANA_AL) AS RATIO FROM TSCR_CCC_HEAT_RAW INNER JOIN TSCR_CC_HEAT_MASTER ON TSCR_CCC_HEAT_RAW.HEAT_ID_MSG6=TSCR_CC_HEAT_MASTER.PRODUCTION_KEY WHERE DATETIME >= '" & FromDate & "' AND DATE_MSG6_CREATE <= '" & ToDate & "' AND DEVICE_KEY = '" & iCaster & "' AND (LF_ANA_CA/LF_ANA_AL) IS NOT NULL ORDER BY DATETIME DESC", sqlCon)
    '            sqlDa.Fill(tblHeat)
    '        End Using
    '        If tblHeat.Rows.Count > 0 Then
    '            If tblHeat.Rows.Count >= 10 Then
    '                strTicksAngle = "angle: -30, "
    '            End If
    '            Dim dv As DataView = tblHeat.DefaultView
    '            dv.RowFilter = "RATIO < 0.07 OR RATIO > 0.12"
    '            Dim dtRed As DataTable = dv.ToTable
    '            If dtRed.Rows.Count = 0 Then
    '                strDataVariables = "dataGreen"
    '                strSeriesColours = "'#14CE30'"
    '                strLegends = "legend: {show: true, placement: 'outsideGrid', rendererOptions: {marginTop: 10, numberRows: 1 }, textColor: '#000000', fontSize: '12px', location: 's', labels: ['Normal'], renderer: $.jqplot.EnhancedLegendRenderer },"
    '            End If
    '            dv.RowFilter = ""
    '            dv = tblHeat.DefaultView
    '            dv.RowFilter = "RATIO >= 0.07 AND RATIO <= 0.12"
    '            Dim dtGreen As DataTable = dv.ToTable
    '            If dtGreen.Rows.Count = 0 Then
    '                strDataVariables = "dataRed"
    '                strSeriesColours = "'#FF0000'"
    '                strLegends = "legend: {show: true, placement: 'outsideGrid', rendererOptions: {marginTop: 10, numberRows: 1 }, textColor: '#000000', fontSize: '12px', location: 's', labels: ['Critical'], renderer: $.jqplot.EnhancedLegendRenderer },"
    '            End If
    '            For i As Short = 0 To dtRed.Rows.Count - 1
    '                If i > 0 Then
    '                    strDataArrayRed &= ", "
    '                End If
    '                strDataArrayRed &= "['" & dtRed.Rows(i)("HEAT_ID") & "', " & dtRed.Rows(i)("RATIO") & "]"
    '            Next
    '            For i As Short = 0 To dtGreen.Rows.Count - 1
    '                If i > 0 Then
    '                    strDataArrayGreen &= ", "
    '                End If
    '                strDataArrayGreen &= "['" & dtGreen.Rows(i)("HEAT_ID") & "', " & dtGreen.Rows(i)("RATIO") & "]"
    '            Next
    '        Else
    '            strLegends = ""
    '        End If
    '    End Using
    '    strDataArrayRed &= "];"
    '    strDataArrayGreen &= "];"

    '    Dim strDataArrays As String = strDataArrayRed & vbCrLf & vbCrLf & strDataArrayGreen & vbCrLf & "dataRed.sort();" & vbCrLf & "dataGreen.sort();" & vbCrLf & vbCrLf
    '    Dim strDefaultProperties As String = "pointLabels: { show:true }, showLine: false, showTooltip: false, showMarker:true, markerOptions: { shadow: false, style: 'filledCircle', size: 16 }, highlighter: {show: false}"
    '    Dim strHorizontalLines As String = "{horizontalLine: { name: '0.07',y: 0.07,lineWidth: 2,xOffset: 0,color: 'rgb(89, 198, 154)', shadow: false, showTooltip: true, tooltipFormatString:'<table style=""background-color:#E84FBA; color: #FFFFFF; font-family: verdana; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>Minimum level of normal ratio (0.07)</td></tr></table>'}},{horizontalLine: { name: '0.12',y: 0.12,lineWidth: 2,xOffset: 0,color: 'rgb(89, 198, 154)', shadow: false, showTooltip: true, tooltipFormatString:'<table style=""background-color:#E84FBA; color: #FFFFFF; font-family: verdana; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>Maximum level of normal ratio (0.12)</td></tr></table>'}}"

    '    Dim js As String = "<script id='" & ScriptName & "' language='javascript' type='text/javascript'>" & vbCrLf & _                           
    '                       "$.jqplot.config.enablePlugins = true;" & vbCrLf & _
    '                       strDataArrays & _
    '                       PlotName & " = $.jqplot('" & ContainerName & "', [" & strDataVariables & "], {" & vbCrLf & _
    '                       "axesDefaults: { tickRenderer: $.jqplot.CanvasAxisTickRenderer, tickOptions: {textColor: '#000000', fontSize: '9pt'}}," & vbCrLf & _
    '                       "seriesDefaults: {" & strDefaultProperties & "}," & vbCrLf & _
    '                       "seriesColors:[" & strSeriesColours & "]," & vbCrLf & _
    '                       "axes: {" & vbCrLf & _
    '                       "xaxis: {" & vbCrLf & _
    '                       "tickOptions:{formatString:'%d-%b %H:%M:%S', " & strTicksAngle & "showGridline: true, fontSize: '10pt'}," & vbCrLf & _
    '                       "renderer:$.jqplot.CategoryAxisRenderer," & vbCrLf & _
    '                       "label: 'Heat Id'" & vbCrLf & _
    '                       "}," & vbCrLf & _
    '                       "yaxis: {" & vbCrLf & _
    '                       "tickOptions: {showGridline: false, formatString:'%.3f'}," & vbCrLf & _
    '                       "min: 0, max: 0.15," & vbCrLf & _
    '                       "labelOptions: {textColor: '#000000'}," & vbCrLf & _
    '                       "label: 'Ca-Al Ratio'," & vbCrLf & _
    '                       "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf & _
    '                       "}" & vbCrLf & _
    '                       "}," & vbCrLf & _
    '                       "animate: true," & vbCrLf & _
    '                       "title: ''," & vbCrLf & _
    '                       "cursor: {" & vbCrLf & _
    '                       "zoom: false, show: false" & vbCrLf & _
    '                       "}," & vbCrLf & _
    '                       "noDataIndicator: { show: true, indicator: 'No data found.' }," & vbCrLf & _
    '                       "canvasOverlay: {show: true, objects: [" & strHorizontalLines & "]}," & vbCrLf & _
    '                       strLegends & vbCrLf & _
    '                       "grid: {backgroundColor: 'rgb(255,255,255)'}" & vbCrLf & _
    '                       "});" & vbCrLf & _
    '                       "</script>"
    '    Context.Response.Write(js)
    'End Sub

    <WebMethod()>
    Public Sub FnCaAlRatioPlot(ByVal FromDate As String, ByVal ToDate As String, ByVal Caster As String, ByVal ContainerName As String, ByVal ScriptName As String, ByVal PlotName As String)
        Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString
        Dim strDataArray As String = "var data = ["
        Dim strTicksAngle As String = ""
        Dim strDataVariable As String = "data"
        Dim strSeriesColour As String = "'#000000'"
        Dim strLegends As String = "legend: {show: true, showSwatches: false, placement: 'outsideGrid', rendererOptions: {marginTop: 10, numberRows: 1, seriesToggle: false }, textColor: '#183B82', fontSize: '12px', location: 's', labels: ['Red: Critical zone | Green: Normal zone'], renderer: $.jqplot.EnhancedLegendRenderer },"
        Dim strLegendShow As String = "true"
        Using sqlCon = New SqlConnection(strConnectionString)
            Dim tblHeat As New DataTable
            Dim iCaster As String = IIf(Caster = "1", "11", "12")
            Using sqlDa = New SqlDataAdapter("SELECT DISTINCT HEAT_ID_MSG6 AS HEAT_ID,DATETIME AS START_TIME, DATE_MSG6_CREATE AS END_TIME, DEVICE_KEY, (LF_ANA_CA/LF_ANA_AL) AS RATIO FROM TSCR_CCC_HEAT_RAW INNER JOIN TSCR_CC_HEAT_MASTER ON TSCR_CCC_HEAT_RAW.HEAT_ID_MSG6=TSCR_CC_HEAT_MASTER.PRODUCTION_KEY WHERE DATETIME >= '" & FromDate & "' AND DATE_MSG6_CREATE <= '" & ToDate & "' AND DEVICE_KEY = '" & iCaster & "' AND (LF_ANA_CA/LF_ANA_AL) IS NOT NULL ORDER BY DATETIME", sqlCon)
                sqlDa.Fill(tblHeat)
            End Using
            If tblHeat.Rows.Count > 0 Then
                If tblHeat.Rows.Count >= 10 Then
                    strTicksAngle = "angle: -30, "
                End If
                'Dim dv As DataView = tblHeat.DefaultView
                'dv.RowFilter = "RATIO < 0.07 OR RATIO > 0.12"
                'Dim dtRed As DataTable = dv.ToTable
                'If dtRed.Rows.Count = 0 Then
                '    strDataVariables = "dataGreen"
                '    strSeriesColours = "'#14CE30'"
                '    strLegends = "legend: {show: true, placement: 'outsideGrid', rendererOptions: {marginTop: 10, numberRows: 1 }, textColor: '#000000', fontSize: '12px', location: 's', labels: ['Normal'], renderer: $.jqplot.EnhancedLegendRenderer },"
                'End If
                'dv.RowFilter = ""
                'dv = tblHeat.DefaultView
                'dv.RowFilter = "RATIO >= 0.07 AND RATIO <= 0.12"
                'Dim dtGreen As DataTable = dv.ToTable
                'If dtGreen.Rows.Count = 0 Then
                '    strDataVariables = "dataRed"
                '    strSeriesColours = "'#FF0000'"
                '    strLegends = "legend: {show: true, placement: 'outsideGrid', rendererOptions: {marginTop: 10, numberRows: 1 }, textColor: '#000000', fontSize: '12px', location: 's', labels: ['Critical'], renderer: $.jqplot.EnhancedLegendRenderer },"
                'End If
                'For i As Short = 0 To dtRed.Rows.Count - 1
                '    If i > 0 Then
                '        strDataArrayRed &= ", "
                '    End If
                '    strDataArrayRed &= "['" & dtRed.Rows(i)("HEAT_ID") & "', " & dtRed.Rows(i)("RATIO") & "]"
                'Next
                'For i As Short = 0 To dtGreen.Rows.Count - 1
                '    If i > 0 Then
                '        strDataArrayGreen &= ", "
                '    End If
                '    strDataArrayGreen &= "['" & dtGreen.Rows(i)("HEAT_ID") & "', " & dtGreen.Rows(i)("RATIO") & "]"
                'Next
                For i As Short = 0 To tblHeat.Rows.Count - 1
                    If i > 0 Then
                        strDataArray &= ", "
                    End If
                    strDataArray &= "['" & tblHeat.Rows(i)("HEAT_ID") & "', " & tblHeat.Rows(i)("RATIO") & "]"
                Next
            Else
                strLegends = ""
            End If
        End Using
        strDataArray &= "];"

        Dim strDataArrays As String = strDataArray & vbCrLf & vbCrLf
        Dim strDefaultProperties As String = "pointLabels: { show:true }, showLine: false, showTooltip: false, showMarker:true, markerOptions: { shadow: false, style: 'filledCircle', size: 16 }, highlighter: {show: false}"
        'Dim strHorizontalLines As String = "{horizontalLine: { name: '0.07',y: 0.07,lineWidth: 2,xOffset: 0,color: 'rgb(89, 198, 154)', shadow: false, showTooltip: true, tooltipFormatString:'<table style=""background-color:#E84FBA; color: #FFFFFF; font-family: verdana; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>Minimum level of normal ratio (0.07)</td></tr></table>'}},{horizontalLine: { name: '0.12',y: 0.12,lineWidth: 2,xOffset: 0,color: 'rgb(89, 198, 154)', shadow: false, showTooltip: true, tooltipFormatString:'<table style=""background-color:#E84FBA; color: #FFFFFF; font-family: verdana; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>Maximum level of normal ratio (0.12)</td></tr></table>'}}"
        Dim strRectanglesObjects As String = "{ rectangle: { ymin: 0, ymax: 0.07, xminOffset: '0px', xmaxOffset: '0px', yminOffset: '0px', ymaxOffset: '0px', color: 'rgba(255, 61, 61, 0.56)', showTooltip: true, tooltipLocation:'e', tooltipFormatString: '<table style=""background-color:#FF0000; color: #FFFFFF; font-family: verdana; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>Critical zone (between 0 and 0.07)</td></tr></table>' } }, "
        strRectanglesObjects &= "{ rectangle: { ymin: 0.07, ymax: 0.12, xminOffset: '0px', xmaxOffset: '0px', yminOffset: '0px', ymaxOffset: '0px', color: 'rgba(91, 210, 111, 0.56)', showTooltip: true, tooltipLocation:'e', tooltipFormatString: '<table style=""background-color:#77F486; color: #000000; font-family: verdana; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>Normal zone (between 0.07 and 0.12)</td></tr></table>' } }, "
        strRectanglesObjects &= "{ rectangle: { ymin: 0.12, ymax: 0.15, xminOffset: '0px', xmaxOffset: '0px', yminOffset: '0px', ymaxOffset: '0px', color: 'rgba(255, 61, 61, 0.56)', showTooltip: true, tooltipLocation:'e', tooltipFormatString: '<table style=""background-color:#FF0000; color: #FFFFFF; font-family: verdana; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>Critical zone (beyond 0.12)</td></tr></table>' } }"

        Dim js As String = "<script id='" & ScriptName & "' language='javascript' type='text/javascript'>" & vbCrLf & _
                           "$.jqplot.config.enablePlugins = true;" & vbCrLf & _
                           strDataArrays & _
                           PlotName & " = $.jqplot('" & ContainerName & "', [" & strDataVariable & "], {" & vbCrLf & _
                           "axesDefaults: { tickRenderer: $.jqplot.CanvasAxisTickRenderer, tickOptions: {textColor: '#000000', fontSize: '9pt'}}," & vbCrLf & _
                           "seriesDefaults: {" & strDefaultProperties & "}," & vbCrLf & _
                           "seriesColors:[" & strSeriesColour & "]," & vbCrLf & _
                           "axes: {" & vbCrLf & _
                           "xaxis: {" & vbCrLf & _
                           "tickOptions:{formatString:'%d-%b %H:%M:%S', " & strTicksAngle & "showGridline: true, fontSize: '10pt'}," & vbCrLf & _
                           "labelOptions: {textColor: '#000000'}," & vbCrLf & _
                           "renderer:$.jqplot.CategoryAxisRenderer," & vbCrLf & _
                           "label: 'Heat Id'" & vbCrLf & _
                           "}," & vbCrLf & _
                           "yaxis: {" & vbCrLf & _
                           "tickOptions: {showGridline: false, formatString:'%.3f'}," & vbCrLf & _
                           "min: 0, max: 0.15," & vbCrLf & _
                           "labelOptions: {textColor: '#000000'}," & vbCrLf & _
                           "label: 'Ca-Al Ratio'," & vbCrLf & _
                           "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf & _
                           "}" & vbCrLf & _
                           "}," & vbCrLf & _
                           "animate: true," & vbCrLf & _
                           "title: ''," & vbCrLf & _
                           "cursor: {" & vbCrLf & _
                           "zoom: false, show: false" & vbCrLf & _
                           "}," & vbCrLf & _
                           "noDataIndicator: { show: true, indicator: 'No data found.' }," & vbCrLf & _
                           "canvasOverlay: {show: true, objects: [" & strRectanglesObjects & "]}," & vbCrLf & _
                           strLegends & vbCrLf & _
                           "grid: {backgroundColor: 'rgb(255,255,255)'}" & vbCrLf & _
                           "});" & vbCrLf & _
                           "</script>"
        Context.Response.Write(js)
    End Sub

    Function GetRawHeatFluxData(ByVal FromDate As String, ByVal ToDate As String, ByVal Caster As String, ByVal RatioType As String, ByVal Connection As SqlConnection) As DataTable
        Dim tbl As New DataTable
        Using sqlAdapter As New SqlDataAdapter("SELECT THD_TIMESTAMP, THD_HF_RATIO FROM TSCR_HEATFLUX_DTLS WHERE THD_TIMESTAMP BETWEEN '" & FromDate & "' AND '" & ToDate & "' AND THD_CASTER='" & Caster & "' AND THD_HF_RATIO_TYPE='" & RatioType & "'", Connection)
            sqlAdapter.Fill(tbl)
        End Using
        Return tbl
    End Function

    <WebMethod()>
    Public Sub FnHeatFluxLineChart(ByVal FromDate As String, ByVal ToDate As String, ByVal Caster As String, ByVal ContainerName As String, ByVal ScriptName As String, ByVal PlotName As String, ByVal RatioType As String)
        Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString
        Dim strDashedVerticalLine As String = ""
        Dim dictAbnormalPoints As New Dictionary(Of String, Decimal)
        Dim strBlankDots As String = "var blank = ["
        Dim slabIdPresent As Boolean = False
        Using sqlCon = New SqlConnection(strConnectionString)
            Dim tblHeat As New DataTable
            Dim iCaster As String = IIf(Caster = "1", "11", "12")
            Using sqlDa = New SqlDataAdapter("SELECT HEAT_ID_MSG6 AS HEAT_ID,DATETIME AS START_TIME, DATE_MSG6_CREATE AS END_TIME, DEVICE_KEY FROM TSCR_CCC_HEAT_RAW INNER JOIN TSCR_CC_HEAT_MASTER ON TSCR_CCC_HEAT_RAW.HEAT_ID_MSG6=TSCR_CC_HEAT_MASTER.PRODUCTION_KEY WHERE DATETIME >= '" & FromDate & "' AND DATE_MSG6_CREATE <= '" & ToDate & "' AND DEVICE_KEY = '" & iCaster & "'", sqlCon)
                sqlDa.Fill(tblHeat)
            End Using
            If tblHeat.Rows.Count > 0 Then
                For i As Short = 0 To tblHeat.Rows.Count - 1
                    Dim dtStart As DateTime = CDate(tblHeat.Rows(i)("START_TIME")).AddMinutes(-10) 'Subracting 10 minutes, as discussed with Arup.
                    Dim dtEnd As DateTime = tblHeat.Rows(i)("END_TIME")
                    iCaster = IIf(Caster = "1", "13", "14")
                    Dim tblSlab As New DataTable
                    Using sqlDa = New SqlDataAdapter("SELECT TSM_SLAB_ID AS SLAB_ID,TSM_PROD_START AS PROD_START,TSM_PROD_END AS PROD_END,TSR_SLAB_THICKNESS AS THICKNESS FROM TSCR_SLAB_MASTER INNER JOIN TSCR_SLAB_RAW ON TSCR_SLAB_MASTER.TSM_SLAB_ID=TSCR_SLAB_RAW.TSR_SLAB_ID WHERE TSM_PROD_START >= '" & dtStart.ToString("yyyy-MM-dd HH:mm:ss") & "' AND TSM_PROD_END <= '" & dtEnd.ToString("yyyy-MM-dd HH:mm:ss") & "' AND TSM_DEVICE_KEY='" & iCaster & "'", sqlCon)
                        sqlDa.Fill(tblSlab)
                    End Using
                    If tblSlab.Rows.Count > 0 Then
                        If Not slabIdPresent Then
                            slabIdPresent = True
                        End If
                        Dim dvTemp As DataView = tblSlab.DefaultView
                        dvTemp.Sort = "PROD_START ASC"
                        tblSlab = dvTemp.ToTable
                        Dim heatIdPattern As String = tblHeat.Rows(i)("HEAT_ID").ToString().Substring(1)
                        dvTemp.RowFilter = ""
                        dvTemp = Nothing
                        dvTemp = tblSlab.DefaultView
                        dvTemp.RowFilter = "SLAB_ID LIKE '%" & heatIdPattern & "%'"
                        tblSlab = dvTemp.ToTable
                        If tblSlab.Rows.Count > 0 Then
                            Dim strStart As String = CDate(tblSlab.Rows(0)("PROD_START")).ToString("yyyy-MM-dd HH:mm:ss")
                            Dim strEnd As String = CDate(tblSlab.Rows(tblSlab.Rows.Count - 1)("PROD_END")).ToString("yyyy-MM-dd HH:mm:ss")
                            Dim tblRaw As DataTable = GetRawHeatFluxData(strStart, strEnd, Caster, RatioType, sqlCon)
                            tblRaw = tblRaw.DefaultView.ToTable(True)
                            For j As Integer = 0 To tblRaw.Rows.Count - 1
                                If Not dictAbnormalPoints.Keys.Contains(tblRaw.Rows(j)("THD_TIMESTAMP")) Then
                                    dictAbnormalPoints.Add(tblRaw.Rows(j)("THD_TIMESTAMP"), tblRaw.Rows(j)("THD_HF_RATIO"))
                                End If
                            Next
                            For j As Short = 0 To tblSlab.Rows.Count - 1
                                If j > 0 Then
                                    strDashedVerticalLine &= ","
                                    strBlankDots &= ","
                                End If
                                If i > 0 Then
                                    If j > 0 Then
                                        strDashedVerticalLine = strDashedVerticalLine.Remove(strDashedVerticalLine.LastIndexOf(","))
                                        strBlankDots = strBlankDots.Remove(strBlankDots.LastIndexOf(","))
                                    End If
                                    strDashedVerticalLine &= ","
                                    strBlankDots &= ","
                                End If
                                strDashedVerticalLine &= "{dashedVerticalLine: { name: '" & tblSlab.Rows(j)("SLAB_ID") & "', x: new Date('" & CDate(tblSlab.Rows(j)("PROD_START")).ToString("yyyy-MM-dd HH:mm:ss") & "'), lineWidth: 1, yOffset: '14', color: 'rgba(7, 17, 29, 0.49)', shadow: false, showTooltip: true, tooltipFormatString:'<table style=""background-color:#77F486; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>Slab Id</td><td>:</td><td>&nbsp;</td><td>" & tblSlab.Rows(j)("SLAB_ID") & "</td></tr></table>' }}"
                                strBlankDots &= "['" & CDate(tblSlab.Rows(j)("PROD_START")) & "', 0]"
                            Next
                        End If
                    End If
                Next
            End If
        End Using
        strBlankDots &= "];"
        Dim strXMinMax As String = "min: '" & FromDate & "', max: '" & ToDate & "',"
        'If dictRedPoints.Count > 0 Then
        '    strXMinMax = "min: '" & FromDate & "', max: '" & ToDate & "',"
        'End If
        Dim k As Integer = 0
        Dim strRedDataArray As String = "var lineRed = ["
        For Each timestamp As String In dictAbnormalPoints.Keys
            If k > 0 Then
                strRedDataArray &= ", "
            End If
            strRedDataArray &= "['" & timestamp & "', " & dictAbnormalPoints.Item(timestamp) & "]"
            k = k + 1
        Next
        strRedDataArray &= "];"

        Dim noDataIndicator As String = ""
        If Not slabIdPresent Then
            noDataIndicator = "noDataIndicator: { show: true, indicator: 'No data found.' },"
            strXMinMax = ""
        End If

        Dim strDataArrays As String = strRedDataArray & vbCrLf & vbCrLf
        Dim strDataVariables As String = "lineRed"
        Dim strSeriesColours As String = "'#FF0000'"
        Dim strDefaultProperties As String = "pointLabels: { show:false }, showLine: false, lineWidth: 2, showTooltip: false, showMarker:true, markerOptions: { shadow: false, style: 'filledCircle', size: 4 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 1,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>%s</td><td>,</td><td>&nbsp;</td><td>%s</td></tr></table>'}"
        Dim strLegends As String = "legend:{show:true, seriesToggle: false, placement: 'outsideGrid', rendererOptions: {marginTop: 10, numberRows: 1 }, textColor: '#000000', fontSize: '12px', location: 's', labels: ['Ratio greater than 90% OR less than 70%'], renderer: $.jqplot.EnhancedLegendRenderer },"
        If dictAbnormalPoints.Count = 0 Then
            strDataArrays &= strBlankDots & vbCrLf & vbCrLf
            strDataVariables = "blank"
            strSeriesColours = "'#FFFFFF'"
            strDefaultProperties = "pointLabels: { show:false }, markerOptions: { shadow: false }, showLine: false, lineWidth: 0, showTooltip: false, showMarker:false, highlighter: {show: false,showMarker: false,tooltipAxes:'xy',yvalues: 1,formatString: '<table style=""display: none; background-color:#FFFDBF; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>%s</td><td>,</td><td>&nbsp;</td><td>%s</td></tr></table>'}"
            strLegends = ""
        End If

        'Dim strDefaultProperties As String = "pointLabels: { show:false }, shadow: false, showLine: false, lineWidth: 2, showTooltip: false, showMarker:true, markerOptions: { style: 'filledCircle', size: 6 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 1,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>%s</td><td>,</td><td>&nbsp;</td><td>%s</td></tr></table>'}"
        Dim js As String = "<script id='" & ScriptName & "' language='javascript' type='text/javascript'>" & vbCrLf & _
                           "$.jqplot.config.enablePlugins = true;" & vbCrLf & _
                           strDataArrays & _
                           PlotName & " = $.jqplot('" & ContainerName & "', [" & strDataVariables & "], {" & vbCrLf & _
                           "axesDefaults: { tickRenderer: $.jqplot.CanvasAxisTickRenderer, tickOptions: {textColor: '#000000', fontSize: '9pt', showGridline: false}}," & vbCrLf & _
                           "seriesDefaults: {" & strDefaultProperties & "}," & vbCrLf & _
                           "seriesColors:[" & strSeriesColours & "]," & vbCrLf & _
                           "axes: {" & vbCrLf & _
                           "xaxis: {" & vbCrLf & _
                           strXMinMax & _
                           "tickOptions:{formatString:'%d-%b %H:%M:%S', angle: -30}," & vbCrLf & _
                           "renderer:$.jqplot.DateAxisRenderer," & vbCrLf & _
                           "label: ''" & vbCrLf & _
                           "}," & vbCrLf & _
                           "yaxis: {" & vbCrLf & _
                           "//tickOptions:{formatString:'%.4f'}," & vbCrLf & _
                           "labelOptions: {textColor: '#000000'}," & vbCrLf & _
                           "label: 'Heat Flux (%)'," & vbCrLf & _
                           "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf & _
                           "}" & vbCrLf & _
                           "}," & vbCrLf & _
                           "animate: true," & vbCrLf & _
                           "title: ''," & vbCrLf & _
                           "cursor: {" & vbCrLf & _
                           "zoom: true, showTooltip: false" & vbCrLf & _
                           "}," & vbCrLf & _
                           noDataIndicator & vbCrLf & _
                           "canvasOverlay: {show: true, objects: [" & strDashedVerticalLine & "]}," & vbCrLf & _
                           strLegends & vbCrLf & _
                           "grid: {backgroundColor: 'rgb(255,255,255)'}" & vbCrLf & _
                           "});" & vbCrLf & _
                           "</script>"
        Context.Response.Write(js)
    End Sub

    <WebMethod()>
    Public Sub FnSenDepthPlot(ByVal FromDate As String, ByVal ToDate As String, ByVal Caster As String, ByVal ContainerName As String, ByVal ScriptName As String, ByVal PlotName As String)
        Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString
        Dim strDashedVerticalLine As String = ""
        Dim dictRedPoints As New Dictionary(Of String, Decimal)
        Dim tblFinal As New DataTable
        tblFinal.Columns.Add("file")
        tblFinal.Columns.Add("timestamp")
        tblFinal.Columns.Add("depth")
        Dim strBlankDots As String = "var blank = ["
        Dim slabIdPresent As Boolean = False
        Using sqlCon = New SqlConnection(strConnectionString)
            Dim tblHeat As New DataTable
            Dim iCaster As String = IIf(Caster = "1", "11", "12")
            Using sqlDa = New SqlDataAdapter("SELECT HEAT_ID_MSG6 AS HEAT_ID,DATETIME AS START_TIME, DATE_MSG6_CREATE AS END_TIME, DEVICE_KEY FROM TSCR_CCC_HEAT_RAW INNER JOIN TSCR_CC_HEAT_MASTER ON TSCR_CCC_HEAT_RAW.HEAT_ID_MSG6=TSCR_CC_HEAT_MASTER.PRODUCTION_KEY WHERE DATETIME >= '" & FromDate & "' AND DATE_MSG6_CREATE <= '" & ToDate & "' AND DEVICE_KEY = '" & iCaster & "'", sqlCon)
                sqlDa.Fill(tblHeat)
            End Using
            If tblHeat.Rows.Count > 0 Then
                For i As Short = 0 To tblHeat.Rows.Count - 1
                    Dim dtStart As DateTime = CDate(tblHeat.Rows(i)("START_TIME")).AddMinutes(-10) 'Subracting 10 minutes, as discussed with Arup.
                    Dim dtEnd As DateTime = tblHeat.Rows(i)("END_TIME")
                    iCaster = IIf(Caster = "1", "13", "14")
                    Dim tblSlab As New DataTable
                    Using sqlDa = New SqlDataAdapter("SELECT TSM_SLAB_ID AS SLAB_ID,TSM_PROD_START AS PROD_START,TSM_PROD_END AS PROD_END,TSR_SLAB_THICKNESS AS THICKNESS FROM TSCR_SLAB_MASTER INNER JOIN TSCR_SLAB_RAW ON TSCR_SLAB_MASTER.TSM_SLAB_ID=TSCR_SLAB_RAW.TSR_SLAB_ID WHERE TSM_PROD_START >= '" & dtStart.ToString("yyyy-MM-dd HH:mm:ss") & "' AND TSM_PROD_END <= '" & dtEnd.ToString("yyyy-MM-dd HH:mm:ss") & "' AND TSM_DEVICE_KEY='" & iCaster & "'", sqlCon)
                        sqlDa.Fill(tblSlab)
                    End Using
                    If tblSlab.Rows.Count > 0 Then
                        If Not slabIdPresent Then
                            slabIdPresent = True
                        End If
                        Dim dvTemp As DataView = tblSlab.DefaultView
                        dvTemp.Sort = "PROD_START ASC"
                        tblSlab = dvTemp.ToTable
                        Dim heatIdPattern As String = tblHeat.Rows(i)("HEAT_ID").ToString().Substring(1)
                        dvTemp.RowFilter = ""
                        dvTemp = Nothing
                        dvTemp = tblSlab.DefaultView
                        dvTemp.RowFilter = "SLAB_ID LIKE '%" & heatIdPattern & "%'"
                        tblSlab = dvTemp.ToTable
                        If tblSlab.Rows.Count > 0 Then
                            Dim strStart As String = CDate(tblSlab.Rows(0)("PROD_START")).ToString("yyyy-MM-dd HH:mm:ss")
                            Dim strEnd As String = CDate(tblSlab.Rows(tblSlab.Rows.Count - 1)("PROD_END")).ToString("yyyy-MM-dd HH:mm:ss")
                            Dim tblRaw As DataTable = GetRawSenDepthData(strStart, strEnd, Caster, sqlCon)
                            tblRaw = tblRaw.DefaultView.ToTable(True)
                            For j As Integer = 0 To tblRaw.Rows.Count - 1
                                If Not dictRedPoints.Keys.Contains(tblRaw.Rows(j)("TSD_TIMESTAMP")) Then
                                    Dim row As DataRow = tblFinal.NewRow
                                    row("file") = tblRaw.Rows(j)("TSD_FILENAME")
                                    row("timestamp") = tblRaw.Rows(j)("TSD_TIMESTAMP")
                                    row("depth") = tblRaw.Rows(j)("TSD_SEN_DEPTH")
                                    tblFinal.Rows.Add(row)
                                    dictRedPoints.Add(tblRaw.Rows(j)("TSD_TIMESTAMP"), tblRaw.Rows(j)("TSD_SEN_DEPTH"))
                                End If
                            Next
                            For j As Short = 0 To tblSlab.Rows.Count - 1
                                If j > 0 Then
                                    strDashedVerticalLine &= ","
                                    strBlankDots &= ","
                                End If
                                If i > 0 Then
                                    If j > 0 Then
                                        strDashedVerticalLine = strDashedVerticalLine.Remove(strDashedVerticalLine.LastIndexOf(","))
                                        strBlankDots = strBlankDots.Remove(strBlankDots.LastIndexOf(","))
                                    End If
                                    strDashedVerticalLine &= ","
                                    strBlankDots &= ","
                                End If
                                strDashedVerticalLine &= "{dashedVerticalLine: { name: '" & tblSlab.Rows(j)("SLAB_ID") & "', x: new Date('" & CDate(tblSlab.Rows(j)("PROD_START")).ToString("yyyy-MM-dd HH:mm:ss") & "'), lineWidth: 1, yOffset: '14', color: 'rgba(7, 17, 29, 0.49)', shadow: false, showTooltip: true, tooltipFormatString:'<table style=""background-color:#77F486; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>Slab Id</td><td>:</td><td>&nbsp;</td><td>" & tblSlab.Rows(j)("SLAB_ID") & "</td></tr></table>' }}"
                                strBlankDots &= "['" & CDate(tblSlab.Rows(j)("PROD_START")) & "', 0]"
                            Next
                        End If
                    End If
                Next
            End If
        End Using
        strBlankDots &= "];"
        Dim strXMinMax As String = "min: '" & FromDate & "', max: '" & ToDate & "',"
        'If dictRedPoints.Count > 0 Then
        '    strXMinMax = "min: '" & FromDate & "', max: '" & ToDate & "',"
        'End If
        Dim strDataVariables As String = ""
        Dim arrFiles() As String = (From row In tblFinal Select col = row.Field(Of String)("file") Distinct).ToArray
        Dim strDataPoints As String = ""
        For i As Short = 0 To arrFiles.Length - 1
            If i > 0 Then
                strDataVariables &= ", "
            End If
            strDataVariables &= "line" & (i + 1)
            Dim x = i
            strDataPoints &= "var line" & (i + 1) & " = ["
            Dim tblTemp As DataTable = (From val In tblFinal.AsEnumerable() Where val.Field(Of String)("file") = arrFiles(x) Select val).CopyToDataTable
            For j As Short = 0 To tblTemp.Rows.Count - 1
                If j > 0 Then
                    strDataPoints &= ", "
                End If
                strDataPoints &= "['" & tblTemp.Rows(j)("timestamp") & "', " & tblTemp.Rows(j)("depth") & "]"
            Next
            strDataPoints &= "];" & vbCrLf & vbCrLf
        Next
        Dim k As Integer = 0
        Dim strRedDataArray As String = "var lineRed = ["
        For Each timestamp As String In dictRedPoints.Keys
            If k > 0 Then
                strRedDataArray &= ", "
            End If
            strRedDataArray &= "['" & timestamp & "', " & dictRedPoints.Item(timestamp) & "]"
            k = k + 1
        Next
        strRedDataArray &= "];"

        Dim noDataIndicator As String = ""
        If Not slabIdPresent Then
            noDataIndicator = "noDataIndicator: { show: true, indicator: 'No data found.' },"
            strXMinMax = ""
        End If

        'Dim strDataArrays As String = strRedDataArray & vbCrLf & vbCrLf
        Dim strDataArrays As String = strDataPoints & vbCrLf & vbCrLf

        Dim strSeriesColours As String = "'#FF0000'"
        Dim strDefaultProperties As String = "pointLabels: { show:false }, showLine: true, lineWidth: 2, showTooltip: false, showMarker:true, markerOptions: { shadow: false, style: 'dash', size: 16 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 1,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>%s</td><td>,</td><td>&nbsp;</td><td>%s</td></tr></table>'}"
        Dim strLegends As String = "legend:{show:true, seriesToggle: false, placement: 'outsideGrid', rendererOptions: {marginTop: 10, numberRows: 1 }, textColor: '#000000', fontSize: '12px', location: 's', labels: ['Sen Depth'], renderer: $.jqplot.EnhancedLegendRenderer },"
        If dictRedPoints.Count = 0 Then
            strDataArrays &= strBlankDots & vbCrLf & vbCrLf
            strDataVariables = "blank"
            strSeriesColours = "'#FFFFFF'"
            strDefaultProperties = "pointLabels: { show:false }, markerOptions: { shadow: false }, step: true, showLine: false, lineWidth: 0, showTooltip: false, showMarker:false, highlighter: {show: false,showMarker: false,tooltipAxes:'xy',yvalues: 1,formatString: '<table style=""display: none; background-color:#FFFDBF; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>%s</td><td>,</td><td>&nbsp;</td><td>%s</td></tr></table>'}"
        End If
        strLegends = ""
        'Dim strDefaultProperties As String = "pointLabels: { show:false }, shadow: false, showLine: false, lineWidth: 2, showTooltip: false, showMarker:true, markerOptions: { style: 'filledCircle', size: 6 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 1,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>%s</td><td>,</td><td>&nbsp;</td><td>%s</td></tr></table>'}"
        Dim js As String = "<script id='" & ScriptName & "' language='javascript' type='text/javascript'>" & vbCrLf & _
                           "$.jqplot.config.enablePlugins = true;" & vbCrLf & _
                           strDataArrays & _
                           PlotName & " = $.jqplot('" & ContainerName & "', [" & strDataVariables & "], {" & vbCrLf & _
                           "axesDefaults: { tickRenderer: $.jqplot.CanvasAxisTickRenderer, tickOptions: {textColor: '#000000', fontSize: '9pt', showGridline: false}}," & vbCrLf & _
                           "seriesDefaults: {" & strDefaultProperties & "}," & vbCrLf & _
                           "seriesColors: ['#4C4ED8','#EF3862','#8A1EEE','#0982EC','#0FBDE3','#043D1D','#059B11','#E1EB05','#666699','#F4ED03','#EF8355','#818181','#FFA500', '#006400','#F10000','#996633','#ECAE06','#009999','#800000','#F05904']," & vbCrLf & _
                           "axes: {" & vbCrLf & _
                           "xaxis: {" & vbCrLf & _
                           strXMinMax & _
                           "tickOptions:{formatString:'%d-%b %H:%M:%S', angle: -30}," & vbCrLf & _
                           "renderer:$.jqplot.DateAxisRenderer," & vbCrLf & _
                           "label: ''" & vbCrLf & _
                           "}," & vbCrLf & _
                           "yaxis: {" & vbCrLf & _
                           "//tickOptions:{formatString:'%.4f'}," & vbCrLf & _
                           "labelOptions: {textColor: '#000000'}," & vbCrLf & _
                           "label: 'SEN Depth (mm)'," & vbCrLf & _
                           "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf & _
                           "}" & vbCrLf & _
                           "}," & vbCrLf & _
                           "animate: true," & vbCrLf & _
                           "title: ''," & vbCrLf & _
                           "cursor: {" & vbCrLf & _
                           "zoom: true, showTooltip: false" & vbCrLf & _
                           "}," & vbCrLf & _
                           noDataIndicator & vbCrLf & _
                           "canvasOverlay: {show: true, objects: [" & strDashedVerticalLine & "]}," & vbCrLf & _
                           strLegends & vbCrLf & _
                           "grid: {backgroundColor: 'rgb(255,255,255)'}" & vbCrLf & _
                           "});" & vbCrLf & _
                           "</script>"
        Context.Response.Write(js)
    End Sub

    Function GetGrade(ByVal NB As Decimal, ByVal TI As Decimal, ByVal V As Decimal, ByVal B As Decimal) As String
        Dim Grade As String = ""
        If NB >= 0.01 And TI >= 0.008 And V < 0.01 And B < 0.0008 Then
            Grade = "Nb-Ti"
        ElseIf NB >= 0.01 And TI >= 0.008 And V < 0.01 And B >= 8 Then
            Grade = "Nb_Ti_B"
        ElseIf TI >= 0.01 And NB < 0.01 And V < 0.01 And B < 0.0008 Then
            Grade = "Only_Ti_High"
        ElseIf TI >= 0.01 And NB < 0.01 And V < 0.01 And B >= 0.0008 Then
            Grade = "Ti_High_B"
        ElseIf V >= 0.02 And NB < 0.01 And TI < 0.008 And B < 0.0008 Then
            Grade = "Only_V"
        ElseIf V >= 0.02 And NB < 0.01 And TI < 0.008 And B >= 0.0008 Then
            Grade = "V_B"
        ElseIf NB >= 0.01 And V < 0.01 And TI < 0.008 And B < 0.0008 Then
            Grade = "Only_Nb"
        ElseIf NB >= 0.01 And V < 0.01 And TI < 0.008 And B >= 0.0008 Then
            Grade = "Nb_B"
        ElseIf NB >= 0.01 And V >= 0.02 And TI < 0.008 And B < 0.0008 Then
            Grade = "Nb_V"
        ElseIf NB >= 0.01 And V >= 0.02 And TI < 0.008 And B >= 0.0008 Then
            Grade = "Nb_V_B"
        ElseIf TI >= 0.008 And TI < 0.01 And NB < 0.01 And V < 0.01 And B < 0.0008 Then
            Grade = "Only_Ti_Low"
        ElseIf TI >= 0.008 And TI < 0.01 And NB < 0.01 And V < 0.01 And B >= 0.0008 Then
            Grade = "Ti_Low_B"
        ElseIf NB < 0.01 And V < 0.01 And TI < 0.008 And B < 0.0008 Then
            Grade = "Al_N2"
        ElseIf B >= 0.0008 And NB < 0.01 And V < 0.01 And TI < 0.01 Then
            Grade = "Only_B"
        ElseIf V >= 0.02 And NB < 0.01 And TI >= 0.008 And B < 0.0008 Then
            Grade = "V_Ti"
        ElseIf V >= 0.02 And NB < 0.01 And TI >= 0.008 And B >= 0.0008 Then
            Grade = "V_Ti_B"
        ElseIf NB >= 0.01 And TI >= 0.008 And V >= 0.02 And B < 0.0008 Then
            Grade = "Nb_Ti_V"
        ElseIf NB >= 0.01 And TI >= 0.008 And V >= 0.02 And B >= 0.0008 Then
            Grade = "Nb_Ti_V_B"
        End If
        Return Grade
    End Function

    <WebMethod()>
    Public Sub FnPrepareTreeData(ByVal FromDate As String, ByVal ToDate As String)
        Dim strConnection As String = ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString
        Dim tblTreeData As New DataTable
        tblTreeData.Columns.Add("time")
        tblTreeData.Columns.Add("caster")
        tblTreeData.Columns.Add("grade")
        tblTreeData.Columns.Add("heat")
        tblTreeData.Columns.Add("slab")
        Using sqlCon = New SqlConnection(strConnection)
            Dim tblHeat As New DataTable
            Using sqlDa = New SqlDataAdapter("SELECT HEAT_ID_MSG6 AS HEAT_ID,DATETIME AS START_TIME, DATE_MSG6_CREATE AS END_TIME, (CASE WHEN DEVICE_KEY = '11' THEN '1' ELSE '2' END) AS CASTER, NB, TI, V, B FROM TSCR_CCC_HEAT_RAW HR INNER JOIN TSCR_CC_HEAT_MASTER HM ON HR.HEAT_ID_MSG6=HM.PRODUCTION_KEY INNER JOIN TSCR_TUNDISH_ANALYSIS TA ON HR.HEAT_ID_MSG6=TA.CAST_NO WHERE DATETIME >= '" & FromDate & "' AND DATE_MSG6_CREATE <= '" & ToDate & "'  ORDER BY DEVICE_KEY ASC, DATETIME DESC", sqlCon)
                sqlDa.Fill(tblHeat)
            End Using
            If tblHeat.Rows.Count > 0 Then
                For i As SByte = 0 To tblHeat.Rows.Count - 1
                    Dim strGrade As String = "" 'tblHeat.Rows(i)("HEAT_ID")
                    Dim nb As Decimal = tblHeat.Rows(i)("NB")
                    Dim ti As Decimal = tblHeat.Rows(i)("TI")
                    Dim v As Decimal = tblHeat.Rows(i)("V")
                    Dim b As Decimal = tblHeat.Rows(i)("B")
                    strGrade = GetGrade(nb, ti, v, b)
                    Dim dtStart As DateTime = CDate(tblHeat.Rows(i)("START_TIME")).AddMinutes(-10) 'Subracting 10 minutes, as discussed with Arup.
                    Dim dtEnd As DateTime = tblHeat.Rows(i)("END_TIME")

                    Dim tblSlab As New DataTable
                    Using sqlDa = New SqlDataAdapter("SELECT TSM_SLAB_ID AS SLAB_ID,TSM_PROD_START AS PROD_START,TSM_PROD_END AS PROD_END,TSR_SLAB_THICKNESS AS THICKNESS FROM TSCR_SLAB_MASTER INNER JOIN TSCR_SLAB_RAW ON TSCR_SLAB_MASTER.TSM_SLAB_ID=TSCR_SLAB_RAW.TSR_SLAB_ID WHERE TSM_PROD_START >= '" & dtStart.ToString("yyyy-MM-dd HH:mm:ss") & "' AND TSM_PROD_END <= '" & dtEnd.ToString("yyyy-MM-dd HH:mm:ss") & "'", sqlCon)
                        sqlDa.Fill(tblSlab)
                    End Using
                    If tblSlab.Rows.Count > 0 Then
                        Dim dvTemp As DataView = tblSlab.DefaultView
                        dvTemp.Sort = "PROD_START ASC"
                        tblSlab = dvTemp.ToTable
                        Dim heatIdPattern As String = tblHeat.Rows(i)("HEAT_ID").ToString().Substring(1)
                        dvTemp.RowFilter = ""
                        dvTemp = Nothing
                        dvTemp = tblSlab.DefaultView
                        dvTemp.RowFilter = "SLAB_ID LIKE '%" & heatIdPattern & "%'"
                        tblSlab = dvTemp.ToTable
                        If tblSlab.Rows.Count > 0 Then
                            For j As SByte = 0 To tblSlab.Rows.Count - 1
                                Dim row As DataRow = tblTreeData.NewRow
                                row("time") = FromDate & " To " & ToDate
                                row("caster") = "Caster " & tblHeat.Rows(i)("CASTER")
                                row("grade") = strGrade
                                row("heat") = tblHeat.Rows(i)("HEAT_ID")
                                row("slab") = tblSlab.Rows(j)("SLAB_ID")
                                tblTreeData.Rows.Add(row)
                            Next
                        Else
                            Dim row As DataRow = tblTreeData.NewRow
                            row("time") = FromDate & " To " & ToDate
                            row("caster") = "Caster " & tblHeat.Rows(i)("CASTER")
                            row("grade") = strGrade
                            row("heat") = tblHeat.Rows(i)("HEAT_ID")
                            row("slab") = ""
                            tblTreeData.Rows.Add(row)
                        End If
                    End If
                Next
            End If
        End Using
        If tblTreeData.Rows.Count > 0 Then
            Dim arrCriticalSlabs As New ArrayList
            Dim strJSON As String = "{ ""name"": ""Root"", ""children"": [" 'START
            Dim arrCasters() As String = (From val In tblTreeData.AsEnumerable() Select val.Field(Of String)("caster") Distinct).ToArray
            For i As SByte = 0 To arrCasters.Length - 1
                If i > 0 Then
                    strJSON &= ", "
                End If
                strJSON &= "{ ""name"": """ & arrCasters(i) & """, ""children"": ["
                Dim x = i
                Dim arrGrades() As String = (From val In tblTreeData.AsEnumerable().Where(Function(row) row.Field(Of String)("caster") = arrCasters(x)) Select val.Field(Of String)("grade") Distinct).ToArray
                For j As SByte = 0 To arrGrades.Length - 1
                    If j > 0 Then
                        strJSON &= ", "
                    End If
                    strJSON &= "{ ""name"": """ & arrGrades(j) & """, ""children"": ["
                    Dim y = j
                    Dim arrHeats() As String = (From val In tblTreeData.AsEnumerable().Where(Function(row) row.Field(Of String)("caster") = arrCasters(x) And row.Field(Of String)("grade") = arrGrades(y)) Select val.Field(Of String)("heat") Distinct).ToArray
                    For k As SByte = 0 To arrHeats.Length - 1
                        If k > 0 Then
                            strJSON &= ", "
                        End If
                        strJSON &= "{ ""name"": """ & arrHeats(k) & """, ""children"": ["
                        Dim z = k
                        Dim arrSlabs() As String = (From val In tblTreeData.AsEnumerable().Where(Function(row) row.Field(Of String)("caster") = arrCasters(x) And row.Field(Of String)("grade") = arrGrades(y) And row.Field(Of String)("heat") = arrHeats(z)) Select val.Field(Of String)("slab") Distinct).ToArray
                        For l As SByte = 0 To arrSlabs.Length - 1
                            If l > 0 Then
                                strJSON &= ", "
                            End If
                            strJSON &= "{ ""name"": """ & arrSlabs(l) & """, ""size"": 1 }"
                        Next
                        strJSON &= "]}"
                    Next
                    strJSON &= "]}"
                Next
                strJSON &= "]}"
            Next
            strJSON &= "]}" 'END
            If File.Exists(Server.MapPath("~\tree.json")) Then
                File.Delete(Server.MapPath("~\tree.json"))
            End If
            File.WriteAllText(Server.MapPath("~\tree.json"), strJSON)
        Else
            File.Delete(Server.MapPath("~\tree.json"))
            Context.Response.Write("No heat details found between the dates.")
        End If
    End Sub

    <WebMethod()>
    Public Sub FnGetStartEnd(ByVal Id As String)

        Dim strStartEnd As String = ""
        Dim strStartslabid As String = ""
        Dim strEndslabid As String = ""
        Dim query As String = ""
        If Id.Length = 6 And Id.Substring(0, 1) = "T" Then
            query = "SELECT DATETIME,DATE_MSG6_CREATE FROM TSCR_CCC_HEAT_RAW WHERE HEAT_ID_MSG6 = '" & Id & "'"
        Else
            query = "SELECT TSM_PROD_START,TSM_PROD_END FROM TSCR_SLAB_MASTER WHERE TSM_SLAB_ID = '" & Id & "'"
        End If
        Dim tbl As New DataTable
        Using sqlCon = New SqlConnection(ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString)
            Using sqlDa = New SqlDataAdapter(query, sqlCon)
                sqlDa.Fill(tbl)
            End Using
        End Using




        If tbl.Rows.Count > 0 Then
            strStartEnd = CDate(tbl.Rows(0)(0)).ToString("yyyy-MM-dd+HH:mm:ss") & "," & CDate(tbl.Rows(0)(1)).ToString("yyyy-MM-dd+HH:mm:ss")
        End If
        Context.Response.Write(strStartEnd)
    End Sub

    Public Function GetSlabStartEnd(ByVal Id As String) As String
        Dim ds As New DataSet()
        Dim strStartEnd As String = ""
        Dim strStartslabid As String = ""
        Dim strEndslabid As String = ""
        Dim query As String = "SELECT TSM_PROD_START,TSM_PROD_END FROM TSCR_SLAB_MASTER WHERE TSM_SLAB_ID = '" & Id & "'"
        Dim tbl As New DataTable
        Using sqlCon = New SqlConnection(ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString)
            Using sqlDa = New SqlDataAdapter(query, sqlCon)
                sqlDa.Fill(tbl)
            End Using
        End Using



        If tbl.Rows.Count > 0 Then
            strStartEnd = CDate(tbl.Rows(0)(0)).ToString("yyyy-MM-dd HH:mm:ss") & "," & CDate(tbl.Rows(0)(1)).ToString("yyyy-MM-dd HH:mm:ss")
        End If
        Return strStartEnd
    End Function

    '<WebMethod()>
    'Public Sub FnBoxPlotForEChart(ByVal FromDate As String, ByVal ToDate As String, ByVal Caster As String)
    '    Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("LPTGSQLDEV").ConnectionString
    '    Using sqlCon = New SqlConnection(strConnectionString)
    '        Dim arrListAllGrades As New ArrayList
    '        Dim dt As New DataTable
    '        Dim oraQuery = ""
    '        Dim casterCondition As String = IIf(Caster = 1, " AND SUBSTR(CC_SEQU_ID4,0,2)=''81''", " AND SUBSTR(CC_SEQU_ID4,0,2)=''82''")
    '        Using sqlDa = New SqlDataAdapter("SELECT * FROM OPENQUERY(TSCR_DSC_ORACLE, 'SELECT DATETIME,CC_DSC_TEMP1,CC_DSC_TEMP2,CC_DSC_TEMP3,CC_DSC_TEMP4,CC_DSC_TEMP5,CC_DSC_TEMP6,CC_DSC_TEMP7,CC_DSC_TEMP8,CC_DSC_TEMP9 FROM CCC_DSC_RAW where to_char(DATETIME, ''YYYY-MM-DD HH24:MI:SS'') >=''" & FromDate & "'' AND to_char(datetime, ''YYYY-MM-DD HH24:MI:SS'') <= ''" & ToDate & "''" & casterCondition & "');", sqlCon)
    '            sqlDa.Fill(dt)
    '        End Using
    '        If dt.Rows.Count > 0 Then
    '            Dim strTemp1 As String = dt.AsEnumerable().Select(Function(col) col.Field(Of Object)("CC_DSC_TEMP1")).Aggregate(Function(s1, s2) String.Concat(s1, ",", s2))
    '            Dim strTemp2 As String = dt.AsEnumerable().Select(Function(col) col.Field(Of Object)("CC_DSC_TEMP2")).Aggregate(Function(s1, s2) String.Concat(s1, ",", s2))
    '            Dim strTemp3 As String = dt.AsEnumerable().Select(Function(col) col.Field(Of Object)("CC_DSC_TEMP3")).Aggregate(Function(s1, s2) String.Concat(s1, ",", s2))
    '            Dim strTemp4 As String = dt.AsEnumerable().Select(Function(col) col.Field(Of Object)("CC_DSC_TEMP4")).Aggregate(Function(s1, s2) String.Concat(s1, ",", s2))
    '            Dim strTemp5 As String = dt.AsEnumerable().Select(Function(col) col.Field(Of Object)("CC_DSC_TEMP5")).Aggregate(Function(s1, s2) String.Concat(s1, ",", s2))
    '            Dim strTemp6 As String = dt.AsEnumerable().Select(Function(col) col.Field(Of Object)("CC_DSC_TEMP6")).Aggregate(Function(s1, s2) String.Concat(s1, ",", s2))
    '            Dim strTemp7 As String = dt.AsEnumerable().Select(Function(col) col.Field(Of Object)("CC_DSC_TEMP7")).Aggregate(Function(s1, s2) String.Concat(s1, ",", s2))
    '            Dim strTemp8 As String = dt.AsEnumerable().Select(Function(col) col.Field(Of Object)("CC_DSC_TEMP8")).Aggregate(Function(s1, s2) String.Concat(s1, ",", s2))
    '            Dim strTemp9 As String = dt.AsEnumerable().Select(Function(col) col.Field(Of Object)("CC_DSC_TEMP9")).Aggregate(Function(s1, s2) String.Concat(s1, ",", s2))
    '            Dim strData As String = strTemp1 & "@" & strTemp2 & "@" & strTemp3 & "@" & strTemp4 & "@" & strTemp5 & "@" & strTemp6 & "@" & strTemp7 & "@" & strTemp8 & "@" & strTemp9
    '            Context.Response.Write(strData)
    '        End If
    '    End Using
    'End Sub

    <WebMethod()>
    Public Sub FnBoxPlotForEChart(ByVal FromDate As String, ByVal ToDate As String, ByVal Caster As String, ByVal Type As String)
        Dim strData As String = ""
        Dim strData_Zone9 As String = ""
        Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("IPQSDB").ConnectionString
        Using oleCon = New OleDbConnection(strConnectionString)
            Dim dt As New DataTable
            Dim casterCondition As String = IIf(Caster = 1, " AND SUBSTR(CC_SEQU_ID4,0,2)='81'", " AND SUBSTR(CC_SEQU_ID4,0,2)='82'")
            Using oleDa = New OleDbDataAdapter("SELECT DATETIME,CC_DSC_TEMP1,CC_DSC_TEMP2,CC_DSC_TEMP3,CC_DSC_TEMP4,CC_DSC_TEMP5,CC_DSC_TEMP6,CC_DSC_TEMP7,CC_DSC_TEMP8,CC_DSC_TEMP9 FROM CCC_DSC_RAW where to_char(DATETIME, 'YYYY-MM-DD HH24:MI:SS') >='" & FromDate & "' AND to_char(datetime, 'YYYY-MM-DD HH24:MI:SS') <= '" & ToDate & "'" & casterCondition, oleCon)
                oleDa.Fill(dt)
            End Using
            If dt.Rows.Count > 0 Then
                Dim strTemp1 As String = dt.AsEnumerable().Select(Function(col) col.Field(Of Object)("CC_DSC_TEMP1")).Aggregate(Function(s1, s2) String.Concat(s1, ",", s2))
                Dim strTemp2 As String = dt.AsEnumerable().Select(Function(col) col.Field(Of Object)("CC_DSC_TEMP2")).Aggregate(Function(s1, s2) String.Concat(s1, ",", s2))
                Dim strTemp3 As String = dt.AsEnumerable().Select(Function(col) col.Field(Of Object)("CC_DSC_TEMP3")).Aggregate(Function(s1, s2) String.Concat(s1, ",", s2))
                Dim strTemp4 As String = dt.AsEnumerable().Select(Function(col) col.Field(Of Object)("CC_DSC_TEMP4")).Aggregate(Function(s1, s2) String.Concat(s1, ",", s2))

                Dim strTemp5 As String = dt.AsEnumerable().Select(Function(col) col.Field(Of Object)("CC_DSC_TEMP5")).Aggregate(Function(s1, s2) String.Concat(s1, ",", s2))
                Dim strTemp6 As String = dt.AsEnumerable().Select(Function(col) col.Field(Of Object)("CC_DSC_TEMP6")).Aggregate(Function(s1, s2) String.Concat(s1, ",", s2))
                Dim strTemp7 As String = dt.AsEnumerable().Select(Function(col) col.Field(Of Object)("CC_DSC_TEMP7")).Aggregate(Function(s1, s2) String.Concat(s1, ",", s2))
                Dim strTemp8 As String = dt.AsEnumerable().Select(Function(col) col.Field(Of Object)("CC_DSC_TEMP8")).Aggregate(Function(s1, s2) String.Concat(s1, ",", s2))
                Dim strTemp9 As String = dt.AsEnumerable().Select(Function(col) col.Field(Of Object)("CC_DSC_TEMP9")).Aggregate(Function(s1, s2) String.Concat(s1, ",", s2))



                strData = strTemp1 & "@" & strTemp2 & "@" & strTemp3 & "@" & strTemp4 & "@" & strTemp5 & "@" & strTemp6 & "@" & strTemp7 & "@" & strTemp8 & "@" & strTemp9
                'Context.Response.Write(strData)
            End If
        End Using
        If Type = "Double" Then
            Using sqlCon = New SqlConnection(ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString)
                Dim dt As New DataTable
                Using sqlDa = New SqlDataAdapter("SELECT TID_ZONE9_TEMP FROM TSCR_IBA_DATA WHERE TID_TIMESTAMP BETWEEN '" & FromDate & "' AND '" & ToDate & "' AND TID_CASTER = 2", sqlCon)
                    sqlDa.Fill(dt)
                End Using
                If dt.Rows.Count > 0 Then
                    Dim arrZero(dt.Rows.Count - 1) As SByte
                    For i As Short = 0 To dt.Rows.Count - 1
                        arrZero(i) = 0
                    Next
                    Dim strTempZero As String = String.Join(",", arrZero)
                    Dim strTemp9 As String = dt.AsEnumerable().Select(Function(col) col.Field(Of Object)("TID_ZONE9_TEMP")).Aggregate(Function(s1, s2) String.Concat(s1, ",", s2))
                    strData_Zone9 = strTempZero & "@" & strTempZero & "@" & strTempZero & "@" & strTempZero & "@" & strTempZero & "@" & strTempZero & "@" & strTempZero & "@" & strTempZero & "@" & strTemp9
                    'Context.Response.Write(strData)
                End If
            End Using
        End If
        If Trim(strData_Zone9) <> "" Then
            Context.Response.Write(strData & "#" & strData_Zone9)
        Else
            Context.Response.Write(strData)
        End If
    End Sub

    <WebMethod()>
    Public Sub FnAlNProductPlot(ByVal HeatIDs As String)
        Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString
        Dim strDataArray As String = "var data = ["
        Dim strTicksAngle As String = ""
        Dim strDataVariable As String = "data"
        Dim strSeriesColour As String = "'#000000'"
        Dim strLegends As String = "legend: {show: true, showSwatches: false, placement: 'outsideGrid', rendererOptions: {marginTop: 10, numberRows: 1, seriesToggle: false }, textColor: '#183B82', fontSize: '12px', location: 's', labels: ['Red: Critical zone (beyond 2.5) | Green: Normal zone (upto 2.5)'], renderer: $.jqplot.EnhancedLegendRenderer },"
        Dim strLegendShow As String = "true"
        Dim ds As New DataSet
        Using sqlCon As New SqlConnection(strConnectionString)
            Using sqlCmd As New SqlCommand
                sqlCmd.CommandText = "USP_GET_HEATWISE_AL_N_PROD"
                sqlCmd.CommandType = CommandType.StoredProcedure
                sqlCmd.Connection = sqlCon
                Dim sqlParam As New SqlParameter
                sqlParam.ParameterName = "@CAST_NO"
                sqlParam.Value = HeatIDs
                sqlParam.DbType = DbType.String
                sqlParam.Direction = ParameterDirection.Input
                sqlCmd.Parameters.Add(sqlParam)
                Using sqlAdapter As New SqlDataAdapter
                    sqlAdapter.SelectCommand = sqlCmd
                    Try
                        sqlCon.Open()
                        sqlCmd.ExecuteNonQuery()
                        sqlCon.Close()
                        sqlAdapter.Fill(ds)
                    Catch ex As Exception

                    Finally
                        sqlCon.Close()
                    End Try
                End Using
            End Using
        End Using
        Dim dt As New DataTable
        dt.Columns.Add("CAST_NO")
        dt.Columns.Add("AL_N_PROD")
        For i As SByte = 0 To ds.Tables.Count - 1
            Dim row As DataRow = dt.NewRow
            row("CAST_NO") = ds.Tables(i).Rows(0)("CAST_NO")
            row("AL_N_PROD") = ds.Tables(i).Rows(0)("AL_N_PROD")
            dt.Rows.Add(row)
        Next
        If dt.Rows.Count > 0 Then
            If dt.Rows.Count >= 10 Then
                strTicksAngle = "angle: -30, "
            End If
            For i As Short = 0 To dt.Rows.Count - 1
                If i > 0 Then
                    strDataArray &= ", "
                End If
                strDataArray &= "['" & dt.Rows(i)("CAST_NO") & "', " & dt.Rows(i)("AL_N_PROD") & "]"
            Next
        Else
            strLegends = ""
        End If
        strDataArray &= "];"

        Dim strDataArrays As String = strDataArray & vbCrLf & vbCrLf
        Dim strDefaultProperties As String = "pointLabels: { show:true }, showLine: false, showTooltip: false, showMarker:true, markerOptions: { shadow: false, style: 'filledCircle', size: 16 }, highlighter: {show: false}"
        Dim strRectanglesObjects As String = "{ rectangle: { ymin: 0, ymax: 2.5, xminOffset: '0px', xmaxOffset: '0px', yminOffset: '0px', ymaxOffset: '0px', color: 'rgba(91, 210, 111, 0.56)', showTooltip: true, tooltipLocation:'e', tooltipFormatString: '<table style=""background-color:#77F486; color: #000000; font-family: verdana; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>Normal zone (between 0 and 2.5)</td></tr></table>' } }, "
        strRectanglesObjects &= "{ rectangle: { ymin: 2.5, ymax: 5.0, xminOffset: '0px', xmaxOffset: '0px', yminOffset: '0px', ymaxOffset: '0px', color: 'rgba(255, 61, 61, 0.56)', showTooltip: true, tooltipLocation:'e', tooltipFormatString: '<table style=""background-color:#FF0000; color: #FFFFFF; font-family: verdana; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>Critical zone (beyond 2.5)</td></tr></table>' } }"

        Dim js As String = "<script id='script1' language='javascript' type='text/javascript'>" & vbCrLf & _
                           "$.jqplot.config.enablePlugins = true;" & vbCrLf & _
                           strDataArrays & _
                           "plot1 = $.jqplot('container1', [" & strDataVariable & "], {" & vbCrLf & _
                           "axesDefaults: { tickRenderer: $.jqplot.CanvasAxisTickRenderer, tickOptions: {textColor: '#000000', fontSize: '9pt'}}," & vbCrLf & _
                           "seriesDefaults: {" & strDefaultProperties & "}," & vbCrLf & _
                           "seriesColors:[" & strSeriesColour & "]," & vbCrLf & _
                           "axes: {" & vbCrLf & _
                           "xaxis: {" & vbCrLf & _
                           "tickOptions:{formatString:'%d-%b %H:%M:%S', " & strTicksAngle & "showGridline: true, fontSize: '10pt'}," & vbCrLf & _
                           "labelOptions: {textColor: '#000000'}," & vbCrLf & _
                           "renderer:$.jqplot.CategoryAxisRenderer," & vbCrLf & _
                           "label: 'Heat Id'" & vbCrLf & _
                           "}," & vbCrLf & _
                           "yaxis: {" & vbCrLf & _
                           "tickOptions: {showGridline: false, formatString:'%.3f'}," & vbCrLf & _
                           "min: 0, max: 5," & vbCrLf & _
                           "labelOptions: {textColor: '#000000'}," & vbCrLf & _
                           "label: 'Al-N Product'," & vbCrLf & _
                           "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf & _
                           "}" & vbCrLf & _
                           "}," & vbCrLf & _
                           "animate: true," & vbCrLf & _
                           "title: ''," & vbCrLf & _
                           "cursor: {" & vbCrLf & _
                           "zoom: false, show: false" & vbCrLf & _
                           "}," & vbCrLf & _
                           "noDataIndicator: { show: true, indicator: 'No data found.' }," & vbCrLf & _
                           "canvasOverlay: {show: true, objects: [" & strRectanglesObjects & "]}," & vbCrLf & _
                           strLegends & vbCrLf & _
                           "grid: {backgroundColor: 'rgb(255,255,255)'}" & vbCrLf & _
                           "});" & vbCrLf & _
                           "</script>"
        Context.Response.Write(js)
    End Sub

    <WebMethod()>
    Public Sub FnPrepareCriticalSlab(ByVal FromDate As String, ByVal ToDate As String)
        Dim strConnection As String = ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString
        Dim tblTreeData As New DataTable
        'tblTreeData.Columns.Add("time")
        tblTreeData.Columns.Add("caster")
        tblTreeData.Columns.Add("grade")
        tblTreeData.Columns.Add("heat")
        tblTreeData.Columns.Add("slab")
        tblTreeData.Columns.Add("slab_start_end")
        Using sqlCon = New SqlConnection(strConnection)
            Dim tblHeat As New DataTable
            Using sqlDa = New SqlDataAdapter("SELECT HEAT_ID_MSG6 AS HEAT_ID,DATETIME AS START_TIME, DATE_MSG6_CREATE AS END_TIME, (CASE WHEN DEVICE_KEY = '11' THEN '1' ELSE '2' END) AS CASTER, NB, TI, V, B FROM TSCR_CCC_HEAT_RAW HR INNER JOIN TSCR_CC_HEAT_MASTER HM ON HR.HEAT_ID_MSG6=HM.PRODUCTION_KEY INNER JOIN TSCR_TUNDISH_ANALYSIS TA ON HR.HEAT_ID_MSG6=TA.CAST_NO WHERE DATETIME >= '" & FromDate & "' AND DATE_MSG6_CREATE <= '" & ToDate & "'  ORDER BY DEVICE_KEY ASC, DATETIME DESC", sqlCon)
                sqlDa.Fill(tblHeat)
            End Using
            If tblHeat.Rows.Count > 0 Then
                For i As SByte = 0 To tblHeat.Rows.Count - 1
                    Dim strGrade As String = "" 'tblHeat.Rows(i)("HEAT_ID")
                    Dim nb As Decimal = tblHeat.Rows(i)("NB")
                    Dim ti As Decimal = tblHeat.Rows(i)("TI")
                    Dim v As Decimal = tblHeat.Rows(i)("V")
                    Dim b As Decimal = tblHeat.Rows(i)("B")
                    strGrade = GetGrade(nb, ti, v, b)
                    Dim dtStart As DateTime = CDate(tblHeat.Rows(i)("START_TIME")).AddMinutes(-10) 'Subracting 10 minutes, as discussed with Arup.
                    Dim dtEnd As DateTime = tblHeat.Rows(i)("END_TIME")
                    Dim tblSlab As New DataTable
                    Using sqlDa = New SqlDataAdapter("SELECT TSM_SLAB_ID AS SLAB_ID,TSM_PROD_START AS PROD_START,TSM_PROD_END AS PROD_END,TSR_SLAB_THICKNESS AS THICKNESS FROM TSCR_SLAB_MASTER INNER JOIN TSCR_SLAB_RAW ON TSCR_SLAB_MASTER.TSM_SLAB_ID=TSCR_SLAB_RAW.TSR_SLAB_ID WHERE TSM_PROD_START >= '" & dtStart.ToString("yyyy-MM-dd HH:mm:ss") & "' AND TSM_PROD_END <= '" & dtEnd.ToString("yyyy-MM-dd HH:mm:ss") & "'", sqlCon)
                        sqlDa.Fill(tblSlab)
                    End Using
                    If tblSlab.Rows.Count > 0 Then
                        Dim dvTemp As DataView = tblSlab.DefaultView
                        dvTemp.Sort = "PROD_START ASC"
                        tblSlab = dvTemp.ToTable
                        Dim heatIdPattern As String = tblHeat.Rows(i)("HEAT_ID").ToString().Substring(1)
                        dvTemp.RowFilter = ""
                        dvTemp = Nothing
                        dvTemp = tblSlab.DefaultView
                        dvTemp.RowFilter = "SLAB_ID LIKE '%" & heatIdPattern & "%'"
                        tblSlab = dvTemp.ToTable
                        If tblSlab.Rows.Count > 0 Then
                            For j As SByte = 0 To tblSlab.Rows.Count - 1
                                Dim row As DataRow = tblTreeData.NewRow
                                'row("time") = FromDate & " To " & ToDate
                                row("caster") = tblHeat.Rows(i)("CASTER")
                                row("grade") = strGrade
                                row("heat") = tblHeat.Rows(i)("HEAT_ID")
                                row("slab") = tblSlab.Rows(j)("SLAB_ID")
                                row("slab_start_end") = GetSlabStartEnd(tblSlab.Rows(j)("SLAB_ID"))
                                tblTreeData.Rows.Add(row)
                            Next
                        Else
                            Dim row As DataRow = tblTreeData.NewRow
                            'row("time") = FromDate & " To " & ToDate
                            row("caster") = tblHeat.Rows(i)("CASTER")
                            row("grade") = strGrade
                            row("heat") = tblHeat.Rows(i)("HEAT_ID")
                            row("slab") = ""
                            row("slab_start_end") = ""
                            tblTreeData.Rows.Add(row)
                        End If
                    End If
                Next
            End If
        End Using
        If tblTreeData.Rows.Count > 0 Then
            Dim strTable As String = "<table class='table table-bordered' id='tblData'>" & vbCrLf
            strTable &= "<thead>" & vbCrLf
            strTable &= "<tr>" & vbCrLf
            strTable &= "<th class='success'>Caster</th>" & vbCrLf
            strTable &= "<th class='success'>Grade</th>" & vbCrLf
            strTable &= "<th class='success'>Heat</th>" & vbCrLf
            strTable &= "<th class='success'>Critical Slabs</th>" & vbCrLf
            strTable &= "</tr>" & vbCrLf
            strTable &= "</thead>" & vbCrLf
            strTable &= "<tbody>" & vbCrLf
            strConnection = ConfigurationManager.ConnectionStrings("IPQSDB").ConnectionString
            Dim criteria As String = " AND ((CC_DSC_TEMP1 > 800 AND CC_DSC_TEMP1 < 900) OR (CC_DSC_TEMP2 > 800 AND CC_DSC_TEMP2 < 900) OR (CC_DSC_TEMP3 > 800 AND CC_DSC_TEMP3 < 900) OR (CC_DSC_TEMP4 > 800 AND CC_DSC_TEMP4 < 900) OR (CC_DSC_TEMP5 > 800 AND CC_DSC_TEMP5 < 900) OR (CC_DSC_TEMP6 > 800 AND CC_DSC_TEMP6 < 900) OR (CC_DSC_TEMP7 > 800 AND CC_DSC_TEMP7 < 900) OR (CC_DSC_TEMP8 > 800 AND CC_DSC_TEMP8 < 900) OR (CC_DSC_TEMP9 > 800 AND CC_DSC_TEMP9 < 900))"
            Using oleCon = New OleDbConnection(strConnection)
                Dim dt As New DataTable
                Dim oraQuery = ""
                For i As Short = 0 To tblTreeData.Rows.Count - 1
                    Dim casterCondition As String = IIf(tblTreeData.Rows(i)("caster") = 1, " AND SUBSTR(CC_SEQU_ID4,0,2)='81'", " AND SUBSTR(CC_SEQU_ID4,0,2)='82'")
                    Dim a() As String = tblTreeData.Rows(i)("slab_start_end").ToString().Split(",")
                    Using oleDa = New OleDbDataAdapter("SELECT DATETIME,CC_DSC_TEMP1,CC_DSC_TEMP2,CC_DSC_TEMP3,CC_DSC_TEMP4,CC_DSC_TEMP5,CC_DSC_TEMP6,CC_DSC_TEMP7,CC_DSC_TEMP8,CC_DSC_TEMP9 FROM CCC_DSC_RAW where to_char(DATETIME, 'YYYY-MM-DD HH24:MI:SS') >='" & a(0) & "' AND to_char(datetime, 'YYYY-MM-DD HH24:MI:SS') <= '" & a(1) & "'" & casterCondition & " " & criteria, oleCon)
                        oleDa.Fill(dt)
                        If dt.Rows.Count > 0 Then
                            strTable &= "<tr>" & vbCrLf
                            strTable &= "<td class='rowspan-combine'>" & tblTreeData.Rows(i)("caster") & "</td>" & vbCrLf
                            strTable &= "<td class='rowspan-combine'>" & tblTreeData.Rows(i)("grade") & "</td>" & vbCrLf
                            strTable &= "<td class='rowspan-combine'>" & tblTreeData.Rows(i)("heat") & "</td>" & vbCrLf
                            strTable &= "<td>" & tblTreeData.Rows(i)("slab") & "</td>" & vbCrLf
                            strTable &= "</tr>" & vbCrLf
                        End If
                    End Using
                Next
            End Using
            strTable &= "</tbody>" & vbCrLf
            strTable &= "</table>" & vbCrLf
            Context.Response.Write(strTable)
        End If
    End Sub
End Class