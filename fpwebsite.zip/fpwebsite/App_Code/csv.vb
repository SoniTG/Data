﻿Imports Microsoft.VisualBasic
Imports System.IO

Public Class csv
    Public Enum TundishType
        allopen
        oneclosed
        twoclosed
    End Enum

    Dim basepath As String = HttpContext.Current.Server.MapPath("tpm_model")
    Dim path_file() As String = {basepath & "/2.5.csv", basepath & "/3.0.csv", basepath & "/3.5.csv", basepath & "/4.0.csv", basepath & "/4.5.csv"}
    Dim path_fileNINL() As String = {basepath & "/ninl/2.4.csv", basepath & "/ninl/2.9.csv", basepath & "/ninl/3.2.csv"}

    Dim path_fileNINL_AllOpen() As String = {basepath & "/ninlstrandwise/2.4", basepath & "/ninlstrandwise/2.9", basepath & "/ninlstrandwise/3.2"}
    Dim path_fileNINL_1Closed() As String = {basepath & "/ninlstrandwise/2.4_1c", basepath & "/ninlstrandwise/2.9_1c", basepath & "/ninlstrandwise/3.2_1c"}
    Dim path_fileNINL_2Closed() As String = {basepath & "/ninlstrandwise/2.4_2c", basepath & "/ninlstrandwise/2.9_2c", basepath & "/ninlstrandwise/3.2_2c"}
    Public Function Search(ByVal fromGrade As String, ByVal toGrade As String, ByVal selected_throughput As Integer) As String
        Dim temp As String
        Dim found As Boolean = False
        Using reader As New StreamReader(New FileStream(path_file(selected_throughput), FileMode.Open, FileAccess.Read))
            temp = reader.ReadLine

            While Not temp Is Nothing
                If temp.ToUpper.StartsWith(fromGrade.ToUpper.Trim & "," & toGrade.ToUpper.Trim) Then
                    found = True
                    Exit While
                End If
                temp = reader.ReadLine
            End While
        End Using

        If found Then
            Return temp
        Else
            Return -1
        End If
    End Function
    Public Function SearchNINL(ByVal fromGrade As String, ByVal toGrade As String, ByVal selected_throughput As Integer) As String
        Dim temp As String
        Dim found As Boolean = False
        Using reader As New StreamReader(New FileStream(path_fileNINL(selected_throughput), FileMode.Open, FileAccess.Read))
            temp = reader.ReadLine

            While Not temp Is Nothing
                If temp.ToUpper.StartsWith(fromGrade.ToUpper.Trim & "," & toGrade.ToUpper.Trim) Then
                    found = True
                    Exit While
                End If
                temp = reader.ReadLine
            End While
        End Using

        If found Then
            Return temp
        Else
            Return -1
        End If
    End Function

    Public Function SearchNINLStrandWise(ByVal fromGrade As String, ByVal toGrade As String, ByVal selected_throughput As Integer, ByVal strandno As String, ByVal ttype As TundishType) As String
        Dim temp As String
        Dim found As Boolean = False

        Dim fpath As String = ""
        If ttype = TundishType.allopen Then
            fpath = path_fileNINL_AllOpen(selected_throughput) & "_" & strandno & ".csv"
        ElseIf ttype = TundishType.oneclosed
            fpath = path_fileNINL_1Closed(selected_throughput) & "_" & strandno & ".csv"
        ElseIf ttype = TundishType.twoclosed
            fpath = path_fileNINL_2Closed(selected_throughput) & "_" & strandno & ".csv"
        End If

        Using reader As New StreamReader(New FileStream(fpath, FileMode.Open, FileAccess.Read))
            temp = reader.ReadLine

            While Not temp Is Nothing
                If temp.ToUpper.StartsWith(fromGrade.ToUpper.Trim & "," & toGrade.ToUpper.Trim) Then
                    found = True
                    Exit While
                End If
                temp = reader.ReadLine
            End While
        End Using

        If found Then
            Return temp
        Else
            Return -1
        End If
    End Function
    Public Function getListNINL() As String()
        Return New String() {"1125", "1116", "909", "980", "445"}
    End Function

    Public Function getList() As String()
        Return New String() {
   "SA996",
"SA998",
"SA999",
"SE111",
"SF214",
"SC113",
"SF144",
"SF145",
"SC234",
"SF209",
"SF219",
"SF110",
"SC251",
"SA111",
"SF109",
"SF122",
"SF124",
"SU100",
"SU101",
"SE113",
"SF103",
"SF217",
"SF104",
"SF113",
"SF114",
"SF115",
"SF216",
"SE110",
"SF143",
"SF137",
"SA140",
"SE112",
"SE114",
"SC255",
"SA147",
"SC226",
"SC252",
"SU102",
"SU103",
"SF138",
"SF139",
"SF229",
"SA437",
"SA103",
"SA121",
"SF116",
"SF119",
"SF120",
"SF106",
"SF126",
"SF125",
"SF203",
"SC235",
"SF202",
"SA128",
"SC115",
"SD201",
"SF123",
"SF107",
"SF224",
"SF221",
"SF118",
"SF211",
"SF129",
"SF133",
"SF134",
"SF215",
"SU802",
"SU807",
"SA152",
"SF108",
"SF111",
"SF222",
"SC150",
"SE109",
"SF135",
"SF132",
"SF212",
"SC160",
"SC162",
"SC155",
"SC158",
"SF150",
"SF147",
"SC202",
"SC151",
"SC156",
"SC157",
"SC159",
"SF223",
"SA122",
"SC114",
"SC143",
"SC148",
"SC141",
"SC144",
"SA137",
"SC146",
"SC147",
"SA110",
"SC152",
"SC153",
"SA138",
"SF213",
"SC161",
"SA115",
"SC111",
"SA104",
"SC112",
"SC140",
"SA219",
"SU801",
"SA112",
"SU806",
"SA113",
"SF121",
"SA212",
"SF201",
"SA133",
"SC201",
"SF101",
"SE201",
"SU197",
"SU104",
"SA997",
"SC139",
"SA151",
"SE100",
"SE116",
"SA156",
"SA157",
"SF112",
"SC225",
"SC149",
"SA139",
"SA154",
"SA102",
"TR101",
"TR102",
"TR103",
"TR104",
"TR105",
"TR106",
"TR107",
"TR108",
"TR109",
"TR110",
"TR111",
"TR112",
"TR113",
"TR114",
"TR115",
"TR116",
"TR117",
"TR118",
"TR119",
"TR120",
"TR121",
"TR122",
"TR123",
"TR124",
"TR125",
"TR126",
"TR127",
"TR128",
"TR129",
"TR130",
"TR131",
"TR132",
"TR133",
"SU804",
"SU805",
"SF208",
"SF130",
"SF131",
"SF141",
"SF142",
"SA158",
"SA114",
"SC120",
"SA101"
}
    End Function
End Class
