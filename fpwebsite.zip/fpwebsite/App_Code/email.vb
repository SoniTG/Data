﻿Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.Data.SqlClient
Imports System.Net.Mail

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
<System.Web.Script.Services.ScriptService()> _
<WebService(Namespace:="http://tempuri.org/")> _
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Public Class email
    Inherits System.Web.Services.WebService

    <WebMethod()> _
    Public Function SendMail(ByVal from As String, ByVal tolist As String, ByVal cclist As String, ByVal bcclist As String, ByVal subject As String, ByVal message As String) As String
        Dim con As New SqlConnection("Data Source=176.0.0.60\LPTGSQLDEV;Initial Catalog=FP_PROCESS_DATA;uid=153521;password=Welcome@135;")
        Dim cmd As New SqlCommand()
        cmd.Connection = con
        Dim da As New SqlDataAdapter(cmd)
        da.SelectCommand.CommandTimeout = 600
        Dim tolistaddr, cclistaddr, bcclistaddr As String
        tolistaddr = "" : cclistaddr = "" : bcclistaddr = ""
        If tolist.Length > 0 Then
            Dim temp() As String = tolist.Split(",")
            For Each s As String In temp
                cmd.CommandText = "select email from t_dpcr_user where alias like '%," & s & ",%'"
                If con.State = Data.ConnectionState.Closed Then con.Open()
                tolistaddr &= "," & cmd.ExecuteScalar & ""
            Next
        End If
        If tolistaddr.Length > 0 Then
            tolistaddr = tolistaddr.Substring(1)
        End If

        If cclist.Length > 0 Then
            Dim temp() As String = cclist.Split(",")
            For Each s As String In temp
                cmd.CommandText = "select email from t_dpcr_user where alias like '%," & s & ",%'"
                If con.State = Data.ConnectionState.Closed Then con.Open()
                cclistaddr &= "," & cmd.ExecuteScalar & ""
            Next
        End If
        If cclistaddr.Length > 0 Then
            cclistaddr = cclistaddr.Substring(1)
        End If

        If bcclist.Length > 0 Then
            Dim temp() As String = bcclist.Split(",")
            For Each s As String In temp

                cmd.CommandText = "select email from t_dpcr_user where alias like '%," & s & ",%'"
                If con.State = Data.ConnectionState.Closed Then con.Open()
                bcclistaddr &= "," & cmd.ExecuteScalar & ""
            Next
        End If
        If bcclistaddr.Length > 0 Then
            bcclistaddr = bcclistaddr.Substring(1)
        End If

        cmd.CommandText = "select name from t_dpcr_user where email='" & from & "'"
        If con.State = Data.ConnectionState.Closed Then con.Open()
        Dim frmuser As String = cmd.ExecuteScalar
        If con.State = Data.ConnectionState.Open Then con.Close()

        Dim newmail As New MailMessage
        newmail.To.Add(tolistaddr)
        Try
            newmail.CC.Add(cclistaddr)
        Catch ex As Exception

        End Try
        Try
            newmail.Bcc.Add(bcclistaddr)
        Catch ex As Exception

        End Try

        'newmail.To.Add("mrityunjay.singh@tatasteel.com")
        newmail.Subject = subject
        newmail.Body = message & "<br/><br/><hr><b>#Commented by Mr. " & frmuser & "</b><br/><br/>"
        newmail.From = New MailAddress("PTG@tatasteel.com", "PTG")
        newmail.IsBodyHtml = True
        Dim client As New SmtpClient
        client.Host = "144.0.16.7"

        Try
            client.Send(newmail)
            Return 1
        Catch ex As Exception
            Return 0
        End Try


    End Function

    <WebMethod()> _
    Function ValidateUser(ByVal userid As String, ByVal password As String) As String
        Try
            Dim con As New SqlConnection("Data Source=176.0.0.60\LPTGSQLDEV;Initial Catalog=FP_PROCESS_DATA;uid=153521;password=Welcome@135;")
            Dim cmd As New SqlCommand()
            cmd.Connection = con
            cmd.CommandText = "select count(*) from t_dpcr_user where email='" & userid & "' and password=dbo.fn_str_TO_BASE64('" & password & "') and Authority='Y'"
            If con.State = Data.ConnectionState.Closed Then con.Open()
            Dim cnt As Integer = cmd.ExecuteScalar
            If con.State = Data.ConnectionState.Open Then con.Close()
            Return cnt
        Catch ex As Exception
            Return 0
        End Try

    End Function
End Class