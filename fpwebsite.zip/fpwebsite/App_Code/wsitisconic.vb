﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
' <System.Web.Script.Services.ScriptService()> _
<WebService(Namespace:="http://tempuri.org/")> _
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Public Class wsitisconic
    Inherits System.Web.Services.WebService

    Dim con As New SqlConnection("server=176.0.0.60\lptgsqldev;database=itisconic;user id=153521;password=Welcome@135")

    <WebMethod()>
    Public Function CheckLogin(ByVal userid As String, ByVal pass As String) As String
        Dim cmd As New SqlCommand("select * from WS_Login where userid='" & userid.Trim & "' and password='" & pass.Trim & "'", con)
        cmd.CommandTimeout = 300
        Dim da As New SqlDataAdapter(cmd)
        Dim dt As New DataTable
        da.Fill(dt)

        If dt.Rows.Count = 0 Then
            Return "-1"
        Else
            Return dt.Rows(0)("usertype") & "~" & dt.Rows(0)("slno")
        End If
    End Function

    <WebMethod()>
    Public Function SaveImage(ByVal b As Byte(), ByVal userid As Integer, ByVal boxresult As String) As String
        Try
            Using cmd As SqlCommand = New SqlCommand("INSERT INTO WS_Data VALUES(@imagefile,@uploadedby,getdate(),@boxresult)", con)
                cmd.CommandType = CommandType.Text
                cmd.Parameters.AddWithValue("@imagefile", b)
                cmd.Parameters.AddWithValue("@uploadedby", userid)
                cmd.Parameters.AddWithValue("@boxresult", boxresult)
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
                Return "1"
            End Using
        Catch ex As Exception
            Return "0"
        End Try

    End Function

    <WebMethod()>
    Public Function SaveImage1(ByVal b As Byte(), ByVal userid As Integer, ByVal boxresult As String) As String
        Try
            Dim savepath As String = Server.MapPath("WSUploads") & "\" & DateTime.Now.ToString("MMddHHmmss") & "_" & userid & ".jpg"
            IO.File.WriteAllBytes(savepath, b)

            Using cmd As SqlCommand = New SqlCommand("INSERT INTO WS_Data VALUES1(@imagepath,@uploadedby,getdate(),@boxresult)", con)
                cmd.CommandType = CommandType.Text
                cmd.Parameters.AddWithValue("@imagepath", DateTime.Now.ToString("MMddHHmmss") & "_" & userid & ".jpg")
                cmd.Parameters.AddWithValue("@uploadedby", userid)
                cmd.Parameters.AddWithValue("@boxresult", boxresult)
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
                Return "1"
            End Using
        Catch ex As Exception
            Return "0"
        End Try

    End Function
End Class
