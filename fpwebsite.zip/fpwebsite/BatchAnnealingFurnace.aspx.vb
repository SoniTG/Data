﻿Imports System.Data
Imports System.IO
Imports System.Data.OleDb
Imports System.Data.SqlClient
Imports OfficeOpenXml

Partial Class BatchAnnealingFurnace
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Dim dt As New DataTable
    Dim dtCutOff As DataTable

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try

                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    txtDate_TextChanged()
                End If

            Catch ex As Exception

            End Try
        End If
        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                'Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
                'Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                ddlFilter.SelectedIndex = 3
                Dim dtStart As String = DateTime.Now.AddDays(-5).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                objController.PopulateGradeForBAF(ddlGrade, dtStart, dtEnd)
                Dim filter As String = ""
                If ddlGrade.SelectedItem.Text.ToString <> "All" Then
                    filter = " where  " & ddlFilter.SelectedValue.ToString() & " between '" & dtStart & "' and '" & dtEnd & "' and ANC_GRD_STEEL = '" & ddlGrade.SelectedItem.Text.ToString() & "' order by " & ddlFilter.SelectedValue.ToString()
                Else
                    filter = " where  " & ddlFilter.SelectedValue.ToString() & " between '" & dtStart & "' and '" & dtEnd & "' order by " & ddlFilter.SelectedValue.ToString()

                End If
                'Dim filter As String = " where  " & ddlFilter.SelectedValue.ToString() & " between '" & dtStart & "' and '" & dtEnd & "'  and LTR_PARAM_TEST IN('EL','RA') order by " & ddlFilter.SelectedValue.ToString()

                dtCutOff = objController.GetBafCutOff()
                ViewState("cutoff") = dtCutOff
                If rdbFullData.Checked Then
                    dt = objController.GetBafData(filter, "yes")
                Else
                    dt = objController.GetBafData(filter, "no")
                End If
                If dt.Rows.Count > 0 Then
                    If rdbFullData.Checked Then


                        For i As Integer = 0 To dt.Rows.Count - 1
                            Dim coil_id As String = dt.Rows(i)("CoilId")
                            Dim dtYSUTS As DataTable
                            dtYSUTS = objController.GetYsUtsData(coil_id)
                            If dtYSUTS.Rows.Count > 0 Then
                                dt.Rows(i)("YS") = dtYSUTS.Rows(0)("YS")
                                dt.Rows(i)("UTS") = dtYSUTS.Rows(0)("UTS")
                            End If
                        Next
                    End If
                    gvData.Visible = True
                    gvData1.Visible = False
                    gvData.DataSource = dt
                    gvData.DataBind()
                    gvData.UseAccessibleHeader = True
                    gvData.HeaderRow.TableSection = TableRowSection.TableHeader
                End If


            Catch ex As Exception

            End Try




        End If
    End Sub
    Protected Sub txtCoilwise_TextChanged(sender As Object, e As EventArgs) Handles txtCoilwise.TextChanged
        Try
            If txtCoilwise.Text IsNot "" Then
                txtDate_TextChanged()
            End If
        Catch ex As Exception

        End Try

        'Dim filter As String = ""
        'If rdbtnStackwise.Checked Then
        '    If txtCoilwise.Text <> "" Then
        '        filter &= " where  T6.LTR_PARAM_TEST In('EL','RA') and anc_id_stack = '" & txtCoilwise.Text & "'"
        '        If GetData(filter).Rows.Count > 0 Then
        '            gvData.DataSource = GetData(filter)
        '            gvData.DataBind()
        '            gvData.UseAccessibleHeader = True
        '            gvData.HeaderRow.TableSection = TableRowSection.TableHeader
        '        End If
        '    End If
        'ElseIf rdbtnCoilwise.Checked Then
        '    If txtCoilwise.Text <> "" Then
        '        filter &= " where  T6.LTR_PARAM_TEST IN('EL','RA') and  ANC_ID_COIL = '" & txtCoilwise.Text & "'"
        '        If GetData(filter).Rows.Count > 0 Then
        '            gvData.DataSource = GetData(filter)
        '            gvData.DataBind()
        '            gvData.UseAccessibleHeader = True
        '            gvData.HeaderRow.TableSection = TableRowSection.TableHeader
        '        End If
        '    End If


        'End If

    End Sub

    Protected Sub btnDownload_Click(sender As Object, e As EventArgs) Handles btnDownload.Click
        If rdbFullData.Checked Then
            If gvData.Rows.Count > 0 Then
                Try

                    Response.ClearContent()
                    Response.Buffer = True
                    Response.AddHeader("content-disposition", String.Format("attachment; filename={0}", "CoilDetail.xls"))
                    Response.ContentEncoding = Encoding.UTF8
                    Response.ContentType = "application/ms-excel"
                    Dim sw As New StringWriter()
                    Dim htw As New HtmlTextWriter(sw)
                    gvData.RenderControl(htw)
                    Response.Write(sw.ToString())
                    Response.End()

                Catch ex As Exception
                Finally

                End Try
            End If
        Else
            If gvData1.Rows.Count > 0 Then
                Try

                    Response.ClearContent()
                    Response.Buffer = True
                    Response.AddHeader("content-disposition", String.Format("attachment; filename={0}", "CoilDetail.xls"))
                    Response.ContentEncoding = Encoding.UTF8
                    Response.ContentType = "application/ms-excel"
                    Dim sw As New StringWriter()
                    Dim htw As New HtmlTextWriter(sw)
                    gvData1.RenderControl(htw)
                    Response.Write(sw.ToString())
                    Response.End()

                Catch ex As Exception
                Finally

                End Try
            End If
        End If

    End Sub

    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)
        ' Verifies that the control is rendered 
    End Sub
    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try

            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            Dim filter As String = ""
            objController.PopulateGradeForBAF(ddlGrade, dtStart, dtEnd)
            'filter = " where T.STR_TM_DESTACKING between to_date('" & CDate(dtStart).ToString("dd-MM-yyyy HH:mm:ss") & "','DD-MM-YYYY HH24:MI:SS') and TO_date('" & CDate(dtEnd).ToString("dd-MM-yyyy HH:mm:ss") & "' ,'DD-MM-YYYY HH24:MI:SS') and T6.LTR_PARAM_TEST IN('EL','RA') order by T.STR_TM_DESTACKING"
            If ddlFilter.SelectedItem.Text = "Coil Id" Then
                'filter = " where " & ddlFilter.SelectedValue.ToString() & " = '" & txtCoilwise.Text.ToString() & "' and LTR_PARAM_TEST IN('EL','RA')"
                If ddlGrade.SelectedItem.Text.ToString <> "All" Then
                    filter = " where " & ddlFilter.SelectedValue.ToString() & " = '" & txtCoilwise.Text.ToString() & "' and ANC_GRD_STEEL = '" & ddlGrade.SelectedItem.Text.ToString() & "'"
                Else
                    filter = " where " & ddlFilter.SelectedValue.ToString() & " = '" & txtCoilwise.Text.ToString() & "'"
                End If

            ElseIf ddlFilter.SelectedItem.Text = "Stack Id" Then
                If ddlGrade.SelectedItem.Text.ToString <> "All" Then
                    filter = " where " & ddlFilter.SelectedValue.ToString() & " = " & txtCoilwise.Text.ToString() & " and ANC_GRD_STEEL = '" & ddlGrade.SelectedItem.Text.ToString() & "'"
                Else
                    filter = " where " & ddlFilter.SelectedValue.ToString() & " = " & txtCoilwise.Text.ToString() & ""
                End If
                'filter = " where " & ddlFilter.SelectedValue.ToString() & " = " & txtCoilwise.Text.ToString() & " and LTR_PARAM_TEST IN('EL','RA')"

            ElseIf ddlFilter.SelectedItem.Text = "Position" Then
                If ddlGrade.SelectedItem.Text.ToString <> "All" Then
                    filter = " where STR_TM_DESTACKING between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "'  and " & ddlFilter.SelectedValue.ToString() & " = " & txtCoilwise.Text.ToString() & " and ANC_GRD_STEEL = '" & ddlGrade.SelectedItem.Text.ToString() & "' order by STR_TM_DESTACKING"
                Else
                    filter = " where STR_TM_DESTACKING between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "'  and " & ddlFilter.SelectedValue.ToString() & " = " & txtCoilwise.Text.ToString() & " order by STR_TM_DESTACKING"
                End If
                'filter = " where STR_TM_DESTACKING between '" & CDate(dtStart).ToString("dd-MM-yyyy HH:mm:ss") & "' and '" & CDate(dtEnd).ToString("dd-MM-yyyy HH:mm:ss") & "'  and LTR_PARAM_TEST IN('EL','RA') and " & ddlFilter.SelectedValue.ToString() & " = " & txtCoilwise.Text & " order by STR_TM_DESTACKING"

                'filter = " where STR_TM_DESTACKING between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "'  and LTR_PARAM_TEST IN('EL','RA') and " & ddlFilter.SelectedValue.ToString() & " = " & txtCoilwise.Text.ToString() & " order by STR_TM_DESTACKING"
            ElseIf ddlFilter.SelectedItem.Text = "Stacking Time" Then
                If ddlGrade.SelectedItem.Text.ToString <> "All" Then
                    filter = " where " & ddlFilter.SelectedValue.ToString() & " between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "' and ANC_GRD_STEEL = '" & ddlGrade.SelectedItem.Text.ToString() & "'  order by " & ddlFilter.SelectedValue.ToString() & ""
                Else
                    filter = " where " & ddlFilter.SelectedValue.ToString() & " between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "'  order by " & ddlFilter.SelectedValue.ToString() & ""
                End If
                'filter = " where " & ddlFilter.SelectedValue.ToString() & " between to_date('" & CDate(dtStart).ToString("dd-MM-yyyy HH:mm:ss") & "','DD-MM-YYYY HH24:MI:SS') and TO_date('" & CDate(dtEnd).ToString("dd-MM-yyyy HH:mm:ss") & "' ,'DD-MM-YYYY HH24:MI:SS') and LTR_PARAM_TEST IN('EL','RA') order by " & ddlFilter.SelectedValue.ToString() & ""

                'filter = " where " & ddlFilter.SelectedValue.ToString() & " between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "'  and LTR_PARAM_TEST IN('EL','RA') order by " & ddlFilter.SelectedValue.ToString() & ""
            ElseIf ddlFilter.SelectedItem.Text = "HH No" Then
                If ddlGrade.SelectedItem.Text.ToString <> "All" Then
                    filter = " where STR_TM_DESTACKING between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "'  and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "' and " & ddlFilter.SelectedValue.ToString() & " = '" & txtCoilwise.Text.ToString().ToUpper() & "' and ANC_GRD_STEEL = '" & ddlGrade.SelectedItem.Text.ToString() & "' order by STR_TM_DESTACKING"
                Else
                    filter = " where STR_TM_DESTACKING between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "'  and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "' and " & ddlFilter.SelectedValue.ToString() & " = '" & txtCoilwise.Text.ToString().ToUpper() & "' order by STR_TM_DESTACKING"
                End If
                'filter = " where STR_TM_DESTACKING between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "'  and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "'  and LTR_PARAM_TEST IN('EL','RA') and " & ddlFilter.SelectedValue.ToString() & " = '" & txtCoilwise.Text.ToString().ToUpper() & "' order by STR_TM_DESTACKING"

            ElseIf ddlFilter.SelectedItem.Text = "Base Id" Then
                If ddlGrade.SelectedItem.Text.ToString <> "All" Then
                    filter = " where STR_TM_DESTACKING between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "'  and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "'  and " & ddlFilter.SelectedValue.ToString() & " = '" & txtCoilwise.Text.ToString().ToUpper() & "' and ANC_GRD_STEEL = '" & ddlGrade.SelectedItem.Text.ToString() & "' order by STR_TM_DESTACKING"
                Else
                    filter = " where STR_TM_DESTACKING between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "'  and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "'  and " & ddlFilter.SelectedValue.ToString() & " = '" & txtCoilwise.Text.ToString().ToUpper() & "' order by STR_TM_DESTACKING"
                End If
                'filter = " where STR_TM_DESTACKING between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "'  and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "'  and LTR_PARAM_TEST IN('EL','RA') and " & ddlFilter.SelectedValue.ToString() & " = '" & txtCoilwise.Text.ToString().ToUpper() & "' order by STR_TM_DESTACKING"

            ElseIf ddlFilter.SelectedItem.Text = "Cooling Hood No" Then
                If ddlGrade.SelectedItem.Text.ToString <> "All" Then
                    filter = " where STR_TM_DESTACKING between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "'  and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "'  and " & ddlFilter.SelectedValue.ToString() & " = '" & txtCoilwise.Text.ToString().ToUpper() & "' and ANC_GRD_STEEL = '" & ddlGrade.SelectedItem.Text.ToString() & "' order by STR_TM_DESTACKING"
                Else
                    filter = " where STR_TM_DESTACKING between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "'  and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "'  and " & ddlFilter.SelectedValue.ToString() & " = '" & txtCoilwise.Text.ToString().ToUpper() & "' order by STR_TM_DESTACKING"
                End If
                'filter = " where STR_TM_DESTACKING between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "'  and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "'  and LTR_PARAM_TEST IN('EL','RA') and " & ddlFilter.SelectedValue.ToString() & " = '" & txtCoilwise.Text.ToString().ToUpper() & "' order by STR_TM_DESTACKING"

            End If
            If rdbFullData.Checked Then
                dt = objController.GetBafData(filter, "yes")
            Else
                dt = objController.GetBafData(filter, "no")
            End If
            If dt.Rows.Count > 0 Then
                If rdbFullData.Checked Then


                    For i As Integer = 0 To dt.Rows.Count - 1
                        Dim coil_id As String = dt.Rows(i)("CoilId")
                        Dim dtYSUTS As DataTable
                        dtYSUTS = objController.GetYsUtsData(coil_id)
                        If dtYSUTS.Rows.Count > 0 Then
                            dt.Rows(i)("YS") = dtYSUTS.Rows(0)("YS")
                            dt.Rows(i)("UTS") = dtYSUTS.Rows(0)("UTS")
                        End If
                    Next
                    gvData.Visible = True
                    gvData1.Visible = False
                    gvData.DataSource = dt
                    gvData.DataBind()
                    gvData.UseAccessibleHeader = True
                    gvData.HeaderRow.TableSection = TableRowSection.TableHeader
                Else
                    gvData.Visible = False
                    gvData1.Visible = True
                    gvData1.DataSource = dt
                    gvData1.DataBind()
                    gvData1.UseAccessibleHeader = True
                    gvData1.HeaderRow.TableSection = TableRowSection.TableHeader
                End If

                'Dim i As Integer = 1
                'Using ep As New ExcelPackage()
                '    'For Each dt As DataTable In ds.Tables
                '    'Dim ws As ExcelWorksheet = ep.Workbook.Worksheets.Add("s" & i)
                '    Dim ws As ExcelWorksheet = ep.Workbook.Worksheets.Add("Download")
                '    ws.Cells("A1").LoadFromDataTable(dt, True)

                '    'i += 1
                '    'Next
                '    Using ms As New MemoryStream
                '        Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                '        Response.AddHeader("content-disposition", "attachment; filename=download.xlsx")
                '        ep.SaveAs(ms)
                '        ms.WriteTo(Response.OutputStream)
                '        Response.Flush()
                '        Response.End()
                '    End Using
                'End Using





            End If
            If dt.Rows.Count = 0 Then
                gvData.DataSource = ""
                gvData.DataBind()
                gvData1.DataSource = ""
                gvData1.DataBind()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub gvData_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles gvData.RowDataBound
        Try

            If gvData.Rows.Count > 0 Then
                If e.Row.RowType = DataControlRowType.DataRow Then
                    Dim gr As String = DataBinder.Eval(e.Row.DataItem, "Grade")
                    Dim ccuage As Double = DataBinder.Eval(e.Row.DataItem, "ccsuage")
                    If dtCutOff Is Nothing Then
                        dtCutOff = CType(ViewState("cutoff"), DataTable)
                    End If
                    Dim dr() As DataRow = dtCutOff.Select("grade='" & gr & "' and parameter_name='ccsuage(hr)'")
                    If dr.Count = 0 Then
                        dr = dtCutOff.Select("grade='ALL' and parameter_name='ccsuage(hr)'")
                    End If
                    If dr.Count > 0 Then
                        If dr(0)(2) = "<" Then
                            If ccuage < dr(0)(3) Then
                                ''color red
                                CType(e.Row.FindControl("lblCCSUAge"), Label).ForeColor = System.Drawing.Color.Red
                            End If
                        ElseIf dr(0)(2) = ">" Then
                            If ccuage > dr(0)(3) Then
                                ''color red
                                CType(e.Row.FindControl("lblCCSUAge"), Label).ForeColor = System.Drawing.Color.Red
                            End If
                        End If
                    End If

                    Dim controlledheating As Double = 0
                    If Not IsDBNull(DataBinder.Eval(e.Row.DataItem, "ControlledHeating")) Then
                        controlledheating = DataBinder.Eval(e.Row.DataItem, "ControlledHeating")
                    Else
                        controlledheating = 0
                    End If
                    dr = dtCutOff.Select("grade='" & gr & "' and parameter_name='ControlledHeating(Hr)'")
                    If dr.Count = 0 Then
                        dr = dtCutOff.Select("grade='ALL' and parameter_name='ControlledHeating(Hr)'")
                    End If
                    If dr.Count > 0 Then
                        If dr(0)(2) = "<" Then
                            If controlledheating < dr(0)(3) Then
                                ''color red
                                CType(e.Row.FindControl("lblControlledHeating"), Label).ForeColor = System.Drawing.Color.Red
                            End If
                        ElseIf dr(0)(2) = ">" Then
                            If controlledheating > dr(0)(3) Then
                                ''color red
                                CType(e.Row.FindControl("lblControlledHeating"), Label).ForeColor = System.Drawing.Color.Red
                            End If
                        End If
                    End If
                    Dim interruption As Double = 0
                    If Not IsDBNull(DataBinder.Eval(e.Row.DataItem, "Interruption")) Then
                        interruption = DataBinder.Eval(e.Row.DataItem, "Interruption")
                    Else
                        interruption = 0
                    End If

                    'Dim interruption As Double = DataBinder.Eval(e.Row.DataItem, "Interruption")
                    dr = dtCutOff.Select("grade='" & gr & "' and parameter_name='Interruption(Hr)'")
                    If dr.Count = 0 Then
                        dr = dtCutOff.Select("grade='ALL' and parameter_name='Interruption(Hr)'")
                    End If
                    If dr.Count > 0 Then
                        If dr(0)(2) = "<" Then
                            If interruption < dr(0)(3) Then
                                ''color red
                                CType(e.Row.FindControl("lblInterruption"), Label).ForeColor = System.Drawing.Color.Red
                            End If
                        ElseIf dr(0)(2) = ">" Then
                            If interruption > dr(0)(3) Then
                                ''color red
                                CType(e.Row.FindControl("lblInterruption"), Label).ForeColor = System.Drawing.Color.Red
                            End If
                        End If
                    End If

                    Dim soakingtime As Double = 0
                    If Not IsDBNull(DataBinder.Eval(e.Row.DataItem, "SoakingTime")) Then
                        soakingtime = DataBinder.Eval(e.Row.DataItem, "SoakingTime")
                    Else
                        soakingtime = 0
                    End If
                    'Dim soakingtime As Double = DataBinder.Eval(e.Row.DataItem, "SoakingTime")
                    dr = dtCutOff.Select("grade='" & gr & "' and parameter_name='SoakingTime(Hr)'")
                    If dr.Count = 0 Then
                        dr = dtCutOff.Select("grade='ALL' and parameter_name='SoakingTime(Hr)'")
                    End If
                    If dr.Count > 0 Then
                        If dr(0)(2) = "<" Then
                            If soakingtime < dr(0)(3) Then
                                ''color red
                                CType(e.Row.FindControl("lblSoakingTime"), Label).ForeColor = System.Drawing.Color.Red
                            End If
                        ElseIf dr(0)(2) = ">" Then
                            If soakingtime > dr(0)(3) Then
                                ''color red
                                CType(e.Row.FindControl("lblSoakingTime"), Label).ForeColor = System.Drawing.Color.Red
                            End If
                        End If
                    End If

                    Dim hhcoolingtime As Double = 0
                    If Not IsDBNull(DataBinder.Eval(e.Row.DataItem, "HHCoolingTime")) Then
                        hhcoolingtime = DataBinder.Eval(e.Row.DataItem, "HHCoolingTime")
                    Else
                        hhcoolingtime = 0
                    End If
                    'Dim hhcoolingtime As Double = DataBinder.Eval(e.Row.DataItem, "HHCoolingTime")
                    dr = dtCutOff.Select("grade='" & gr & "' and parameter_name='HHCoolingTime(Hr)'")
                    If dr.Count = 0 Then
                        dr = dtCutOff.Select("grade='ALL' and parameter_name='HHCoolingTime(Hr)'")
                    End If
                    If dr.Count > 0 Then
                        If dr(0)(2) = "<" Then
                            If hhcoolingtime < dr(0)(3) Then
                                ''color red
                                CType(e.Row.FindControl("lblHHCoolingTime"), Label).ForeColor = System.Drawing.Color.Red
                            End If
                        ElseIf dr(0)(2) = ">" Then
                            If hhcoolingtime > dr(0)(3) Then
                                ''color red
                                CType(e.Row.FindControl("lblHHCoolingTime"), Label).ForeColor = System.Drawing.Color.Red
                            End If
                        End If
                    End If

                    Dim coolinghoodtime As Double = 0
                    If Not IsDBNull(DataBinder.Eval(e.Row.DataItem, "CoolingHoodTime")) Then
                        coolinghoodtime = DataBinder.Eval(e.Row.DataItem, "CoolingHoodTime")
                    Else
                        coolinghoodtime = 0
                    End If
                    'Dim coolinghoodtime As Double = DataBinder.Eval(e.Row.DataItem, "CoolingHoodTime")
                    dr = dtCutOff.Select("grade='" & gr & "' and parameter_name='CoolingHood/Time(Hr)'")
                    If dr.Count = 0 Then
                        dr = dtCutOff.Select("grade='ALL' and parameter_name='CoolingHood/Time(Hr)'")
                    End If
                    If dr.Count > 0 Then
                        If dr(0)(2) = "<" Then
                            If coolinghoodtime < dr(0)(3) Then
                                ''color red
                                CType(e.Row.FindControl("lblCoolingHoodTime"), Label).ForeColor = System.Drawing.Color.Red
                            End If
                        ElseIf dr(0)(2) = ">" Then
                            If coolinghoodtime > dr(0)(3) Then
                                ''color red
                                CType(e.Row.FindControl("lblCoolingHoodTime"), Label).ForeColor = System.Drawing.Color.Red
                            End If
                        End If
                    End If

                    Dim h2consp10 As Double = 0
                    If Not IsDBNull(DataBinder.Eval(e.Row.DataItem, "H2Consp10")) Then
                        h2consp10 = DataBinder.Eval(e.Row.DataItem, "H2Consp10")
                    Else
                        h2consp10 = 0
                    End If
                    ' Dim h2consp10 As Double = DataBinder.Eval(e.Row.DataItem, "H2Consp10")
                    dr = dtCutOff.Select("grade='" & gr & "' and parameter_name='H2Rate1(m3/hr)'")
                    If dr.Count = 0 Then
                        dr = dtCutOff.Select("grade='ALL' and parameter_name='H2Rate1(m3/hr)'")
                    End If
                    If dr.Count > 0 Then
                        If dr(0)(2) = "<" Then
                            If h2consp10 < dr(0)(3) Then
                                ''color red
                                CType(e.Row.FindControl("H2Consp10"), Label).ForeColor = System.Drawing.Color.Red
                            End If
                        ElseIf dr(0)(2) = ">" Then
                            If h2consp10 > dr(0)(3) Then
                                ''color red
                                CType(e.Row.FindControl("H2Consp10"), Label).ForeColor = System.Drawing.Color.Red
                            End If
                        End If
                    End If



                End If
            End If

        Catch ex As Exception

        End Try

    End Sub
    Protected Sub ddlFilter_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlFilter.SelectedIndexChanged
        Try
            ddlGrade.SelectedIndex = 0
            txtCoilwise.Text = ""
            If ddlFilter.SelectedItem.Text = "Stacking Time" Then
                txtCoilwise.Enabled = False
                txtDate_TextChanged()
            Else
                txtCoilwise.Enabled = True
                txtCoilwise.Focus()
                gvData.DataSource = ""
                gvData.DataBind()
                gvData1.DataSource = ""
                gvData1.DataBind()

            End If
            'txtDate_TextChanged()

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub ddlGrade_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlGrade.SelectedIndexChanged
        Try

            ''txtCoilwise.Text = ""
            'If ddlFilter.SelectedItem.Text = "Stacking Time" Then
            '    txtCoilwise.Enabled = False
            '    'txtDate_TextChanged()
            'Else
            '    txtCoilwise.Enabled = True
            '    txtCoilwise.Focus()
            '    'gvData.DataSource = ""
            '    'gvData.DataBind()

            'End If
            Try

                Dim dtStart As String = hfFrom.Value
                Dim dtEnd As String = hfTo.Value
                Dim filter As String = ""
                'filter = " where T.STR_TM_DESTACKING between to_date('" & CDate(dtStart).ToString("dd-MM-yyyy HH:mm:ss") & "','DD-MM-YYYY HH24:MI:SS') and TO_date('" & CDate(dtEnd).ToString("dd-MM-yyyy HH:mm:ss") & "' ,'DD-MM-YYYY HH24:MI:SS') and T6.LTR_PARAM_TEST IN('EL','RA') order by T.STR_TM_DESTACKING"
                If ddlFilter.SelectedItem.Text = "Coil Id" Then
                    'filter = " where " & ddlFilter.SelectedValue.ToString() & " = '" & txtCoilwise.Text.ToString() & "' and LTR_PARAM_TEST IN('EL','RA')"
                    If ddlGrade.SelectedItem.Text.ToString <> "All" Then
                        filter = " where " & ddlFilter.SelectedValue.ToString() & " = '" & txtCoilwise.Text.ToString() & "' and ANC_GRD_STEEL = '" & ddlGrade.SelectedItem.Text.ToString() & "'"
                    Else
                        filter = " where " & ddlFilter.SelectedValue.ToString() & " = '" & txtCoilwise.Text.ToString() & "'"
                    End If

                ElseIf ddlFilter.SelectedItem.Text = "Stack Id" Then
                    If ddlGrade.SelectedItem.Text.ToString <> "All" Then
                        filter = " where " & ddlFilter.SelectedValue.ToString() & " = " & txtCoilwise.Text.ToString() & " and ANC_GRD_STEEL = '" & ddlGrade.SelectedItem.Text.ToString() & "'"
                    Else
                        filter = " where " & ddlFilter.SelectedValue.ToString() & " = " & txtCoilwise.Text.ToString() & ""
                    End If
                    'filter = " where " & ddlFilter.SelectedValue.ToString() & " = " & txtCoilwise.Text.ToString() & " and LTR_PARAM_TEST IN('EL','RA')"

                ElseIf ddlFilter.SelectedItem.Text = "Position" Then
                    If ddlGrade.SelectedItem.Text.ToString <> "All" Then
                        filter = " where STR_TM_DESTACKING between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "'  and " & ddlFilter.SelectedValue.ToString() & " = " & txtCoilwise.Text.ToString() & " and ANC_GRD_STEEL = '" & ddlGrade.SelectedItem.Text.ToString() & "' order by STR_TM_DESTACKING"
                    Else
                        filter = " where STR_TM_DESTACKING between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "'  and " & ddlFilter.SelectedValue.ToString() & " = " & txtCoilwise.Text.ToString() & " order by STR_TM_DESTACKING"
                    End If
                    'filter = " where STR_TM_DESTACKING between '" & CDate(dtStart).ToString("dd-MM-yyyy HH:mm:ss") & "' and '" & CDate(dtEnd).ToString("dd-MM-yyyy HH:mm:ss") & "'  and LTR_PARAM_TEST IN('EL','RA') and " & ddlFilter.SelectedValue.ToString() & " = " & txtCoilwise.Text & " order by STR_TM_DESTACKING"

                    'filter = " where STR_TM_DESTACKING between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "'  and LTR_PARAM_TEST IN('EL','RA') and " & ddlFilter.SelectedValue.ToString() & " = " & txtCoilwise.Text.ToString() & " order by STR_TM_DESTACKING"
                ElseIf ddlFilter.SelectedItem.Text = "Stacking Time" Then
                    If ddlGrade.SelectedItem.Text.ToString <> "All" Then
                        filter = " where " & ddlFilter.SelectedValue.ToString() & " between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "' and ANC_GRD_STEEL = '" & ddlGrade.SelectedItem.Text.ToString() & "'  order by " & ddlFilter.SelectedValue.ToString() & ""
                    Else
                        filter = " where " & ddlFilter.SelectedValue.ToString() & " between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "'  order by " & ddlFilter.SelectedValue.ToString() & ""
                    End If
                    'filter = " where " & ddlFilter.SelectedValue.ToString() & " between to_date('" & CDate(dtStart).ToString("dd-MM-yyyy HH:mm:ss") & "','DD-MM-YYYY HH24:MI:SS') and TO_date('" & CDate(dtEnd).ToString("dd-MM-yyyy HH:mm:ss") & "' ,'DD-MM-YYYY HH24:MI:SS') and LTR_PARAM_TEST IN('EL','RA') order by " & ddlFilter.SelectedValue.ToString() & ""

                    'filter = " where " & ddlFilter.SelectedValue.ToString() & " between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "'  and LTR_PARAM_TEST IN('EL','RA') order by " & ddlFilter.SelectedValue.ToString() & ""
                ElseIf ddlFilter.SelectedItem.Text = "HH No" Then
                    If ddlGrade.SelectedItem.Text.ToString <> "All" Then
                        filter = " where STR_TM_DESTACKING between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "'  and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "' and " & ddlFilter.SelectedValue.ToString() & " = '" & txtCoilwise.Text.ToString().ToUpper() & "' and ANC_GRD_STEEL = '" & ddlGrade.SelectedItem.Text.ToString() & "' order by STR_TM_DESTACKING"
                    Else
                        filter = " where STR_TM_DESTACKING between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "'  and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "' and " & ddlFilter.SelectedValue.ToString() & " = '" & txtCoilwise.Text.ToString().ToUpper() & "' order by STR_TM_DESTACKING"
                    End If
                    'filter = " where STR_TM_DESTACKING between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "'  and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "'  and LTR_PARAM_TEST IN('EL','RA') and " & ddlFilter.SelectedValue.ToString() & " = '" & txtCoilwise.Text.ToString().ToUpper() & "' order by STR_TM_DESTACKING"

                ElseIf ddlFilter.SelectedItem.Text = "Base Id" Then
                    If ddlGrade.SelectedItem.Text.ToString <> "All" Then
                        filter = " where STR_TM_DESTACKING between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "'  and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "'  and " & ddlFilter.SelectedValue.ToString() & " = '" & txtCoilwise.Text.ToString().ToUpper() & "' and ANC_GRD_STEEL = '" & ddlGrade.SelectedItem.Text.ToString() & "' order by STR_TM_DESTACKING"
                    Else
                        filter = " where STR_TM_DESTACKING between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "'  and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "'  and " & ddlFilter.SelectedValue.ToString() & " = '" & txtCoilwise.Text.ToString().ToUpper() & "' order by STR_TM_DESTACKING"
                    End If
                    'filter = " where STR_TM_DESTACKING between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "'  and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "'  and LTR_PARAM_TEST IN('EL','RA') and " & ddlFilter.SelectedValue.ToString() & " = '" & txtCoilwise.Text.ToString().ToUpper() & "' order by STR_TM_DESTACKING"

                ElseIf ddlFilter.SelectedItem.Text = "Cooling Hood No" Then
                    If ddlGrade.SelectedItem.Text.ToString <> "All" Then
                        filter = " where STR_TM_DESTACKING between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "'  and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "'  and " & ddlFilter.SelectedValue.ToString() & " = '" & txtCoilwise.Text.ToString().ToUpper() & "' and ANC_GRD_STEEL = '" & ddlGrade.SelectedItem.Text.ToString() & "' order by STR_TM_DESTACKING"
                    Else
                        filter = " where STR_TM_DESTACKING between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "'  and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "'  and " & ddlFilter.SelectedValue.ToString() & " = '" & txtCoilwise.Text.ToString().ToUpper() & "' order by STR_TM_DESTACKING"
                    End If
                    'filter = " where STR_TM_DESTACKING between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "'  and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "'  and LTR_PARAM_TEST IN('EL','RA') and " & ddlFilter.SelectedValue.ToString() & " = '" & txtCoilwise.Text.ToString().ToUpper() & "' order by STR_TM_DESTACKING"

                End If
                If rdbFullData.Checked Then
                    dt = objController.GetBafData(filter, "yes")
                Else
                    dt = objController.GetBafData(filter, "no")
                End If

                If dt.Rows.Count > 0 Then
                    If rdbFullData.Checked Then


                        For i As Integer = 0 To dt.Rows.Count - 1
                            Dim coil_id As String = dt.Rows(i)("CoilId")
                            Dim dtYSUTS As DataTable
                            dtYSUTS = objController.GetYsUtsData(coil_id)
                            If dtYSUTS.Rows.Count > 0 Then
                                dt.Rows(i)("YS") = dtYSUTS.Rows(0)("YS")
                                dt.Rows(i)("UTS") = dtYSUTS.Rows(0)("UTS")
                            End If
                        Next
                        gvData.Visible = True
                        gvData1.Visible = False
                        gvData.DataSource = dt
                        gvData.DataBind()
                        gvData.UseAccessibleHeader = True
                        gvData.HeaderRow.TableSection = TableRowSection.TableHeader
                    Else
                        gvData.Visible = False
                        gvData1.Visible = True
                        gvData1.DataSource = dt
                        gvData1.DataBind()
                        gvData1.UseAccessibleHeader = True
                        gvData1.HeaderRow.TableSection = TableRowSection.TableHeader
                    End If

                    'Dim i As Integer = 1
                    'Using ep As New ExcelPackage()
                    '    'For Each dt As DataTable In ds.Tables
                    '    'Dim ws As ExcelWorksheet = ep.Workbook.Worksheets.Add("s" & i)
                    '    Dim ws As ExcelWorksheet = ep.Workbook.Worksheets.Add("Download")
                    '    ws.Cells("A1").LoadFromDataTable(dt, True)

                    '    'i += 1
                    '    'Next
                    '    Using ms As New MemoryStream
                    '        Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    '        Response.AddHeader("content-disposition", "attachment; filename=download.xlsx")
                    '        ep.SaveAs(ms)
                    '        ms.WriteTo(Response.OutputStream)
                    '        Response.Flush()
                    '        Response.End()
                    '    End Using
                    'End Using





                End If
                If dt.Rows.Count = 0 Then
                    gvData.DataSource = ""
                    gvData.DataBind()
                    gvData1.DataSource = ""
                    gvData1.DataBind()
                End If

            Catch ex As Exception

            End Try

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub rdbFullData_CheckedChanged(sender As Object, e As System.EventArgs) Handles rdbFullData.CheckedChanged
        Try
            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            'objController.PopulateGradeForBAF(ddlGrade, dtStart, dtEnd)
            Dim filter As String = ""
            If ddlGrade.SelectedItem.Text.ToString <> "All" Then
                filter = " where  " & ddlFilter.SelectedValue.ToString() & " between '" & dtStart & "' and '" & dtEnd & "' and ANC_GRD_STEEL = '" & ddlGrade.SelectedItem.Text.ToString() & "' order by " & ddlFilter.SelectedValue.ToString()
            Else
                filter = " where  " & ddlFilter.SelectedValue.ToString() & " between '" & dtStart & "' and '" & dtEnd & "' order by " & ddlFilter.SelectedValue.ToString()

            End If
            'Dim filter As String = " where  " & ddlFilter.SelectedValue.ToString() & " between '" & dtStart & "' and '" & dtEnd & "'  and LTR_PARAM_TEST IN('EL','RA') order by " & ddlFilter.SelectedValue.ToString()

            dtCutOff = objController.GetBafCutOff()
            ViewState("cutoff") = dtCutOff
            If rdbFullData.Checked Then
                dt = objController.GetBafData(filter, "yes")
            Else
                dt = objController.GetBafData(filter, "no")
            End If
            If dt.Rows.Count > 0 Then
                If rdbFullData.Checked Then


                    For i As Integer = 0 To dt.Rows.Count - 1
                        Dim coil_id As String = dt.Rows(i)("CoilId")
                        Dim dtYSUTS As DataTable
                        dtYSUTS = objController.GetYsUtsData(coil_id)
                        If dtYSUTS.Rows.Count > 0 Then
                            dt.Rows(i)("YS") = dtYSUTS.Rows(0)("YS")
                            dt.Rows(i)("UTS") = dtYSUTS.Rows(0)("UTS")
                        End If
                    Next
                    gvData.Visible = True
                    gvData1.Visible = False
                    gvData.DataSource = dt
                    gvData.DataBind()
                    gvData.UseAccessibleHeader = True
                    gvData.HeaderRow.TableSection = TableRowSection.TableHeader
                Else
                    gvData.Visible = False
                    gvData1.Visible = True
                    gvData1.DataSource = dt
                    gvData1.DataBind()
                    gvData1.UseAccessibleHeader = True
                    gvData1.HeaderRow.TableSection = TableRowSection.TableHeader
                End If

            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub rdbFilterData_CheckedChanged(sender As Object, e As System.EventArgs) Handles rdbFilterData.CheckedChanged
        Try
            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            'objController.PopulateGradeForBAF(ddlGrade, dtStart, dtEnd)
            Dim filter As String = ""
            If ddlGrade.SelectedItem.Text.ToString <> "All" Then
                filter = " where  " & ddlFilter.SelectedValue.ToString() & " between '" & dtStart & "' and '" & dtEnd & "' and ANC_GRD_STEEL = '" & ddlGrade.SelectedItem.Text.ToString() & "' order by " & ddlFilter.SelectedValue.ToString()
            Else
                filter = " where  " & ddlFilter.SelectedValue.ToString() & " between '" & dtStart & "' and '" & dtEnd & "' order by " & ddlFilter.SelectedValue.ToString()

            End If
            'Dim filter As String = " where  " & ddlFilter.SelectedValue.ToString() & " between '" & dtStart & "' and '" & dtEnd & "'  and LTR_PARAM_TEST IN('EL','RA') order by " & ddlFilter.SelectedValue.ToString()

            dtCutOff = objController.GetBafCutOff()
            ViewState("cutoff") = dtCutOff
            If rdbFullData.Checked Then
                dt = objController.GetBafData(filter, "yes")
            Else
                dt = objController.GetBafData(filter, "no")
            End If
            If dt.Rows.Count > 0 Then
                If rdbFullData.Checked Then


                    For i As Integer = 0 To dt.Rows.Count - 1
                        Dim coil_id As String = dt.Rows(i)("CoilId")
                        Dim dtYSUTS As DataTable
                        dtYSUTS = objController.GetYsUtsData(coil_id)
                        If dtYSUTS.Rows.Count > 0 Then
                            dt.Rows(i)("YS") = dtYSUTS.Rows(0)("YS")
                            dt.Rows(i)("UTS") = dtYSUTS.Rows(0)("UTS")
                        End If
                    Next
                    gvData.Visible = True
                    gvData1.Visible = False
                    gvData.DataSource = dt
                    gvData.DataBind()
                    gvData.UseAccessibleHeader = True
                    gvData.HeaderRow.TableSection = TableRowSection.TableHeader
                Else
                    gvData.Visible = False
                    gvData1.Visible = True
                    gvData1.DataSource = dt
                    gvData1.DataBind()
                    gvData1.UseAccessibleHeader = True
                    gvData1.HeaderRow.TableSection = TableRowSection.TableHeader
                End If

            End If
        Catch ex As Exception

        End Try
    End Sub
End Class
