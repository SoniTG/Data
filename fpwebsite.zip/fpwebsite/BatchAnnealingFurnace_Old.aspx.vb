﻿Imports System.Data
Imports System.IO
Imports System.Data.OleDb

Partial Class BatchAnnealingFurnace_Old
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("ACPM_Ora").ConnectionString
    Dim Oleconnection_ora As New OleDbConnection(strConnectionString)
    Dim OleAdap As New OleDbDataAdapter
    Dim ds As New DataSet
    Dim dt As New DataTable
    Dim OleCom As New OleDbCommand
    Dim dtCutOff As DataTable
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    txtDate_TextChanged()
                End If
            Catch ex As Exception

            End Try

        End If
        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                'Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
                'Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                Dim dtStart As String = DateTime.Now.AddDays(-5).ToString("dd-MM-yyyy HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("dd-MM-yyyy HH:mm")
                Dim filter As String = " where T.STR_TM_DESTACKING between to_date('" & dtStart & "','DD-MM-YYYY HH24:MI:SS') and TO_date('" & dtEnd & "' ,'DD-MM-YYYY HH24:MI:SS') and T6.LTR_PARAM_TEST IN('EL','RA') order by T.STR_TM_DESTACKING"
                dtCutOff = objController.GetBafCutOff()
                ViewState("cutoff") = dtCutOff
                If GetData(filter).Rows.Count > 0 Then

                    gvData.DataSource = GetData(filter)
                    gvData.DataBind()
                    gvData.UseAccessibleHeader = True
                    gvData.HeaderRow.TableSection = TableRowSection.TableHeader


                End If


            Catch ex As Exception

            End Try



        End If
    End Sub
    Public Function GetData(ByVal Filter As String) As DataTable
        Try

            CloseConnection()
            Oleconnection_ora.Open()
            ds.Clear()
            dt.Clear()
            Dim OraQuery As String = "Select distinct t.str_id_stack As StackID, t.str_cycle As Cycle,ROUND(t.str_tminv_restab/3600,2) As Interruption,t.str_tm_heating_st As StackingTime, t.str_tm_cooling_st," & vbCrLf &
             "t.str_tm_destacking As DestackingTime, ROUND(t.str_tminv_ramp/3600,2) As RampUp,ROUND(t.str_dr_mx_tp_seg/60,2) AS SoakingTime,t.str_tot_h2_consp As H2Consumption," & vbCrLf &
             "t.str_recipe As Recipe,t.str_tp_mx_set_pt AS SoakingTemp, t.str_id_heat_hood As HHNo,t.str_id_base AS BaseId, t.str_id_cool_hood As CoolingHoodNo,t.str_tot_n2_consp AS N2Consumption,t.str_ms_tot_coils/1000 As StackWeight," & vbCrLf &
             "ROUND((t.str_tm_event11 - t.str_tm_event10) * 24 ,2) As HHCoolingTime,ROUND(ROUND((t.str_tm_event10 - t.str_tm_event9) * 24,2)  - t.str_tminv_ramp/3600 - t.str_dr_mx_tp_seg/60 - t.str_tminv_restab/3600,2) AS ControlledHeating,ROUND((t.str_tm_event16 - t.str_tm_event14) * 24,2) As CoolingHoodTime,ROUND((t.str_tm_event16 - t.str_tm_event15) * 24,2) As BypassCoolingTime," & vbCrLf &
             "t1.anc_position AS Position, t2.ccl_id_coil As CoilId,t2.ccl_shape_grade, t2.ccl_surface_grade as SurGrade,t1.anc_grd_steel as Grade, t2.ccl_tdc_aim As TDC,t2.ccl_tdc_actl, t2.ccl_sec1 As Thickness, t2.ccl_sec2 As Width,t3.spl_odia AS OD,ROUND(((1 - fhc_sec1_cr_coil / fhc_sec1_hr_coil1) * 100),2) As TCMReduction," & vbCrLf &
             "t5.sts_ts_sply_compl AS MNBayPostECL,(select NVL(ltr_test_value,0) from  V_LAB_TST_RES a  WHERE a.LTR_ID_COIL = t1.anc_id_coil  And   a.ltr_seq_sample = (select max(ltr_seq_sample) from v_lab_tst_res where ltr_id_coil = t1.anc_id_coil And a.ltr_param_test ='EL'))  as EL, (select NVL(ltr_test_value, 0) from  V_LAB_TST_RES a  WHERE a.LTR_ID_COIL = t1.anc_id_coil  And   a.ltr_seq_sample = (select max(ltr_seq_sample) from v_lab_tst_res" & vbCrLf &
              "where ltr_id_coil = t1.anc_id_coil And a.ltr_param_test ='RA'))  as RA,'' AS mnbaypreeclage,t5.STS_NO_CCSU AS ccsuno,ROUND((t3.SPL_TM_ROLL_ST - t.STR_TM_DESTACKING)* 24,0) AS ccsuage,'' AS H2Segment, '' AS H2Segmentwise, '' AS ys, '' AS uts,t4.fhc_ln_cr_coil/ 1000 AS TCMRollLength,T.STR_H2_CONSP1/10 as STR_H2_CONSP1,T.STR_H2_CONSP2/10 as STR_H2_CONSP2" & vbCrLf &
              ",T.STR_H2_CONSP3/10 as STR_H2_CONSP3,T.STR_H2_CONSP4/10 as STR_H2_CONSP4,T.STR_H2_CONSP5/10 as STR_H2_CONSP5,ROUND(STR_H2_CONSP1/NULLIF(ROUND((T.STR_TM_PURGE_ST2 - T.STR_TM_PURGE_ST1)* 24,2),0),2) as H2Consp10,ROUND(STR_H2_CONSP2/NULLIF(ROUND((T.STR_TM_PURGE_ST3 - T.STR_TM_PURGE_ST2)* 24,2),0),2) as H2Consp11,ROUND(STR_H2_CONSP3/NULLIF(ROUND((T.STR_TM_PURGE_ST4 - T.STR_TM_PURGE_ST3)* 24,2),0),2) as H2Consp12,ROUND(STR_H2_CONSP4/NULLIF(ROUND((T.STR_TM_PURGE_ST5 - T.STR_TM_PURGE_ST4)* 24,2),0),2) as H2Consp13,ROUND(STR_H2_CONSP5/NULLIF(ROUND((T.STR_TM_PURGE_ST6 - T.STR_TM_PURGE_ST5)* 24,2),0),2) as H2Consp14" & vbCrLf &
              ",T.STR_TM_PURGE_ST1,T.STR_TM_PURGE_ST2,T.STR_TM_PURGE_ST3,T.STR_TM_PURGE_ST4,T.STR_TM_PURGE_ST5,T.STR_TM_PURGE_ST6" & vbCrLf &
            "  From v_stack_result t INNER Join v_anealed_coil t1  On t.str_id_stack = t1.anc_id_stack  INNER Join v_cold_coil t2 ON t1.anc_id_coil = t2.ccl_id_coil  INNER Join v_skin_pass_coil t3 ON t1.anc_id_coil = t3.spl_id_coil" & vbCrLf &
             "INNER Join v_full_hard_coils t4 On t1.anc_id_coil = t4.fhc_id_coil  INNER Join v_stack_schd t5 ON t1.anc_id_stack = t5.sts_id_stack  INNER Join v_lab_tst_res t6 ON t1.anc_id_coil = t6.ltr_id_coil   And   t6.ltr_seq_sample = (select max(ltr_seq_sample) from v_lab_tst_res   where ltr_id_coil = t1.anc_id_coil)" & vbCrLf &
              "" & Filter & ""
            Ora_selectquery(OraQuery)
            OleAdap.Fill(ds)
            dt = ds.Tables(0)
            For i As Integer = 0 To dt.Rows.Count - 1
                Dim coil_id As String = dt.Rows(i)("CoilId")
                Dim dtYSUTS As DataTable
                dtYSUTS = objController.GetYsUtsData(coil_id)
                If dtYSUTS.Rows.Count > 0 Then
                    dt.Rows(i)("YS") = dtYSUTS.Rows(0)("YS")
                    dt.Rows(i)("UTS") = dtYSUTS.Rows(0)("UTS")
                End If
            Next
            Return dt

        Catch ex As Exception

        End Try
    End Function
    Sub CloseConnection()
        Try
            If Oleconnection_ora.State <> ConnectionState.Closed Then
                Oleconnection_ora.Close()
            End If
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

    End Sub
    Public Function Ora_selectquery(ByVal strselect As String) As OleDbDataAdapter
        Try

            OleCom.Connection = Oleconnection_ora
            OleCom.CommandText = strselect
            OleAdap.SelectCommand = OleCom

            Return OleAdap

        Catch ex As Exception

        End Try
    End Function


    Protected Sub rdbtnCoilwise_CheckedChanged(sender As Object, e As EventArgs) Handles rdbtnCoilwise.CheckedChanged
        Try
            txtCoilwise.Enabled = True
            txtCoilwise.Focus()
            gvData.DataSource = ""
            gvData.DataBind()
        Catch ex As Exception

        End Try


    End Sub
    Protected Sub rdbtnStackwise_CheckedChanged(sender As Object, e As EventArgs) Handles rdbtnStackwise.CheckedChanged
        Try
            txtCoilwise.Enabled = True
            txtCoilwise.Text = ""
            txtCoilwise.Focus()
            gvData.DataSource = ""
            gvData.DataBind()
        Catch ex As Exception

        End Try

    End Sub
    Protected Sub rdbtnDatewise_CheckedChanged(sender As Object, e As EventArgs) Handles rdbtnDatewise.CheckedChanged
        Try
            txtCoilwise.Enabled = False
            txtCoilwise.Text = ""
            txtDate_TextChanged()
        Catch ex As Exception

        End Try

    End Sub


    Protected Sub txtCoilwise_TextChanged(sender As Object, e As EventArgs) Handles txtCoilwise.TextChanged
        Try

            Dim filter As String = ""
            If rdbtnStackwise.Checked Then
                If txtCoilwise.Text <> "" Then
                    filter &= " where  T6.LTR_PARAM_TEST In('EL','RA') and anc_id_stack = '" & txtCoilwise.Text & "'"
                    If GetData(filter).Rows.Count > 0 Then
                        gvData.DataSource = GetData(filter)
                        gvData.DataBind()
                        gvData.UseAccessibleHeader = True
                        gvData.HeaderRow.TableSection = TableRowSection.TableHeader
                    End If
                End If
            ElseIf rdbtnCoilwise.Checked Then
                If txtCoilwise.Text <> "" Then
                    filter &= " where  T6.LTR_PARAM_TEST IN('EL','RA') and  ANC_ID_COIL = '" & txtCoilwise.Text & "'"
                    If GetData(filter).Rows.Count > 0 Then
                        gvData.DataSource = GetData(filter)
                        gvData.DataBind()
                        gvData.UseAccessibleHeader = True
                        gvData.HeaderRow.TableSection = TableRowSection.TableHeader
                    End If
                End If


            End If

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnDownload_Click(sender As Object, e As EventArgs) Handles btnDownload.Click
        If gvData.Rows.Count > 0 Then
            Try

                Response.ClearContent()
                Response.Buffer = True
                Response.AddHeader("content-disposition", String.Format("attachment; filename={0}", "CoilDetail.xls"))
                Response.ContentEncoding = Encoding.UTF8
                Response.ContentType = "application/ms-excel"
                Dim sw As New StringWriter()
                Dim htw As New HtmlTextWriter(sw)
                gvData.RenderControl(htw)
                Response.Write(sw.ToString())
                Response.End()

            Catch ex As Exception
            Finally

            End Try
        End If
    End Sub

    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)
        ' Verifies that the control is rendered 
    End Sub
    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try

            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            Dim filter As String = " where T.STR_TM_DESTACKING between to_date('" & CDate(dtStart).ToString("dd-MM-yyyy HH:mm:ss") & "','DD-MM-YYYY HH24:MI:SS') and TO_date('" & CDate(dtEnd).ToString("dd-MM-yyyy HH:mm:ss") & "' ,'DD-MM-YYYY HH24:MI:SS') and T6.LTR_PARAM_TEST IN('EL','RA') order by T.STR_TM_DESTACKING"
            If GetData(filter).Rows.Count > 0 Then
                gvData.DataSource = GetData(filter)
                gvData.DataBind()
                gvData.UseAccessibleHeader = True
                gvData.HeaderRow.TableSection = TableRowSection.TableHeader
            End If


        Catch ex As Exception

        End Try
    End Sub

    Private Sub gvData_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles gvData.RowDataBound
        Try

            If gvData.Rows.Count > 0 Then
                If e.Row.RowType = DataControlRowType.DataRow Then
                    Dim gr As String = DataBinder.Eval(e.Row.DataItem, "Grade")
                    Dim ccuage As Double = DataBinder.Eval(e.Row.DataItem, "ccsuage")
                    If dtCutOff Is Nothing Then
                        dtCutOff = CType(ViewState("cutoff"), DataTable)
                    End If
                    Dim dr() As DataRow = dtCutOff.Select("grade='" & gr & "' and parameter_name='ccsuage(hr)'")
                    If dr.Count = 0 Then
                        dr = dtCutOff.Select("grade='ALL' and parameter_name='ccsuage(hr)'")
                    End If
                    If dr.Count > 0 Then
                        If dr(0)(2) = "<" Then
                            If ccuage < dr(0)(3) Then
                                ''color red
                                CType(e.Row.FindControl("lblCCSUAge"), Label).ForeColor = Drawing.Color.Red
                            End If
                        ElseIf dr(0)(2) = ">" Then
                            If ccuage > dr(0)(3) Then
                                ''color red
                                CType(e.Row.FindControl("lblCCSUAge"), Label).ForeColor = Drawing.Color.Red
                            End If
                        End If
                    End If

                    Dim controlledheating As Double = 0
                    If Not IsDBNull(DataBinder.Eval(e.Row.DataItem, "ControlledHeating")) Then
                        controlledheating = DataBinder.Eval(e.Row.DataItem, "ControlledHeating")
                    Else
                        controlledheating = 0
                    End If
                    dr = dtCutOff.Select("grade='" & gr & "' and parameter_name='ControlledHeating(Hr)'")
                    If dr.Count = 0 Then
                        dr = dtCutOff.Select("grade='ALL' and parameter_name='ControlledHeating(Hr)'")
                    End If
                    If dr.Count > 0 Then
                        If dr(0)(2) = "<" Then
                            If controlledheating < dr(0)(3) Then
                                ''color red
                                CType(e.Row.FindControl("lblControlledHeating"), Label).ForeColor = Drawing.Color.Red
                            End If
                        ElseIf dr(0)(2) = ">" Then
                            If controlledheating > dr(0)(3) Then
                                ''color red
                                CType(e.Row.FindControl("lblControlledHeating"), Label).ForeColor = Drawing.Color.Red
                            End If
                        End If
                    End If
                    Dim interruption As Double = 0
                    If Not IsDBNull(DataBinder.Eval(e.Row.DataItem, "Interruption")) Then
                        interruption = DataBinder.Eval(e.Row.DataItem, "Interruption")
                    Else
                        interruption = 0
                    End If

                    'Dim interruption As Double = DataBinder.Eval(e.Row.DataItem, "Interruption")
                    dr = dtCutOff.Select("grade='" & gr & "' and parameter_name='Interruption(Hr)'")
                    If dr.Count = 0 Then
                        dr = dtCutOff.Select("grade='ALL' and parameter_name='Interruption(Hr)'")
                    End If
                    If dr.Count > 0 Then
                        If dr(0)(2) = "<" Then
                            If interruption < dr(0)(3) Then
                                ''color red
                                CType(e.Row.FindControl("lblInterruption"), Label).ForeColor = Drawing.Color.Red
                            End If
                        ElseIf dr(0)(2) = ">" Then
                            If interruption > dr(0)(3) Then
                                ''color red
                                CType(e.Row.FindControl("lblInterruption"), Label).ForeColor = Drawing.Color.Red
                            End If
                        End If
                    End If

                    Dim soakingtime As Double = 0
                    If Not IsDBNull(DataBinder.Eval(e.Row.DataItem, "SoakingTime")) Then
                        soakingtime = DataBinder.Eval(e.Row.DataItem, "SoakingTime")
                    Else
                        soakingtime = 0
                    End If
                    'Dim soakingtime As Double = DataBinder.Eval(e.Row.DataItem, "SoakingTime")
                    dr = dtCutOff.Select("grade='" & gr & "' and parameter_name='SoakingTime(Hr)'")
                    If dr.Count = 0 Then
                        dr = dtCutOff.Select("grade='ALL' and parameter_name='SoakingTime(Hr)'")
                    End If
                    If dr.Count > 0 Then
                        If dr(0)(2) = "<" Then
                            If soakingtime < dr(0)(3) Then
                                ''color red
                                CType(e.Row.FindControl("lblSoakingTime"), Label).ForeColor = Drawing.Color.Red
                            End If
                        ElseIf dr(0)(2) = ">" Then
                            If soakingtime > dr(0)(3) Then
                                ''color red
                                CType(e.Row.FindControl("lblSoakingTime"), Label).ForeColor = Drawing.Color.Red
                            End If
                        End If
                    End If

                    Dim hhcoolingtime As Double = 0
                    If Not IsDBNull(DataBinder.Eval(e.Row.DataItem, "HHCoolingTime")) Then
                        hhcoolingtime = DataBinder.Eval(e.Row.DataItem, "HHCoolingTime")
                    Else
                        hhcoolingtime = 0
                    End If
                    'Dim hhcoolingtime As Double = DataBinder.Eval(e.Row.DataItem, "HHCoolingTime")
                    dr = dtCutOff.Select("grade='" & gr & "' and parameter_name='HHCoolingTime(Hr)'")
                    If dr.Count = 0 Then
                        dr = dtCutOff.Select("grade='ALL' and parameter_name='HHCoolingTime(Hr)'")
                    End If
                    If dr.Count > 0 Then
                        If dr(0)(2) = "<" Then
                            If hhcoolingtime < dr(0)(3) Then
                                ''color red
                                CType(e.Row.FindControl("lblHHCoolingTime"), Label).ForeColor = Drawing.Color.Red
                            End If
                        ElseIf dr(0)(2) = ">" Then
                            If hhcoolingtime > dr(0)(3) Then
                                ''color red
                                CType(e.Row.FindControl("lblHHCoolingTime"), Label).ForeColor = Drawing.Color.Red
                            End If
                        End If
                    End If

                    Dim coolinghoodtime As Double = 0
                    If Not IsDBNull(DataBinder.Eval(e.Row.DataItem, "CoolingHoodTime")) Then
                        coolinghoodtime = DataBinder.Eval(e.Row.DataItem, "CoolingHoodTime")
                    Else
                        coolinghoodtime = 0
                    End If
                    'Dim coolinghoodtime As Double = DataBinder.Eval(e.Row.DataItem, "CoolingHoodTime")
                    dr = dtCutOff.Select("grade='" & gr & "' and parameter_name='CoolingHood/Time(Hr)'")
                    If dr.Count = 0 Then
                        dr = dtCutOff.Select("grade='ALL' and parameter_name='CoolingHood/Time(Hr)'")
                    End If
                    If dr.Count > 0 Then
                        If dr(0)(2) = "<" Then
                            If coolinghoodtime < dr(0)(3) Then
                                ''color red
                                CType(e.Row.FindControl("lblCoolingHoodTime"), Label).ForeColor = Drawing.Color.Red
                            End If
                        ElseIf dr(0)(2) = ">" Then
                            If coolinghoodtime > dr(0)(3) Then
                                ''color red
                                CType(e.Row.FindControl("lblCoolingHoodTime"), Label).ForeColor = Drawing.Color.Red
                            End If
                        End If
                    End If

                    Dim h2consp10 As Double = 0
                    If Not IsDBNull(DataBinder.Eval(e.Row.DataItem, "H2Consp10")) Then
                        h2consp10 = DataBinder.Eval(e.Row.DataItem, "H2Consp10")
                    Else
                        h2consp10 = 0
                    End If
                    ' Dim h2consp10 As Double = DataBinder.Eval(e.Row.DataItem, "H2Consp10")
                    dr = dtCutOff.Select("grade='" & gr & "' and parameter_name='H2Rate1(m3/hr)'")
                    If dr.Count = 0 Then
                        dr = dtCutOff.Select("grade='ALL' and parameter_name='H2Rate1(m3/hr)'")
                    End If
                    If dr.Count > 0 Then
                        If dr(0)(2) = "<" Then
                            If h2consp10 < dr(0)(3) Then
                                ''color red
                                CType(e.Row.FindControl("H2Consp10"), Label).ForeColor = Drawing.Color.Red
                            End If
                        ElseIf dr(0)(2) = ">" Then
                            If h2consp10 > dr(0)(3) Then
                                ''color red
                                CType(e.Row.FindControl("H2Consp10"), Label).ForeColor = Drawing.Color.Red
                            End If
                        End If
                    End If



                End If
            End If

        Catch ex As Exception

        End Try
    End Sub
End Class
