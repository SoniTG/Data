﻿Imports System.Data
Imports System.IO
Imports System.Data.OleDb
Imports System.Data.SqlClient

Partial Class BatchAnnealingFurnace_Viz
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Dim dt As New DataTable
    Dim dtCutOff As DataTable

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try

                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    txtDate_TextChanged()
                End If

            Catch ex As Exception

            End Try
        End If
        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-5).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                objController.PopulateGradeForBAFViz(ddlGrade, dtStart, dtEnd)
                Dim charReplace As String = ""
                Dim filter As String = ""
                If ddlColumn.SelectedItem.Text = "CCSU AGE" Then
                    charReplace = ddlColumn.SelectedValue.Replace("AS ccsuage", "")
                ElseIf ddlColumn.SelectedItem.Text = "RAMPUP" Then
                    charReplace = ddlColumn.SelectedValue.Replace("As RampUp", "")
                ElseIf ddlColumn.SelectedItem.Text = "HH COOLING TIME" Then
                    charReplace = ddlColumn.SelectedValue.Replace("As HHCoolingTime", "")

                End If

                If ddlGrade.SelectedItem.Text.ToLower = "all" Then
                    filter &= " where  STR_TM_DESTACKING between '" & dtStart & "' and '" & dtEnd & "' and " & charReplace & " is not null order by STR_TM_DESTACKING"
                Else
                    filter &= " where  STR_TM_DESTACKING between '" & dtStart & "' and '" & dtEnd & "'  and ANC_GRD_STEEL = '" & ddlGrade.SelectedItem.Text & "' and " & charReplace & " is not null order by STR_TM_DESTACKING"
                End If

                'dtCutOff = objController.GetBafCutOff()
                'ViewState("cutoff") = dtCutOff
                dt = objController.GetBAFVizData(filter, ddlColumn.SelectedValue)
                If dt.Rows.Count > 0 Then
                    Dim colName As String = ""
                    Dim min As String = ""
                    Dim max As String = ""
                    Dim unit As String = ""
                    If ddlColumn.SelectedItem.Text.Trim = "CCSU AGE" Then
                        colName = "ccsuage"
                        max = "120"
                        unit = "Kg"
                    ElseIf ddlColumn.SelectedItem.Text.Trim = "RAMPUP" Then
                        colName = "RampUp"
                        min = "1.5"
                        unit = "Kg"
                    ElseIf ddlColumn.SelectedItem.Text.Trim = "HH COOLING TIME" Then
                        colName = "HHCoolingTime"
                        min = "-1"
                        unit = "Hr"
                    End If
                    objController.PlotLineChartForBAFViz(dt, "STR_TM_DESTACKING", colName, Lit1, "container", "plot1", "", unit, "ANC_GRD_STEEL", min, max)
                Else
                    Lit1.Text = ""
                End If


            Catch ex As Exception

            End Try




        End If
    End Sub
    'Public Sub DrawChart()
    '    Try

    '        Dim dtStart As String = hfFrom.Value
    '        Dim dtEnd As String = hfTo.Value
    '        Dim charReplace As String = ""
    '        Dim filter As String = ""
    '        If ddlColumn.SelectedItem.Text = "CCSU AGE" Then
    '            charReplace = ddlColumn.SelectedValue.Replace("AS ccsuage", "")
    '        ElseIf ddlColumn.SelectedItem.Text = "RAMPUP" Then
    '            charReplace = ddlColumn.SelectedValue.Replace("As RampUp", "")
    '        End If

    '        If ddlGrade.SelectedItem.Text.ToLower = "all" Then
    '            filter &= " where  STR_TM_DESTACKING between '" & dtStart & "' and '" & dtEnd & "' and " & charReplace & " is not null order by STR_TM_DESTACKING"
    '        Else
    '            filter &= " where  STR_TM_DESTACKING between '" & dtStart & "' and '" & dtEnd & "'  and ANC_GRD_STEEL = '" & ddlGrade.SelectedItem.Text & "' and " & charReplace & " is not null order by STR_TM_DESTACKING"
    '        End If
    '        dt = objController.GetBAFVizData(filter, ddlColumn.SelectedValue)
    '        If dt.Rows.Count > 0 Then
    '            Dim colName As String = ""
    '            Dim min As String = ""
    '            Dim max As String = ""
    '            If ddlColumn.SelectedItem.Text.Trim = "CCSU AGE" Then
    '                colName = "ccsuage"
    '                max = "120"
    '            ElseIf ddlColumn.SelectedItem.Text.Trim = "RAMPUP" Then
    '                colName = "RampUp"
    '                min = "1.5"
    '            End If
    '            'objController.PlotLineChartForBAFViz(dt, "STR_TM_DESTACKING", colName, Lit1, "container", "plot1", "", "", "0", min, max)

    '        End If

    '    Catch ex As Exception

    '    End Try
    'End Sub

    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try

            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            Dim charReplace As String = ""
            Dim filter As String = ""
            If ddlColumn.SelectedItem.Text = "CCSU AGE" Then
                charReplace = ddlColumn.SelectedValue.Replace("AS ccsuage", "")
            ElseIf ddlColumn.SelectedItem.Text = "RAMPUP" Then
                charReplace = ddlColumn.SelectedValue.Replace("As RampUp", "")
            ElseIf ddlColumn.SelectedItem.Text = "HH COOLING TIME" Then
                charReplace = ddlColumn.SelectedValue.Replace("As HHCoolingTime", "")
            End If

            If ddlGrade.SelectedItem.Text.ToLower = "all" Then
                filter &= " where  STR_TM_DESTACKING between '" & dtStart & "' and '" & dtEnd & "' and " & charReplace & " is not null order by STR_TM_DESTACKING"
            Else
                filter &= " where  STR_TM_DESTACKING between '" & dtStart & "' and '" & dtEnd & "'  and ANC_GRD_STEEL = '" & ddlGrade.SelectedItem.Text & "' and " & charReplace & " is not null order by STR_TM_DESTACKING"
            End If
            dt = objController.GetBAFVizData(filter, ddlColumn.SelectedValue)
            If dt.Rows.Count > 0 Then
                Dim colName As String = ""
                Dim min As String = ""
                Dim max As String = ""
                Dim unit As String = ""
                If ddlColumn.SelectedItem.Text.Trim = "CCSU AGE" Then
                    colName = "ccsuage"
                    max = "120"
                    unit = "Kg"
                ElseIf ddlColumn.SelectedItem.Text.Trim = "RAMPUP" Then
                    colName = "RampUp"
                    min = "1.5"
                    unit = "Kg"
                ElseIf ddlColumn.SelectedItem.Text.Trim = "HH COOLING TIME" Then
                    colName = "HHCoolingTime"
                    min = "-1"
                    unit = "Hr"
                End If
                objController.PlotLineChartForBAFViz(dt, "STR_TM_DESTACKING", colName, Lit1, "container", "plot1", "", unit, "ANC_GRD_STEEL", min, max)
            Else
                Lit1.Text = ""
            End If

        Catch ex As Exception

        End Try
        ' DrawChart()
    End Sub

    Protected Sub ddlGrade_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlGrade.SelectedIndexChanged
        Try
            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            Dim charReplace As String = ""
            Dim filter As String = ""
            If ddlColumn.SelectedItem.Text = "CCSU AGE" Then
                charReplace = ddlColumn.SelectedValue.Replace("AS ccsuage", "")
            ElseIf ddlColumn.SelectedItem.Text = "RAMPUP" Then
                charReplace = ddlColumn.SelectedValue.Replace("As RampUp", "")
            ElseIf ddlColumn.SelectedItem.Text = "HH COOLING TIME" Then
                charReplace = ddlColumn.SelectedValue.Replace("As HHCoolingTime", "")
            End If

            If ddlGrade.SelectedItem.Text.ToLower = "all" Then
                filter &= " where  STR_TM_DESTACKING between '" & dtStart & "' and '" & dtEnd & "' and " & charReplace & " is not null order by STR_TM_DESTACKING"
            Else
                filter &= " where  STR_TM_DESTACKING between '" & dtStart & "' and '" & dtEnd & "'  and ANC_GRD_STEEL = '" & ddlGrade.SelectedItem.Text & "' and " & charReplace & " is not null order by STR_TM_DESTACKING"
            End If
            dt = objController.GetBAFVizData(filter, ddlColumn.SelectedValue)
            If dt.Rows.Count > 0 Then
                Dim colName As String = ""
                Dim min As String = ""
                Dim max As String = ""
                Dim unit As String = ""
                If ddlColumn.SelectedItem.Text.Trim = "CCSU AGE" Then
                    colName = "ccsuage"
                    max = "120"
                    unit = "Kg"
                ElseIf ddlColumn.SelectedItem.Text.Trim = "RAMPUP" Then
                    colName = "RampUp"
                    min = "1.5"
                    unit = "Kg"
                ElseIf ddlColumn.SelectedItem.Text.Trim = "HH COOLING TIME" Then
                    colName = "HHCoolingTime"
                    min = "-1"
                    unit = "Hr"
                End If
                objController.PlotLineChartForBAFViz(dt, "STR_TM_DESTACKING", colName, Lit1, "container", "plot1", "", unit, "ANC_GRD_STEEL", min, max)
            Else
                Lit1.Text = ""
            End If
        Catch ex As Exception

        End Try
        'DrawChart()
    End Sub
    
    Protected Sub ddlColumn_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlColumn.SelectedIndexChanged
        Try
            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            Dim charReplace As String = ""
            Dim filter As String = ""
            If ddlColumn.SelectedItem.Text = "CCSU AGE" Then
                charReplace = ddlColumn.SelectedValue.Replace("AS ccsuage", "")
            ElseIf ddlColumn.SelectedItem.Text = "RAMPUP" Then
                charReplace = ddlColumn.SelectedValue.Replace("As RampUp", "")
            ElseIf ddlColumn.SelectedItem.Text = "HH COOLING TIME" Then
                charReplace = ddlColumn.SelectedValue.Replace("As HHCoolingTime", "")
            End If

            If ddlGrade.SelectedItem.Text.ToLower = "all" Then
                filter &= " where  STR_TM_DESTACKING between '" & dtStart & "' and '" & dtEnd & "' and " & charReplace & " is not null order by STR_TM_DESTACKING"
            Else
                filter &= " where  STR_TM_DESTACKING between '" & dtStart & "' and '" & dtEnd & "'  and ANC_GRD_STEEL = '" & ddlGrade.SelectedItem.Text & "' and " & charReplace & " is not null order by STR_TM_DESTACKING"
            End If
            dt = objController.GetBAFVizData(filter, ddlColumn.SelectedValue)
            If dt.Rows.Count > 0 Then
                Dim colName As String = ""
                Dim min As String = ""
                Dim max As String = ""
                Dim unit As String = ""
                If ddlColumn.SelectedItem.Text.Trim = "CCSU AGE" Then
                    colName = "ccsuage"
                    max = "120"
                    unit = "Kg"
                ElseIf ddlColumn.SelectedItem.Text.Trim = "RAMPUP" Then
                    colName = "RampUp"
                    min = "1.5"
                    unit = "Kg"
                ElseIf ddlColumn.SelectedItem.Text.Trim = "HH COOLING TIME" Then
                    colName = "HHCoolingTime"
                    min = "-1"
                    unit = "Hr"
                End If
                objController.PlotLineChartForBAFViz(dt, "STR_TM_DESTACKING", colName, Lit1, "container", "plot1", "", unit, "ANC_GRD_STEEL", min, max)
            Else
                Lit1.Text = ""
            End If


        Catch ex As Exception

        End Try
        ' DrawChart()
    End Sub

   
End Class
