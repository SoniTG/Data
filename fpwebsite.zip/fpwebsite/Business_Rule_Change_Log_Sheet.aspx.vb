﻿Imports System.Data
Imports System.IO
Imports System.Data.OleDb
Imports System.Data.SqlClient
Imports OfficeOpenXml

Partial Class Business_Rule_Change_Log_Sheet
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Dim dt As New DataTable
    Dim dtCutOff As DataTable

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try

                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    txtDate_TextChanged()
                End If

            Catch ex As Exception

            End Try
        End If
        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))

                Dim dtStart As String = DateTime.Now.AddDays(-29).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                objController.PopulateBusinessRuleForLogDetails(ddlBRule, dtStart, dtEnd, "")
                Dim filter As String = ""
                If ddlBRule.SelectedItem.Text.ToString <> "All" Then
                    filter = " where  UPDATED_ON between '" & dtStart & "' and '" & dtEnd & "' and B_Rule = '" & ddlBRule.SelectedItem.Text.ToString() & "' order by UPDATED_ON desc"
                Else
                    filter = " where  UPDATED_ON between '" & dtStart & "' and '" & dtEnd & "' order by UPDATED_ON desc"

                End If

                dt = objController.GetDataForLogDetails(filter)

                If dt.Rows.Count > 0 Then


                    gvData.DataSource = dt
                    gvData.DataBind()
                    gvData.UseAccessibleHeader = True
                    gvData.HeaderRow.TableSection = TableRowSection.TableHeader
                End If


            Catch ex As Exception

            End Try




        End If
    End Sub


    Protected Sub btnDownload_Click(sender As Object, e As EventArgs) Handles btnDownload.Click

        If gvData.Rows.Count > 0 Then
            Try

                Response.ClearContent()
                Response.Buffer = True
                Response.AddHeader("content-disposition", String.Format("attachment; filename={0}", "Business_Rule_Log_Details.xls"))
                Response.ContentEncoding = Encoding.UTF8
                Response.ContentType = "application/ms-excel"
                Dim sw As New StringWriter()
                Dim htw As New HtmlTextWriter(sw)
                gvData.RenderControl(htw)
                Response.Write(sw.ToString())
                Response.End()

            Catch ex As Exception
            Finally

            End Try
        End If

    End Sub

    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)
        ' Verifies that the control is rendered 
    End Sub
    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try

            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            Dim filter As String = ""


            objController.PopulateBusinessRuleForLogDetails(ddlBRule, dtStart, dtEnd, "")

            If ddlBRule.SelectedItem.Text.ToString <> "All" Then
                filter = " where  UPDATED_ON between '" & dtStart & "' and '" & dtEnd & "' and B_Rule = '" & ddlBRule.SelectedItem.Text.ToString() & "' order by UPDATED_ON desc"
            Else
                filter = " where  UPDATED_ON between '" & dtStart & "' and '" & dtEnd & "' order by UPDATED_ON desc"

            End If

            dt = objController.GetDataForLogDetails(filter)

            If dt.Rows.Count > 0 Then


                gvData.DataSource = dt
                gvData.DataBind()
                gvData.UseAccessibleHeader = True
                gvData.HeaderRow.TableSection = TableRowSection.TableHeader
            End If



            If dt.Rows.Count = 0 Then
                gvData.DataSource = ""
                gvData.DataBind()

            End If

        Catch ex As Exception

        End Try
    End Sub




    Protected Sub ddlBRule_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlBRule.SelectedIndexChanged


        Try

            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            Dim filter As String = ""


            If ddlBRule.SelectedItem.Text.ToString <> "All" Then
                filter = " where  UPDATED_ON between '" & dtStart & "' and '" & dtEnd & "' and B_Rule = '" & ddlBRule.SelectedItem.Text.ToString() & "' order by UPDATED_ON desc"
            Else
                filter = " where  UPDATED_ON between '" & dtStart & "' and '" & dtEnd & "' order by UPDATED_ON desc"

            End If

            dt = objController.GetDataForLogDetails(filter)

            If dt.Rows.Count > 0 Then


                gvData.DataSource = dt
                gvData.DataBind()
                gvData.UseAccessibleHeader = True
                gvData.HeaderRow.TableSection = TableRowSection.TableHeader
            End If

            If dt.Rows.Count = 0 Then
                gvData.DataSource = ""
                gvData.DataBind()

            End If

        Catch ex As Exception

        End Try


    End Sub




End Class
