﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Math
Imports OfficeOpenXml.FormulaParsing.Excel.Functions.Math
Imports Microsoft.VisualBasic
Imports OfficeOpenXml
Imports System.IO

Partial Class CGL2_Zn_Yield
    Inherits System.Web.UI.Page
    Dim objDataHandler As New DataHandler
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub

    Sub UserMsgBoxSuccess(ByVal Message As String, ByVal Url As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalertandredirect('" + Message + "', '" + Url + "');", True)
    End Sub

    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub

    Function getdatatable(ByVal query As String) As DataTable
        Dim fndatatable As New DataTable
        Dim connection As String = "Password=Welcome@135;Persist Security Info=True;User ID=153521;Initial Catalog=FP_PROCESS_DATA;Data Source=176.0.0.60\lptgsqldev"
        Using con As New SqlConnection(connection)
            Using cmd As New SqlCommand(query, con)
                cmd.CommandType = CommandType.Text
                Using sda As New SqlDataAdapter(cmd)
                    'Using dt As New DataTable()
                    sda.Fill(fndatatable)
                    'End Using
                End Using
            End Using
        End Using
        Return fndatatable
    End Function

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim fromDt As String = DateTime.Now.AddDays(-29).ToString("yyyy-MM-dd 06:00:00")
            Dim toDt As String = DateTime.Now.AddDays(1).ToString("yyyy-MM-dd 06:00:00")
            Dim orfrom As DateTime = DateTime.Now.AddDays(-29)
            Dim orto As DateTime = DateTime.Now.ToString("yyyy-MM-dd 06:00:00")
            hfFrom.Value = fromDt
            hfTo.Value = toDt
            fnquery(fromDt, toDt)
        End If

        If Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim p As String = Request("__EVENTARGUMENT")
                If (p = "d") Then
                    Dim fromDt As String = hfFrom.Value
                    Dim toDt As String = CDate(hfTo.Value).AddDays(1).ToString("yyyy-MM-dd 06:00:00")
                    hfFrom.Value = fromDt
                    hfTo.Value = toDt
                    fnquery(fromDt, toDt)
                End If
            Catch ex As Exception
                Throw ex
            End Try
        End If

    




    End Sub

    Public Sub fnquery(ByVal fromdt As Date, ByVal todt As Date)
        Dim fromDtq As String = fromdt.ToString("dd-MMM-yy")
        Dim toDtq As String = todt.ToString("dd-MMM-yy")
        Dim q As String = "select LMO_TS_ROL_END,LMO_id_moth_coil,lmo_yld_ratio,LMO_CD_PROD,pdl_id_coil, pdl_cd_coat"
        q &= " from V_CG2_MOTHER_COIL,v_pr_data_ip_cg2"
        q &= " where pdl_id_coil = LMO_id_moth_coil and LMO_TS_ROL_END between '" & fromDtq & "' and '" & toDtq & "'"
        q &= " order by LMO_TS_ROL_END desc"
        Dim dt As DataTable = objDataHandler.GetOracleData(q)

        PlotLinegraph_all(dt, "LMO_TS_ROL_END", "lmo_yld_ratio", Lit1, "main1", "plot", "Yield", fromDtq, toDtq)
        PlotLinegraph_all1(dt, "LMO_TS_ROL_END", "lmo_yld_ratio", Lit2, "main2", "plot2", "Yield2", fromDtq, toDtq)
    End Sub
    Public Sub PlotLinegraph_all1(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal YAxisLabelName As String, ByVal fromdtq As String, ByVal todtq As String)
        Try
            LiteralName.Text = ""
            Dim line1 As String = ""
            Dim line2 As String = ""
            Dim line3 As String = ""
            Dim line4 As String = ""
            Dim line5 As String = ""
            Dim line6 As String = ""
            'Dim max As Integer = 0
            'Dim min As Integer = 999
            'Dim max As Integer = dt.AsEnumerable().Max(Function(row) row(YAxisColName)) + 1
            'Dim min As Integer = dt.AsEnumerable().Min(Function(row) row(YAxisColName)) - 1
            'If dt.Rows.Count > 0 Then
            '    For i As Integer = 0 To dt.Rows.Count - 1
            '        Try
            '            If dt.Rows(i)("LMO_CD_PROD") = "C03" And Not IsDBNull(dt.Rows(i)(YAxisColName)) Then
            '                If dt.Rows(i)(YAxisColName) > max Then
            '                    max = dt.Rows(i)(YAxisColName)
            '                ElseIf dt.Rows(i)(YAxisColName) < min Then
            '                    min = dt.Rows(i)(YAxisColName)
            '                End If
            '                line1 &= "['" & (Convert.ToDateTime(dt.Rows(i)(XAxisColName))).ToString("yyyy-MM-dd HH:mm:ss") & "', " & Math.Round(dt.Rows(i)(YAxisColName), 2) & "],"
            '            ElseIf dt.Rows(i)("LMO_CD_PROD") = "C10" And Not IsDBNull(dt.Rows(i)(YAxisColName)) Then
            '                If dt.Rows(i)(YAxisColName) > max Then
            '                    max = dt.Rows(i)(YAxisColName)
            '                ElseIf dt.Rows(i)(YAxisColName) < min Then
            '                    min = dt.Rows(i)(YAxisColName)
            '                End If
            '                line2 &= "['" & (Convert.ToDateTime(dt.Rows(i)(XAxisColName))).ToString("yyyy-MM-dd HH:mm:ss") & "', " & Math.Round(dt.Rows(i)(YAxisColName), 2) & "],"
            '            End If
            '        Catch ex As Exception
            '            Throw ex
            '        End Try
            '    Next
            'End If
            If dt.Rows.Count > 0 Then

                dt.Columns.Add("zn_weightdiff", GetType(Double))

                For i As Integer = 0 To dt.Rows.Count - 1
                    Try


                        Dim q1 As String = "select * from v_lab_tst_res where ltr_id_coil like '" & dt.Rows(i)("LMO_id_moth_coil").ToString.Substring(0, 6) & "%' and LTR_param_test in ('ZCQTTM','ZCQTBM')"
                        Dim dtq1 As DataTable = objDataHandler.GetOracleData(q1)
                        'If dtq1.Rows.Count = 0 Then
                        '    Continue For
                        'End If
                        Dim q As String = "select distinct lgc_ts_end, LGC_id_coil as D_coil_id,lgc_id_moth_coil,LGC_SEC1_COIL as thick,LGC_SEC2_COIL as width,lgc_ms_coil_actl as D_coil_wt,"
                        q &= "LMO_ID_MOTH_COIL as M_coil_id,LMO_MS_COIL as MC_WT,LMO_LN_HD_ENT as head_shear_length,LMO_LN_TAIL_ENT as tail_shear_length, "
                        q &= "pdl_cD_coat as Zn_coat_gsm "
                        q &= " from v_cg2_galv_coil,V_CG2_MOTHER_COIL,v_pr_data_ip_cg2"
                        q &= " where lgc_id_moth_coil = LMO_ID_MOTH_COIL and PDL_ID_COIL = LMO_ID_MOTH_COIL and LGC_id_coil like '" & dt.Rows(i)("LMO_id_moth_coil").ToString.Substring(0, 6) & "%'"
                        q &= " order by lgc_ts_end desc"
                        Dim dt1 As DataTable = objDataHandler.GetOracleData(q)
                        Dim head_SL As Double = dt1.Rows(0)("head_shear_length")
                        Dim tail_SL As Double = dt1.Rows(0)("tail_shear_length")
                        If head_SL = 0 Or tail_SL = 0 Then
                            Continue For
                        End If
                        If dt1.Rows(0)("M_coil_id").ToString.Contains("Z") Or dt1.Rows(0)("D_coil_id").ToString.Contains("Z") Then
                            Continue For
                        End If
                        Dim shear_lenght As Double = head_SL + tail_SL
                        Dim q2 As String = "select fhc_ln_cr_coil from V_FULL_HARD_COILS   where fhc_id_coil like '" & dt.Rows(i)("LMO_id_moth_coil").ToString.Substring(0, 6) & "%'"

                        Dim dtq2 As DataTable = objDataHandler.GetOracleData(q2)
                        Dim mc_lenght As Double = dtq2.Rows(0)(0)

                        Dim mc_wt As Double = dt1.Rows(0)("MC_WT")
                        Dim shear_wt As Double = shear_lenght / (mc_lenght) * mc_wt
                        Dim sa As Double = (mc_lenght - shear_lenght) * dt1.Rows(0)("width") / 1000
                        Dim aim_zn_wt As Double = (dt1.Rows(0)("Zn_coat_gsm").ToString.Substring(1) + 4) * sa / 1000
                        Dim d_wt As Double = 0
                        For j As Integer = 0 To dt1.Rows.Count - 1
                            d_wt = d_wt + dt1.Rows(j)("D_coil_wt")
                        Next
                        Dim sum_ct_b As Double = 0
                        Dim zn_coating As Double
                        For j As Integer = 0 To dtq1.Rows.Count - 1
                            sum_ct_b = sum_ct_b + dtq1.Rows(j)("ltr_test_value")
                        Next
                        If dt1.Rows.Count > 0 Then
                            sum_ct_b = sum_ct_b / dt1.Rows.Count
                            zn_coating = sum_ct_b / (dt1.Rows(0)("Zn_coat_gsm").ToString.Substring(1) + 4) * 100
                        Else
                            zn_coating = 0
                        End If

                        Dim act_coating_wt As Double = d_wt - mc_wt + shear_wt
                        Dim zn_weightdiff As Double = act_coating_wt / aim_zn_wt * 100


                        dt.Rows(i)("zn_weightdiff") = zn_weightdiff


                        'Dim dtOrig As DataTable = New DataTable()
                        ''dtOrig.Columns.Add(New DataColumn("Id", Type.GetType("System.Int32")))
                        'dtOrig.Columns.Add(New DataColumn("", Type.GetType("System.String")))
                        'Dim dtCopy As DataTable = New DataTable()
                        ''Dim dtOrig As DataTable = New DataTable()
                        ''create copy of original datatable (structure)
                        'dtCopy = dtOrig.Clone()
                        'dtCopy = dtOrig.Copy()
                        'dtCopy.Columns.Add(New DataColumn("PDL_ID_COIL", Type.GetType("System.String")))
                        'dtCopy.Columns.Add("pdl_cD_coat")
                        'dtCopy.Columns.Add("Zn_coat_gsm")


                        'For k As Integer = 0 To dtCopy.Rows.Count - 1
                        '    Dim dr As DataRow = dtCopy.Rows(k)
                        '    dr("value") = 100 * (k + 1.5)
                        '    'list.Add(new zn_weightdff_new {"value"})
                        'Next





                        If Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour > 6 And Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour <= 14 Then
                            line1 &= "['" & (Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end"))).ToString("yyyy-MM-dd HH:mm:ss") & "', " & Math.Round(zn_weightdiff, 2) & "],"
                            line4 &= "['" & (Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end"))).ToString("yyyy-MM-dd HH:mm:ss") & "', " & Math.Round(zn_coating, 2) & "],"
                        ElseIf Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour > 14 And Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour <= 22 Then
                            line2 &= "['" & (Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end"))).ToString("yyyy-MM-dd HH:mm:ss") & "', " & Math.Round(zn_weightdiff, 2) & "],"
                            line5 &= "['" & (Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end"))).ToString("yyyy-MM-dd HH:mm:ss") & "', " & Math.Round(zn_coating, 2) & "],"
                            'ElseIf Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour > 22 And Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour <= 6 Then
                        Else
                            line3 &= "['" & (Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end"))).ToString("yyyy-MM-dd HH:mm:ss") & "', " & Math.Round(zn_weightdiff, 2) & "],"
                            line6 &= "['" & (Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end"))).ToString("yyyy-MM-dd HH:mm:ss") & "', " & Math.Round(zn_coating, 2) & "],"
                        End If

                    Catch ex As Exception
                        Continue For
                    End Try
                Next
            End If

            Dim dt_avg As DataTable = dt.DefaultView.ToTable(True, "LMO_CD_PROD", "PDL_CD_COAT")

            dt_avg.Columns.Add("Avg", GetType(Double))

            For row As Integer = 0 To dt_avg.Rows.Count - 1
                Dim avg As Double = dt.Compute("Avg(zn_weightdiff)", "LMO_CD_PROD='" & dt_avg.Rows(row)(0) & "' and PDL_CD_COAT='" & dt_avg.Rows(row)(1) & "'")
                dt_avg.Rows(row)(2) = Math.Round(avg, 2)
            Next

            gridViewDetails.DataSource = dt_avg
            gridViewDetails.DataBind()
            ContainerName = ContainerName.Replace(" ", "_")
            Dim js As String = ""
            js &= " <script type='text/javascript'> var " & PlotName & " = echarts.init(document.getElementById('" & ContainerName & "'));"
            js &= "option = {tooltip: {trigger: 'item'},"
            js &= "legend: {},"
            js &= "grid: {left:   '10%',right:  '10%',bottom:  '10%',containLabel: true},"
            js &= "toolbox: {show: true,feature: {dataZoom: {yAxisIndex: 'none'},restore: {},saveAsImage: {}}},"
            js &= "xAxis: {type: 'time',axisLabel : { formatter: '{value}',fontWeight:'bold',rotate: 45},name: '" & XAxisColName & "',nameLocation: 'middle',nameGap: 70,nameTextStyle: {fontWeight:'bold'},"
            js &= "splitLine: {show:true,lineStyle: {color: 'grey'}}},"
            js &= " yAxis : [{type : 'value',max:130,min:80,axisLabel : {formatter: '{value}',fontWeight:'bold'},name: '" & YAxisLabelName & "',nameLocation: 'middle',nameGap: 50,nameTextStyle: {fontWeight:'bold'} }],"
            js &= "dataZoom: [{type: 'slider',xAxisIndex: 0,filterMode: 'empty'},{type: 'slider',yAxisIndex: 0,filterMode: 'empty'},{type: 'inside',xAxisIndex: 0,filterMode: 'empty'},{type: 'inside',yAxisIndex: 0,filterMode: 'empty'}],"
            js &= "series: [{name: 'Zn yield (Based on coil weigth) A',type: 'bar',color: '#6bfc03' ,symbolSize:8,"
            js &= "data: [" & line1 & "] },"
            js &= "{name: 'Zn yield (Based on coil weigth) B',type: 'bar',color: '#00d639' ,symbolSize:8,data: [" & line2 & "] },"
            js &= "{name: 'Zn yield (Based on coil weigth) C',type: 'bar',color: '#027521' ,symbolSize:8,data: [" & line3 & "] },"
            js &= "{name: 'Zn yield (based on Coating) A',type: 'bar',color: '#e35d5d' ,symbolSize:8,data: [" & line4 & "] },"
            js &= "{name: 'Zn yield (based on Coating) B',type: 'bar',color: '#ed0000' ,symbolSize:8,data: [" & line5 & "] },"
            js &= "{name: 'Zn yield (based on Coating) C',type: 'bar',color: '#7d0404' ,symbolSize:8,data: [" & line6 & "] },"
            js &= "]};"
            js &= "" & PlotName & ".setOption(option);</script>"
            LiteralName.Text = js
        Catch ex As Exception
            'Continue For
        End Try


    End Sub
    Public Sub PlotLinegraph_all(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal YAxisLabelName As String, ByVal fromdtq As String, ByVal todtq As String)
        Try
            LiteralName.Text = ""
            Dim line1 As String = ""
            Dim line2 As String = ""
            Dim line3 As String = ""
            Dim line4 As String = ""
            Dim line5 As String = ""
            Dim line6 As String = ""
            'Dim max As Integer = 0
            'Dim min As Integer = 999
            'Dim max As Integer = dt.AsEnumerable().Max(Function(row) row(YAxisColName)) + 1
            'Dim min As Integer = dt.AsEnumerable().Min(Function(row) row(YAxisColName)) - 1
            'If dt.Rows.Count > 0 Then
            '    For i As Integer = 0 To dt.Rows.Count - 1
            '        Try
            '            If dt.Rows(i)("LMO_CD_PROD") = "C03" And Not IsDBNull(dt.Rows(i)(YAxisColName)) Then
            '                If dt.Rows(i)(YAxisColName) > max Then
            '                    max = dt.Rows(i)(YAxisColName)
            '                ElseIf dt.Rows(i)(YAxisColName) < min Then
            '                    min = dt.Rows(i)(YAxisColName)
            '                End If
            '                line1 &= "['" & (Convert.ToDateTime(dt.Rows(i)(XAxisColName))).ToString("yyyy-MM-dd HH:mm:ss") & "', " & Math.Round(dt.Rows(i)(YAxisColName), 2) & "],"
            '            ElseIf dt.Rows(i)("LMO_CD_PROD") = "C10" And Not IsDBNull(dt.Rows(i)(YAxisColName)) Then
            '                If dt.Rows(i)(YAxisColName) > max Then
            '                    max = dt.Rows(i)(YAxisColName)
            '                ElseIf dt.Rows(i)(YAxisColName) < min Then
            '                    min = dt.Rows(i)(YAxisColName)
            '                End If
            '                line2 &= "['" & (Convert.ToDateTime(dt.Rows(i)(XAxisColName))).ToString("yyyy-MM-dd HH:mm:ss") & "', " & Math.Round(dt.Rows(i)(YAxisColName), 2) & "],"
            '            End If
            '        Catch ex As Exception
            '            Throw ex
            '        End Try
            '    Next
            'End If
            If dt.Rows.Count > 0 Then
                For i As Integer = 0 To dt.Rows.Count - 1
                    Try


                        Dim q1 As String = "select * from v_lab_tst_res where ltr_id_coil like '" & dt.Rows(i)("LMO_id_moth_coil").ToString.Substring(0, 6) & "%' and LTR_param_test in ('ZCQTTM','ZCQTBM')"
                        Dim dtq1 As DataTable = objDataHandler.GetOracleData(q1)
                        'If dtq1.Rows.Count = 0 Then
                        '    Continue For
                        'End If
                        Dim q As String = "select distinct lgc_ts_end, LGC_id_coil as D_coil_id,lgc_id_moth_coil,LGC_SEC1_COIL as thick,LGC_SEC2_COIL as width,lgc_ms_coil_actl as D_coil_wt,"
                        q &= "LMO_ID_MOTH_COIL as M_coil_id,LMO_MS_COIL as MC_WT,LMO_LN_HD_ENT as head_shear_length,LMO_LN_TAIL_ENT as tail_shear_length, "
                        q &= "pdl_cD_coat as Zn_coat_gsm "
                        q &= " from v_cg2_galv_coil,V_CG2_MOTHER_COIL,v_pr_data_ip_cg2"
                        q &= " where lgc_id_moth_coil = LMO_ID_MOTH_COIL and PDL_ID_COIL = LMO_ID_MOTH_COIL and LGC_id_coil like '" & dt.Rows(i)("LMO_id_moth_coil").ToString.Substring(0, 6) & "%'"
                        q &= " order by lgc_ts_end desc"
                        Dim dt1 As DataTable = objDataHandler.GetOracleData(q)
                        Dim head_SL As Double = dt1.Rows(0)("head_shear_length")
                        Dim tail_SL As Double = dt1.Rows(0)("tail_shear_length")
                        If head_SL = 0 Or tail_SL = 0 Then
                            Continue For
                        End If
                        If dt1.Rows(0)("M_coil_id").ToString.Contains("Z") Or dt1.Rows(0)("D_coil_id").ToString.Contains("Z") Then
                            Continue For
                        End If
                        Dim shear_lenght As Double = head_SL + tail_SL
                        Dim q2 As String = "select fhc_ln_cr_coil from V_FULL_HARD_COILS   where fhc_id_coil like '" & dt.Rows(i)("LMO_id_moth_coil").ToString.Substring(0, 6) & "%'"

                        Dim dtq2 As DataTable = objDataHandler.GetOracleData(q2)
                        Dim mc_lenght As Double = dtq2.Rows(0)(0)

                        Dim mc_wt As Double = dt1.Rows(0)("MC_WT")
                        Dim shear_wt As Double = shear_lenght / (mc_lenght) * mc_wt
                        Dim sa As Double = (mc_lenght - shear_lenght) * dt1.Rows(0)("width") / 1000
                        Dim aim_zn_wt As Double = (dt1.Rows(0)("Zn_coat_gsm").ToString.Substring(1) + 4) * sa / 1000
                        Dim d_wt As Double = 0
                        For j As Integer = 0 To dt1.Rows.Count - 1
                            d_wt = d_wt + dt1.Rows(j)("D_coil_wt")
                        Next
                        Dim sum_ct_b As Double = 0
                        Dim zn_coating As Double
                        For j As Integer = 0 To dtq1.Rows.Count - 1
                            sum_ct_b = sum_ct_b + dtq1.Rows(j)("ltr_test_value")
                        Next
                        If dt1.Rows.Count > 0 Then
                            sum_ct_b = sum_ct_b / dt1.Rows.Count
                            zn_coating = sum_ct_b / (dt1.Rows(0)("Zn_coat_gsm").ToString.Substring(1) + 4) * 100
                        Else
                            zn_coating = 0
                        End If

                        Dim act_coating_wt As Double = d_wt - mc_wt + shear_wt
                        Dim zn_weightdiff As Double = act_coating_wt / aim_zn_wt * 100

                        If Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour > 6 And Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour <= 14 Then
                            line1 &= "['" & (Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end"))).ToString("yyyy-MM-dd HH:mm:ss") & "', " & Math.Round(zn_weightdiff, 2) & "],"
                            line4 &= "['" & (Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end"))).ToString("yyyy-MM-dd HH:mm:ss") & "', " & Math.Round(zn_coating, 2) & "],"
                        ElseIf Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour > 14 And Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour <= 22 Then
                            line2 &= "['" & (Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end"))).ToString("yyyy-MM-dd HH:mm:ss") & "', " & Math.Round(zn_weightdiff, 2) & "],"
                            line5 &= "['" & (Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end"))).ToString("yyyy-MM-dd HH:mm:ss") & "', " & Math.Round(zn_coating, 2) & "],"
                            'ElseIf Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour > 22 And Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour <= 6 Then
                        Else
                            line3 &= "['" & (Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end"))).ToString("yyyy-MM-dd HH:mm:ss") & "', " & Math.Round(zn_weightdiff, 2) & "],"
                            line6 &= "['" & (Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end"))).ToString("yyyy-MM-dd HH:mm:ss") & "', " & Math.Round(zn_coating, 2) & "],"
                        End If

                    Catch ex As Exception
                        Continue For
                    End Try
                Next
            End If
            ContainerName = ContainerName.Replace(" ", "_")
            Dim js As String = ""
            js &= " <script type='text/javascript'> var " & PlotName & " = echarts.init(document.getElementById('" & ContainerName & "'));"
            js &= "option = {tooltip: {trigger: 'item'},"
            js &= "legend: {},"
            js &= "grid: {left:   '10%',right:  '10%',bottom:  '10%',containLabel: true},"
            js &= "toolbox: {show: true,feature: {dataZoom: {yAxisIndex: 'none'},restore: {},saveAsImage: {}}},"
            js &= "xAxis: {type: 'time',axisLabel : { formatter: '{value}',fontWeight:'bold',rotate: 45},name: '" & XAxisColName & "',nameLocation: 'middle',nameGap: 70,nameTextStyle: {fontWeight:'bold'},"
            js &= "splitLine: {show:true,lineStyle: {color: 'grey'}}},"
            js &= " yAxis : [{type : 'value',max:130,min:80,axisLabel : {formatter: '{value}',fontWeight:'bold'},name: '" & YAxisLabelName & "',nameLocation: 'middle',nameGap: 50,nameTextStyle: {fontWeight:'bold'} }],"
            js &= "dataZoom: [{type: 'slider',xAxisIndex: 0,filterMode: 'empty'},{type: 'slider',yAxisIndex: 0,filterMode: 'empty'},{type: 'inside',xAxisIndex: 0,filterMode: 'empty'},{type: 'inside',yAxisIndex: 0,filterMode: 'empty'}],"
            js &= "series: [{name: 'Zn yield (Based on coil weigth) A',type: 'scatter',color: '#6bfc03' ,symbolSize:8,"
            js &= "data: [" & line1 & "] },"
            js &= "{name: 'Zn yield (Based on coil weigth) B',type: 'scatter',color: '#00d639' ,symbolSize:8,data: [" & line2 & "] },"
            js &= "{name: 'Zn yield (Based on coil weigth) C',type: 'scatter',color: '#027521' ,symbolSize:8,data: [" & line3 & "] },"
            js &= "{name: 'Zn yield (based on Coating) A',type: 'scatter',color: '#e35d5d' ,symbolSize:8,data: [" & line4 & "] },"
            js &= "{name: 'Zn yield (based on Coating) B',type: 'scatter',color: '#ed0000' ,symbolSize:8,data: [" & line5 & "] },"
            js &= "{name: 'Zn yield (based on Coating) C',type: 'scatter',color: '#7d0404' ,symbolSize:8,data: [" & line6 & "] },"
            js &= "]};"
            js &= "" & PlotName & ".setOption(option);</script>"
            LiteralName.Text = js
        Catch ex As Exception
            'Continue For
        End Try


    End Sub
    'Public Sub PlotLinegraph_all_new(ByVal dt As DataTable, ByVal XAxisColName_new As String, ByVal YAxisColName_new As String, ByVal LiteralName_new As Literal, ByVal ContainerName_new As String, ByVal PlotName_new As String, ByVal YAxisLabelName_new As String, ByVal fromdtq As String, ByVal todtq As String)

    '    Try

    '    LiteralName_new.Text = ""
    '        Dim line11 As String = ""
    '        Dim line21 As String = ""
    '        Dim line31 As String = ""
    '        Dim line41 As String = ""
    '        Dim line51 As String = ""
    '        Dim line61 As String = ""
    '        Dim line12 As String = ""
    '        Dim line22 As String = ""
    '        Dim line32 As String = ""
    '        Dim line42 As String = ""
    '        Dim line52 As String = ""
    '        Dim line62 As String = ""
    '    'Try 'Dim max As Integer = 0
    '    '    'Dim min As Integer = 999
    '    '    'Dim max As Integer = dt.AsEnumerable().Max(Function(row) row(YAxisColName)) + 1
    '    '    'Dim min As Integer = dt.AsEnumerable().Min(Function(row) row(YAxisColName)) - 1
    '    '    'If dt.Rows.Count > 0 Then
    '    '    '    For i As Integer = 0 To dt.Rows.Count - 1
    '    '    '        Try
    '    '    '            If dt.Rows(i)("LMO_CD_PROD") = "C03" And Not IsDBNull(dt.Rows(i)(YAxisColName)) Then
    '    '    '                If dt.Rows(i)(YAxisColName) > max Then
    '    '    '                    max = dt.Rows(i)(YAxisColName)
    '    '    '                ElseIf dt.Rows(i)(YAxisColName) < min Then
    '    '    '                    min = dt.Rows(i)(YAxisColName)
    '    '    '                End If
    '    '    '                line1 &= "['" & (Convert.ToDateTime(dt.Rows(i)(XAxisColName))).ToString("yyyy-MM-dd HH:mm:ss") & "', " & Math.Round(dt.Rows(i)(YAxisColName), 2) & "],"
    '    '    '            ElseIf dt.Rows(i)("LMO_CD_PROD") = "C10" And Not IsDBNull(dt.Rows(i)(YAxisColName)) Then
    '    '    '                If dt.Rows(i)(YAxisColName) > max Then
    '    '    '                    max = dt.Rows(i)(YAxisColName)
    '    '    '                ElseIf dt.Rows(i)(YAxisColName) < min Then
    '    '    '                    min = dt.Rows(i)(YAxisColName)
    '    '    '                End If
    '    '    '                line2 &= "['" & (Convert.ToDateTime(dt.Rows(i)(XAxisColName))).ToString("yyyy-MM-dd HH:mm:ss") & "', " & Math.Round(dt.Rows(i)(YAxisColName), 2) & "],"
    '    '    '            End If
    '    '    '        Catch ex As Exception
    '    '    '            Throw ex
    '    '    '        End Try
    '    '    '    Next
    '    '    'End If
    '        If dt.Rows.Count > 0 Then
    '            For i As Integer = 0 To dt.Rows.Count - 1
    '                Try


    '                    Dim q1 As String = "select * from v_lab_tst_res where ltr_id_coil like '" & dt.Rows(i)("LMO_id_moth_coil").ToString.Substring(0, 6) & "%' and LTR_param_test in ('ZCQTTM','ZCQTBM')"
    '                    Dim dtq1 As DataTable = objDataHandler.GetOracleData(q1)
    '                    'If dtq1.Rows.Count = 0 Then
    '                    '    Continue For
    '                    'End If
    '                    Dim q As String = "select distinct lgc_ts_end, LGC_id_coil as D_coil_id,lgc_id_moth_coil,LGC_SEC1_COIL as thick,LGC_SEC2_COIL as width,lgc_ms_coil_actl as D_coil_wt,"
    '                    q &= "LMO_ID_MOTH_COIL as M_coil_id,LMO_MS_COIL as MC_WT,LMO_LN_HD_ENT as head_shear_length,LMO_LN_TAIL_ENT as tail_shear_length, "
    '                    q &= "pdl_cD_coat as Zn_coat_gsm "
    '                    q &= " from v_cg2_galv_coil,V_CG2_MOTHER_COIL,v_pr_data_ip_cg2"
    '                    q &= " where lgc_id_moth_coil = LMO_ID_MOTH_COIL and PDL_ID_COIL = LMO_ID_MOTH_COIL and LGC_id_coil like '" & dt.Rows(i)("LMO_id_moth_coil").ToString.Substring(0, 6) & "%'"
    '                    q &= " order by lgc_ts_end desc"
    '                    Dim dt1 As DataTable = objDataHandler.GetOracleData(q)
    '                    Dim head_SL As Double = dt1.Rows(0)("head_shear_length")
    '                    Dim tail_SL As Double = dt1.Rows(0)("tail_shear_length")
    '                    If head_SL = 0 Or tail_SL = 0 Then
    '                        Continue For
    '                    End If
    '                    If dt1.Rows(0)("M_coil_id").ToString.Contains("Z") Or dt1.Rows(0)("D_coil_id").ToString.Contains("Z") Then
    '                        Continue For
    '                    End If
    '                    Dim shear_lenght As Double = head_SL + tail_SL
    '                    Dim q2 As String = "select fhc_ln_cr_coil from V_FULL_HARD_COILS   where fhc_id_coil like '" & dt.Rows(i)("LMO_id_moth_coil").ToString.Substring(0, 6) & "%'"

    '                    Dim dtq2 As DataTable = objDataHandler.GetOracleData(q2)
    '                    Dim mc_lenght As Double = dtq2.Rows(0)(0)

    '                    Dim mc_wt As Double = dt1.Rows(0)("MC_WT")
    '                    Dim shear_wt As Double = shear_lenght / (mc_lenght) * mc_wt
    '                    Dim sa As Double = (mc_lenght - shear_lenght) * dt1.Rows(0)("width") / 1000
    '                    Dim aim_zn_wt As Double = (dt1.Rows(0)("Zn_coat_gsm").ToString.Substring(1) + 4) * sa / 1000
    '                    Dim d_wt As Double = 0
    '                    For j As Integer = 0 To dt1.Rows.Count - 1
    '                        d_wt = d_wt + dt1.Rows(j)("D_coil_wt")
    '                    Next
    '                    Dim sum_ct_b As Double = 0
    '                    Dim zn_coating As Double
    '                    For j As Integer = 0 To dtq1.Rows.Count - 1
    '                        sum_ct_b = sum_ct_b + dtq1.Rows(j)("ltr_test_value")
    '                    Next
    '                    If dt1.Rows.Count > 0 Then
    '                        sum_ct_b = sum_ct_b / dt1.Rows.Count
    '                        zn_coating = sum_ct_b / (dt1.Rows(0)("Zn_coat_gsm").ToString.Substring(1) + 4) * 100
    '                    Else
    '                        zn_coating = 0
    '                    End If

    '                    Dim act_coating_wt As Double = d_wt - mc_wt + shear_wt
    '                    Dim zn_weightdiff As Double = act_coating_wt / aim_zn_wt * 100

    '                    If Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour > 6 And Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour <= 14 Then
    '                        line12 &= "'" & (Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end"))).ToString("yyyy-MM-dd HH:mm:ss") & "',"
    '                        line42 &= "'" & (Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end"))).ToString("yyyy-MM-dd HH:mm:ss") & "', "
    '                    ElseIf Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour > 14 And Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour <= 22 Then
    '                        line22 &= "'" & (Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end"))).ToString("yyyy-MM-dd HH:mm:ss") & "', "
    '                        line52 &= "'" & (Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end"))).ToString("yyyy-MM-dd HH:mm:ss") & "', "
    '                        'ElseIf Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour > 22 And Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour <= 6 Then
    '                    Else
    '                        line32 &= "'" & (Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end"))).ToString("yyyy-MM-dd HH:mm:ss") & "', "
    '                        line62 &= "'" & (Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end"))).ToString("yyyy-MM-dd HH:mm:ss") & "', "
    '                    End If
    '                    If Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour > 6 And Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour <= 14 Then
    '                        line11 &= " " & Math.Round(zn_weightdiff, 2) & ","
    '                        line41 &= " " & Math.Round(zn_coating, 2) & ","
    '                    ElseIf Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour > 14 And Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour <= 22 Then
    '                        line21 &= " " & Math.Round(zn_weightdiff, 2) & ","
    '                        line51 &= " " & (Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end"))).ToString("yyyy-MM-dd HH:mm:ss") & "', " & Math.Round(zn_coating, 2) & "],"
    '                        'ElseIf Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour > 22 And Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour <= 6 Then
    '                    Else
    '                        line31 &= " " & Math.Round(zn_weightdiff, 2) & ","
    '                        line61 &= " " & Math.Round(zn_coating, 2) & ","
    '                    End If
    '                Catch ex As Exception
    '                    Continue For
    '                End Try
    '            Next
    '        End If '--------------------------------
    '    '    Dim q3 As String = "select PDL_CD_PROD, PDL_CD_COAT, value from v_pr_data_ip_cg2 "
    '    '    Dim dtq3 As DataTable = objDataHandler.GetOracleData(q3)

    '    '    Dim sum_ct_b_new As Double = 0
    '    '    Dim zn_coating_new As Double
    '    '    Dim SumCount As Double
    '    '    Dim Sum As Double
    '    '    Dim AverageCount As Integer

    '    '    For j As Integer = 0 To dtq3.Rows.Count - 1
    '        '       
    '        '            zn_A_new = (dtq3.Rows(0)("PDL_CD_PROD").ToString.Substring(1) + 4) 
    '        '             zn_C_new=(dtq3.Rows(0)("PDL_CD_COAT").ToString.Substring(1) + 4)
    '        ' If ( zn_A_new <> zn_C_new)then

    '        '            sum_ct_b_new = dtq3.Rows(0)("value").ToString
    '        '            For SumCount = sum_ct_b_new To dtq3.Rows.Count - 1
    '        '                Sum = SumCount + Sum
    '        '                AverageCount = Sum / SumCount
    '        '            Next

    '        '        Else
    '        '            zn_coating_new = 0
    '        '        End If
    '        '    Next


    '        'End If
    '        '-------------------------------------------------------------another method

    '        '--------------------------------
    '        'Dim q3 As String = "select PDL_CD_PROD, PDL_CD_COAT from v_pr_data_ip_cg2 "
    '        'Dim dtq3 As DataTable = objDataHandler.GetOracleData(q3)

    '        'Dim count As Integer = 0
    '        'Dim SumCountt As Double = 0.0
    '        'Dim Avg As Double = 0.0
    '        'Dim zn_weightdiff1 As Double = 0.0
    '        'For j As Integer = 0 To dtq3.Rows.Count - 1
    '        '    If (dtq3.Rows(j)("PDL_CD_PROD").ToString.Substring(1) + 4) = (dtq3.Rows(j)("PDL_CD_COAT").ToString.Substring(1) + 4) Then
    '        '        SumCountt = zn_weightdiff1 + SumCountt
    '        '        count = count + 1
    '        '    End If
    '        'Next

    '        'Avg = SumCountt / count

    '        '-------------------------------------------------------------another method
    '        'Dim q4 As String = "select PDL_CD_PROD, PDL_CD_COAT from v_pr_data_ip_cg2 "
    '        'Dim dtq4 As DataTable = objDataHandler.GetOracleData(q4)

    '        'Dim sum_ct_b_new1 As Double = 0
    '        'Dim zn_coating_new1 As Double
    '        'For k As Integer = 0 To dtq4.Rows.Count - 1
    '        'sum_ct_b_new1 = dtq4.Rows(0)("PDL_CD_PROD").ToString.Substring(1) + 4)
    '        'zn_coating_new1=dtq4.Rows(0)("PDL_CD_COAT").ToString.Substring(1) + 4)
    '        '    For j As Integer = 0 To dtq4.Rows.Count - 1
    '        '        If (sum_ct_b_new1 = zn_coating_new1) Then
    '        '            'Dim ComArray As Double = (sum_ct_b_new1 = zn_coating_new1)
    '        '            Dim ComArray As Double = sum_ct_b_new1.CompareTo.zn_coating_new1

    '        '        End If
    '        '    Next
    '        'Next
    '        'If dtq4.Rows.Count > 0 Then

    '        'End If


    '        '            adapter.SelectCommand = new MySqlCommand(query, conn);
    '        '//execute the query
    '        '            reader = SqlCommand.ExecuteReader();
    '        '//Assign the results 
    '        'GridView1.DataSource = reader;
    '        '  '//Bind the data
    '        'GridView1.DataBind();
    '        ' -----------------------------------------------------------------


    '        'Dim act_coating_wt As Double = d_wt - mc_wt + shear_wt
    '        'Dim zn_weightdiff As Double = act_coating_wt / aim_zn_wt * 100

    '        'If Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour > 6 And Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour <= 14 Then
    '        '    line11 &= "" & Math.Round(zn_weightdiff, 2) & ","
    '        '    line41 &= "" & Math.Round(zn_coating, 2) & ","
    '        'ElseIf Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour > 14 And Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour <= 22 Then
    '        '    line21 &= "" & Math.Round(zn_weightdiff, 2) & ","
    '        '    line51 &= "" & Math.Round(zn_coating, 2) & ","
    '        '    'ElseIf Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour > 22 And Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour <= 6 Then
    '        'Else
    '        '    line31 &= "" & Math.Round(zn_weightdiff, 2) & ","
    '        '    line61 &= "" & Math.Round(zn_coating, 2) & ","

    '        'End If
    '        'If Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour > 6 And Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour <= 14 Then
    '        '    line12 &= "'" & (Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end"))).ToString("yyyy-MM-dd HH:mm:ss") & "',"
    '        '    line42 &= "'" & (Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end"))).ToString("yyyy-MM-dd HH:mm:ss") & "', "
    '        'ElseIf Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour > 14 And Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour <= 22 Then
    '        '    line22 &= "'" & (Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end"))).ToString("yyyy-MM-dd HH:mm:ss") & "', "
    '        '    line52 &= "'" & (Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end"))).ToString("yyyy-MM-dd HH:mm:ss") & "', "
    '        '    'ElseIf Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour > 22 And Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour <= 6 Then
    '        'Else
    '        '    line32 &= "'" & (Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end"))).ToString("yyyy-MM-dd HH:mm:ss") & "', "
    '        '    line62 &= "'" & (Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end"))).ToString("yyyy-MM-dd HH:mm:ss") & "', "
    '        'End If
    '        'If Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour > 6 And Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour <= 14 Then
    '        '    line11 &= " " & Math.Round(zn_weightdiff, 2) & ","
    '        '    line41 &= " " & Math.Round(zn_coating, 2) & ","
    '        'ElseIf Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour > 14 And Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour <= 22 Then
    '        '    line21 &= " " & Math.Round(zn_weightdiff, 2) & ","
    '        '    line51 &= " " & (Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end"))).ToString("yyyy-MM-dd HH:mm:ss") & "', " & Math.Round(zn_coating, 2) & "],"
    '        '    'ElseIf Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour > 22 And Convert.ToDateTime(dt1.Rows(0)("lgc_ts_end")).Hour <= 6 Then
    '        'Else
    '        '    line31 &= " " & Math.Round(zn_weightdiff, 2) & ","
    '        '    line61 &= " " & Math.Round(zn_coating, 2) & ","
    '        'End If





    '        Dim js1 As String = ""
    '        js1 &= " <script type='text/javascript'> var " & PlotName_new & " = echarts.init(document.getElementById('" & ContainerName_new & "'));"
    '        js1 &= " option = {"
    '        js1 &= "    xAxis: {"
    '        js1 &= "type:       'category',"
    '        js1 &= "  data: ['" & line12 & "', '" & line22 & "', '" & line32 & "', '" & line42 & "', '" & line52 & "', '" & line62 & "'],"
    '        js1 &= "  },"
    '        js1 &= " yAxis: {"
    '        js1 &= "type:       'value'"
    '        js1 &= " },"
    '        js1 &= " series: [{"
    '        js1 &= " data: [" & line11 & ", " & line21 & "," & line31 & ", " & line41 & ", " & line51 & ", " & line61 & "],"
    '        js1 &= "type:       'bar',"
    '        js1 &= " showBackground: true,"
    '        js1 &= " backgroundStyle: {"
    '        js1 &= "color:      'rgba(220, 220, 220, 0.8, 34, 234)'"
    '        js1 &= " }"
    '        js1 &= " }]"
    '        js1 &= "};"
    '        js1 &= "" & PlotName_new & ".setOption(option);</script>"
    '        LiteralName_new.Text = js1
    '        '            Dim s As New StringBuilder("<script>")
    '        '            s.Append(" var " & ContainerName_new & " = echarts.init(document.getElementById('" & ContainerName_new & "'));")


    '        '            s.Append("  var data = echarts.dataTool.prepareBoxplotData([[" & line11 & " ]]);")
    '        '            s.Append("  var data1 = echarts.dataTool.prepareBoxplotData([[" & line21 & " ]]);")
    '        '            s.Append("  var data2 = echarts.dataTool.prepareBoxplotData([[" & line31 & " ]]);")
    '        '            s.Append("  var data3 = echarts.dataTool.prepareBoxplotData([[" & line41 & " ]]);")
    '        '            s.Append("  var data4 = echarts.dataTool.prepareBoxplotData([[" & line51 & " ]]);")
    '        '            s.Append("  var data5 = echarts.dataTool.prepareBoxplotData([[" & line61 & " ]]);")
    '        '            ' s.Append("  var data6 = echarts.dataTool.prepareBoxplotData([[" & line11 & " ]]);")
    '        '            's.Append("  var data7 = echarts.dataTool.prepareBoxplotData([[" & plot_val7 & " ]]);")
    '        '            's.Append("  var data8 = echarts.dataTool.prepareBoxplotData([[" & plot_val8 & " ]]);")

    '        '            '' s.Append("  var data4 = echarts.dataTool.prepareBoxplotData([" & plot_val & " ]);")
    '        '            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    '        '            s.Append(" option = {title: {text: ' " & groupby & " ', },")
    '        '            s.Append(" legend: { y: '10%', data: ['1', '2', '3', '4','5','6','7','ALL']    },")
    '        '            s.Append("  tooltip: {")
    '        '            s.Append("      trigger: 'item',")
    '        '            s.Append("         axisPointer: {")
    '        '            s.Append(" type: 'shadow' } },")
    '        '            s.Append(" grid: {")
    '        '            s.Append("    left: '10%',")
    '        '            s.Append("    top: '20%',")
    '        '            s.Append("    right: '10%',")
    '        '            s.Append("    bottom: '15%'    },")
    '        '            s.Append("   xAxis: {")
    '        '            s.Append("       show: false,")
    '        '            s.Append("     type: 'category',")
    '        '            s.Append("    data: data1.axisData,")
    '        '            s.Append("    boundaryGap: true,")
    '        '            s.Append("    nameGap: 30,")
    '        '            s.Append("    splitArea: {")
    '        '            s.Append("        show: true  }, },")
    '        '            s.Append(" yAxis: {")
    '        '            s.Append("   type: 'value',")
    '        '            s.Append("   name: 'Defect " & tooltip & "',")
    '        '            s.Append("   nameTextStyle:{  fontSize:'15', fontWeight:'bold'   }," & XAxisColName_new & "")
    '        '            s.Append("   nameLocation: 'middle',")
    '        '            s.Append("   nameGap:40,")
    '        '            s.Append("     splitArea: {show: false   },")
    '        '            s.Append("    axisLabel: {fontWeight:'bold',fontSize:15,},}, dataZoom: [ {type: 'slider',yAxisIndex: 0, filterMode: 'empty' }, ],")

    '        '            s.Append("  series: [   {")
    '        '            s.Append("     name: '1',")
    '        '            s.Append("     type: 'boxplot',")
    '        '            s.Append("     data: data1.boxData,")
    '        '            s.Append("       itemStyle: {color: '#2f4508 ',borderColor: '#2f4508'}, ")
    '        '            s.Append("     tooltip: {formatter: formatter}     },")

    '        '            s.Append("     { name: '2',")
    '        '            s.Append("       type: 'boxplot',")
    '        '            s.Append("     data: data2.boxData,")
    '        '            s.Append("      itemStyle: {color: ' #ff6a00 ',borderColor: '#ff6a00'}, ")
    '        '            s.Append("    tooltip: {formatter: formatter} },")

    '        '            s.Append("  {  name: '3',")
    '        '            s.Append("      type: 'boxplot',")
    '        '            s.Append("      data: data3.boxData,")
    '        '            s.Append("     itemStyle: {color: ' #0725eb ',borderColor: '#0725eb'},")
    '        '            s.Append("   tooltip: {formatter: formatter} },")

    '        '            s.Append("  {  name: '4',")
    '        '            s.Append("      type: 'boxplot',")
    '        '            s.Append("      data: data4.boxData,")
    '        '            s.Append("    itemStyle: {color: ' #a8137b ',borderColor: '#a8137b'},")
    '        '            s.Append("   tooltip: {formatter: formatter} },")

    '        '            s.Append("  {  name: '5',")
    '        '            s.Append("      type: 'boxplot',")
    '        '            s.Append("      data: data5.boxData,")
    '        '            s.Append("     itemStyle: {color: ' #076a75 ',borderColor: '#076a75'}, ")
    '        '            s.Append("   tooltip: {formatter: formatter} },")
    '        '            s.Append("  {  name: '6',")
    '        '            s.Append("      type: 'boxplot',")
    '        '            s.Append("      data: data6.boxData,")
    '        '            s.Append("    itemStyle: {color: ' #08cf15 ',borderColor: '#08cf15'}, ")
    '        '            s.Append("   tooltip: {formatter: formatter} },")
    '        '            s.Append("  {  name: '7',")
    '        '            s.Append("      type: 'boxplot',")
    '        '            s.Append("      data: data7.boxData,")
    '        '            s.Append("      itemStyle: {color: '#fbff00 ',borderColor: '#fbff00'}, ")
    '        '            s.Append("   tooltip: {formatter: formatter} },")
    '        '            s.Append("  {  name: 'ALL',")
    '        '            s.Append("      type: 'boxplot',")
    '        '            s.Append("      data: data8.boxData,")
    '        '            s.Append("      itemStyle: {color: ' #f00c0c ',borderColor: '#f00c0c'},")
    '        '            s.Append("   tooltip: {formatter: formatter} },")
    '        '            s.Append("  {    name: '1',")
    '        '            s.Append("      type: 'pictorialBar',")
    '        '            s.Append("    symbolPosition: 'end',")
    '        '            s.Append("   symbolSize: 8,")
    '        '            s.Append("   itemStyle: {color: '#2f4508 ',borderColor: '#2f4508'}, ")
    '        '            s.Append("  data: data1.outliers },")
    '        '            s.Append("    {   name: '2',")
    '        '            s.Append("    type: 'pictorialBar',")
    '        '            s.Append("   symbolPosition: 'end',")
    '        '            s.Append("  symbolSize: 8,")
    '        '            s.Append("    itemStyle: {color: ' #ff6a00 ',borderColor: '#ff6a00'}, ")
    '        '            s.Append("  data: data2.outliers},")
    '        '            s.Append("   {   name: '3',")
    '        '            s.Append("  type: 'pictorialBar',")
    '        '            s.Append("  symbolPosition: 'end',")
    '        '            s.Append("  symbolSize: 8,")
    '        '            s.Append("   itemStyle: {color: ' #0725eb ',borderColor: '#0725eb'},")
    '        '            s.Append("  barGap: '30%',")
    '        '            s.Append("  data: data3.outliers}, ")
    '        '            s.Append("   {   name: '4',")
    '        '            s.Append("  type: 'pictorialBar',")
    '        '            s.Append("  symbolPosition: 'end',")
    '        '            s.Append("  symbolSize: 8,")
    '        '            s.Append("   itemStyle: {color: ' #a8137b ',borderColor: '#a8137b'},")
    '        '            s.Append("  barGap: '30%',")
    '        '            s.Append("  data: data4.outliers}, ")
    '        '            s.Append("   {   name: '5',")
    '        '            s.Append("  type: 'pictorialBar',")
    '        '            s.Append("  symbolPosition: 'end',")
    '        '            s.Append("  symbolSize: 8,")
    '        '            s.Append("   itemStyle: {color: ' #076a75 ',borderColor: '#076a75'}, ")
    '        '            s.Append("  barGap: '30%',")
    '        '            s.Append("  data: data5.outliers}, ")
    '        '            s.Append("   {   name: '6',")
    '        '            s.Append("  type: 'pictorialBar',")
    '        '            s.Append("  symbolPosition: 'end',")
    '        '            s.Append("  symbolSize: 8,")
    '        '            s.Append("   itemStyle: {color: ' #08cf15 ',borderColor: '#08cf15'}, ")
    '        '            s.Append("  barGap: '30%',")
    '        '            s.Append("  data: data6.outliers}, ")
    '        '            s.Append("   {   name: '7',")
    '        '            s.Append("  type: 'pictorialBar',")
    '        '            s.Append("  symbolPosition: 'end',")
    '        '            s.Append("  symbolSize: 8,")
    '        '            s.Append("    itemStyle: {color: '#fbff00 ',borderColor: '#fbff00'}, ")
    '        '            s.Append("  barGap: '30%',")
    '        '            s.Append("  data: data7.outliers}, ")
    '        '            s.Append("   {   name: 'ALL',")
    '        '            s.Append("  type: 'pictorialBar',")
    '        '            s.Append("  symbolPosition: 'end',")
    '        '            s.Append("  symbolSize: 8,")
    '        '            s.Append("    itemStyle: {color: ' #f00c0c ',borderColor: '#f00c0c'},")
    '        '            s.Append("  barGap: '30%',")
    '        '            s.Append("  data: data8.outliers} ")
    '        '            s.Append("  ]}; console.log(data);")
    '        '            s.Append(" function formatter(param) {   return [")
    '        '            s.Append("  'upper: ' + param.data[0],")
    '        '            s.Append("  'Q1: ' + param.data[1],")
    '        '            s.Append("  'median: ' + param.data[2],")
    '        '            s.Append("  'Q3: ' + param.data[3],")
    '        '            s.Append("  'lower: ' + param.data[4]    ].join('<br/>');}")
    '        '            s.Append(ContainerName_new & ".setOption(option);")
    '        '            s.Append("</script>")


    '        '            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    '        '            LiteralName_new.Text = s.ToString()


    '        '        Catch ex As Exception
    '        '            Throw ex
    '        '        End Try
    '        'End Sub
    '        'Public Sub gridArray(ByVal dt As DataTable)
    '        '    Try
    '        '        If dt.Rows.Count > 0 Then


    '        '            For i As Integer = 0 To dt.Rows.Count - 1
    '        '                Dim act_coating_wt1(400) As Double
    '        '                Dim zn_weightdiff1(400) As Double
    '        '                Dim arrayCol(400) As Double = act_coating_wt1 + zn_weightdiff1
    '        '                Dim arrayAvg As Double = arrayCol / 2
    '        '            Next
    '        '        End If

    '        '    Catch ex As Exception

    '        '    End Try
    '        'End Sub

    '        'Dim query As String = "  select PDL_CD_PROD, PDL_CD_COAT from v_pr_data_ip_cg2 "
    '        'Dim gridViewDetails As GridView

    '        'objController.CGL2_Zn_Yield_fun(query, gridViewDetails)
    '        'If gridViewDetails.Rows.Count > 0 Then
    '        '    gridViewDetails.UseAccessibleHeader = True
    '        '    gridViewDetails.HeaderRow.TableSection = TableRowSection.TableHeader
    '        '    '  gvDetails.DataSource = Nothing
    '        '    gridViewDetails.DataBind()
    '        'End If
    '    Catch ex As Exception
    '        Throw New Exception(ex.ToString())
    '    End Try




    'End Sub

   
End Class

