﻿
Imports System.IO
Imports System.Data
Imports OfficeOpenXml

Partial Class CLSModel
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))


            Catch ex As Exception

            End Try

        End If

    End Sub
    Public Sub WriteToExcel(filePath As String, NValue As String, C As String, Mn As String, S As String, P As String, CastingSpeed As String, Superheat As String, SurfaceToCenter As String)
        Using package As New ExcelPackage(New FileInfo(filePath))
            Dim worksheet = package.Workbook.Worksheets("CLS model")
            worksheet.Cells(6, 1).Value = NValue
            worksheet.Cells(6, 6).Value = C
            worksheet.Cells(6, 9).Value = Mn
            worksheet.Cells(6, 12).Value = S
            worksheet.Cells(6, 15).Value = P
            worksheet.Cells(4, 2).Value = CastingSpeed
            worksheet.Cells(4, 3).Value = Superheat
            worksheet.Cells(4, 4).Value = SurfaceToCenter

            package.Save()

        End Using

    End Sub

    Private Sub btnDrawChart_Click(sender As Object, e As EventArgs) Handles btnDrawChart.Click
        Dim filePath As String = Server.MapPath("~/Uploads/CLS model - UserInterface.xlsx")
        'Dim NValue As String = "495"
        If Not String.IsNullOrEmpty(txtN.Text) AndAlso IsNumeric(txtN.Text) AndAlso Not String.IsNullOrEmpty(txtCPercent.Text) AndAlso IsNumeric(txtCPercent.Text) AndAlso Not String.IsNullOrEmpty(txtMnPercent.Text) AndAlso IsNumeric(txtMnPercent.Text) AndAlso Not String.IsNullOrEmpty(txtSPercent.Text) AndAlso IsNumeric(txtSPercent.Text) AndAlso Not String.IsNullOrEmpty(txtPPercent.Text) AndAlso IsNumeric(txtPPercent.Text) AndAlso Not String.IsNullOrEmpty(txtCastingSpeed.Text) AndAlso IsNumeric(txtCastingSpeed.Text) AndAlso Not String.IsNullOrEmpty(txtSuperheat.Text) AndAlso IsNumeric(txtSuperheat.Text) AndAlso Not String.IsNullOrEmpty(txtSurfaceCenter.Text) AndAlso IsNumeric(txtSurfaceCenter.Text) Then
            Dim CastingSpeed As Double = Convert.ToDecimal(txtCastingSpeed.Text)
            If CastingSpeed >= 2 AndAlso CastingSpeed <= 4 Then
                Try
                    WriteToExcel(filePath, txtN.Text, txtCPercent.Text, txtMnPercent.Text, txtSPercent.Text, txtPPercent.Text, txtCastingSpeed.Text, txtSuperheat.Text, txtSurfaceCenter.Text)
                    PlotLineEChart(5, 14, 14, 15, Lit1, "container1", "Plot1", "Distance from surface, C", "C%")
                    PlotLineEChart(5, 14, 14, 16, Lit2, "container2", "Plot2", "Distance from surface, C", "C/C0")

                    CLSIndex()


                Catch ex As Exception
                    ex.ToString()
                End Try
            Else
                UserMsgBoxWarning("Casting Speed should be between 2 and 4.")
            End If
        Else
            UserMsgBoxError("Please enter valid decimal values in all fields.")

        End If

        'If Not String.IsNullOrEmpty(txtCPercent.Text) AndAlso IsNumeric(txtCPercent.Text) AndAlso Not String.IsNullOrEmpty(txtMnPercent.Text) AndAlso IsNumeric(txtMnPercent.Text) AndAlso Not String.IsNullOrEmpty(txtSPercent.Text) AndAlso IsNumeric(txtSPercent.Text) AndAlso Not String.IsNullOrEmpty(txtPPercent.Text) AndAlso IsNumeric(txtPPercent.Text) AndAlso Not String.IsNullOrEmpty(txtCastingSpeed.Text) AndAlso IsNumeric(txtCastingSpeed.Text) AndAlso Not String.IsNullOrEmpty(txtSuperheat.Text) AndAlso IsNumeric(txtSuperheat.Text) AndAlso Not String.IsNullOrEmpty(txtCastThickness.Text) AndAlso IsNumeric(txtCastThickness.Text) Then
        '    Dim CastingSpeed As Double = Convert.ToDecimal(txtCastingSpeed.Text)
        '    If CastingSpeed >= 2 AndAlso CastingSpeed <= 4 Then
        '        If ViewState("MyDataTable") Is Nothing Then
        '            Dim dt As New DataTable()
        '            dt.Columns.Add("C", GetType(Decimal))
        '            dt.Columns.Add("Mn", GetType(Decimal))
        '            dt.Columns.Add("S", GetType(Decimal))
        '            dt.Columns.Add("P", GetType(Decimal))
        '            dt.Columns.Add("CastingSpeed", GetType(Decimal))
        '            dt.Columns.Add("Superheat", GetType(Decimal))
        '            dt.Columns.Add("CastThickness", GetType(Decimal))
        '            ViewState("MyDataTable") = dt
        '        End If
        '        Dim dataTable As DataTable = DirectCast(ViewState("MyDataTable"), DataTable)
        '        If dataTable IsNot Nothing Then
        '            Dim row As DataRow = dataTable.NewRow()
        '            row("C") = txtCPercent.Text
        '            row("Mn") = txtMnPercent.Text
        '            row("S") = txtSPercent.Text
        '            row("P") = txtPPercent.Text
        '            row("CastingSpeed") = txtCastingSpeed.Text
        '            row("Superheat") = txtSuperheat.Text
        '            row("CastThickness") = txtCastThickness.Text

        '            dataTable.Rows.Add(row)
        '            ViewState("MyDataTable") = dataTable
        '            txtCPercent.Text = ""
        '            txtMnPercent.Text = ""
        '            txtSPercent.Text = ""
        '            txtPPercent.Text = ""
        '            txtCastingSpeed.Text = ""
        '            txtSuperheat.Text = ""
        '            txtCastThickness.Text = ""
        '            UserMsgBoxSuccess("Values added successfully.")
        '        End If


        '    Else
        '        UserMsgBoxWarning("Casting Speed should be between 2 and 4.")
        '    End If
        'Else
        '    UserMsgBoxError("Please enter valid decimal values in all fields.")
        'End If
    End Sub
    Public Sub PlotLineEChart(ByVal startRow As Integer, ByVal endRow As Integer, ByVal xcolumn As Integer, ByVal ycolumn As Integer, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal XAxisLabelName As String, ByVal YAxisLabelName As String)
        ' Try
        Dim filePath = Server.MapPath("~/Uploads/CLS model - UserInterface.xlsx")
        LiteralName.Text = ""

        Dim data As String = ""
        Using package As New ExcelPackage(New FileInfo(filePath))
            Dim worksheet = package.Workbook.Worksheets("CLS model")
            'Dim startRow As Integer = 5
            'Dim endRow As Integer = 14
            'Dim xcolumn As Integer = 14
            'Dim ycolumn As Integer = 15
            For row As Integer = startRow To endRow
                data &= "," & "[" & worksheet.Cells(row, xcolumn).Value & "," & worksheet.Cells(row, ycolumn).Value & "]"
            Next
        End Using


        'For i As Integer = 0 To dt.Rows.Count - 1
        '    'data &= "," & "[" & dt.Rows(i)(xcol) & "," & dt.Rows(i)(ycol) & "]"
        '    data &= "," & "[" & i + 1 & "," & dt.Rows(i)(ycol) & "]"

        'Next

        data = data.Substring(1)
        '' dv.Item(0)("lenseverity")
        Dim s As New StringBuilder("<script>")

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        s.Append(" var myChart = echarts.init(document.getElementById('" & ContainerName & "'));")

        s.Append("option = {")

        s.Append("title: {")
        s.Append("text: ''")
        s.Append("},")
        s.Append("tooltip: {")
        s.Append("trigger: 'axis'")
        s.Append("},")
        s.Append("xAxis: {  name: '" & XAxisLabelName & "',")

        s.Append("},")
        s.Append("yAxis: {  name: '" & YAxisLabelName & "',")

        s.Append("},")
        s.Append("toolbox: {")
        s.Append("left: 'center',")
        s.Append("feature: {")
        s.Append("dataZoom: {")
        s.Append("yAxisIndex: 'none'")
        s.Append("},")
        s.Append("restore: {},")
        s.Append("saveAsImage: {}")
        s.Append("}")
        s.Append("},")

        s.Append("series: [")
        s.Append("{")
        s.Append("type: 'scatter',symbolSize: 20,")

        s.Append("data: [" & data & "]")
        s.Append("},")

        s.Append("]")
        s.Append("};")

        s.Append(" myChart.setOption(option);")
        s.Append("</script>")
        LiteralName.Text = s.ToString()


        'Catch ex As Exception

        'End Try
    End Sub
    Public Sub CLSIndex()
        Dim filePath = Server.MapPath("~/Uploads/CLS model - UserInterface.xlsx")

        Using package As New ExcelPackage(New FileInfo(filePath))
            Dim worksheet = package.Workbook.Worksheets("CLS model")

            txtCLSIndexC.Text = worksheet.Cells(14, 16).Value
            'txtCLSIndexMn.Text = worksheet.Cells(14, 25).Value
            'txtCLSIndexS.Text = worksheet.Cells(14, 34).Value
            'txtCLSIndexP.Text = worksheet.Cells(14, 43).Value

        End Using
    End Sub
    'Public Sub PlotLineEChart1(ByVal startRow As Integer, ByVal endRow As Integer, ByVal ycolumn As Integer, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal XAxisLabelName As String, ByVal YAxisLabelName As String, ByVal iVal As Integer)
    '    ' Try
    '    Dim filePath = Server.MapPath("~/Uploads/CLS model - UserInterface.xlsx")
    '    LiteralName.Text = ""

    '    Dim data As String = ""
    '    Using package As New ExcelPackage(New FileInfo(filePath))
    '        Dim worksheet = package.Workbook.Worksheets("CLS model")
    '        'Dim startRow As Integer = 5
    '        'Dim endRow As Integer = 14
    '        'Dim xcolumn As Integer = 14
    '        'Dim ycolumn As Integer = 15
    '        For row As Integer = startRow To endRow
    '            data &= "," & "[" & row - iVal & "," & worksheet.Cells(row, ycolumn).Value & "]"
    '        Next
    '    End Using


    '    'For i As Integer = 0 To dt.Rows.Count - 1
    '    '    'data &= "," & "[" & dt.Rows(i)(xcol) & "," & dt.Rows(i)(ycol) & "]"
    '    '    data &= "," & "[" & i + 1 & "," & dt.Rows(i)(ycol) & "]"

    '    'Next

    '    data = data.Substring(1)
    '    '' dv.Item(0)("lenseverity")
    '    Dim s As New StringBuilder("<script>")

    '    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    '    s.Append(" var myChart = echarts.init(document.getElementById('" & ContainerName & "'));")

    '    s.Append("option = {")

    '    s.Append("title: {")
    '    s.Append("text: ''")
    '    s.Append("},")
    '    s.Append("tooltip: {")
    '    s.Append("trigger: 'axis'")
    '    s.Append("},")
    '    s.Append("xAxis: {  name: '" & XAxisLabelName & "',")

    '    s.Append("},")
    '    s.Append("yAxis: {  name: '" & YAxisLabelName & "',")

    '    s.Append("},")
    '    s.Append("toolbox: {")
    '    s.Append("left: 'center',")
    '    s.Append("feature: {")
    '    s.Append("dataZoom: {")
    '    s.Append("yAxisIndex: 'none'")
    '    s.Append("},")
    '    s.Append("restore: {},")
    '    s.Append("saveAsImage: {}")
    '    s.Append("}")
    '    s.Append("},")

    '    s.Append("series: [")
    '    s.Append("{")
    '    s.Append("type: 'scatter',symbolSize: 20,")

    '    s.Append("data: [" & data & "]")
    '    s.Append("},")

    '    s.Append("]")
    '    s.Append("};")

    '    s.Append(" myChart.setOption(option);")
    '    s.Append("</script>")
    '    LiteralName.Text = s.ToString()


    '    'Catch ex As Exception

    '    'End Try
    'End Sub
End Class
