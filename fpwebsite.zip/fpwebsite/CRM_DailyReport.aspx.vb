﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Drawing
Imports System.Globalization
Imports System.IO
Imports System.Linq
Imports Microsoft
Imports System.Math
Imports System.Web
Imports System.Text
Imports System.Security.Cryptography
Imports OfficeOpenXml
Partial Class CRM_DailyReport
    Inherits System.Web.UI.Page
    Dim objDataHandler As New DataHandler
    Dim objController As New Controller
    Dim dtEnd As String
    Dim ds As New DataSet()

    Private Property dtStart As String

    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Dim fromDt As String = hfFrom.Value
        Dim toDt As String = hfTo.Value
        'LoadData()
        If gvDetails.Rows.Count > 0 Then
            gvDetails.UseAccessibleHeader = True
            gvDetails.HeaderRow.TableSection = TableRowSection.TableHeader
        End If
        If Not Page.IsPostBack Then
            Dim param As String = ""
            Dim dtval As String = ""
            If Request.QueryString("ParamName") <> "" And Request.QueryString("DateVal") <> "" Then
                'param = Decrypt(HttpUtility.UrlDecode(Request.QueryString("ParamName")))
                param = Request.QueryString("ParamName")
                'dtval = Decrypt(HttpUtility.UrlDecode(Request.QueryString("DateVal")))
                dtval = Request.QueryString("DateVal")
            End If



            If param <> "" And dtval <> "" Then
                Dim dtSt As String = CDate(dtval).ToString("yyyy-MM-dd 06:00:00")
                Dim dtFm As String = CDate(dtval).AddMonths(1).ToString("yyyy-MM-dd 06:00:00")
                hfFrom.Value = dtSt
                hfTo.Value = dtFm
                objController.PopulateGradeForCRMDailyReport(ddlGrade, dtSt, dtFm)
                objController.PopulateTdcForCRMDailyReport(ddlTdc, dtSt, dtFm, ddlGrade.SelectedItem.Text)
                ''objController.PopulateRoughForCRMDailyReport(ddlRough, dtStart, dtEnd, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
                objController.PopulateThicknessForCRMDailyReport(ddlThickness, dtSt, dtFm, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
                objController.LoadColumnNameForCRMDailayManagement1(ddlParamTest1, Session("TableName"), "CLR_PARAM_TEST", Session("DateColumn"), dtSt, dtFm, "")
                'ddlParamTest1.Items.FindByText(param).Selected = True
                ddlParamTest1.SelectedIndex = ddlParamTest1.Items.IndexOf(ddlParamTest1.Items.FindByText(param))
                hfTo.Value = CDate(dtFm).AddDays(-1).ToString("yyyy-MM-dd 06:00:00")
                LoadData()
                param = ""
                dtval = ""
            Else
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-29).ToString("yyyy-MM-dd 06:00:00")
                'Dim dtStart As DateTime = DateTime.Now.AddMonths(-4).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.AddDays(1).ToString("yyyy-MM-dd 06:00:00")
                objController.PopulateGradeForCRMDailyReport(ddlGrade, dtStart, dtEnd)
                objController.PopulateTdcForCRMDailyReport(ddlTdc, dtStart, dtEnd, ddlGrade.SelectedItem.Text)
                ''objController.PopulateRoughForCRMDailyReport(ddlRough, dtStart, dtEnd, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
                objController.PopulateThicknessForCRMDailyReport(ddlThickness, dtStart, dtEnd, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
                objController.LoadColumnNameForCRMDailayManagement1(ddlParamTest1, Session("TableName"), "CLR_PARAM_TEST", Session("DateColumn"), dtStart, dtEnd, "")

            End If

        End If

    End Sub
    Private Function Decrypt(cipherText As String) As String
        'Dim EncryptionKey As String = "MAKV2SPBNI99212"
        Dim EncryptionKey As String = "TGGWL"
        cipherText = cipherText.Replace(" ", "+")
        Dim cipherBytes As Byte() = Convert.FromBase64String(cipherText)
        Using encryptor As Aes = Aes.Create()
            Dim pdb As New Rfc2898DeriveBytes(EncryptionKey, New Byte() {&H49, &H76, &H61, &H6E, &H20, &H4D, _
             &H65, &H64, &H76, &H65, &H64, &H65, _
             &H76})
            encryptor.Key = pdb.GetBytes(32)
            encryptor.IV = pdb.GetBytes(16)
            Using ms As New MemoryStream()
                Using cs As New CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write)
                    cs.Write(cipherBytes, 0, cipherBytes.Length)
                    cs.Close()
                End Using
                cipherText = Encoding.Unicode.GetString(ms.ToArray())
            End Using
        End Using
        Return cipherText
    End Function

    Sub LoadData()
        Dim fromDt As String = hfFrom.Value
        Dim toDt As String = CDate(hfTo.Value).AddDays(1).ToString("yyyy-MM-dd 06:00:00")
        Dim str1 As String = ""
        Dim count1 As Integer = 0
        Dim appendString1 = ""
        Dim myStr As String
        lblAvg.Text = ""
        lblMin.Text = ""
        lblMax.Text = ""
        lblLCL.Text = ""
        lblUCL.Text = ""
        lblStddev.Text = ""
        lblMean.Text = ""
        lblCpk.Text = ""
        lblCp.Text = ""
        myStr = lblAvg.Text
        myStr = lblMin.Text
        myStr = lblMax.Text
        myStr = lblLCL.Text
        myStr = lblUCL.Text
        myStr = lblStddev.Text
        myStr = lblCpk.Text
        myStr = lblCp.Text
        Session("Svar") = myStr
        If Not String.IsNullOrEmpty(Session("Svar")) Then
            Response.Write(Session("Svar").ToString())
        End If
        For i As Integer = 0 To ddlParamTest1.Items.Count - 1
            If ddlParamTest1.Items(i).Selected Then
                count1 += 1
                str1 &= "," & ddlParamTest1.Items(i).Value
                appendString1 &= "<div class='col-md-12'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>" & ddlParamTest1.Items(i).Text & "</h3> <span></span></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='" & ddlParamTest1.Items(i).Value.Replace(" ", "").Replace("%", "") & "' style='height: 310px;'></div></div></div></div>"
            End If
        Next
        divHolder.InnerHtml = appendString1
        If str1 = "" Then
        Else
            str1 = str1.Substring(1)
            Dim filter As String = " 1=1"
            If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
                filter &= " and PRM_CD_GRADE = '" & ddlGrade.SelectedItem.Text & "'"
            End If
            If ddlTdc.SelectedItem.Text.ToLower <> "all" Then
                filter &= " and PRM_TDC_NO = '" & ddlTdc.SelectedItem.Text & "'"
            End If
            If ddlThickness.SelectedItem.Text.ToLower <> "all" Then
                filter &= " and PRM_SEC1_COIL = '" & ddlThickness.SelectedItem.Text & "'"
            End If
            ddlElongSet.Visible = False
            If ddlParamTest1.SelectedItem.Text = "ECL tank" Then
                ddlGrade.Enabled = False
                ddlTdc.Enabled = False
                'ddlRough.Enabled = False
                ddlThickness.Enabled = False
            End If
            If ddlParamTest1.SelectedItem.Text = "Predeg.tank" Then
                ddlGrade.Enabled = False
                ddlTdc.Enabled = False
                'ddlRough.Enabled = False
                ddlThickness.Enabled = False
            End If
            If ddlParamTest1.SelectedItem.Text = "Sheet Chromium" Then
                ddlGrade.Enabled = False
                ddlTdc.Enabled = False
                'ddlRough.Enabled = False
                ddlThickness.Enabled = False
            End If
            If ddlParamTest1.SelectedItem.Text = "Working Tank" Then
                ddlGrade.Enabled = False
                ddlTdc.Enabled = False
                'ddlRough.Enabled = False
                ddlThickness.Enabled = False
            End If
            If ddlParamTest1.SelectedItem.Text = "ECL rectifier Current" Then
                ddlGrade.Enabled = True
                ddlTdc.Enabled = False
                'ddlRough.Enabled = False
                ddlThickness.Enabled = False
            End If
            If ddlParamTest1.SelectedItem.Text = "Sheet Fe in GA" Then
                ddlGrade.Enabled = True
                ddlTdc.Enabled = False
                'ddlRough.Enabled = False
                ddlThickness.Enabled = False
            End If
            If ddlParamTest1.SelectedItem.Text = "Soaking Temperature" Then
                ddlGrade.Enabled = True
                ddlTdc.Enabled = False
                'ddlRough.Enabled = False
                ddlThickness.Enabled = True
            End If
            If ddlParamTest1.SelectedItem.Text = "SPM Elongation" Then
                ddlGrade.Enabled = True
                ddlTdc.Enabled = False
                'ddlRough.Enabled = False
                ddlThickness.Enabled = False
                'ddlElongSet.Visible = True
                'ddlElongSet.Items.Clear()
                'objController.PopulateElongationSet(ddlElongSet, fromDt, toDt, ddlGrade.SelectedItem.Text)
            End If
            If ddlParamTest1.SelectedItem.Text = "Zinc Pot Temperature" Then
                ddlGrade.Enabled = False
                ddlTdc.Enabled = False
                'ddlRough.Enabled = False
                ddlThickness.Enabled = True
            End If
            If ddlParamTest1.SelectedItem.Text = "ECL Tank Concentration" Then
                ddlGrade.Enabled = False
                ddlTdc.Enabled = False
                'ddlRough.Enabled = False
                ddlThickness.Enabled = False
            End If
            If ddlParamTest1.SelectedItem.Text = "Chromate Tank Concentration - Passerite" Then
                ddlGrade.Enabled = False
                ddlTdc.Enabled = False
                'ddlRough.Enabled = False
                ddlThickness.Enabled = False
            End If
            If ddlParamTest1.SelectedItem.Text = "Chromate Tank Concentration - Galvaguard" Then
                ddlGrade.Enabled = False
                ddlTdc.Enabled = False
                'ddlRough.Enabled = False
                ddlThickness.Enabled = False
            End If
            If ddlParamTest1.SelectedItem.Text = "Sheet Chromium Fuel tank" Then
                ddlGrade.Enabled = False
                ddlTdc.Enabled = False
                'ddlRough.Enabled = False
                ddlThickness.Enabled = False
            End If
            If ddlParamTest1.SelectedItem.Text = "Sheet Chromium ZS Coils" Then
                ddlGrade.Enabled = False
                ddlTdc.Enabled = False
                'ddlRough.Enabled = False
                ddlThickness.Enabled = False
            End If
            If ddlParamTest1.SelectedItem.Text = "Pre Degreasing Conc" Then
                ddlGrade.Enabled = False
                ddlTdc.Enabled = False
                'ddlRough.Enabled = False
                ddlThickness.Enabled = False
            End If

            If ddlParamTest1.SelectedItem.Text = "ECL Temperature" Then
                ddlGrade.Enabled = False
                ddlTdc.Enabled = False
                'ddlRough.Enabled = False
                ddlThickness.Enabled = False
            End If

            If ddlParamTest1.SelectedItem.Text = "Coating Weight_GA Fuel Tank_Top" Then
                ddlGrade.Enabled = False
                ddlTdc.Enabled = False
                'ddlRough.Enabled = False
                ddlThickness.Enabled = False
            End If

            If ddlParamTest1.SelectedItem.Text = "Coating Weight_GA Fuel Tank_BOTTOM" Then
                ddlGrade.Enabled = False
                ddlTdc.Enabled = False
                'ddlRough.Enabled = False
                ddlThickness.Enabled = False
            End If

            If ddlParamTest1.SelectedItem.Text = "Roughness_GA Fuel Tank (Coil Middle)" Then
                ddlGrade.Enabled = False
                ddlTdc.Enabled = False
                'ddlRough.Enabled = False
                ddlThickness.Enabled = False
            End If

            If ddlParamTest1.SelectedItem.Text = "Fe content in GA" Then
                ddlGrade.Enabled = False
                ddlTdc.Enabled = False
                'ddlRough.Enabled = False
                ddlThickness.Enabled = False
            End If

            If ddlParamTest1.SelectedItem.Text = "Bath Al% in GA" Then
                ddlGrade.Enabled = False
                ddlTdc.Enabled = False
                'ddlRough.Enabled = False
                ddlThickness.Enabled = False
            End If

            If ddlParamTest1.SelectedItem.Text = "Bath Al% in ZS" Then
                ddlGrade.Enabled = False
                ddlTdc.Enabled = False
                'ddlRough.Enabled = False
                ddlThickness.Enabled = False
            End If

            If ddlParamTest1.SelectedItem.Text = "GA Soaking Temperature" Then
                ddlGrade.Enabled = False
                ddlTdc.Enabled = False
                'ddlRough.Enabled = False
                ddlThickness.Enabled = False
            End If




            If ddlParamTest1.SelectedItem.Text = "Select" Then
                txtMin.Text = ""
                txtMax.Text = ""
                ddlGrade.Enabled = False
            End If
            If ddlParamTest1.SelectedItem.Text <> "Select" Then
                'txtParamName.Text = ddlParamTest1.SelectedItem.Text
                lblParameter.Text = ddlParamTest1.SelectedItem.Text
            End If

            'Try

            '    Dim pass As Boolean = True
            '    If txtMin.Text.Trim() = "" Then
            '        'UserMsgBoxWarning("Please enter min value.")
            '        'txtMin.Focus()
            '        pass = False
            '    ElseIf txtMax.Text.Trim() = "" Then
            '        'UserMsgBoxWarning("Please enter max value.")
            '        'txtMax.Focus()
            '        pass = False
            '    End If
            '    If pass And hfButton.Value = "1" And ddlParamTest1.SelectedItem.Text <> "Select" Then
            '        Dim count = 0
            '        count = objController.UpdateLimitForDaily(txtMin.Text, txtMax.Text, ddlParamTest1.SelectedItem.Text.Trim)
            '        If count > 0 Then

            '        End If
            '        hfButton.Value = "0"
            '    End If
            'Catch ex As Exception

            'End Try
            DrawChartTop1(str1, fromDt, toDt, filter)
        End If
    End Sub

    'Protected Sub btnOk_Click(sender As Object, e As System.EventArgs) Handles btnOk.Click
    '    Dim fromDt As String = hfFrom.Value
    '    Dim toDt As String = hfTo.Value

    '    Dim str1 As String = ""
    '    Dim count1 As Integer = 0
    '    Dim appendString1 = ""
    '    For i As Integer = 0 To ddlParamTest1.Items.Count - 1
    '        If ddlParamTest1.Items(i).Selected Then
    '            count1 += 1
    '            str1 &= "," & ddlParamTest1.Items(i).Value
    '            appendString1 &= "<div class='col-md-12'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>" & ddlParamTest1.Items(i).Text & "</h3> <span></span></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='" & ddlParamTest1.Items(i).Value & "' style='height: 310px;'></div></div></div></div>"
    '        End If
    '    Next
    '    divHolder.InnerHtml = appendString1
    '    If str1 = "" Then
    '    Else
    '        str1 = str1.Substring(1)
    '        Dim filter As String = " 1=1"
    '        If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
    '            filter &= " and PRM_CD_GRADE = '" & ddlGrade.SelectedItem.Text & "'"
    '        End If
    '        If ddlTdc.SelectedItem.Text.ToLower <> "all" Then
    '            filter &= " and PRM_TDC_NO = '" & ddlTdc.SelectedItem.Text & "'"
    '        End If
    '        If ddlThickness.SelectedItem.Text.ToLower <> "all" Then
    '            filter &= " and PRM_SEC1_COIL = '" & ddlThickness.SelectedItem.Text & "'"
    '        End If
    '        If ddlParamTest1.SelectedItem.Text = "ECL tank" Then
    '            ddlGrade.Enabled = False
    '            ddlTdc.Enabled = False
    '            ddlRough.Enabled = False
    '            ddlThickness.Enabled = False
    '        End If
    '        If ddlParamTest1.SelectedItem.Text = "Predeg.tank" Then
    '            ddlGrade.Enabled = False
    '            ddlTdc.Enabled = False
    '            ddlRough.Enabled = False
    '            ddlThickness.Enabled = False
    '        End If
    '        If ddlParamTest1.SelectedItem.Text = "Sheet Chromium" Then
    '            ddlGrade.Enabled = False
    '            ddlTdc.Enabled = False
    '            ddlRough.Enabled = False
    '            ddlThickness.Enabled = False
    '        End If
    '        If ddlParamTest1.SelectedItem.Text = "Working Tank" Then
    '            ddlGrade.Enabled = False
    '            ddlTdc.Enabled = False
    '            ddlRough.Enabled = False
    '            ddlThickness.Enabled = False
    '        End If
    '        If ddlParamTest1.SelectedItem.Text = "ECL rectifier Current" Then
    '            ddlGrade.Enabled = False
    '            ddlTdc.Enabled = False
    '            ddlRough.Enabled = False
    '            ddlThickness.Enabled = False
    '        End If
    '        If ddlParamTest1.SelectedItem.Text = "Sheet Fe in GA" Then
    '            ddlGrade.Enabled = True
    '            ddlTdc.Enabled = False
    '            ddlRough.Enabled = False
    '            ddlThickness.Enabled = False
    '        End If
    '        If ddlParamTest1.SelectedItem.Text = "Soaking Temperature" Then
    '            ddlGrade.Enabled = True
    '            ddlTdc.Enabled = False
    '            ddlRough.Enabled = False
    '            ddlThickness.Enabled = True
    '        End If
    '        If ddlParamTest1.SelectedItem.Text = "SPM Elongation" Then
    '            ddlGrade.Enabled = True
    '            ddlTdc.Enabled = False
    '            ddlRough.Enabled = False
    '            ddlThickness.Enabled = False
    '        End If
    '        If ddlParamTest1.SelectedItem.Text = "Zinc Pot Temperature" Then
    '            ddlGrade.Enabled = False
    '            ddlTdc.Enabled = False
    '            ddlRough.Enabled = False
    '            ddlThickness.Enabled = True
    '        End If
    '        DrawChartTop1(str1, fromDt, toDt, filter)
    '    End If

    'End Sub

    Sub DrawChartTop1(ByVal ColumnName As String, ByVal FromDt As String, ByVal ToDt As String, ByVal Filter As String)
        Try

            Dim strfrmDt As String = FromDt
            Dim strToDt As String = ToDt
            Dim usl As Double = 0.0
            Dim lsl As Double = 0.0
            Dim avg As Double = 0.0
            Dim lcl As Double = 0.0
            Dim ucl As Double = 0.0
            Dim standev As Double = 0.0
            Dim unit As String = ""
            Dim Cpk1 As Double = 0.0
            Dim Cp1 As Double = 0.0
            Dim js As String = ""
            Dim a() As String = ColumnName.Split(",")
            Dim l As Literal

            'For index As Integer = 0 To UBound(a)
            '    ddlGrade.Text = index.ToString
            '    UpdatePanel1.Update()
            'Next
            For i As Integer = 0 To UBound(a)
                Dim literals = Page.Master.FindControl("content_body").Controls.OfType(Of Literal)()
                For Each lit In literals
                    If (lit.ID = "Lit" & i + 1) Then
                        l = lit
                        Exit For
                    End If
                Next
                'If ddlParamTest1.SelectedItem.Text.Trim = "ECL tank" Then
                '    Dim dt As DataTable = objController.GetDataForCRMDailyReportECLTank("CRM_LABTEST_RES", "CLR_DT_SAMPLING_DATE", "CLR_PARAM_TEST", strfrmDt, strToDt, "", a(i))
                '    If dt.Rows.Count > 0 Then
                '        Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("ECL tank")

                '        Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(strfrmDt, strToDt, "ECL tank")

                '        CalculateCPK(dt, "clr_test_value", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)

                '        lblLCL.Text = Math.Round(lcl, 3)
                '        lblUCL.Text = Math.Round(ucl, 3)
                '        lblStddev.Text = Math.Round(standev, 3)
                '        lblUnitVal.Text = unit
                '        lblCpk.Text = Math.Round(Cpk1, 3)
                '        lblCp.Text = Math.Round(Cp1, 3)
                '        lblMean.Text = Math.Round(avg, 3)


                '        'Dim yVal() As String
                '        'yVal = (From row In dt Select col = row("clr_test_value").ToString).ToArray()

                '        ''Commented by pratik said by Dinesh
                '        ''lblMin.Text = yVal.Min()
                '        ''lblMax.Text = yVal.Max()

                '        'Dim sum As Integer = 0

                '        'For j As Integer = 0 To dt.Rows.Count - 1

                '        '    sum = sum + dt.Rows(j)("clr_test_value")


                '        'Next
                '        'avg = sum / dt.Rows.Count

                '        ''Commented by pratik said by Dinesh
                '        ''lblAvg.Text = Math.Round(avg, 3)

                '        'For k As Integer = 0 To dt.Rows.Count - 1
                '        '    standev += Pow(dt.Rows(k)("clr_test_value") - avg, 2)
                '        'Next
                '        'standev = Math.Sqrt(standev / dt.Rows.Count)
                '        'lcl = avg - (3 * standev)
                '        'ucl = avg + (3 * standev)
                '        'lblLCL.Text = Math.Round(lcl, 3)
                '        'lblUCL.Text = Math.Round(ucl, 3)
                '        'lblStddev.Text = Math.Round(standev, 3)
                '        'Dim val1 As Double = 0.0
                '        'Dim val2 As Double = 0.0

                '        ' ''Ádded on 25 may 2020
                '        'Dim usl1, lsl1 As Double
                '        'lsl1 = dtLimit.Rows(0)("LSL")
                '        'usl1 = dtLimit.Rows(0)("USL")
                '        'If IsDBNull(dtLimit.Rows(0)("Unit")) Then
                '        '    unit = ""
                '        'Else
                '        '    unit = dtLimit.Rows(0)("Unit")
                '        'End If
                '        'lblUnitVal.Text = unit
                '        'val1 = (usl1 - avg) / (3 * standev)
                '        'val2 = (avg - lsl1) / (3 * standev)

                '        'Dim Cpk As Double = 0.0
                '        'Cpk = Math.Min(val1, val2)
                '        'lblCpk.Text = Math.Round(Cpk, 3)
                '        'Dim Cp As Double = 0.0
                '        'Cp = ((yVal.Max() - yVal.Min()) / (6 * standev))
                '        'lblCp.Text = Math.Round(Cp, 3)
                '        'lblMean.Text = Math.Round(avg, 3)

                '        If dtLimit.Rows.Count > 0 Then

                '            'Commented by pratik said by Dinesh
                '            'txtMin.Text = dtLimit.Rows(0)("LSL")
                '            'txtMax.Text = dtLimit.Rows(0)("USL")
                '            lblMin.Text = dtLimit.Rows(0)("LSL")
                '            lblMax.Text = dtLimit.Rows(0)("USL")

                '            objController.PlotLineChartForCRMDailyReport(dt, "CLR_DT_SAMPLING_DATE", "clr_test_value", l, a(i), "plot" & i + 1, unit, dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                '        Else
                '            objController.PlotLineChartForCRMDailyReport(dt, "CLR_DT_SAMPLING_DATE", "clr_test_value", l, a(i), "plot" & i + 1, unit, 3, 2, avg, ucl, lcl, dtRemarks)
                '        End If

                '        Dim query As String = "select distinct CLR_DT_SAMPLING_DATE as 'SAMPLING_DATE',CLR_TEST_VALUE as 'TEST_VALUE',CLR_PARAM_TEST as 'PARAM_TEST',CLR_PROCESS_LINE as 'PROCESS_LINE','' as GRADE,'' as TDC_NO, '' as CD_PROD from CRM_LABTEST_RES where CLR_DT_SAMPLING_DATE between '" & strfrmDt & "' and '" & strToDt & "' and CLR_PROCESS_LINE IN('G','L') and CLR_PARAM_TEST = 'ALET' and CLR_TEST_VALUE > 0 order by CLR_DT_SAMPLING_DATE"
                '        objController.PopulateDailyReportData(query, gvDetails)
                '    Else
                '        gvDetails.DataSource = Nothing
                '        gvDetails.DataBind()
                '    End If
                'End If
                'If ddlParamTest1.SelectedItem.Text.Trim = "Predeg.tank" Then
                '    Dim dt As DataTable = objController.GetDataForCRMDailyReport("CRM_LABTEST_RES", "CLR_DT_SAMPLING_DATE", "CLR_PARAM_TEST", strfrmDt, strToDt, "", a(i))
                '    If dt.Rows.Count > 0 Then
                '        Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("Predeg.tank")

                '        Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(strfrmDt, strToDt, "Predeg.tank")

                '        CalculateCPK(dt, "clr_test_value", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)

                '        lblLCL.Text = Math.Round(lcl, 3)
                '        lblUCL.Text = Math.Round(ucl, 3)
                '        lblStddev.Text = Math.Round(standev, 3)
                '        lblUnitVal.Text = unit
                '        lblCpk.Text = Math.Round(Cpk1, 3)
                '        lblCp.Text = Math.Round(Cp1, 3)
                '        lblMean.Text = Math.Round(avg, 3)


                '        'Dim yVal() As String
                '        'yVal = (From row In dt Select col = row("clr_test_value").ToString).ToArray()

                '        ''Commented by pratik said by Dinesh
                '        ''lblMin.Text = yVal.Min()
                '        ''lblMax.Text = yVal.Max()

                '        'Dim sum As Integer = 0

                '        'For j As Integer = 0 To dt.Rows.Count - 1

                '        '    sum = sum + dt.Rows(j)("clr_test_value")

                '        'Next
                '        'avg = sum / dt.Rows.Count

                '        ''Commented by pratik said by Dinesh
                '        ''lblAvg.Text = Math.Round(avg, 3)

                '        'For k As Integer = 0 To dt.Rows.Count - 1
                '        '    standev += Pow(dt.Rows(k)("clr_test_value") - avg, 2)
                '        'Next
                '        'standev = Math.Sqrt(standev / dt.Rows.Count)

                '        'lcl = avg - (3 * standev)
                '        'ucl = avg + (3 * standev)
                '        'lblLCL.Text = Math.Round(lcl, 3)
                '        'lblUCL.Text = Math.Round(ucl, 3)
                '        'lblStddev.Text = Math.Round(standev, 3)
                '        'Dim val1 As Double = 0.0
                '        'Dim val2 As Double = 0.0

                '        ' ''Ádded on 25 may 2020
                '        'Dim usl1, lsl1 As Double
                '        'lsl1 = dtLimit.Rows(0)("LSL")
                '        'usl1 = dtLimit.Rows(0)("USL")
                '        'If IsDBNull(dtLimit.Rows(0)("Unit")) Then
                '        '    unit = ""
                '        'Else
                '        '    unit = dtLimit.Rows(0)("Unit")
                '        'End If
                '        'lblUnitVal.Text = unit
                '        'val1 = (usl1 - avg) / (3 * standev)
                '        'val2 = (avg - lsl1) / (3 * standev)

                '        'Dim Cpk As Double = 0.0
                '        'Cpk = Math.Min(val1, val2)
                '        'lblCpk.Text = Math.Round(Cpk, 3)
                '        'Dim Cp As Double = 0.0
                '        'Cp = ((yVal.Max() - yVal.Min()) / (6 * standev))
                '        'lblCp.Text = Math.Round(Cp, 3)
                '        'lblMean.Text = Math.Round(avg, 3)
                '        If dtLimit.Rows.Count > 0 Then

                '            'Commented by pratik said by Dinesh
                '            'txtMin.Text = dtLimit.Rows(0)("LSL")
                '            'txtMax.Text = dtLimit.Rows(0)("USL")
                '            lblMin.Text = dtLimit.Rows(0)("LSL")
                '            lblMax.Text = dtLimit.Rows(0)("USL")

                '            objController.PlotLineChartForCRMDailyReport(dt, "CLR_DT_SAMPLING_DATE", "clr_test_value", l, a(i), "plot" & i + 1, unit, dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                '        Else
                '            objController.PlotLineChartForCRMDailyReport(dt, "CLR_DT_SAMPLING_DATE", "clr_test_value", l, a(i), "plot" & i + 1, unit, 3.0, 2.0, avg, ucl, lcl, dtRemarks)
                '        End If


                '        Dim query As String = "select distinct CLR_DT_SAMPLING_DATE as 'SAMPLING_DATE',CLR_TEST_VALUE as 'TEST_VALUE',CLR_PARAM_TEST as 'PARAM_TEST',CLR_PROCESS_LINE as 'PROCESS_LINE','' as GRADE,'' as TDC_NO, '' as CD_PROD from CRM_LABTEST_RES where CLR_DT_SAMPLING_DATE between '" & strfrmDt & "' and '" & strToDt & "' and CLR_PROCESS_LINE IN('G','L') and CLR_PARAM_TEST = 'ALPT' and CLR_TEST_VALUE > 0 order by CLR_DT_SAMPLING_DATE"
                '        objController.PopulateDailyReportData(query, gvDetails)
                '    Else
                '        gvDetails.DataSource = Nothing
                '        gvDetails.DataBind()
                '    End If
                'End If
                'If ddlParamTest1.SelectedItem.Text.Trim = "Sheet Chromium" Then
                '    Dim dt1 As DataTable = objController.GetDataForCRMDailyReportSheetChromium("CRM_LABTEST_RES", "CLR_DT_SAMPLING_DATE", "CLR_PARAM_TEST", strfrmDt, strToDt, "", a(i))
                '    If dt1.Rows.Count > 0 Then
                '        Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("Sheet Chromium")

                '        Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(strfrmDt, strToDt, "Sheet Chromium")

                '        CalculateCPK(dt1, "clr_test_value", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)

                '        lblLCL.Text = Math.Round(lcl, 3)
                '        lblUCL.Text = Math.Round(ucl, 3)
                '        lblStddev.Text = Math.Round(standev, 3)
                '        lblUnitVal.Text = unit
                '        lblCpk.Text = Math.Round(Cpk1, 3)
                '        lblCp.Text = Math.Round(Cp1, 3)
                '        lblMean.Text = Math.Round(avg, 3)


                '        'Dim yVal() As String
                '        'yVal = (From row In dt1 Select col = row("clr_test_value").ToString).ToArray()

                '        ''Commented by pratik said by Dinesh
                '        ''lblMin.Text = yVal.Min()
                '        ''lblMax.Text = yVal.Max()

                '        'Dim sum As Integer = 0

                '        'For j As Integer = 0 To dt1.Rows.Count - 1

                '        '    sum = sum + dt1.Rows(j)("clr_test_value")

                '        'Next
                '        'avg = sum / dt1.Rows.Count

                '        ''Commented by pratik said by Dinesh
                '        ''lblAvg.Text = Math.Round(avg, 3)

                '        'For k As Integer = 0 To dt1.Rows.Count - 1
                '        '    standev += Pow(dt1.Rows(k)("clr_test_value") - avg, 2)
                '        'Next
                '        'standev = Math.Sqrt(standev / dt1.Rows.Count)

                '        'lcl = avg - (3 * standev)
                '        'ucl = avg + (3 * standev)
                '        'lblLCL.Text = Math.Round(lcl, 3)
                '        'lblUCL.Text = Math.Round(ucl, 3)
                '        'lblStddev.Text = Math.Round(standev, 3)
                '        'Dim val1 As Double = 0.0
                '        'Dim val2 As Double = 0.0

                '        ' ''Ádded on 25 may 2020
                '        'Dim usl1, lsl1 As Double
                '        'lsl1 = dtLimit.Rows(0)("LSL")
                '        'usl1 = dtLimit.Rows(0)("USL")
                '        'If IsDBNull(dtLimit.Rows(0)("Unit")) Then
                '        '    unit = ""
                '        'Else
                '        '    unit = dtLimit.Rows(0)("Unit")
                '        'End If
                '        'lblUnitVal.Text = unit
                '        'val1 = (usl1 - avg) / (3 * standev)
                '        'val2 = (avg - lsl1) / (3 * standev)

                '        'Dim Cpk As Double = 0.0
                '        'Cpk = Math.Min(val1, val2)
                '        'lblCpk.Text = Math.Round(Cpk, 3)
                '        'Dim Cp As Double = 0.0
                '        'Cp = ((yVal.Max() - yVal.Min()) / (6 * standev))
                '        'lblCp.Text = Math.Round(Cp, 3)
                '        'lblMean.Text = Math.Round(avg, 3)
                '        If dtLimit.Rows.Count > 0 Then

                '            'Commented by pratik said by Dinesh
                '            'txtMin.Text = dtLimit.Rows(0)("LSL")
                '            'txtMax.Text = dtLimit.Rows(0)("USL")
                '            lblMin.Text = dtLimit.Rows(0)("LSL")
                '            lblMax.Text = dtLimit.Rows(0)("USL")

                '            objController.PlotLineChartForCRMDailyReport(dt1, "CLR_DT_SAMPLING_DATE", "clr_test_value", l, a(i), "plot" & i + 1, unit, dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                '        Else
                '            objController.PlotLineChartForCRMDailyReport(dt1, "CLR_DT_SAMPLING_DATE", "clr_test_value", l, a(i), "plot" & i + 1, unit, 65.0, 30.0, avg, ucl, lcl, dtRemarks)
                '        End If

                '        'Dim query As String = "Select CR.CLR_DT_SAMPLING_DATE as 'SAMPLING_DATE',CR.CLR_ID_COIL,TC.PRM_ID_COIL,CR.CLR_TEST_VALUE as 'TEST_VALUE',CLR_PARAM_TEST as 'PARAM_TEST',CLR_PROCESS_LINE as 'PROCESS_LINE',TC.PRM_CD_GRADE as GRADE,TC.PRM_TDC_NO as TDC_NO, TC.PRM_CD_PROD as CD_PROD from CRM_LABTEST_RES CR INNER JOIN T_CGL_FUR_PARAM TC ON TC.PRM_ID_COIL LIKE CONCAT('%',CR.CLR_ID_COIL,'%') AND CR.CLR_ID_COIL=TC.PRM_ID_COIL   WHERE CR.CLR_PROCESS_LINE='L' AND TC.PRM_TDC_NO IN('GA14','GAF3','GA04','GA15') AND CR.CLR_DT_SAMPLING_DATE between '" & strfrmDt & "' and '" & strToDt & "' and CLR_PARAM_TEST = 'SHCR' order by CR.CLR_DT_SAMPLING_DATE "
                '        Dim query As String = "Select distinct CR.CLR_DT_SAMPLING_DATE as 'SAMPLING_DATE',CR.CLR_ID_COIL,TC.PRM_ID_COIL,CR.CLR_TEST_VALUE as 'TEST_VALUE',CLR_PARAM_TEST as 'PARAM_TEST',CLR_PROCESS_LINE as 'PROCESS_LINE',TC.PRM_CD_GRADE as GRADE,TC.PRM_TDC_NO as TDC_NO, TC.PRM_CD_PROD as CD_PROD from CRM_LABTEST_RES CR INNER JOIN T_CGL_FUR_PARAM TC ON substring(CR.CLR_ID_COIL,1,6)=substring(TC.PRM_ID_COIL,1,6)   WHERE CR.CLR_PROCESS_LINE='L' AND TC.PRM_TDC_NO IN('GA14','GAF3','GA04','GA15') AND CR.CLR_DT_SAMPLING_DATE between '" & strfrmDt & "' and '" & strToDt & "' and CLR_PARAM_TEST = 'SHCR' and CR.CLR_TEST_VALUE > 0 order by CR.CLR_DT_SAMPLING_DATE "
                '        objController.PopulateDailyReportData(query, gvDetails)
                '    Else
                '        gvDetails.DataSource = Nothing
                '        gvDetails.DataBind()
                '    End If
                'End If
                'If ddlParamTest1.SelectedItem.Text.Trim = "Working tank" Then
                '    Dim dt1 As DataTable = objController.GetDataForCRMDailyReportChromateTank("CRM_LABTEST_RES", "CLR_DT_SAMPLING_DATE", "CLR_PARAM_TEST", strfrmDt, strToDt, "", a(i))
                '    If dt1.Rows.Count > 0 Then
                '        Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("Working tank")

                '        Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(strfrmDt, strToDt, "Working tank")

                '        CalculateCPK(dt1, "clr_test_value", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)

                '        lblLCL.Text = Math.Round(lcl, 3)
                '        lblUCL.Text = Math.Round(ucl, 3)
                '        lblStddev.Text = Math.Round(standev, 3)
                '        lblUnitVal.Text = unit
                '        lblCpk.Text = Math.Round(Cpk1, 3)
                '        lblCp.Text = Math.Round(Cp1, 3)
                '        lblMean.Text = Math.Round(avg, 3)


                '        'Dim yVal() As String
                '        'yVal = (From row In dt1 Select col = row("clr_test_value").ToString).ToArray()

                '        ''Commented by pratik said by Dinesh
                '        ''lblMin.Text = yVal.Min()
                '        ''lblMax.Text = yVal.Max()

                '        'Dim sum As Integer = 0

                '        'For j As Integer = 0 To dt1.Rows.Count - 1

                '        '    sum = sum + dt1.Rows(j)("clr_test_value")

                '        'Next
                '        'avg = sum / dt1.Rows.Count

                '        ''Commented by pratik said by Dinesh
                '        ''lblAvg.Text = Math.Round(avg, 3)

                '        'For k As Integer = 0 To dt1.Rows.Count - 1
                '        '    standev += Pow(dt1.Rows(k)("clr_test_value") - avg, 2)
                '        'Next
                '        'standev = Math.Sqrt(standev / dt1.Rows.Count)

                '        'lcl = avg - (3 * standev)
                '        'ucl = avg + (3 * standev)
                '        'lblLCL.Text = Math.Round(lcl, 3)
                '        'lblUCL.Text = Math.Round(ucl, 3)
                '        'lblStddev.Text = Math.Round(standev, 3)
                '        'Dim val1 As Double = 0.0
                '        'Dim val2 As Double = 0.0

                '        ' ''Ádded on 25 may 2020
                '        'Dim usl1, lsl1 As Double
                '        'lsl1 = dtLimit.Rows(0)("LSL")
                '        'usl1 = dtLimit.Rows(0)("USL")
                '        'If IsDBNull(dtLimit.Rows(0)("Unit")) Then
                '        '    unit = ""
                '        'Else
                '        '    unit = dtLimit.Rows(0)("Unit")
                '        'End If
                '        'lblUnitVal.Text = unit
                '        'val1 = (usl1 - avg) / (3 * standev)
                '        'val2 = (avg - lsl1) / (3 * standev)

                '        'Dim Cpk As Double = 0.0
                '        'Cpk = Math.Min(val1, val2)
                '        'lblCpk.Text = Math.Round(Cpk, 3)
                '        'Dim Cp As Double = 0.0
                '        'Cp = ((yVal.Max() - yVal.Min()) / (6 * standev))
                '        'lblCp.Text = Math.Round(Cp, 3)
                '        'lblMean.Text = Math.Round(avg, 3)
                '        If dtLimit.Rows.Count > 0 Then

                '            'Commented by pratik said by Dinesh
                '            'txtMin.Text = dtLimit.Rows(0)("LSL")
                '            'txtMax.Text = dtLimit.Rows(0)("USL")
                '            lblMin.Text = dtLimit.Rows(0)("LSL")
                '            lblMax.Text = dtLimit.Rows(0)("USL")

                '            objController.PlotLineChartForCRMDailyReport(dt1, "CLR_DT_SAMPLING_DATE", "clr_test_value", l, a(i), "plot" & i + 1, unit, dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                '        Else
                '            objController.PlotLineChartForCRMDailyReport(dt1, "CLR_DT_SAMPLING_DATE", "clr_test_value", l, a(i), "plot" & i + 1, unit, 25.0, 20.0, avg, ucl, lcl, dtRemarks)
                '        End If

                '        Dim query As String = "Select distinct CR.CLR_DT_SAMPLING_DATE as 'SAMPLING_DATE',CR.CLR_ID_COIL,TC.PRM_ID_COIL,CR.CLR_TEST_VALUE as 'TEST_VALUE',CLR_PARAM_TEST as 'PARAM_TEST',CLR_PROCESS_LINE as 'PROCESS_LINE',TC.PRM_CD_GRADE as GRADE,TC.PRM_TDC_NO as TDC_NO, TC.PRM_CD_PROD as CD_PROD from CRM_LABTEST_RES CR INNER JOIN T_CGL_FUR_PARAM TC ON TC.PRM_ID_COIL LIKE CONCAT('%',CR.CLR_ID_COIL,'%') AND CR.CLR_ID_COIL=TC.PRM_ID_COIL WHERE CR.CLR_PROCESS_LINE='L' AND TC.PRM_CD_PROD='C10' AND CR.CLR_DT_SAMPLING_DATE between '" & strfrmDt & "' and '" & strToDt & "' and CLR_PARAM_TEST = 'CRWT' and CR.CLR_TEST_VALUE > 0 order by CLR_DT_SAMPLING_DATE "
                '        objController.PopulateDailyReportData(query, gvDetails)
                '    Else
                '        gvDetails.DataSource = Nothing
                '        gvDetails.DataBind()
                '    End If
                'End If
                If ddlParamTest1.SelectedItem.Text.Trim = "Sheet Fe in GA" Then
                    'Dim dt1 As DataTable = objController.GetDataForCRMDailyReportInFeGA("T_CGL_FUR_PARAM", strfrmDt, strToDt, "PRM_TS_END", ColumnName, Filter)
                    Dim dt1 As DataTable = objController.GetDataForCRMDailyReportNew("T_DM1", strfrmDt, strToDt, "PRM_TEST_VALUE_FEGA", Filter)
                    If dt1.Rows.Count > 0 Then
                        Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("Sheet Fe in GA")

                        Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(strfrmDt, strToDt, "Sheet Fe in GA")

                        CalculateCPK(dt1, "TEST_VALUE", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)

                        lblLCL.Text = Math.Round(lcl, 3)
                        lblUCL.Text = Math.Round(ucl, 3)
                        lblStddev.Text = Math.Round(standev, 3)
                        lblUnitVal.Text = unit
                        lblCpk.Text = Math.Round(Cpk1, 3)
                        lblCp.Text = Math.Round(Cp1, 3)
                        lblMean.Text = Math.Round(avg, 3)

                        'Dim yVal() As String
                        'yVal = (From row In dt1 Select col = row("PRM_TEST_VALUE_FEGA").ToString).ToArray()

                        ''Commented by pratik said by Dinesh
                        ''lblMin.Text = yVal.Min()
                        ''lblMax.Text = yVal.Max()

                        'Dim sum As Integer = 0

                        'For j As Integer = 0 To dt1.Rows.Count - 1

                        '    sum = sum + dt1.Rows(j)("PRM_TEST_VALUE_FEGA")

                        'Next
                        'avg = sum / dt1.Rows.Count

                        ''Commented by pratik said by Dinesh
                        ''lblAvg.Text = Math.Round(avg, 3)

                        'For k As Integer = 0 To dt1.Rows.Count - 1
                        '    standev += Pow(dt1.Rows(k)("PRM_TEST_VALUE_FEGA") - avg, 2)
                        'Next
                        'standev = Math.Sqrt(standev / dt1.Rows.Count)

                        'lcl = avg - (3 * standev)
                        'ucl = avg + (3 * standev)
                        'lblLCL.Text = Math.Round(lcl, 3)
                        'lblUCL.Text = Math.Round(ucl, 3)
                        'lblStddev.Text = Math.Round(standev, 3)
                        'Dim val1 As Double = 0.0
                        'Dim val2 As Double = 0.0

                        ' ''Ádded on 25 may 2020
                        'Dim usl1, lsl1 As Double
                        'lsl1 = dtLimit.Rows(0)("LSL")
                        'usl1 = dtLimit.Rows(0)("USL")
                        'If IsDBNull(dtLimit.Rows(0)("Unit")) Then
                        '    unit = ""
                        'Else
                        '    unit = dtLimit.Rows(0)("Unit")
                        'End If
                        'lblUnitVal.Text = unit
                        'val1 = (usl1 - avg) / (3 * standev)
                        'val2 = (avg - lsl1) / (3 * standev)

                        'Dim Cpk As Double = 0.0
                        'Cpk = Math.Min(val1, val2)
                        'lblCpk.Text = Math.Round(Cpk, 3)
                        'Dim Cp As Double = 0.0
                        'Cp = ((yVal.Max() - yVal.Min()) / (6 * standev))
                        'lblCp.Text = Math.Round(Cp, 3)
                        'lblMean.Text = Math.Round(avg, 3)
                        If dtLimit.Rows.Count > 0 Then

                            'Commented by pratik said by Dinesh
                            'txtMin.Text = dtLimit.Rows(0)("LSL")
                            'txtMax.Text = dtLimit.Rows(0)("USL")
                            lblMin.Text = dtLimit.Rows(0)("LSL")
                            lblMax.Text = dtLimit.Rows(0)("USL")

                            objController.PlotLineChartForCRMDailyReportInFeGA(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                        Else
                            objController.PlotLineChartForCRMDailyReportInFeGA(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, 12.5, 8.0, avg, ucl, lcl, dtRemarks)
                        End If

                        Dim query As String = "Select distinct SAMPLING_DATE as 'SAMPLING_DATE',COIL_ID,TEST_VALUE as 'TEST_VALUE','' as 'PARAM_TEST','' as 'PROCESS_LINE',GRADE as GRADE,TDC_NO as TDC_NO, CD_PROD as CD_PROD from T_DM1 where PARAM_TEST = 'PRM_TEST_VALUE_FEGA' and SAMPLING_DATE between '" & strfrmDt & "' and '" & strToDt & "' and TEST_VALUE is not null and TEST_VALUE > 0 order by SAMPLING_DATE"
                        objController.PopulateDailyReportData(query, gvDetails)

                    Else
                        gvDetails.DataSource = Nothing
                        gvDetails.DataBind()
                    End If
                End If
                If ddlParamTest1.SelectedItem.Text.Trim = "Soaking Temperature" Then
                    'Dim dt1 As DataTable = objController.GetDataForCRMDailyReportInFeGA("T_CGL_FUR_PARAM", strfrmDt, strToDt, "PRM_TS_END", ColumnName, Filter)
                    Dim dt1 As DataTable = objController.GetDataForCRMDailyReportNew("T_DM1", strfrmDt, strToDt, "PRM_SS_STRP_TMP", Filter)
                    If dt1.Rows.Count > 0 Then
                        Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("Soaking Temperature")

                        Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(strfrmDt, strToDt, "Soaking Temperature")

                        CalculateCPK(dt1, "TEST_VALUE", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)

                        lblLCL.Text = Math.Round(lcl, 3)
                        lblUCL.Text = Math.Round(ucl, 3)
                        lblStddev.Text = Math.Round(standev, 3)
                        lblUnitVal.Text = unit
                        lblCpk.Text = Math.Round(Cpk1, 3)
                        lblCp.Text = Math.Round(Cp1, 3)
                        lblMean.Text = Math.Round(avg, 3)

                        'Dim yVal() As String
                        'yVal = (From row In dt1 Select col = row("PRM_SS_STRP_TMP").ToString).ToArray()

                        ''Commented by pratik said by Dinesh
                        ''lblMin.Text = yVal.Min()
                        ''lblMax.Text = yVal.Max()

                        'Dim sum As Integer = 0

                        'For j As Integer = 0 To dt1.Rows.Count - 1

                        '    sum = sum + dt1.Rows(j)("PRM_SS_STRP_TMP")

                        'Next
                        'avg = sum / dt1.Rows.Count

                        ''Commented by pratik said by Dinesh
                        ''lblAvg.Text = Math.Round(avg, 3)

                        'For k As Integer = 0 To dt1.Rows.Count - 1
                        '    standev += Pow(dt1.Rows(k)("PRM_SS_STRP_TMP") - avg, 2)
                        'Next
                        'standev = Math.Sqrt(standev / dt1.Rows.Count)

                        'lcl = avg - (3 * standev)
                        'ucl = avg + (3 * standev)
                        'lblLCL.Text = Math.Round(lcl, 3)
                        'lblUCL.Text = Math.Round(ucl, 3)
                        'lblStddev.Text = Math.Round(standev, 3)
                        'Dim val1 As Double = 0.0
                        'Dim val2 As Double = 0.0

                        ' ''Ádded on 25 may 2020
                        'Dim usl1, lsl1 As Double
                        'lsl1 = dtLimit.Rows(0)("LSL")
                        'usl1 = dtLimit.Rows(0)("USL")
                        'If IsDBNull(dtLimit.Rows(0)("Unit")) Then
                        '    unit = ""
                        'Else
                        '    unit = dtLimit.Rows(0)("Unit")
                        'End If
                        'lblUnitVal.Text = unit
                        'val1 = (usl1 - avg) / (3 * standev)
                        'val2 = (avg - lsl1) / (3 * standev)

                        'Dim Cpk As Double = 0.0
                        'Cpk = Math.Min(val1, val2)
                        'lblCpk.Text = Math.Round(Cpk, 3)
                        'Dim Cp As Double = 0.0
                        'Cp = ((yVal.Max() - yVal.Min()) / (6 * standev))
                        'lblCp.Text = Math.Round(Cp, 3)
                        'lblMean.Text = Math.Round(avg, 3)
                        If dtLimit.Rows.Count > 0 Then

                            'Commented by pratik said by Dinesh
                            'txtMin.Text = dtLimit.Rows(0)("LSL")
                            'txtMax.Text = dtLimit.Rows(0)("USL")
                            lblMin.Text = dtLimit.Rows(0)("LSL")
                            lblMax.Text = dtLimit.Rows(0)("USL")

                            objController.PlotLineChartForCRMDailyReportInFeGA(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                        Else
                            objController.PlotLineChartForCRMDailyReportInFeGA(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, 750.0, 700.0, avg, ucl, lcl, dtRemarks)
                        End If

                        'Dim query As String = "Select distinct PRM_TS_END as 'SAMPLING_DATE',PRM_ID_COIL,PRM_SS_STRP_TMP as 'TEST_VALUE','' as 'PARAM_TEST','' as 'PROCESS_LINE',PRM_CD_GRADE as GRADE,PRM_TDC_NO as TDC_NO, PRM_CD_PROD as CD_PROD from T_CGL_FUR_PARAM where PRM_TS_END between '" & strfrmDt & "' and '" & strToDt & "' and  1=1 and PRM_SS_STRP_TMP is not null and PRM_SS_STRP_TMP > 0 "
                        Dim query As String = "Select distinct SAMPLING_DATE as 'SAMPLING_DATE',COIL_ID,TEST_VALUE as 'TEST_VALUE','' as 'PARAM_TEST','' as 'PROCESS_LINE',GRADE as GRADE,TDC_NO as TDC_NO, CD_PROD as CD_PROD from T_DM1 where PARAM_TEST = 'PRM_SS_STRP_TMP' and SAMPLING_DATE between '" & strfrmDt & "' and '" & strToDt & "' and TEST_VALUE is not null and TEST_VALUE > 0 order by SAMPLING_DATE"
                        objController.PopulateDailyReportData(query, gvDetails)
                    Else
                        gvDetails.DataSource = Nothing
                        gvDetails.DataBind()
                    End If
                End If
                If ddlParamTest1.SelectedItem.Text.Trim = "SPM Elongation" Then
                    'Dim dt1 As DataTable = objController.GetDataForCRMDailyReportInFeGA("T_CGL_FUR_PARAM", strfrmDt, strToDt, "PRM_TS_END", ColumnName, Filter)
                    Dim dt1 As DataTable = objController.GetDataForCRMDailyReportNew("T_DM1", strfrmDt, strToDt, "PRM_ELONG", Filter)
                    If dt1.Rows.Count > 0 Then
                        Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("SPM Elongation")

                        Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(strfrmDt, strToDt, "SPM Elongation")

                        CalculateCPK(dt1, "TEST_VALUE", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)

                        lblLCL.Text = Math.Round(lcl, 3)
                        lblUCL.Text = Math.Round(ucl, 3)
                        lblStddev.Text = Math.Round(standev, 3)
                        lblUnitVal.Text = unit
                        lblCpk.Text = Math.Round(Cpk1, 3)
                        lblCp.Text = Math.Round(Cp1, 3)
                        lblMean.Text = Math.Round(avg, 3)

                        'Dim yVal() As String
                        'yVal = (From row In dt1 Select col = row("PRM_ELONG").ToString).ToArray()

                        ''Commented by pratik said by Dinesh
                        ''lblMin.Text = yVal.Min()
                        ''lblMax.Text = yVal.Max()

                        'Dim sum As Integer = 0

                        'For j As Integer = 0 To dt1.Rows.Count - 1

                        '    sum = sum + dt1.Rows(j)("PRM_ELONG")

                        'Next
                        'avg = sum / dt1.Rows.Count

                        ''Commented by pratik said by Dinesh
                        ''lblAvg.Text = Math.Round(avg, 3)

                        'For k As Integer = 0 To dt1.Rows.Count - 1
                        '    standev += Pow(dt1.Rows(k)("PRM_ELONG") - avg, 2)
                        'Next
                        'standev = Math.Sqrt(standev / dt1.Rows.Count)

                        'lcl = avg - (3 * standev)
                        'ucl = avg + (3 * standev)
                        'lblLCL.Text = Math.Round(lcl, 3)
                        'lblUCL.Text = Math.Round(ucl, 3)
                        'lblStddev.Text = Math.Round(standev, 3)
                        'Dim val1 As Double = 0.0
                        'Dim val2 As Double = 0.0

                        ' ''Ádded on 25 may 2020
                        'Dim usl1, lsl1 As Double
                        'lsl1 = dtLimit.Rows(0)("LSL")
                        'usl1 = dtLimit.Rows(0)("USL")
                        'If IsDBNull(dtLimit.Rows(0)("Unit")) Then
                        '    unit = ""
                        'Else
                        '    unit = dtLimit.Rows(0)("Unit")
                        'End If
                        'lblUnitVal.Text = unit
                        'val1 = (usl1 - avg) / (3 * standev)
                        'val2 = (avg - lsl1) / (3 * standev)

                        'Dim Cpk As Double = 0.0
                        'Cpk = Math.Min(val1, val2)
                        'lblCpk.Text = Math.Round(Cpk, 3)
                        'Dim Cp As Double = 0.0
                        'Cp = ((yVal.Max() - yVal.Min()) / (6 * standev))
                        'lblCp.Text = Math.Round(Cp, 3)
                        'lblMean.Text = Math.Round(avg, 3)
                        If dtLimit.Rows.Count > 0 Then

                            'Commented by pratik said by Dinesh
                            'txtMin.Text = dtLimit.Rows(0)("LSL")
                            'txtMax.Text = dtLimit.Rows(0)("USL")
                            lblMin.Text = dtLimit.Rows(0)("LSL")
                            lblMax.Text = dtLimit.Rows(0)("USL")

                            objController.PlotLineChartForCRMDailyReportInFeGA(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                        Else
                            objController.PlotLineChartForCRMDailyReportInFeGA(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, 2.0, 1.0, avg, ucl, lcl, dtRemarks)
                        End If

                        'Dim query As String = "Select distinct PRM_TS_END as 'SAMPLING_DATE',PRM_ID_COIL,PRM_ELONG as 'TEST_VALUE','' as 'PARAM_TEST','' as 'PROCESS_LINE',PRM_CD_GRADE as GRADE,PRM_TDC_NO as TDC_NO, PRM_CD_PROD as CD_PROD from T_CGL_FUR_PARAM where PRM_TS_END between '" & strfrmDt & "' and '" & strToDt & "' and  1=1 and PRM_ELONG is not null and PRM_ELONG > 0 "
                        Dim query As String = "Select distinct SAMPLING_DATE as 'SAMPLING_DATE',COIL_ID,TEST_VALUE as 'TEST_VALUE','' as 'PARAM_TEST','' as 'PROCESS_LINE',GRADE as GRADE,TDC_NO as TDC_NO, CD_PROD as CD_PROD from T_DM1 where PARAM_TEST = 'PRM_ELONG' and SAMPLING_DATE between '" & strfrmDt & "' and '" & strToDt & "' and TEST_VALUE is not null and TEST_VALUE > 0 order by SAMPLING_DATE"
                        objController.PopulateDailyReportData(query, gvDetails)
                    Else
                        gvDetails.DataSource = Nothing
                        gvDetails.DataBind()
                    End If

                End If
                If ddlParamTest1.SelectedItem.Text.Trim = "Zinc Pot Temperature" Then
                    'Dim dt1 As DataTable = objController.GetDataForCRMDailyReportInFeGA("T_CGL_FUR_PARAM", strfrmDt, strToDt, "PRM_TS_END", ColumnName, Filter)
                    Dim dt1 As DataTable = objController.GetDataForCRMDailyReportNew("T_DM1", strfrmDt, strToDt, "PRM_ZINC_POT_TMP", Filter)
                    If dt1.Rows.Count > 0 Then
                        Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("Zinc Pot Temperature")

                        Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(strfrmDt, strToDt, "Zinc Pot Temperature")

                        CalculateCPK(dt1, "TEST_VALUE", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)

                        lblLCL.Text = Math.Round(lcl, 3)
                        lblUCL.Text = Math.Round(ucl, 3)
                        lblStddev.Text = Math.Round(standev, 3)
                        lblUnitVal.Text = unit
                        lblCpk.Text = Math.Round(Cpk1, 3)
                        lblCp.Text = Math.Round(Cp1, 3)
                        lblMean.Text = Math.Round(avg, 3)

                        'Dim yVal() As String
                        'yVal = (From row In dt1 Select col = row("PRM_ZINC_POT_TMP").ToString).ToArray()

                        ''Commented by pratik said by Dinesh
                        ''lblMin.Text = yVal.Min()
                        ''lblMax.Text = yVal.Max()

                        'Dim sum As Integer = 0

                        'For j As Integer = 0 To dt1.Rows.Count - 1

                        '    sum = sum + dt1.Rows(j)("PRM_ZINC_POT_TMP")

                        'Next
                        'avg = sum / dt1.Rows.Count

                        ''Commented by pratik said by Dinesh
                        ''lblAvg.Text = Math.Round(avg, 3)

                        'For k As Integer = 0 To dt1.Rows.Count - 1
                        '    standev += Pow(dt1.Rows(k)("PRM_ZINC_POT_TMP") - avg, 2)
                        'Next
                        'standev = Math.Sqrt(standev / dt1.Rows.Count)

                        'lcl = avg - (3 * standev)
                        'ucl = avg + (3 * standev)
                        'lblLCL.Text = Math.Round(lcl, 3)
                        'lblUCL.Text = Math.Round(ucl, 3)
                        'lblStddev.Text = Math.Round(standev, 3)
                        'Dim val1 As Double = 0.0
                        'Dim val2 As Double = 0.0

                        ' ''Ádded on 25 may 2020
                        'Dim usl1, lsl1 As Double
                        'lsl1 = dtLimit.Rows(0)("LSL")
                        'usl1 = dtLimit.Rows(0)("USL")
                        'If IsDBNull(dtLimit.Rows(0)("Unit")) Then
                        '    unit = ""
                        'Else
                        '    unit = dtLimit.Rows(0)("Unit")
                        'End If
                        'lblUnitVal.Text = unit
                        'val1 = (usl1 - avg) / (3 * standev)
                        'val2 = (avg - lsl1) / (3 * standev)

                        'Dim Cpk As Double = 0.0
                        'Cpk = Math.Min(val1, val2)
                        'lblCpk.Text = Math.Round(Cpk, 3)
                        'Dim Cp As Double = 0.0
                        'Cp = ((yVal.Max() - yVal.Min()) / (6 * standev))
                        'lblCp.Text = Math.Round(Cp, 3)
                        'lblMean.Text = Math.Round(avg, 3)
                        If dtLimit.Rows.Count > 0 Then

                            'Commented by pratik said by Dinesh
                            'txtMin.Text = dtLimit.Rows(0)("LSL")
                            'txtMax.Text = dtLimit.Rows(0)("USL")
                            lblMin.Text = dtLimit.Rows(0)("LSL")
                            lblMax.Text = dtLimit.Rows(0)("USL")

                            objController.PlotLineChartForCRMDailyReportInFeGA(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                        Else
                            objController.PlotLineChartForCRMDailyReportInFeGA(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, 465.0, 455.0, avg, ucl, lcl, dtRemarks)
                        End If

                        'Dim query As String = "Select distinct PRM_TS_END as 'SAMPLING_DATE',PRM_ID_COIL,PRM_ZINC_POT_TMP as 'TEST_VALUE','' as 'PARAM_TEST','' as 'PROCESS_LINE',PRM_CD_GRADE as GRADE,PRM_TDC_NO as TDC_NO, PRM_CD_PROD as CD_PROD from T_CGL_FUR_PARAM where PRM_TS_END between '" & strfrmDt & "' and '" & strToDt & "' and  1=1 and PRM_ZINC_POT_TMP is not null and PRM_ZINC_POT_TMP > 0 "
                        Dim query As String = "Select distinct SAMPLING_DATE as 'SAMPLING_DATE',COIL_ID,TEST_VALUE as 'TEST_VALUE','' as 'PARAM_TEST','' as 'PROCESS_LINE',GRADE as GRADE,TDC_NO as TDC_NO, CD_PROD as CD_PROD from T_DM1 where PARAM_TEST = 'PRM_ZINC_POT_TMP' and SAMPLING_DATE between '" & strfrmDt & "' and '" & strToDt & "' and TEST_VALUE is not null and TEST_VALUE > 0 order by SAMPLING_DATE"
                        objController.PopulateDailyReportData(query, gvDetails)
                    Else
                        gvDetails.DataSource = Nothing
                        gvDetails.DataBind()

                    End If
                End If
                If ddlParamTest1.SelectedItem.Text.Trim = "ECL rectifier Current" Then
                    'Dim dt1 As DataTable = objController.GetDataForCRMDailyReportInFeGA("T_CGL_FUR_PARAM", strfrmDt, strToDt, "PRM_TS_END", ColumnName, Filter)
                    Dim dt1 As DataTable = objController.GetDataForCRMDailyReportNew("T_DM1", strfrmDt, strToDt, "PRM_DS_ELEC_CUR", Filter)
                    If dt1.Rows.Count > 0 Then
                        Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("ECL rectifier Current")

                        Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(strfrmDt, strToDt, "ECL rectifier Current")

                        CalculateCPK(dt1, "TEST_VALUE", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)

                        lblLCL.Text = Math.Round(lcl, 3)
                        lblUCL.Text = Math.Round(ucl, 3)
                        lblStddev.Text = Math.Round(standev, 3)
                        lblUnitVal.Text = unit
                        lblCpk.Text = Math.Round(Cpk1, 3)
                        lblCp.Text = Math.Round(Cp1, 3)
                        lblMean.Text = Math.Round(avg, 3)


                        'Dim yVal() As String
                        'yVal = (From row In dt1 Select col = row("PRM_DS_ELEC_CUR").ToString).ToArray()

                        ''Commented by pratik said by Dinesh
                        ''lblMin.Text = yVal.Min()
                        ''lblMax.Text = yVal.Max()

                        'Dim sum As Integer = 0

                        'For j As Integer = 0 To dt1.Rows.Count - 1

                        '    sum = sum + dt1.Rows(j)("PRM_DS_ELEC_CUR")

                        'Next
                        'avg = sum / dt1.Rows.Count

                        ''Commented by pratik said by Dinesh
                        ''lblAvg.Text = Math.Round(avg, 3)

                        'For k As Integer = 0 To dt1.Rows.Count - 1
                        '    standev += Pow(dt1.Rows(k)("PRM_DS_ELEC_CUR") - avg, 2)
                        'Next
                        'standev = Math.Sqrt(standev / dt1.Rows.Count)

                        'lcl = avg - (3 * standev)
                        'ucl = avg + (3 * standev)
                        'lblLCL.Text = Math.Round(lcl, 3)
                        'lblUCL.Text = Math.Round(ucl, 3)
                        'lblStddev.Text = Math.Round(standev, 3)
                        'Dim val1 As Double = 0.0
                        'Dim val2 As Double = 0.0

                        ' ''Ádded on 25 may 2020
                        'Dim usl1, lsl1 As Double
                        'lsl1 = dtLimit.Rows(0)("LSL")
                        'usl1 = dtLimit.Rows(0)("USL")
                        'If IsDBNull(dtLimit.Rows(0)("Unit")) Then
                        '    unit = ""
                        'Else
                        '    unit = dtLimit.Rows(0)("Unit")
                        'End If
                        'lblUnitVal.Text = unit
                        'val1 = (usl1 - avg) / (3 * standev)
                        'val2 = (avg - lsl1) / (3 * standev)

                        'Dim Cpk As Double = 0.0
                        'Cpk = Math.Min(val1, val2)
                        'lblCpk.Text = Math.Round(Cpk, 3)
                        'Dim Cp As Double = 0.0
                        'Cp = ((yVal.Max() - yVal.Min()) / (6 * standev))
                        'lblCp.Text = Math.Round(Cp, 3)
                        'lblMean.Text = Math.Round(avg, 3)
                        If dtLimit.Rows.Count > 0 Then

                            'Commented by pratik said by Dinesh
                            'txtMin.Text = dtLimit.Rows(0)("LSL")
                            'txtMax.Text = dtLimit.Rows(0)("USL")
                            lblMin.Text = dtLimit.Rows(0)("LSL")
                            lblMax.Text = dtLimit.Rows(0)("USL")

                            objController.PlotLineChartForCRMDailyReportInFeGA(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                        Else
                            objController.PlotLineChartForCRMDailyReportInFeGA(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, 4500, 2000, avg, ucl, lcl, dtRemarks)
                        End If

                        'Dim query As String = "Select distinct PRM_TS_END as 'SAMPLING_DATE',PRM_ID_COIL,PRM_DS_ELEC_CUR as 'TEST_VALUE','' as 'PARAM_TEST','' as 'PROCESS_LINE',PRM_CD_GRADE as GRADE,PRM_TDC_NO as TDC_NO, PRM_CD_PROD as CD_PROD from T_CGL_FUR_PARAM where PRM_TS_END between '" & strfrmDt & "' and '" & strToDt & "' and  1=1 and PRM_DS_ELEC_CUR is not null and PRM_DS_ELEC_CUR > 0 "
                        Dim query As String = "Select distinct SAMPLING_DATE as 'SAMPLING_DATE',COIL_ID,TEST_VALUE as 'TEST_VALUE','' as 'PARAM_TEST','' as 'PROCESS_LINE',GRADE as GRADE,TDC_NO as TDC_NO, CD_PROD as CD_PROD from T_DM1 where PARAM_TEST = 'PRM_DS_ELEC_CUR' and SAMPLING_DATE between '" & strfrmDt & "' and '" & strToDt & "' and TEST_VALUE is not null and TEST_VALUE > 0 order by SAMPLING_DATE"
                        objController.PopulateDailyReportData(query, gvDetails)
                    Else
                        gvDetails.DataSource = Nothing
                        gvDetails.DataBind()
                    End If
                End If
                If ddlParamTest1.SelectedItem.Text.Trim = "ECL Tank Concentration" Then
                    Dim Filter1 As String = "  SAMPLING_DATE between '" & FromDt & "' and '" & ToDt & "' and PARAM_TEST = 'ALET' and PROCESS_LINE = 'L' "
                    'Session("Filter") = ""
                    'Session("Filter") = Filter1
                    'Dim dt1 As DataTable = objController.GetDataForCRMDailyReport("T_DM1", FromDt, ToDt, "SAMPLING_DATE", Filter1)
                    Dim dt1 As DataTable = objController.GetDataForCRMDailyReport("T_DM1", "SAMPLING_DATE", Filter1)
                    If dt1.Rows.Count > 0 Then
                        Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("ECL Tank Concentration")

                        Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(strfrmDt, strToDt, "ECL Tank Concentration")

                        CalculateCPK(dt1, "TEST_VALUE", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)

                        lblLCL.Text = Math.Round(lcl, 3)
                        lblUCL.Text = Math.Round(ucl, 3)
                        lblStddev.Text = Math.Round(standev, 3)
                        lblUnitVal.Text = unit
                        lblCpk.Text = Math.Round(Cpk1, 3)
                        lblCp.Text = Math.Round(Cp1, 3)
                        lblMean.Text = Math.Round(avg, 3)

                        'Dim yVal() As String
                        'yVal = (From row In dt1 Select col = row("TEST_VALUE").ToString).ToArray()

                        ''Commented by pratik said by Dinesh
                        ''lblMin.Text = yVal.Min()
                        ''lblMax.Text = yVal.Max()

                        'Dim sum As Integer = 0

                        'For j As Integer = 0 To dt1.Rows.Count - 1

                        '    sum = sum + dt1.Rows(j)("TEST_VALUE")

                        'Next
                        'avg = sum / dt1.Rows.Count

                        ''Commented by pratik said by Dinesh
                        ''lblAvg.Text = Math.Round(avg, 3)

                        'For k As Integer = 0 To dt1.Rows.Count - 1
                        '    standev += Pow(dt1.Rows(k)("TEST_VALUE") - avg, 2)
                        'Next
                        'standev = Math.Sqrt(standev / dt1.Rows.Count)

                        'lcl = avg - (3 * standev)
                        'ucl = avg + (3 * standev)
                        'lblLCL.Text = Math.Round(lcl, 3)
                        'lblUCL.Text = Math.Round(ucl, 3)
                        'lblStddev.Text = Math.Round(standev, 3)
                        'Dim val1 As Double = 0.0
                        'Dim val2 As Double = 0.0

                        ' ''Ádded on 25 may 2020
                        'Dim usl1, lsl1 As Double
                        'lsl1 = dtLimit.Rows(0)("LSL")
                        'usl1 = dtLimit.Rows(0)("USL")
                        'If IsDBNull(dtLimit.Rows(0)("Unit")) Then
                        '    unit = ""
                        'Else
                        '    unit = dtLimit.Rows(0)("Unit")
                        'End If
                        'lblUnitVal.Text = unit
                        'val1 = (usl1 - avg) / (3 * standev)
                        'val2 = (avg - lsl1) / (3 * standev)

                        'Dim Cpk As Double = 0.0
                        'Cpk = Math.Min(val1, val2)
                        'lblCpk.Text = Math.Round(Cpk, 3)
                        'Dim Cp As Double = 0.0
                        'Cp = ((yVal.Max() - yVal.Min()) / (6 * standev))
                        'lblCp.Text = Math.Round(Cp, 3)
                        'lblMean.Text = Math.Round(avg, 3)
                        If dtLimit.Rows.Count > 0 Then

                            'Commented by pratik said by Dinesh
                            'txtMin.Text = dtLimit.Rows(0)("LSL")
                            'txtMax.Text = dtLimit.Rows(0)("USL")
                            lblMin.Text = dtLimit.Rows(0)("LSL")
                            lblMax.Text = dtLimit.Rows(0)("USL")

                            objController.PlotLineChartForCRMDailyReportTDM(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                        Else
                            objController.PlotLineChartForCRMDailyReportTDM(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, 3.37, 1.8, avg, ucl, lcl, dtRemarks)
                        End If

                        Dim query As String = "select distinct SAMPLING_DATE as SAMPLING_DATE,TEST_VALUE as TEST_VALUE,PARAM_TEST as PARAM_TEST,PROCESS_LINE as PROCESS_LINE,GRADE as GRADE,TDC_NO as TDC_NO,CD_PROD as CD_PROD from T_DM1 where " & Filter1 & " and TEST_VALUE > 0 order by SAMPLING_DATE"
                        objController.PopulateDailyReportData(query, gvDetails)
                    Else
                        gvDetails.DataSource = Nothing
                        gvDetails.DataBind()
                    End If
                End If
                If ddlParamTest1.SelectedItem.Text.Trim = "Chromate Tank Concentration - Passerite" Then
                    Dim Filter1 As String = " PARAM_TEST = 'CRWT' and PROCESS_LINE = 'L' and CD_PROD = 'c10' "
                    Dim dt1 As DataTable = objController.GetDataForCRMDailyReport("T_DM1", FromDt, ToDt, "SAMPLING_DATE", Filter1)
                    If dt1.Rows.Count > 0 Then
                        Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("Chromate Tank Concentration - Passerite")

                        Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(strfrmDt, strToDt, "Chromate Tank Concentration - Passerite")

                        CalculateCPK(dt1, "TEST_VALUE", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)

                        lblLCL.Text = Math.Round(lcl, 3)
                        lblUCL.Text = Math.Round(ucl, 3)
                        lblStddev.Text = Math.Round(standev, 3)
                        lblUnitVal.Text = unit
                        lblCpk.Text = Math.Round(Cpk1, 3)
                        lblCp.Text = Math.Round(Cp1, 3)
                        lblMean.Text = Math.Round(avg, 3)

                        'Dim yVal() As String
                        'yVal = (From row In dt1 Select col = row("TEST_VALUE").ToString).ToArray()

                        ''Commented by pratik said by Dinesh
                        ''lblMin.Text = yVal.Min()
                        ''lblMax.Text = yVal.Max()

                        'Dim sum As Integer = 0

                        'For j As Integer = 0 To dt1.Rows.Count - 1

                        '    sum = sum + dt1.Rows(j)("TEST_VALUE")

                        'Next
                        'avg = sum / dt1.Rows.Count

                        ''Commented by pratik said by Dinesh
                        ''lblAvg.Text = Math.Round(avg, 3)

                        'For k As Integer = 0 To dt1.Rows.Count - 1
                        '    standev += Pow(dt1.Rows(k)("TEST_VALUE") - avg, 2)
                        'Next
                        'standev = Math.Sqrt(standev / dt1.Rows.Count)

                        'lcl = avg - (3 * standev)
                        'ucl = avg + (3 * standev)
                        'lblLCL.Text = Math.Round(lcl, 3)
                        'lblUCL.Text = Math.Round(ucl, 3)
                        'lblStddev.Text = Math.Round(standev, 3)
                        'Dim val1 As Double = 0.0
                        'Dim val2 As Double = 0.0

                        ' ''Ádded on 25 may 2020
                        'Dim usl1, lsl1 As Double
                        'lsl1 = dtLimit.Rows(0)("LSL")
                        'usl1 = dtLimit.Rows(0)("USL")
                        'If IsDBNull(dtLimit.Rows(0)("Unit")) Then
                        '    unit = ""
                        'Else
                        '    unit = dtLimit.Rows(0)("Unit")
                        'End If
                        'lblUnitVal.Text = unit
                        'val1 = (usl1 - avg) / (3 * standev)
                        'val2 = (avg - lsl1) / (3 * standev)

                        'Dim Cpk As Double = 0.0
                        'Cpk = Math.Min(val1, val2)
                        'lblCpk.Text = Math.Round(Cpk, 3)
                        'Dim Cp As Double = 0.0
                        'Cp = ((yVal.Max() - yVal.Min()) / (6 * standev))
                        'lblCp.Text = Math.Round(Cp, 3)
                        'lblMean.Text = Math.Round(avg, 3)
                        If dtLimit.Rows.Count > 0 Then

                            'Commented by pratik said by Dinesh
                            'txtMin.Text = dtLimit.Rows(0)("LSL")
                            'txtMax.Text = dtLimit.Rows(0)("USL")
                            lblMin.Text = dtLimit.Rows(0)("LSL")
                            lblMax.Text = dtLimit.Rows(0)("USL")

                            objController.PlotLineChartForCRMDailyReportTDM(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                        Else
                            objController.PlotLineChartForCRMDailyReportTDM(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, 70, 40, avg, ucl, lcl, dtRemarks)
                        End If

                        Dim query As String = "select distinct SAMPLING_DATE as SAMPLING_DATE,TEST_VALUE as TEST_VALUE,PARAM_TEST as PARAM_TEST,PROCESS_LINE as PROCESS_LINE,GRADE as GRADE,TDC_NO as TDC_NO,CD_PROD as CD_PROD from T_DM1 where SAMPLING_DATE between '" & FromDt & "' and '" & ToDt & "' and " & Filter1 & " and TEST_VALUE > 0 order by SAMPLING_DATE"
                        objController.PopulateDailyReportData(query, gvDetails)
                    Else
                        gvDetails.DataSource = Nothing
                        gvDetails.DataBind()
                    End If
                End If
                If ddlParamTest1.SelectedItem.Text.Trim = "Chromate Tank Concentration - Galvaguard" Then
                    Dim Filter1 As String = " PARAM_TEST = 'CRWT' and PROCESS_LINE = 'L' and CD_PROD = 'c03' and TDC_NO in ('GA14','GAF3','GA04','GA15') "
                    Dim dt1 As DataTable = objController.GetDataForCRMDailyReport("T_DM1", FromDt, ToDt, "SAMPLING_DATE", Filter1)
                    If dt1.Rows.Count > 0 Then
                        Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("Chromate Tank Concentration - Galvaguard")

                        Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(strfrmDt, strToDt, "Chromate Tank Concentration - Galvaguard")

                        CalculateCPK(dt1, "TEST_VALUE", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)

                        lblLCL.Text = Math.Round(lcl, 3)
                        lblUCL.Text = Math.Round(ucl, 3)
                        lblStddev.Text = Math.Round(standev, 3)
                        lblUnitVal.Text = unit
                        lblCpk.Text = Math.Round(Cpk1, 3)
                        lblCp.Text = Math.Round(Cp1, 3)
                        lblMean.Text = Math.Round(avg, 3)
                        

                        'Dim yVal() As String
                        'yVal = (From row In dt1 Select col = row("TEST_VALUE").ToString).ToArray()

                        ''Commented by pratik said by Dinesh
                        ''lblMin.Text = yVal.Min()
                        ''lblMax.Text = yVal.Max()

                        'Dim sum As Integer = 0

                        'For j As Integer = 0 To dt1.Rows.Count - 1

                        '    sum = sum + dt1.Rows(j)("TEST_VALUE")

                        'Next
                        'avg = sum / dt1.Rows.Count

                        ''Commented by pratik said by Dinesh
                        ''lblAvg.Text = Math.Round(avg, 3)

                        'For k As Integer = 0 To dt1.Rows.Count - 1
                        '    standev += Pow(dt1.Rows(k)("TEST_VALUE") - avg, 2)
                        'Next
                        'standev = Math.Sqrt(standev / dt1.Rows.Count)

                        'lcl = avg - (3 * standev)
                        'ucl = avg + (3 * standev)
                        'lblLCL.Text = Math.Round(lcl, 3)
                        'lblUCL.Text = Math.Round(ucl, 3)
                        'lblStddev.Text = Math.Round(standev, 3)
                        'Dim val1 As Double = 0.0
                        'Dim val2 As Double = 0.0
                        ' ''Ádded on 25 may 2020
                        'Dim usl1, lsl1 As Double
                        'lsl1 = dtLimit.Rows(0)("LSL")
                        'usl1 = dtLimit.Rows(0)("USL")
                        'If IsDBNull(dtLimit.Rows(0)("Unit")) Then
                        '    unit = ""
                        'Else
                        '    unit = dtLimit.Rows(0)("Unit")
                        'End If
                        'lblUnitVal.Text = unit

                        'val1 = (usl1 - avg) / (3 * standev)
                        'val2 = (avg - lsl1) / (3 * standev)

                        'Dim Cpk As Double = 0.0
                        'Cpk = Math.Min(val1, val2)
                        'lblCpk.Text = Math.Round(Cpk, 3)
                        'Dim Cp As Double = 0.0
                        'Cp = ((yVal.Max() - yVal.Min()) / (6 * standev))
                        'lblCp.Text = Math.Round(Cp, 3)
                        'lblMean.Text = Math.Round(avg, 3)
                        If dtLimit.Rows.Count > 0 Then

                            'Commented by pratik said by Dinesh
                            'txtMin.Text = dtLimit.Rows(0)("LSL")
                            'txtMax.Text = dtLimit.Rows(0)("USL")
                            lblMin.Text = dtLimit.Rows(0)("LSL")
                            lblMax.Text = dtLimit.Rows(0)("USL")

                            objController.PlotLineChartForCRMDailyReportTDM(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                        Else
                            objController.PlotLineChartForCRMDailyReportTDM(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, 70, 55, avg, ucl, lcl, dtRemarks)
                        End If

                        Dim query As String = "select distinct SAMPLING_DATE as SAMPLING_DATE,TEST_VALUE as TEST_VALUE,PARAM_TEST as PARAM_TEST,PROCESS_LINE as PROCESS_LINE,GRADE as GRADE,TDC_NO as TDC_NO,CD_PROD as CD_PROD from T_DM1 where SAMPLING_DATE between '" & FromDt & "' and '" & ToDt & "' and " & Filter1 & " and TEST_VALUE > 0 order by SAMPLING_DATE"
                        objController.PopulateDailyReportData(query, gvDetails)
                    Else
                        gvDetails.DataSource = Nothing
                        gvDetails.DataBind()
                    End If
                End If
                If ddlParamTest1.SelectedItem.Text.Trim = "Sheet Chromium Fuel tank" Then
                    Dim Filter1 As String = " PARAM_TEST = 'SHCR' and PROCESS_LINE = 'L' and CD_PROD = 'c03' and TDC_NO in ('GA14','GAF3','GA04','GA15') "
                    Dim dt1 As DataTable = objController.GetDataForCRMDailyReport("T_DM1", FromDt, ToDt, "SAMPLING_DATE", Filter1)
                    If dt1.Rows.Count > 0 Then
                        Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("Sheet Chromium Fuel tank")

                        Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(strfrmDt, strToDt, "Sheet Chromium Fuel tank")

                        CalculateCPK(dt1, "TEST_VALUE", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)

                        lblLCL.Text = Math.Round(lcl, 3)
                        lblUCL.Text = Math.Round(ucl, 3)
                        lblStddev.Text = Math.Round(standev, 3)
                        lblUnitVal.Text = unit
                        lblCpk.Text = Math.Round(Cpk1, 3)
                        lblCp.Text = Math.Round(Cp1, 3)
                        lblMean.Text = Math.Round(avg, 3)


                        'Dim yVal() As String
                        'yVal = (From row In dt1 Select col = row("TEST_VALUE").ToString).ToArray()

                        ''Commented by pratik said by Dinesh
                        ''lblMin.Text = yVal.Min()
                        ''lblMax.Text = yVal.Max()

                        'Dim sum As Integer = 0

                        'For j As Integer = 0 To dt1.Rows.Count - 1

                        '    sum = sum + dt1.Rows(j)("TEST_VALUE")

                        'Next
                        'avg = sum / dt1.Rows.Count

                        ''Commented by pratik said by Dinesh
                        ''lblAvg.Text = Math.Round(avg, 3)

                        'For k As Integer = 0 To dt1.Rows.Count - 1
                        '    standev += Pow(dt1.Rows(k)("TEST_VALUE") - avg, 2)
                        'Next
                        'standev = Math.Sqrt(standev / dt1.Rows.Count)

                        'lcl = avg - (3 * standev)
                        'ucl = avg + (3 * standev)
                        'lblLCL.Text = Math.Round(lcl, 3)
                        'lblUCL.Text = Math.Round(ucl, 3)
                        'lblStddev.Text = Math.Round(standev, 3)
                        'Dim val1 As Double = 0.0
                        'Dim val2 As Double = 0.0

                        ' ''Ádded on 25 may 2020
                        'Dim usl1, lsl1 As Double
                        'lsl1 = dtLimit.Rows(0)("LSL")
                        'usl1 = dtLimit.Rows(0)("USL")
                        'If IsDBNull(dtLimit.Rows(0)("Unit")) Then
                        '    unit = ""
                        'Else
                        '    unit = dtLimit.Rows(0)("Unit")
                        'End If
                        'lblUnitVal.Text = unit
                        'val1 = (usl1 - avg) / (3 * standev)
                        'val2 = (avg - lsl1) / (3 * standev)

                        'Dim Cpk As Double = 0.0
                        'Cpk = Math.Min(val1, val2)
                        'lblCpk.Text = Math.Round(Cpk, 3)
                        'Dim Cp As Double = 0.0
                        'Cp = ((yVal.Max() - yVal.Min()) / (6 * standev))
                        'lblCp.Text = Math.Round(Cp, 3)
                        'lblMean.Text = Math.Round(avg, 3)
                        If dtLimit.Rows.Count > 0 Then

                            'Commented by pratik said by Dinesh
                            'txtMin.Text = dtLimit.Rows(0)("LSL")
                            'txtMax.Text = dtLimit.Rows(0)("USL")
                            lblMin.Text = dtLimit.Rows(0)("LSL")
                            lblMax.Text = dtLimit.Rows(0)("USL")

                            objController.PlotLineChartForCRMDailyReportTDM(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                        Else
                            objController.PlotLineChartForCRMDailyReportTDM(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, 80, 50, avg, ucl, lcl, dtRemarks)
                        End If

                        Dim query As String = "select distinct SAMPLING_DATE as SAMPLING_DATE,TEST_VALUE as TEST_VALUE,PARAM_TEST as PARAM_TEST,PROCESS_LINE as PROCESS_LINE,GRADE as GRADE,TDC_NO as TDC_NO,CD_PROD as CD_PROD from T_DM1 where SAMPLING_DATE between '" & FromDt & "' and '" & ToDt & "' and " & Filter1 & " and TEST_VALUE > 0 order by SAMPLING_DATE"
                        objController.PopulateDailyReportData(query, gvDetails)
                    Else
                        gvDetails.DataSource = Nothing
                        gvDetails.DataBind()
                    End If
                End If
                If ddlParamTest1.SelectedItem.Text.Trim = "Sheet Chromium ZS Coils" Then
                    Dim Filter1 As String = " PARAM_TEST = 'SHCR' and PROCESS_LINE = 'L' and CD_PROD = 'c10' "
                    Dim dt1 As DataTable = objController.GetDataForCRMDailyReport("T_DM1", FromDt, ToDt, "SAMPLING_DATE", Filter1)
                    If dt1.Rows.Count > 0 Then
                        Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("Sheet Chromium ZS Coils")

                        Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(strfrmDt, strToDt, "Sheet Chromium ZS Coils")

                        CalculateCPK(dt1, "TEST_VALUE", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)

                        lblLCL.Text = Math.Round(lcl, 3)
                        lblUCL.Text = Math.Round(ucl, 3)
                        lblStddev.Text = Math.Round(standev, 3)
                        lblUnitVal.Text = unit
                        lblCpk.Text = Math.Round(Cpk1, 3)
                        lblCp.Text = Math.Round(Cp1, 3)
                        lblMean.Text = Math.Round(avg, 3)


                        'Dim yVal() As String
                        'yVal = (From row In dt1 Select col = row("TEST_VALUE").ToString).ToArray()

                        ''Commented by pratik said by Dinesh
                        ''lblMin.Text = yVal.Min()
                        ''lblMax.Text = yVal.Max()

                        'Dim sum As Integer = 0

                        'For j As Integer = 0 To dt1.Rows.Count - 1

                        '    sum = sum + dt1.Rows(j)("TEST_VALUE")

                        'Next
                        'avg = sum / dt1.Rows.Count

                        ''Commented by pratik said by Dinesh
                        ''lblAvg.Text = Math.Round(avg, 3)

                        'For k As Integer = 0 To dt1.Rows.Count - 1
                        '    standev += Pow(dt1.Rows(k)("TEST_VALUE") - avg, 2)
                        'Next
                        'standev = Math.Sqrt(standev / dt1.Rows.Count)

                        'lcl = avg - (3 * standev)
                        'ucl = avg + (3 * standev)
                        'lblLCL.Text = Math.Round(lcl, 3)
                        'lblUCL.Text = Math.Round(ucl, 3)
                        'lblStddev.Text = Math.Round(standev, 3)
                        'Dim val1 As Double = 0.0
                        'Dim val2 As Double = 0.0

                        ' ''Ádded on 25 may 2020
                        'Dim usl1, lsl1 As Double
                        'lsl1 = dtLimit.Rows(0)("LSL")
                        'usl1 = dtLimit.Rows(0)("USL")
                        'If IsDBNull(dtLimit.Rows(0)("Unit")) Then
                        '    unit = ""
                        'Else
                        '    unit = dtLimit.Rows(0)("Unit")
                        'End If
                        'lblUnitVal.Text = unit
                        'val1 = (usl1 - avg) / (3 * standev)
                        'val2 = (avg - lsl1) / (3 * standev)

                        'Dim Cpk As Double = 0.0
                        'Cpk = Math.Min(val1, val2)
                        'lblCpk.Text = Math.Round(Cpk, 3)
                        'Dim Cp As Double = 0.0
                        'Cp = ((yVal.Max() - yVal.Min()) / (6 * standev))
                        'lblCp.Text = Math.Round(Cp, 3)
                        'lblMean.Text = Math.Round(avg, 3)
                        If dtLimit.Rows.Count > 0 Then

                            'Commented by pratik said by Dinesh
                            'txtMin.Text = dtLimit.Rows(0)("LSL")
                            'txtMax.Text = dtLimit.Rows(0)("USL")
                            lblMin.Text = dtLimit.Rows(0)("LSL")
                            lblMax.Text = dtLimit.Rows(0)("USL")

                            objController.PlotLineChartForCRMDailyReportTDM(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                        Else
                            objController.PlotLineChartForCRMDailyReportTDM(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, 100, 60, avg, ucl, lcl, dtRemarks)
                        End If

                        Dim query As String = "select distinct SAMPLING_DATE as SAMPLING_DATE,TEST_VALUE as TEST_VALUE,PARAM_TEST as PARAM_TEST,PROCESS_LINE as PROCESS_LINE,GRADE as GRADE,TDC_NO as TDC_NO,CD_PROD as CD_PROD from T_DM1 where SAMPLING_DATE between '" & FromDt & "' and '" & ToDt & "' and " & Filter1 & " and TEST_VALUE > 0 order by SAMPLING_DATE"
                        objController.PopulateDailyReportData(query, gvDetails)
                    Else
                        gvDetails.DataSource = Nothing
                        gvDetails.DataBind()
                    End If
                End If
                If ddlParamTest1.SelectedItem.Text.Trim = "Pre Degreasing Conc L" Then
                    Dim Filter1 As String = " PARAM_TEST = 'ALPT' and PROCESS_LINE in ('L') "
                    Dim dt1 As DataTable = objController.GetDataForCRMDailyReport("T_DM1", FromDt, ToDt, "SAMPLING_DATE", Filter1)
                    If dt1.Rows.Count > 0 Then
                        Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("Pre Degreasing Conc")

                        Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(strfrmDt, strToDt, "Pre Degreasing Conc L")

                        CalculateCPK(dt1, "TEST_VALUE", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)

                        lblLCL.Text = Math.Round(lcl, 3)
                        lblUCL.Text = Math.Round(ucl, 3)
                        lblStddev.Text = Math.Round(standev, 3)
                        lblUnitVal.Text = unit
                        lblCpk.Text = Math.Round(Cpk1, 3)
                        lblCp.Text = Math.Round(Cp1, 3)
                        lblMean.Text = Math.Round(avg, 3)


                        'Dim yVal() As String
                        'yVal = (From row In dt1 Select col = row("TEST_VALUE").ToString).ToArray()

                        ''Commented by pratik said by Dinesh
                        ''lblMin.Text = yVal.Min()
                        ''lblMax.Text = yVal.Max()

                        'Dim sum As Integer = 0

                        'For j As Integer = 0 To dt1.Rows.Count - 1

                        '    sum = sum + dt1.Rows(j)("TEST_VALUE")

                        'Next
                        'avg = sum / dt1.Rows.Count

                        ''Commented by pratik said by Dinesh
                        ''lblAvg.Text = Math.Round(avg, 3)

                        'For k As Integer = 0 To dt1.Rows.Count - 1
                        '    standev += Pow(dt1.Rows(k)("TEST_VALUE") - avg, 2)
                        'Next
                        'standev = Math.Sqrt(standev / dt1.Rows.Count)

                        'lcl = avg - (3 * standev)
                        'ucl = avg + (3 * standev)
                        'lblLCL.Text = Math.Round(lcl, 3)
                        'lblUCL.Text = Math.Round(ucl, 3)
                        'lblStddev.Text = Math.Round(standev, 3)
                        'Dim val1 As Double = 0.0
                        'Dim val2 As Double = 0.0

                        ' ''Ádded on 25 may 2020
                        'Dim usl1, lsl1 As Double
                        'lsl1 = dtLimit.Rows(0)("LSL")
                        'usl1 = dtLimit.Rows(0)("USL")
                        'If IsDBNull(dtLimit.Rows(0)("Unit")) Then
                        '    unit = ""
                        'Else
                        '    unit = dtLimit.Rows(0)("Unit")
                        'End If
                        'lblUnitVal.Text = unit
                        'val1 = (usl1 - avg) / (3 * standev)
                        'val2 = (avg - lsl1) / (3 * standev)

                        'Dim Cpk As Double = 0.0
                        'Cpk = Math.Min(val1, val2)
                        'lblCpk.Text = Math.Round(Cpk, 3)
                        'Dim Cp As Double = 0.0
                        'Cp = ((yVal.Max() - yVal.Min()) / (6 * standev))
                        'lblCp.Text = Math.Round(Cp, 3)
                        'lblMean.Text = Math.Round(avg, 3)
                        If dtLimit.Rows.Count > 0 Then

                            'Commented by pratik said by Dinesh
                            'txtMin.Text = dtLimit.Rows(0)("LSL")
                            'txtMax.Text = dtLimit.Rows(0)("USL")
                            lblMin.Text = dtLimit.Rows(0)("LSL")
                            lblMax.Text = dtLimit.Rows(0)("USL")

                            objController.PlotLineChartForCRMDailyReportTDM(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                        Else
                            objController.PlotLineChartForCRMDailyReportTDM(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, 3.43, 1.59, avg, ucl, lcl, dtRemarks)
                        End If

                        Dim query As String = "select distinct SAMPLING_DATE as SAMPLING_DATE,TEST_VALUE as TEST_VALUE,PARAM_TEST as PARAM_TEST,PROCESS_LINE as PROCESS_LINE,GRADE as GRADE,TDC_NO as TDC_NO,CD_PROD as CD_PROD from T_DM1 where SAMPLING_DATE between '" & FromDt & "' and '" & ToDt & "' and " & Filter1 & " and TEST_VALUE > 0 order by SAMPLING_DATE"
                        objController.PopulateDailyReportData(query, gvDetails)
                    Else
                        gvDetails.DataSource = Nothing
                        gvDetails.DataBind()
                    End If
                End If
                If ddlParamTest1.SelectedItem.Text.Trim = "Pre Degreasing Conc G" Then
                    Dim Filter1 As String = " PARAM_TEST = 'ALPT' and PROCESS_LINE in ('G') "
                    Dim dt1 As DataTable = objController.GetDataForCRMDailyReport("T_DM1", FromDt, ToDt, "SAMPLING_DATE", Filter1)
                    If dt1.Rows.Count > 0 Then
                        Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("Pre Degreasing Conc")

                        Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(strfrmDt, strToDt, "Pre Degreasing Conc G")

                        CalculateCPK(dt1, "TEST_VALUE", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)

                        lblLCL.Text = Math.Round(lcl, 3)
                        lblUCL.Text = Math.Round(ucl, 3)
                        lblStddev.Text = Math.Round(standev, 3)
                        lblUnitVal.Text = unit
                        lblCpk.Text = Math.Round(Cpk1, 3)
                        lblCp.Text = Math.Round(Cp1, 3)
                        lblMean.Text = Math.Round(avg, 3)


                        'Dim yVal() As String
                        'yVal = (From row In dt1 Select col = row("TEST_VALUE").ToString).ToArray()

                        ''Commented by pratik said by Dinesh
                        ''lblMin.Text = yVal.Min()
                        ''lblMax.Text = yVal.Max()

                        'Dim sum As Integer = 0

                        'For j As Integer = 0 To dt1.Rows.Count - 1

                        '    sum = sum + dt1.Rows(j)("TEST_VALUE")

                        'Next
                        'avg = sum / dt1.Rows.Count

                        ''Commented by pratik said by Dinesh
                        ''lblAvg.Text = Math.Round(avg, 3)

                        'For k As Integer = 0 To dt1.Rows.Count - 1
                        '    standev += Pow(dt1.Rows(k)("TEST_VALUE") - avg, 2)
                        'Next
                        'standev = Math.Sqrt(standev / dt1.Rows.Count)

                        'lcl = avg - (3 * standev)
                        'ucl = avg + (3 * standev)
                        'lblLCL.Text = Math.Round(lcl, 3)
                        'lblUCL.Text = Math.Round(ucl, 3)
                        'lblStddev.Text = Math.Round(standev, 3)
                        'Dim val1 As Double = 0.0
                        'Dim val2 As Double = 0.0

                        ' ''Ádded on 25 may 2020
                        'Dim usl1, lsl1 As Double
                        'lsl1 = dtLimit.Rows(0)("LSL")
                        'usl1 = dtLimit.Rows(0)("USL")
                        'If IsDBNull(dtLimit.Rows(0)("Unit")) Then
                        '    unit = ""
                        'Else
                        '    unit = dtLimit.Rows(0)("Unit")
                        'End If
                        'lblUnitVal.Text = unit
                        'val1 = (usl1 - avg) / (3 * standev)
                        'val2 = (avg - lsl1) / (3 * standev)

                        'Dim Cpk As Double = 0.0
                        'Cpk = Math.Min(val1, val2)
                        'lblCpk.Text = Math.Round(Cpk, 3)
                        'Dim Cp As Double = 0.0
                        'Cp = ((yVal.Max() - yVal.Min()) / (6 * standev))
                        'lblCp.Text = Math.Round(Cp, 3)
                        'lblMean.Text = Math.Round(avg, 3)
                        If dtLimit.Rows.Count > 0 Then

                            'Commented by pratik said by Dinesh
                            'txtMin.Text = dtLimit.Rows(0)("LSL")
                            'txtMax.Text = dtLimit.Rows(0)("USL")
                            lblMin.Text = dtLimit.Rows(0)("LSL")
                            lblMax.Text = dtLimit.Rows(0)("USL")

                            objController.PlotLineChartForCRMDailyReportTDM(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                        Else
                            objController.PlotLineChartForCRMDailyReportTDM(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, 3.43, 1.59, avg, ucl, lcl, dtRemarks)
                        End If

                        Dim query As String = "select distinct SAMPLING_DATE as SAMPLING_DATE,TEST_VALUE as TEST_VALUE,PARAM_TEST as PARAM_TEST,PROCESS_LINE as PROCESS_LINE,GRADE as GRADE,TDC_NO as TDC_NO,CD_PROD as CD_PROD from T_DM1 where SAMPLING_DATE between '" & FromDt & "' and '" & ToDt & "' and " & Filter1 & " and TEST_VALUE > 0 order by SAMPLING_DATE"
                        objController.PopulateDailyReportData(query, gvDetails)
                    Else
                        gvDetails.DataSource = Nothing
                        gvDetails.DataBind()
                    End If
                End If

                If ddlParamTest1.SelectedItem.Text.Trim = "ECL Temperature" Then
                    'Dim dt1 As DataTable = objController.GetDataForCRMDailyReportInFeGA("T_CGL_FUR_PARAM", strfrmDt, strToDt, "PRM_TS_END", ColumnName, Filter)
                    Dim dt1 As DataTable = objController.GetDataForCRMDailyReportNew("T_DM1", strfrmDt, strToDt, "PRM_DS_ELEC_TMP", Filter)
                    If dt1.Rows.Count > 0 Then
                        Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("ECL Temperature")

                        Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(strfrmDt, strToDt, "ECL Temperature")

                        CalculateCPK(dt1, "TEST_VALUE", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)

                        lblLCL.Text = Math.Round(lcl, 3)
                        lblUCL.Text = Math.Round(ucl, 3)
                        lblStddev.Text = Math.Round(standev, 3)
                        lblUnitVal.Text = unit
                        lblCpk.Text = Math.Round(Cpk1, 3)
                        lblCp.Text = Math.Round(Cp1, 3)
                        lblMean.Text = Math.Round(avg, 3)

                        'Dim yVal() As String
                        'yVal = (From row In dt1 Select col = row("PRM_TEST_VALUE_FEGA").ToString).ToArray()

                        ''Commented by pratik said by Dinesh
                        ''lblMin.Text = yVal.Min()
                        ''lblMax.Text = yVal.Max()

                        'Dim sum As Integer = 0

                        'For j As Integer = 0 To dt1.Rows.Count - 1

                        '    sum = sum + dt1.Rows(j)("PRM_TEST_VALUE_FEGA")

                        'Next
                        'avg = sum / dt1.Rows.Count

                        ''Commented by pratik said by Dinesh
                        ''lblAvg.Text = Math.Round(avg, 3)

                        'For k As Integer = 0 To dt1.Rows.Count - 1
                        '    standev += Pow(dt1.Rows(k)("PRM_TEST_VALUE_FEGA") - avg, 2)
                        'Next
                        'standev = Math.Sqrt(standev / dt1.Rows.Count)

                        'lcl = avg - (3 * standev)
                        'ucl = avg + (3 * standev)
                        'lblLCL.Text = Math.Round(lcl, 3)
                        'lblUCL.Text = Math.Round(ucl, 3)
                        'lblStddev.Text = Math.Round(standev, 3)
                        'Dim val1 As Double = 0.0
                        'Dim val2 As Double = 0.0

                        ' ''Ádded on 25 may 2020
                        'Dim usl1, lsl1 As Double
                        'lsl1 = dtLimit.Rows(0)("LSL")
                        'usl1 = dtLimit.Rows(0)("USL")
                        'If IsDBNull(dtLimit.Rows(0)("Unit")) Then
                        '    unit = ""
                        'Else
                        '    unit = dtLimit.Rows(0)("Unit")
                        'End If
                        'lblUnitVal.Text = unit
                        'val1 = (usl1 - avg) / (3 * standev)
                        'val2 = (avg - lsl1) / (3 * standev)

                        'Dim Cpk As Double = 0.0
                        'Cpk = Math.Min(val1, val2)
                        'lblCpk.Text = Math.Round(Cpk, 3)
                        'Dim Cp As Double = 0.0
                        'Cp = ((yVal.Max() - yVal.Min()) / (6 * standev))
                        'lblCp.Text = Math.Round(Cp, 3)
                        'lblMean.Text = Math.Round(avg, 3)
                        If dtLimit.Rows.Count > 0 Then

                            'Commented by pratik said by Dinesh
                            'txtMin.Text = dtLimit.Rows(0)("LSL")
                            'txtMax.Text = dtLimit.Rows(0)("USL")
                            lblMin.Text = dtLimit.Rows(0)("LSL")
                            lblMax.Text = dtLimit.Rows(0)("USL")

                            objController.PlotLineChartForCRMDailyReportInFeGA(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                        Else
                            objController.PlotLineChartForCRMDailyReportInFeGA(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, 80, 60, avg, ucl, lcl, dtRemarks)
                        End If

                        'Dim query As String = "Select distinct PRM_TS_END as 'SAMPLING_DATE',PRM_ID_COIL,PRM_DS_ELEC_TMP as 'TEST_VALUE','' as 'PARAM_TEST','' as 'PROCESS_LINE',PRM_CD_GRADE as GRADE,PRM_TDC_NO as TDC_NO, PRM_CD_PROD as CD_PROD from T_CGL_FUR_PARAM where PRM_TS_END between '" & strfrmDt & "' and '" & strToDt & "' and  1=1 and PRM_DS_ELEC_TMP is not null and PRM_DS_ELEC_TMP > 0 "
                        Dim query As String = "Select distinct SAMPLING_DATE as 'SAMPLING_DATE',COIL_ID,TEST_VALUE as 'TEST_VALUE','' as 'PARAM_TEST','' as 'PROCESS_LINE',GRADE as GRADE,TDC_NO as TDC_NO, CD_PROD as CD_PROD from T_DM1 where PARAM_TEST = 'PRM_DS_ELEC_TMP' and SAMPLING_DATE between '" & strfrmDt & "' and '" & strToDt & "' and TEST_VALUE is not null and TEST_VALUE > 0 order by SAMPLING_DATE"
                        objController.PopulateDailyReportData(query, gvDetails)

                    Else
                        gvDetails.DataSource = Nothing
                        gvDetails.DataBind()
                    End If
                End If

                If ddlParamTest1.SelectedItem.Text.Trim = "Coating Weight_GA Fuel Tank_Top" Then
                    Filter &= " and TDC_NO in('GA14', 'GAF3', 'GA04', 'GA15')"
                    'Dim dt1 As DataTable = objController.GetDataForCRMDailyReportInTank("T_CGL_FUR_PARAM", strfrmDt, strToDt, "PRM_TS_END", ColumnName, Filter)
                    Dim dt1 As DataTable = objController.GetDataForCRMDailyReportNew("T_DM1", strfrmDt, strToDt, "PRM_TTC_AVG", Filter)
                    If dt1.Rows.Count > 0 Then
                        Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("Coating Weight_GA Fuel Tank_Top")

                        Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(strfrmDt, strToDt, "Coating Weight_GA Fuel Tank_Top")

                        CalculateCPK(dt1, "TEST_VALUE", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)

                        lblLCL.Text = Math.Round(lcl, 3)
                        lblUCL.Text = Math.Round(ucl, 3)
                        lblStddev.Text = Math.Round(standev, 3)
                        lblUnitVal.Text = unit
                        lblCpk.Text = Math.Round(Cpk1, 3)
                        lblCp.Text = Math.Round(Cp1, 3)
                        lblMean.Text = Math.Round(avg, 3)

                        'Dim yVal() As String
                        'yVal = (From row In dt1 Select col = row("PRM_TEST_VALUE_FEGA").ToString).ToArray()

                        ''Commented by pratik said by Dinesh
                        ''lblMin.Text = yVal.Min()
                        ''lblMax.Text = yVal.Max()

                        'Dim sum As Integer = 0

                        'For j As Integer = 0 To dt1.Rows.Count - 1

                        '    sum = sum + dt1.Rows(j)("PRM_TEST_VALUE_FEGA")

                        'Next
                        'avg = sum / dt1.Rows.Count

                        ''Commented by pratik said by Dinesh
                        ''lblAvg.Text = Math.Round(avg, 3)

                        'For k As Integer = 0 To dt1.Rows.Count - 1
                        '    standev += Pow(dt1.Rows(k)("PRM_TEST_VALUE_FEGA") - avg, 2)
                        'Next
                        'standev = Math.Sqrt(standev / dt1.Rows.Count)

                        'lcl = avg - (3 * standev)
                        'ucl = avg + (3 * standev)
                        'lblLCL.Text = Math.Round(lcl, 3)
                        'lblUCL.Text = Math.Round(ucl, 3)
                        'lblStddev.Text = Math.Round(standev, 3)
                        'Dim val1 As Double = 0.0
                        'Dim val2 As Double = 0.0

                        ' ''Ádded on 25 may 2020
                        'Dim usl1, lsl1 As Double
                        'lsl1 = dtLimit.Rows(0)("LSL")
                        'usl1 = dtLimit.Rows(0)("USL")
                        'If IsDBNull(dtLimit.Rows(0)("Unit")) Then
                        '    unit = ""
                        'Else
                        '    unit = dtLimit.Rows(0)("Unit")
                        'End If
                        'lblUnitVal.Text = unit
                        'val1 = (usl1 - avg) / (3 * standev)
                        'val2 = (avg - lsl1) / (3 * standev)

                        'Dim Cpk As Double = 0.0
                        'Cpk = Math.Min(val1, val2)
                        'lblCpk.Text = Math.Round(Cpk, 3)
                        'Dim Cp As Double = 0.0
                        'Cp = ((yVal.Max() - yVal.Min()) / (6 * standev))
                        'lblCp.Text = Math.Round(Cp, 3)
                        'lblMean.Text = Math.Round(avg, 3)
                        If dtLimit.Rows.Count > 0 Then

                            'Commented by pratik said by Dinesh
                            'txtMin.Text = dtLimit.Rows(0)("LSL")
                            'txtMax.Text = dtLimit.Rows(0)("USL")
                            lblMin.Text = dtLimit.Rows(0)("LSL")
                            lblMax.Text = dtLimit.Rows(0)("USL")

                            objController.PlotLineChartForCRMDailyReportInFeGA(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                        Else
                            objController.PlotLineChartForCRMDailyReportInFeGA(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, 37, 30, avg, ucl, lcl, dtRemarks)
                        End If

                        'Dim query As String = "Select distinct PRM_TS_END as 'SAMPLING_DATE',PRM_ID_COIL,PRM_TTC_AVG as 'TEST_VALUE','' as 'PARAM_TEST','' as 'PROCESS_LINE',PRM_CD_GRADE as GRADE,PRM_TDC_NO as TDC_NO, PRM_CD_PROD as CD_PROD from T_CGL_FUR_PARAM where PRM_TS_END between '" & strfrmDt & "' and '" & strToDt & "' and  1=1 and PRM_TTC_AVG is not null and PRM_TTC_AVG > 0 and PRM_TDC_ACTL in('GA14', 'GAF3', 'GA04', 'GA15')"
                        Dim query As String = "Select distinct SAMPLING_DATE as 'SAMPLING_DATE',COIL_ID,TEST_VALUE as 'TEST_VALUE','' as 'PARAM_TEST','' as 'PROCESS_LINE',GRADE as GRADE,TDC_NO as TDC_NO, CD_PROD as CD_PROD from T_DM1 where PARAM_TEST = 'PRM_TTC_AVG' and SAMPLING_DATE between '" & strfrmDt & "' and '" & strToDt & "' and TDC_NO in('GA14', 'GAF3', 'GA04', 'GA15') and TEST_VALUE is not null and TEST_VALUE > 0 order by SAMPLING_DATE"
                        objController.PopulateDailyReportData(query, gvDetails)

                    Else
                        gvDetails.DataSource = Nothing
                        gvDetails.DataBind()
                    End If
                End If


                If ddlParamTest1.SelectedItem.Text.Trim = "Coating Weight_GA Fuel Tank_BOTTOM" Then

                    Filter &= " and TDC_NO in('GA14', 'GAF3', 'GA04', 'GA15')"
                
                'Dim dt1 As DataTable = objController.GetDataForCRMDailyReportInTank("T_CGL_FUR_PARAM", strfrmDt, strToDt, "PRM_TS_END", ColumnName, Filter)
                Dim dt1 As DataTable = objController.GetDataForCRMDailyReportNew("T_DM1", strfrmDt, strToDt, "PRM_BTC_AVG", Filter)
                If dt1.Rows.Count > 0 Then
                    Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("Coating Weight_GA Fuel Tank_BOTTOM")

                    Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(strfrmDt, strToDt, "Coating Weight_GA Fuel Tank_BOTTOM")

                    CalculateCPK(dt1, "TEST_VALUE", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)

                    lblLCL.Text = Math.Round(lcl, 3)
                    lblUCL.Text = Math.Round(ucl, 3)
                    lblStddev.Text = Math.Round(standev, 3)
                    lblUnitVal.Text = unit
                    lblCpk.Text = Math.Round(Cpk1, 3)
                    lblCp.Text = Math.Round(Cp1, 3)
                    lblMean.Text = Math.Round(avg, 3)

                    'Dim yVal() As String
                    'yVal = (From row In dt1 Select col = row("PRM_TEST_VALUE_FEGA").ToString).ToArray()

                    ''Commented by pratik said by Dinesh
                    ''lblMin.Text = yVal.Min()
                    ''lblMax.Text = yVal.Max()

                    'Dim sum As Integer = 0

                    'For j As Integer = 0 To dt1.Rows.Count - 1

                    '    sum = sum + dt1.Rows(j)("PRM_TEST_VALUE_FEGA")

                    'Next
                    'avg = sum / dt1.Rows.Count

                    ''Commented by pratik said by Dinesh
                    ''lblAvg.Text = Math.Round(avg, 3)

                    'For k As Integer = 0 To dt1.Rows.Count - 1
                    '    standev += Pow(dt1.Rows(k)("PRM_TEST_VALUE_FEGA") - avg, 2)
                    'Next
                    'standev = Math.Sqrt(standev / dt1.Rows.Count)

                    'lcl = avg - (3 * standev)
                    'ucl = avg + (3 * standev)
                    'lblLCL.Text = Math.Round(lcl, 3)
                    'lblUCL.Text = Math.Round(ucl, 3)
                    'lblStddev.Text = Math.Round(standev, 3)
                    'Dim val1 As Double = 0.0
                    'Dim val2 As Double = 0.0

                    ' ''Ádded on 25 may 2020
                    'Dim usl1, lsl1 As Double
                    'lsl1 = dtLimit.Rows(0)("LSL")
                    'usl1 = dtLimit.Rows(0)("USL")
                    'If IsDBNull(dtLimit.Rows(0)("Unit")) Then
                    '    unit = ""
                    'Else
                    '    unit = dtLimit.Rows(0)("Unit")
                    'End If
                    'lblUnitVal.Text = unit
                    'val1 = (usl1 - avg) / (3 * standev)
                    'val2 = (avg - lsl1) / (3 * standev)

                    'Dim Cpk As Double = 0.0
                    'Cpk = Math.Min(val1, val2)
                    'lblCpk.Text = Math.Round(Cpk, 3)
                    'Dim Cp As Double = 0.0
                    'Cp = ((yVal.Max() - yVal.Min()) / (6 * standev))
                    'lblCp.Text = Math.Round(Cp, 3)
                    'lblMean.Text = Math.Round(avg, 3)
                    If dtLimit.Rows.Count > 0 Then

                        'Commented by pratik said by Dinesh
                        'txtMin.Text = dtLimit.Rows(0)("LSL")
                        'txtMax.Text = dtLimit.Rows(0)("USL")
                        lblMin.Text = dtLimit.Rows(0)("LSL")
                        lblMax.Text = dtLimit.Rows(0)("USL")

                        objController.PlotLineChartForCRMDailyReportInFeGA(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                    Else
                        objController.PlotLineChartForCRMDailyReportInFeGA(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, 37, 30, avg, ucl, lcl, dtRemarks)
                    End If

                    'Dim query As String = "Select distinct PRM_TS_END as 'SAMPLING_DATE',PRM_ID_COIL,PRM_BTC_AVG as 'TEST_VALUE','' as 'PARAM_TEST','' as 'PROCESS_LINE',PRM_CD_GRADE as GRADE,PRM_TDC_NO as TDC_NO, PRM_CD_PROD as CD_PROD from T_CGL_FUR_PARAM where PRM_TS_END between '" & strfrmDt & "' and '" & strToDt & "' and  1=1 and PRM_BTC_AVG is not null and PRM_BTC_AVG > 0 and PRM_TDC_ACTL in('GA14', 'GAF3', 'GA04', 'GA15')"
                        Dim query As String = "Select distinct SAMPLING_DATE as 'SAMPLING_DATE',COIL_ID,TEST_VALUE as 'TEST_VALUE','' as 'PARAM_TEST','' as 'PROCESS_LINE',GRADE as GRADE,TDC_NO as TDC_NO, CD_PROD as CD_PROD from T_DM1 where PARAM_TEST = 'PRM_BTC_AVG' and SAMPLING_DATE between '" & strfrmDt & "' and '" & strToDt & "' and TDC_NO in('GA14', 'GAF3', 'GA04', 'GA15') and TEST_VALUE is not null and TEST_VALUE > 0 order by SAMPLING_DATE"
                    objController.PopulateDailyReportData(query, gvDetails)

                Else
                    gvDetails.DataSource = Nothing
                    gvDetails.DataBind()
                End If
                End If


                If ddlParamTest1.SelectedItem.Text.Trim = "Roughness_GA Fuel Tank (Coil Middle)" Then
                    Filter &= " and TDC_NO in('GA14', 'GAF3', 'GA04', 'GA15')"
                    'Dim dt1 As DataTable = objController.GetDataForCRMDailyReportInTank("T_CGL_FUR_PARAM", strfrmDt, strToDt, "PRM_TS_END", ColumnName, Filter)
                    Dim dt1 As DataTable = objController.GetDataForCRMDailyReportNew("T_DM1", strfrmDt, strToDt, "PRM_TEST_VALUE_RA", Filter)
                    If dt1.Rows.Count > 0 Then
                        Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("Roughness_GA Fuel Tank (Coil Middle)")

                        Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(strfrmDt, strToDt, "Roughness_GA Fuel Tank (Coil Middle)")

                        CalculateCPK(dt1, "TEST_VALUE", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)

                        lblLCL.Text = Math.Round(lcl, 3)
                        lblUCL.Text = Math.Round(ucl, 3)
                        lblStddev.Text = Math.Round(standev, 3)
                        lblUnitVal.Text = unit
                        lblCpk.Text = Math.Round(Cpk1, 3)
                        lblCp.Text = Math.Round(Cp1, 3)
                        lblMean.Text = Math.Round(avg, 3)

                        'Dim yVal() As String
                        'yVal = (From row In dt1 Select col = row("PRM_TEST_VALUE_FEGA").ToString).ToArray()

                        ''Commented by pratik said by Dinesh
                        ''lblMin.Text = yVal.Min()
                        ''lblMax.Text = yVal.Max()

                        'Dim sum As Integer = 0

                        'For j As Integer = 0 To dt1.Rows.Count - 1

                        '    sum = sum + dt1.Rows(j)("PRM_TEST_VALUE_FEGA")

                        'Next
                        'avg = sum / dt1.Rows.Count

                        ''Commented by pratik said by Dinesh
                        ''lblAvg.Text = Math.Round(avg, 3)

                        'For k As Integer = 0 To dt1.Rows.Count - 1
                        '    standev += Pow(dt1.Rows(k)("PRM_TEST_VALUE_FEGA") - avg, 2)
                        'Next
                        'standev = Math.Sqrt(standev / dt1.Rows.Count)

                        'lcl = avg - (3 * standev)
                        'ucl = avg + (3 * standev)
                        'lblLCL.Text = Math.Round(lcl, 3)
                        'lblUCL.Text = Math.Round(ucl, 3)
                        'lblStddev.Text = Math.Round(standev, 3)
                        'Dim val1 As Double = 0.0
                        'Dim val2 As Double = 0.0

                        ' ''Ádded on 25 may 2020
                        'Dim usl1, lsl1 As Double
                        'lsl1 = dtLimit.Rows(0)("LSL")
                        'usl1 = dtLimit.Rows(0)("USL")
                        'If IsDBNull(dtLimit.Rows(0)("Unit")) Then
                        '    unit = ""
                        'Else
                        '    unit = dtLimit.Rows(0)("Unit")
                        'End If
                        'lblUnitVal.Text = unit
                        'val1 = (usl1 - avg) / (3 * standev)
                        'val2 = (avg - lsl1) / (3 * standev)

                        'Dim Cpk As Double = 0.0
                        'Cpk = Math.Min(val1, val2)
                        'lblCpk.Text = Math.Round(Cpk, 3)
                        'Dim Cp As Double = 0.0
                        'Cp = ((yVal.Max() - yVal.Min()) / (6 * standev))
                        'lblMean.Text = Math.Round(avg, 3)
                        If dtLimit.Rows.Count > 0 Then

                            'Commented by pratik said by Dinesh
                            'txtMin.Text = dtLimit.Rows(0)("LSL")
                            'txtMax.Text = dtLimit.Rows(0)("USL")
                            lblMin.Text = dtLimit.Rows(0)("LSL")
                            lblMax.Text = dtLimit.Rows(0)("USL")

                            objController.PlotLineChartForCRMDailyReportInFeGA(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                        Else
                            objController.PlotLineChartForCRMDailyReportInFeGA(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, 1.2, 0.8, avg, ucl, lcl, dtRemarks)
                        End If

                        'Dim query As String = "Select distinct PRM_TS_END as 'SAMPLING_DATE',PRM_ID_COIL,PRM_TEST_VALUE_RA as 'TEST_VALUE','' as 'PARAM_TEST','' as 'PROCESS_LINE',PRM_CD_GRADE as GRADE,PRM_TDC_NO as TDC_NO, PRM_CD_PROD as CD_PROD from T_CGL_FUR_PARAM where PRM_TS_END between '" & strfrmDt & "' and '" & strToDt & "' and  1=1 and PRM_TEST_VALUE_RA is not null and PRM_TEST_VALUE_RA > 0 and PRM_TDC_ACTL in('GA14', 'GAF3', 'GA04', 'GA15')"
                        Dim query As String = "Select distinct SAMPLING_DATE as 'SAMPLING_DATE',COIL_ID,TEST_VALUE as 'TEST_VALUE','' as 'PARAM_TEST','' as 'PROCESS_LINE',GRADE as GRADE,TDC_NO as TDC_NO, CD_PROD as CD_PROD from T_DM1 where PARAM_TEST = 'PRM_TEST_VALUE_RA' and SAMPLING_DATE between '" & strfrmDt & "' and '" & strToDt & "' and TDC_NO in('GA14', 'GAF3', 'GA04', 'GA15') and TEST_VALUE is not null and TEST_VALUE > 0 order by SAMPLING_DATE"
                        objController.PopulateDailyReportData(query, gvDetails)

                    Else
                        gvDetails.DataSource = Nothing
                        gvDetails.DataBind()
                    End If
                End If


                If ddlParamTest1.SelectedItem.Text.Trim = "Fe content in GA" Then
                    Filter &= " and PROCESS_LINE = 'L' and PARAM_TEST = 'FE' "
                    'Dim dt As DataTable = objController.GetDataForCRMDailyReportFeContentInGa("CRM_LABTEST_RES", "CLR_DT_SAMPLING_DATE", "CLR_PARAM_TEST", strfrmDt, strToDt, "", a(i))
                    Dim dt As DataTable = objController.GetDataForCRMDailyReportNew("T_DM1", strfrmDt, strToDt, "PRM_SS_STRP_TMP", Filter)
                    If dt.Rows.Count > 0 Then
                        Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("Fe content in GA")

                        Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(strfrmDt, strToDt, "Fe content in GA")

                        'CalculateCPK(dt, "clr_test_value", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)
                        CalculateCPK(dt, "TEST_VALUE", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)


                        lblLCL.Text = Math.Round(lcl, 3)
                        lblUCL.Text = Math.Round(ucl, 3)
                        lblStddev.Text = Math.Round(standev, 3)
                        lblUnitVal.Text = unit
                        lblCpk.Text = Math.Round(Cpk1, 3)
                        lblCp.Text = Math.Round(Cp1, 3)
                        lblMean.Text = Math.Round(avg, 3)


                        'Dim yVal() As String
                        'yVal = (From row In dt Select col = row("clr_test_value").ToString).ToArray()

                        ''Commented by pratik said by Dinesh
                        ''lblMin.Text = yVal.Min()
                        ''lblMax.Text = yVal.Max()

                        'Dim sum As Integer = 0

                        'For j As Integer = 0 To dt.Rows.Count - 1

                        '    sum = sum + dt.Rows(j)("clr_test_value")


                        'Next
                        'avg = sum / dt.Rows.Count

                        ''Commented by pratik said by Dinesh
                        ''lblAvg.Text = Math.Round(avg, 3)

                        'For k As Integer = 0 To dt.Rows.Count - 1
                        '    standev += Pow(dt.Rows(k)("clr_test_value") - avg, 2)
                        'Next
                        'standev = Math.Sqrt(standev / dt.Rows.Count)
                        'lcl = avg - (3 * standev)
                        'ucl = avg + (3 * standev)
                        'lblLCL.Text = Math.Round(lcl, 3)
                        'lblUCL.Text = Math.Round(ucl, 3)
                        'lblStddev.Text = Math.Round(standev, 3)
                        'Dim val1 As Double = 0.0
                        'Dim val2 As Double = 0.0

                        ' ''Ádded on 25 may 2020
                        'Dim usl1, lsl1 As Double
                        'lsl1 = dtLimit.Rows(0)("LSL")
                        'usl1 = dtLimit.Rows(0)("USL")
                        'If IsDBNull(dtLimit.Rows(0)("Unit")) Then
                        '    unit = ""
                        'Else
                        '    unit = dtLimit.Rows(0)("Unit")
                        'End If
                        'lblUnitVal.Text = unit
                        'val1 = (usl1 - avg) / (3 * standev)
                        'val2 = (avg - lsl1) / (3 * standev)

                        'Dim Cpk As Double = 0.0
                        'Cpk = Math.Min(val1, val2)
                        'lblCpk.Text = Math.Round(Cpk, 3)
                        'Dim Cp As Double = 0.0
                        'Cp = ((yVal.Max() - yVal.Min()) / (6 * standev))
                        'lblCp.Text = Math.Round(Cp, 3)
                        'lblMean.Text = Math.Round(avg, 3)

                        If dtLimit.Rows.Count > 0 Then

                            'Commented by pratik said by Dinesh
                            'txtMin.Text = dtLimit.Rows(0)("LSL")
                            'txtMax.Text = dtLimit.Rows(0)("USL")
                            lblMin.Text = dtLimit.Rows(0)("LSL")
                            lblMax.Text = dtLimit.Rows(0)("USL")

                            'objController.PlotLineChartForCRMDailyReport(dt, "CLR_DT_SAMPLING_DATE", "clr_test_value", l, a(i), "plot" & i + 1, unit, dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                            objController.PlotLineChartForCRMDailyReport(dt, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                        Else
                            'objController.PlotLineChartForCRMDailyReport(dt, "CLR_DT_SAMPLING_DATE", "clr_test_value", l, a(i), "plot" & i + 1, unit, 12.5, 8.0, avg, ucl, lcl, dtRemarks)
                            objController.PlotLineChartForCRMDailyReport(dt, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, 12.5, 8.0, avg, ucl, lcl, dtRemarks)
                        End If

                        'Dim query As String = "select distinct CLR_DT_SAMPLING_DATE as 'SAMPLING_DATE',CLR_TEST_VALUE as 'TEST_VALUE',CLR_PARAM_TEST as 'PARAM_TEST',CLR_PROCESS_LINE as 'PROCESS_LINE','' as GRADE,'' as TDC_NO, '' as CD_PROD from CRM_LABTEST_RES where CLR_DT_SAMPLING_DATE between '" & strfrmDt & "' and '" & strToDt & "' and CLR_PROCESS_LINE IN('L') and CLR_PARAM_TEST = 'Fe' and CLR_TEST_VALUE > 0 order by CLR_DT_SAMPLING_DATE"
                        Dim query As String = "Select distinct SAMPLING_DATE as 'SAMPLING_DATE',COIL_ID,TEST_VALUE as 'TEST_VALUE','' as 'PARAM_TEST','' as 'PROCESS_LINE',GRADE as GRADE,TDC_NO as TDC_NO, CD_PROD as CD_PROD from T_DM1 where PROCESS_LINE ='L' and PARAM_TEST = 'FE' and SAMPLING_DATE between '" & strfrmDt & "' and '" & strToDt & "' and TEST_VALUE is not null and TEST_VALUE > 0 order by SAMPLING_DATE"
                        objController.PopulateDailyReportData(query, gvDetails)
                    Else
                        gvDetails.DataSource = Nothing
                        gvDetails.DataBind()
                    End If
                End If


                If ddlParamTest1.SelectedItem.Text.Trim = "Bath Al% in GA" Then
                    Filter &= " and PROCESS_LINE ='L' and PARAM_TEST in ('ZAGA','ZAAL')"
                    'Dim dt As DataTable = objController.GetDataForCRMDailyReportBathAlGA("CLR_PROCESS_LINE = 'L' AND CLR_PARAM_TEST in ('ZAGA')", strfrmDt, strToDt)
                    Dim dt As DataTable = objController.GetDataForCRMDailyReportNew("T_DM1", strfrmDt, strToDt, Filter)

                    If dt.Rows.Count > 0 Then
                        Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("Bath Al% in GA")

                        Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(strfrmDt, strToDt, "Bath Al% in GA")

                        'CalculateCPK(dt, "clr_test_value", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)
                        CalculateCPK(dt, "TEST_VALUE", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)

                        lblLCL.Text = Math.Round(lcl, 3)
                        lblUCL.Text = Math.Round(ucl, 3)
                        lblStddev.Text = Math.Round(standev, 3)
                        lblUnitVal.Text = unit
                        lblCpk.Text = Math.Round(Cpk1, 3)
                        lblCp.Text = Math.Round(Cp1, 3)
                        lblMean.Text = Math.Round(avg, 3)


                        'Dim yVal() As String
                        'yVal = (From row In dt Select col = row("clr_test_value").ToString).ToArray()

                        ''Commented by pratik said by Dinesh
                        ''lblMin.Text = yVal.Min()
                        ''lblMax.Text = yVal.Max()

                        'Dim sum As Integer = 0

                        'For j As Integer = 0 To dt.Rows.Count - 1

                        '    sum = sum + dt.Rows(j)("clr_test_value")


                        'Next
                        'avg = sum / dt.Rows.Count

                        ''Commented by pratik said by Dinesh
                        ''lblAvg.Text = Math.Round(avg, 3)

                        'For k As Integer = 0 To dt.Rows.Count - 1
                        '    standev += Pow(dt.Rows(k)("clr_test_value") - avg, 2)
                        'Next
                        'standev = Math.Sqrt(standev / dt.Rows.Count)
                        'lcl = avg - (3 * standev)
                        'ucl = avg + (3 * standev)
                        'lblLCL.Text = Math.Round(lcl, 3)
                        'lblUCL.Text = Math.Round(ucl, 3)
                        'lblStddev.Text = Math.Round(standev, 3)
                        'Dim val1 As Double = 0.0
                        'Dim val2 As Double = 0.0

                        ' ''Ádded on 25 may 2020
                        'Dim usl1, lsl1 As Double
                        'lsl1 = dtLimit.Rows(0)("LSL")
                        'usl1 = dtLimit.Rows(0)("USL")
                        'If IsDBNull(dtLimit.Rows(0)("Unit")) Then
                        '    unit = ""
                        'Else
                        '    unit = dtLimit.Rows(0)("Unit")
                        'End If
                        'lblUnitVal.Text = unit
                        'val1 = (usl1 - avg) / (3 * standev)
                        'val2 = (avg - lsl1) / (3 * standev)

                        'Dim Cpk As Double = 0.0
                        'Cpk = Math.Min(val1, val2)
                        'lblCpk.Text = Math.Round(Cpk, 3)
                        'Dim Cp As Double = 0.0
                        'Cp = ((yVal.Max() - yVal.Min()) / (6 * standev))
                        'lblCp.Text = Math.Round(Cp, 3)
                        'lblMean.Text = Math.Round(avg, 3)

                        If dtLimit.Rows.Count > 0 Then

                            'Commented by pratik said by Dinesh
                            'txtMin.Text = dtLimit.Rows(0)("LSL")
                            'txtMax.Text = dtLimit.Rows(0)("USL")
                            lblMin.Text = dtLimit.Rows(0)("LSL")
                            lblMax.Text = dtLimit.Rows(0)("USL")

                            'objController.PlotLineChartForCRMDailyReport(dt, "CLR_DT_SAMPLING_DATE", "clr_test_value", l, a(i), "plot" & i + 1, unit, dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                            objController.PlotLineChartForCRMDailyReport(dt, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                        Else
                            'objController.PlotLineChartForCRMDailyReport(dt, "CLR_DT_SAMPLING_DATE", "clr_test_value", l, a(i), "plot" & i + 1, unit, 0.13, 0.126, avg, ucl, lcl, dtRemarks)
                            objController.PlotLineChartForCRMDailyReport(dt, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, 0.13, 0.126, avg, ucl, lcl, dtRemarks)
                        End If

                        'Dim query As String = "select distinct CLR_DT_SAMPLING_DATE as 'SAMPLING_DATE',CLR_TEST_VALUE as 'TEST_VALUE',CLR_PARAM_TEST as 'PARAM_TEST',CLR_PROCESS_LINE as 'PROCESS_LINE','' as GRADE,'' as TDC_NO, '' as CD_PROD from CRM_LABTEST_RES where CLR_DT_SAMPLING_DATE between '" & strfrmDt & "' and '" & strToDt & "' and CLR_PROCESS_LINE IN('L') and CLR_PARAM_TEST in('ZAGA') and CLR_TEST_VALUE > 0 order by CLR_DT_SAMPLING_DATE"
                        Dim query As String = "Select distinct SAMPLING_DATE as 'SAMPLING_DATE',COIL_ID,TEST_VALUE as 'TEST_VALUE','' as 'PARAM_TEST','' as 'PROCESS_LINE',GRADE as GRADE,TDC_NO as TDC_NO, CD_PROD as CD_PROD from T_DM1 where PROCESS_LINE = 'L' and PARAM_TEST in ('ZAGA','ZAAL') and SAMPLING_DATE between '" & strfrmDt & "' and '" & strToDt & "' and TEST_VALUE is not null and TEST_VALUE > 0 order by SAMPLING_DATE"
                        objController.PopulateDailyReportData(query, gvDetails)
                    Else
                        gvDetails.DataSource = Nothing
                        gvDetails.DataBind()
                    End If
                End If

                If ddlParamTest1.SelectedItem.Text.Trim = "Bath Al% in ZS" Then
                    Filter &= " and PROCESS_LINE ='L' and PARAM_TEST = 'ZAZS'"
                    ' Dim dt As DataTable = objController.GetDataForCRMDailyReportBathAlGA("CLR_PROCESS_LINE = 'L' AND CLR_PARAM_TEST in ('ZAZS')", strfrmDt, strToDt)
                    Dim dt As DataTable = objController.GetDataForCRMDailyReportNew("T_DM1", strfrmDt, strToDt, Filter)


                    If dt.Rows.Count > 0 Then
                        Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("Bath Al% in ZS")

                        Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(strfrmDt, strToDt, "Bath Al% in ZS")

                        CalculateCPK(dt, "TEST_VALUE", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)

                        lblLCL.Text = Math.Round(lcl, 3)
                        lblUCL.Text = Math.Round(ucl, 3)
                        lblStddev.Text = Math.Round(standev, 3)
                        lblUnitVal.Text = unit
                        lblCpk.Text = Math.Round(Cpk1, 3)
                        lblCp.Text = Math.Round(Cp1, 3)
                        lblMean.Text = Math.Round(avg, 3)


                        'Dim yVal() As String
                        'yVal = (From row In dt Select col = row("clr_test_value").ToString).ToArray()

                        ''Commented by pratik said by Dinesh
                        ''lblMin.Text = yVal.Min()
                        ''lblMax.Text = yVal.Max()

                        'Dim sum As Integer = 0

                        'For j As Integer = 0 To dt.Rows.Count - 1

                        '    sum = sum + dt.Rows(j)("clr_test_value")


                        'Next
                        'avg = sum / dt.Rows.Count

                        ''Commented by pratik said by Dinesh
                        ''lblAvg.Text = Math.Round(avg, 3)

                        'For k As Integer = 0 To dt.Rows.Count - 1
                        '    standev += Pow(dt.Rows(k)("clr_test_value") - avg, 2)
                        'Next
                        'standev = Math.Sqrt(standev / dt.Rows.Count)
                        'lcl = avg - (3 * standev)
                        'ucl = avg + (3 * standev)
                        'lblLCL.Text = Math.Round(lcl, 3)
                        'lblUCL.Text = Math.Round(ucl, 3)
                        'lblStddev.Text = Math.Round(standev, 3)
                        'Dim val1 As Double = 0.0
                        'Dim val2 As Double = 0.0

                        ' ''Ádded on 25 may 2020
                        'Dim usl1, lsl1 As Double
                        'lsl1 = dtLimit.Rows(0)("LSL")
                        'usl1 = dtLimit.Rows(0)("USL")
                        'If IsDBNull(dtLimit.Rows(0)("Unit")) Then
                        '    unit = ""
                        'Else
                        '    unit = dtLimit.Rows(0)("Unit")
                        'End If
                        'lblUnitVal.Text = unit
                        'val1 = (usl1 - avg) / (3 * standev)
                        'val2 = (avg - lsl1) / (3 * standev)

                        'Dim Cpk As Double = 0.0
                        'Cpk = Math.Min(val1, val2)
                        'lblCpk.Text = Math.Round(Cpk, 3)
                        'Dim Cp As Double = 0.0
                        'Cp = ((yVal.Max() - yVal.Min()) / (6 * standev))
                        'lblCp.Text = Math.Round(Cp, 3)
                        'lblMean.Text = Math.Round(avg, 3)

                        If dtLimit.Rows.Count > 0 Then

                            'Commented by pratik said by Dinesh
                            'txtMin.Text = dtLimit.Rows(0)("LSL")
                            'txtMax.Text = dtLimit.Rows(0)("USL")
                            lblMin.Text = dtLimit.Rows(0)("LSL")
                            lblMax.Text = dtLimit.Rows(0)("USL")

                            'objController.PlotLineChartForCRMDailyReport(dt, "CLR_DT_SAMPLING_DATE", "clr_test_value", l, a(i), "plot" & i + 1, unit, dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                            objController.PlotLineChartForCRMDailyReport(dt, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                        Else
                            'objController.PlotLineChartForCRMDailyReport(dt, "CLR_DT_SAMPLING_DATE", "clr_test_value", l, a(i), "plot" & i + 1, unit, 0.24, 0.18, avg, ucl, lcl, dtRemarks)
                            objController.PlotLineChartForCRMDailyReport(dt, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, 0.24, 0.18, avg, ucl, lcl, dtRemarks)
                        End If

                        'Dim query As String = "select distinct CLR_DT_SAMPLING_DATE as 'SAMPLING_DATE',CLR_TEST_VALUE as 'TEST_VALUE',CLR_PARAM_TEST as 'PARAM_TEST',CLR_PROCESS_LINE as 'PROCESS_LINE','' as GRADE,'' as TDC_NO, '' as CD_PROD from CRM_LABTEST_RES where CLR_DT_SAMPLING_DATE between '" & strfrmDt & "' and '" & strToDt & "' and CLR_PROCESS_LINE IN('L') and CLR_PARAM_TEST in('ZAZS') and CLR_TEST_VALUE > 0 order by CLR_DT_SAMPLING_DATE"
                        Dim query As String = "Select distinct SAMPLING_DATE as 'SAMPLING_DATE',COIL_ID,TEST_VALUE as 'TEST_VALUE','' as 'PARAM_TEST','' as 'PROCESS_LINE',GRADE as GRADE,TDC_NO as TDC_NO, CD_PROD as CD_PROD from T_DM1 where PROCESS_LINE = 'L' and PARAM_TEST = 'ZAZS' and SAMPLING_DATE between '" & strfrmDt & "' and '" & strToDt & "' and TEST_VALUE is not null and TEST_VALUE > 0 order by SAMPLING_DATE"
                        objController.PopulateDailyReportData(query, gvDetails)
                    Else
                        gvDetails.DataSource = Nothing
                        gvDetails.DataBind()
                    End If
                End If

                If ddlParamTest1.SelectedItem.Text.Trim = "GA Soaking Temperature" Then
                    'Dim dt1 As DataTable = objController.GetDataForCRMDailyReportInFeGA("T_CGL_FUR_PARAM", strfrmDt, strToDt, "PRM_TS_END", ColumnName, Filter)
                    Filter &= " and PROCESS_LINE = 'L' "
                    Dim dt1 As DataTable = objController.GetDataForCRMDailyReportNew("T_DM1", strfrmDt, strToDt, "ga_soak_strp_tmp", Filter)
                    If dt1.Rows.Count > 0 Then
                        Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("GA Soaking Temperature")

                        Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(strfrmDt, strToDt, "GA Soaking Temperature")

                        CalculateCPK(dt1, "TEST_VALUE", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)

                        lblLCL.Text = Math.Round(lcl, 3)
                        lblUCL.Text = Math.Round(ucl, 3)
                        lblStddev.Text = Math.Round(standev, 3)
                        lblUnitVal.Text = unit
                        lblCpk.Text = Math.Round(Cpk1, 3)
                        lblCp.Text = Math.Round(Cp1, 3)
                        lblMean.Text = Math.Round(avg, 3)

                        'Dim yVal() As String
                        'yVal = (From row In dt1 Select col = row("PRM_SS_STRP_TMP").ToString).ToArray()

                        ''Commented by pratik said by Dinesh
                        ''lblMin.Text = yVal.Min()
                        ''lblMax.Text = yVal.Max()

                        'Dim sum As Integer = 0

                        'For j As Integer = 0 To dt1.Rows.Count - 1

                        '    sum = sum + dt1.Rows(j)("PRM_SS_STRP_TMP")

                        'Next
                        'avg = sum / dt1.Rows.Count

                        ''Commented by pratik said by Dinesh
                        ''lblAvg.Text = Math.Round(avg, 3)

                        'For k As Integer = 0 To dt1.Rows.Count - 1
                        '    standev += Pow(dt1.Rows(k)("PRM_SS_STRP_TMP") - avg, 2)
                        'Next
                        'standev = Math.Sqrt(standev / dt1.Rows.Count)

                        'lcl = avg - (3 * standev)
                        'ucl = avg + (3 * standev)
                        'lblLCL.Text = Math.Round(lcl, 3)
                        'lblUCL.Text = Math.Round(ucl, 3)
                        'lblStddev.Text = Math.Round(standev, 3)
                        'Dim val1 As Double = 0.0
                        'Dim val2 As Double = 0.0

                        ' ''Ádded on 25 may 2020
                        'Dim usl1, lsl1 As Double
                        'lsl1 = dtLimit.Rows(0)("LSL")
                        'usl1 = dtLimit.Rows(0)("USL")
                        'If IsDBNull(dtLimit.Rows(0)("Unit")) Then
                        '    unit = ""
                        'Else
                        '    unit = dtLimit.Rows(0)("Unit")
                        'End If
                        'lblUnitVal.Text = unit
                        'val1 = (usl1 - avg) / (3 * standev)
                        'val2 = (avg - lsl1) / (3 * standev)

                        'Dim Cpk As Double = 0.0
                        'Cpk = Math.Min(val1, val2)
                        'lblCpk.Text = Math.Round(Cpk, 3)
                        'Dim Cp As Double = 0.0
                        'Cp = ((yVal.Max() - yVal.Min()) / (6 * standev))
                        'lblCp.Text = Math.Round(Cp, 3)
                        'lblMean.Text = Math.Round(avg, 3)
                        If dtLimit.Rows.Count > 0 Then

                            'Commented by pratik said by Dinesh
                            'txtMin.Text = dtLimit.Rows(0)("LSL")
                            'txtMax.Text = dtLimit.Rows(0)("USL")
                            lblMin.Text = dtLimit.Rows(0)("LSL")
                            lblMax.Text = dtLimit.Rows(0)("USL")

                            objController.PlotLineChartForCRMDailyReportInFeGA(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                        Else
                            objController.PlotLineChartForCRMDailyReportInFeGA(dt1, "SAMPLING_DATE", "TEST_VALUE", l, a(i), "plot" & i + 1, unit, 750.0, 700.0, avg, ucl, lcl, dtRemarks)
                        End If

                        'Dim query As String = "Select distinct PRM_TS_END as 'SAMPLING_DATE',PRM_ID_COIL,PRM_SS_STRP_TMP as 'TEST_VALUE','' as 'PARAM_TEST','' as 'PROCESS_LINE',PRM_CD_GRADE as GRADE,PRM_TDC_NO as TDC_NO, PRM_CD_PROD as CD_PROD from T_CGL_FUR_PARAM where PRM_TS_END between '" & strfrmDt & "' and '" & strToDt & "' and  1=1 and PRM_SS_STRP_TMP is not null and PRM_SS_STRP_TMP > 0 "
                        Dim query As String = "Select distinct SAMPLING_DATE as 'SAMPLING_DATE',COIL_ID,TEST_VALUE as 'TEST_VALUE','' as 'PARAM_TEST','' as 'PROCESS_LINE',GRADE as GRADE,TDC_NO as TDC_NO, CD_PROD as CD_PROD from T_DM1 where PARAM_TEST = 'ga_soak_strp_tmp' and PROCESS_LINE = 'L'  and SAMPLING_DATE between '" & strfrmDt & "' and '" & strToDt & "' and TEST_VALUE is not null and TEST_VALUE > 0 order by SAMPLING_DATE"
                        objController.PopulateDailyReportData(query, gvDetails)
                    Else
                        gvDetails.DataSource = Nothing
                        gvDetails.DataBind()
                    End If
                End If

            Next

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub ddlGrade_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlGrade.SelectedIndexChanged
        Dim fromDt As String = hfFrom.Value
        Dim toDt As String = CDate(hfTo.Value).AddDays(1).ToString("yyyy-MM-dd 06:00:00")
        objController.PopulateTdcForCRMDailyReport(ddlTdc, fromDt, toDt, ddlGrade.SelectedItem.Text)
        'objController.PopulateRoughForCRMDailyReport(ddlThickness, fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
        'Page_Load(sender, e)
        LoadData()
    End Sub

    Protected Sub ddlTdc_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlTdc.SelectedIndexChanged
        Dim fromDt As String = hfFrom.Value
        Dim toDt As String = CDate(hfTo.Value).AddDays(1).ToString("yyyy-MM-dd 06:00:00")
        objController.PopulateThicknessForCRMDailyReport(ddlThickness, fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
        'Page_Load(sender, e)
        LoadData()
    End Sub

    'Protected Sub ddlRough_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlTdc.SelectedIndexChanged
    '    Dim fromDt As String = hfFrom.Value
    '    Dim toDt As String = hfTo.Value
    '    objController.PopulateRoughForCRMDailyReport(ddlRough, fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
    '    btnOk_Click(sender, e)
    'End Sub

    Protected Sub ddlThickness_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlThickness.SelectedIndexChanged
        Dim fromDt As String = hfFrom.Value
        Dim toDt As String = CDate(hfTo.Value).AddDays(1).ToString("yyyy-MM-dd 06:00:00")
        'Page_Load(sender, e)
        LoadData()
    End Sub
    Protected Sub txtDate_TextChanged(sender As Object, e As System.EventArgs) Handles txtDate.TextChanged
        Dim fromDt As String = hfFrom.Value
        Dim toDt As String = CDate(hfTo.Value).AddDays(1).ToString("yyyy-MM-dd 06:00:00")
        If ddlGrade.SelectedIndex > 0 And ddlTdc.SelectedIndex > 0 And ddlThickness.SelectedIndex > 0 Then
            objController.PopulateGradeForCRMDailyReport(ddlGrade, fromDt, toDt)
            objController.PopulateTdcForCRMDailyReport(ddlTdc, fromDt, toDt, ddlGrade.SelectedItem.Text)
            'objController.PopulateRoughForCRMDailyReport(ddlThickness, fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
            objController.PopulateThicknessForCRMDailyReport(ddlThickness, fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
        End If
        'Page_Load(sender, e)
        LoadData()

    End Sub



    Protected Sub btnGo_Click(sender As Object, e As System.EventArgs) Handles btnGo.Click
        
        'Dim pass As Boolean = True
        'If txtMin.Text.Trim() = "" Then
        '    'UserMsgBoxWarning("Please enter min value.")
        '    'txtMin.Focus()
        '    pass = False
        'ElseIf txtMax.Text.Trim() = "" Then
        '    'UserMsgBoxWarning("Please enter max value.")
        '    'txtMax.Focus()
        '    pass = False
        'End If
        'If pass And ddlParamTest1.SelectedItem.Text <> "Select" Then
        '    Dim count = 0
        '    count = objController.UpdateLimitForDaily(txtMin.Text, txtMax.Text, ddlParamTest1.SelectedItem.Text.Trim)
        '    If count > 0 Then
        '        txtMin.Text = ""
        '        txtMax.Text = ""
        '        LoadData()
        '    End If
        'End If


    End Sub


    Protected Sub ddlParamTest1_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlParamTest1.SelectedIndexChanged
        LoadData()
    End Sub

    Protected Sub gvDetails_RowCancelingEdit(sender As Object, e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) Handles gvDetails.RowCancelingEdit
        gvDetails.EditIndex = -1
        ddlParamTest1_SelectedIndexChanged(sender, e)

    End Sub

    Protected Sub gvDetails_RowEditing(sender As Object, e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles gvDetails.RowEditing
        gvDetails.EditIndex = e.NewEditIndex
        ddlParamTest1_SelectedIndexChanged(sender, e)
    End Sub

   
    Protected Sub gvDetails_RowUpdating(sender As Object, e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles gvDetails.RowUpdating
        Dim row As GridViewRow = gvDetails.Rows(e.RowIndex)
        Dim SamplingDate As DateTime = (TryCast(row.FindControl("lblDatetime"), Label)).Text
        Dim TestValue As String = (TryCast(row.FindControl("txtTestValue"), TextBox)).Text
        Dim TestParam As String = (TryCast(row.FindControl("lblTestParam"), Label)).Text
        Dim ProcessLine As String = (TryCast(row.FindControl("lblProcessLine"), Label)).Text
        Dim Grade As String = (TryCast(row.FindControl("lblGrade"), Label)).Text
        Dim TDCNo As String = (TryCast(row.FindControl("lblTdcNo"), Label)).Text
        Dim ProdCode As String = (TryCast(row.FindControl("lblProdCode"), Label)).Text
        gvDetails.EditIndex = -1
        Dim count As Integer = 0
        'If ddlParamTest1.SelectedItem.Text.Trim = "ECL tank" Or ddlParamTest1.SelectedItem.Text.Trim = "Predeg.tank" Or ddlParamTest1.SelectedItem.Text.Trim = "Sheet Chromium" Or ddlParamTest1.SelectedItem.Text.Trim = "Working tank" Or ddlParamTest1.SelectedItem.Text.Trim = "Sheet Fe in GA" Or ddlParamTest1.SelectedItem.Text.Trim = "Soaking Temperature" Or ddlParamTest1.SelectedItem.Text.Trim = "SPM Elongation" Or ddlParamTest1.SelectedItem.Text.Trim = "Zinc Pot Temperature" Then
        '    count = objController.UpdateDailyReportData(SamplingDate.ToString("yyyy-MM-dd HH:mm:ss"), TestValue, TestParam, ProcessLine)
        'ElseIf ddlParamTest1.SelectedItem.Text.Trim = "ECL Tank Concentration" Or ddlParamTest1.SelectedItem.Text.Trim = "ECL rectifier Current" Or ddlParamTest1.SelectedItem.Text.Trim = "Chromate Tank Concentration - Passerite" Or ddlParamTest1.SelectedItem.Text.Trim = "Chromate Tank Concentration - Galvaguard" Or ddlParamTest1.SelectedItem.Text.Trim = "Sheet Chromium Fuel tank" Or ddlParamTest1.SelectedItem.Text.Trim = "Sheet Chromium ZS Coils" Or ddlParamTest1.SelectedItem.Text.Trim = "Pre Degreasing Conc L" Or ddlParamTest1.SelectedItem.Text.Trim = "Pre Degreasing Conc G" Then
        '    count = objController.UpdateDailyReportData(SamplingDate.ToString("yyyy-MM-dd HH:mm:ss"), TestValue, TestParam, ProcessLine, Grade, TDCNo, ProdCode)
        'End If

            count = objController.UpdateDailyReportData(SamplingDate.ToString("yyyy-MM-dd HH:mm:ss"), TestValue, TestParam, ProcessLine, Grade, TDCNo, ProdCode)

        If count > 0 Then
            UserMsgBoxSuccess("Updated successfully.")
            ddlParamTest1_SelectedIndexChanged(sender, e)
        End If
    End Sub

    Protected Sub btnRemarksSave_Click(sender As Object, e As System.EventArgs) Handles btnRemarksSave.Click
        Try

            Dim pass As Boolean = True
            If txtRemarksDate.Text.Trim() = "" Then
                UserMsgBoxWarning("Please select date.")
                txtRemarksDate.Focus()
                pass = False
                'ElseIf txtParamName.Text.Trim() = "" Then
                '    UserMsgBoxWarning("Please enter parameter.")
                '    txtParamName.Focus()
                '    pass = False
            ElseIf ddlShift.SelectedItem.Text = "Select" Then
                UserMsgBoxWarning("Please select shift.")
                ddlShift.Focus()
                pass = False
            ElseIf txtRemarks.Text = "" Then
                UserMsgBoxWarning("Please enter remarks.")
                txtRemarks.Focus()
                pass = False
            End If
            If pass Then
                Dim count = 0
                count = objController.SaveDMRemarks(txtRemarksDate.Text, lblParameter.Text, txtCoilId.Text, ddlShift.SelectedItem.Text, txtRemarks.Text)

                If count > 0 Then
                    UserMsgBoxSuccess("Remarks saved successfully.")
                    txtRemarksDate.Text = ""
                    'txtParamName.Text = ""
                    txtCoilId.Text = ""
                    ddlShift.SelectedIndex = 0
                    txtRemarks.Text = ""
                   
                Else
                    UserMsgBoxError("Remarks not saved.")
                End If
            End If

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnYes_Click(sender As Object, e As System.EventArgs) Handles btnYes.Click
        Dim pass As Boolean = True
        If txtMin.Text.Trim() = "" Then
            'UserMsgBoxWarning("Please enter min value.")
            'txtMin.Focus()
            pass = False
        ElseIf txtMax.Text.Trim() = "" Then
            'UserMsgBoxWarning("Please enter max value.")
            'txtMax.Focus()
            pass = False
        End If
        If pass And ddlParamTest1.SelectedItem.Text <> "Select" Then
            Dim count = 0
            Dim str As String = ""
            If ddlParamTest1.SelectedItem.Text.Trim = "Pre Degreasing Conc L" Or ddlParamTest1.SelectedItem.Text.Trim = "Pre Degreasing Conc G" Then
                str = ddlParamTest1.SelectedItem.Text.Trim.Substring(0, 19)
            Else
                str = ddlParamTest1.SelectedItem.Text.Trim
            End If
            count = objController.UpdateLimitForDaily(txtMin.Text, txtMax.Text, str)
            If count > 0 Then
                txtMin.Text = ""
                txtMax.Text = ""
                LoadData()
            End If
        End If

    End Sub
    Public Sub CalculateCPK(ByVal dt As DataTable, ByVal ColumnName As String, ByVal dtLimit As DataTable, ByRef Avg As Double, ByRef usl As Double, ByRef lsl As Double, ByRef lcl As Double, ByRef ucl As Double, ByRef standev As Double, ByRef unit As String, ByRef Cpk1 As Double, ByRef Cp1 As Double)

        'Dim usl As Double = 0.0
        'Dim lsl As Double = 0.0
        'Dim avg As Double = 0.0
        'Dim lcl As Double = 0.0
        'Dim ucl As Double = 0.0
        'Dim standev As Double = 0.0
        'Dim unit As String = ""
        Dim sum As Double = 0.0

        Dim yVal() As String
        yVal = (From row In dt Select col = row(ColumnName).ToString).ToArray()

        For j As Integer = 0 To dt.Rows.Count - 1

            sum = sum + dt.Rows(j)(ColumnName)


        Next
        Avg = sum / dt.Rows.Count

        'Commented by pratik said by Dinesh
        'lblAvg.Text = Math.Round(avg, 3)

        For k As Integer = 0 To dt.Rows.Count - 1
            standev += Pow(dt.Rows(k)(ColumnName) - Avg, 2)
        Next
        standev = Math.Sqrt(standev / dt.Rows.Count)
        lcl = Avg - (3 * standev)
        ucl = Avg + (3 * standev)
        'lblLCL.Text = Math.Round(lcl, 3)
        'lblUCL.Text = Math.Round(ucl, 3)
        'lblStddev.Text = Math.Round(standev, 3)
        Dim val1 As Double = 0.0
        Dim val2 As Double = 0.0

        ''Ádded on 25 may 2020
        Dim usl1, lsl1 As Double
        lsl1 = dtLimit.Rows(0)("LSL")
        usl1 = dtLimit.Rows(0)("USL")
        If IsDBNull(dtLimit.Rows(0)("Unit")) Then
            unit = ""
        Else
            unit = dtLimit.Rows(0)("Unit")
        End If
        'lblUnitVal.Text = unit
        val1 = (usl1 - Avg) / (3 * standev)
        val2 = (Avg - lsl1) / (3 * standev)

        'Dim Cpk As Double = 0.0
        Cpk1 = Math.Min(val1, val2)
        'lblCpk.Text = Math.Round(Cpk, 3)
        'Dim Cp As Double = 0.0
        Cp1 = ((yVal.Max() - yVal.Min()) / (6 * standev))
        'lblCp.Text = Math.Round(Cp, 3)
        'lblMean.Text = Math.Round(Avg, 3)



    End Sub

    
    Protected Sub btnDownload_Click(sender As Object, e As System.EventArgs) Handles btnDownload.Click
        Dim fromDt As String = hfFrom.Value
        Dim toDt As String = CDate(hfTo.Value).AddDays(1).ToString("yyyy-MM-dd 06:00:00")
        Dim ds As DataSet
        ds = objController.GetDataForDownload("T_DM1", fromDt, toDt)
        Dim arr() As String = {"", "Sheet Fe in GA", "Soaking Temperature", "SPM Elongation", "Zinc Pot Temperature", "ECL rectifier Current", "ECL Tank Concentration", "Chromate Tank Concentration - Passerite", "Chromate Tank Concentration - Galvaguard", "Sheet Chromium Fuel tank", "Sheet Chromium ZS Coils", "Pre Degreasing Conc L", "Pre Degreasing Conc G", "ECL Temperature", "Coating Weight_GA Fuel Tank_Top", "Coating Weight_GA Fuel Tank_BOTTOM", "Roughness_GA Fuel Tank (Coil Middle)", "Fe content in GA", "Bath Al% in GA", "Bath Al% in ZS", "GA Soaking Temperature"}
        Dim i As Integer = 1
        Using ep As New ExcelPackage()
            For Each dt As DataTable In ds.Tables
                'Dim ws As ExcelWorksheet = ep.Workbook.Worksheets.Add("s" & i)
                Dim ws As ExcelWorksheet = ep.Workbook.Worksheets.Add(arr(i))
                ws.Cells("A1").LoadFromDataTable(dt, True)

                i += 1
            Next
            Using ms As New MemoryStream
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                Response.AddHeader("content-disposition", "attachment; filename=download.xlsx")
                ep.SaveAs(ms)
                ms.WriteTo(Response.OutputStream)
                Response.Flush()
                Response.End()
            End Using
        End Using
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)
        ' Verifies that the control is rendered 
    End Sub
End Class
