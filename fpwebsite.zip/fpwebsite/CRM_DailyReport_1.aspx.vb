﻿
Imports System.Data
Imports System.Data.SqlClient
Imports System.Math

Partial Class CRM_DailyReport_1
    Inherits System.Web.UI.Page
    Dim objDataHandler As New DataHandler
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub

    Sub UserMsgBoxSuccess(ByVal Message As String, ByVal Url As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalertandredirect('" + Message + "', '" + Url + "');", True)
    End Sub

    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub

    Public Shared scumdt As DataTable
    Public Shared risdt As DataTable
    Public Shared rustdt As DataTable
    Public Shared alkalidt As DataTable
    Public Shared rubbingdt As DataTable
    Public Shared stickerdt As DataTable
    Public Shared strecherdt As DataTable
    Public Shared mechdt As DataTable
    'Public Shared spmdt As DataTable
    Public Shared pltcmfrom As String
    Public Shared pltcmto As String
    Public Shared eclfrom As String
    Public Shared eclto As String
    Public Shared baffrom As String
    Public Shared bafto As String
    Public Shared spmfrom As String
    Public Shared spmto As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Dim fromDt As String = DateTime.Now.AddDays(-29).ToString("yyyy-MM-dd 06:00:00")
            Dim toDt As String = DateTime.Now.AddDays(1).ToString("yyyy-MM-dd 06:00:00")
            Dim orfrom As DateTime = DateTime.Now.AddDays(-29)
            Dim orto As DateTime = DateTime.Now.AddDays(1)

            LoadGrade(orfrom, orto)
            ' LoadTdc(orfrom, orto)
            lstTdc.Visible = False
            hfFrom.Value = fromDt
            hfTo.Value = toDt
            'Dim strGrade As String = getSelectedData(lstGrade)
            'Dim strTDC As String = getSelectedData(lstTdc)

            'If strGrade.Length > 0 Then
            '    strGrade = "'" & strGrade.Replace(",", "','") & "'"
            'End If

            'If strTDC.Length > 0 Then
            '    strTDC = "'" & strTDC.Replace(",", "','") & "'"
            'End If
            Lit2.Text = ""
        End If

        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
                'Dim strGrade As String = getSelectedData(lstGrade)
                'Dim strTDC As String = getSelectedData(lstTdc)

                'If strGrade.Length > 0 Then
                '    strGrade = "'" & strGrade.Replace(",", "','") & "'"
                'End If

                'If strTDC.Length > 0 Then
                '    strTDC = "'" & strTDC.Replace(",", "','") & "'"
                'End If
                If Not (p = "") Then
                    'processThickness()
                    lblgraph2.Text = p
                    If p = "ALKALI C/O" Then
                        PlotLinegraph(alkalidt, Lit2, "main2")
                        Multibar(alkalidt)
                    End If
                    If p = "MECH PROP NOT OK" Then
                        PlotLinegraph(mechdt, Lit2, "main2")
                        Multibar(mechdt)
                    End If
                    If p = "RIS" Then
                        PlotLinegraph(risdt, Lit2, "main2")
                        Multibar(risdt)
                    End If
                    If p = "RUBBING MARK" Then
                        PlotLinegraph(rubbingdt, Lit2, "main2")
                        Multibar(rubbingdt)
                    End If
                    If p = "RUST" Then
                        PlotLinegraph(rustdt, Lit2, "main2")
                        Multibar(rustdt)
                    End If
                    If p = "SCUM" Then
                        PlotLinegraph(scumdt, Lit2, "main2")
                        Multibar(scumdt)
                    End If
                    If p = "STICKER" Then
                        PlotLinegraph(stickerdt, Lit2, "main2")
                        Multibar(stickerdt)
                    End If
                    If p = "STRECHER STRAIN" Then
                        PlotLinegraph(strecherdt, Lit2, "main2")
                        Multibar(strecherdt)
                    End If
                    lblmultibar.Text = "Line Wise Defect Quantity"
                    'dynamicdiv(p)
                    If p = "d" Then
                        Try
                            Dim fromDt As String = hfFrom.Value
                            Dim toDt As String = CDate(hfTo.Value).AddDays(1).ToString("yyyy-MM-dd 06:00:00")

                            LoadGrade(fromDt, toDt)
                            ' LoadTdc(fromDt, toDt)
                            hfFrom.Value = fromDt
                            hfTo.Value = toDt
                            Lit1.Text = ""
                            Lit2.Text = ""
                            Lit3.Text = ""
                            lblgraph1.Text = ""
                            lblgraph2.Text = ""
                            lblmultibar.Text = ""
                            lstTdc.Visible = False


                            'Dim strGrade As String = getSelectedData(lstGrade)
                            'Dim strTDC As String = getSelectedData(lstTdc)

                            'If strGrade.Length > 0 Then
                            '    strGrade = "'" & strGrade.Replace(",", "','") & "'"
                            'End If

                            'If strTDC.Length > 0 Then
                            '    strTDC = "'" & strTDC.Replace(",", "','") & "'"
                            'End If


                        Catch ex As Exception

                        End Try
                    End If
                End If
            Catch ex As Exception
                Throw ex
            End Try
        End If
    End Sub

    Sub LoadTdc(ByVal fromDt As DateTime, ByVal toDt As DateTime)

        Dim fromDtq As String = fromDt.ToString("dd-MMM-yy HH:mm")
        Dim toDtq As String = toDt.ToString("dd-MMM-yy HH:mm")
        Dim dt As DataTable = Nothing
        Dim strGrade As String = getSelectedData(lstGrade)

        If strGrade.Length > 0 Then
            strGrade = "'" & strGrade.Replace(",", "','") & "'"
        Else
            strGrade = "''"
        End If
        Dim dtd As DataTable = getdatatable("SELECT [Desc]  FROM [CRM_DEFECT_CODE] where process='CRCA' and selected=1")
        Dim filter As String = ""
        For i As Integer = 0 To dtd.Rows.Count - 1
            If i = dtd.Rows.Count - 1 Then
                filter &= "'" & dtd.Rows(i)(0) & "')"
            Else
                filter &= "'" & dtd.Rows(i)(0) & "', "
            End If
        Next
        filter &= " and iql_grade in (" & strGrade & ")"
        Dim query As String = ""
        query = "Select distinct ccl_tdc_aim from V_COIL_HOLD_RLS "
        query &= "inner join V_COLD_COIL On ccl_id_coil = chr_id_coil "
        query &= "inner join v_codes On cd_value = chr_cd_fnl_decsn "
        query &= "inner join v_quality on ccl_cd_qlty_aim=iql_cd_qlty "
        query &= "where "
        query &= "chr_id_coil In(Select distinct chr_id_coil from V_COIL_HOLD_RLS where "
        query &= "chr_ts_release between to_date('" & fromDtq & "','DD-MON-YY HH24:MI') and to_date('" & toDtq & "','DD-MON-YY HH24:MI') "
        query &= "and chr_remarks in ('Seconds-M','DownGraded-M','Diverted-M') and chr_cd_fnl_decsn <> 'null'  ) "
        query &= "and chr_cd_fnl_decsn=chr_cd_rsn_hold "
        query &= "and ccl_cd_prod = 'C01' "
        query &= "and CD_TYPE like 'C0015'"
        query &= "and cd_desc in (" & filter
        query &= " order by ccl_tdc_aim"
        dt = objDataHandler.GetOracleData(query)
        'dt = objDataHandler.GetOracleData("select distinct(ccl_tdc_aim) from v_quality inner join v_cold_coil on ccl_cd_qlty_aim=iql_cd_qlty where ccl_ts_creation between to_date('" & fromDtq & "','DD-MON-YY HH24:MI') and to_date('" & toDtq & "','DD-MON-YY HH24:MI') and iql_grade in (" & strGrade & ") order by ccl_tdc_aim") ' ' AND TC.PRM_TS_END between '" & fromDt & "' and '" & toDt & "'
        lstTdc.DataSource = dt
        lstTdc.DataTextField = "ccl_tdc_aim"
        lstTdc.DataValueField = "ccl_tdc_aim"
        lstTdc.DataBind()
        For Each lst As ListItem In lstTdc.Items
            lst.Selected = True
        Next
        'If dt.Rows.Count > 0 Then
        '    lstDefName.Items.FindByText("SCUMD").Selected = True
        'End If
    End Sub

    Sub LoadGrade(ByVal fromDt As DateTime, ByVal toDt As DateTime)
        Dim fromDtq As String = fromDt.ToString("dd-MMM-yy HH:mm")
        Dim toDtq As String = toDt.ToString("dd-MMM-yy HH:mm")
        'Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT DISTINCT Defect_Name FROM RCL_JCAP_SURFACE_INSPECTION where date_create between '" & fromDt & "' and '" & toDt & "' and Defect_Name !=''  ORDER BY DEFECT_NAME").Tables(0)
        Dim dt As DataTable = Nothing
        Dim dtd As DataTable = getdatatable("SELECT [Desc]  FROM [CRM_DEFECT_CODE] where process='CRCA' and selected=1")
        Dim filter As String = ""
        For i As Integer = 0 To dtd.Rows.Count - 1
            If i = dtd.Rows.Count - 1 Then
                filter &= "'" & dtd.Rows(i)(0) & "')"
            Else
                filter &= "'" & dtd.Rows(i)(0) & "', "
            End If
        Next
        Dim query As String = ""
        query = "Select distinct iql_grade from V_COIL_HOLD_RLS "
        query &= "inner join V_COLD_COIL On ccl_id_coil = chr_id_coil "
        query &= "inner join v_codes On cd_value = chr_cd_fnl_decsn "
        query &= "inner join v_quality on ccl_cd_qlty_aim=iql_cd_qlty "
        query &= "where "
        query &= "chr_id_coil In(Select distinct chr_id_coil from V_COIL_HOLD_RLS where "
        query &= "chr_ts_release between to_date('" & fromDtq & "','DD-MON-YY HH24:MI') and to_date('" & toDtq & "','DD-MON-YY HH24:MI') "
        query &= "and chr_remarks in ('Seconds-M','DownGraded-M','Diverted-M') and chr_cd_fnl_decsn <> 'null'  ) "
        query &= "and chr_cd_fnl_decsn=chr_cd_rsn_hold "
        query &= "and ccl_cd_prod = 'C01' "
        query &= "and CD_TYPE like 'C0015'"
        query &= "and cd_desc in (" & filter
        query &= " order by iql_grade"
        dt = objDataHandler.GetOracleData(query)
        'Dim dt As DataTable = objDataHandler.GetOracleData("Select DISTINCT(iql_grade) from v_quality inner join v_cold_coil On ccl_cd_qlty_aim=iql_cd_qlty where ccl_ts_creation between to_date('" & fromDtq & "','DD-MON-YY HH24:MI') and to_date('" & toDtq & "','DD-MON-YY HH24:MI') order by iql_grade")
        lstGrade.DataSource = dt
        lstGrade.DataTextField = "iql_grade"
        lstGrade.DataValueField = "iql_grade"
        lstGrade.DataBind()
        For Each lst As ListItem In lstGrade.Items
            lst.Selected = True
        Next
        'If dt.Rows.Count > 0 Then
        '    lstDefName.Items.FindByText("SCUMD").Selected = True
        'End If
    End Sub

    Function getSelectedData(ByRef lst As ListBox) As String
        Dim retVal As String = ""
        For Each lstItem As ListItem In lst.Items
            If lstItem.Selected = True Then
                retVal &= "," & lstItem.Text & ""
            End If
        Next

        If (retVal.Length > 0) Then
            Return retVal.Substring(1)
        Else
            Return retVal
        End If

    End Function

    Public Function fnQuerySelector() As String
        Dim dt As DataTable = getdatatable("SELECT [Desc]  FROM [CRM_DEFECT_CODE] where process='CRCA' and selected=1")
        Dim filter As String = ""
        For i As Integer = 0 To dt.Rows.Count - 1
            If i = dt.Rows.Count - 1 Then
                filter &= "'" & dt.Rows(i)(0) & "')"
            Else
                filter &= "'" & dt.Rows(i)(0) & "', "
            End If
        Next
        Dim strGrade As String = getSelectedData(lstGrade)
        Dim strTDC As String = getSelectedData(lstTdc)

        If strGrade.Length > 0 Then
            strGrade = "'" & strGrade.Replace(",", "','") & "'"
        Else
            strGrade = "''"
        End If

        If strTDC.Length > 0 Then
            strTDC = "'" & strTDC.Replace(",", "','") & "'"
        Else
            strTDC = "''"
        End If
        filter &= " and ccl_tdc_aim in (" & strTDC & ")"
        filter &= " and iql_grade in (" & strGrade & ")"
        Dim fromDt_dt As DateTime = hfFrom.Value
        Dim toDt_dt As DateTime = hfTo.Value
        Dim fromDt As String = fromDt_dt.ToString("dd-MMM-yy HH:mm")
        Dim toDt As String = toDt_dt.ToString("dd-MMM-yy HH:mm")
        'store coils for each defect
        Dim defectquery As String = "SELECT distinct[Defect_Group] FROM [CRM_DEFECT_CODE] where Selected=1 order by Defect_Group desc"
        Dim defectdt As DataTable = getdatatable(defectquery)
        For i As Integer = 0 To defectdt.Rows.Count - 1
            Dim defect As String = defectdt.Rows(i)(0)
            Dim dt1 As DataTable = getdatatable("SELECT [Desc]  FROM [CRM_DEFECT_CODE] where process='CRCA' and selected=1 and Defect_Group='" & defect & "'")
            Dim f As String = Nothing

            For j As Integer = 0 To dt1.Rows.Count - 1

                If j = dt1.Rows.Count - 1 Then
                    f &= "'" & dt1.Rows(j)(0) & "')"
                Else
                    f &= "'" & dt1.Rows(j)(0) & "', "
                End If
            Next
            f &= " and ccl_tdc_aim in (" & strTDC & ")"
            f &= " and iql_grade in (" & strGrade & ")"
            Dim q As String = ""
            If rdbtnUncoated.Checked = True And rdbtnDecision.Checked = True Then
                q = "select distinct chr_id_coil,ccl_ms_piece_actl from V_COIL_HOLD_RLS "
                q &= "inner join V_COLD_COIL on ccl_id_coil = chr_id_coil "
                q &= "inner join v_codes on cd_value = chr_cd_fnl_decsn "
                q &= "inner join v_quality on ccl_cd_qlty_aim=iql_cd_qlty "
                q &= "where "
                q &= "chr_id_coil in(select distinct chr_id_coil from V_COIL_HOLD_RLS where "
                q &= "chr_ts_release between to_date('" & fromDt & "','DD-MON-YY HH24:MI') and to_date('" & toDt & "','DD-MON-YY HH24:MI') "
                q &= "and chr_remarks in ('Seconds-M','DownGraded-M','Diverted-M') and chr_cd_fnl_decsn <> 'null'  ) "
                q &= "and chr_cd_fnl_decsn=chr_cd_rsn_hold "
                q &= "and ccl_cd_prod = 'C01' "
                q &= "and CD_TYPE like 'C0015'"
                q &= "and cd_desc in (" & f
            End If
            If defect = "ALKALI C/O" Then
                alkalidt = objDataHandler.GetOracleData(q)
            End If
            If defect = "MECH PROP NOT OK" Then
                mechdt = objDataHandler.GetOracleData(q)
            End If
            If defect = "RIS" Then
                risdt = objDataHandler.GetOracleData(q)
            End If
            If defect = "RUBBING MARK" Then
                rubbingdt = objDataHandler.GetOracleData(q)
            End If
            If defect = "RUST" Then
                rustdt = objDataHandler.GetOracleData(q)
            End If
            If defect = "SCUM" Then
                scumdt = objDataHandler.GetOracleData(q)
            End If
            If defect = "STICKER" Then
                stickerdt = objDataHandler.GetOracleData(q)
            End If
            If defect = "STRECHER STRAIN" Then
                strecherdt = objDataHandler.GetOracleData(q)
            End If

        Next


        Dim query As String = ""
        If rdbtnUncoated.Checked = True And rdbtnDecision.Checked = True Then
            query = "Select distinct chr_id_coil,(chr_cd_fnl_decsn),chr_remarks,chr_cd_rsn_hold,chr_ts_release,ccl_ms_piece_actl,cd_desc from V_COIL_HOLD_RLS "
            query &= "inner join V_COLD_COIL On ccl_id_coil = chr_id_coil "
            query &= "inner join v_codes On cd_value = chr_cd_fnl_decsn "
            query &= "inner join v_quality on ccl_cd_qlty_aim=iql_cd_qlty "
            query &= "where "
            query &= "chr_id_coil In(Select distinct chr_id_coil from V_COIL_HOLD_RLS where "
            query &= "chr_ts_release between to_date('" & fromDt & "','DD-MON-YY HH24:MI') and to_date('" & toDt & "','DD-MON-YY HH24:MI') "
            query &= "and chr_remarks in ('Seconds-M','DownGraded-M','Diverted-M') and chr_cd_fnl_decsn <> 'null'  ) "
            query &= "and chr_cd_fnl_decsn=chr_cd_rsn_hold "
            query &= "and ccl_cd_prod = 'C01' "
            query &= "and CD_TYPE like 'C0015'"
            query &= "and cd_desc in (" & filter
            lblgraph1.Text = rdbtnUncoated.Text & "(" & rdbtnDecision.Text & ")Tonnage"
        ElseIf rdbtnCoated.Checked = True And rdbtnDefect.Checked = True Then
            query = "select chr_id_coil,chr_ts_release,chr_cd_process,chr_cd_rsn_hold, chr_remarks from V_COIL_HOLD_RLS  "
            query &= "where "
            query &= "chr_ts_release between to_date('" & fromDt & "','DD-MON-YY HH24:MI') and to_date('" & toDt & "','DD-MON-YY HH24:MI') "
            query &= "and chr_cd_rsn_hold  in ('006') and chr_cd_process like ‘L' "
            query &= "order by chr_ts_release"
        ElseIf rdbtnCoated.Checked = True And rdbtnDecision.Checked = True Then
            query = "select distinct chr_id_coil,(chr_cd_fnl_decsn),chr_remarks,chr_cd_rsn_hold,chr_ts_release,ccl_ms_piece_actl,cd_desc from V_COIL_HOLD_RLS"
            query &= "inner join V_COLD_COIL on ccl_id_coil = chr_id_coil"
            query &= "inner join v_codes on cd_value = chr_cd_fnl_decsn "
            query &= "where "
            query &= "chr_id_coil in(select distinct chr_id_coil from V_COIL_HOLD_RLS where "
            query &= "chr_ts_release between to_date('" & fromDt & "','DD-MON-YY HH24:MI') and to_date('" & toDt & "','DD-MON-YY HH24:MI') "
            query &= "and chr_remarks in ('Seconds-M','DownGraded-M','Diverted-M') and chr_cd_fnl_decsn <> 'null'  ) "
            query &= "and chr_cd_fnl_decsn=chr_cd_rsn_hold "
            query &= "and ccl_cd_prod = 'C03' "
            query &= "and CD_TYPE like 'C0015'"
        ElseIf rdbtnUncoated.Checked = True And rdbtnDefect.Checked = True Then
            query = "select chr_id_coil,chr_ts_release,chr_cd_process,chr_cd_rsn_hold, chr_remarks from V_COIL_HOLD_RLS  "
            query &= "where "
            query &= "chr_ts_release between to_date('" & fromDt & "','DD-MON-YY HH24:MI') and to_date('" & toDt & "','DD-MON-YY HH24:MI') "
            query &= "and chr_cd_rsn_hold  in ('006') and chr_cd_process like ‘P' "
            query &= "order by chr_ts_release"
        Else
            UserMsgBoxWarning("Check your Selection")
        End If
        Return query
    End Function
    Public Sub PlotBarGraph(ByVal y As String, ByVal x As String, ByVal LiteralName As Literal, ByVal ContainerName As String)
        LiteralName.Text = ""
        Dim js As String = ""
        js &= " <script type='text/javascript'> var " & ContainerName & " = echarts.init(document.getElementById('" & ContainerName & "'));"
        js &= "option = {"
        js &= "grid: {left:   '3%',right:  '4%',bottom:  '10%',containLabel: true},"
        js &= "tooltip: {trigger: 'axis'},"
        js &= "toolbox: {show: true,feature: {dataZoom: {yAxisIndex: 'none'},restore: {},saveAsImage: {}}},"
        js &= "dataZoom: [{type: 'inside'}, {type: 'slider'}],"
        js &= "xAxis: {"
        js &= "type: 'category',"
        js &= "axisLabel: {fontWeight:'bold',rotate: 45},"
        js &= "data: [" & x & "]},"
        js &= "yAxis: {type: 'value',name: 'Quantity(Ton)',axisLabel : { formatter: '{value}',fontWeight:'bold',fontSize:15},nameLocation: 'middle',nameGap: 35,nameTextStyle: {fontWeight:'bold',fontSize:15}},"
        js &= "series: [{"
        js &= "data: [" & y & "],"
        js &= "type: 'bar'"
        js &= "}]"
        js &= "};"
        js &= ContainerName & ".setOption(option);"
        js &= ContainerName & ".on('click', function (params) {bar2( params.name );});"
        js &= "$(window).resize(function() {" & ContainerName & ".resize(); });</script>"
        LiteralName.Text = js
    End Sub
    Public Sub PlotLinegraph(ByVal dt1 As DataTable, ByVal LiteralName As Literal, ByVal ContainerName As String)
        LiteralName.Text = ""
        Dim js As String = ""
        js &= " <script type='text/javascript'> var " & ContainerName & " = echarts.init(document.getElementById('" & ContainerName & "'));"
        js &= "option={"
        js &= "tooltip: {trigger:  'item', formatter:function(params){  return params.seriesName + '<br />' + params.value+ '<br />' + '(' + params.name + ')';}},"
        js &= "legend: {type: 'scroll',width:400},"
        js &= "grid: {left:   '3%',right:  '4%',bottom:  '10%',containLabel: true},"
        'js &= "legend: {data: ['PLTCM','ECL','BAF','SPM']},"
        js &= "toolbox: {show: true,feature: {dataZoom: {yAxisIndex: 'none'},restore: {},saveAsImage: {}}},"
        js &= "xAxis:{"
        js &= "type:   'category',axisLabel: {fontWeight:'bold',rotate: 45},"
        js &= "data:['PLTCM','ECL','BAF','SPM']"
        js &= "},"
        js &= "yAxis:{"
        js &= "type:   'time'  ,"
        js &= "name: 'Processing Date (Month-Date-Year)',axisLabel : { formatter: '{value}',fontWeight:'bold',fontSize:15},nameLocation: 'middle',nameGap: 50,nameTextStyle: {fontWeight:'bold',fontSize:15}"
        js &= "},"
        js &= "series:["

        Dim s As String
        Dim filter As String = ""
        For i As Integer = 0 To dt1.Rows.Count - 1
            If i = dt1.Rows.Count - 1 Then
                filter &= "CR_COIL_ID like '" & dt1.Rows(i)(0).Substring(0, 6) & "%'"
            Else
                filter &= "CR_COIL_ID like '" & dt1.Rows(i)(0).Substring(0, 6) & "%' or "
            End If
        Next
        ' s = "SELECT [CR_COIL_ID] ,[TCM_ROLLING_DT],[ECL_DATETIME],[SPM_DATETIME],[BAF_DATETIME] FROM [CRM_HR_CR_RLN] where " & filter
        s = "SELECT [CR_COIL_ID] ,nullif([TCM_ROLLING_DT],'1900-01-01 00:00:00.000')as TCM_ROLLING_DT,nullif([ECL_DATETIME],'1900-01-01 00:00:00.000')as ECL_DATETIME,nullif([BAF_DATETIME],'1900-01-01 00:00:00.000') as BAF_DATETIME,nullif([SPM_DATETIME],'1900-01-01 00:00:00.000') as SPM_DATETIME FROM [CRM_HR_CR_RLN] where " & filter
        Dim dt As DataTable = getdatatable(s)
        For i As Integer = 0 To dt.Rows.Count - 1
            If i = dt.Rows.Count - 1 Then
                js &= "{type: 'line',"
                js &= "name:   '" & dt.Rows(i)(0) & "', "
                If IsDBNull(dt.Rows(i)(1)) Then
                    js &= "data: ['',"
                Else
                    js &= "data: ['" & (Convert.ToDateTime(dt.Rows(i)(1))).ToString("yyyy-MM-dd") & "',"
                End If
                If IsDBNull(dt.Rows(i)(2)) Then
                    js &= "'',"
                Else
                    js &= "'" & (Convert.ToDateTime(dt.Rows(i)(2))).ToString("yyyy-MM-dd") & "',"
                End If
                If IsDBNull(dt.Rows(i)(3)) Then
                    js &= "'',"
                Else
                    js &= "'" & (Convert.ToDateTime(dt.Rows(i)(3))).ToString("yyyy-MM-dd") & "',"
                End If
                If IsDBNull(dt.Rows(i)(4)) Then
                    js &= "'']"
                Else
                    js &= "'" & (Convert.ToDateTime(dt.Rows(i)(4))).ToString("yyyy-MM-dd") & "']"
                End If
                js &= "}"
            Else
                js &= "{type: 'line',"
                js &= "name:   '" & dt.Rows(i)(0) & "',"
                ' js &= "name:   '" & dt.Rows(i)(0) & ",PltcmDate:" & (Convert.ToDateTime(dt.Rows(i)(1))).ToString("yyyy-MM-dd") & ",EclDate:" & (Convert.ToDateTime(dt.Rows(i)(2))).ToString("yyyy-MM-dd") & ",BafDate:" & (Convert.ToDateTime(dt.Rows(i)(3))).ToString("yyyy-MM-dd") & ",SpmDate:" & (Convert.ToDateTime(dt.Rows(i)(4))).ToString("yyyy-MM-dd") & "',"
                If IsDBNull(dt.Rows(i)(1)) Then
                    js &= "data: ['',"
                Else
                    js &= "data: ['" & (Convert.ToDateTime(dt.Rows(i)(1))).ToString("yyyy-MM-dd") & "',"
                End If
                If IsDBNull(dt.Rows(i)(2)) Then
                    js &= "'',"
                Else
                    js &= "'" & (Convert.ToDateTime(dt.Rows(i)(2))).ToString("yyyy-MM-dd") & "',"
                End If
                If IsDBNull(dt.Rows(i)(3)) Then
                    js &= "'',"
                Else
                    js &= "'" & (Convert.ToDateTime(dt.Rows(i)(3))).ToString("yyyy-MM-dd") & "',"
                End If
                If IsDBNull(dt.Rows(i)(4)) Then
                    js &= "'']"
                Else
                    js &= "'" & (Convert.ToDateTime(dt.Rows(i)(4))).ToString("yyyy-MM-dd") & "']"
                End If
                'js &= "data: ['" & (Convert.ToDateTime(dt.Rows(i)(1))).ToString("yyyy-MM-dd") & "','" & (Convert.ToDateTime(dt.Rows(i)(2))).ToString("yyyy-MM-dd") & "','" & (Convert.ToDateTime(dt.Rows(i)(3))).ToString("yyyy-MM-dd") & "','" & (Convert.ToDateTime(dt.Rows(i)(4))).ToString("yyyy-MM-dd") & "']"
                js &= "},"
            End If
        Next
        js &= "]"
        js &= "};"
        js &= ContainerName & ".setOption(option);"
        'js &= ContainerName & ".on('click', function (params) {heat( params.name );});"
        js &= "$(window).resize(function() {" & ContainerName & ".resize(); });</script>"
        LiteralName.Text = js
        pltcmto = ""
        pltcmfrom = ""
        eclto = ""
        eclfrom = ""
        bafto = ""
        baffrom = ""
        spmto = ""
        spmfrom = ""
        Dim datequery As String = "select max(nullif([TCM_ROLLING_DT],'1900-01-01 00:00:00.000')) as tcmmax,min(nullif([TCM_ROLLING_DT],'1900-01-01 00:00:00.000')) as tcmmin,"
        datequery &= " max(nullif([ECL_DATETIME],'1900-01-01 00:00:00.000')) as eclmax,min(nullif([ECL_DATETIME],'1900-01-01 00:00:00.000')) as eclmin,"
        datequery &= "max(nullif([BAF_DATETIME],'1900-01-01 00:00:00.000')) as bafmax,min(nullif([BAF_DATETIME],'1900-01-01 00:00:00.000')) as bafmin,"
        datequery &= "max(nullif([SPM_DATETIME],'1900-01-01 00:00:00.000')) as spmmax,min(nullif([SPM_DATETIME],'1900-01-01 00:00:00.000')) as spmmin from CRM_HR_CR_RLN  where " & filter
        Dim datedt As DataTable = getdatatable(datequery)
        If Not IsDBNull(datedt.Rows(0)(0)) Then
            pltcmto = datedt.Rows(0)(0)
        End If
        If Not IsDBNull(datedt.Rows(0)(1)) Then
            pltcmfrom = datedt.Rows(0)(1)
        End If
        If Not IsDBNull(datedt.Rows(0)(2)) Then
            eclto = datedt.Rows(0)(2)
        End If
        If Not IsDBNull(datedt.Rows(0)(3)) Then
            eclfrom = datedt.Rows(0)(3)
        End If
        If Not IsDBNull(datedt.Rows(0)(4)) Then
            bafto = datedt.Rows(0)(4)
        End If
        If Not IsDBNull(datedt.Rows(0)(5)) Then
            baffrom = datedt.Rows(0)(5)
        End If
        If Not IsDBNull(datedt.Rows(0)(6)) Then
            spmto = datedt.Rows(0)(6)
        End If
        If Not IsDBNull(datedt.Rows(0)(7)) Then
            spmfrom = datedt.Rows(0)(7)
        End If
    End Sub
    Function getdatatable(ByVal query As String) As DataTable
        Dim fndatatable As New DataTable
        Dim connection As String = "Password=Welcome@135;Persist Security Info=True;User ID=153521;Initial Catalog=FP_PROCESS_DATA;Data Source=176.0.0.60\lptgsqldev"
        Using con As New SqlConnection(connection)
            Using cmd As New SqlCommand(query, con)
                cmd.CommandType = CommandType.Text
                Using sda As New SqlDataAdapter(cmd)
                    'Using dt As New DataTable()
                    sda.Fill(fndatatable)
                    'End Using
                End Using
            End Using
        End Using
        Return fndatatable
    End Function

    Private Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click
        'empty all dts
        Lit2.Text = ""
        Lit3.Text = ""
        lblgraph2.Text = Nothing
        lblmultibar.Text = Nothing
        scumdt = Nothing
        risdt = Nothing
        rustdt = Nothing
        alkalidt = Nothing
        rubbingdt = Nothing
        stickerdt = Nothing
        strecherdt = Nothing
        mechdt = Nothing
        'dynamicdiv("")
        Dim mainquery As String = fnQuerySelector()
        Dim dt As DataTable = objDataHandler.GetOracleData(mainquery)
        Dim bardt As DataTable = objDataHandler.GetOracleData("select cd_desc,sum(ccl_ms_piece_actl) as ccl_ms_piece_actl from ( " & mainquery & " )group by cd_desc order by ccl_ms_piece_actl desc")
        Dim xaxis As String = ""
        Dim yaxis As String = ""
        Dim dt1 As DataTable = getdatatable("SELECT [Desc],[Defect_Group]  FROM [CRM_DEFECT_CODE] where process='CRCA' and selected=1")

        '  1st method sum without desc
        'Dim Series() = (From row In dt Select col = row.Field(Of String)("cd_desc") Distinct).ToArray
        'For i As Integer = 0 To Series.Length - 1
        '    Dim x = i
        '    Dim query = From val In dt.AsEnumerable() Where val.Field(Of String)("cd_desc") = Series(x) Select val
        '    Dim dtValue = query.CopyToDataTable()
        '    Dim result As Decimal = dtValue.AsEnumerable().Sum(Function(row) row.Field(Of Single)("ccl_ms_piece_actl"))

        '    If i = Series.Length - 1 Then
        '        yaxis &= result
        '        xaxis &= "'" & Series(i) & "'"
        '    Else
        '        yaxis &= result & ","
        '        xaxis &= "'" & Series(i) & "',"
        '    End If
        'Next

        ' 2nd method sum cd with desc
        'For i As Integer = 0 To bardt.Rows.Count - 1
        '    If i = bardt.Rows.Count - 1 Then
        '        yaxis &= bardt.Rows(i)(0)
        '        xaxis &= "'" & bardt.Rows(i)(1) & "'"
        '    Else
        '        yaxis &= bardt.Rows(i)(0) & ","
        '        xaxis &= "'" & bardt.Rows(i)(1) & "',"
        '    End If
        'Next

        ' 3rd mehod sum and show defect group
        bardt.Columns.Add(New DataColumn("Defect_Group", GetType(String)))
        For i As Integer = 0 To bardt.Rows.Count - 1
            For j As Integer = 0 To dt1.Rows.Count - 1
                If bardt.Rows(i)(0) = dt1.Rows(j)(0) Then
                    bardt.Rows(i)(2) = dt1.Rows(j)(1)
                End If
            Next
        Next
        Dim Series() = (From row In bardt Select col = row.Field(Of String)("Defect_Group") Distinct).ToArray
        For i As Integer = 0 To Series.Length - 1
            Dim x = i
            Dim query = From val In bardt.AsEnumerable() Where val.Field(Of String)("Defect_Group") = Series(x) Select val
            Dim dtValue = query.CopyToDataTable()
            Dim result As Decimal = dtValue.AsEnumerable().Sum(Function(row) row.Field(Of Decimal)("ccl_ms_piece_actl"))

            If i = Series.Length - 1 Then
                yaxis &= result
                xaxis &= "'" & Series(i) & "'"
            Else
                yaxis &= result & ","
                xaxis &= "'" & Series(i) & "',"
            End If
        Next

        PlotBarGraph(yaxis, xaxis, Lit1, "main1")
    End Sub

    Public Sub plotMultipleBar(ByVal data1 As String, ByVal data2 As String, ByVal data3 As String, ByVal data4 As String, ByVal ymax As Integer, ByVal xmin As String, ByVal xmax As String, ByVal ContainerName As String, ByVal LiteralName As Literal)
        Try
            LiteralName.Text = ""
            Dim js As String = ""
            js &= " <script type='text/javascript'> var " & ContainerName & " = echarts.init(document.getElementById('" & ContainerName & "'));"
            js &= "data1 =[" & data1 & "];"
            js &= "data2 =[" & data2 & "];"
            js &= "data3 =[" & data3 & "];"
            js &= "data4 =[" & data4 & "];"
            'js &= "var dateList = data.map(function (item) {return item[0];});"
            'js &= "var valueList = data.map(function (item) {return item[1];});"
            js &= "option = {"
            js &= "title: [{top: '0%',left: 'center',text: 'PLTCM'},{top: '25%',left: 'center',text: 'ECL'},{top: '50%',left: 'center',text: 'BAF'},{top: '75%',left: 'center',text: 'SPM'}],"
            js &= "tooltip: {trigger: 'axis'},"
            js &= "toolbox: {feature: {dataZoom: {yAxisIndex: 'none'},restore: {},saveAsImage: {}}},"
            js &= "dataZoom: [{type: 'slider',xAxisIndex: [0, 1,2,3],filterMode: 'empty'}],"
            js &= "xAxis: [{type: 'time',min:'" & xmin & "',max:'" & xmax & "'},{type:'time',gridIndex: 1,min:'" & xmin & "',max:'" & xmax & "'},{type:'time',gridIndex: 2,min:'" & xmin & "',max:'" & xmax & "'},{type:'time',gridIndex: 3,min:'" & xmin & "',max:'" & xmax & "'}],"
            js &= "yAxis: [{splitLine: {show: false},max:" & ymax & ",name: 'Defect Quantity(Ton)',axisLabel : { formatter: '{value}',fontWeight:'bold',fontSize:15},nameLocation: 'middle',nameGap: 35,nameTextStyle: {fontWeight:'bold',fontSize:12}},"
            js &= "{splitLine: {show: false},gridIndex: 1,max:" & ymax & ",name: 'Defect Quantity(Ton)',axisLabel : { formatter: '{value}',fontWeight:'bold',fontSize:15},nameLocation: 'middle',nameGap: 35,nameTextStyle: {fontWeight:'bold',fontSize:12}},"
            js &= "{splitLine: {show: false},gridIndex: 2,max:" & ymax & ",name: 'Defect Quantity(Ton)',axisLabel : { formatter: '{value}',fontWeight:'bold',fontSize:15},nameLocation: 'middle',nameGap: 35,nameTextStyle: {fontWeight:'bold',fontSize:12}},"
            js &= "{splitLine: {show: false},gridIndex: 3,max:" & ymax & ",name: 'Defect Quantity(Ton)',axisLabel : { formatter: '{value}',fontWeight:'bold',fontSize:15},nameLocation: 'middle',nameGap: 35,nameTextStyle: {fontWeight:'bold',fontSize:12}}],"
            js &= "grid: [{top: '5%',bottom: '80%'},{top: '30%',bottom: '55%'},{top: '55%',bottom: '30%'},{top: '80%',bottom: '5%'}],"
            js &= "series: [{type: 'bar',showSymbol: false,data: data1,barWidth:5},{type: 'bar',showSymbol: false,data: data2,xAxisIndex: 1,yAxisIndex: 1,barWidth:5},{type: 'bar',showSymbol: false,data: data3,xAxisIndex: 2,yAxisIndex: 2,barWidth:5},{type: 'bar',showSymbol: false,data: data4,xAxisIndex: 3,yAxisIndex: 3,barWidth:5}]"
            js &= "};"
            js &= ContainerName & ".setOption(option);"
            'js &= ContainerName & ".on('click', function (params) {heat( params.name );});"
            js &= "$(window).resize(function() {" & ContainerName & ".resize(); });</script>"
            LiteralName.Text = js
        Catch ex As Exception

        End Try
    End Sub
    Public Sub Multibar(ByVal dt As DataTable)
        Dim s As String = ""
        Dim filter As String = ""
        For i As Integer = 0 To dt.Rows.Count - 1
            If i = dt.Rows.Count - 1 Then
                filter &= "CR_COIL_ID like '" & dt.Rows(i)(0).Substring(0, 6) & "%'"
            Else
                filter &= "CR_COIL_ID like '" & dt.Rows(i)(0).Substring(0, 6) & "%' or "
            End If
        Next
        ' s = "SELECT [CR_COIL_ID] ,[TCM_ROLLING_DT],[ECL_DATETIME],[SPM_DATETIME],[BAF_DATETIME] FROM [CRM_HR_CR_RLN] where " & filter
        s = "SELECT [CR_COIL_ID] ,nullif(CONVERT(varchar,[TCM_ROLLING_DT],111),'1900/01/01')as TCM_ROLLING_DT,nullif(CONVERT(varchar,[ECL_DATETIME],111),'1900/01/01')as ECL_DATETIME,nullif(CONVERT(varchar,[BAF_DATETIME],111),'1900/01/01') as BAF_DATETIME,nullif(CONVERT(varchar,[SPM_DATETIME],111),'1900/01/01') as SPM_DATETIME FROM [CRM_HR_CR_RLN] where " & filter
        's = "SELECT [CR_COIL_ID] ,nullif([TCM_ROLLING_DT],'1900-01-01 00:00:00.000')as TCM_ROLLING_DT,nullif([ECL_DATETIME],'1900-01-01 00:00:00.000')as ECL_DATETIME,nullif([BAF_DATETIME],'1900-01-01 00:00:00.000') as BAF_DATETIME,nullif([SPM_DATETIME],'1900-01-01 00:00:00.000') as SPM_DATETIME FROM [CRM_HR_CR_RLN] where " & filter
        Dim tempdt As DataTable = getdatatable(s)
        tempdt.Columns.Add(New DataColumn("Tonnage", GetType(Decimal)))
        For i As Integer = 0 To tempdt.Rows.Count - 1
            For j As Integer = 0 To dt.Rows.Count - 1
                If tempdt.Rows(i)("CR_COIL_ID").Substring(0, 6) = dt.Rows(j)("chr_id_coil").Substring(0, 6) Then
                    tempdt.Rows(i)("Tonnage") = dt.Rows(j)("ccl_ms_piece_actl")
                End If
            Next
        Next

        'Dim MaxValue As Double = tempdt.AsEnumerable().Max(Function(row) Convert.ToDouble(row("Tonnage")))
        'Dim Max As Integer = Math.Round(MaxValue / 10) * 10
        'PlotLinegraph(dt, Lit2, "main2")
        Dim data1 As String = ""
        Dim data2 As String = ""
        Dim data3 As String = ""
        Dim data4 As String = ""
        'use data directly
        'For i As Integer = 0 To tempdt.Rows.Count - 1
        '    If Not (tempdt.Rows(i)(1).ToString() = "") Then
        '        'data1 &= "['" & Convert.ToDateTime(tempdt.Rows(i)(1)).ToString("yyyy-MM-dd") & "'," & tempdt.Rows(i)("Tonnage") & "],"
        '    End If
        '    If Not (tempdt.Rows(i)(2).ToString() = "") Then
        '        data2 &= "['" & Convert.ToDateTime(tempdt.Rows(i)(2)).ToString("yyyy-MM-dd") & "'," & tempdt.Rows(i)("Tonnage") & "],"
        '    End If
        '    If Not (tempdt.Rows(i)(3).ToString() = "") Then
        '        data3 &= "['" & Convert.ToDateTime(tempdt.Rows(i)(3)).ToString("yyyy-MM-dd") & "'," & tempdt.Rows(i)("Tonnage") & "],"
        '    End If
        '    If Not (tempdt.Rows(i)(4).ToString() = "") Then
        '        data4 &= "['" & Convert.ToDateTime(tempdt.Rows(i)(4)).ToString("yyyy-MM-dd") & "'," & tempdt.Rows(i)("Tonnage") & "],"
        '    End If
        'Next
        Dim tcmdt As DataTable = New DataTable()
        'Dim dr As DataRow
        dt.TableName = "tcmdt"
        tcmdt.Columns.Add(New DataColumn("TCM_ROLLING_DT", GetType(Date)))
        tcmdt.Columns.Add(New DataColumn("Tonnage", GetType(Decimal)))
        'dr = PLDT.NewRow()
        'PLDT.Rows.Add(dr)
        ViewState("tcmdt") = tcmdt

        Dim ecldt As DataTable = New DataTable()
        dt.TableName = "ecldt"
        ecldt.Columns.Add(New DataColumn("ECL_DATETIME", GetType(Date)))
        ecldt.Columns.Add(New DataColumn("Tonnage", GetType(Decimal)))
        ViewState("ecldt") = ecldt

        Dim bafdt As DataTable = New DataTable()
        dt.TableName = "bafdt"
        bafdt.Columns.Add(New DataColumn("BAF_DATETIME", GetType(Date)))
        bafdt.Columns.Add(New DataColumn("Tonnage", GetType(Decimal)))
        ViewState("bafdt") = bafdt

        Dim spmdt As DataTable = New DataTable()
        dt.TableName = "spmdt"
        spmdt.Columns.Add(New DataColumn("SPM_DATETIME", GetType(Date)))
        spmdt.Columns.Add(New DataColumn("Tonnage", GetType(Decimal)))
        ViewState("spmdt") = spmdt


        For i As Integer = 0 To tempdt.Rows.Count - 1
            If Not (tempdt.Rows(i)(1).ToString() = "") Then
                tcmdt.Rows.Add(Convert.ToDateTime(tempdt.Rows(i)(1)).ToString("yyyy-MM-dd"), tempdt.Rows(i)("Tonnage"))
                'data1 &= "['" & Convert.ToDateTime(tempdt.Rows(i)(1)).ToString("yyyy-MM-dd") & "'," & tempdt.Rows(i)("Tonnage") & "],"
            End If
            If Not (tempdt.Rows(i)(2).ToString() = "") Then
                ecldt.Rows.Add(Convert.ToDateTime(tempdt.Rows(i)(2)).ToString("yyyy-MM-dd"), tempdt.Rows(i)("Tonnage"))
                'data2 &= "['" & Convert.ToDateTime(tempdt.Rows(i)(2)).ToString("yyyy-MM-dd") & "'," & tempdt.Rows(i)("Tonnage") & "],"
            End If
            If Not (tempdt.Rows(i)(3).ToString() = "") Then
                bafdt.Rows.Add(Convert.ToDateTime(tempdt.Rows(i)(3)).ToString("yyyy-MM-dd"), tempdt.Rows(i)("Tonnage"))
                'data3 &= "['" & Convert.ToDateTime(tempdt.Rows(i)(3)).ToString("yyyy-MM-dd") & "'," & tempdt.Rows(i)("Tonnage") & "],"
            End If
            If Not (tempdt.Rows(i)(4).ToString() = "") Then
                spmdt.Rows.Add(Convert.ToDateTime(tempdt.Rows(i)(4)).ToString("yyyy-MM-dd"), tempdt.Rows(i)("Tonnage"))
                'data4 &= "['" & Convert.ToDateTime(tempdt.Rows(i)(4)).ToString("yyyy-MM-dd") & "'," & tempdt.Rows(i)("Tonnage") & "],"
            End If
        Next

        Dim d_min1 As Date = tcmdt.AsEnumerable().[Select](Function(cols) cols.Field(Of DateTime)(0)).OrderBy(Function(p) p.Ticks).FirstOrDefault()
        Dim d_max1 As Date = tcmdt.AsEnumerable().[Select](Function(cols) cols.Field(Of DateTime)(0)).OrderByDescending(Function(p) p.Ticks).FirstOrDefault()
        Dim d_min2 As Date = ecldt.AsEnumerable().[Select](Function(cols) cols.Field(Of DateTime)(0)).OrderBy(Function(p) p.Ticks).FirstOrDefault()
        Dim d_max2 As Date = ecldt.AsEnumerable().[Select](Function(cols) cols.Field(Of DateTime)(0)).OrderByDescending(Function(p) p.Ticks).FirstOrDefault()
        Dim d_min3 As Date = bafdt.AsEnumerable().[Select](Function(cols) cols.Field(Of DateTime)(0)).OrderBy(Function(p) p.Ticks).FirstOrDefault()
        Dim d_max3 As Date = bafdt.AsEnumerable().[Select](Function(cols) cols.Field(Of DateTime)(0)).OrderByDescending(Function(p) p.Ticks).FirstOrDefault()
        Dim d_min4 As Date = spmdt.AsEnumerable().[Select](Function(cols) cols.Field(Of DateTime)(0)).OrderBy(Function(p) p.Ticks).FirstOrDefault()
        Dim d_max4 As Date = spmdt.AsEnumerable().[Select](Function(cols) cols.Field(Of DateTime)(0)).OrderByDescending(Function(p) p.Ticks).FirstOrDefault()
        Dim xmin As Date = d_min1
        Dim xmax As Date = d_max1
        Dim max As Double = 0

        If DateDiff(DateInterval.Day, d_min2, xmin) > 0 Then
            xmin = d_min2
        End If
        If DateDiff(DateInterval.Day, xmax, d_max2) > 0 Then
            xmax = d_max2
        End If
        If DateDiff(DateInterval.Day, d_min3, xmin) > 0 Then
            xmin = d_min3
        End If
        If DateDiff(DateInterval.Day, xmax, d_max3) > 0 Then
            xmax = d_max3
        End If
        If DateDiff(DateInterval.Day, d_min4, xmin) > 0 Then
            xmin = d_min4
        End If
        If DateDiff(DateInterval.Day, xmax, d_max4) > 0 Then
            xmax = d_max4
        End If
        'Dim recentTen As DataTable = tempdt.AsEnumerable().OrderByDescending(Function(r) r.Field(Of DateTime)("TCM_ROLLING_DT")).GroupBy(Function(r) r.Field(Of DateTime)("TCM_ROLLING_DT")).[Select](Function(g) g.First()).CopyToDataTable()
        Dim Series1() = (From row In tcmdt Select col = row.Field(Of DateTime)("TCM_ROLLING_DT") Distinct Order By Asc("TCM_ROLLING_DT")).ToArray
        'Order By val.Field(Of Date)("TCM_ROLLING_DT") Ascending
        For i As Integer = 0 To Series1.Length - 1
            Dim x = i
            Dim query = From val In tcmdt.AsEnumerable() Where val.Field(Of DateTime)("TCM_ROLLING_DT") = Series1(x) Select val
            Dim dtValue = query.CopyToDataTable()
            Dim result1 As Decimal = dtValue.AsEnumerable().Sum(Function(row) row.Field(Of Decimal)("Tonnage"))
            If result1 > max Then
                max = result1
            End If
            If i = Series1.Length - 1 Then
                data1 &= "['" & Convert.ToDateTime(Series1(i)).ToString("yyyy-MM-dd") & "'," & result1 & "]"
            Else
                data1 &= "['" & Convert.ToDateTime(Series1(i)).ToString("yyyy-MM-dd") & "'," & result1 & "],"
            End If
        Next
        Dim Series2() = (From row In ecldt Select col = row.Field(Of DateTime)("ECL_DATETIME") Distinct Order By Asc("ECL_DATETIME")).ToArray
        'Order By val.Field(Of Date)("TCM_ROLLING_DT") Ascending
        For i As Integer = 0 To Series2.Length - 1
            Dim x = i
            Dim query = From val In ecldt.AsEnumerable() Where val.Field(Of DateTime)("ECL_DATETIME") = Series2(x) Select val
            Dim dtValue = query.CopyToDataTable()
            Dim result1 As Decimal = dtValue.AsEnumerable().Sum(Function(row) row.Field(Of Decimal)("Tonnage"))
            If result1 > max Then
                max = result1
            End If
            If i = Series2.Length - 1 Then
                data2 &= "['" & Convert.ToDateTime(Series2(i)).ToString("yyyy-MM-dd") & "'," & result1 & "]"
            Else
                data2 &= "['" & Convert.ToDateTime(Series2(i)).ToString("yyyy-MM-dd") & "'," & result1 & "],"
            End If
        Next
        Dim Series3() = (From row In bafdt Select col = row.Field(Of DateTime)("BAF_DATETIME") Distinct Order By Asc("BAF_DATETIME")).ToArray
        'Order By val.Field(Of Date)("TCM_ROLLING_DT") Ascending
        For i As Integer = 0 To Series3.Length - 1
            Dim x = i
            Dim query = From val In bafdt.AsEnumerable() Where val.Field(Of DateTime)("BAF_DATETIME") = Series3(x) Select val
            Dim dtValue = query.CopyToDataTable()
            Dim result1 As Decimal = dtValue.AsEnumerable().Sum(Function(row) row.Field(Of Decimal)("Tonnage"))
            If result1 > max Then
                max = result1
            End If
            If i = Series3.Length - 1 Then
                data3 &= "['" & Convert.ToDateTime(Series3(i)).ToString("yyyy-MM-dd") & "'," & result1 & "]"
            Else
                data3 &= "['" & Convert.ToDateTime(Series3(i)).ToString("yyyy-MM-dd") & "'," & result1 & "],"
            End If
        Next
        Dim Series4() = (From row In spmdt Select col = row.Field(Of DateTime)("SPM_DATETIME") Distinct Order By Asc("SPM_DATETIME")).ToArray
        'Order By val.Field(Of Date)("TCM_ROLLING_DT") Ascending
        For i As Integer = 0 To Series4.Length - 1
            Dim x = i
            Dim query = From val In spmdt.AsEnumerable() Where val.Field(Of DateTime)("SPM_DATETIME") = Series4(x) Select val
            Dim dtValue = query.CopyToDataTable()
            Dim result1 As Decimal = dtValue.AsEnumerable().Sum(Function(row) row.Field(Of Decimal)("Tonnage"))
            If result1 > max Then
                max = result1
            End If
            If i = Series4.Length - 1 Then
                data4 &= "['" & Convert.ToDateTime(Series4(i)).ToString("yyyy-MM-dd") & "'," & result1 & "]"
            Else
                data4 &= "['" & Convert.ToDateTime(Series4(i)).ToString("yyyy-MM-dd") & "'," & result1 & "],"
            End If
        Next
        Dim ymax As Integer = Math.Ceiling(max / 10) * 10
        Dim x_min As String = xmin.ToString("yyyy-MM-dd")
        Dim x_max As String = xmax.ToString("yyyy-MM-dd")
        plotMultipleBar(data1, data2, data3, data4, ymax, x_min, x_max, "main3", Lit3)
    End Sub

    Private Sub btnchangegrade_Click(sender As Object, e As EventArgs) Handles btnchangegrade.Click
        Dim fromDt As String = hfFrom.Value
        Dim toDt As String = CDate(hfTo.Value).ToString("yyyy-MM-dd 06:00:00")
        Lit1.Text = ""
        Lit2.Text = ""
        Lit3.Text = ""
        lblgraph1.Text = ""
        lblgraph2.Text = ""
        lblmultibar.Text = ""
        lstTdc.Visible = True
        LoadTdc(fromDt, toDt)
    End Sub

End Class
