﻿
Imports System.Data
Imports System.Data.SqlClient
Imports System.Math

Partial Class CRM_DailyReport_2
    Inherits System.Web.UI.Page
    Dim objDataHandler As New DataHandler
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub

    Sub UserMsgBoxSuccess(ByVal Message As String, ByVal Url As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalertandredirect('" + Message + "', '" + Url + "');", True)
    End Sub

    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub

    Public Shared scumdt As DataTable
    Public Shared risdt As DataTable
    Public Shared rustdt As DataTable
    Public Shared alkalidt As DataTable
    Public Shared rubbingdt As DataTable
    Public Shared stickerdt As DataTable
    Public Shared strecherdt As DataTable
    Public Shared mechdt As DataTable
    'Public Shared spmdt As DataTable
    Public Shared pltcmfrom As String
    Public Shared pltcmto As String
    Public Shared eclfrom As String
    Public Shared eclto As String
    Public Shared baffrom As String
    Public Shared bafto As String
    Public Shared spmfrom As String
    Public Shared spmto As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim fromDt As String = DateTime.Now.AddDays(-29).ToString("yyyy-MM-dd 06:00:00")
            Dim toDt As String = DateTime.Now.ToString("yyyy-MM-dd 06:00:00")
            Dim orfrom As DateTime = DateTime.Now.AddDays(-29)
            Dim orto As DateTime = DateTime.Now.ToString("yyyy-MM-dd 06:00:00")
            LoadGrade(orfrom, orto)
            ' LoadTdc(orfrom, orto)

            hfFrom.Value = fromDt
            hfTo.Value = toDt
            lblDefectdrop.Visible = False
            ddlDefectdrop.Visible = False
        End If

        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
                If (p = "d") Then
                    Dim fromDt As String = hfFrom.Value
                    Dim toDt As String = CDate(hfTo.Value).ToString("yyyy-MM-dd 06:00:00")
                    LoadGrade(fromDt, toDt)
                    hfFrom.Value = fromDt
                    hfTo.Value = toDt
                    lstTdc.Visible = False
                    Lit1.Text = ""
                    dynamicdiv("")
                    lblDefectdrop.Visible = False
                    ddlDefectdrop.Visible = False

                End If
            Catch ex As Exception
                Throw ex
            End Try

        End If
    End Sub

    Sub LoadTdc(ByVal fromDt As DateTime, ByVal toDt As DateTime)

        Dim fromDtq As String = fromDt.ToString("dd-MMM-yy HH:mm")
        Dim toDtq As String = toDt.ToString("dd-MMM-yy HH:mm")
        Dim dt As DataTable = Nothing
        Dim strGrade As String = getSelectedData(lstGrade)

        If strGrade.Length > 0 Then
            strGrade = "'" & strGrade.Replace(",", "','") & "'"
        Else
            strGrade = "''"
        End If
        Dim dtd As DataTable = getdatatable("SELECT [Desc]  FROM [CRM_DEFECT_CODE] where process='CRCA' and selected=1")
        Dim filter As String = ""
        For i As Integer = 0 To dtd.Rows.Count - 1
            If i = dtd.Rows.Count - 1 Then
                filter &= "'" & dtd.Rows(i)(0) & "')"
            Else
                filter &= "'" & dtd.Rows(i)(0) & "', "
            End If
        Next
        filter &= " and iql_grade in (" & strGrade & ")"
        Dim query As String = ""
        query = "Select distinct ccl_tdc_aim from V_COIL_HOLD_RLS "
        query &= "inner join V_COLD_COIL On ccl_id_coil = chr_id_coil "
        query &= "inner join v_codes On cd_value = chr_cd_fnl_decsn "
        query &= "inner join v_quality on ccl_cd_qlty_aim=iql_cd_qlty "
        query &= "where "
        query &= "chr_id_coil In(Select distinct chr_id_coil from V_COIL_HOLD_RLS where "
        query &= "chr_ts_release between to_date('" & fromDtq & "','DD-MON-YY HH24:MI') and to_date('" & toDtq & "','DD-MON-YY HH24:MI') "
        query &= "and chr_remarks in ('Seconds-M','DownGraded-M','Diverted-M') and chr_cd_fnl_decsn <> 'null'  ) "
        query &= "and chr_cd_fnl_decsn=chr_cd_rsn_hold "
        query &= "and ccl_cd_prod = 'C01' "
        query &= "and CD_TYPE like 'C0015'"
        query &= "and cd_desc in (" & filter
        query &= " order by ccl_tdc_aim"
        dt = objDataHandler.GetOracleData(query)
        'dt = objDataHandler.GetOracleData("select distinct(ccl_tdc_aim) from v_quality inner join v_cold_coil on ccl_cd_qlty_aim=iql_cd_qlty where ccl_ts_creation between to_date('" & fromDtq & "','DD-MON-YY HH24:MI') and to_date('" & toDtq & "','DD-MON-YY HH24:MI') and iql_grade in (" & strGrade & ") order by ccl_tdc_aim") ' ' AND TC.PRM_TS_END between '" & fromDt & "' and '" & toDt & "'
        lstTdc.DataSource = dt
        lstTdc.DataTextField = "ccl_tdc_aim"
        lstTdc.DataValueField = "ccl_tdc_aim"
        lstTdc.DataBind()
        For Each lst As ListItem In lstTdc.Items
            lst.Selected = True
        Next
        'If dt.Rows.Count > 0 Then
        '    lstDefName.Items.FindByText("SCUMD").Selected = True
        'End If
    End Sub

    Sub LoadGrade(ByVal fromDt As DateTime, ByVal toDt As DateTime)
        Dim fromDtq As String = fromDt.ToString("dd-MMM-yy HH:mm")
        Dim toDtq As String = toDt.ToString("dd-MMM-yy HH:mm")
        'Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT DISTINCT Defect_Name FROM RCL_JCAP_SURFACE_INSPECTION where date_create between '" & fromDt & "' and '" & toDt & "' and Defect_Name !=''  ORDER BY DEFECT_NAME").Tables(0)
        Dim dt As DataTable = Nothing
        Dim dtd As DataTable = getdatatable("SELECT [Desc]  FROM [CRM_DEFECT_CODE] where process='CRCA' and selected=1")
        Dim filter As String = ""
        For i As Integer = 0 To dtd.Rows.Count - 1
            If i = dtd.Rows.Count - 1 Then
                filter &= "'" & dtd.Rows(i)(0) & "')"
            Else
                filter &= "'" & dtd.Rows(i)(0) & "', "
            End If
        Next
        Dim query As String = ""
        query = "Select distinct iql_grade from V_COIL_HOLD_RLS "
        query &= "inner join V_COLD_COIL On ccl_id_coil = chr_id_coil "
        query &= "inner join v_codes On cd_value = chr_cd_fnl_decsn "
        query &= "inner join v_quality on ccl_cd_qlty_aim=iql_cd_qlty "
        query &= "where "
        query &= "chr_id_coil In(Select distinct chr_id_coil from V_COIL_HOLD_RLS where "
        query &= "chr_ts_release between to_date('" & fromDtq & "','DD-MON-YY HH24:MI') and to_date('" & toDtq & "','DD-MON-YY HH24:MI') "
        query &= "and chr_remarks in ('Seconds-M','DownGraded-M','Diverted-M') and chr_cd_fnl_decsn <> 'null'  ) "
        query &= "and chr_cd_fnl_decsn=chr_cd_rsn_hold "
        query &= "and ccl_cd_prod = 'C01' "
        query &= "and CD_TYPE like 'C0015'"
        query &= "and cd_desc in (" & filter
        query &= " order by iql_grade"
        dt = objDataHandler.GetOracleData(query)
        'Dim dt As DataTable = objDataHandler.GetOracleData("Select DISTINCT(iql_grade) from v_quality inner join v_cold_coil On ccl_cd_qlty_aim=iql_cd_qlty where ccl_ts_creation between to_date('" & fromDtq & "','DD-MON-YY HH24:MI') and to_date('" & toDtq & "','DD-MON-YY HH24:MI') order by iql_grade")
        lstGrade.DataSource = dt
        lstGrade.DataTextField = "iql_grade"
        lstGrade.DataValueField = "iql_grade"
        lstGrade.DataBind()
        For Each lst As ListItem In lstGrade.Items
            lst.Selected = True
        Next
        'If dt.Rows.Count > 0 Then
        '    lstDefName.Items.FindByText("SCUMD").Selected = True
        'End If
    End Sub

    Function getSelectedData(ByRef lst As ListBox) As String
        Dim retVal As String = ""
        For Each lstItem As ListItem In lst.Items
            If lstItem.Selected = True Then
                retVal &= "," & lstItem.Text & ""
            End If
        Next

        If (retVal.Length > 0) Then
            Return retVal.Substring(1)
        Else
            Return retVal
        End If

    End Function

    'Protected Sub txtDate_TextChanged(sender As Object, e As System.EventArgs) Handles txtDate.TextChanged


    'End Sub

    Public Function fnQuerySelector() As String
        Dim dt As DataTable = getdatatable("SELECT [Desc]  FROM [CRM_DEFECT_CODE] where process='CRCA' and selected=1")
        Dim filter As String = ""
        For i As Integer = 0 To dt.Rows.Count - 1
            If i = dt.Rows.Count - 1 Then
                filter &= "'" & dt.Rows(i)(0) & "')"
            Else
                filter &= "'" & dt.Rows(i)(0) & "', "
            End If
        Next
        Dim strGrade As String = getSelectedData(lstGrade)
        Dim strTDC As String = getSelectedData(lstTdc)

        If strGrade.Length > 0 Then
            strGrade = "'" & strGrade.Replace(",", "','") & "'"
        Else
            strGrade = "''"
        End If

        If strTDC.Length > 0 Then
            strTDC = "'" & strTDC.Replace(",", "','") & "'"
        Else
            strTDC = "''"
        End If
        filter &= " and ccl_tdc_aim in (" & strTDC & ")"
        filter &= " and iql_grade in (" & strGrade & ")"
        'Dim fromDt_dt As DateTime = hfFrom.Value
        'Dim toDt_dt As DateTime = hfTo.Value
        Dim fromDt_dt As DateTime = hfFrom.Value
        Dim toDt_dt As DateTime = CDate(hfTo.Value).ToString("yyyy-MM-dd 06:00:00")
        Dim fromDt As String = fromDt_dt.ToString("dd-MMM-yy HH:mm")
        Dim toDt As String = toDt_dt.ToString("dd-MMM-yy HH:mm")
        'store coils for each defect
        Dim defectquery As String = "SELECT distinct[Defect_Group] FROM [CRM_DEFECT_CODE] where Selected=1 order by Defect_Group desc"
        Dim defectdt As DataTable = getdatatable(defectquery)
        For i As Integer = 0 To defectdt.Rows.Count - 1
            Dim defect As String = defectdt.Rows(i)(0)
            Dim dt1 As DataTable = getdatatable("SELECT [Desc]  FROM [CRM_DEFECT_CODE] where process='CRCA' and selected=1 and Defect_Group='" & defect & "'")
            Dim f As String = Nothing

            For j As Integer = 0 To dt1.Rows.Count - 1

                If j = dt1.Rows.Count - 1 Then
                    f &= "'" & dt1.Rows(j)(0) & "')"
                Else
                    f &= "'" & dt1.Rows(j)(0) & "', "
                End If
            Next
            f &= " and ccl_tdc_aim in (" & strTDC & ")"
            f &= " and iql_grade in (" & strGrade & ")"
            Dim q As String = ""
            If rdbtnUncoated.Checked = True And rdbtnDecision.Checked = True Then
                q = "select distinct chr_id_coil,ccl_ms_piece_actl from V_COIL_HOLD_RLS "
                q &= "inner join V_COLD_COIL on ccl_id_coil = chr_id_coil "
                q &= "inner join v_codes on cd_value = chr_cd_fnl_decsn "
                q &= "inner join v_quality on ccl_cd_qlty_aim=iql_cd_qlty "
                q &= "where "
                q &= "chr_id_coil in(select distinct chr_id_coil from V_COIL_HOLD_RLS where "
                q &= "chr_ts_release between to_date('" & fromDt & "','DD-MON-YY HH24:MI') and to_date('" & toDt & "','DD-MON-YY HH24:MI') "
                q &= "and chr_remarks in ('Seconds-M','DownGraded-M','Diverted-M') and chr_cd_fnl_decsn <> 'null'  ) "
                q &= "and chr_cd_fnl_decsn=chr_cd_rsn_hold "
                q &= "and ccl_cd_prod = 'C01' "
                q &= "and CD_TYPE like 'C0015'"
                q &= "and cd_desc in (" & f
            End If
            If defect = "ALKALI C/O" Then
                alkalidt = objDataHandler.GetOracleData(q)
            End If
            If defect = "MECH PROP NOT OK" Then
                mechdt = objDataHandler.GetOracleData(q)
            End If
            If defect = "RIS" Then
                risdt = objDataHandler.GetOracleData(q)
            End If
            If defect = "RUBBING MARK" Then
                rubbingdt = objDataHandler.GetOracleData(q)
            End If
            If defect = "RUST" Then
                rustdt = objDataHandler.GetOracleData(q)
            End If
            If defect = "SCUM" Then
                scumdt = objDataHandler.GetOracleData(q)
            End If
            If defect = "STICKER" Then
                stickerdt = objDataHandler.GetOracleData(q)
            End If
            If defect = "STRECHER STRAIN" Then
                strecherdt = objDataHandler.GetOracleData(q)
            End If

        Next


        Dim query As String = ""
        If rdbtnUncoated.Checked = True And rdbtnDecision.Checked = True Then
            query = "Select distinct chr_id_coil,(chr_cd_fnl_decsn),chr_remarks,chr_cd_rsn_hold,chr_ts_release,ccl_ms_piece_actl,cd_desc from V_COIL_HOLD_RLS "
            query &= "inner join V_COLD_COIL On ccl_id_coil = chr_id_coil "
            query &= "inner join v_codes On cd_value = chr_cd_fnl_decsn "
            query &= "inner join v_quality on ccl_cd_qlty_aim=iql_cd_qlty "
            query &= "where "
            query &= "chr_id_coil In(Select distinct chr_id_coil from V_COIL_HOLD_RLS where "
            query &= "chr_ts_release between to_date('" & fromDt & "','DD-MON-YY HH24:MI') and to_date('" & toDt & "','DD-MON-YY HH24:MI') "
            query &= "and chr_remarks in ('Seconds-M','DownGraded-M','Diverted-M') and chr_cd_fnl_decsn <> 'null'  ) "
            query &= "and chr_cd_fnl_decsn=chr_cd_rsn_hold "
            query &= "and ccl_cd_prod = 'C01' "
            query &= "and CD_TYPE like 'C0015'"
            query &= "and cd_desc in (" & filter

        ElseIf rdbtnCoated.Checked = True And rdbtnDefect.Checked = True Then
            query = "select chr_id_coil,chr_ts_release,chr_cd_process,chr_cd_rsn_hold, chr_remarks from V_COIL_HOLD_RLS  "
            query &= "where "
            query &= "chr_ts_release between to_date('" & fromDt & "','DD-MON-YY HH24:MI') and to_date('" & toDt & "','DD-MON-YY HH24:MI') "
            query &= "and chr_cd_rsn_hold  in ('006') and chr_cd_process like ‘L' "
            query &= "order by chr_ts_release"
        ElseIf rdbtnCoated.Checked = True And rdbtnDecision.Checked = True Then
            query = "select distinct chr_id_coil,(chr_cd_fnl_decsn),chr_remarks,chr_cd_rsn_hold,chr_ts_release,ccl_ms_piece_actl,cd_desc from V_COIL_HOLD_RLS"
            query &= "inner join V_COLD_COIL on ccl_id_coil = chr_id_coil"
            query &= "inner join v_codes on cd_value = chr_cd_fnl_decsn "
            query &= "where "
            query &= "chr_id_coil in(select distinct chr_id_coil from V_COIL_HOLD_RLS where "
            query &= "chr_ts_release between to_date('" & fromDt & "','DD-MON-YY HH24:MI') and to_date('" & toDt & "','DD-MON-YY HH24:MI') "
            query &= "and chr_remarks in ('Seconds-M','DownGraded-M','Diverted-M') and chr_cd_fnl_decsn <> 'null'  ) "
            query &= "and chr_cd_fnl_decsn=chr_cd_rsn_hold "
            query &= "and ccl_cd_prod = 'C03' "
            query &= "and CD_TYPE like 'C0015'"
        ElseIf rdbtnUncoated.Checked = True And rdbtnDefect.Checked = True Then
            query = "select chr_id_coil,chr_ts_release,chr_cd_process,chr_cd_rsn_hold, chr_remarks from V_COIL_HOLD_RLS  "
            query &= "where "
            query &= "chr_ts_release between to_date('" & fromDt & "','DD-MON-YY HH24:MI') and to_date('" & toDt & "','DD-MON-YY HH24:MI') "
            query &= "and chr_cd_rsn_hold  in ('006') and chr_cd_process like ‘P' "
            query &= "order by chr_ts_release"
        Else
            UserMsgBoxWarning("Check your Selection")
        End If
        Return query
    End Function

    Function getdatatable(ByVal query As String) As DataTable
        Dim fndatatable As New DataTable
        Dim connection As String = "Password=Welcome@135;Persist Security Info=True;User ID=153521;Initial Catalog=FP_PROCESS_DATA;Data Source=176.0.0.60\lptgsqldev"
        Using con As New SqlConnection(connection)
            Using cmd As New SqlCommand(query, con)
                cmd.CommandType = CommandType.Text
                Using sda As New SqlDataAdapter(cmd)
                    'Using dt As New DataTable()
                    sda.Fill(fndatatable)
                    'End Using
                End Using
            End Using
        End Using
        Return fndatatable
    End Function

    Public Sub Setdates(ByVal dt As DataTable)
        If dt.Rows.Count > 0 Then
            Dim filter As String = ""
            For i As Integer = 0 To dt.Rows.Count - 1
                If i = dt.Rows.Count - 1 Then
                    filter &= "CR_COIL_ID like '" & dt.Rows(i)(0).Substring(0, 6) & "%'"
                Else
                    filter &= "CR_COIL_ID like '" & dt.Rows(i)(0).Substring(0, 6) & "%' or "
                End If
            Next

            pltcmto = ""
            pltcmfrom = ""
            eclto = ""
            eclfrom = ""
            bafto = ""
            baffrom = ""
            spmto = ""
            spmfrom = ""
            Dim datequery As String = "select max(nullif([TCM_ROLLING_DT],'1900-01-01 00:00:00.000')) as tcmmax,min(nullif([TCM_ROLLING_DT],'1900-01-01 00:00:00.000')) as tcmmin,"
            datequery &= " max(nullif([ECL_DATETIME],'1900-01-01 00:00:00.000')) as eclmax,min(nullif([ECL_DATETIME],'1900-01-01 00:00:00.000')) as eclmin,"
            datequery &= "max(nullif([BAF_DATETIME],'1900-01-01 00:00:00.000')) as bafmax,min(nullif([BAF_DATETIME],'1900-01-01 00:00:00.000')) as bafmin,"
            datequery &= "max(nullif([SPM_DATETIME],'1900-01-01 00:00:00.000')) as spmmax,min(nullif([SPM_DATETIME],'1900-01-01 00:00:00.000')) as spmmin from CRM_HR_CR_RLN  where " & filter
            Dim datedt As DataTable = getdatatable(datequery)
            If Not IsDBNull(datedt.Rows(0)(0)) Then
                pltcmto = datedt.Rows(0)(0)
            End If
            If Not IsDBNull(datedt.Rows(0)(1)) Then
                pltcmfrom = datedt.Rows(0)(1)
            End If
            If Not IsDBNull(datedt.Rows(0)(2)) Then
                eclto = datedt.Rows(0)(2)
            End If
            If Not IsDBNull(datedt.Rows(0)(3)) Then
                eclfrom = datedt.Rows(0)(3)
            End If
            If Not IsDBNull(datedt.Rows(0)(4)) Then
                bafto = datedt.Rows(0)(4)
            End If
            If Not IsDBNull(datedt.Rows(0)(5)) Then
                baffrom = datedt.Rows(0)(5)
            End If
            If Not IsDBNull(datedt.Rows(0)(6)) Then
                spmto = datedt.Rows(0)(6)
            End If
            If Not IsDBNull(datedt.Rows(0)(7)) Then
                spmfrom = datedt.Rows(0)(7)
            End If
        End If
    End Sub

    Private Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click
        'empty all dts
        lblDefectdrop.Visible = False
        ddlDefectdrop.Visible = False
        scumdt = Nothing
        risdt = Nothing
        rustdt = Nothing
        alkalidt = Nothing
        rubbingdt = Nothing
        stickerdt = Nothing
        strecherdt = Nothing
        mechdt = Nothing
        pltcmto = ""
        pltcmfrom = ""
        eclto = ""
        eclfrom = ""
        bafto = ""
        baffrom = ""
        spmto = ""
        spmfrom = ""
        Lit1.Text = ""
        dynamicdiv("")
        Dim mainquery As String = fnQuerySelector()
        Dim dt As DataTable = objDataHandler.GetOracleData(mainquery)
        Dim bardt As DataTable = objDataHandler.GetOracleData("select cd_desc,sum(ccl_ms_piece_actl) as ccl_ms_piece_actl from ( " & mainquery & " )group by cd_desc order by ccl_ms_piece_actl desc")
        Dim dt1 As DataTable = getdatatable("SELECT [Desc],[Defect_Group]  FROM [CRM_DEFECT_CODE] where process='CRCA' and selected=1")
        bardt.Columns.Add(New DataColumn("Defect_Group", GetType(String)))
        For i As Integer = 0 To bardt.Rows.Count - 1
            For j As Integer = 0 To dt1.Rows.Count - 1
                If bardt.Rows(i)(0) = dt1.Rows(j)(0) Then
                    bardt.Rows(i)(2) = dt1.Rows(j)(1)
                End If
            Next
        Next
        ddlDefectdrop.DataSource = bardt
        ddlDefectdrop.DataTextField = "Defect_Group"
        ddlDefectdrop.DataValueField = "Defect_Group"
        ddlDefectdrop.DataBind()
        ddlDefectdrop.Items.Insert(0, New ListItem("--Select--", "0"))
        lblDefectdrop.Visible = True
        ddlDefectdrop.Visible = True
    End Sub

    Public Sub dynamicdiv(ByVal val As String)
        Dim query As String = "SELECT [Parameter],Chart_Title FROM [CRM_DEFECT_VARIABLE_MAP] where selection=1 and Defect_Name='" & val & "'"
        Dim dt As DataTable = getdatatable(query)
        Dim str1 As String = ""
        If dt.Rows.Count > 0 Then
            Dim count As Integer = 0
            Dim appendString = ""
            For i As Integer = 0 To dt.Rows.Count - 1

                str1 &= "," & dt.Rows(i)(0)
                Dim ChartTitle As String = ""

                ChartTitle = dt.Rows(i)(1)

                Dim spanClass As String = ""

                appendString &= "<div class='col-md-6'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>" & ChartTitle & "</h3> <span class='" & spanClass & "'></span></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='" & dt.Rows(i)(0).ToString.Replace(" ", "_") & "' style='height: 400px;'></div></div></div></div>"
                'appendString &= "<div class='col-md-6'>"
                'appendString &= "<table border = '1'>"
                'appendString &= "                       <tr>"
                'appendString &= "                          <th colspan='1' >Std Deviation (σ) :</th>"
                'appendString &= "                  <td><asp:Label ID='lblStddev'  runat='server' style=' font-weight:bold;color:blue;'  Font-Underline=' False' ></asp:Label></td>"
                'appendString &= "                   </tr>"
                'appendString &= " < tr><th colspan = ' 1'  > Mean(µ) : </th>"
                'appendString &= " < td <> ASP : Label ID = ' lblMean'  runat=' server'  style=' font-weight:bold;color:blue;'  Font-Underline=' False' ></asp: Label></td>"
                'appendString &= "              </tr>"
                'appendString &= "              <tr>"
                'appendString &= "               <th colspan = ' 1'  > Upper Control Limit (UCL) :</th>"
                'appendString &= " < td <> ASP : Label ID = ' lblUCL'  runat=' server'  style=' font-weight:bold;color:blue;'  Font-Underline=' False' ></asp: Label></td>"
                'appendString &= "          </tr>"
                'appendString &= "         <tr>"
                'appendString &= "             <th colspan = ' 1'  > Lower Control Limit (LCL) :</th>"
                'appendString &= " < td <> ASP : Label ID = ' lblLCL'  runat=' server'  style=' font-weight:bold;color:blue;'  Font-Underline=' False' ></asp: Label></td>"
                'appendString &= "     </tr>"
                'appendString &= "   </table>"
                'appendString &= "</div>"


            Next
            divHolder.InnerHtml = appendString
            If str1 = "" Then

            Else
                str1 = str1.Substring(1)

                Dim filter As String = ""
                For j As Integer = 0 To dt.Rows.Count - 1

                    filter &= "," & dt.Rows(j)(0)


                Next
                If filter.Length > 0 Then
                    filter = filter.Substring(1)
                    'If rdbtnDatewise.Checked = True Then
                    DrawCharts(str1, filter, val)
                    'Else
                    'DrawChartTop1(str1, fromDt, toDt, filter)
                    'End If

                End If

            End If
        Else
            divHolder.InnerHtml = Nothing
        End If
    End Sub

    Public Sub DrawCharts(ByVal ColumnName As String, ByVal Filter As String, ByVal val As String)
        Dim strGrade As String = getSelectedData(lstGrade)
        Dim strTDC As String = getSelectedData(lstTdc)

        If strGrade.Length > 0 Then
            strGrade = "'" & strGrade.Replace(",", "','") & "'"
        Else
            strGrade = "''"
        End If

        If strTDC.Length > 0 Then
            strTDC = "'" & strTDC.Replace(",", "','") & "'"
        Else
            strTDC = "''"
        End If
        Dim usl As Double = 0.0
        Dim lsl As Double = 0.0
        Dim avg As Double = 0.0
        Dim lcl As Double = 0.0
        Dim ucl As Double = 0.0
        Dim standev As Double = 0.0
        Dim unit As String = ""
        Dim Cpk1 As Double = 0.0
        Dim Cp1 As Double = 0.0
        Dim a() As String = ColumnName.Split(",")
        Dim l As Literal
        For i As Integer = 0 To UBound(a)
            Dim literals = Page.Master.FindControl("content_body").Controls.OfType(Of Literal)()
            For Each lit In literals
                If (lit.ID = "Literal" & i + 1) Then
                    l = lit
                    Exit For
                End If
            Next
            If a(i) = "Unwinding Tension(kg/mm2)" Then
                Dim from As DateTime = spmfrom
                Dim f As String = from.ToString("yyyy-MM-dd HH:mm:ss")
                Dim todate As DateTime = spmto
                Dim t As String = todate.ToString("yyyy-MM-dd HH:mm:ss")
                ' get data from that process
                Dim s As String = "select [TENSION_POS_ENTRY]/([THICKNESS]*[width])as Tension,COIL_STARTDATETIME  from CRM_SPM_PROCESS_DATA_COILWISE_BODY "
                s &= "where COIL_STARTDATETIME between '" & f & "' and '" & t & "' and tdc_no in (" & strTDC & ") and grade in (" & strGrade & ") order by COIL_STARTDATETIME asc"
                Dim dt As DataTable = getdatatable(s)
                Dim fil As String = ""
                If val = "RUBBING MARK" Then
                    For j As Integer = 0 To rubbingdt.Rows.Count - 1
                        If j = rubbingdt.Rows.Count - 1 Then
                            fil &= "DAUGHTER_COILID_TEXT like '" & rubbingdt.Rows(j)(0).Substring(0, 6) & "%'"
                        Else
                            fil &= "DAUGHTER_COILID_TEXT like '" & rubbingdt.Rows(j)(0).Substring(0, 6) & "%' or "
                        End If
                    Next
                ElseIf val = "STICKER" Then
                    For j As Integer = 0 To stickerdt.Rows.Count - 1
                        If j = stickerdt.Rows.Count - 1 Then
                            fil &= "DAUGHTER_COILID_TEXT like '" & stickerdt.Rows(j)(0).Substring(0, 6) & "%'"
                        Else
                            fil &= "DAUGHTER_COILID_TEXT like '" & stickerdt.Rows(j)(0).Substring(0, 6) & "%' or "
                        End If
                    Next
                End If
                fil &= " and tdc_no in (" & strTDC & ")"
                fil &= " and grade in (" & strGrade & ")"
                Dim q As String = "select [TENSION_POS_ENTRY]/([THICKNESS]*[width])as Tension,COIL_STARTDATETIME  from CRM_SPM_PROCESS_DATA_COILWISE_BODY "
                q &= "Where " & fil
                q &= " order by COIL_STARTDATETIME asc"
                Dim defdt As DataTable = getdatatable(q)
                ' get details for markline
                If dt.Rows.Count > 0 Then
                    'Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("HCL Acid T4")

                    'Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(pltcmfrom, pltcmto, "HCL Acid T4")

                    'CalculateCPK(dt, "Tension", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)
                    ' plot the graph
                    PlotLinegraph_all(dt, defdt, "COIL_STARTDATETIME", "Tension", l, a(i), "plot" & i + 1, "kg/mm2", usl, lsl, avg, ucl, lcl)
                End If
            End If
            If a(i) = "HRP_MIN_SPD_PLT" Then
                ' get data from that process
                Dim from As DateTime = pltcmfrom
                Dim f As String = from.ToString("dd-MMM-yy HH:mm")
                Dim todate As DateTime = pltcmto
                Dim t As String = todate.ToString("dd-MMM-yy HH:mm")
                Dim s As String = "select HRp_ID_PC_USRKEY, to_char(fhc_tm_rol_str,'YYYY-MM-DD HH24:MI') as pl_start, to_char(fhc_tm_rol_end,'YYYY-MM-DD HH24:MI') as pl_end,"
                s &= "hrc_cd_product,hrp_id_cr_coil,hrp_prod_cd,HRP_MIN_SPD_PLT,HRP_MAX_SPD_PLT,HRP_AVG_SPD_PLT,hrp_min_elon_tl "
                s &= " from v_hr_coil,V_full_hard_coils,v_hr_coil_process inner join v_cold_coil on ccl_id_coil=hrp_id_cr_coil inner join v_quality on ccl_cd_qlty_aim=iql_cd_qlty"
                s &= " where  HRp_ID_PC_USRKEY=HRc_ID_PC_USRKEY "
                s &= " and HRp_ID_PC_USRKEY = fhc_id_hr_coil1"
                '--and HRp_ID_PC_USRKEY = '84800320'
                s &= " And fhc_tm_rol_str between to_date('" & f & "','DD-MON-YY HH24:MI')   and to_date('" & t & "','DD-MON-YY HH24:MI') and ccl_tdc_aim in (" & strTDC & ") and iql_grade in (" & strGrade & ") order by pl_start asc"
                Dim dt As DataTable = objDataHandler.GetOracleData(s)
                Dim fil As String = ""
                If val = "SCUM" Then
                    For j As Integer = 0 To scumdt.Rows.Count - 1
                        If j = scumdt.Rows.Count - 1 Then
                            fil &= "'" & scumdt.Rows(j)(0).Substring(0, 6) & "0000')"
                        Else
                            fil &= "'" & scumdt.Rows(j)(0).Substring(0, 6) & "0000' ,"
                        End If
                    Next
                ElseIf val = "RIS" Then
                    For j As Integer = 0 To risdt.Rows.Count - 1
                        If j = risdt.Rows.Count - 1 Then
                            fil &= "'" & risdt.Rows(j)(0).Substring(0, 6) & "0000')"
                        Else
                            fil &= "'" & risdt.Rows(j)(0).Substring(0, 6) & "0000' ,"
                        End If
                    Next
                End If
                fil &= " and ccl_tdc_aim in (" & strTDC & ")"
                fil &= " and iql_grade in (" & strGrade & ")"
                Dim q As String = "select HRp_ID_PC_USRKEY, to_char(fhc_tm_rol_str,'YYYY-MM-DD HH24:MI') as pl_start, to_char(fhc_tm_rol_end,'YYYY-MM-DD HH24:MI') as pl_end,"
                q &= "hrc_cd_product,hrp_id_cr_coil,hrp_prod_cd,HRP_MIN_SPD_PLT,HRP_MAX_SPD_PLT,HRP_AVG_SPD_PLT,hrp_min_elon_tl "
                q &= " from v_hr_coil,V_full_hard_coils,v_hr_coil_process inner join v_cold_coil on ccl_id_coil=hrp_id_cr_coil inner join v_quality on ccl_cd_qlty_aim=iql_cd_qlty"
                q &= " where  HRp_ID_PC_USRKEY=HRc_ID_PC_USRKEY "
                q &= " and HRp_ID_PC_USRKEY = fhc_id_hr_coil1"
                q &= " And hrp_id_cr_coil in(" & fil
                q &= " order by pl_start asc"
                Dim defdt As DataTable = objDataHandler.GetOracleData(q)
                ' get details for markline
                If dt.Rows.Count > 0 Then
                    'Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("Coil_Age_BAF")

                    'Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(f, t, "Coil_Age_BAF")

                    'CalculateCPK(dt, "HRP_MIN_SPD_PLT", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)
                    ' plot the graph
                    PlotLinegraph_all(dt, defdt, "pl_start", "HRP_MIN_SPD_PLT", l, a(i), "plot" & i + 1, "m/min", usl, lsl, avg, ucl, lcl)
                End If

            End If
            If a(i) = "HRP_MAX_SPD_PLT" Then
                ' get data from that process
                Dim from As DateTime = pltcmfrom
                Dim f As String = from.ToString("dd-MMM-yy HH:mm")
                Dim todate As DateTime = pltcmto
                Dim t As String = todate.ToString("dd-MMM-yy HH:mm")
                Dim s As String = "select HRp_ID_PC_USRKEY, to_char(fhc_tm_rol_str,'YYYY-MM-DD HH24:MI') as pl_start, to_char(fhc_tm_rol_end,'YYYY-MM-DD HH24:MI') as pl_end,"
                s &= "hrc_cd_product,hrp_id_cr_coil,hrp_prod_cd,HRP_MIN_SPD_PLT,HRP_MAX_SPD_PLT,HRP_AVG_SPD_PLT,hrp_min_elon_tl "
                s &= " from v_hr_coil,V_full_hard_coils,v_hr_coil_process inner join v_cold_coil on ccl_id_coil=hrp_id_cr_coil inner join v_quality on ccl_cd_qlty_aim=iql_cd_qlty"
                s &= " where  HRp_ID_PC_USRKEY=HRc_ID_PC_USRKEY "
                s &= " and HRp_ID_PC_USRKEY = fhc_id_hr_coil1"
                '--and HRp_ID_PC_USRKEY = '84800320'
                s &= " And fhc_tm_rol_str between to_date('" & f & "','DD-MON-YY HH24:MI')   and to_date('" & t & "','DD-MON-YY HH24:MI') and ccl_tdc_aim in (" & strTDC & ") and iql_grade in (" & strGrade & ") order by pl_start asc"
                Dim dt As DataTable = objDataHandler.GetOracleData(s)
                Dim fil As String = ""
                If val = "SCUM" Then
                    For j As Integer = 0 To scumdt.Rows.Count - 1
                        If j = scumdt.Rows.Count - 1 Then
                            fil &= "'" & scumdt.Rows(j)(0).Substring(0, 6) & "0000')"
                        Else
                            fil &= "'" & scumdt.Rows(j)(0).Substring(0, 6) & "0000' ,"
                        End If
                    Next
                ElseIf val = "RIS" Then
                    For j As Integer = 0 To risdt.Rows.Count - 1
                        If j = risdt.Rows.Count - 1 Then
                            fil &= "'" & risdt.Rows(j)(0).Substring(0, 6) & "0000')"
                        Else
                            fil &= "'" & risdt.Rows(j)(0).Substring(0, 6) & "0000' ,"
                        End If
                    Next
                End If
                fil &= " and ccl_tdc_aim in (" & strTDC & ")"
                fil &= " and iql_grade in (" & strGrade & ")"
                Dim q As String = "select HRp_ID_PC_USRKEY, to_char(fhc_tm_rol_str,'YYYY-MM-DD HH24:MI') as pl_start, to_char(fhc_tm_rol_end,'YYYY-MM-DD HH24:MI') as pl_end,"
                q &= "hrc_cd_product,hrp_id_cr_coil,hrp_prod_cd,HRP_MIN_SPD_PLT,HRP_MAX_SPD_PLT,HRP_AVG_SPD_PLT,hrp_min_elon_tl "
                q &= " from v_hr_coil,V_full_hard_coils,v_hr_coil_process inner join v_cold_coil on ccl_id_coil=hrp_id_cr_coil inner join v_quality on ccl_cd_qlty_aim=iql_cd_qlty"
                q &= " where  HRp_ID_PC_USRKEY=HRc_ID_PC_USRKEY "
                q &= " and HRp_ID_PC_USRKEY = fhc_id_hr_coil1"
                q &= " And hrp_id_cr_coil in(" & fil
                q &= " order by pl_start asc"
                Dim defdt As DataTable = objDataHandler.GetOracleData(q)
                ' get details for markline
                If dt.Rows.Count > 0 Then
                    'Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("Coil_Age_BAF")

                    'Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(f, t, "Coil_Age_BAF")

                    'CalculateCPK(dt, "HRP_MAX_SPD_PLT", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)
                    ' plot the graph
                    PlotLinegraph_all(dt, defdt, "pl_start", "HRP_MAX_SPD_PLT", l, a(i), "plot" & i + 1, "m/min", usl, lsl, avg, ucl, lcl)
                End If
            End If
            If a(i) = "HRP_AVG_SPD_PLT" Then
                ' get data from that process
                Dim from As DateTime = pltcmfrom
                Dim f As String = from.ToString("dd-MMM-yy HH:mm")
                Dim todate As DateTime = pltcmto
                Dim t As String = todate.ToString("dd-MMM-yy HH:mm")
                Dim s As String = "select HRp_ID_PC_USRKEY, to_char(fhc_tm_rol_str,'YYYY-MM-DD HH24:MI') as pl_start, to_char(fhc_tm_rol_end,'YYYY-MM-DD HH24:MI') as pl_end,"
                s &= "hrc_cd_product,hrp_id_cr_coil,hrp_prod_cd,HRP_MIN_SPD_PLT,HRP_MAX_SPD_PLT,HRP_AVG_SPD_PLT,hrp_min_elon_tl "
                s &= " from v_hr_coil,V_full_hard_coils,v_hr_coil_process inner join v_cold_coil on ccl_id_coil=hrp_id_cr_coil inner join v_quality on ccl_cd_qlty_aim=iql_cd_qlty"
                s &= " where  HRp_ID_PC_USRKEY=HRc_ID_PC_USRKEY "
                s &= " and HRp_ID_PC_USRKEY = fhc_id_hr_coil1"
                '--and HRp_ID_PC_USRKEY = '84800320'
                s &= " And fhc_tm_rol_str between to_date('" & f & "','DD-MON-YY HH24:MI')   and to_date('" & t & "','DD-MON-YY HH24:MI') and ccl_tdc_aim in (" & strTDC & ") and iql_grade in (" & strGrade & ") order by pl_start asc"
                Dim dt As DataTable = objDataHandler.GetOracleData(s)
                Dim fil As String = ""
                If val = "SCUM" Then
                    For j As Integer = 0 To scumdt.Rows.Count - 1
                        If j = scumdt.Rows.Count - 1 Then
                            fil &= "'" & scumdt.Rows(j)(0).Substring(0, 6) & "0000')"
                        Else
                            fil &= "'" & scumdt.Rows(j)(0).Substring(0, 6) & "0000' ,"
                        End If
                    Next
                ElseIf val = "RIS" Then
                    For j As Integer = 0 To risdt.Rows.Count - 1
                        If j = risdt.Rows.Count - 1 Then
                            fil &= "'" & risdt.Rows(j)(0).Substring(0, 6) & "0000')"
                        Else
                            fil &= "'" & risdt.Rows(j)(0).Substring(0, 6) & "0000' ,"
                        End If
                    Next
                End If
                fil &= " and ccl_tdc_aim in (" & strTDC & ")"
                fil &= " and iql_grade in (" & strGrade & ")"
                Dim q As String = "select HRp_ID_PC_USRKEY, to_char(fhc_tm_rol_str,'YYYY-MM-DD HH24:MI') as pl_start, to_char(fhc_tm_rol_end,'YYYY-MM-DD HH24:MI') as pl_end,"
                q &= "hrc_cd_product,hrp_id_cr_coil,hrp_prod_cd,HRP_MIN_SPD_PLT,HRP_MAX_SPD_PLT,HRP_AVG_SPD_PLT,hrp_min_elon_tl "
                q &= " from v_hr_coil,V_full_hard_coils,v_hr_coil_process inner join v_cold_coil on ccl_id_coil=hrp_id_cr_coil inner join v_quality on ccl_cd_qlty_aim=iql_cd_qlty"
                q &= " where  HRp_ID_PC_USRKEY=HRc_ID_PC_USRKEY "
                q &= " and HRp_ID_PC_USRKEY = fhc_id_hr_coil1"
                q &= " And hrp_id_cr_coil in(" & fil
                q &= " order by pl_start asc"
                Dim defdt As DataTable = objDataHandler.GetOracleData(q)
                ' get details for markline
                If dt.Rows.Count > 0 Then
                    'Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("Coil_Age_BAF")

                    'Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(f, t, "Coil_Age_BAF")

                    'CalculateCPK(dt, "HRP_AVG_SPD_PLT", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)
                    ' plot the graph
                    PlotLinegraph_all(dt, defdt, "pl_start", "HRP_AVG_SPD_PLT", l, a(i), "plot" & i + 1, "m/min", usl, lsl, avg, ucl, lcl)
                End If
            End If
            If a(i) = "hrp_min_elon_tl " Then
                ' get data from that process
                Dim from As DateTime = pltcmfrom
                Dim f As String = from.ToString("dd-MMM-yy HH:mm")
                Dim todate As DateTime = pltcmto
                Dim t As String = todate.ToString("dd-MMM-yy HH:mm")
                Dim s As String = "select HRp_ID_PC_USRKEY, to_char(fhc_tm_rol_str,'YYYY-MM-DD HH24:MI') as pl_start, to_char(fhc_tm_rol_end,'YYYY-MM-DD HH24:MI') as pl_end,"
                s &= "hrc_cd_product,hrp_id_cr_coil,hrp_prod_cd,HRP_MIN_SPD_PLT,HRP_MAX_SPD_PLT,HRP_AVG_SPD_PLT,hrp_min_elon_tl "
                s &= " from v_hr_coil,V_full_hard_coils,v_hr_coil_process inner join v_cold_coil on ccl_id_coil=hrp_id_cr_coil inner join v_quality on ccl_cd_qlty_aim=iql_cd_qlty"
                s &= " where  HRp_ID_PC_USRKEY=HRc_ID_PC_USRKEY "
                s &= " and HRp_ID_PC_USRKEY = fhc_id_hr_coil1"
                '--and HRp_ID_PC_USRKEY = '84800320'
                s &= " And fhc_tm_rol_str between to_date('" & f & "','DD-MON-YY HH24:MI')   and to_date('" & t & "','DD-MON-YY HH24:MI') and ccl_tdc_aim in (" & strTDC & ") and iql_grade in (" & strGrade & ") order by pl_start asc"
                Dim dt As DataTable = objDataHandler.GetOracleData(s)
                Dim fil As String = ""
                If val = "SCUM" Then
                    For j As Integer = 0 To scumdt.Rows.Count - 1
                        If j = scumdt.Rows.Count - 1 Then
                            fil &= "'" & scumdt.Rows(j)(0).Substring(0, 6) & "0000')"
                        Else
                            fil &= "'" & scumdt.Rows(j)(0).Substring(0, 6) & "0000' ,"
                        End If
                    Next
                ElseIf val = "RIS" Then
                    For j As Integer = 0 To risdt.Rows.Count - 1
                        If j = risdt.Rows.Count - 1 Then
                            fil &= "'" & risdt.Rows(j)(0).Substring(0, 6) & "0000')"
                        Else
                            fil &= "'" & risdt.Rows(j)(0).Substring(0, 6) & "0000' ,"
                        End If
                    Next
                End If
                fil &= " and ccl_tdc_aim in (" & strTDC & ")"
                fil &= " and iql_grade in (" & strGrade & ")"
                Dim q As String = "select HRp_ID_PC_USRKEY, to_char(fhc_tm_rol_str,'YYYY-MM-DD HH24:MI') as pl_start, to_char(fhc_tm_rol_end,'YYYY-MM-DD HH24:MI') as pl_end,"
                q &= "hrc_cd_product,hrp_id_cr_coil,hrp_prod_cd,HRP_MIN_SPD_PLT,HRP_MAX_SPD_PLT,HRP_AVG_SPD_PLT,hrp_min_elon_tl "
                q &= " from v_hr_coil,V_full_hard_coils,v_hr_coil_process inner join v_cold_coil on ccl_id_coil=hrp_id_cr_coil inner join v_quality on ccl_cd_qlty_aim=iql_cd_qlty"
                q &= " where  HRp_ID_PC_USRKEY=HRc_ID_PC_USRKEY "
                q &= " and HRp_ID_PC_USRKEY = fhc_id_hr_coil1"
                q &= " And hrp_id_cr_coil in(" & fil
                q &= " order by pl_start asc"
                Dim defdt As DataTable = objDataHandler.GetOracleData(q)
                ' get details for markline
                If dt.Rows.Count > 0 Then
                    'Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("Coil_Age_BAF")

                    'Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(f, t, "Coil_Age_BAF")

                    'CalculateCPK(dt, "hrp_min_elon_tl", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)
                    ' plot the graph
                    PlotLinegraph_all(dt, defdt, "pl_start", "hrp_min_elon_tl", l, a(i), "plot" & i + 1, "%", usl, lsl, avg, ucl, lcl)
                End If
            End If
            If a(i) = "ACIDT1" Then
                Dim from As DateTime = pltcmfrom
                Dim f As String = from.ToString("yyyy-MM-dd HH:mm:ss")
                Dim todate As DateTime = pltcmto
                Dim t As String = todate.ToString("yyyy-MM-dd HH:mm:ss")
                ' get data from that process
                Dim s As String = "SELECT [PLTCM_START],[ACID1],[ACID2],[ACID3],[ACID4],[ACID5] From CRM_PLTCM_ORA_PROCESS_DATA "
                s &= "Where [PLTCM_START] > '" & f & "' and [PLTCM_START] < '" & t & "' and TDC_NO in (" & strTDC & ") and GRADE in (" & strGrade & ") order by PLTCM_START asc"
                Dim dt As DataTable = getdatatable(s)
                Dim fil As String = ""
                If val = "SCUM" Then
                    For j As Integer = 0 To scumdt.Rows.Count - 1
                        If j = scumdt.Rows.Count - 1 Then
                            fil &= "CR_ID_COIL like '" & scumdt.Rows(j)(0).Substring(0, 6) & "%'"
                        Else
                            fil &= "CR_ID_COIL like '" & scumdt.Rows(j)(0).Substring(0, 6) & "%' or "
                        End If
                    Next
                ElseIf val = "RIS" Then
                    For j As Integer = 0 To risdt.Rows.Count - 1
                        If j = risdt.Rows.Count - 1 Then
                            fil &= "CR_ID_COIL like '" & risdt.Rows(j)(0).Substring(0, 6) & "%'"
                        Else
                            fil &= "CR_ID_COIL like '" & risdt.Rows(j)(0).Substring(0, 6) & "%' or "
                        End If
                    Next
                End If
                fil &= " and TDC_NO in (" & strTDC & ")"
                fil &= " and GRADE in (" & strGrade & ")"
                Dim q As String = "SELECT [PLTCM_START],[ACID1],[ACID2],[ACID3],[ACID4],[ACID5] From CRM_PLTCM_ORA_PROCESS_DATA "
                q &= "Where " & fil
                q &= " order by PLTCM_START asc"
                Dim defdt As DataTable = getdatatable(q)
                ' get details for markline
                If dt.Rows.Count > 0 Then
                    Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("HCL Acid T1")

                    Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(f, t, "HCL Acid T1")

                    CalculateCPK(dt, "ACID1", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)
                    ' plot the graph
                    PlotLinegraph_all(dt, defdt, "PLTCM_START", "ACID1", l, a(i), "plot" & i + 1, "%", dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl)
                End If
            End If
            If a(i) = "ACIDT2" Then
                Dim from As DateTime = pltcmfrom
                Dim f As String = from.ToString("yyyy-MM-dd HH:mm:ss")
                Dim todate As DateTime = pltcmto
                Dim t As String = todate.ToString("yyyy-MM-dd HH:mm:ss")
                ' get data from that process
                Dim s As String = "SELECT [PLTCM_START],[ACID1],[ACID2],[ACID3],[ACID4],[ACID5] From CRM_PLTCM_ORA_PROCESS_DATA "
                s &= "Where [PLTCM_START] > '" & f & "' and [PLTCM_START] < '" & t & "' and TDC_NO in (" & strTDC & ") and GRADE in (" & strGrade & ") order by PLTCM_START asc"
                Dim dt As DataTable = getdatatable(s)
                Dim fil As String = ""
                If val = "SCUM" Then
                    For j As Integer = 0 To scumdt.Rows.Count - 1
                        If j = scumdt.Rows.Count - 1 Then
                            fil &= "CR_ID_COIL like '" & scumdt.Rows(j)(0).Substring(0, 6) & "%'"
                        Else
                            fil &= "CR_ID_COIL like '" & scumdt.Rows(j)(0).Substring(0, 6) & "%' or "
                        End If
                    Next
                ElseIf val = "RIS" Then
                    For j As Integer = 0 To risdt.Rows.Count - 1
                        If j = risdt.Rows.Count - 1 Then
                            fil &= "CR_ID_COIL like '" & risdt.Rows(j)(0).Substring(0, 6) & "%'"
                        Else
                            fil &= "CR_ID_COIL like '" & risdt.Rows(j)(0).Substring(0, 6) & "%' or "
                        End If
                    Next
                End If
                fil &= " and TDC_NO in (" & strTDC & ")"
                fil &= " and GRADE in (" & strGrade & ")"
                Dim q As String = "SELECT [PLTCM_START],[ACID1],[ACID2],[ACID3],[ACID4],[ACID5] From CRM_PLTCM_ORA_PROCESS_DATA "
                q &= "Where " & fil
                q &= " order by PLTCM_START asc"
                Dim defdt As DataTable = getdatatable(q)
                ' get details for markline
                If dt.Rows.Count > 0 Then
                    Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("HCL Acid T2")

                    Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(f, t, "HCL Acid T2")

                    CalculateCPK(dt, "ACID2", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)
                    ' plot the graph
                    PlotLinegraph_all(dt, defdt, "PLTCM_START", "ACID2", l, a(i), "plot" & i + 1, "%", dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl)
                End If
            End If
            If a(i) = "ACIDT3" Then
                Dim from As DateTime = pltcmfrom
                Dim f As String = from.ToString("yyyy-MM-dd HH:mm:ss")
                Dim todate As DateTime = pltcmto
                Dim t As String = todate.ToString("yyyy-MM-dd HH:mm:ss")
                ' get data from that process
                Dim s As String = "SELECT [PLTCM_START],[ACID1],[ACID2],[ACID3],[ACID4],[ACID5] From CRM_PLTCM_ORA_PROCESS_DATA "
                s &= "Where [PLTCM_START] > '" & f & "' and [PLTCM_START] < '" & t & "' and TDC_NO in (" & strTDC & ") and GRADE in (" & strGrade & ") order by PLTCM_START asc"
                Dim dt As DataTable = getdatatable(s)
                Dim fil As String = ""
                If val = "SCUM" Then
                    For j As Integer = 0 To scumdt.Rows.Count - 1
                        If j = scumdt.Rows.Count - 1 Then
                            fil &= "CR_ID_COIL like '" & scumdt.Rows(j)(0).Substring(0, 6) & "%'"
                        Else
                            fil &= "CR_ID_COIL like '" & scumdt.Rows(j)(0).Substring(0, 6) & "%' or "
                        End If
                    Next
                ElseIf val = "RIS" Then
                    For j As Integer = 0 To risdt.Rows.Count - 1
                        If j = risdt.Rows.Count - 1 Then
                            fil &= "CR_ID_COIL like '" & risdt.Rows(j)(0).Substring(0, 6) & "%'"
                        Else
                            fil &= "CR_ID_COIL like '" & risdt.Rows(j)(0).Substring(0, 6) & "%' or "
                        End If
                    Next
                End If
                fil &= " and TDC_NO in (" & strTDC & ")"
                fil &= " and GRADE in (" & strGrade & ")"
                Dim q As String = "SELECT [PLTCM_START],[ACID1],[ACID2],[ACID3],[ACID4],[ACID5] From CRM_PLTCM_ORA_PROCESS_DATA "
                q &= "Where " & fil
                q &= " order by PLTCM_START asc"
                Dim defdt As DataTable = getdatatable(q)
                ' get details for markline
                If dt.Rows.Count > 0 Then
                    Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("HCL Acid T3")

                    Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(f, t, "HCL Acid T3")

                    CalculateCPK(dt, "ACID3", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)
                    ' plot the graph
                    PlotLinegraph_all(dt, defdt, "PLTCM_START", "ACID3", l, a(i), "plot" & i + 1, "%", dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl)
                End If
            End If
            If a(i) = "ACIDT4" Then
                Dim from As DateTime = pltcmfrom
                Dim f As String = from.ToString("yyyy-MM-dd HH:mm:ss")
                Dim todate As DateTime = pltcmto
                Dim t As String = todate.ToString("yyyy-MM-dd HH:mm:ss")
                ' get data from that process
                Dim s As String = "SELECT [PLTCM_START],[ACID1],[ACID2],[ACID3],[ACID4],[ACID5] From CRM_PLTCM_ORA_PROCESS_DATA "
                s &= "Where [PLTCM_START] > '" & f & "' and [PLTCM_START] < '" & t & "' and TDC_NO in (" & strTDC & ") and GRADE in (" & strGrade & ") order by PLTCM_START asc"
                Dim dt As DataTable = getdatatable(s)
                Dim fil As String = ""
                If val = "SCUM" Then
                    For j As Integer = 0 To scumdt.Rows.Count - 1
                        If j = scumdt.Rows.Count - 1 Then
                            fil &= "CR_ID_COIL like '" & scumdt.Rows(j)(0).Substring(0, 6) & "%'"
                        Else
                            fil &= "CR_ID_COIL like '" & scumdt.Rows(j)(0).Substring(0, 6) & "%' or "
                        End If
                    Next
                ElseIf val = "RIS" Then
                    For j As Integer = 0 To risdt.Rows.Count - 1
                        If j = risdt.Rows.Count - 1 Then
                            fil &= "CR_ID_COIL like '" & risdt.Rows(j)(0).Substring(0, 6) & "%'"
                        Else
                            fil &= "CR_ID_COIL like '" & risdt.Rows(j)(0).Substring(0, 6) & "%' or "
                        End If
                    Next
                End If
                fil &= " and TDC_NO in (" & strTDC & ")"
                fil &= " and GRADE in (" & strGrade & ")"
                Dim q As String = "SELECT [PLTCM_START],[ACID1],[ACID2],[ACID3],[ACID4],[ACID5] From CRM_PLTCM_ORA_PROCESS_DATA "
                q &= "Where " & fil
                q &= " order by PLTCM_START asc"
                Dim defdt As DataTable = getdatatable(q)
                ' get details for markline
                If dt.Rows.Count > 0 Then
                    Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("HCL Acid T4")

                    Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(f, t, "HCL Acid T4")

                    CalculateCPK(dt, "ACID4", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)
                    ' plot the graph
                    PlotLinegraph_all(dt, defdt, "PLTCM_START", "ACID4", l, a(i), "plot" & i + 1, "%", dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl)
                End If
            End If
            If a(i) = "ENLONGATION_ACT" Then
                Dim from As DateTime = spmfrom
                Dim f As String = from.ToString("yyyy-MM-dd HH:mm:ss")
                Dim todate As DateTime = spmto
                Dim t As String = todate.ToString("yyyy-MM-dd HH:mm:ss")
                ' get data from that process
                Dim s As String = "select [ENLONGATION_ACT],COIL_STARTDATETIME from CRM_SPM_PROCESS_DATA_COILWISE_BODY "
                s &= "where COIL_STARTDATETIME between '" & f & "' and '" & t & "' and tdc_no in (" & strTDC & ") and grade in (" & strGrade & ") order by COIL_STARTDATETIME asc"
                Dim dt As DataTable = getdatatable(s)
                Dim fil As String = ""
                If val = "STRECHER STRAIN" Then
                    For j As Integer = 0 To strecherdt.Rows.Count - 1
                        If j = strecherdt.Rows.Count - 1 Then
                            fil &= "DAUGHTER_COILID_TEXT like '" & strecherdt.Rows(j)(0).Substring(0, 6) & "%'"
                        Else
                            fil &= "DAUGHTER_COILID_TEXT like '" & strecherdt.Rows(j)(0).Substring(0, 6) & "%' or "
                        End If
                    Next
                ElseIf val = "MECH PROP NOT OK" Then
                    For j As Integer = 0 To mechdt.Rows.Count - 1
                        If j = mechdt.Rows.Count - 1 Then
                            fil &= "DAUGHTER_COILID_TEXT like '" & mechdt.Rows(j)(0).Substring(0, 6) & "%'"
                        Else
                            fil &= "DAUGHTER_COILID_TEXT like '" & mechdt.Rows(j)(0).Substring(0, 6) & "%' or "
                        End If
                    Next
                End If
                fil &= " and tdc_no in (" & strTDC & ")"
                fil &= " and grade in (" & strGrade & ")"
                Dim q As String = "select [ENLONGATION_ACT],COIL_STARTDATETIME from CRM_SPM_PROCESS_DATA_COILWISE_BODY "
                q &= "Where " & fil
                q &= " order by COIL_STARTDATETIME asc"
                Dim defdt As DataTable = getdatatable(q)
                ' get details for markline
                If dt.Rows.Count > 0 Then
                    'Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("HCL Acid T4")

                    'Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(pltcmfrom, pltcmto, "HCL Acid T4")

                    'CalculateCPK(dt, "ENLONGATION_ACT", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)
                    ' plot the graph
                    PlotLinegraph_all(dt, defdt, "COIL_STARTDATETIME", "ENLONGATION_ACT", l, a(i), "plot" & i + 1, "%", usl, lsl, avg, ucl, lcl)
                End If
            End If
            If a(i) = "Furnace Cooling Duration" Then
                Dim from As DateTime = baffrom
                Dim f As String = from.ToString("yyyy-MM-dd HH:mm:ss")
                Dim todate As DateTime = bafto
                Dim t As String = todate.ToString("yyyy-MM-dd HH:mm:ss")
                ' get data from that process
                Dim s As String = "select datediff(hour,[STR_TM_EVENT10], [STR_TM_EVENT11]) as Diff,str_tm_heating_st from T_BAF_DETAILS "
                s &= "where str_tm_heating_st between '" & f & "' and '" & t & "' and CCL_TDC_AIM in (" & strTDC & ") and ANC_GRD_STEEL in (" & strGrade & ") order by str_tm_heating_st asc"
                Dim dt As DataTable = getdatatable(s)
                Dim fil As String = ""
                For j As Integer = 0 To stickerdt.Rows.Count - 1
                    If j = stickerdt.Rows.Count - 1 Then
                        fil &= "CCL_ID_COIL Like '" & stickerdt.Rows(j)(0).Substring(0, 6) & "%'"
                    Else
                        fil &= "CCL_ID_COIL like '" & stickerdt.Rows(j)(0).Substring(0, 6) & "%' or "
                    End If
                Next
                fil &= " and CCL_TDC_AIM in (" & strTDC & ")"
                fil &= " and ANC_GRD_STEEL in (" & strGrade & ")"
                Dim q As String = "select datediff(hour,[STR_TM_EVENT10], [STR_TM_EVENT11]) as Diff,str_tm_heating_st from T_BAF_DETAILS where " & fil
                q &= " order by str_tm_heating_st asc"

                Dim defdt As DataTable = getdatatable(q)
                ' get details for markline
                If dt.Rows.Count > 0 Then
                    Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("BAF_Furn_cooling")

                    Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(f, t, "BAF_Furn_cooling")

                    CalculateCPK(dt, "Diff", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)
                    ' plot the graph
                    PlotLinegraph_all(dt, defdt, "str_tm_heating_st", "Diff", l, a(i), "plot" & i + 1, "Hours", usl, dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                End If
            End If
            If a(i) = "Coil Age(Hours)" Then
                ' get data from that process
                Dim from As DateTime = baffrom
                Dim f As String = from.ToString("dd-MMM-yy HH:mm")
                Dim todate As DateTime = bafto
                Dim t As String = todate.ToString("dd-MMM-yy HH:mm")
                Dim s As String = "select to_char(str_tm_heating_st,'yyyy-mm-dd HH24:MI:SS') str_tm_heating_st, round(24*(SPL_TM_ROLL_ST-STR_TM_DESTACKING)) Datediff"
                s &= " FROM  v_stack_result"
                s &= " INNER JOIN v_anealed_coil  ON str_id_stack = anc_id_stack"
                s &= " INNER JOIN v_skin_pass_coil On spl_id_mother_coil = anc_id_coil"
                s &= " inner join v_cold_coil on spl_id_coil=ccl_id_coil"
                s &= " where str_tm_heating_st between to_date('" & f & "','DD-MON-YY HH24:MI')   and to_date('" & t & "','DD-MON-YY HH24:MI')"
                s &= "and ccl_tdc_aim in (" & strTDC & ") and spl_grd_prod in (" & strGrade & ")"
                s &= " order by str_tm_heating_st asc"
                Dim dt As DataTable = objDataHandler.GetOracleData(s)
                Dim fil As String = ""
                For j As Integer = 0 To rustdt.Rows.Count - 1
                    If j = rustdt.Rows.Count - 1 Then
                        fil &= "spl_id_coil like '" & rustdt.Rows(j)(0).Substring(0, 6) & "%'"
                    Else
                        fil &= "spl_id_coil like '" & rustdt.Rows(j)(0).Substring(0, 6) & "%' or "
                    End If
                Next
                fil &= " and ccl_tdc_aim in (" & strTDC & ")"
                fil &= " and spl_grd_prod in (" & strGrade & ")"
                Dim q As String = "select to_char(str_tm_heating_st,'yyyy-mm-dd HH24:MI:SS') str_tm_heating_st, round(24*(SPL_TM_ROLL_ST-STR_TM_DESTACKING)) Datediff"
                q &= " FROM  v_stack_result"
                q &= " INNER JOIN v_anealed_coil  ON str_id_stack = anc_id_stack"
                q &= " INNER JOIN v_skin_pass_coil On spl_id_mother_coil = anc_id_coil"
                q &= " inner join v_cold_coil on spl_id_coil=ccl_id_coil"
                q &= " where " & fil
                q &= " order by str_tm_heating_st asc"
                Dim defdt As DataTable = objDataHandler.GetOracleData(q)
                ' get details for markline
                If dt.Rows.Count > 0 Then
                    Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("Coil_Age_BAF")

                    Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(f, t, "Coil_Age_BAF")

                    CalculateCPK(dt, "Datediff", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)
                    ' plot the graph
                    PlotLinegraph_all(dt, defdt, "str_tm_heating_st", "Datediff", l, a(i), "plot" & i + 1, "Hours", dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                End If
            End If
            If a(i) = "Strip Ra(Microns)" Then
                ' get data from that process
                Dim from As DateTime = baffrom
                Dim f As String = from.ToString("dd-MMM-yy HH:mm")
                Dim todate As DateTime = bafto
                Dim t As String = todate.ToString("dd-MMM-yy HH:mm")
                Dim s As String = "select nvl(min(decode(a.ltr_param_test,'RA',a.ltr_test_value)),'0')RA, to_char(ltr_ts_test,'yyyy-mm-dd HH24:MI:SS') ltr_ts_test "
                s &= " from V_Lab_tst_res a where  a.ltr_seq_sample=(select max(ltr_seq_sample) from v_lab_tst_res where ltr_id_coil=A.ltr_id_coil)"
                s &= " And ltr_ts_test between to_date('" & f & "','DD-MON-YY HH24:MI')   and to_date('" & t & "','DD-MON-YY HH24:MI')"
                s &= "   Group by ltr_ts_test order by ltr_ts_test asc"
                Dim dt As DataTable = objDataHandler.GetOracleData(s)
                Dim fil As String = ""
                For j As Integer = 0 To stickerdt.Rows.Count - 1
                    If j = stickerdt.Rows.Count - 1 Then
                        fil &= "ltr_id_coil like '" & stickerdt.Rows(j)(0).Substring(0, 6) & "%'"
                    Else
                        fil &= "ltr_id_coil like '" & stickerdt.Rows(j)(0).Substring(0, 6) & "%' or "
                    End If
                Next
                Dim q As String = "select nvl(min(decode(a.ltr_param_test,'RA',a.ltr_test_value)),'0')RA, to_char(ltr_ts_test,'yyyy-mm-dd HH24:MI:SS') ltr_ts_test "
                q &= " from V_Lab_tst_res a where  a.ltr_seq_sample=(select max(ltr_seq_sample) from v_lab_tst_res where ltr_id_coil=A.ltr_id_coil)"
                q &= " And " & fil
                q &= "   Group by ltr_ts_test order by ltr_ts_test asc"

                Dim defdt As DataTable = objDataHandler.GetOracleData(q)
                ' get details for markline
                If dt.Rows.Count > 0 Then
                    Dim dtLimit As DataTable = objController.GetLimitForCRMDaily("SPM_RA")

                    Dim dtRemarks As DataTable = objController.GetRemarksForCRMDaily(f, t, "SPM_RA")

                    CalculateCPK(dt, "RA", dtLimit, avg, usl, lsl, lcl, ucl, standev, unit, Cpk1, Cp1)
                    ' plot the graph
                    PlotLinegraph_all(dt, defdt, "ltr_ts_test", "RA", l, a(i), "plot" & i + 1, "Microns", dtLimit.Rows(0)("USL"), dtLimit.Rows(0)("LSL"), avg, ucl, lcl, dtRemarks)
                End If
            End If
        Next

    End Sub

    Public Sub CalculateCPK(ByVal dt As DataTable, ByVal ColumnName As String, ByVal dtLimit As DataTable, ByRef Avg As Double, ByRef usl As Double, ByRef lsl As Double, ByRef lcl As Double, ByRef ucl As Double, ByRef standev As Double, ByRef unit As String, ByRef Cpk1 As Double, ByRef Cp1 As Double)

        'Dim usl As Double = 0.0
        'Dim lsl As Double = 0.0
        'Dim avg As Double = 0.0
        'Dim lcl As Double = 0.0
        'Dim ucl As Double = 0.0
        'Dim standev As Double = 0.0
        'Dim unit As String = ""
        Dim sum As Integer = 0

        Dim yVal() As String
        yVal = (From row In dt Select col = row(ColumnName).ToString).ToArray()

        For j As Integer = 0 To dt.Rows.Count - 1
            Try
                sum = sum + dt.Rows(j)(ColumnName)
            Catch ex As Exception
                Continue For
            End Try



        Next
        Avg = sum / dt.Rows.Count

        'Commented by pratik said by Dinesh
        'lblAvg.Text = Math.Round(avg, 3)

        For k As Integer = 0 To dt.Rows.Count - 1
            Try
                standev += Pow(dt.Rows(k)(ColumnName) - Avg, 2)
            Catch ex As Exception
                Continue For
            End Try

        Next
        standev = Math.Sqrt(standev / dt.Rows.Count)
        lcl = Avg - (3 * standev)
        ucl = Avg + (3 * standev)
        'lblLCL.Text = Math.Round(lcl, 3)
        'lblUCL.Text = Math.Round(ucl, 3)
        'lblStddev.Text = Math.Round(standev, 3)
        Dim val1 As Double = 0.0
        Dim val2 As Double = 0.0

        ''Ádded on 25 may 2020
        Dim usl1, lsl1 As Double
        lsl1 = dtLimit.Rows(0)("LSL")
        If IsDBNull(dtLimit.Rows(0)("USL")) Then
            usl1 = 0
        Else
            usl1 = dtLimit.Rows(0)("USL")
        End If

        If IsDBNull(dtLimit.Rows(0)("Unit")) Then
            unit = ""
        Else
            unit = dtLimit.Rows(0)("Unit")
        End If
        'lblUnitVal.Text = unit
        val1 = (usl1 - Avg) / (3 * standev)
        val2 = (Avg - lsl1) / (3 * standev)

        'Dim Cpk As Double = 0.0
        Cpk1 = Math.Min(val1, val2)
        'lblCpk.Text = Math.Round(Cpk, 3)
        'Dim Cp As Double = 0.0
        Dim lst = yVal.ToList()
        Dim nullOrEmptyItemCount = lst.RemoveAll(Function(s) String.IsNullOrEmpty(s))
        Cp1 = ((lst.Max() - lst.Min()) / (6 * standev))
        'lblCp.Text = Math.Round(Cp, 3)
        'lblMean.Text = Math.Round(Avg, 3)



    End Sub

    Public Sub PlotLinegraph_all(ByVal dt As DataTable, ByVal defdt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal YAxisLabelName As String, ByVal usl As Double, ByVal lsl As Double, ByVal avg As Double, ByVal ucl As Double, ByVal lcl As Double, Optional dtremarks As DataTable = Nothing)
        Try


            LiteralName.Text = ""
            'Dim dv1 As DataView = dt.DefaultView
            'Dim dv2 As DataView = defdt.DefaultView
            'Dim max As String = dt.Rows(dt.Rows.Count - 1)(0)
            'Dim min As String = dt.Rows(0)(0)
            Dim line1 As String = ""
            Dim line2 As String = ""
            'Dim dtDist1 As DataTable = dt.DefaultView.ToTable(True, XAxisColName)
            'Dim dtDist2 As DataTable = defdt.DefaultView.ToTable(True, XAxisColName)
            'Dim full_data1 As DataTable
            'full_data1 = dt.DefaultView.ToTable(True, XAxisColName).Copy()
            'full_data1.Merge(dtDist2, False, MissingSchemaAction.Ignore)

            'Dim full_data As DataTable = full_data1.DefaultView.ToTable(True, XAxisColName)
            For i As Integer = 0 To dt.Rows.Count - 1
                Try
                    If i = dt.Rows.Count - 1 And Not (dt.Rows(i)(YAxisColName)).ToString() = "" Then
                        line1 &= "['" & (Convert.ToDateTime(dt.Rows(i)(XAxisColName))).ToString("yyyy-MM-dd HH:mm:ss") & "', " & Math.Round(dt.Rows(i)(YAxisColName), 2) & "]"
                    ElseIf Not (dt.Rows(i)(YAxisColName)).ToString() = "" Then
                        line1 &= "['" & (Convert.ToDateTime(dt.Rows(i)(XAxisColName))).ToString("yyyy-MM-dd HH:mm:ss") & "', " & Math.Round(dt.Rows(i)(YAxisColName), 2) & "],"
                    End If

                Catch ex As Exception
                    Throw ex
                End Try
            Next
            For i As Integer = 0 To defdt.Rows.Count - 1
                Try
                    If i = defdt.Rows.Count - 1 And Not (defdt.Rows(i)(YAxisColName)).ToString() = "" Then
                        line2 &= "['" & (Convert.ToDateTime(defdt.Rows(i)(XAxisColName))).ToString("yyyy-MM-dd HH:mm:ss") & "', " & Math.Round(defdt.Rows(i)(YAxisColName), 2) & "]"
                    ElseIf Not (defdt.Rows(i)(YAxisColName)).ToString() = "" Then
                        line2 &= "['" & (Convert.ToDateTime(defdt.Rows(i)(XAxisColName))).ToString("yyyy-MM-dd HH:mm:ss") & "', " & Math.Round(defdt.Rows(i)(YAxisColName), 2) & "],"
                    End If

                Catch ex As Exception
                    Throw ex
                End Try
            Next

            ' to pass empty field
            'For i As Integer = 0 To full_data.Rows.Count - 1
            '    Try
            '        dv1.RowFilter = "STR_TM_HEATING_ST = '" & full_data.Rows(i)(0) & "' or STR_TM_HEATING_ST is null"
            '        Dim tempfat As DataTable = dv1.ToTable()

            '        dv2.RowFilter = "STR_TM_HEATING_ST = '" & full_data.Rows(i)(0) & "' or STR_TM_HEATING_ST is null"
            '        Dim tempdt As DataTable = dv2.ToTable()
            '        y &= Math.Round(tempfat.Rows(0)(YAxisColName), 2) & ","
            '        x &= "'" & (Convert.ToDateTime(full_data.Rows(i)(0))).ToString("yyyy-MM-dd") & "',"
            '        Try
            '            y1 &= Math.Round(tempdt.Rows(0)(YAxisColName), 2) & ","
            '        Catch ex As Exception
            '            y1 &= ","
            '        End Try


            '    Catch ex As Exception
            '        Continue For
            '    End Try
            ' Next

            ContainerName = ContainerName.Replace(" ", "_")
            Dim js As String = ""
            js &= " <script type='text/javascript'> var " & PlotName & " = echarts.init(document.getElementById('" & ContainerName & "'));"
            js &= "option = {tooltip: {trigger: 'item'},"
            js &= "legend: {},"
            js &= "grid: {left:   '10%',right:  '10%',bottom:  '10%',containLabel: true},"
            js &= "toolbox: {show: true,feature: {dataZoom: {yAxisIndex: 'none'},restore: {},saveAsImage: {}}},"
            js &= "xAxis: {type: 'time',axisLabel : { formatter: '{value}',fontWeight:'bold',rotate: 45},name: '" & XAxisColName & "',nameLocation: 'middle',nameGap: 70,nameTextStyle: {fontWeight:'bold'},"
            js &= "splitLine: {show:true,lineStyle: {color: 'grey'}}},"
            'js &= "xAxis: [{type: 'category',axisLabel : { formatter: '{value}',fontWeight:'bold',rotate: 45},name: '" & XAxisColName & "',nameLocation: 'middle',nameGap: 70,nameTextStyle: {fontWeight:'bold'},"
            'js &= "data: [" & x & "],splitLine: {show:true,lineStyle: {color: 'grey'}}"
            'js &= "},{type: 'category',axisLabel : {formatter: '{value}',fontWeight:'bold',rotate: 45},name: '" & XAxisColName & "',nameLocation: 'middle',nameGap: 70,nameTextStyle: {fontWeight:'bold'},"
            'js &= "data: [" & x1 & "]}],"
            js &= " yAxis : [{type : 'value',axisLabel : {formatter: '{value}',fontWeight:'bold'},name: '" & YAxisLabelName & "',nameLocation: 'middle',nameGap: 50,nameTextStyle: {fontWeight:'bold'} }],"
            js &= "dataZoom: [{type: 'slider',xAxisIndex: 0,filterMode: 'empty'},{type: 'slider',yAxisIndex: 0,filterMode: 'empty'},{type: 'inside',xAxisIndex: 0,filterMode: 'empty'},{type: 'inside',yAxisIndex: 0,filterMode: 'empty'}],"
            js &= "series: [{name: '" & ContainerName & "',type: 'scatter',color: '#3e86f0' ,"
            js &= "data: [" & line1 & "] },"
            js &= "{name: 'Defect',type: 'scatter',color: 'black' ,data: [" & line2 & "] },"
            js &= "{name:   'Average',type: 'line',color: 'green',markLine : {lineStyle:{type: 'solid'},data :[{yAxis:'" & Math.Round(avg, 2) & "'}]}},"
            js &= "{name:   'USL',type: 'line',color: 'red',markLine : {lineStyle:{type: 'solid'},data :[{yAxis:'" & Math.Round(usl, 2) & "'}]}},"
            js &= "{name:   'LSL',type: 'line',color: 'red',markLine : {lineStyle:{type: 'solid'},data :[{yAxis:'" & Math.Round(lsl, 2) & "'}]}},"
            js &= "{name:   'UCL',type: 'line',color: '#c79e08',markLine : {lineStyle:{type: 'solid'},data :[{yAxis:'" & Math.Round(ucl, 2) & "'}]}},"
            js &= "{name:   'LCL',type: 'line',color: '#c79e08',markLine : {lineStyle:{type: 'solid'},data :[{yAxis:'" & Math.Round(lcl, 2) & "'}]}},"
            ' js &= "{name:   'Remarks',type: 'line',color: 'black',markLine : {data :[{yAxis:'" & r & "'}]}}"
            js &= "]};"
            js &= "" & PlotName & ".setOption(option);</script>"
            LiteralName.Text = js
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Private Sub ddlDefectdrop_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlDefectdrop.SelectedIndexChanged
        Dim selected As String = ddlDefectdrop.SelectedValue
        If selected = "ALKALI C/O" Then
            Setdates(alkalidt)
            Multibar(alkalidt)
        End If
        If selected = "MECH PROP NOT OK" Then
            Setdates(mechdt)
            Multibar(mechdt)
        End If
        If selected = "RIS" Then
            Setdates(risdt)
            Multibar(risdt)
        End If
        If selected = "RUBBING MARK" Then
            Setdates(rubbingdt)
            Multibar(rubbingdt)
        End If
        If selected = "RUST" Then
            Setdates(rustdt)
            Multibar(rustdt)
        End If
        If selected = "SCUM" Then
            Setdates(scumdt)
            Multibar(scumdt)
        End If
        If selected = "STICKER" Then
            Setdates(stickerdt)
            Multibar(stickerdt)
        End If
        If selected = "STRECHER STRAIN" Then
            Setdates(strecherdt)
            Multibar(strecherdt)
        End If
        dynamicdiv(selected)
    End Sub

    Public Sub plotMultipleBar(ByVal data1 As String, ByVal data2 As String, ByVal data3 As String, ByVal data4 As String, ByVal ymax As Integer, ByVal xmin As String, ByVal xmax As String, ByVal ContainerName As String, ByVal LiteralName As Literal)
        Try
            LiteralName.Text = ""
            Dim js As String = ""
            js &= " <script type='text/javascript'> var " & ContainerName & " = echarts.init(document.getElementById('" & ContainerName & "'));"
            js &= "data1 =[" & data1 & "];"
            js &= "data2 =[" & data2 & "];"
            js &= "data3 =[" & data3 & "];"
            js &= "data4 =[" & data4 & "];"
            'js &= "var dateList = data.map(function (item) {return item[0];});"
            'js &= "var valueList = data.map(function (item) {return item[1];});"
            js &= "option = {"
            js &= "title: [{top: '0%',left: 'center',text: 'PLTCM'}],"
            js &= "tooltip: {trigger: 'axis'},"
            js &= "toolbox: {feature: {dataZoom: {yAxisIndex: 'none'},restore: {},saveAsImage: {}}},"
            js &= "dataZoom: [{type: 'slider',xAxisIndex: [0],filterMode: 'empty'}],"
            js &= "xAxis: [{type: 'time',min:'" & xmin & "',max:'" & xmax & "'}],"
            js &= "yAxis: [{splitLine: {show: false},max:" & ymax & ",name: 'Defect Quantity(Ton)',axisLabel : { formatter: '{value}',fontWeight:'bold',fontSize:15},nameLocation: 'middle',nameGap: 35,nameTextStyle: {fontWeight:'bold',fontSize:12}}],"
            js &= "grid: [{top: '5%',bottom: '15%'}],"
            js &= "series: [{type: 'bar',showSymbol: false,data: data1,barWidth:5}]"
            js &= "};"
            js &= ContainerName & ".setOption(option);"
            'js &= ContainerName & ".on('click', function (params) {heat( params.name );});"
            js &= "$(window).resize(function() {" & ContainerName & ".resize(); });</script>"
            LiteralName.Text = js
        Catch ex As Exception

        End Try
    End Sub
    Public Sub Multibar(ByVal dt As DataTable)
        Dim s As String = ""
        Dim filter As String = ""
        For i As Integer = 0 To dt.Rows.Count - 1
            If i = dt.Rows.Count - 1 Then
                filter &= "CR_COIL_ID like '" & dt.Rows(i)(0).Substring(0, 6) & "%'"
            Else
                filter &= "CR_COIL_ID like '" & dt.Rows(i)(0).Substring(0, 6) & "%' or "
            End If
        Next
        ' s = "SELECT [CR_COIL_ID] ,[TCM_ROLLING_DT],[ECL_DATETIME],[SPM_DATETIME],[BAF_DATETIME] FROM [CRM_HR_CR_RLN] where " & filter
        s = "SELECT [CR_COIL_ID] ,nullif(CONVERT(varchar,[TCM_ROLLING_DT],111),'1900/01/01')as TCM_ROLLING_DT,nullif(CONVERT(varchar,[ECL_DATETIME],111),'1900/01/01')as ECL_DATETIME,nullif(CONVERT(varchar,[BAF_DATETIME],111),'1900/01/01') as BAF_DATETIME,nullif(CONVERT(varchar,[SPM_DATETIME],111),'1900/01/01') as SPM_DATETIME FROM [CRM_HR_CR_RLN] where " & filter
        's = "SELECT [CR_COIL_ID] ,nullif([TCM_ROLLING_DT],'1900-01-01 00:00:00.000')as TCM_ROLLING_DT,nullif([ECL_DATETIME],'1900-01-01 00:00:00.000')as ECL_DATETIME,nullif([BAF_DATETIME],'1900-01-01 00:00:00.000') as BAF_DATETIME,nullif([SPM_DATETIME],'1900-01-01 00:00:00.000') as SPM_DATETIME FROM [CRM_HR_CR_RLN] where " & filter
        Dim tempdt As DataTable = getdatatable(s)
        tempdt.Columns.Add(New DataColumn("Tonnage", GetType(Decimal)))
        For i As Integer = 0 To tempdt.Rows.Count - 1
            For j As Integer = 0 To dt.Rows.Count - 1
                If tempdt.Rows(i)("CR_COIL_ID").Substring(0, 6) = dt.Rows(j)("chr_id_coil").Substring(0, 6) Then
                    tempdt.Rows(i)("Tonnage") = dt.Rows(j)("ccl_ms_piece_actl")
                End If
            Next
        Next

        'Dim MaxValue As Double = tempdt.AsEnumerable().Max(Function(row) Convert.ToDouble(row("Tonnage")))
        'Dim Max As Integer = Math.Round(MaxValue / 10) * 10
        'PlotLinegraph(dt, Lit2, "main2")
        Dim data1 As String = ""
        Dim data2 As String = ""
        Dim data3 As String = ""
        Dim data4 As String = ""
        'use data directly
        'For i As Integer = 0 To tempdt.Rows.Count - 1
        '    If Not (tempdt.Rows(i)(1).ToString() = "") Then
        '        'data1 &= "['" & Convert.ToDateTime(tempdt.Rows(i)(1)).ToString("yyyy-MM-dd") & "'," & tempdt.Rows(i)("Tonnage") & "],"
        '    End If
        '    If Not (tempdt.Rows(i)(2).ToString() = "") Then
        '        data2 &= "['" & Convert.ToDateTime(tempdt.Rows(i)(2)).ToString("yyyy-MM-dd") & "'," & tempdt.Rows(i)("Tonnage") & "],"
        '    End If
        '    If Not (tempdt.Rows(i)(3).ToString() = "") Then
        '        data3 &= "['" & Convert.ToDateTime(tempdt.Rows(i)(3)).ToString("yyyy-MM-dd") & "'," & tempdt.Rows(i)("Tonnage") & "],"
        '    End If
        '    If Not (tempdt.Rows(i)(4).ToString() = "") Then
        '        data4 &= "['" & Convert.ToDateTime(tempdt.Rows(i)(4)).ToString("yyyy-MM-dd") & "'," & tempdt.Rows(i)("Tonnage") & "],"
        '    End If
        'Next
        Dim tcmdt As DataTable = New DataTable()
        'Dim dr As DataRow
        dt.TableName = "tcmdt"
        tcmdt.Columns.Add(New DataColumn("TCM_ROLLING_DT", GetType(Date)))
        tcmdt.Columns.Add(New DataColumn("Tonnage", GetType(Decimal)))
        'dr = PLDT.NewRow()
        'PLDT.Rows.Add(dr)
        ViewState("tcmdt") = tcmdt

        Dim ecldt As DataTable = New DataTable()
        dt.TableName = "ecldt"
        ecldt.Columns.Add(New DataColumn("ECL_DATETIME", GetType(Date)))
        ecldt.Columns.Add(New DataColumn("Tonnage", GetType(Decimal)))
        ViewState("ecldt") = ecldt

        Dim bafdt As DataTable = New DataTable()
        dt.TableName = "bafdt"
        bafdt.Columns.Add(New DataColumn("BAF_DATETIME", GetType(Date)))
        bafdt.Columns.Add(New DataColumn("Tonnage", GetType(Decimal)))
        ViewState("bafdt") = bafdt

        Dim spmdt As DataTable = New DataTable()
        dt.TableName = "spmdt"
        spmdt.Columns.Add(New DataColumn("SPM_DATETIME", GetType(Date)))
        spmdt.Columns.Add(New DataColumn("Tonnage", GetType(Decimal)))
        ViewState("spmdt") = spmdt


        For i As Integer = 0 To tempdt.Rows.Count - 1
            If Not (tempdt.Rows(i)(1).ToString() = "") Then
                tcmdt.Rows.Add(Convert.ToDateTime(tempdt.Rows(i)(1)).ToString("yyyy-MM-dd"), tempdt.Rows(i)("Tonnage"))
                'data1 &= "['" & Convert.ToDateTime(tempdt.Rows(i)(1)).ToString("yyyy-MM-dd") & "'," & tempdt.Rows(i)("Tonnage") & "],"
            End If
            If Not (tempdt.Rows(i)(2).ToString() = "") Then
                ecldt.Rows.Add(Convert.ToDateTime(tempdt.Rows(i)(2)).ToString("yyyy-MM-dd"), tempdt.Rows(i)("Tonnage"))
                'data2 &= "['" & Convert.ToDateTime(tempdt.Rows(i)(2)).ToString("yyyy-MM-dd") & "'," & tempdt.Rows(i)("Tonnage") & "],"
            End If
            If Not (tempdt.Rows(i)(3).ToString() = "") Then
                bafdt.Rows.Add(Convert.ToDateTime(tempdt.Rows(i)(3)).ToString("yyyy-MM-dd"), tempdt.Rows(i)("Tonnage"))
                'data3 &= "['" & Convert.ToDateTime(tempdt.Rows(i)(3)).ToString("yyyy-MM-dd") & "'," & tempdt.Rows(i)("Tonnage") & "],"
            End If
            If Not (tempdt.Rows(i)(4).ToString() = "") Then
                spmdt.Rows.Add(Convert.ToDateTime(tempdt.Rows(i)(4)).ToString("yyyy-MM-dd"), tempdt.Rows(i)("Tonnage"))
                'data4 &= "['" & Convert.ToDateTime(tempdt.Rows(i)(4)).ToString("yyyy-MM-dd") & "'," & tempdt.Rows(i)("Tonnage") & "],"
            End If
        Next

        Dim d_min1 As Date = tcmdt.AsEnumerable().[Select](Function(cols) cols.Field(Of DateTime)(0)).OrderBy(Function(p) p.Ticks).FirstOrDefault()
        Dim d_max1 As Date = tcmdt.AsEnumerable().[Select](Function(cols) cols.Field(Of DateTime)(0)).OrderByDescending(Function(p) p.Ticks).FirstOrDefault()
        Dim d_min2 As Date = ecldt.AsEnumerable().[Select](Function(cols) cols.Field(Of DateTime)(0)).OrderBy(Function(p) p.Ticks).FirstOrDefault()
        Dim d_max2 As Date = ecldt.AsEnumerable().[Select](Function(cols) cols.Field(Of DateTime)(0)).OrderByDescending(Function(p) p.Ticks).FirstOrDefault()
        Dim d_min3 As Date = bafdt.AsEnumerable().[Select](Function(cols) cols.Field(Of DateTime)(0)).OrderBy(Function(p) p.Ticks).FirstOrDefault()
        Dim d_max3 As Date = bafdt.AsEnumerable().[Select](Function(cols) cols.Field(Of DateTime)(0)).OrderByDescending(Function(p) p.Ticks).FirstOrDefault()
        Dim d_min4 As Date = spmdt.AsEnumerable().[Select](Function(cols) cols.Field(Of DateTime)(0)).OrderBy(Function(p) p.Ticks).FirstOrDefault()
        Dim d_max4 As Date = spmdt.AsEnumerable().[Select](Function(cols) cols.Field(Of DateTime)(0)).OrderByDescending(Function(p) p.Ticks).FirstOrDefault()
        Dim xmin As Date = d_min1
        Dim xmax As Date = d_max1
        Dim max As Double = 0

        If DateDiff(DateInterval.Day, d_min2, xmin) > 0 Then
            xmin = d_min2
        End If
        If DateDiff(DateInterval.Day, xmax, d_max2) > 0 Then
            xmax = d_max2
        End If
        If DateDiff(DateInterval.Day, d_min3, xmin) > 0 Then
            xmin = d_min3
        End If
        If DateDiff(DateInterval.Day, xmax, d_max3) > 0 Then
            xmax = d_max3
        End If
        If DateDiff(DateInterval.Day, d_min4, xmin) > 0 Then
            xmin = d_min4
        End If
        If DateDiff(DateInterval.Day, xmax, d_max4) > 0 Then
            xmax = d_max4
        End If
        'Dim recentTen As DataTable = tempdt.AsEnumerable().OrderByDescending(Function(r) r.Field(Of DateTime)("TCM_ROLLING_DT")).GroupBy(Function(r) r.Field(Of DateTime)("TCM_ROLLING_DT")).[Select](Function(g) g.First()).CopyToDataTable()
        Dim Series1() = (From row In tcmdt Select col = row.Field(Of DateTime)("TCM_ROLLING_DT") Distinct Order By Asc("TCM_ROLLING_DT")).ToArray
        'Order By val.Field(Of Date)("TCM_ROLLING_DT") Ascending
        For i As Integer = 0 To Series1.Length - 1
            Dim x = i
            Dim query = From val In tcmdt.AsEnumerable() Where val.Field(Of DateTime)("TCM_ROLLING_DT") = Series1(x) Select val
            Dim dtValue = query.CopyToDataTable()
            Dim result1 As Decimal = dtValue.AsEnumerable().Sum(Function(row) row.Field(Of Decimal)("Tonnage"))
            If result1 > max Then
                max = result1
            End If
            If i = Series1.Length - 1 Then
                data1 &= "['" & Convert.ToDateTime(Series1(i)).ToString("yyyy-MM-dd") & "'," & result1 & "]"
            Else
                data1 &= "['" & Convert.ToDateTime(Series1(i)).ToString("yyyy-MM-dd") & "'," & result1 & "],"
            End If
        Next
        Dim Series2() = (From row In ecldt Select col = row.Field(Of DateTime)("ECL_DATETIME") Distinct Order By Asc("ECL_DATETIME")).ToArray
        'Order By val.Field(Of Date)("TCM_ROLLING_DT") Ascending
        For i As Integer = 0 To Series2.Length - 1
            Dim x = i
            Dim query = From val In ecldt.AsEnumerable() Where val.Field(Of DateTime)("ECL_DATETIME") = Series2(x) Select val
            Dim dtValue = query.CopyToDataTable()
            Dim result1 As Decimal = dtValue.AsEnumerable().Sum(Function(row) row.Field(Of Decimal)("Tonnage"))
            If result1 > max Then
                max = result1
            End If
            If i = Series2.Length - 1 Then
                data2 &= "['" & Convert.ToDateTime(Series2(i)).ToString("yyyy-MM-dd") & "'," & result1 & "]"
            Else
                data2 &= "['" & Convert.ToDateTime(Series2(i)).ToString("yyyy-MM-dd") & "'," & result1 & "],"
            End If
        Next
        Dim Series3() = (From row In bafdt Select col = row.Field(Of DateTime)("BAF_DATETIME") Distinct Order By Asc("BAF_DATETIME")).ToArray
        'Order By val.Field(Of Date)("TCM_ROLLING_DT") Ascending
        For i As Integer = 0 To Series3.Length - 1
            Dim x = i
            Dim query = From val In bafdt.AsEnumerable() Where val.Field(Of DateTime)("BAF_DATETIME") = Series3(x) Select val
            Dim dtValue = query.CopyToDataTable()
            Dim result1 As Decimal = dtValue.AsEnumerable().Sum(Function(row) row.Field(Of Decimal)("Tonnage"))
            If result1 > max Then
                max = result1
            End If
            If i = Series3.Length - 1 Then
                data3 &= "['" & Convert.ToDateTime(Series3(i)).ToString("yyyy-MM-dd") & "'," & result1 & "]"
            Else
                data3 &= "['" & Convert.ToDateTime(Series3(i)).ToString("yyyy-MM-dd") & "'," & result1 & "],"
            End If
        Next
        Dim Series4() = (From row In spmdt Select col = row.Field(Of DateTime)("SPM_DATETIME") Distinct Order By Asc("SPM_DATETIME")).ToArray
        'Order By val.Field(Of Date)("TCM_ROLLING_DT") Ascending
        For i As Integer = 0 To Series4.Length - 1
            Dim x = i
            Dim query = From val In spmdt.AsEnumerable() Where val.Field(Of DateTime)("SPM_DATETIME") = Series4(x) Select val
            Dim dtValue = query.CopyToDataTable()
            Dim result1 As Decimal = dtValue.AsEnumerable().Sum(Function(row) row.Field(Of Decimal)("Tonnage"))
            If result1 > max Then
                max = result1
            End If
            If i = Series4.Length - 1 Then
                data4 &= "['" & Convert.ToDateTime(Series4(i)).ToString("yyyy-MM-dd") & "'," & result1 & "]"
            Else
                data4 &= "['" & Convert.ToDateTime(Series4(i)).ToString("yyyy-MM-dd") & "'," & result1 & "],"
            End If
        Next
        Dim ymax As Integer = Math.Ceiling(max / 10) * 10
        Dim x_min As String = xmin.ToString("yyyy-MM-dd")
        Dim x_max As String = xmax.ToString("yyyy-MM-dd")
        plotMultipleBar(data1, data2, data3, data4, ymax, x_min, x_max, "main1", Lit1)
    End Sub

    Private Sub btnchangegrade_Click(sender As Object, e As EventArgs) Handles btnchangegrade.Click
        Dim fromDt As String = hfFrom.Value
        Dim toDt As String = CDate(hfTo.Value).ToString("yyyy-MM-dd 06:00:00")
        lstTdc.Visible = True
        Lit1.Text = ""
        dynamicdiv("")
        lblDefectdrop.Visible = False
        ddlDefectdrop.Visible = False
        LoadTdc(fromDt, toDt)
    End Sub
End Class
