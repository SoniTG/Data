﻿Imports System.Data
Imports System.IO

Partial Class CRM_Defect_Variable_MAP29_
    Inherits System.Web.UI.Page

    Dim db As New DataHandler
    Dim objController As New Controller

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
            GENERATETREE()
        End If
    End Sub

    Private Sub GENERATETREE()

        Dim jsonString As New StringBuilder("<script> var treeData = {""name"": ""CRM"",""parent"": ""null"",""children"": [")
        Dim tablenme As String = "CRM_DEFECT_VARIABLE_MAP30"

        Dim dtL1 As DataTable = db.GetDataSetFromQuery("SELECT  distinct  [Process_Line] FROM [FP_PROCESS_DATA].[dbo].[" & tablenme & "]   ").Tables(0)
        For i As Integer = 0 To dtL1.Rows.Count - 1

            jsonString.Append("{""name"": """ & dtL1.Rows(i)(0) & """,""parent"": ""CRM"",""children"": [")

            Dim dtL2 As DataTable = db.GetDataSetFromQuery("SELECT  distinct [Defect_Name] FROM [FP_PROCESS_DATA].[dbo].[" & tablenme & "]   where [Process_Line]='" & dtL1.Rows(i)(0) & "'").Tables(0)


            For j As Integer = 0 To dtL2.Rows.Count - 1

                jsonString.Append("{""name"": """ & dtL2.Rows(j)(0) & """,""parent"": """ & dtL1.Rows(i)(0) & """, ""children"":[")


                Dim dtL3 As DataTable = db.GetDataSetFromQuery("SELECT  distinct [Chart_Title] FROM [FP_PROCESS_DATA].[dbo].[" & tablenme & "]   where [Defect_Name]='" & dtL2.Rows(j)(0) & "'").Tables(0)

                For k As Integer = 0 To dtL3.Rows.Count - 1

                    jsonString.Append("{""name"": """ & dtL3.Rows(k)(0) & """,""parent"": """ & dtL2.Rows(j)(0) & """},")

                Next

                jsonString.Append("]},")
            Next

            jsonString.Append("]},")

        Next
        jsonString.Append("]}; </script>")


        Literal1.Text = jsonString.ToString
    End Sub

End Class
