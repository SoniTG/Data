﻿Imports System
Imports System.Collections.Generic
'Imports System.Linq
Imports System.Data
Imports System.Text
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
'Imports System.Data.Odbc
Imports System.Data.SqlClient
'Imports System.Data.OleDb
Imports System.Collections.Specialized
Imports System.Configuration
Imports System.IO
Imports System.Timers

Partial Class CRM_SPM
    Inherits System.Web.UI.Page
    Dim objController As New Controller

    Public fileName As String = ""
    Private ConnStr As String = ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString
    Public Shared aTimer As System.Timers.Timer
    Public ChartTableNameNew As String = Nothing
    Public ChartColumnXAxis1 As String = Nothing
    Public ChartColumnYAxis1 As String = Nothing
    Public ChartColumnYAxis2 As String = Nothing

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        ChartTableNameNew = "CRM_SPM_MECH_MODEL_INPUT"
        ChartColumnXAxis1 = "READ_TIME"
        ChartColumnYAxis1 = "Pred_YS"
        ChartColumnYAxis2 = "LENGTH"

        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                'Dim dtStart As String = DateTime.Now.AddDays(-29).ToString("yyyy-MM-dd HH:mm")

                'Dim dtStart As String = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd HH:mm")
                'Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

                'Automatically call Method to generate Chart
                'aTimer = New System.Timers.Timer(60000)
                'AddHandler aTimer.Elapsed, New Timers.ElapsedEventHandler(AddressOf AutoBuildChart)
                'aTimer.Elapsed &= btnBuildChart_Click(dtstart, dtend)
                'aTimer.AutoReset = True
                'aTimer.Enabled = True
                'End Here
                'btnBuildChart_Click(dtStart, dtEnd)
                cmdOk_Click()
                'aTimer = New System.Timers.Timer(20000)
                'AddHandler aTimer.Elapsed, AddressOf cmdOk_Click
                'aTimer.AutoReset = True
                'aTimer.Enabled = True

                'AutoBuildChart()
            Catch ex As Exception
                Console.WriteLine(ex)
            End Try

        Else
            cmdOk_Click()
        End If

    End Sub
    Public Sub AutoBuildChart()
        'Dim dtStart As String = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd HH:mm")
        'Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim aTimer As System.Timers.Timer
        'aTimer = New System.Timers.Timer(60000)
        aTimer = New System.Timers.Timer(6000)
        AddHandler aTimer.Elapsed, AddressOf cmdOk_Click
        aTimer.AutoReset = True
        aTimer.Enabled = True
        'btnImport_Click()
        'btnBuildChart_Click()
        'AutoBuildChart()

    End Sub

    Protected Sub btnImport_Click()
        Dim filePATH As String = "D:\Tirth\Output.txt"
        Dim iDt As DataTable = ImportDataFromCSVFile(filePATH)

        Using conn As SqlConnection = New SqlConnection(ConnStr)
            Dim objbulk As SqlBulkCopy = New SqlBulkCopy(conn)
            objbulk.DestinationTableName = "CRM_SPM_MECH_MODEL"
            objbulk.ColumnMappings.Add("READ_TIME", "READ_TIME")
            objbulk.ColumnMappings.Add("VALUE", "VALUE")
            objbulk.ColumnMappings.Add("LENGTH", "LENGTH")
            conn.Open()
            objbulk.WriteToServer(iDt)
            conn.Close()
        End Using
    End Sub

    Protected Shared Function ImportDataFromCSVFile(ByVal filePath As String) As DataTable
        Dim dt As DataTable = New DataTable()
        dt.Columns.Add(New DataColumn("READ_TIME", GetType(String)))
        dt.Columns.Add(New DataColumn("VALUE", GetType(Single)))
        dt.Columns.Add(New DataColumn("LENGTH", GetType(Single)))

        Try

            Using readFile As StreamReader = New StreamReader(filePath)
                Dim line As String
                Dim sb As StringBuilder = New StringBuilder()
                Dim row As String()
                Dim length As Integer = 0

                While (Not (readFile.EndOfStream))

                    line = readFile.ReadLine()
                    row = line.Split(",")

                    For j As Integer = 0 To row.Length - 1

                        If j = 0 Then
                            row(j) = row(j).Remove(19)
                        ElseIf j = 1 Then
                            Dim strTemp As String = row(j)
                            row(j) = Math.Round(Convert.ToDecimal(strTemp), 2).ToString()
                        ElseIf j = 2 Then
                            Dim strTemp1 As String = row(j).Remove(7)
                            row(j) = Math.Round(Convert.ToDecimal(strTemp1), 2).ToString()
                        End If
                    Next

                    length = row.Length

                    If True Then

                        If row.Length = dt.Columns.Count Then
                            Dim dr As DataRow = dt.NewRow()

                            For i As Integer = 0 To length - 1

                                If row(i).ToString().Contains("""") Then
                                    row(i) = row(i).Replace("""", " ")
                                End If

                                dr(i) = Convert.ToString(row(i))
                            Next

                            dt.Rows.Add(dr)
                        Else
                        End If
                    End If
                End While
            End Using

        Catch ex As Exception
        End Try

        Return dt
    End Function
    Protected Sub btnBuildChart_Click(ByVal dtStart As String, ByVal dtEnd As String, ByVal ChartColumnYAxis1 As String,
                                      ByVal ChartColumnYAxis2 As String, ByVal ChartColumnXAxis1 As String, ByVal ChartTableNameNew As String)
        'sender As Object, e As EventArgs
        Dim dt As DataTable = GetChartData(dtStart, dtEnd, ChartColumnXAxis1, ChartColumnYAxis1, ChartColumnYAxis2, ChartTableNameNew)
        'GenHistogram(dt)
        ' plothistochartLastBarA(dt, ChartColumnYAxis1)
        PlotHistECharts(dt, ChartColumnYAxis1)
        Dim s As StringBuilder = New StringBuilder()
        Literal1.Text = Nothing
        Dim dv As DataView = dt.DefaultView
        'dv.Sort = "READ_TIME"
        'dv.Sort = "COIL_STARTDATETIME"
        'dt = dv.ToTable()
        Dim data As String = Nothing
        Dim data1 As String = Nothing
        Dim date_val As String = Nothing

        For I As Integer = 0 To dt.Rows.Count - 1
            'data += dt.Rows(I)("VALUE") & ","
            'data1 += dt.Rows(I)("LENGTH") & ","
            data += dt.Rows(I)(ChartColumnYAxis1) & ","
            data1 += dt.Rows(I)(ChartColumnYAxis2) & ","

            'Dim dtVal1 As String = dt.Rows(I)("READ_TIME").ToString().Trim().Substring(0, 5)
            'Dim dtVal2 As String = dt.Rows(I)("READ_TIME").ToString().Trim().Substring(11, 8)
            Dim dtVal1 As String = dt.Rows(I)("Time").ToString()
            'Dim dtVal2 As String = dt.Rows(I)("COIL_STARTDATETIME").ToString()
            'Dim date_valF As String = String.Concat(dtVal1, " ", dtVal2)
            date_val += "'" & dtVal1 & "',"
        Next

        'Dim ymin1 As Double = Convert.ToDouble(dt.Compute("min(VALUE)", ""))
        'Dim ymax1 As Double = Convert.ToDouble(dt.Compute("max(VALUE)", ""))
        'Dim ymin2 As Double = Convert.ToDouble(dt.Compute("min(LENGTH)", ""))
        'Dim ymax2 As Double = Convert.ToDouble(dt.Compute("max(LENGTH)", ""))
        Dim ymin1 As Double = Convert.ToDouble(dt.Compute("min(" & ChartColumnYAxis1 & ")", ""))
        Dim ymax1 As Double = Convert.ToDouble(dt.Compute("max(" & ChartColumnYAxis1 & ")", ""))
        Dim ymin2 As Double = Convert.ToDouble(dt.Compute("min(" & ChartColumnYAxis2 & ")", ""))
        Dim ymax2 As Double = Convert.ToDouble(dt.Compute("max(" & ChartColumnYAxis2 & ")", ""))
        s.Append("<script>")
        s.Append("var myChart = echarts.init(document.getElementById('main'));")
        s.Append("const colors = ['#5470C6', '#91CC75', '#EE6666'];")
        s.Append("option = {")
        s.Append("color: colors,")
        s.Append("tooltip:")
        s.Append("{")
        s.Append("trigger: 'axis',")
        s.Append("axisPointer:")
        s.Append("{")
        s.Append("type: 'cross'")
        s.Append("}")
        s.Append("},")
        s.Append("grid:")
        s.Append("{")
        s.Append("right: '10%',")
        s.Append("bottom: '30%'")
        s.Append("},")
        s.Append("toolbox:")
        s.Append("{")
        s.Append("feature:")
        s.Append("{")
        s.Append("dataView: { show: true, readOnly: false },")
        s.Append("restore: { show: true },")
        s.Append("saveAsImage: { show: true }")
        s.Append("}")
        s.Append("},")
        s.Append("legend:")
        s.Append("{")
        s.Append("data:['YS', 'Length']")
        s.Append("},")
        s.Append("xAxis:")
        s.Append("[")
        s.Append("{")
        s.Append("type: 'category',")
        s.Append("axisTick:")
        s.Append("{")
        s.Append("alignWithLabel: true")
        s.Append("},")
        s.Append("axisLabel:")
        s.Append("{")
        s.Append("show: true,")
        s.Append("rotate: 45")
        s.Append("},")
        s.Append("data:[" & date_val & "]")
        s.Append("}")
        s.Append("],")
        s.Append("yAxis:")
        s.Append("[")
        s.Append("{")
        s.Append("type: 'value',")
        s.Append("name: 'YS',")
        s.Append("min: " & ymin1 & ",")
        s.Append("max: " & ymax1 & ",")
        s.Append("position: 'left',")
        s.Append("splitLine:{show:false},")
        s.Append("axisLine:")
        s.Append("{")
        s.Append("show: true,")
        s.Append("lineStyle:")
        s.Append("{")
        s.Append("color: colors[0]")
        s.Append("}")
        s.Append("},")
        s.Append("axisLabel:")
        s.Append("{")
        s.Append("formatter: '{value} '")
        s.Append("}")
        s.Append("},")
        s.Append("{")
        s.Append("type: 'value',")
        s.Append("name: 'Length',")
        s.Append("min: " & ymin2 & ",")
        s.Append("max: " & ymax2 & ",")
        s.Append("position: 'right',")
        's.Append("offset: 80,")
        s.Append("splitLine:{show:false},")
        s.Append("axisLine:")
        s.Append("{")
        s.Append("show: true,")
        s.Append("lineStyle:")
        s.Append("{")
        s.Append("color: colors[1]")
        s.Append("}")
        s.Append("},")
        s.Append("axisLabel:")
        s.Append("{")
        s.Append("formatter: '{value}'")
        s.Append("}")
        s.Append("},")
        s.Append("],")
        s.Append("series:")
        s.Append("[")
        s.Append("{")
        s.Append("name: 'YS',")
        s.Append("type: 'line',")
        s.Append("data:[")
        s.Append(data)
        s.Append("]")
        s.Append("},")
        s.Append("{")
        s.Append("name: 'Length',")
        s.Append("type: 'line',")
        s.Append("yAxisIndex: 1,")
        s.Append("data:[")
        s.Append(data1)
        s.Append("]")
        s.Append("}")
        s.Append("]")
        s.Append("};")
        s.Append("myChart.setOption(option);")
        s.Append("</script>")
        Literal1.Text = s.ToString()
    End Sub
    Public Function GetChartData1(ByVal dtStart As String, ByVal dtEnd As String) As DataTable
        Using connection As SqlConnection = New SqlConnection(ConnStr)
            'Dim sqlQuery As String = "SELECT READ_TIME, VALUE, LENGTH, [CURRENT_TIME] FROM CRM_SPM_MECH_MODEL"
            Dim sqlQuery As String = "Select Format([COIL_STARTDATETIME],'dd/MMM HH:mm:ss') As COIL_STARTDATETIME, [ENLONGATION_ACT],[ENLONGATION_SET] "
            sqlQuery += "From [FP_PROCESS_DATA].[dbo].[CRM_SPM_PROCESS_DATA_COILWISE_HEAD]"
            'sqlQuery += "Where [COIL_STARTDATETIME] between '2022-02-06 05:08:19' and '2022-02-07 05:08:19'"
            sqlQuery += "Where [COIL_STARTDATETIME] between '" + dtStart + "' and '" + dtEnd + "'"
            'sqlQuery += "order by CRM_SPM_PROCESS_DATA_COILWISE_HEAD.COIL_STARTDATETIME desc"
            sqlQuery += "order by CRM_SPM_PROCESS_DATA_COILWISE_HEAD.COIL_STARTDATETIME asc"
            Dim da As SqlDataAdapter = New SqlDataAdapter(sqlQuery, connection)
            Dim ds As DataSet = New DataSet()
            da.Fill(ds)
            Dim dt As DataTable = New DataTable()
            dt = ds.Tables(0)
            Return dt
        End Using
    End Function
    Public Function GetChartData(ByVal dtStart As String, ByVal dtEnd As String, ByVal ChartColumnXAxis1 As String, ByVal ChartColumnYAxis1 As String,
                                                                        ByVal ChartColumnYAxis2 As String, ByVal ChartTableNameNew As String) As DataTable
        'Using connection As SqlConnection = New SqlConnection(ConnStr)
        '    'Dim sqlQuery As String = "SELECT READ_TIME, VALUE, LENGTH, [CURRENT_TIME] FROM CRM_SPM_MECH_MODEL"
        '    Dim sqlQuery As String = "Select Format([" & ChartColumnXAxis1 & "],'dd/MMM HH:mm:ss') As TIME, [" & ChartColumnYAxis1 & "],[" & ChartColumnYAxis2 & "] "
        '    sqlQuery += "From [" & ChartTableNameNew & "]"
        '    'sqlQuery += "Where [COIL_STARTDATETIME] between '2022-02-06 05:08:19' and '2022-02-07 05:08:19'"
        '    sqlQuery += "Where [" & ChartColumnXAxis1 & "] between '" + dtStart + "' and '" + dtEnd + "' and " & ChartColumnYAxis1 & " > 0 "
        '    'sqlQuery += "order by CRM_SPM_PROCESS_DATA_COILWISE_HEAD.COIL_STARTDATETIME desc"
        '    sqlQuery += "order by " & ChartTableNameNew & ".TIME asc"
        '    Dim da As SqlDataAdapter = New SqlDataAdapter(sqlQuery, connection)
        '    Dim ds As DataSet = New DataSet()
        '    da.Fill(ds)
        '    Dim dt As DataTable = New DataTable()
        '    dt = ds.Tables(0)
        '    Return dt
        'End Using

        Using connection As SqlConnection = New SqlConnection(ConnStr)
            'Dim sqlQuery As String = "SELECT READ_TIME, VALUE, LENGTH, [CURRENT_TIME] FROM CRM_SPM_MECH_MODEL"
            Dim sqlQuery As String = "Select Format([READ_TIME],'dd/MMM HH:mm:ss') As TIME, [Pred_YS],[LENGTH] "
            sqlQuery += "From [CRM_SPM_MECH_MODEL_INPUT]"
            'sqlQuery += "Where [COIL_STARTDATETIME] between '2022-02-06 05:08:19' and '2022-02-07 05:08:19'"
            sqlQuery += " Where [READ_TIME] between '" + dtStart + "' and '" + dtEnd + "' and Pred_YS > 0 "
            'sqlQuery += "order by CRM_SPM_PROCESS_DATA_COILWISE_HEAD.COIL_STARTDATETIME desc"
            sqlQuery += "order by CRM_SPM_MECH_MODEL_INPUT.READ_TIME asc"
            Dim da As SqlDataAdapter = New SqlDataAdapter(sqlQuery, connection)
            Dim ds As DataSet = New DataSet()
            da.Fill(ds)
            Dim dt As DataTable = New DataTable()
            dt = ds.Tables(0)
            Return dt
        End Using
    End Function
    Public Sub GenHistogram(ByVal dt As DataTable)

        Dim data As String = "Length"
        For i As Integer = 0 To dt.Rows.Count - 1
            data &= "\n" & dt.Rows(i)("LENGTH")
        Next

        'js &= "var width = 400, height = 500, padding = 50;" & vbCrLf &
        'js &= "var width = 200, height = 250, padding = 50;" & vbCrLf &
        '".call(d3.axisBottom(x))" & vbCrLf & Line 307

        Dim js = "<script>" & vbCrLf
        js &= "var width = document.getElementById('histoGraph').clientWidth, height = document.getElementById('histoGraph').clientHeight, padding = 50;" & vbCrLf &
         "var data = d3.csvParse('" & data & "')" & vbCrLf &
         "console.log(data)" & vbCrLf &
        "var map = data.map(function(i) { return parseInt(i.Length); })" & vbCrLf &
        "console.log(map)" & vbCrLf &
        "var histogram = d3.histogram()" & vbCrLf &
        ".thresholds(5)" & vbCrLf &
        "(map)" & vbCrLf &
        "console.log(histogram)" & vbCrLf &
        "var bins = d3.histogram(map);" & vbCrLf &
        "var y = d3.scaleLinear()" & vbCrLf &
        ".domain([0, d3.max(histogram.map(function(i) { return i.length; }))])" & vbCrLf &
        ".range([0, height]);" & vbCrLf &
        "var x = d3.scaleLinear()" & vbCrLf &
        ".domain([0, d3.max(map)])" & vbCrLf &
        ".range([0, width]);" & vbCrLf &
        "var xAxis = d3.axisBottom(x);" & vbCrLf &
        "var canvas = d3.select('#histoGraph').append('svg')" & vbCrLf &
        ".attr('width', width - padding)" & vbCrLf &
        ".attr('height', height - padding)" & vbCrLf &
        ".append('g')" & vbCrLf &
        ".attr('transform','translate(20,0)');" & vbCrLf &
        "var Group = canvas.append('g')" & vbCrLf &
        ".attr('transform','translate(0,' + height + ')')" & vbCrLf &
        ".call(xAxis);" & vbCrLf &
        "var bars = canvas.selectAll('.bar')" & vbCrLf &
        ".data(histogram)" & vbCrLf &
        ".enter()" & vbCrLf &
        ".append('g');" & vbCrLf &
        "bars.append('rect')" & vbCrLf &
        ".attr('x', function(d) { return x(d.x0); })" & vbCrLf &
        ".attr('y', function(d) { return 250 - y(d.length); })" & vbCrLf &
        ".attr('width', function(d) { return x(d.x1 - d.x0); })" & vbCrLf &
        ".attr('height', function(d) { return y(d.length); })" & vbCrLf &
        ".on('mouseover', onMouseOver)" & vbCrLf &
        ".on('mouseout', onMouseOut)" & vbCrLf &
        ".attr('fill', 'steelblue');" & vbCrLf &
        "function onMouseOver(d, i)" & vbCrLf &
        "{" & vbCrLf &
        "var xPos = parseFloat(d3.select(this).attr('x'));" & vbCrLf &
        "var yPos = parseFloat(d3.select(this).attr('y')) / 2 + height / 2;" & vbCrLf &
        "    d3.select('#tooltip')" & vbCrLf &
        ".style('left', xPos + 'px')" & vbCrLf &
        ".style('top', yPos + 'px')" & vbCrLf &
        ".select('#value').text(i.length);" & vbCrLf &
        "d3.select('#tooltip').classed('hidden', false);" & vbCrLf &
        "}" & vbCrLf &
        "function onMouseOut(d, i)" & vbCrLf &
        "{" & vbCrLf &
        "d3.select('#tooltip').classed('hidden', true);" & vbCrLf &
        "}" & vbCrLf &
        "bars.append('text')" & vbCrLf &
        ".attr('x', function(d) { return x(d.x0); })" & vbCrLf &
        ".attr('y', function(d) { return 250 - y(d.length); })" & vbCrLf &
        ".attr('dy', function(d) { return y(d.length) / 2; })" & vbCrLf &
        ".attr('dx', function(d) { return x(d.x1 - d.x0) / 2; })" & vbCrLf &
        ".attr('fill', '#fff')" & vbCrLf &
        ".attr('text-anchor','middle')" & vbCrLf &
        ".text(function(d) { return d.length; });" & vbCrLf &
        "canvas.append('g')" & vbCrLf &
        ".attr('transform','translate(' + (0 - 10) + ', ' + (height - 100) + ') ')" & vbCrLf &
        ".append('text')" & vbCrLf &
        ".attr('text-anchor','middle')" & vbCrLf &
        ".attr('transform','rotate(-90)')" & vbCrLf &
        ".text('Y Axis Label');" & vbCrLf &
        "canvas.append('g')" & vbCrLf &
        ".attr('transform', 'translate(200, ' + (height + 50) + ') ')" & vbCrLf &
        ".append('text')" & vbCrLf &
        ".attr('text-anchor','middle')" & vbCrLf &
        ".text('X Axis Label');" & vbCrLf &
        "</script>" & vbCrLf
        '"});" & vbCrLf &
        Literal2.Text = js.ToString()
    End Sub

    Sub PlotHistECharts(ByVal dt As DataTable, ByVal ChartColumnYAxis1 As String)
        Literal2.Text = ""
        Dim data As String = "" '"LastBarA"
        For i = 0 To dt.Rows.Count - 1
            data &= "," & dt.Rows(i)(ChartColumnYAxis1)
        Next

        data = data.Substring(1)
        Literal2.Text = ""
        Dim js = "<script>var bins = ecStat.histogram([" & data & "]);echarts.init(document.getElementById('histoGraph')).setOption({grid:{left:'3%',right:'3%',bottom:'3%',containLabel:!0},xAxis:{scale:!0},yAxis:{},series:[{name:'height',type:'bar',barWidth:'99.3%',label:{normal:{show:0,position:'insideTop'}},data:bins.data}]});</script>"
        Literal2.Text = js
    End Sub
    Public Sub plothistochartLastBarA(ByVal dt As DataTable, ByVal ChartColumnYAxis1 As String)
        Try
            Literal2.Text = ""
            Dim js = "<script>function drawHistLastBarA(){$('#histoGraph').empty(); var  margin = {top: 10, right: 30, bottom: 35, left: 40}, " & vbCrLf &
             " width = document.getElementById('histoGraph').clientWidth - margin.left - margin.right," & vbCrLf &
             "height = document.getElementById('histoGraph').clientHeight - margin.top - margin.bottom " & vbCrLf &
              "svg = d3.select('#histoGraph')" & vbCrLf &
                    ".append('svg') " & vbCrLf &
                      " .attr('width', width + margin.left + margin.right) " & vbCrLf &
                      ".attr('height', height + margin.top + margin.bottom) " & vbCrLf &
                    ".append('g') " & vbCrLf &
                     ".attr('transform', " & vbCrLf &
                   "'translate(' + margin.left + ',' + margin.top + ')');" & vbCrLf

            Dim data As String = "ENLONGATION" '"LastBarA"
            For i = 0 To dt.Rows.Count - 1
                data &= "\n" & dt.Rows(i)(ChartColumnYAxis1)
            Next
            '".value(function (d) { return d.LastBarA; })" & vbCrLf & Line 402

            js &= "var data = d3.csvParse('" & data & "');"
            js &= "var x = d3.scaleLinear() " & vbCrLf &
                ".domain([0, d3.max(data, function(d) { return +d.ENLONGATION })])" & vbCrLf &
                ".range([0, width]);" & vbCrLf &
                 "svg.append('g')" & vbCrLf &
                 ".attr('transform', 'translate(0,' + height + ')')" & vbCrLf &
                 ".call(d3.axisBottom(x));" & vbCrLf &
                 "var histogram = d3.histogram()" & vbCrLf &
                 ".value(function (d) { return d.ENLONGATION; })" & vbCrLf &
                 ".domain(x.domain())" & vbCrLf &
                 ".thresholds(x.ticks(70));" & vbCrLf &
                 " var bins = histogram(data);" & vbCrLf &
                 "var y = d3.scaleLinear()" & vbCrLf &
                 ".range([height, 0]);" & vbCrLf &
                 " y.domain([0, d3.max(bins, function (d) { return d.length; })]);" & vbCrLf &
                 " svg.append('g')" & vbCrLf &
                 ".call(d3.axisLeft(y));" & vbCrLf &
                 "svg.append('text')" & vbCrLf &
                 ".attr('transform', 'rotate(-90)')" & vbCrLf &
                 ".attr('y', 0 - margin.left)" & vbCrLf &
                 ".attr('x', 0 - (height / 2))" & vbCrLf &
                 ".attr('dy', '1em')" & vbCrLf &
                 ".style('text-anchor', 'middle')" & vbCrLf &
                  ".text('No.Of Observation'); " & vbCrLf &
                  "svg.append('text')" & vbCrLf &
                  ".attr('text-anchor', 'middle')" & vbCrLf &
                  ".attr('x', width)" & vbCrLf &
                  ".attr('y', height + margin.top + 20)" & vbCrLf &
                  ".attr('x', width / 2 )" & vbCrLf &
                  ".style('text-anchor', 'middle')" & vbCrLf &
                  ".text('Yield Strength, MPa');" & vbCrLf &
                 "var tooltip = d3.select('#histoGraph')" & vbCrLf &
                 ".append('div')" & vbCrLf &
                 " .style('opacity', 0)" & vbCrLf &
                 ".attr('class', 'tooltip')" & vbCrLf &
                 ".style('background-color', 'black')" & vbCrLf &
                 ".style('color', 'white')" & vbCrLf &
                 ".style('border-radius', '5px')" & vbCrLf &
                 ".style('padding', '10px')" & vbCrLf &
                 "var showTooltip = function (d, i) {" & vbCrLf &
                 "tooltip" & vbCrLf &
                 ".transition()" & vbCrLf &
                  ".duration(100)" & vbCrLf &
                  ".style('opacity', 1)" & vbCrLf &
                  "tooltip" & vbCrLf &
                 ".html('Range: ' + i.x0 + ' - ' + i.x1)" & vbCrLf &
                 ".style('left', (d3.pointer(this)[1] + 20) + 'px')" & vbCrLf &
                  ".style('top', (d3.pointer(this)[1]) + 'px')" & vbCrLf &
                   "}" & vbCrLf &
                 "var moveTooltip = function (d)" & vbCrLf &
                 "{" & vbCrLf &
                 "tooltip" & vbCrLf &
                 ".style('left', (d3.pointer(this)[1] + 20) + 'px')" & vbCrLf &
                 ".style('top', (d3.pointer(this)[1]) + 'px')" & vbCrLf &
                 "}" & vbCrLf &
                 "var hideTooltip = function (d)" & vbCrLf &
                 "{" & vbCrLf &
                 "tooltip" & vbCrLf &
                 ".transition()" & vbCrLf &
                 ".duration(100)" & vbCrLf &
                 ".style('opacity', 0)" & vbCrLf &
                 "}" & vbCrLf &
                 "svg.selectAll('rect')" & vbCrLf &
                 ".data(bins)" & vbCrLf &
                 ".enter()" & vbCrLf &
                 ".append('rect')" & vbCrLf &
                 ".attr('x', 1)" & vbCrLf &
                 ".attr('transform', function (d)" & vbCrLf &
                 "{" & vbCrLf &
                 " return 'translate(' + x(d.x0) + ',' + y(d.length) + ')'; " & vbCrLf &
                 "})" & vbCrLf &
                 ".attr('width', function (d)" & vbCrLf &
                 "{" & vbCrLf &
                  " return x(d.x1) - x(d.x0) - 1;" & vbCrLf &
                 "})" & vbCrLf &
                ".attr('height', function (d)" & vbCrLf &
                "{" & vbCrLf &
                "return height - y(d.length);" & vbCrLf &
                "})" & vbCrLf &
                ".style('fill', '#69b3a2')" & vbCrLf &
                ".on('mouseover', showTooltip)" & vbCrLf &
                ".on('mousemove', moveTooltip)" & vbCrLf &
                ".on('mouseleave', hideTooltip)" & vbCrLf &
               "} drawHistLastBarA();</script>" & vbCrLf

            Literal2.Text = js
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub cmdOk_Click()


        Dim dtStart As String
        Dim dtEnd As String
        If hfFrom.Value = Nothing And hfTo.Value = Nothing Then
            dtStart = DateTime.Now.AddHours(-5).ToString("yyyy-MM-dd HH:mm")
            dtEnd = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Else
            dtStart = hfFrom.Value
            dtEnd = hfTo.Value
        End If
        btnBuildChart_Click(dtStart, dtEnd, ChartColumnYAxis1, ChartColumnYAxis2, ChartColumnXAxis1, ChartTableNameNew)
        'aTimer = New System.Timers.Timer(60000)
        'AddHandler aTimer.Elapsed, AddressOf cmdOk_Click
        'aTimer.AutoReset = True
        'aTimer.Enabled = True
        AutoRebuildChart()
    End Sub

    Protected Sub AutoRebuildChart()

        aTimer = New System.Timers.Timer(60000)
        AddHandler aTimer.Elapsed, AddressOf cmdOk_Click
        aTimer.AutoReset = True
        aTimer.Enabled = True
    End Sub
End Class