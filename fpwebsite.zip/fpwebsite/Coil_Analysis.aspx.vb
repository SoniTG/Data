﻿Imports System.Data
Imports System.IO
Imports iTextSharp.text
Imports iTextSharp.text.html.simpleparser
Imports iTextSharp.text.pdf
Imports iTextSharp.tool.xml
Imports System.Net
Imports System.Drawing
Imports System.Data.OleDb
Imports OfficeOpenXml

Partial Class Coil_Analysis
    Inherits System.Web.UI.Page
    Dim objController As New Controller_CoilDeviation
    Private _getBase64String As Object

    Private Property GetBase64String(url As String) As Object
        Get
            Return _getBase64String
        End Get
        Set(value As Object)
            _getBase64String = value
        End Set
    End Property



    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then

            Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))

        End If
    End Sub
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Dim maindt As New DataTable

    Protected Sub btnGo_Click(sender As Object, e As System.EventArgs) Handles btnGo.Click
        '    txtWithHint.Attributes.Add("placeholder", "hint");
        'txtSearch.Text = "Search Using Coil id"
        txtSearch.Attributes.Add("placeholder", "Search Using Coil id")
        'Dim tb As New TextBox
        'txtSearch.Controls.Add(tb)
        'tb.ID = "dynTextBox1"
        Dim stDate As String = hfFrom.Value
        Dim enDate As String = hfTo.Value
        Dim ds As DataSet = objController.GetCOILData(stDate, enDate)
        Dim dt As DataTable = ds.Tables(0)
        ' dt.DefaultView.Sort = " START_TIME"
        'dt = dt.DefaultView.ToTable
        'dt.DefaultView.Sort = "START_TIME desc"
        Dim ds1 As DataSet = objController.GetCOIL_Defect(stDate, enDate)
        Dim dt1 As DataTable = ds1.Tables(0)

        maindt.Columns.Add("COIL_ID")
        maindt.Columns.Add("START_TIME")
        maindt.Columns.Add("COIL_THICKNESS")
        maindt.Columns.Add("MILL_ENTRY_TEMP")
        ' maindt.Columns.Add("SPEED_BEFORE_F1")
        maindt.Columns.Add("ENTRY_DS_PRESSURE")
        maindt.Columns.Add("EXIT_DS_PRESSURE")
        maindt.Columns.Add("FRT")
        maindt.Columns.Add("F1_ROLL_GAP")
        maindt.Columns.Add("F2_ROLL_GAP")
        maindt.Columns.Add("F3_ROLL_GAP")
        maindt.Columns.Add("F4_ROLL_GAP")
        maindt.Columns.Add("F5_ROLL_GAP")
        maindt.Columns.Add("F6_ROLL_GAP")
        maindt.Columns.Add("QLTY_CODE")
        maindt.Columns.Add("ROLL_FORCE_F1")
        maindt.Columns.Add("ROLL_FORCE_F2")
        maindt.Columns.Add("ROLL_FORCE_F3")
        maindt.Columns.Add("ROLL_FORCE_F4")
        maindt.Columns.Add("ROLL_FORCE_F5")
        maindt.Columns.Add("ROLL_FORCE_F6")
        maindt.Columns.Add("F1_INSTND_COOL")
        maindt.Columns.Add("F2_INSTND_COOL")
        maindt.Columns.Add("F3_INSTND_COOL")
        maindt.Columns.Add("RGL_F2_TOP_OIL_WATER")
        maindt.Columns.Add("RGL_F2_BOT_OIL_WATER")
        maindt.Columns.Add("RGL_F3_TOP_OIL_WATER")
        maindt.Columns.Add("RGL_F3_BOT_OIL_WATER")
        maindt.Columns.Add("RGL_F4_TOP_OIL_WATER")
        maindt.Columns.Add("RGL_F4_BOT_OIL_WATER")
        maindt.Columns.Add("DEFECT_TYPE")

       Dim coil_id As String = ""

        If dt1.Rows.Count > 0 Then
            For i As Short = 0 To dt1.Rows.Count - 1
                coil_id = dt1.Rows.Item(i)("coil_id")
                For j = 0 To dt.Rows.Count - 1
                    If dt.Rows.Item(j)("coil_id") = coil_id Then


                        Dim row As DataRow = maindt.NewRow


                        If IsDBNull(dt.Rows.Item(j)("COIL_ID")) Then
                            row("COIL_ID") = 0
                        Else
                            row("COIL_ID") = dt.Rows.Item(j)("COIL_ID")
                        End If
                        If IsDBNull(dt.Rows.Item(j)("START_TIME")) Then
                            row("START_TIME") = 0
                        Else
                            row("START_TIME") = dt.Rows.Item(j)("START_TIME")
                        End If

                        If IsDBNull(dt.Rows.Item(j)("COIL_THICKNESS")) Then
                            row("COIL_THICKNESS") = 0
                        Else
                            row("COIL_THICKNESS") = dt.Rows.Item(j)("COIL_THICKNESS")
                        End If
                        If IsDBNull(dt.Rows.Item(j)("MILL_ENTRY_TEMP")) Then
                            row("MILL_ENTRY_TEMP") = 0
                        Else
                            row("MILL_ENTRY_TEMP") = dt.Rows.Item(j)("MILL_ENTRY_TEMP")
                        End If

                        '  row("SPEED_BEFORE_F1") = speedBefore
                        If IsDBNull(dt.Rows.Item(j)("ENTRY_DS_PRESSURE")) Then
                            row("ENTRY_DS_PRESSURE") = 0
                        Else
                            row("ENTRY_DS_PRESSURE") = dt.Rows.Item(j)("ENTRY_DS_PRESSURE")
                        End If

                        If IsDBNull(dt.Rows.Item(j)("EXIT_DS_PRESSURE")) Then
                            row("EXIT_DS_PRESSURE") = 0
                        Else
                            row("EXIT_DS_PRESSURE") = dt.Rows.Item(j)("EXIT_DS_PRESSURE")
                        End If

                        ' row("FRT") = FRT

                        If IsDBNull(dt.Rows.Item(j)("FRT")) Then
                            row("FRT") = 0
                        Else
                            row("FRT") = dt.Rows.Item(j)("FRT")
                        End If
                        '=======================================================================================

                        If IsDBNull(dt.Rows.Item(j)("F1_ROLL_GAP")) Then
                            row("F1_ROLL_GAP") = 0
                        Else
                            row("F1_ROLL_GAP") = dt.Rows.Item(j)("F1_ROLL_GAP")
                        End If


                        If IsDBNull(dt.Rows.Item(j)("F2_ROLL_GAP")) Then
                            row("F2_ROLL_GAP") = 0
                        Else
                            row("F2_ROLL_GAP") = dt.Rows.Item(j)("F2_ROLL_GAP")
                        End If


                        If IsDBNull(dt.Rows.Item(j)("F3_ROLL_GAP")) Then
                            row("F3_ROLL_GAP") = 0
                        Else
                            row("F3_ROLL_GAP") = dt.Rows.Item(j)("F3_ROLL_GAP")
                        End If

                        If IsDBNull(dt.Rows.Item(j)("F4_ROLL_GAP")) Then
                            row("F4_ROLL_GAP") = 0
                        Else
                            row("F4_ROLL_GAP") = dt.Rows.Item(j)("F4_ROLL_GAP")
                        End If

                        If IsDBNull(dt.Rows.Item(j)("F5_ROLL_GAP")) Then
                            row("F5_ROLL_GAP") = 0
                        Else
                            row("F5_ROLL_GAP") = dt.Rows.Item(j)("F5_ROLL_GAP")
                        End If


                        If IsDBNull(dt.Rows.Item(j)("F6_ROLL_GAP")) Then
                            row("F6_ROLL_GAP") = 0
                        Else
                            row("F6_ROLL_GAP") = dt.Rows.Item(j)("F6_ROLL_GAP")
                        End If
                        '--------------------------------------------------------------------------------------------------------------
                        If IsDBNull(dt.Rows.Item(j)("QLTY_CODE")) Then
                            row("QLTY_CODE") = 0
                        Else
                            row("QLTY_CODE") = dt.Rows.Item(j)("QLTY_CODE")
                        End If
                        '================================================================================================================
                        If IsDBNull(dt.Rows.Item(j)("ROLL_FORCE_F1")) Then
                            row("ROLL_FORCE_F1") = 0
                        Else
                            row("ROLL_FORCE_F1") = dt.Rows.Item(j)("ROLL_FORCE_F1")
                        End If
                        If IsDBNull(dt.Rows.Item(j)("ROLL_FORCE_F2")) Then
                            row("ROLL_FORCE_F2") = 0
                        Else
                            row("ROLL_FORCE_F2") = dt.Rows.Item(j)("ROLL_FORCE_F2")
                        End If
                        If IsDBNull(dt.Rows.Item(j)("ROLL_FORCE_F3")) Then
                            row("ROLL_FORCE_F3") = 0
                        Else
                            row("ROLL_FORCE_F3") = dt.Rows.Item(j)("ROLL_FORCE_F3")
                        End If
                        If IsDBNull(dt.Rows.Item(j)("ROLL_FORCE_F4")) Then
                            row("ROLL_FORCE_F4") = 0
                        Else
                            row("ROLL_FORCE_F4") = dt.Rows.Item(j)("ROLL_FORCE_F4")
                        End If
                        If IsDBNull(dt.Rows.Item(j)("ROLL_FORCE_F5")) Then
                            row("ROLL_FORCE_F5") = 0
                        Else
                            row("ROLL_FORCE_F5") = dt.Rows.Item(j)("ROLL_FORCE_F5")
                        End If
                        If IsDBNull(dt.Rows.Item(j)("ROLL_FORCE_F6")) Then
                            row("ROLL_FORCE_F6") = 0
                        Else
                            row("ROLL_FORCE_F6") = dt.Rows.Item(j)("ROLL_FORCE_F6")
                        End If
                        '=================
                        If IsDBNull(dt.Rows.Item(j)("F1_INSTND_COOL")) Then
                            row("F1_INSTND_COOL") = 0
                        Else
                            row("F1_INSTND_COOL") = dt.Rows.Item(j)("F1_INSTND_COOL")
                        End If

                        If IsDBNull(dt.Rows.Item(j)("F2_INSTND_COOL")) Then
                            row("F2_INSTND_COOL") = 0
                        Else
                            row("F2_INSTND_COOL") = dt.Rows.Item(j)("F2_INSTND_COOL")
                        End If

                        If IsDBNull(dt.Rows.Item(j)("F3_INSTND_COOL")) Then
                            row("F3_INSTND_COOL") = 0
                        Else
                            row("F3_INSTND_COOL") = dt.Rows.Item(j)("F3_INSTND_COOL")
                        End If
                        '===============================================
                        If IsDBNull(dt.Rows.Item(j)("RGL_F2_TOP_OIL_WATER")) Then
                            row("RGL_F2_TOP_OIL_WATER") = 0
                        Else
                            row("RGL_F2_TOP_OIL_WATER") = dt.Rows.Item(j)("RGL_F2_TOP_OIL_WATER")
                        End If
                        If IsDBNull(dt.Rows.Item(j)("RGL_F2_BOT_OIL_WATER")) Then
                            row("RGL_F2_BOT_OIL_WATER") = 0
                        Else
                            row("RGL_F2_BOT_OIL_WATER") = dt.Rows.Item(j)("RGL_F2_BOT_OIL_WATER")
                        End If
                        If IsDBNull(dt.Rows.Item(j)("RGL_F3_TOP_OIL_WATER")) Then
                            row("RGL_F3_TOP_OIL_WATER") = 0
                        Else
                            row("RGL_F3_TOP_OIL_WATER") = dt.Rows.Item(j)("RGL_F3_TOP_OIL_WATER")
                        End If
                        If IsDBNull(dt.Rows.Item(j)("RGL_F3_BOT_OIL_WATER")) Then
                            row("RGL_F3_BOT_OIL_WATER") = 0
                        Else
                            row("RGL_F3_BOT_OIL_WATER") = dt.Rows.Item(j)("RGL_F3_BOT_OIL_WATER")
                        End If


                        If IsDBNull(dt.Rows.Item(j)("RGL_F4_TOP_OIL_WATER")) Then
                            row("RGL_F4_TOP_OIL_WATER") = 0
                        Else
                            row("RGL_F4_TOP_OIL_WATER") = dt.Rows.Item(j)("RGL_F4_TOP_OIL_WATER")
                        End If

                        If IsDBNull(dt.Rows.Item(j)("RGL_F4_BOT_OIL_WATER")) Then
                            row("RGL_F4_BOT_OIL_WATER") = 0
                        Else
                            row("RGL_F4_BOT_OIL_WATER") = dt.Rows.Item(j)("RGL_F4_BOT_OIL_WATER")
                        End If
                        If IsDBNull(dt1.Rows.Item(i)("Defect_type_meaning")) Then
                            row("defect_type") = 0
                        Else
                            row("defect_type") = dt1.Rows.Item(i)("Defect_type_meaning")
                        End If
                        '===========================================
                        maindt.Rows.Add(row)
                    End If
                Next
            Next
        End If

        Dim SheetName As String = ""
        Dim filepath As String = AppDomain.CurrentDomain.BaseDirectory & "FRT_Spec.xlsx"
        'ViewState("exfname") = exfname
        'ViewState("filename") = FileUpload1.FileName
        Dim package As New ExcelPackage(New FileInfo(filepath))
        Dim workbook As ExcelWorkbook = package.Workbook
        Dim sheet As ExcelWorksheet = workbook.Worksheets(1)

        Dim dtExcel As New DataTable
        Dim c As Integer = 1
        Dim x As Short = 1

        While Not sheet.Cells(1, c).Value Is Nothing
            Dim colName As String = ""

            dtExcel.Columns.Add(sheet.Cells(1, c).Value)
            c = c + 1

        End While

        'dtExcel.Rows.Add()
        Dim rRR As Integer = 2
        While Not sheet.Cells(rRR, 1).Value Is Nothing
            dtExcel.Rows.Add()
            For i As Integer = 1 To c - 1
                Dim value As String = ""
                Try
                    value = sheet.Cells(rRR, i).Text
                    'value = sheet.Cells(r, i).Value
                Catch ex As Exception
                End Try
                dtExcel.Rows(rRR - 2)(i - 1) = value
            Next
            rRR = rRR + 1
        End While
        Dim dtmainfinal As New DataTable
        Dim Qlty As String = ""
        'Dim Qltymaindt As String = ""
        Dim maincount As Integer = 0
        dtmainfinal.Columns.Add("COIL_ID")
        dtmainfinal.Columns.Add("START_TIME")
        dtmainfinal.Columns.Add("COIL_THICKNESS")
        dtmainfinal.Columns.Add("MILL_ENTRY_TEMP")
        ' maindt.Columns.Add("SPEED_BEFORE_F1")
        dtmainfinal.Columns.Add("ENTRY_DS_PRESSURE")
        dtmainfinal.Columns.Add("EXIT_DS_PRESSURE")
        dtmainfinal.Columns.Add("FRT")
        dtmainfinal.Columns.Add("F1_ROLL_GAP")
        dtmainfinal.Columns.Add("F2_ROLL_GAP")
        dtmainfinal.Columns.Add("F3_ROLL_GAP")
        dtmainfinal.Columns.Add("F4_ROLL_GAP")
        dtmainfinal.Columns.Add("F5_ROLL_GAP")
        dtmainfinal.Columns.Add("F6_ROLL_GAP")
        dtmainfinal.Columns.Add("QLTY_CODE")
        dtmainfinal.Columns.Add("frtcheck")
        dtmainfinal.Columns.Add("ROLL_FORCE_F1")
        dtmainfinal.Columns.Add("ROLL_FORCE_F2")
        dtmainfinal.Columns.Add("ROLL_FORCE_F3")
        dtmainfinal.Columns.Add("ROLL_FORCE_F4")
        dtmainfinal.Columns.Add("ROLL_FORCE_F5")
        dtmainfinal.Columns.Add("ROLL_FORCE_F6")
        dtmainfinal.Columns.Add("F1_INSTND_COOL")
        dtmainfinal.Columns.Add("F2_INSTND_COOL")
        dtmainfinal.Columns.Add("F3_INSTND_COOL")
        dtmainfinal.Columns.Add("RGL_F2_TOP_OIL_WATER")
        dtmainfinal.Columns.Add("RGL_F2_BOT_OIL_WATER")
        dtmainfinal.Columns.Add("RGL_F3_TOP_OIL_WATER")
        dtmainfinal.Columns.Add("RGL_F3_BOT_OIL_WATER")
        dtmainfinal.Columns.Add("RGL_F4_TOP_OIL_WATER")
        dtmainfinal.Columns.Add("RGL_F4_BOT_OIL_WATER")
        dtmainfinal.Columns.Add("DEFECT_TYPE")
        If dtExcel.Rows.Count > 0 Then
            For i As Short = 0 To dtExcel.Rows.Count - 1
                Qlty = dtExcel.Rows.Item(i)("Q.CODE")
                'Qltymaindt = maindt.Rows.Item(i)("QLTY_CODE")
                ' If dtExcel.Rows.Item(i)("THK-MIN") = "1.6" Then
                For count1 As Short = 0 To maindt.Rows.Count - 1
                    If maindt.Rows.Item(count1)("QLTY_CODE") = Qlty Then ' Or maindt.Rows.Item(count1)("QLTY_CODE") = Qltymaindt Then
                        If Math.Abs(dtExcel.Rows.Item(i)("FRT") - maindt.Rows.Item(count1)("FRT")) <= 25 Then
                            'dtmainfinal.Rows.Add = maindt.Rows

                            Dim newRow As DataRow = dtmainfinal.NewRow()
                            newRow("COIL_ID") = maindt.Rows(count1)("COIL_ID").ToString
                            newRow("START_TIME") = maindt.Rows(count1)("START_TIME").ToString
                            newRow("COIL_THICKNESS") = maindt.Rows(count1)("COIL_THICKNESS").ToString
                            newRow("MILL_ENTRY_TEMP") = maindt.Rows(count1)("MILL_ENTRY_TEMP").ToString
                            newRow("ENTRY_DS_PRESSURE") = maindt.Rows(count1)("ENTRY_DS_PRESSURE").ToString
                            newRow("EXIT_DS_PRESSURE") = maindt.Rows(count1)("EXIT_DS_PRESSURE").ToString
                            newRow("FRT") = maindt.Rows(count1)("FRT").ToString
                            newRow("F1_ROLL_GAP") = maindt.Rows(count1)("F1_ROLL_GAP").ToString
                            newRow("F2_ROLL_GAP") = maindt.Rows(count1)("F2_ROLL_GAP").ToString
                            newRow("F3_ROLL_GAP") = maindt.Rows(count1)("F3_ROLL_GAP").ToString
                            newRow("F4_ROLL_GAP") = maindt.Rows(count1)("F4_ROLL_GAP").ToString
                            newRow("F5_ROLL_GAP") = maindt.Rows(count1)("F5_ROLL_GAP").ToString
                            newRow("F6_ROLL_GAP") = maindt.Rows(count1)("F6_ROLL_GAP").ToString
                            newRow("QLTY_CODE") = maindt.Rows(count1)("QLTY_CODE").ToString
                            newRow("frtcheck") = "0"
                            newRow("ROLL_FORCE_F1") = maindt.Rows(count1)("ROLL_FORCE_F1").ToString
                            newRow("ROLL_FORCE_F2") = maindt.Rows(count1)("ROLL_FORCE_F2").ToString
                            newRow("ROLL_FORCE_F3") = maindt.Rows(count1)("ROLL_FORCE_F3").ToString
                            newRow("ROLL_FORCE_F4") = maindt.Rows(count1)("ROLL_FORCE_F4").ToString
                            newRow("ROLL_FORCE_F5") = maindt.Rows(count1)("ROLL_FORCE_F5").ToString
                            newRow("ROLL_FORCE_F6") = maindt.Rows(count1)("ROLL_FORCE_F6").ToString
                            newRow("F1_INSTND_COOL") = maindt.Rows(count1)("F1_INSTND_COOL").ToString
                            newRow("F2_INSTND_COOL") = maindt.Rows(count1)("F2_INSTND_COOL").ToString
                            newRow("F3_INSTND_COOL") = maindt.Rows(count1)("F3_INSTND_COOL").ToString
                            newRow("RGL_F2_TOP_OIL_WATER") = maindt.Rows(count1)("RGL_F2_TOP_OIL_WATER").ToString
                            newRow("RGL_F2_BOT_OIL_WATER") = maindt.Rows(count1)("RGL_F2_BOT_OIL_WATER").ToString
                            newRow("RGL_F3_TOP_OIL_WATER") = maindt.Rows(count1)("RGL_F3_TOP_OIL_WATER").ToString
                            newRow("RGL_F3_BOT_OIL_WATER") = maindt.Rows(count1)("RGL_F3_BOT_OIL_WATER").ToString
                            newRow("RGL_F4_TOP_OIL_WATER") = maindt.Rows(count1)("RGL_F4_TOP_OIL_WATER").ToString
                            newRow("RGL_F4_BOT_OIL_WATER") = maindt.Rows(count1)("RGL_F4_BOT_OIL_WATER").ToString
                            newRow("DEFECT_TYPE") = maindt.Rows(count1)("DEFECT_TYPE").ToString
                            dtmainfinal.Rows.Add(newRow)
                            'maincount = maincount + 1
                            ' dtmainfinal.DefaultView.Sort = "START_TIME desc"
                            'frt1 = 0  'green  frt1 = 1

                        Else
                            'frt1 = 1 'red 

                            Dim newRow As DataRow = dtmainfinal.NewRow()
                            newRow("COIL_ID") = maindt.Rows(count1)("COIL_ID").ToString
                            newRow("START_TIME") = maindt.Rows(count1)("START_TIME").ToString
                            newRow("COIL_THICKNESS") = maindt.Rows(count1)("COIL_THICKNESS").ToString
                            newRow("MILL_ENTRY_TEMP") = maindt.Rows(count1)("MILL_ENTRY_TEMP").ToString
                            newRow("ENTRY_DS_PRESSURE") = maindt.Rows(count1)("ENTRY_DS_PRESSURE").ToString
                            newRow("EXIT_DS_PRESSURE") = maindt.Rows(count1)("EXIT_DS_PRESSURE").ToString
                            newRow("FRT") = maindt.Rows(count1)("FRT").ToString
                            newRow("F1_ROLL_GAP") = maindt.Rows(count1)("F1_ROLL_GAP").ToString
                            newRow("F2_ROLL_GAP") = maindt.Rows(count1)("F2_ROLL_GAP").ToString
                            newRow("F3_ROLL_GAP") = maindt.Rows(count1)("F3_ROLL_GAP").ToString
                            newRow("F4_ROLL_GAP") = maindt.Rows(count1)("F4_ROLL_GAP").ToString
                            newRow("F5_ROLL_GAP") = maindt.Rows(count1)("F5_ROLL_GAP").ToString
                            newRow("F6_ROLL_GAP") = maindt.Rows(count1)("F6_ROLL_GAP").ToString
                            newRow("QLTY_CODE") = maindt.Rows(count1)("QLTY_CODE").ToString
                            newRow("frtcheck") = "1"
                            newRow("ROLL_FORCE_F1") = maindt.Rows(count1)("ROLL_FORCE_F1").ToString
                            newRow("ROLL_FORCE_F2") = maindt.Rows(count1)("ROLL_FORCE_F2").ToString
                            newRow("ROLL_FORCE_F3") = maindt.Rows(count1)("ROLL_FORCE_F3").ToString
                            newRow("ROLL_FORCE_F4") = maindt.Rows(count1)("ROLL_FORCE_F4").ToString
                            newRow("ROLL_FORCE_F5") = maindt.Rows(count1)("ROLL_FORCE_F5").ToString
                            newRow("ROLL_FORCE_F6") = maindt.Rows(count1)("ROLL_FORCE_F6").ToString
                            newRow("F1_INSTND_COOL") = maindt.Rows(count1)("F1_INSTND_COOL").ToString
                            newRow("F2_INSTND_COOL") = maindt.Rows(count1)("F2_INSTND_COOL").ToString
                            newRow("F3_INSTND_COOL") = maindt.Rows(count1)("F3_INSTND_COOL").ToString
                            newRow("RGL_F2_TOP_OIL_WATER") = maindt.Rows(count1)("RGL_F2_TOP_OIL_WATER").ToString
                            newRow("RGL_F2_BOT_OIL_WATER") = maindt.Rows(count1)("RGL_F2_BOT_OIL_WATER").ToString
                            newRow("RGL_F3_TOP_OIL_WATER") = maindt.Rows(count1)("RGL_F3_TOP_OIL_WATER").ToString
                            newRow("RGL_F3_BOT_OIL_WATER") = maindt.Rows(count1)("RGL_F3_BOT_OIL_WATER").ToString
                            newRow("RGL_F4_TOP_OIL_WATER") = maindt.Rows(count1)("RGL_F4_TOP_OIL_WATER").ToString
                            newRow("RGL_F4_BOT_OIL_WATER") = maindt.Rows(count1)("RGL_F4_BOT_OIL_WATER").ToString
                            newRow("DEFECT_TYPE") = maindt.Rows(count1)("DEFECT_TYPE").ToString
                            dtmainfinal.Rows.Add(newRow)
                            ' maincount = maincount + 1
                            'dtmainfinal.DefaultView.Sort = "START_TIME desc"
                        End If

                    End If

                Next
                'Else


                'End If

            Next
            For Val As Integer = 0 To maindt.Rows.Count - 1
                If maindt.Rows.Item(Val)("QLTY_CODE") = "0" Then

                    Dim newRow As DataRow = dtmainfinal.NewRow()
                    newRow("COIL_ID") = maindt.Rows(Val)("COIL_ID").ToString
                    newRow("START_TIME") = maindt.Rows(Val)("START_TIME").ToString
                    newRow("COIL_THICKNESS") = maindt.Rows(Val)("COIL_THICKNESS").ToString
                    newRow("MILL_ENTRY_TEMP") = maindt.Rows(Val)("MILL_ENTRY_TEMP").ToString
                    newRow("ENTRY_DS_PRESSURE") = maindt.Rows(Val)("ENTRY_DS_PRESSURE").ToString
                    newRow("EXIT_DS_PRESSURE") = maindt.Rows(Val)("EXIT_DS_PRESSURE").ToString
                    newRow("FRT") = maindt.Rows(Val)("FRT").ToString
                    newRow("F1_ROLL_GAP") = maindt.Rows(Val)("F1_ROLL_GAP").ToString
                    newRow("F2_ROLL_GAP") = maindt.Rows(Val)("F2_ROLL_GAP").ToString
                    newRow("F3_ROLL_GAP") = maindt.Rows(Val)("F3_ROLL_GAP").ToString
                    newRow("F4_ROLL_GAP") = maindt.Rows(Val)("F4_ROLL_GAP").ToString
                    newRow("F5_ROLL_GAP") = maindt.Rows(Val)("F5_ROLL_GAP").ToString
                    newRow("F6_ROLL_GAP") = maindt.Rows(Val)("F6_ROLL_GAP").ToString
                    newRow("QLTY_CODE") = maindt.Rows(Val)("QLTY_CODE").ToString
                    newRow("frtcheck") = ""
                    newRow("ROLL_FORCE_F1") = maindt.Rows(Val)("ROLL_FORCE_F1").ToString
                    newRow("ROLL_FORCE_F2") = maindt.Rows(Val)("ROLL_FORCE_F2").ToString
                    newRow("ROLL_FORCE_F3") = maindt.Rows(Val)("ROLL_FORCE_F3").ToString
                    newRow("ROLL_FORCE_F4") = maindt.Rows(Val)("ROLL_FORCE_F4").ToString
                    newRow("ROLL_FORCE_F5") = maindt.Rows(Val)("ROLL_FORCE_F5").ToString
                    newRow("ROLL_FORCE_F6") = maindt.Rows(Val)("ROLL_FORCE_F6").ToString
                    newRow("F1_INSTND_COOL") = maindt.Rows(Val)("F1_INSTND_COOL").ToString
                    newRow("F2_INSTND_COOL") = maindt.Rows(Val)("F2_INSTND_COOL").ToString
                    newRow("F3_INSTND_COOL") = maindt.Rows(Val)("F3_INSTND_COOL").ToString
                    newRow("RGL_F2_TOP_OIL_WATER") = maindt.Rows(Val)("RGL_F2_TOP_OIL_WATER").ToString
                    newRow("RGL_F2_BOT_OIL_WATER") = maindt.Rows(Val)("RGL_F2_BOT_OIL_WATER").ToString
                    newRow("RGL_F3_TOP_OIL_WATER") = maindt.Rows(Val)("RGL_F3_TOP_OIL_WATER").ToString
                    newRow("RGL_F3_BOT_OIL_WATER") = maindt.Rows(Val)("RGL_F3_BOT_OIL_WATER").ToString
                    newRow("RGL_F4_TOP_OIL_WATER") = maindt.Rows(Val)("RGL_F4_TOP_OIL_WATER").ToString
                    newRow("RGL_F4_BOT_OIL_WATER") = maindt.Rows(Val)("RGL_F4_BOT_OIL_WATER").ToString
                    newRow("DEFECT_TYPE") = maindt.Rows(Val)("DEFECT_TYPE").ToString
                    dtmainfinal.Rows.Add(newRow)
                End If

            Next
        End If
        dtmainfinal.DefaultView.Sort = "START_TIME desc"


        For k = 0 To dtmainfinal.Rows.Count - 1
            If dtmainfinal.Rows.Item(k)("frtcheck") = "" Then
                dtmainfinal(k)("frtcheck") = "2"
            End If
            ' dtmainfinal.DefaultView.Sort = "START_TIME desc"
        Next


        Dim sum As Double = 0.0
        For column As Integer = 7 To dtmainfinal.Columns.Count - 1
            For splitcol As Integer = 0 To dtmainfinal.Rows.Count - 1
                '  Dim f1val As String
                '   f1val = dtmainfinal.Rows()("F1_ROLL_GAP")
                Dim f1val As String = dtmainfinal.Rows.Item(splitcol)(column).ToString
                Dim f1split() As String = f1val.Split(",")
                If f1split.Length > 1 Then
                    sum = (CDbl(f1split(0).ToString()) + CDbl(f1split(1).ToString())) / 2
                    dtmainfinal.Rows(splitcol)(column) = sum
                Else
                    'dtmainfinal.Rows(splitcol)(column) = sum
                    Continue For
                End If

                'Dim a(f1val.Length) As String

                'For i As Integer = 0 To f1val.Length - 1
                '    a(i) = f1val.Substring(i, 1)
                'Next i
            Next
            Continue For
        Next

        dtmainfinal.DefaultView.Sort = "START_TIME desc"


        Dim dtchart As New DataTable
        dtchart.Columns.Add("COIL_ID")
        dtchart.Columns.Add("START_TIME")
        dtchart.Columns.Add("COIL_THICKNESS")
        dtchart.Columns.Add("MILL_ENTRY_TEMP")
        dtchart.Columns.Add("ENTRY_DS_PRESSURE")
        dtchart.Columns.Add("EXIT_DS_PRESSURE")
        dtchart.Columns.Add("FRT")
        dtchart.Columns.Add("ROLL_FORCE_F1")
        dtchart.Columns.Add("ROLL_FORCE_F2")
        dtchart.Columns.Add("ROLL_FORCE_F3")
        dtchart.Columns.Add("ROLL_FORCE_F4")
        dtchart.Columns.Add("ROLL_FORCE_F5")
        dtchart.Columns.Add("ROLL_FORCE_F6")
        dtchart.Columns.Add("QLTY_CODE")

        For chart = 0 To dtmainfinal.Rows.Count - 1

            If IsDBNull(dtmainfinal.Rows.Item(chart)("MILL_ENTRY_TEMP")) Then
                dtmainfinal(chart)("MILL_ENTRY_TEMP") = 0
            Else
                dtmainfinal(chart)("MILL_ENTRY_TEMP") = dtmainfinal.Rows.Item(chart)("MILL_ENTRY_TEMP")
            End If
            If IsDBNull(dtmainfinal.Rows.Item(chart)("ENTRY_DS_PRESSURE")) Then
                dtmainfinal(chart)("ENTRY_DS_PRESSURE") = 0
            Else
                dtmainfinal(chart)("ENTRY_DS_PRESSURE") = dtmainfinal.Rows.Item(chart)("ENTRY_DS_PRESSURE")
            End If
            If IsDBNull(dtmainfinal.Rows.Item(chart)("EXIT_DS_PRESSURE")) Then
                dtmainfinal(chart)("EXIT_DS_PRESSURE") = 0
            Else
                dtmainfinal(chart)("EXIT_DS_PRESSURE") = dtmainfinal.Rows.Item(chart)("EXIT_DS_PRESSURE")
            End If
            If IsDBNull(dtmainfinal.Rows.Item(chart)("FRT")) Then
                dtmainfinal(chart)("FRT") = 0
            Else
                dtmainfinal(chart)("FRT") = dtmainfinal.Rows.Item(chart)("FRT")
            End If
            If IsDBNull(dtmainfinal.Rows.Item(chart)("ROLL_FORCE_F1")) Then
                dtmainfinal(chart)("ROLL_FORCE_F1") = 0
            Else
                dtmainfinal(chart)("ROLL_FORCE_F1") = dtmainfinal.Rows.Item(chart)("ROLL_FORCE_F1")
            End If
            If IsDBNull(dtmainfinal.Rows.Item(chart)("ROLL_FORCE_F2")) Then
                dtmainfinal(chart)("ROLL_FORCE_F2") = 0
            Else
                dtmainfinal(chart)("ROLL_FORCE_F2") = dtmainfinal.Rows.Item(chart)("ROLL_FORCE_F2")
            End If

            If IsDBNull(dtmainfinal.Rows.Item(chart)("ROLL_FORCE_F3")) Then
                dtmainfinal(chart)("ROLL_FORCE_F3") = 0
            Else
                dtmainfinal(chart)("ROLL_FORCE_F3") = dtmainfinal.Rows.Item(chart)("ROLL_FORCE_F3")
            End If
            If IsDBNull(dtmainfinal.Rows.Item(chart)("ROLL_FORCE_F4")) Then
                dtmainfinal(chart)("ROLL_FORCE_F4") = 0
            Else
                dtmainfinal(chart)("ROLL_FORCE_F4") = dtmainfinal.Rows.Item(chart)("ROLL_FORCE_F4")
            End If
            If IsDBNull(dtmainfinal.Rows.Item(chart)("ROLL_FORCE_F5")) Then
                dtmainfinal(chart)("ROLL_FORCE_F5") = 0
            Else
                dtmainfinal(chart)("ROLL_FORCE_F5") = dtmainfinal.Rows.Item(chart)("ROLL_FORCE_F5")
            End If
            If IsDBNull(dtmainfinal.Rows.Item(chart)("ROLL_FORCE_F6")) Then
                dtmainfinal(chart)("ROLL_FORCE_F6") = 0
            Else
                dtmainfinal(chart)("ROLL_FORCE_F6") = dtmainfinal.Rows.Item(chart)("ROLL_FORCE_F6")
            End If
            If IsDBNull(dtmainfinal.Rows.Item(chart)("QLTY_CODE")) Then
                dtmainfinal(chart)("QLTY_CODE") = 0
            Else
                dtmainfinal(chart)("QLTY_CODE") = dtmainfinal.Rows.Item(chart)("QLTY_CODE")
            End If






            dtchart.Rows.Add()
            dtchart(chart)("COIL_ID") = dtmainfinal(chart)(0)
            dtchart(chart)("START_TIME") = dtmainfinal(chart)(1)
            dtchart(chart)("COIL_THICKNESS") = dtmainfinal(chart)(2)

            If dtmainfinal(chart)("COIL_THICKNESS") = 1.6 And Not IsDBNull(dtmainfinal(chart)("MILL_ENTRY_TEMP")) Then
                If dtmainfinal(chart)("MILL_ENTRY_TEMP") < 1030 Or dtmainfinal(chart)("MILL_ENTRY_TEMP") > 1070 Then
                    dtchart(chart)("MILL_ENTRY_TEMP") = 1
                Else
                    dtchart(chart)("MILL_ENTRY_TEMP") = 0
                End If
            Else
                dtchart(chart)("MILL_ENTRY_TEMP") = 0
            End If


            If dtmainfinal(chart)("COIL_THICKNESS") = 1.6 And Not IsDBNull(dtmainfinal(chart)("ENTRY_DS_PRESSURE")) Then
                If dtmainfinal(chart)("ENTRY_DS_PRESSURE") < 187 Then
                    dtchart(chart)("ENTRY_DS_PRESSURE") = 1

                Else
                    dtchart(chart)("ENTRY_DS_PRESSURE") = 0
                End If
            Else
                dtchart(chart)("ENTRY_DS_PRESSURE") = 0
            End If
            ' If dt(j)("COIL_THICKNESS") >= 1.0 And dt(j)("COIL_THICKNESS") <= 1.74 And dt(j)("EXIT_DS_PRESSURE") < 210 Then
            If dtmainfinal(chart)("COIL_THICKNESS") = 1.6 And Not IsDBNull(dtmainfinal(chart)("EXIT_DS_PRESSURE")) Then
                If dtmainfinal(chart)("EXIT_DS_PRESSURE") < 210 Then
                    dtchart(chart)("EXIT_DS_PRESSURE") = 1

                Else
                    dtchart(chart)("EXIT_DS_PRESSURE") = 0
                End If
            Else
                dtchart(chart)("EXIT_DS_PRESSURE") = 0
            End If
            If IsDBNull(dtmainfinal.Rows.Item(chart)("FRT")) Then
                dtchart(chart)("FRT") = 0
            Else
                dtchart(chart)("FRT") = dtmainfinal.Rows.Item(chart)("FRT")
            End If
            If dtmainfinal(chart)("COIL_THICKNESS") = 1.6 And Not IsDBNull(dtmainfinal(chart)("ROLL_FORCE_F1")) Then
                If dtmainfinal(chart)("ROLL_FORCE_F1") > 35 Then
                    dtchart(chart)("ROLL_FORCE_F1") = 1
                Else
                    dtchart(chart)("ROLL_FORCE_F1") = 0
                End If
            Else
                dtchart(chart)("ROLL_FORCE_F1") = 0
            End If

            If dtmainfinal(chart)("COIL_THICKNESS") = 1.6 And Not IsDBNull(dtmainfinal(chart)("ROLL_FORCE_F2")) Then
                If dtmainfinal(chart)("ROLL_FORCE_F2") > 30 Then
                    dtchart(chart)("ROLL_FORCE_F2") = 1
                Else
                    dtchart(chart)("ROLL_FORCE_F2") = 0
                End If
            Else
                dtchart(chart)("ROLL_FORCE_F2") = 0
            End If
            If dtmainfinal(chart)("COIL_THICKNESS") = 1.6 And Not IsDBNull(dtmainfinal(chart)("ROLL_FORCE_F3")) Then
                If dtmainfinal(chart)("ROLL_FORCE_F3") > 25 Then
                    dtchart(chart)("ROLL_FORCE_F3") = 1
                Else
                    dtchart(chart)("ROLL_FORCE_F3") = 0
                End If
            Else
                dtchart(chart)("ROLL_FORCE_F3") = 0
            End If
            If dtmainfinal(chart)("COIL_THICKNESS") = 1.6 And Not IsDBNull(dtmainfinal(chart)("ROLL_FORCE_F4")) Then
                If dtmainfinal(chart)("ROLL_FORCE_F4") < 18 Or dtmainfinal(chart)("ROLL_FORCE_F4") > 22 Then

                    dtchart(chart)("ROLL_FORCE_F4") = 1
                Else
                    dtchart(chart)("ROLL_FORCE_F4") = 0
                End If
            Else
                dtchart(chart)("ROLL_FORCE_F4") = 0
            End If
            If dtmainfinal(chart)("COIL_THICKNESS") = 1.6 And Not IsDBNull(dtmainfinal(chart)("ROLL_FORCE_F5")) Then
                If dtmainfinal(chart)("ROLL_FORCE_F5") < 12 Or dtmainfinal(chart)("ROLL_FORCE_F5") > 18 Then
                    dtchart(chart)("ROLL_FORCE_F5") = 1
                Else
                    dtchart(chart)("ROLL_FORCE_F5") = 0
                End If
            Else
                dtchart(chart)("ROLL_FORCE_F5") = 0
            End If

            If dtmainfinal(chart)("COIL_THICKNESS") = 1.6 And Not IsDBNull(dtmainfinal(chart)("ROLL_FORCE_F6")) Then
                If dtmainfinal(chart)("ROLL_FORCE_F6") < 5 Or dtmainfinal(chart)("ROLL_FORCE_F6") > 12 Then

                    dtchart(chart)("ROLL_FORCE_F6") = 1
                Else
                    dtchart(chart)("ROLL_FORCE_F6") = 0
                End If
            Else
                dtchart(chart)("ROLL_FORCE_F6") = 0
            End If



        Next








        Dim millentry_chart As Integer = dtchart.Compute("count (MILL_ENTRY_TEMP)", "MILL_ENTRY_TEMP  = 1 And COIL_THICKNESS = 1.6")
        Dim EntryDs_chart As Integer = dtchart.Compute("count(ENTRY_DS_PRESSURE)", "ENTRY_DS_PRESSURE  = 1 And COIL_THICKNESS = 1.6")
        Dim ExitDs_chart As Integer = dtchart.Compute("count(EXIT_DS_PRESSURE)", "EXIT_DS_PRESSURE  = 1 And COIL_THICKNESS = 1.6")
        Dim frtchart As Integer = dtmainfinal.Compute("count(frtcheck)", "frtcheck  = 1 And COIL_THICKNESS = 1.6")
        Dim RollForceF1_chart As Integer = dtchart.Compute("count(ROLL_FORCE_F1)", "ROLL_FORCE_F1  = 1 And COIL_THICKNESS = 1.6")
        Dim RollForceF2_chart As Integer = dtchart.Compute("count(ROLL_FORCE_F2)", "ROLL_FORCE_F2  = 1 And COIL_THICKNESS = 1.6")
        Dim RollForceF3_chart As Integer = dtchart.Compute("count(ROLL_FORCE_F3)", "ROLL_FORCE_F3  = 1 And COIL_THICKNESS = 1.6")
        Dim RollForceF4_chart As Integer = dtchart.Compute("count(ROLL_FORCE_F4)", "ROLL_FORCE_F4  = 1 And COIL_THICKNESS = 1.6")
        Dim RollForceF5_chart As Integer = dtchart.Compute("count(ROLL_FORCE_F5)", "ROLL_FORCE_F5  = 1 and COIL_THICKNESS = 1.6")
        Dim RollForceF6_chart As Integer = dtchart.Compute("count(ROLL_FORCE_F6)", "ROLL_FORCE_F6  = 1 and COIL_THICKNESS = 1.6")
        ' Dim millentry1_chart As Integer = maindt.Compute("count(ENTRY_DS_PRESSURE)", "ENTRY_DS_PRESSURE= ")

        'Dim exitDS_chart As Integer = maindt.Compute("count(EXIT_DS_PRESSURE)", "EXIT_DS_PRESSURE >= 300")



        Literal1.Text = ""
        ' Dim s As New StringBuilder("<script>$(document).ready(function(){$.jqplot.config.enablePlugins=!0;plot1=$.jqplot('graph',[[" & mlf_chart & "," & c_speed_chart & "," & stopper_rod_chart & " , " & bleed_signal_chart & " , " & speed_slowdown_chart & "]],{animate:!$.jqplot.use_excanvas,seriesDefaults:{renderer:$.jqplot.BarRenderer,rendererOptions:{ varyBarColor : true,barMargin: 50 },pointLabels:{show:true,formatString: '%.0f'}},axesDefaults: { tickOptions: { fontSize:'10pt' } },axes:{xaxis:{label:'Parameters',renderer:$.jqplot.CategoryAxisRenderer,ticks:['MLF','CSPEED','STP_ROD','BLEED_SIGNAL','CSPEED_SLOWDOWN']}, yaxis: {min:0,tickOptions : { showGridline : false}, label:  'Number of SLAB',labelRenderer: $.jqplot.CanvasAxisLabelRenderer,formatString:'%.0f'}},seriesColors: ['#008000','#ffc4c4','#8e8d8d','#FF7133','#FF7666'],highlighter:{show:!0}})});</script>")
        Dim s As New StringBuilder("<script>$(document).ready(function(){$.jqplot.config.enablePlugins=!0;plot1=$.jqplot('graph',[[" & millentry_chart & ", " & EntryDs_chart & " , " & ExitDs_chart & " , " & frtchart & " , " & RollForceF1_chart & " , " & RollForceF2_chart & " , " & RollForceF3_chart & " , " & RollForceF4_chart & " , " & RollForceF5_chart & " , " & RollForceF6_chart & "]],{animate:!$.jqplot.use_excanvas,seriesDefaults:{renderer:$.jqplot.BarRenderer,rendererOptions:{ varyBarColor : true,barMargin: 50 },pointLabels:{show:true,formatString: '%.0f'}},axesDefaults: { tickOptions: { fontSize:'10pt' } },axes:{xaxis:{label:'Parameters',renderer:$.jqplot.CategoryAxisRenderer,ticks:['MILL ENTRY TEMP', 'Entry DS Pressure', 'Exit DS Pressure' , 'FRT', 'Roll Force F1' , 'Roll Force F2' , 'Roll Force F3' , 'Roll Force F4' , 'Roll Force F5' , 'Roll Force F6' ]}, yaxis: {min:0,tickOptions : { showGridline : false}, label:  'Number of Coil Deviation',labelRenderer: $.jqplot.CanvasAxisLabelRenderer,formatString:'%.0f'}},seriesColors: ['#008000','#ffc4c4','#8e8d8d','#FF7133','#FF7666'],highlighter:{show:!0}})});</script>")
        Literal1.Text = s.ToString



        'Dim millentry_chart As Integer = maindt.Compute("count (MILL_ENTRY_TEMP)", "MILL_ENTRY_TEMP  = 1 And COIL_THICKNESS = 1.6")
        'Dim EntryDs_chart As Integer = maindt.Compute("count(ENTRY_DS_PRESSURE)", "ENTRY_DS_PRESSURE  = 1 And COIL_THICKNESS = 1.6")
        'Dim ExitDs_chart As Integer = maindt.Compute("count(EXIT_DS_PRESSURE)", "EXIT_DS_PRESSURE  = 1 And COIL_THICKNESS = 1.6")
        'Dim frtchart As Integer = dtmainfinal.Compute("count(frtcheck)", "frtcheck  = 1 And COIL_THICKNESS = 1.6")
        'Dim RollForceF1_chart As Integer = maindt.Compute("count(ROLL_FORCE_F1)", "ROLL_FORCE_F1  = 1 And COIL_THICKNESS = 1.6")
        'Dim RollForceF2_chart As Integer = maindt.Compute("count(ROLL_FORCE_F2)", "ROLL_FORCE_F2  = 1 And COIL_THICKNESS = 1.6")
        'Dim RollForceF3_chart As Integer = maindt.Compute("count(ROLL_FORCE_F3)", "ROLL_FORCE_F3  = 1 And COIL_THICKNESS = 1.6")
        'Dim RollForceF4_chart As Integer = maindt.Compute("count(ROLL_FORCE_F4)", "ROLL_FORCE_F4  = 1 And COIL_THICKNESS = 1.6")
        'Dim RollForceF5_chart As Integer = maindt.Compute("count(ROLL_FORCE_F5)", "ROLL_FORCE_F5  = 1 and COIL_THICKNESS = 1.6")
        'Dim RollForceF6_chart As Integer = maindt.Compute("count(ROLL_FORCE_F6)", "ROLL_FORCE_F6  = 1 and COIL_THICKNESS = 1.6")
        '' Dim millentry1_chart As Integer = maindt.Compute("count(ENTRY_DS_PRESSURE)", "ENTRY_DS_PRESSURE= ")

        ''Dim exitDS_chart As Integer = maindt.Compute("count(EXIT_DS_PRESSURE)", "EXIT_DS_PRESSURE >= 300")



        'Literal1.Text = ""
        '' Dim s As New StringBuilder("<script>$(document).ready(function(){$.jqplot.config.enablePlugins=!0;plot1=$.jqplot('graph',[[" & mlf_chart & "," & c_speed_chart & "," & stopper_rod_chart & " , " & bleed_signal_chart & " , " & speed_slowdown_chart & "]],{animate:!$.jqplot.use_excanvas,seriesDefaults:{renderer:$.jqplot.BarRenderer,rendererOptions:{ varyBarColor : true,barMargin: 50 },pointLabels:{show:true,formatString: '%.0f'}},axesDefaults: { tickOptions: { fontSize:'10pt' } },axes:{xaxis:{label:'Parameters',renderer:$.jqplot.CategoryAxisRenderer,ticks:['MLF','CSPEED','STP_ROD','BLEED_SIGNAL','CSPEED_SLOWDOWN']}, yaxis: {min:0,tickOptions : { showGridline : false}, label:  'Number of SLAB',labelRenderer: $.jqplot.CanvasAxisLabelRenderer,formatString:'%.0f'}},seriesColors: ['#008000','#ffc4c4','#8e8d8d','#FF7133','#FF7666'],highlighter:{show:!0}})});</script>")
        'Dim s As New StringBuilder("<script>$(document).ready(function(){$.jqplot.config.enablePlugins=!0;plot1=$.jqplot('graph',[[" & millentry_chart & ", " & EntryDs_chart & " , " & ExitDs_chart & " , " & frtchart & " , " & RollForceF1_chart & " , " & RollForceF2_chart & " , " & RollForceF3_chart & " , " & RollForceF4_chart & " , " & RollForceF5_chart & " , " & RollForceF6_chart & "]],{animate:!$.jqplot.use_excanvas,seriesDefaults:{renderer:$.jqplot.BarRenderer,rendererOptions:{ varyBarColor : true,barMargin: 50 },pointLabels:{show:true,formatString: '%.0f'}},axesDefaults: { tickOptions: { fontSize:'10pt' } },axes:{xaxis:{label:'Parameters',renderer:$.jqplot.CategoryAxisRenderer,ticks:['MILL ENTRY TEMP', 'Entry DS Pressure', 'Exit DS Pressure' , 'FRT', 'Roll Force F1' , 'Roll Force F2' , 'Roll Force F3' , 'Roll Force F4' , 'Roll Force F5' , 'Roll Force F6' ]}, yaxis: {min:0,tickOptions : { showGridline : false}, label:  'Number of Coil Deviation',labelRenderer: $.jqplot.CanvasAxisLabelRenderer,formatString:'%.0f'}},seriesColors: ['#008000','#ffc4c4','#8e8d8d','#FF7133','#FF7666'],highlighter:{show:!0}})});</script>")
        'Literal1.Text = s.ToString
        dtmainfinal.DefaultView.Sort = "START_TIME desc"

        Dim distinctTable As DataTable = dtmainfinal.DefaultView.ToTable(True)

        tblData.DataSource = distinctTable

        'tblData.DataSource = dtmainfinal
        tblData.DataBind()
    
        If maindt.Rows.Count > 0 Then
            tblData.UseAccessibleHeader = True
            tblData.HeaderRow.TableSection = TableRowSection.TableHeader
        End If
        tblData.DataBind()
        If dtmainfinal.Rows.Count > 0 Then
            tblData.UseAccessibleHeader = True
            tblData.HeaderRow.TableSection = TableRowSection.TableHeader
        End If
        'If dtExcel.Rows.Count > 0 Then

        'End If

        'sheet.Dispose()
        'workbook.Dispose()
        'package.Dispose()


        '----------------------------------------------------------------


        'Dim dt_select As New System.Data.DataTable
        'dt_select = dt.Clone
        dt.Clear()
        maindt.Clear()
        dtmainfinal.Clear()

    End Sub
    Protected Sub btnDownload_Click(sender As Object, e As System.EventArgs) Handles btnDownload.Click
        Response.Clear()
        Response.Buffer = True
        Response.ClearContent()
        Response.ClearHeaders()
        Response.Charset = ""
        Dim FileName = "Mill Parameter Deviation" + DateTime.Now + ".xls"
        Dim strwritter As New StringWriter()
        Dim htmltextwrtter As New HtmlTextWriter(strwritter)
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.ContentType = "application/vnd.ms-excel"
        Response.AddHeader("Content-Disposition", "attachment;filename=" + FileName)
        tblData.GridLines = GridLines.Both
        tblData.HeaderStyle.Font.Bold = True
        tblData.RenderControl(htmltextwrtter)
        Response.Write(strwritter.ToString())
        Response.End()

    End Sub

    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)
        ' Verifies that the control is rendered 
    End Sub
   

    Protected Sub tblData_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles tblData.RowDataBound
     
        If e.Row.RowType = DataControlRowType.DataRow Then

            Dim count As Short = 0
            Dim coilid As Short = 0
            Dim mill_entry As String = ""
            Dim start_time As String = ""
            Dim thickness As String = ""
            '  Dim speedBefore As String = ""
            Dim entryDS As String = ""
            Dim exitDS As String = ""
            Dim frt As String = ""
            Dim t As Double = 0.0
            Dim usl As String = "1070"
            Dim lsl As String = "1030"
            Dim r As Double
            '    Dim r1 As Double
            Dim entrypr1 = 187
            Dim entrypr2 = 200
            Dim entrypr3 = 213
            Dim entrypr4 = 225
            Dim entrypr5 = 240
            Dim entrypr6 = 240
            Dim exitpr1 = 210
            Dim exitpr2 = 255
            Dim exitpr3 = 298
            Dim exitpr4 = 315
            Dim exitpr5 = 315
            Dim exitpr6 = 340
            Dim t1_act As Integer

            If IsDBNull(DataBinder.Eval(e.Row.DataItem, "MILL_ENTRY_TEMP")) Then
                e.Row.Cells(3).Text = "0"
            End If


            If IsDBNull(DataBinder.Eval(e.Row.DataItem, "MILL_ENTRY_TEMP")) OrElse CStr(DataBinder.Eval(e.Row.DataItem, "MILL_ENTRY_TEMP").ToString().Trim()) = 0 Then
                e.Row.Cells(3).BackColor = Color.Transparent
            ElseIf t1_act >= lsl And t1_act <= usl Then
                e.Row.Cells(3).BackColor = Color.Green
            Else
                e.Row.Cells(3).BackColor = Color.Tomato 'FromName("#FD714B") 'Color.Red
            End If
            'If DataBinder.Eval(e.Row.DataItem, "MILL_ENTRY_TEMP") >= lsl And DataBinder.Eval(e.Row.DataItem, "MILL_ENTRY_TEMP") <= usl Then
            '    e.Row.Cells(3).BackColor = Color.Green
            'Else
            '    e.Row.Cells(3).BackColor = Color.Red
            'End If
            r = DataBinder.Eval(e.Row.DataItem, "COIL_THICKNESS")

            'If r >= 1.0 And r <= 1.74 Then

            If r = 1.6 Then

                If IsDBNull(DataBinder.Eval(e.Row.DataItem, "ENTRY_DS_PRESSURE")) OrElse CStr(DataBinder.Eval(e.Row.DataItem, "ENTRY_DS_PRESSURE").ToString().Trim()) = 0 Then
                    e.Row.Cells(4).BackColor = Color.Transparent

                ElseIf CStr(DataBinder.Eval(e.Row.DataItem, "ENTRY_DS_PRESSURE").ToString().Trim()) >= entrypr1 Then
                    e.Row.Cells(4).BackColor = Color.Green
                Else
                    e.Row.Cells(4).BackColor = Color.Tomato 'Color.FromName("#FD714B") 'Color.Red
                End If
                If IsDBNull(DataBinder.Eval(e.Row.DataItem, "EXIT_DS_PRESSURE")) OrElse CStr(DataBinder.Eval(e.Row.DataItem, "EXIT_DS_PRESSURE").ToString().Trim()) = 0 Then
                    e.Row.Cells(5).BackColor = Color.Transparent

                ElseIf CStr(DataBinder.Eval(e.Row.DataItem, "EXIT_DS_PRESSURE").ToString().Trim()) >= exitpr1 Then
                    e.Row.Cells(5).BackColor = Color.Green
                Else
                    e.Row.Cells(5).BackColor = Color.Tomato ' Color.FromName("#FD714B")
                End If
            End If
          


            If IsDBNull(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F1")) Then
                e.Row.Cells(13).Text = "0"
            End If
            If IsDBNull(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F2")) Then
                e.Row.Cells(14).Text = "0"
            End If
            If IsDBNull(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F3")) Then
                e.Row.Cells(15).Text = "0"
            End If
            If IsDBNull(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F4")) Then
                e.Row.Cells(16).Text = "0"
            End If
            If IsDBNull(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F5")) Then
                e.Row.Cells(17).Text = "0"
            End If
            If IsDBNull(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F6")) Then
                e.Row.Cells(18).Text = "0"
            End If

            If r = 1.6 Then
                If CStr(DataBinder.Eval(e.Row.DataItem, "frtcheck").ToString().Trim()) = "2" Then
                    e.Row.Cells(6).BackColor = Color.Transparent
                ElseIf CStr(DataBinder.Eval(e.Row.DataItem, "frtcheck").ToString().Trim()) = 0 Then
                    e.Row.Cells(6).BackColor = Color.Green
                Else
                    e.Row.Cells(6).BackColor = Color.Tomato 'Color.FromName("#FD714B")  '#930606
                    'e.Row.Cells(6).ForeColor = Color.White
                End If


                If IsDBNull(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F1")) OrElse CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F1").ToString().Trim()) = 0 Then
                    e.Row.Cells(13).BackColor = Color.Transparent
                ElseIf CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F1").ToString().Trim()) < 35 Then
                    e.Row.Cells(13).BackColor = Color.Green
                Else
                    e.Row.Cells(13).BackColor = Color.Tomato 'Color.FromName("#FD714B")  'Color.Red
                End If
                If IsDBNull(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F2")) OrElse CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F2").ToString().Trim()) = 0 Then
                    e.Row.Cells(14).BackColor = Color.Transparent
                ElseIf CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F2").ToString().Trim()) < 30 Then
                    e.Row.Cells(14).BackColor = Color.Green
                Else
                    e.Row.Cells(14).BackColor = Color.Tomato 'Color.FromName("#FD714B") 'Color.Red
                End If

                If IsDBNull(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F3")) OrElse CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F3").ToString().Trim()) = 0 Then
                    e.Row.Cells(15).BackColor = Color.Transparent
                ElseIf CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F3").ToString().Trim()) < 25 Then
                    e.Row.Cells(15).BackColor = Color.Green
                Else
                    e.Row.Cells(15).BackColor = Color.Tomato 'Color.FromName("#FD714B") 'Color.Red
                End If

                If IsDBNull(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F4")) OrElse CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F4").ToString().Trim()) = 0 Then
                    e.Row.Cells(16).BackColor = Color.Transparent
                ElseIf CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F4").ToString().Trim()) >= 18 And CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F4").ToString().Trim()) <= 22 Then

                    e.Row.Cells(16).BackColor = Color.Green
                Else
                    e.Row.Cells(16).BackColor = Color.Tomato 'Color.FromName("#FD714B") 'Color.Red
                End If

                If IsDBNull(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F5")) OrElse CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F5").ToString().Trim()) = 0 Then
                    e.Row.Cells(17).BackColor = Color.Transparent
                ElseIf CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F5").ToString().Trim()) >= 12 And CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F5").ToString().Trim()) <= 18 Then
                    e.Row.Cells(17).BackColor = Color.Green
                Else
                    e.Row.Cells(17).BackColor = Color.Tomato 'Color.FromName("#FD714B") 'Color.Red
                End If
                If IsDBNull(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F6")) OrElse CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F6").ToString().Trim()) = 0 Then
                    e.Row.Cells(18).BackColor = Color.Transparent
                ElseIf CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F6").ToString().Trim()) >= 5 And CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F6").ToString().Trim()) <= 12 Then
                    e.Row.Cells(18).BackColor = Color.Green
                Else
                    e.Row.Cells(18).BackColor = Color.Tomato 'Color.FromName("#FD714B") 'Color.Red
                End If
            End If




            '   e.Row.ToolTip = e.Row.Cells(1).Text & "-" & e.Row.Cells(3).Text
            'For j = 0 To dt.Rows.Count - 1
            '    Dim row = dt.NewRow
            '    If DataBinder.Eval(e.Row.DataItem, "MILL_ENTRY_TEMP") = "No Deviation" Then

            '        e.Row.ToolTip = dt.Rows.Item(j)(3)
            '        dt.Rows.Add(row)
            '        e.Row.ToolTip = e.Row.DataItem("coil_id").ToString()
            '        e.Row.ToolTip = e.Row.DataItem("EXIT_DS_PRESSURE").ToString()
            '    End If
            'Next

            'For j = 0 To dt.Rows.Count - 1
            '    ' for (i = 0; i < e.Row.Cells.Count; i++)

            '    'e.Row.ToolTip = e.Row.DataItem("ENTRY_DS_PRESSURE").ToString()

            '    e.Row.ToolTip = TryCast(e.Row.DataItem, DataRowView)("MILL_ENTRY_TEMP").ToString()
            'Next


            ''''-----------------------TOOLTIP------------------------ ''''
            'If e.Row.RowType = DataControlRowType.Header Then

            '    For i As Integer = 0 To tblData1.Columns.Count - 1
            '        e.Row.Cells(i).ToolTip = tblData1.Columns(i).HeaderText
            '    Next
            'End If

            'If e.Row.RowType = DataControlRowType.DataRow Then

            '    For Each gvcell As TableCell In e.Row.Cells
            '        gvcell.ToolTip = gvcell.Text
            '    Next
            'End If  




        End If
    End Sub


    'Protected Sub tblData_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles tblData.RowDataBound
    '    'If e.Row.RowType = DataControlRowType.Header Then
    '    '    e.Row.Cells(0).CssClass = "headerText"
    '    '    e.Row.Cells(1).CssClass = "headerText"
    '    '    e.Row.Cells(2).CssClass = "headerText"
    '    '    e.Row.Cells(3).CssClass = "headerText"
    '    '    e.Row.Cells(4).CssClass = "headerText"
    '    '    e.Row.Cells(5).CssClass = "headerText"
    '    '    e.Row.Cells(6).CssClass = "headerText"
    '    '    e.Row.Cells(7).CssClass = "headerText"
    '    '    e.Row.Cells(8).CssClass = "headerText"
    '    '    e.Row.Cells(9).CssClass = "headerText"
    '    '    e.Row.Cells(10).CssClass = "headerText"
    '    '    e.Row.Cells(11).CssClass = "headerText"
    '    '    e.Row.Cells(12).CssClass = "headerText"
    '    '    e.Row.Cells(13).CssClass = "headerText"
    '    '    e.Row.Cells(14).CssClass = "headerText"
    '    '    e.Row.Cells(15).CssClass = "headerText"
    '    '    e.Row.Cells(16).CssClass = "headerText"
    '    '    e.Row.Cells(17).CssClass = "headerText"
    '    '    e.Row.Cells(18).CssClass = "headerText"
    '    '    e.Row.Cells(19).CssClass = "headerText"
    '    '    e.Row.Cells(20).CssClass = "headerText"
    '    '    e.Row.Cells(21).CssClass = "headerText"
    '    'End If

    '    If e.Row.RowType = DataControlRowType.DataRow Then

    '        Dim count As Short = 0
    '        Dim coilid As Short = 0
    '        Dim mill_entry As String = ""
    '        Dim start_time As String = ""
    '        Dim thickness As String = ""
    '        '  Dim speedBefore As String = ""
    '        Dim entryDS As String = ""
    '        Dim exitDS As String = ""
    '        Dim frt As String = ""
    '        Dim t As Double = 0.0
    '        Dim usl As String = "1070"
    '        Dim lsl As String = "1030"
    '        Dim r As Double
    '        '    Dim r1 As Double
    '        Dim entrypr1 = 187
    '        Dim entrypr2 = 200
    '        Dim entrypr3 = 213
    '        Dim entrypr4 = 225
    '        Dim entrypr5 = 240
    '        Dim entrypr6 = 240
    '        Dim exitpr1 = 210
    '        Dim exitpr2 = 255
    '        Dim exitpr3 = 298
    '        Dim exitpr4 = 315
    '        Dim exitpr5 = 315
    '        Dim exitpr6 = 340
    '        Dim t1_act As Integer = DataBinder.Eval(e.Row.DataItem, "MILL_ENTRY_TEMP")
    '        If t1_act = 0 Then
    '            e.Row.Cells(3).BackColor = Color.Transparent
    '        ElseIf t1_act >= lsl And t1_act <= usl Then
    '            e.Row.Cells(3).BackColor = Color.Green
    '        Else
    '            e.Row.Cells(3).BackColor = Color.FromName("#FD714B") ' Color.Red
    '            'e.Row.Cells(3).ForeColor = Color.White
    '        End If
    '        'If DataBinder.Eval(e.Row.DataItem, "MILL_ENTRY_TEMP") >= lsl And DataBinder.Eval(e.Row.DataItem, "MILL_ENTRY_TEMP") <= usl Then
    '        '    e.Row.Cells(3).BackColor = Color.Green
    '        'Else
    '        '    e.Row.Cells(3).BackColor = Color.Red
    '        'End If
    '        r = DataBinder.Eval(e.Row.DataItem, "COIL_THICKNESS")

    '        If r >= 1.0 And r <= 1.74 Then
    '            If CStr(DataBinder.Eval(e.Row.DataItem, "ENTRY_DS_PRESSURE").ToString().Trim()) = 0 Then
    '                e.Row.Cells(4).BackColor = Color.Transparent

    '            ElseIf CStr(DataBinder.Eval(e.Row.DataItem, "ENTRY_DS_PRESSURE").ToString().Trim()) >= entrypr1 Then
    '                e.Row.Cells(4).BackColor = Color.Green
    '            Else
    '                e.Row.Cells(4).BackColor = Color.FromName("#FD714B") 'Color.Red
    '                'e.Row.Cells(4).ForeColor = Color.White
    '            End If
    '            If CStr(DataBinder.Eval(e.Row.DataItem, "EXIT_DS_PRESSURE").ToString().Trim()) = 0 Then
    '                e.Row.Cells(5).BackColor = Color.Transparent

    '            ElseIf CStr(DataBinder.Eval(e.Row.DataItem, "EXIT_DS_PRESSURE").ToString().Trim()) >= exitpr1 Then
    '                e.Row.Cells(5).BackColor = Color.Green
    '            Else
    '                e.Row.Cells(5).BackColor = Color.FromName("#FD714B") ' Color.Red
    '                'e.Row.Cells(5).ForeColor = Color.White
    '            End If
    '        End If

    '        If r = 1.6 Then
    '            '------FRT-------

    '            If CStr(DataBinder.Eval(e.Row.DataItem, "frtcheck").ToString().Trim()) = "" Then
    '                e.Row.Cells(6).BackColor = Color.Transparent
    '            ElseIf CStr(DataBinder.Eval(e.Row.DataItem, "frtcheck").ToString().Trim()) = 0 Then
    '                e.Row.Cells(6).BackColor = Color.Green
    '            Else
    '                e.Row.Cells(6).BackColor = Color.FromName("#FD714B")  '#930606
    '                'e.Row.Cells(6).ForeColor = Color.White
    '            End If
    '        End If
    '        '-------------ROLLF1---------
    '        If r = 1.6 Then
    '            If CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F1").ToString().Trim()) = 0 Then
    '                e.Row.Cells(13).BackColor = Color.Transparent
    '            ElseIf CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F1").ToString().Trim()) < 35 Then
    '                e.Row.Cells(13).BackColor = Color.Green
    '            Else
    '                e.Row.Cells(13).BackColor = Color.FromName("#FD714B") ' Color.Red
    '                'e.Row.Cells(7).ForeColor = Color.White
    '            End If
    '            '-------------ROLLF2---------
    '            If CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F2").ToString().Trim()) = 0 Then
    '                e.Row.Cells(14).BackColor = Color.Transparent

    '            ElseIf CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F2").ToString().Trim()) < 30 Then
    '                e.Row.Cells(14).BackColor = Color.Green
    '            Else
    '                e.Row.Cells(14).BackColor = Color.FromName("#FD714B") ' Color.Red
    '                'e.Row.Cells(8).ForeColor = Color.White
    '            End If
    '            '-------------ROLLF3---------
    '            If CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F3").ToString().Trim()) = 0 Then
    '                e.Row.Cells(15).BackColor = Color.Transparent
    '            ElseIf CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F3").ToString().Trim()) < 25 Then
    '                e.Row.Cells(15).BackColor = Color.Green
    '            Else
    '                e.Row.Cells(15).BackColor = Color.FromName("#FD714B") ' Color.Red
    '                'e.Row.Cells(9).ForeColor = Color.White
    '            End If
    '            '-------------ROLLF4---------
    '            If CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F4").ToString().Trim()) = 0 Then
    '                e.Row.Cells(16).BackColor = Color.Transparent
    '            ElseIf CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F4").ToString().Trim()) >= 18 And CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F4").ToString().Trim()) <= 22 Then

    '                e.Row.Cells(16).BackColor = Color.Green
    '            Else
    '                e.Row.Cells(16).BackColor = Color.FromName("#FD714B") ' Color.Red
    '                'e.Row.Cells(10).ForeColor = Color.White
    '            End If
    '            '-------------ROLLF5---------
    '            If CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F5").ToString().Trim()) = 0 Then
    '                e.Row.Cells(17).BackColor = Color.Transparent
    '            ElseIf CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F5").ToString().Trim()) >= 12 And CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F5").ToString().Trim()) <= 18 Then
    '                e.Row.Cells(17).BackColor = Color.Green
    '            Else
    '                e.Row.Cells(17).BackColor = Color.FromName("#FD714B") ' Color.Red
    '                'e.Row.Cells(11).ForeColor = Color.White
    '            End If
    '            '-------------ROLLF6---------
    '            If CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F6").ToString().Trim()) = 0 Then
    '                e.Row.Cells(18).BackColor = Color.Transparent
    '            ElseIf CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F6").ToString().Trim()) >= 5 And CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F6").ToString().Trim()) <= 12 Then
    '                e.Row.Cells(18).BackColor = Color.Green
    '            Else
    '                e.Row.Cells(18).BackColor = Color.FromName("#FD714B") ' Color.Red
    '                'e.Row.Cells(12).ForeColor = Color.White
    '            End If
    '        End If




    '        'If DataBinder.Eval(e.Row.DataItem, "MILL_ENTRY_TEMP") = "No Deviation" Then

    '        '    e.Row.Cells(3).BackColor = Color.Green
    '        'Else
    '        '    e.Row.Cells(3).BackColor = Color.Red

    '        'End If
    '        'If DataBinder.Eval(e.Row.DataItem, "ENTRY_DS_PRESSURE") = "No Deviation" Then

    '        '    e.Row.Cells(4).BackColor = Color.Green
    '        'Else
    '        '    e.Row.Cells(4).BackColor = Color.Red

    '        'End If
    '        'If DataBinder.Eval(e.Row.DataItem, "EXIT_DS_PRESSURE") = "No Deviation" Then

    '        '    e.Row.Cells(5).BackColor = Color.Green
    '        'Else
    '        '    e.Row.Cells(5).BackColor = Color.Red

    '        'End If


    '        '   e.Row.ToolTip = e.Row.Cells(1).Text & "-" & e.Row.Cells(3).Text
    '        'For j = 0 To dt.Rows.Count - 1
    '        '    Dim row = dt.NewRow
    '        '    If DataBinder.Eval(e.Row.DataItem, "MILL_ENTRY_TEMP") = "No Deviation" Then

    '        '        e.Row.ToolTip = dt.Rows.Item(j)(3)
    '        '        dt.Rows.Add(row)
    '        '        e.Row.ToolTip = e.Row.DataItem("coil_id").ToString()
    '        '        e.Row.ToolTip = e.Row.DataItem("EXIT_DS_PRESSURE").ToString()
    '        '    End If
    '        'Next

    '        'For j = 0 To dt.Rows.Count - 1
    '        '    ' for (i = 0; i < e.Row.Cells.Count; i++)

    '        '    'e.Row.ToolTip = e.Row.DataItem("ENTRY_DS_PRESSURE").ToString()

    '        '    e.Row.ToolTip = TryCast(e.Row.DataItem, DataRowView)("MILL_ENTRY_TEMP").ToString()
    '        'Next


    '        ''''-----------------------TOOLTIP------------------------ ''''
    '        'If e.Row.RowType = DataControlRowType.Header Then

    '        '    For i As Integer = 0 To tblData1.Columns.Count - 1
    '        '        e.Row.Cells(i).ToolTip = tblData1.Columns(i).HeaderText
    '        '    Next
    '        'End If

    '        'If e.Row.RowType = DataControlRowType.DataRow Then

    '        '    For Each gvcell As TableCell In e.Row.Cells
    '        '        gvcell.ToolTip = gvcell.Text
    '        '    Next
    '        'End If




    '    End If
    'End Sub




    Protected Sub txtSearch_TextChanged(sender As Object, e As System.EventArgs) Handles txtSearch.TextChanged

        Try

            Dim filter As String = ""
            'Dim ds As DataSet = objController.SearchCOIL(filter)
            'Dim dt As DataTable = ds.Tables(0)

            If txtSearch.Text <> "" Then
                '  filter &= " WHERE COIL_ID = '" & txtSearch.Text & "'"
                filter &= " WHERE  [TSCR_COIL_DETAILS].coil_id  = '" & txtSearch.Text & "'"
                Dim ds As DataSet = objController.SearchCOIL(filter)
                Dim dt As DataTable = ds.Tables(0)
                If dt.Rows.Count > 0 Then
                    tblData.DataSource = dt
                    tblData.DataBind()
                    tblData.UseAccessibleHeader = True
                    tblData.HeaderRow.TableSection = TableRowSection.TableHeader
                Else
                    UserMsgBoxError("Coil-Id Not Found.")
                    '  txtSearch.Attributes.Add("placeholder", "Search Using Coil id")

                End If
            End If

        Catch ex As Exception
            tblData.UseAccessibleHeader = True
            tblData.HeaderRow.TableSection = TableRowSection.TableHeader
        End Try
    End Sub



End Class
                '--------------------------------------------------
                '1st method to save dt in .txt or .csv file
                '--------------------------------------------------
                'Dim filename As String = "D:\Ritika\Ritika\Checktextfile\a.txt"

                'Dim _nRowIndex As Integer = 1
                'Using _objWriter As New StreamWriter(filename, False, Encoding.UTF8)
                '    For Each row As DataRow In dt.Rows
                '        _nRowIndex += 1
                '        For Each col As DataColumn In dt.Columns
                '            _objWriter.WriteLine(row(col.ColumnName).ToString())
                '        Next
                '    Next
                'End Using
                '----------------------------------------------------------
                '2nd method to save dt in .txt or .csv file
                '----------------------------------------------------------
                ' Public Shared Sub WriteDataToFile(ByVal submittedDataTable As DataTable, ByVal submittedFilePath As String)
                '---------------------------------------
                'Dim i As Integer = 0
                'Dim sw As StreamWriter = Nothing
                'Dim filename As String = "D:\Ritika\Ritika\Checktextfile\a.csv"
                '' sw = New StreamWriter(filename, False, Encoding.UTF8)
                'sw = New StreamWriter(filename, False)

                'For i = 0 To dt.Columns.Count - 1 - 1
                '    sw.Write(dt.Columns(i).ColumnName)
                'Next

                'sw.Write(dt.Columns(i).ColumnName & "")
                'sw.WriteLine()

                'For Each row As DataRow In dt.Rows
                '    Dim array As Object() = row.ItemArray

                '    For i = 0 To array.Length - 1 - 1
                '        sw.Write(array(i).ToString() & "")
                '    Next

                '    sw.Write(array(i).ToString())
                '    sw.WriteLine()
                'Next

                'sw.Close()
                '-----------------------------------------------------

                '3rd method to save dt in .txt or .csv file
                '-------------------------------------------------
                '        Dim sw As StreamWriter = Nothing
                '        Dim filename As String = "D:\Ritika\Ritika\Checktextfile\a.csv"
                '        ' sw = New StreamWriter(filename, False, Encoding.UTF8)


                '        sw = New StreamWriter(filename, False)

                '        For i As Integer = 0 To dt.Columns.Count - 1
                '            sw.Write(dt.Columns(i))

                '            If i < dt.Columns.Count - 1 Then
                '                sw.Write(",")
                '            End If
                '        Next

                'sw.Write(sw.NewLine)

                '        For Each dr As DataRow In dt.Rows

                '            For i As Integer = 0 To dt.Columns.Count - 1

                '                If Not Convert.IsDBNull(dr(i)) Then
                '                    Dim value As String = dr(i).ToString()

                '                    If value.Contains(","c) Then
                '                        value = String.Format("""{0}""", value)
                '                        sw.Write(value)
                '                    Else
                '                        sw.Write(dr(i).ToString())
                '                    End If
                '                End If

                '                If i < dt.Columns.Count - 1 Then
                '                    sw.Write(",")
                '                End If
                '            Next

                '            sw.Write(sw.NewLine)
                '        Next

                '        sw.Close()
                '----------------- ------------------------------------
           

