﻿Imports System.Data
Imports System.IO
Imports System.Net
Imports System.Drawing
Imports System.Data.OleDb
Imports OfficeOpenXml

Partial Class Coil_Deviation
    Inherits System.Web.UI.Page
    Dim objController As New Controller_CoilDeviation
    Private _getBase64String As Object

    Private Property GetBase64String(url As String) As Object
        Get
            Return _getBase64String
        End Get
        Set(value As Object)
            _getBase64String = value
        End Set
    End Property

    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            lnkbtn_datetime.Text = Now.AddDays(-7).ToString("dd-MM-yyyy hh:mm:ss tt") & " To " & Now.ToString("dd-MM-yyyy hh:mm:ss tt")
            hfFrom.Value = Now.AddDays(-7).ToString("yyyy-MM-dd HH:mm:ss")
            hfTo.Value = Now.ToString("yyyy-MM-dd HH:mm:ss")
            Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
            main()

            'maind1()
        End If
    End Sub
    Dim maindt As New DataTable
    ' Dim maindt2 As New DataTable

    Sub main()

        Dim startDate As String = hfFrom.Value
        Dim endDate As String = hfTo.Value
        Dim ds As DataSet = objController.GetCOILDataDEVIATION(startDate, endDate)
        Dim dt As DataTable = ds.Tables(0)
        dt.DefaultView.Sort = " START_TIME"



        Dim ds1 As DataSet = objController.GetCOIL_Defect(startDate, endDate)
        Dim dt1 As DataTable = ds1.Tables(0)
        '  Dim dtfinal As New DataTable
        ' dt = dt.DefaultView.ToTable
        maindt.Columns.Add("COIL_ID")
        maindt.Columns.Add("START_TIME")
        maindt.Columns.Add("COIL_THICKNESS")
        maindt.Columns.Add("MILL_ENTRY_TEMP")
        ' maindt.Columns.Add("SPEED_BEFORE_F1")
        maindt.Columns.Add("ENTRY_DS_PRESSURE")
        maindt.Columns.Add("EXIT_DS_PRESSURE")
        maindt.Columns.Add("FRT")
        maindt.Columns.Add("F1_ROLL_GAP")
        maindt.Columns.Add("F2_ROLL_GAP")
        maindt.Columns.Add("F3_ROLL_GAP")
        maindt.Columns.Add("F4_ROLL_GAP")
        maindt.Columns.Add("F5_ROLL_GAP")
        maindt.Columns.Add("F6_ROLL_GAP")
        maindt.Columns.Add("QLTY_CODE")
        maindt.Columns.Add("ROLL_FORCE_F1")
        maindt.Columns.Add("ROLL_FORCE_F2")
        maindt.Columns.Add("ROLL_FORCE_F3")
        maindt.Columns.Add("ROLL_FORCE_F4")
        maindt.Columns.Add("ROLL_FORCE_F5")
        maindt.Columns.Add("ROLL_FORCE_F6")
        maindt.Columns.Add("F1_INSTND_COOL")
        maindt.Columns.Add("F2_INSTND_COOL")
        maindt.Columns.Add("F3_INSTND_COOL")
        maindt.Columns.Add("RGL_F2_TOP_OIL_WATER")
        maindt.Columns.Add("RGL_F2_BOT_OIL_WATER")
        maindt.Columns.Add("RGL_F3_TOP_OIL_WATER")
        maindt.Columns.Add("RGL_F3_BOT_OIL_WATER")
        maindt.Columns.Add("RGL_F4_TOP_OIL_WATER")
        maindt.Columns.Add("RGL_F4_BOT_OIL_WATER")
        maindt.Columns.Add("DEFECT_TYPE")
        Dim count As Short = 0
        Dim coilid As Short = 0
        Dim mill_entry As String = ""
        Dim start_time As String = ""
        Dim thickness As String = ""
        '  Dim speedBefore As String = ""
        Dim entryDS As String = ""
        Dim exitDS As String = ""
        Dim frt As String = ""
        Dim QtyCode As String = ""
        Dim t As Double = 0.0
        Dim usl As String = "1070"
        Dim lsl As String = "1030"
        Dim r As Double
        '    Dim r1 As Double
        Dim entrypr1 = 187
        Dim entrypr2 = 200
        Dim entrypr3 = 213
        Dim entrypr4 = 225
        Dim entrypr5 = 240
        Dim entrypr6 = 240
        Dim exitpr1 = 210
        Dim exitpr2 = 255
        Dim exitpr3 = 298
        Dim exitpr4 = 315
        Dim exitpr5 = 315
        Dim exitpr6 = 340

        Dim coil_id As String = ""

        If dt1.Rows.Count > 0 Then
            For i As Short = 0 To dt1.Rows.Count - 1
                coil_id = dt1.Rows.Item(i)("coil_id")
                For j = 0 To dt.Rows.Count - 1
                    If dt.Rows.Item(j)("coil_id") = coil_id Then


                        Dim row = maindt.NewRow


                        If IsDBNull(dt.Rows.Item(j)(0)) Then
                            row("COIL_ID") = 0
                        Else
                            row("COIL_ID") = dt.Rows.Item(j)(0)
                        End If
                        If IsDBNull(dt.Rows.Item(j)(1)) Then
                            row("START_TIME") = 0
                        Else
                            row("START_TIME") = dt.Rows.Item(j)(1)
                        End If

                        If IsDBNull(dt.Rows.Item(j)(2)) Then
                            row("COIL_THICKNESS") = 0
                        Else
                            row("COIL_THICKNESS") = dt.Rows.Item(j)(2)
                        End If
                        If IsDBNull(dt.Rows.Item(j)(3)) Then
                            row("MILL_ENTRY_TEMP") = 0
                        Else
                            row("MILL_ENTRY_TEMP") = dt.Rows.Item(j)(3)
                        End If

                        '  row("SPEED_BEFORE_F1") = speedBefore
                        If IsDBNull(dt.Rows.Item(j)(5)) Then
                            row("ENTRY_DS_PRESSURE") = 0
                        Else
                            row("ENTRY_DS_PRESSURE") = dt.Rows.Item(j)(5)
                        End If

                        If IsDBNull(dt.Rows.Item(j)(6)) Then
                            row("EXIT_DS_PRESSURE") = 0
                        Else
                            row("EXIT_DS_PRESSURE") = dt.Rows.Item(j)(6)
                        End If

                        ' row("FRT") = FRT

                        If IsDBNull(dt.Rows.Item(j)(7)) Then
                            row("FRT") = 0
                        Else
                            row("FRT") = dt.Rows.Item(j)(7)
                        End If
                        '=======================================================================================

                        If IsDBNull(dt.Rows.Item(j)(8)) Then
                            row("F1_ROLL_GAP") = 0
                        Else
                            row("F1_ROLL_GAP") = dt.Rows.Item(j)(8)
                        End If


                        If IsDBNull(dt.Rows.Item(j)(9)) Then
                            row("F2_ROLL_GAP") = 0
                        Else
                            row("F2_ROLL_GAP") = dt.Rows.Item(j)(9)
                        End If


                        If IsDBNull(dt.Rows.Item(j)(10)) Then
                            row("F3_ROLL_GAP") = 0
                        Else
                            row("F3_ROLL_GAP") = dt.Rows.Item(j)(10)
                        End If

                        If IsDBNull(dt.Rows.Item(j)(11)) Then
                            row("F4_ROLL_GAP") = 0
                        Else
                            row("F4_ROLL_GAP") = dt.Rows.Item(j)(11)
                        End If

                        If IsDBNull(dt.Rows.Item(j)(12)) Then
                            row("F5_ROLL_GAP") = 0
                        Else
                            row("F5_ROLL_GAP") = dt.Rows.Item(j)(12)
                        End If


                        If IsDBNull(dt.Rows.Item(j)(13)) Then
                            row("F6_ROLL_GAP") = 0
                        Else
                            row("F6_ROLL_GAP") = dt.Rows.Item(j)(13)
                        End If
                        '--------------------------------------------------------------------------------------------------------------
                        If IsDBNull(dt.Rows.Item(j)(14)) Then
                            row("QLTY_CODE") = 0
                        Else
                            row("QLTY_CODE") = dt.Rows.Item(j)(14)
                        End If
                        '================================================================================================================
                        If IsDBNull(dt.Rows.Item(j)(15)) Then
                            row("ROLL_FORCE_F1") = 0
                        Else
                            row("ROLL_FORCE_F1") = dt.Rows.Item(j)(15)
                        End If
                        If IsDBNull(dt.Rows.Item(j)(16)) Then
                            row("ROLL_FORCE_F2") = 0
                        Else
                            row("ROLL_FORCE_F2") = dt.Rows.Item(j)(16)
                        End If
                        If IsDBNull(dt.Rows.Item(j)(17)) Then
                            row("ROLL_FORCE_F3") = 0
                        Else
                            row("ROLL_FORCE_F3") = dt.Rows.Item(j)(17)
                        End If
                        If IsDBNull(dt.Rows.Item(j)(18)) Then
                            row("ROLL_FORCE_F4") = 0
                        Else
                            row("ROLL_FORCE_F4") = dt.Rows.Item(j)(18)
                        End If
                        If IsDBNull(dt.Rows.Item(j)(19)) Then
                            row("ROLL_FORCE_F5") = 0
                        Else
                            row("ROLL_FORCE_F5") = dt.Rows.Item(j)(19)
                        End If
                        If IsDBNull(dt.Rows.Item(j)(20)) Then
                            row("ROLL_FORCE_F6") = 0
                        Else
                            row("ROLL_FORCE_F6") = dt.Rows.Item(j)(20)
                        End If
                        '=================
                        If IsDBNull(dt.Rows.Item(j)(21)) Then
                            row("F1_INSTND_COOL") = 0
                        Else
                            row("F1_INSTND_COOL") = dt.Rows.Item(j)(21)
                        End If

                        If IsDBNull(dt.Rows.Item(j)(22)) Then
                            row("F2_INSTND_COOL") = 0
                        Else
                            row("F2_INSTND_COOL") = dt.Rows.Item(j)(22)
                        End If

                        If IsDBNull(dt.Rows.Item(j)(23)) Then
                            row("F3_INSTND_COOL") = 0
                        Else
                            row("F3_INSTND_COOL") = dt.Rows.Item(j)(23)
                        End If
                        '===============================================
                        If IsDBNull(dt.Rows.Item(j)(24)) Then
                            row("RGL_F2_TOP_OIL_WATER") = 0
                        Else
                            row("RGL_F2_TOP_OIL_WATER") = dt.Rows.Item(j)(24)
                        End If
                        If IsDBNull(dt.Rows.Item(j)(25)) Then
                            row("RGL_F2_BOT_OIL_WATER") = 0
                        Else
                            row("RGL_F2_BOT_OIL_WATER") = dt.Rows.Item(j)(25)
                        End If
                        If IsDBNull(dt.Rows.Item(j)(26)) Then
                            row("RGL_F3_TOP_OIL_WATER") = 0
                        Else
                            row("RGL_F3_TOP_OIL_WATER") = dt.Rows.Item(j)(26)
                        End If
                        If IsDBNull(dt.Rows.Item(j)(27)) Then
                            row("RGL_F3_BOT_OIL_WATER") = 0
                        Else
                            row("RGL_F3_BOT_OIL_WATER") = dt.Rows.Item(j)(27)
                        End If


                        If IsDBNull(dt.Rows.Item(j)(28)) Then
                            row("RGL_F4_TOP_OIL_WATER") = 0
                        Else
                            row("RGL_F4_TOP_OIL_WATER") = dt.Rows.Item(j)(28)
                        End If

                        If IsDBNull(dt.Rows.Item(j)(29)) Then
                            row("RGL_F4_BOT_OIL_WATER") = 0
                        Else
                            row("RGL_F4_BOT_OIL_WATER") = dt.Rows.Item(j)(29)
                        End If
                        If IsDBNull(dt1.Rows.Item(i)(3)) Then
                            row("defect_type") = 0
                        Else
                            row("defect_type") = dt1.Rows.Item(i)(3)
                        End If
                        '===========================================
                        maindt.Rows.Add(row)


                        'dtfinal.Rows.Add(newRowdefect)
                    End If
                Next
            Next
        End If
        'tblData1.DataSource = maindt
        'tblData1.DataBind()

        'If maindt.Rows.Count > 0 Then
        '    tblData1.UseAccessibleHeader = True
        '    tblData1.HeaderRow.TableSection = TableRowSection.TableHeader
        'End If

        '-----------------------------------------------------FRT_Spec.xlsx
        'Dim dtResult As DataTable = Nothing
        'Dim totalSheet As Integer = 0

        'Using objConn As OleDbConnection = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & FRT_Spec.xlsx & ";Extended Properties='Excel 12.0;HDR=YES;IMEX=1;';")
        '    objConn.Open()
        '    Dim cmd As OleDbCommand = New OleDbCommand()
        '    Dim oleda As OleDbDataAdapter = New OleDbDataAdapter()
        '    Dim ds As DataSet = New DataSet()
        '    Dim dt As DataTable = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing)
        '    Dim sheetName As String = String.Empty

        '    If dt IsNot Nothing Then
        '        Dim tempDataTable = (From dataRow In dt.AsEnumerable() Where Not dataRow("TABLE_NAME").ToString().Contains("FilterDatabase") Select dataRow).CopyToDataTable()
        '        dt = tempDataTable
        '        totalSheet = dt.Rows.Count
        '        sheetName = dt.Rows(0)("TABLE_NAME").ToString()
        '    End If

        '    cmd.Connection = objConn
        '    cmd.CommandType = CommandType.Text
        '    cmd.CommandText = "SELECT * FROM [" & sheetName & "]"
        '    oleda = New OleDbDataAdapter(cmd)
        '    oleda.Fill(ds, "excelData")
        '    dtResult = ds.Tables("excelData")
        '    objConn.Close()
        'End Using
        '--------------------------------------------------------------------------------------------------------------
        'Dim dtexcel As New DataTable
        'Dim filepath As String = AppDomain.CurrentDomain.BaseDirectory & "FRT_Spec.xlsx"
        ''D:\Ritika\Ritika\Hosted_Websites\fpwebsite
        'Dim MyConnection As System.Data.OleDb.OleDbConnection
        'Dim MyCommand As System.Data.OleDb.OleDbDataAdapter
        'MyConnection = New System.Data.OleDb.OleDbConnection("provider=Microsoft.Jet.OLEDB.4.0;Data Source='" & filepath & "';Extended Properties=Excel 8.0;")
        'MyCommand = New System.Data.OleDb.OleDbDataAdapter("select * from [COMPENDIUM_DTLS$]", MyConnection)
        'MyCommand.TableMappings.Add("Table", "TestTable")
        'MyCommand.Fill(dtexcel)

        '-----------------------------------------------------------------
        '  Dim dtexcel As New DataTable

        ' Dim frt1 As Integer
        Dim SheetName As String = ""
        Dim filepath As String = AppDomain.CurrentDomain.BaseDirectory & "FRT_Spec.xlsx"
        'ViewState("exfname") = exfname
        'ViewState("filename") = FileUpload1.FileName
        Dim package As New ExcelPackage(New FileInfo(filepath))
        Dim workbook As ExcelWorkbook = package.Workbook
        Dim sheet As ExcelWorksheet = workbook.Worksheets(1)

        Dim dtExcel As New DataTable
        Dim c As Integer = 1
        Dim x As Short = 1

        While Not sheet.Cells(1, c).Value Is Nothing
            Dim colName As String = ""

            dtExcel.Columns.Add(sheet.Cells(1, c).Value)
            c = c + 1

        End While

        'dtExcel.Rows.Add()
        Dim rRR As Integer = 2
        While Not sheet.Cells(rRR, 1).Value Is Nothing
            dtExcel.Rows.Add()
            For i As Integer = 1 To c - 1
                Dim value As String = ""
                Try
                    value = sheet.Cells(rRR, i).Text
                    'value = sheet.Cells(r, i).Value
                Catch ex As Exception
                End Try
                dtExcel.Rows(rRR - 2)(i - 1) = value
            Next
            rRR = rRR + 1
        End While
        Dim dtmainfinal As New DataTable
        Dim Qlty As String = ""
        'Dim Qltymaindt As String = ""
        Dim maincount As Integer = 0
        dtmainfinal.Columns.Add("COIL_ID")
        dtmainfinal.Columns.Add("START_TIME")
        dtmainfinal.Columns.Add("COIL_THICKNESS")
        dtmainfinal.Columns.Add("MILL_ENTRY_TEMP")
        ' maindt.Columns.Add("SPEED_BEFORE_F1")
        dtmainfinal.Columns.Add("ENTRY_DS_PRESSURE")
        dtmainfinal.Columns.Add("EXIT_DS_PRESSURE")
        dtmainfinal.Columns.Add("FRT")
        dtmainfinal.Columns.Add("F1_ROLL_GAP")
        dtmainfinal.Columns.Add("F2_ROLL_GAP")
        dtmainfinal.Columns.Add("F3_ROLL_GAP")
        dtmainfinal.Columns.Add("F4_ROLL_GAP")
        dtmainfinal.Columns.Add("F5_ROLL_GAP")
        dtmainfinal.Columns.Add("F6_ROLL_GAP")
        dtmainfinal.Columns.Add("QLTY_CODE")
        dtmainfinal.Columns.Add("frtcheck")
        dtmainfinal.Columns.Add("ROLL_FORCE_F1")
        dtmainfinal.Columns.Add("ROLL_FORCE_F2")
        dtmainfinal.Columns.Add("ROLL_FORCE_F3")
        dtmainfinal.Columns.Add("ROLL_FORCE_F4")
        dtmainfinal.Columns.Add("ROLL_FORCE_F5")
        dtmainfinal.Columns.Add("ROLL_FORCE_F6")
        dtmainfinal.Columns.Add("F1_INSTND_COOL")
        dtmainfinal.Columns.Add("F2_INSTND_COOL")
        dtmainfinal.Columns.Add("F3_INSTND_COOL")
        dtmainfinal.Columns.Add("RGL_F2_TOP_OIL_WATER")
        dtmainfinal.Columns.Add("RGL_F2_BOT_OIL_WATER")
        dtmainfinal.Columns.Add("RGL_F3_TOP_OIL_WATER")
        dtmainfinal.Columns.Add("RGL_F3_BOT_OIL_WATER")
        dtmainfinal.Columns.Add("RGL_F4_TOP_OIL_WATER")
        dtmainfinal.Columns.Add("RGL_F4_BOT_OIL_WATER")
        dtmainfinal.Columns.Add("DEFECT_TYPE")
        If dtExcel.Rows.Count > 0 Then
            For i As Short = 0 To dtExcel.Rows.Count - 1
                Qlty = dtExcel.Rows.Item(i)("Q.CODE")
                'Qltymaindt = maindt.Rows.Item(i)("QLTY_CODE")
                ' If dtExcel.Rows.Item(i)("THK-MIN") = "1.6" Then
                For count1 As Short = 0 To maindt.Rows.Count - 1
                    If maindt.Rows.Item(count1)("QLTY_CODE") = Qlty Then ' Or maindt.Rows.Item(count1)("QLTY_CODE") = Qltymaindt Then
                        If Math.Abs(dtExcel.Rows.Item(i)("FRT") - maindt.Rows.Item(count1)("FRT")) <= 25 Then
                            'dtmainfinal.Rows.Add = maindt.Rows

                            Dim newRow As DataRow = dtmainfinal.NewRow()
                            newRow("COIL_ID") = maindt.Rows(count1)("COIL_ID").ToString
                            newRow("START_TIME") = maindt.Rows(count1)("START_TIME").ToString
                            newRow("COIL_THICKNESS") = maindt.Rows(count1)("COIL_THICKNESS").ToString
                            newRow("MILL_ENTRY_TEMP") = maindt.Rows(count1)("MILL_ENTRY_TEMP").ToString
                            newRow("ENTRY_DS_PRESSURE") = maindt.Rows(count1)("ENTRY_DS_PRESSURE").ToString
                            newRow("EXIT_DS_PRESSURE") = maindt.Rows(count1)("EXIT_DS_PRESSURE").ToString
                            newRow("FRT") = maindt.Rows(count1)("FRT").ToString
                            newRow("F1_ROLL_GAP") = maindt.Rows(count1)("F1_ROLL_GAP").ToString
                            newRow("F2_ROLL_GAP") = maindt.Rows(count1)("F2_ROLL_GAP").ToString
                            newRow("F3_ROLL_GAP") = maindt.Rows(count1)("F3_ROLL_GAP").ToString
                            newRow("F4_ROLL_GAP") = maindt.Rows(count1)("F4_ROLL_GAP").ToString
                            newRow("F5_ROLL_GAP") = maindt.Rows(count1)("F5_ROLL_GAP").ToString
                            newRow("F6_ROLL_GAP") = maindt.Rows(count1)("F6_ROLL_GAP").ToString
                            newRow("QLTY_CODE") = maindt.Rows(count1)("QLTY_CODE").ToString
                            newRow("frtcheck") = "0"
                            newRow("ROLL_FORCE_F1") = maindt.Rows(count1)("ROLL_FORCE_F1").ToString
                            newRow("ROLL_FORCE_F2") = maindt.Rows(count1)("ROLL_FORCE_F2").ToString
                            newRow("ROLL_FORCE_F3") = maindt.Rows(count1)("ROLL_FORCE_F3").ToString
                            newRow("ROLL_FORCE_F4") = maindt.Rows(count1)("ROLL_FORCE_F4").ToString
                            newRow("ROLL_FORCE_F5") = maindt.Rows(count1)("ROLL_FORCE_F5").ToString
                            newRow("ROLL_FORCE_F6") = maindt.Rows(count1)("ROLL_FORCE_F6").ToString
                            newRow("F1_INSTND_COOL") = maindt.Rows(count1)("F1_INSTND_COOL").ToString
                            newRow("F2_INSTND_COOL") = maindt.Rows(count1)("F2_INSTND_COOL").ToString
                            newRow("F3_INSTND_COOL") = maindt.Rows(count1)("F3_INSTND_COOL").ToString
                            newRow("RGL_F2_TOP_OIL_WATER") = maindt.Rows(count1)("RGL_F2_TOP_OIL_WATER").ToString
                            newRow("RGL_F2_BOT_OIL_WATER") = maindt.Rows(count1)("RGL_F2_BOT_OIL_WATER").ToString
                            newRow("RGL_F3_TOP_OIL_WATER") = maindt.Rows(count1)("RGL_F3_TOP_OIL_WATER").ToString
                            newRow("RGL_F3_BOT_OIL_WATER") = maindt.Rows(count1)("RGL_F3_BOT_OIL_WATER").ToString
                            newRow("RGL_F4_TOP_OIL_WATER") = maindt.Rows(count1)("RGL_F4_TOP_OIL_WATER").ToString
                            newRow("RGL_F4_BOT_OIL_WATER") = maindt.Rows(count1)("RGL_F4_BOT_OIL_WATER").ToString
                            newRow("DEFECT_TYPE") = maindt.Rows(count1)("DEFECT_TYPE").ToString
                            dtmainfinal.Rows.Add(newRow)
                            'maincount = maincount + 1
                            ' dtmainfinal.DefaultView.Sort = "START_TIME desc"
                            'frt1 = 0  'green  frt1 = 1

                        Else
                            'frt1 = 1 'red 

                            Dim newRow As DataRow = dtmainfinal.NewRow()
                            newRow("COIL_ID") = maindt.Rows(count1)("COIL_ID").ToString
                            newRow("START_TIME") = maindt.Rows(count1)("START_TIME").ToString
                            newRow("COIL_THICKNESS") = maindt.Rows(count1)("COIL_THICKNESS").ToString
                            newRow("MILL_ENTRY_TEMP") = maindt.Rows(count1)("MILL_ENTRY_TEMP").ToString
                            newRow("ENTRY_DS_PRESSURE") = maindt.Rows(count1)("ENTRY_DS_PRESSURE").ToString
                            newRow("EXIT_DS_PRESSURE") = maindt.Rows(count1)("EXIT_DS_PRESSURE").ToString
                            newRow("FRT") = maindt.Rows(count1)("FRT").ToString
                            newRow("F1_ROLL_GAP") = maindt.Rows(count1)("F1_ROLL_GAP").ToString
                            newRow("F2_ROLL_GAP") = maindt.Rows(count1)("F2_ROLL_GAP").ToString
                            newRow("F3_ROLL_GAP") = maindt.Rows(count1)("F3_ROLL_GAP").ToString
                            newRow("F4_ROLL_GAP") = maindt.Rows(count1)("F4_ROLL_GAP").ToString
                            newRow("F5_ROLL_GAP") = maindt.Rows(count1)("F5_ROLL_GAP").ToString
                            newRow("F6_ROLL_GAP") = maindt.Rows(count1)("F6_ROLL_GAP").ToString
                            newRow("QLTY_CODE") = maindt.Rows(count1)("QLTY_CODE").ToString
                            newRow("frtcheck") = "1"
                            newRow("ROLL_FORCE_F1") = maindt.Rows(count1)("ROLL_FORCE_F1").ToString
                            newRow("ROLL_FORCE_F2") = maindt.Rows(count1)("ROLL_FORCE_F2").ToString
                            newRow("ROLL_FORCE_F3") = maindt.Rows(count1)("ROLL_FORCE_F3").ToString
                            newRow("ROLL_FORCE_F4") = maindt.Rows(count1)("ROLL_FORCE_F4").ToString
                            newRow("ROLL_FORCE_F5") = maindt.Rows(count1)("ROLL_FORCE_F5").ToString
                            newRow("ROLL_FORCE_F6") = maindt.Rows(count1)("ROLL_FORCE_F6").ToString
                            newRow("F1_INSTND_COOL") = maindt.Rows(count1)("F1_INSTND_COOL").ToString
                            newRow("F2_INSTND_COOL") = maindt.Rows(count1)("F2_INSTND_COOL").ToString
                            newRow("F3_INSTND_COOL") = maindt.Rows(count1)("F3_INSTND_COOL").ToString
                            newRow("RGL_F2_TOP_OIL_WATER") = maindt.Rows(count1)("RGL_F2_TOP_OIL_WATER").ToString
                            newRow("RGL_F2_BOT_OIL_WATER") = maindt.Rows(count1)("RGL_F2_BOT_OIL_WATER").ToString
                            newRow("RGL_F3_TOP_OIL_WATER") = maindt.Rows(count1)("RGL_F3_TOP_OIL_WATER").ToString
                            newRow("RGL_F3_BOT_OIL_WATER") = maindt.Rows(count1)("RGL_F3_BOT_OIL_WATER").ToString
                            newRow("RGL_F4_TOP_OIL_WATER") = maindt.Rows(count1)("RGL_F4_TOP_OIL_WATER").ToString
                            newRow("RGL_F4_BOT_OIL_WATER") = maindt.Rows(count1)("RGL_F4_BOT_OIL_WATER").ToString
                            dtmainfinal.Rows.Add(newRow)
                            ' maincount = maincount + 1
                            'dtmainfinal.DefaultView.Sort = "START_TIME desc"
                        End If

                    End If

                Next
                'Else


                'End If

            Next
            For Val As Integer = 0 To maindt.Rows.Count - 1
                If maindt.Rows.Item(Val)("QLTY_CODE") = "0" Then

                    Dim newRow As DataRow = dtmainfinal.NewRow()
                    newRow("COIL_ID") = maindt.Rows(Val)("COIL_ID").ToString
                    newRow("START_TIME") = maindt.Rows(Val)("START_TIME").ToString
                    newRow("COIL_THICKNESS") = maindt.Rows(Val)("COIL_THICKNESS").ToString
                    newRow("MILL_ENTRY_TEMP") = maindt.Rows(Val)("MILL_ENTRY_TEMP").ToString
                    newRow("ENTRY_DS_PRESSURE") = maindt.Rows(Val)("ENTRY_DS_PRESSURE").ToString
                    newRow("EXIT_DS_PRESSURE") = maindt.Rows(Val)("EXIT_DS_PRESSURE").ToString
                    newRow("FRT") = maindt.Rows(Val)("FRT").ToString
                    newRow("F1_ROLL_GAP") = maindt.Rows(Val)("F1_ROLL_GAP").ToString
                    newRow("F2_ROLL_GAP") = maindt.Rows(Val)("F2_ROLL_GAP").ToString
                    newRow("F3_ROLL_GAP") = maindt.Rows(Val)("F3_ROLL_GAP").ToString
                    newRow("F4_ROLL_GAP") = maindt.Rows(Val)("F4_ROLL_GAP").ToString
                    newRow("F5_ROLL_GAP") = maindt.Rows(Val)("F5_ROLL_GAP").ToString
                    newRow("F6_ROLL_GAP") = maindt.Rows(Val)("F6_ROLL_GAP").ToString
                    newRow("QLTY_CODE") = maindt.Rows(Val)("QLTY_CODE").ToString
                    newRow("frtcheck") = ""
                    newRow("ROLL_FORCE_F1") = maindt.Rows(Val)("ROLL_FORCE_F1").ToString
                    newRow("ROLL_FORCE_F2") = maindt.Rows(Val)("ROLL_FORCE_F2").ToString
                    newRow("ROLL_FORCE_F3") = maindt.Rows(Val)("ROLL_FORCE_F3").ToString
                    newRow("ROLL_FORCE_F4") = maindt.Rows(Val)("ROLL_FORCE_F4").ToString
                    newRow("ROLL_FORCE_F5") = maindt.Rows(Val)("ROLL_FORCE_F5").ToString
                    newRow("ROLL_FORCE_F6") = maindt.Rows(Val)("ROLL_FORCE_F6").ToString
                    newRow("F1_INSTND_COOL") = maindt.Rows(Val)("F1_INSTND_COOL").ToString
                    newRow("F2_INSTND_COOL") = maindt.Rows(Val)("F2_INSTND_COOL").ToString
                    newRow("F3_INSTND_COOL") = maindt.Rows(Val)("F3_INSTND_COOL").ToString
                    newRow("RGL_F2_TOP_OIL_WATER") = maindt.Rows(Val)("RGL_F2_TOP_OIL_WATER").ToString
                    newRow("RGL_F2_BOT_OIL_WATER") = maindt.Rows(Val)("RGL_F2_BOT_OIL_WATER").ToString
                    newRow("RGL_F3_TOP_OIL_WATER") = maindt.Rows(Val)("RGL_F3_TOP_OIL_WATER").ToString
                    newRow("RGL_F3_BOT_OIL_WATER") = maindt.Rows(Val)("RGL_F3_BOT_OIL_WATER").ToString
                    newRow("RGL_F4_TOP_OIL_WATER") = maindt.Rows(Val)("RGL_F4_TOP_OIL_WATER").ToString
                    newRow("RGL_F4_BOT_OIL_WATER") = maindt.Rows(Val)("RGL_F4_BOT_OIL_WATER").ToString
                    newRow("DEFECT_TYPE") = maindt.Rows(Val)("DEFECT_TYPE").ToString
                    dtmainfinal.Rows.Add(newRow)
                End If

            Next
        End If
        dtmainfinal.DefaultView.Sort = "START_TIME desc"
        Dim sum As Double = 0.0
        For column As Integer = 7 To dtmainfinal.Columns.Count - 1
            For splitcol As Integer = 0 To dtmainfinal.Rows.Count - 1
                '  Dim f1val As String
                '   f1val = dtmainfinal.Rows()("F1_ROLL_GAP")
                Dim f1val As String = dtmainfinal.Rows.Item(splitcol)(column).ToString
                Dim f1split() As String = f1val.Split(",")
                If f1split.Length > 1 Then
                    sum = (CDbl(f1split(0).ToString()) + CDbl(f1split(1).ToString())) / 2
                    dtmainfinal.Rows(splitcol)(column) = sum
                Else
                    'dtmainfinal.Rows(splitcol)(column) = sum
                    Continue For
                End If

                'Dim a(f1val.Length) As String

                'For i As Integer = 0 To f1val.Length - 1
                '    a(i) = f1val.Substring(i, 1)
                'Next i
            Next
            Continue For
        Next

        dtmainfinal.DefaultView.Sort = "START_TIME desc"

        'Dim ds1 As DataSet = objController.GetCOIL_Defect(startDate, endDate)
        'Dim dt1 As DataTable = ds1.Tables(0)
        'Dim dtfinal As New DataTable

        'dtfinal.Columns.Add("COIL_ID")
        'dtfinal.Columns.Add("START_TIME")
        'dtfinal.Columns.Add("COIL_THICKNESS")
        'dtfinal.Columns.Add("MILL_ENTRY_TEMP")
        '' maindt.Columns.Add("SPEED_BEFORE_F1")
        'dtfinal.Columns.Add("ENTRY_DS_PRESSURE")
        'dtfinal.Columns.Add("EXIT_DS_PRESSURE")
        'dtfinal.Columns.Add("FRT")
        'dtfinal.Columns.Add("F1_ROLL_GAP")
        'dtfinal.Columns.Add("F2_ROLL_GAP")
        'dtfinal.Columns.Add("F3_ROLL_GAP")
        'dtfinal.Columns.Add("F4_ROLL_GAP")
        'dtfinal.Columns.Add("F5_ROLL_GAP")
        'dtfinal.Columns.Add("F6_ROLL_GAP")
        'dtfinal.Columns.Add("QLTY_CODE")
        'dtfinal.Columns.Add("frtcheck")
        'dtfinal.Columns.Add("ROLL_FORCE_F1")
        'dtfinal.Columns.Add("ROLL_FORCE_F2")
        'dtfinal.Columns.Add("ROLL_FORCE_F3")
        'dtfinal.Columns.Add("ROLL_FORCE_F4")
        'dtfinal.Columns.Add("ROLL_FORCE_F5")
        'dtfinal.Columns.Add("ROLL_FORCE_F6")
        'dtfinal.Columns.Add("F1_INSTND_COOL")
        'dtfinal.Columns.Add("F2_INSTND_COOL")
        'dtfinal.Columns.Add("F3_INSTND_COOL")
        'dtfinal.Columns.Add("RGL_F2_TOP_OIL_WATER")
        'dtfinal.Columns.Add("RGL_F2_BOT_OIL_WATER")
        'dtfinal.Columns.Add("RGL_F3_TOP_OIL_WATER")
        'dtfinal.Columns.Add("RGL_F3_BOT_OIL_WATER")
        'dtfinal.Columns.Add("RGL_F4_TOP_OIL_WATER")
        'dtfinal.Columns.Add("RGL_F4_BOT_OIL_WATER")
        'dtfinal.Columns.Add("DEFECT_TYPE")
        'Dim coil_id As String = ""
        'If dt1.Rows.Count > 0 Then
        '    For i As Short = 0 To dt1.Rows.Count - 1
        '        coil_id = dt1.Rows.Item(i)("coil_id")
        '        For matchids As Short = 0 To dtmainfinal.Rows.Count - 1
        '            If dtmainfinal.Rows.Item(matchids)("coil_id") = coil_id Then

        '                '  dt1.Rows.Item(i)("defect_type") = "DEFECT_TYPE"
        '                Dim newRowdefect As DataRow = dtfinal.NewRow()
        '                newRowdefect("COIL_ID") = dtmainfinal.Rows(matchids)("COIL_ID").ToString
        '                newRowdefect("START_TIME") = dtmainfinal.Rows(matchids)("START_TIME").ToString
        '                newRowdefect("COIL_THICKNESS") = dtmainfinal.Rows(matchids)("COIL_THICKNESS").ToString
        '                newRowdefect("MILL_ENTRY_TEMP") = dtmainfinal.Rows(matchids)("MILL_ENTRY_TEMP").ToString
        '                newRowdefect("ENTRY_DS_PRESSURE") = dtmainfinal.Rows(matchids)("ENTRY_DS_PRESSURE").ToString
        '                newRowdefect("EXIT_DS_PRESSURE") = dtmainfinal.Rows(matchids)("EXIT_DS_PRESSURE").ToString
        '                newRowdefect("FRT") = dtmainfinal.Rows(matchids)("FRT").ToString
        '                newRowdefect("F1_ROLL_GAP") = dtmainfinal.Rows(matchids)("F1_ROLL_GAP").ToString
        '                newRowdefect("F2_ROLL_GAP") = dtmainfinal.Rows(matchids)("F2_ROLL_GAP").ToString
        '                newRowdefect("F3_ROLL_GAP") = dtmainfinal.Rows(matchids)("F3_ROLL_GAP").ToString
        '                newRowdefect("F4_ROLL_GAP") = dtmainfinal.Rows(matchids)("F4_ROLL_GAP").ToString
        '                newRowdefect("F5_ROLL_GAP") = dtmainfinal.Rows(matchids)("F5_ROLL_GAP").ToString
        '                newRowdefect("F6_ROLL_GAP") = dtmainfinal.Rows(matchids)("F6_ROLL_GAP").ToString
        '                newRowdefect("QLTY_CODE") = dtmainfinal.Rows(matchids)("QLTY_CODE").ToString
        '                newRowdefect("frtcheck") = "0"
        '                newRowdefect("ROLL_FORCE_F1") = dtmainfinal.Rows(matchids)("ROLL_FORCE_F1").ToString
        '                newRowdefect("ROLL_FORCE_F2") = dtmainfinal.Rows(matchids)("ROLL_FORCE_F2").ToString
        '                newRowdefect("ROLL_FORCE_F3") = dtmainfinal.Rows(matchids)("ROLL_FORCE_F3").ToString
        '                newRowdefect("ROLL_FORCE_F4") = dtmainfinal.Rows(matchids)("ROLL_FORCE_F4").ToString
        '                newRowdefect("ROLL_FORCE_F5") = dtmainfinal.Rows(matchids)("ROLL_FORCE_F5").ToString
        '                newRowdefect("ROLL_FORCE_F6") = dtmainfinal.Rows(matchids)("ROLL_FORCE_F6").ToString
        '                newRowdefect("F1_INSTND_COOL") = dtmainfinal.Rows(matchids)("F1_INSTND_COOL").ToString
        '                newRowdefect("F2_INSTND_COOL") = dtmainfinal.Rows(matchids)("F2_INSTND_COOL").ToString
        '                newRowdefect("F3_INSTND_COOL") = dtmainfinal.Rows(matchids)("F3_INSTND_COOL").ToString
        '                newRowdefect("RGL_F2_TOP_OIL_WATER") = dtmainfinal.Rows(matchids)("RGL_F2_TOP_OIL_WATER").ToString
        '                newRowdefect("RGL_F2_BOT_OIL_WATER") = dtmainfinal.Rows(matchids)("RGL_F2_BOT_OIL_WATER").ToString
        '                newRowdefect("RGL_F3_TOP_OIL_WATER") = dtmainfinal.Rows(matchids)("RGL_F3_TOP_OIL_WATER").ToString
        '                newRowdefect("RGL_F3_BOT_OIL_WATER") = dtmainfinal.Rows(matchids)("RGL_F3_BOT_OIL_WATER").ToString
        '                newRowdefect("RGL_F4_TOP_OIL_WATER") = dtmainfinal.Rows(matchids)("RGL_F4_TOP_OIL_WATER").ToString
        '                newRowdefect("RGL_F4_BOT_OIL_WATER") = dtmainfinal.Rows(matchids)("RGL_F4_BOT_OIL_WATER").ToString
        '                newRowdefect("DEFECT_TYPE") = dtmainfinal.Rows(matchids)("DEFECT_TYPE").ToString
        '                dtfinal.Rows.Add(newRowdefect)
        '            End If
        '        Next
        '    Next
        'End If









        Dim distinctTable As DataTable = dtmainfinal.DefaultView.ToTable(True)

        tblData1.DataSource = distinctTable

        '  tblData1.DataSource = dtmainfinal
        tblData1.DataBind()
        If dtmainfinal.Rows.Count > 0 Then
            'tblData1.UseAccessibleHeader = True
            'tblData1.HeaderRow.TableSection = TableRowSection.TableHeader
        End If
        'If dtExcel.Rows.Count > 0 Then

        'End If

        'sheet.Dispose()
        'workbook.Dispose()
        'package.Dispose()


        '----------------------------------------------------------------


        'Dim dt_select As New System.Data.DataTable
        'dt_select = dt.Clone
        dt.Clear()
        maindt.Clear()
        dtmainfinal.Clear()
    End Sub

    'Protected Sub tblData1_RowCreated(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles tblData1.RowCreated
    '    If e.Row.RowType = DataControlRowType.Header Then
    '        Dim row As New GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Insert)
    '        Dim cell As New TableHeaderCell()
    '        cell.Text = "Customers"
    '        cell.CssClass = "gridfreeze"
    '        cell.HorizontalAlign = HorizontalAlign.Center
    '        cell.ColumnSpan = e.Row.Cells.Count
    '        row.Controls.Add(cell)
    '        row.CssClass = "gfreeze"
    '        row.BackColor = ColorTranslator.FromHtml("#3AC0F2")
    '        tblData1.Controls(0).Controls.AddAt(0, row)
    '    End If
    'End Sub
 


    Protected Sub tblData1_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles tblData1.RowDataBound
        'If e.Row.RowType = DataControlRowType.Header Then
        '    e.Row.Cells(0).CssClass = "headerText"
        '    e.Row.Cells(1).CssClass = "headerText"
        '    e.Row.Cells(2).CssClass = "headerText"
        '    e.Row.Cells(3).CssClass = "headerText"
        '    e.Row.Cells(4).CssClass = "headerText"
        '    e.Row.Cells(5).CssClass = "headerText"
        '    e.Row.Cells(6).CssClass = "headerText"
        '    e.Row.Cells(7).CssClass = "headerText"
        '    e.Row.Cells(8).CssClass = "headerText"
        '    e.Row.Cells(9).CssClass = "headerText"
        '    e.Row.Cells(10).CssClass = "headerText"
        '    e.Row.Cells(11).CssClass = "headerText"
        '    e.Row.Cells(12).CssClass = "headerText"
        '    e.Row.Cells(13).CssClass = "headerText"
        '    e.Row.Cells(14).CssClass = "headerText"
        '    e.Row.Cells(15).CssClass = "headerText"
        '    e.Row.Cells(16).CssClass = "headerText"
        '    e.Row.Cells(17).CssClass = "headerText"
        '    e.Row.Cells(18).CssClass = "headerText"
        '    e.Row.Cells(19).CssClass = "headerText"
        '    e.Row.Cells(20).CssClass = "headerText"
        '    e.Row.Cells(21).CssClass = "headerText"
        'End If

        If e.Row.RowType = DataControlRowType.DataRow Then

            Dim count As Short = 0
            Dim coilid As Short = 0
            Dim mill_entry As String = ""
            Dim start_time As String = ""
            Dim thickness As String = ""
            '  Dim speedBefore As String = ""
            Dim entryDS As String = ""
            Dim exitDS As String = ""
            Dim frt As String = ""
            Dim t As Double = 0.0
            Dim usl As String = "1070"
            Dim lsl As String = "1030"
            Dim r As Double
            '    Dim r1 As Double
            Dim entrypr1 = 187
            Dim entrypr2 = 200
            Dim entrypr3 = 213
            Dim entrypr4 = 225
            Dim entrypr5 = 240
            Dim entrypr6 = 240
            Dim exitpr1 = 210
            Dim exitpr2 = 255
            Dim exitpr3 = 298
            Dim exitpr4 = 315
            Dim exitpr5 = 315
            Dim exitpr6 = 340
            Dim t1_act As Integer = DataBinder.Eval(e.Row.DataItem, "MILL_ENTRY_TEMP")
            If t1_act = 0 Then
                e.Row.Cells(3).BackColor = Color.Transparent
            ElseIf t1_act >= lsl And t1_act <= usl Then
                e.Row.Cells(3).BackColor = Color.Green
            Else
                e.Row.Cells(3).BackColor = Color.FromName("#FD714B") ' Color.Red
                'e.Row.Cells(3).ForeColor = Color.White
            End If
            'If DataBinder.Eval(e.Row.DataItem, "MILL_ENTRY_TEMP") >= lsl And DataBinder.Eval(e.Row.DataItem, "MILL_ENTRY_TEMP") <= usl Then
            '    e.Row.Cells(3).BackColor = Color.Green
            'Else
            '    e.Row.Cells(3).BackColor = Color.Red
            'End If
            r = DataBinder.Eval(e.Row.DataItem, "COIL_THICKNESS")

            If r >= 1.0 And r <= 1.74 Then
                If CStr(DataBinder.Eval(e.Row.DataItem, "ENTRY_DS_PRESSURE").ToString().Trim()) = 0 Then
                    e.Row.Cells(4).BackColor = Color.Transparent

                ElseIf CStr(DataBinder.Eval(e.Row.DataItem, "ENTRY_DS_PRESSURE").ToString().Trim()) >= entrypr1 Then
                    e.Row.Cells(4).BackColor = Color.Green
                Else
                    e.Row.Cells(4).BackColor = Color.FromName("#FD714B") 'Color.Red
                    'e.Row.Cells(4).ForeColor = Color.White
                End If
                If CStr(DataBinder.Eval(e.Row.DataItem, "EXIT_DS_PRESSURE").ToString().Trim()) = 0 Then
                    e.Row.Cells(5).BackColor = Color.Transparent

                ElseIf CStr(DataBinder.Eval(e.Row.DataItem, "EXIT_DS_PRESSURE").ToString().Trim()) >= exitpr1 Then
                    e.Row.Cells(5).BackColor = Color.Green
                Else
                    e.Row.Cells(5).BackColor = Color.FromName("#FD714B") ' Color.Red
                    'e.Row.Cells(5).ForeColor = Color.White
                End If
            End If

            If r = 1.6 Then
                '------FRT-------

                If CStr(DataBinder.Eval(e.Row.DataItem, "frtcheck").ToString().Trim()) = "" Then
                    e.Row.Cells(6).BackColor = Color.Transparent
                ElseIf CStr(DataBinder.Eval(e.Row.DataItem, "frtcheck").ToString().Trim()) = 0 Then
                    e.Row.Cells(6).BackColor = Color.Green
                Else
                    e.Row.Cells(6).BackColor = Color.FromName("#FD714B")  '#930606
                    'e.Row.Cells(6).ForeColor = Color.White
                End If
            End If
            '-------------ROLLF1---------
            If r = 1.6 Then
                If CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F1").ToString().Trim()) = 0 Then
                    e.Row.Cells(13).BackColor = Color.Transparent
                ElseIf CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F1").ToString().Trim()) < 35 Then
                    e.Row.Cells(13).BackColor = Color.Green
                Else
                    e.Row.Cells(13).BackColor = Color.FromName("#FD714B") ' Color.Red
                    'e.Row.Cells(7).ForeColor = Color.White
                End If
                '-------------ROLLF2---------
                If CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F2").ToString().Trim()) = 0 Then
                    e.Row.Cells(14).BackColor = Color.Transparent

                ElseIf CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F2").ToString().Trim()) < 30 Then
                    e.Row.Cells(14).BackColor = Color.Green
                Else
                    e.Row.Cells(14).BackColor = Color.FromName("#FD714B") ' Color.Red
                    'e.Row.Cells(8).ForeColor = Color.White
                End If
                '-------------ROLLF3---------
                If CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F3").ToString().Trim()) = 0 Then
                    e.Row.Cells(15).BackColor = Color.Transparent
                ElseIf CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F3").ToString().Trim()) < 25 Then
                    e.Row.Cells(15).BackColor = Color.Green
                Else
                    e.Row.Cells(15).BackColor = Color.FromName("#FD714B") ' Color.Red
                    'e.Row.Cells(9).ForeColor = Color.White
                End If
                '-------------ROLLF4---------
                If CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F4").ToString().Trim()) = 0 Then
                    e.Row.Cells(16).BackColor = Color.Transparent
                ElseIf CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F4").ToString().Trim()) >= 18 And CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F4").ToString().Trim()) <= 22 Then

                    e.Row.Cells(16).BackColor = Color.Green
                Else
                    e.Row.Cells(16).BackColor = Color.FromName("#FD714B") ' Color.Red
                    'e.Row.Cells(10).ForeColor = Color.White
                End If
                '-------------ROLLF5---------
                If CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F5").ToString().Trim()) = 0 Then
                    e.Row.Cells(17).BackColor = Color.Transparent
                ElseIf CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F5").ToString().Trim()) >= 12 And CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F5").ToString().Trim()) <= 18 Then
                    e.Row.Cells(17).BackColor = Color.Green
                Else
                    e.Row.Cells(17).BackColor = Color.FromName("#FD714B") ' Color.Red
                    'e.Row.Cells(11).ForeColor = Color.White
                End If
                '-------------ROLLF6---------
                If CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F6").ToString().Trim()) = 0 Then
                    e.Row.Cells(18).BackColor = Color.Transparent
                ElseIf CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F6").ToString().Trim()) >= 5 And CStr(DataBinder.Eval(e.Row.DataItem, "ROLL_FORCE_F6").ToString().Trim()) <= 12 Then
                    e.Row.Cells(18).BackColor = Color.Green
                Else
                    e.Row.Cells(18).BackColor = Color.FromName("#FD714B") ' Color.Red
                    'e.Row.Cells(12).ForeColor = Color.White
                End If
            End If




            'If DataBinder.Eval(e.Row.DataItem, "MILL_ENTRY_TEMP") = "No Deviation" Then

            '    e.Row.Cells(3).BackColor = Color.Green
            'Else
            '    e.Row.Cells(3).BackColor = Color.Red

            'End If
            'If DataBinder.Eval(e.Row.DataItem, "ENTRY_DS_PRESSURE") = "No Deviation" Then

            '    e.Row.Cells(4).BackColor = Color.Green
            'Else
            '    e.Row.Cells(4).BackColor = Color.Red

            'End If
            'If DataBinder.Eval(e.Row.DataItem, "EXIT_DS_PRESSURE") = "No Deviation" Then

            '    e.Row.Cells(5).BackColor = Color.Green
            'Else
            '    e.Row.Cells(5).BackColor = Color.Red

            'End If


            '   e.Row.ToolTip = e.Row.Cells(1).Text & "-" & e.Row.Cells(3).Text
            'For j = 0 To dt.Rows.Count - 1
            '    Dim row = dt.NewRow
            '    If DataBinder.Eval(e.Row.DataItem, "MILL_ENTRY_TEMP") = "No Deviation" Then

            '        e.Row.ToolTip = dt.Rows.Item(j)(3)
            '        dt.Rows.Add(row)
            '        e.Row.ToolTip = e.Row.DataItem("coil_id").ToString()
            '        e.Row.ToolTip = e.Row.DataItem("EXIT_DS_PRESSURE").ToString()
            '    End If
            'Next

            'For j = 0 To dt.Rows.Count - 1
            '    ' for (i = 0; i < e.Row.Cells.Count; i++)

            '    'e.Row.ToolTip = e.Row.DataItem("ENTRY_DS_PRESSURE").ToString()

            '    e.Row.ToolTip = TryCast(e.Row.DataItem, DataRowView)("MILL_ENTRY_TEMP").ToString()
            'Next


            ''''-----------------------TOOLTIP------------------------ ''''
            'If e.Row.RowType = DataControlRowType.Header Then

            '    For i As Integer = 0 To tblData1.Columns.Count - 1
            '        e.Row.Cells(i).ToolTip = tblData1.Columns(i).HeaderText
            '    Next
            'End If

            'If e.Row.RowType = DataControlRowType.DataRow Then

            '    For Each gvcell As TableCell In e.Row.Cells
            '        gvcell.ToolTip = gvcell.Text
            '    Next
            'End If




        End If
    End Sub


    'Protected Sub OnDataBound(sender As Object, e As EventArgs)
    '    Dim row As New GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Normal)
    '    Dim cell As New TableHeaderCell()
    '    cell.Text = "Customers"
    '    cell.ColumnSpan = 2
    '    row.Controls.Add(cell)

    '    cell = New TableHeaderCell()
    '    cell.ColumnSpan = 2
    '    cell.Text = "Employees"
    '    row.Controls.Add(cell)

    '    row.BackColor = ColorTranslator.FromHtml("#3AC0F2")
    '    tblData1.HeaderRow.Parent.Controls.AddAt(0, row)
    'End Sub
End Class
