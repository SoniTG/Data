﻿Imports System.Data
Imports System.IO
Imports System.Net
Imports System.Drawing
Imports System.Data.OleDb
Imports OfficeOpenXml
Partial Class Coil_Deviation_CheckBox
    Inherits System.Web.UI.Page
    Dim objController As New Controller_CoilDeviation
    Private _getBase64String As Object

    Private Property GetBase64String(url As String) As Object
        Get
            Return _getBase64String
        End Get
        Set(value As Object)
            _getBase64String = value
        End Set
    End Property



    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        'If Not Page.IsPostBack Then
        '    ' lnkbtn_datetime.Text = Now.AddDays(-7).ToString("dd-MM-yyyy hh:mm:ss tt") & " To " & Now.ToString("dd-MM-yyyy hh:mm:ss tt")
        '    Dim stDate As String = hfFrom.Value
        '    Dim enDate As String = hfTo.Value
        '    'hfFrom.Value = Now.AddDays(-7).ToString("yyyy-MM-dd HH:mm:ss")
        '    'hfTo.Value = Now.ToString("yyyy-MM-dd HH:mm:ss")
        '    Session("pagehit") = New Controller().SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
        '    Dim dtStart As String = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd HH:mm")
        '    Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        '    main(dtStart, dtEnd)
        '    accessible()
        '    'maind1()
        'End If

        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    txtDate_TextChanged()
                End If
            Catch ex As Exception

            End Try

        End If
        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))

                Dim dtStart As String = DateTime.Now.AddDays(-5).ToString("dd-MM-yyyy HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("dd-MM-yyyy HH:mm")

                main(dtStart, dtEnd)
                accessible()

            Catch ex As Exception

            End Try



        End If
    End Sub
    Dim maindt As New DataTable


    Sub main(ByVal startDate As String, ByVal endDate As String)

        'Dim starDate As String = hfFrom.Value
        'Dim enDate As String = hfTo.Value
        Dim ds As DataSet = objController.GetCOILDeviation_checkbox(startDate, endDate)
        Dim dt As DataTable = ds.Tables(0)
        dt.DefaultView.Sort = " START_TIME"



        Dim ds1 As DataSet = objController.GetCOIL_Defect(startDate, endDate)
        Dim dt1 As DataTable = ds1.Tables(0)
        '------------------furnace data-------------------------------
        Dim furnacemaindt As New DataTable
        Dim dsFurnace As DataSet = objController.GetSlab_Furnace(startDate, endDate)
        Dim dtFurnace As DataTable = dsFurnace.Tables(0)
        '================================================================
        furnacemaindt.Columns.Add("stand_id")
        furnacemaindt.Columns.Add("roll_id")
        furnacemaindt.Columns.Add("dia")
        furnacemaindt.Columns.Add("length")
        furnacemaindt.Columns.Add("weight")
        'For i As Integer = 1 To 6
        '    Dim dsRoll As DataSet = objController.oradata(startDate, endDate, i)

        '    Dim dtRoll As DataTable = dsRoll.Tables(0)
        '    For Val As Integer = 0 To dtRoll.Rows.Count - 1
        '        Dim row = furnacemaindt.NewRow
        '        row("stand_id") = dtRoll.Rows(Val)("STAND_ID")
        '        row("roll_id") = dtRoll.Rows(Val)("ROLL_ID")
        '        row("dia") = dtRoll.Rows(Val)("DIA")
        '        row("length") = dtRoll.Rows(Val)("LENGTH")
        '        row("weight") = dtRoll.Rows(Val)("WEIGHT")
        '        furnacemaindt.Rows.Add(row)
        '    Next


        'Next

        '--------------------------------------------------------------------
        '  Dim dtfinal As New DataTable
        ' dt = dt.DefaultView.ToTable
        maindt.Columns.Add("COIL_ID")
        maindt.Columns.Add("START_TIME")
        maindt.Columns.Add("COIL_THICKNESS")
        maindt.Columns.Add("MILL_ENTRY_TEMP")
        ' maindt.Columns.Add("SPEED_BEFORE_F1")
        maindt.Columns.Add("ENTRY_DS_PRESSURE")
        maindt.Columns.Add("EXIT_DS_PRESSURE")
        maindt.Columns.Add("FRT")
        maindt.Columns.Add("F1_ROLL_GAP")
        maindt.Columns.Add("F2_ROLL_GAP")
        maindt.Columns.Add("F3_ROLL_GAP")
        maindt.Columns.Add("F4_ROLL_GAP")
        maindt.Columns.Add("F5_ROLL_GAP")
        maindt.Columns.Add("F6_ROLL_GAP")
        maindt.Columns.Add("QLTY_CODE")
        maindt.Columns.Add("ROLL_FORCE_F1")
        maindt.Columns.Add("ROLL_FORCE_F2")
        maindt.Columns.Add("ROLL_FORCE_F3")
        maindt.Columns.Add("ROLL_FORCE_F4")
        maindt.Columns.Add("ROLL_FORCE_F5")
        maindt.Columns.Add("ROLL_FORCE_F6")
        maindt.Columns.Add("F1_INSTND_COOL")
        maindt.Columns.Add("F2_INSTND_COOL")
        maindt.Columns.Add("F3_INSTND_COOL")
        maindt.Columns.Add("RGL_F2_TOP_OIL_WATER")
        maindt.Columns.Add("RGL_F2_BOT_OIL_WATER")
        maindt.Columns.Add("RGL_F3_TOP_OIL_WATER")
        maindt.Columns.Add("RGL_F3_BOT_OIL_WATER")
        maindt.Columns.Add("RGL_F4_TOP_OIL_WATER")
        maindt.Columns.Add("RGL_F4_BOT_OIL_WATER")
        maindt.Columns.Add("DEFECT_TYPE_MEANING")
        maindt.Columns.Add("SLAB_ID")

        Dim count As Short = 0
        Dim coilid As Short = 0
        Dim mill_entry As String = ""
        Dim start_time As String = ""
        Dim thickness As String = ""
        '  Dim speedBefore As String = ""
        Dim entryDS As String = ""
        Dim exitDS As String = ""
        Dim frt As String = ""
        Dim QtyCode As String = ""
        Dim t As Double = 0.0
        Dim usl As String = "1070"
        Dim lsl As String = "1030"
        Dim r As Double
        '    Dim r1 As Double
        Dim entrypr1 = 187
        Dim entrypr2 = 200
        Dim entrypr3 = 213
        Dim entrypr4 = 225
        Dim entrypr5 = 240
        Dim entrypr6 = 240
        Dim exitpr1 = 210
        Dim exitpr2 = 255
        Dim exitpr3 = 298
        Dim exitpr4 = 315
        Dim exitpr5 = 315
        Dim exitpr6 = 340

        Dim coil_id As String = ""
        Dim slab_id As String = ""


        If dt1.Rows.Count > 0 Then
            'OrElse dtFurnace.Rows.Count > 0
            For i As Short = 0 To dt1.Rows.Count - 1
                'For fur As Short = 0 To dtFurnace.Rows.Count - 1
                coil_id = dt1.Rows.Item(i)("coil_id")
                'slab_id = dt.Rows.Item(i)("slab_id")
                For j = 0 To dt.Rows.Count - 1
                    If dt.Rows.Item(j)("coil_id") = coil_id Then
                        '   AndAlso (dt.Rows.Item(j)("slab_id") = slab_id OrElse IsDBNull(dt.Rows.Item(j)("slab_id"))) Then
                        'Or dt.Rows.Item(j)("slab_id") = slab_id

                        Dim row = maindt.NewRow


                        If IsDBNull(dt.Rows.Item(j)("COIL_ID")) Then
                            row("COIL_ID") = 0
                        Else
                            row("COIL_ID") = dt.Rows.Item(j)("COIL_ID")
                        End If
                        If IsDBNull(dt.Rows.Item(j)("START_TIME")) Then
                            row("START_TIME") = 0
                        Else
                            row("START_TIME") = dt.Rows.Item(j)("START_TIME")
                        End If

                        If IsDBNull(dt.Rows.Item(j)("COIL_THICKNESS")) Then
                            row("COIL_THICKNESS") = 0
                        Else
                            row("COIL_THICKNESS") = dt.Rows.Item(j)("COIL_THICKNESS")
                        End If
                        If IsDBNull(dt.Rows.Item(j)("MILL_ENTRY_TEMP")) Then
                            row("MILL_ENTRY_TEMP") = 0
                        Else
                            row("MILL_ENTRY_TEMP") = dt.Rows.Item(j)("MILL_ENTRY_TEMP")
                        End If

                        '  row("SPEED_BEFORE_F1") = speedBefore
                        If IsDBNull(dt.Rows.Item(j)("ENTRY_DS_PRESSURE")) Then
                            row("ENTRY_DS_PRESSURE") = 0
                        Else
                            row("ENTRY_DS_PRESSURE") = dt.Rows.Item(j)("ENTRY_DS_PRESSURE")
                        End If

                        If IsDBNull(dt.Rows.Item(j)("EXIT_DS_PRESSURE")) Then
                            row("EXIT_DS_PRESSURE") = 0
                        Else
                            row("EXIT_DS_PRESSURE") = dt.Rows.Item(j)("EXIT_DS_PRESSURE")
                        End If

                        ' row("FRT") = FRT

                        If IsDBNull(dt.Rows.Item(j)("FRT")) Then
                            row("FRT") = 0
                        Else
                            row("FRT") = dt.Rows.Item(j)("FRT")
                        End If
                        '=======================================================================================

                        If IsDBNull(dt.Rows.Item(j)("F1_ROLL_GAP")) Then
                            row("F1_ROLL_GAP") = 0
                        Else
                            row("F1_ROLL_GAP") = dt.Rows.Item(j)("F1_ROLL_GAP")
                        End If


                        If IsDBNull(dt.Rows.Item(j)("F2_ROLL_GAP")) Then
                            row("F2_ROLL_GAP") = 0
                        Else
                            row("F2_ROLL_GAP") = dt.Rows.Item(j)("F2_ROLL_GAP")
                        End If


                        If IsDBNull(dt.Rows.Item(j)("F3_ROLL_GAP")) Then
                            row("F3_ROLL_GAP") = 0
                        Else
                            row("F3_ROLL_GAP") = dt.Rows.Item(j)("F3_ROLL_GAP")
                        End If

                        If IsDBNull(dt.Rows.Item(j)("F4_ROLL_GAP")) Then
                            row("F4_ROLL_GAP") = 0
                        Else
                            row("F4_ROLL_GAP") = dt.Rows.Item(j)("F4_ROLL_GAP")
                        End If

                        If IsDBNull(dt.Rows.Item(j)("F5_ROLL_GAP")) Then
                            row("F5_ROLL_GAP") = 0
                        Else
                            row("F5_ROLL_GAP") = dt.Rows.Item(j)("F5_ROLL_GAP")
                        End If


                        If IsDBNull(dt.Rows.Item(j)("F6_ROLL_GAP")) Then
                            row("F6_ROLL_GAP") = 0
                        Else
                            row("F6_ROLL_GAP") = dt.Rows.Item(j)("F6_ROLL_GAP")
                        End If
                        '--------------------------------------------------------------------------------------------------------------
                        If IsDBNull(dt.Rows.Item(j)("QLTY_CODE")) Then
                            row("QLTY_CODE") = 0
                        Else
                            row("QLTY_CODE") = dt.Rows.Item(j)("QLTY_CODE")
                        End If
                        '================================================================================================================
                        If IsDBNull(dt.Rows.Item(j)("ROLL_FORCE_F1")) Then
                            row("ROLL_FORCE_F1") = 0
                        Else
                            row("ROLL_FORCE_F1") = dt.Rows.Item(j)("ROLL_FORCE_F1")
                        End If
                        If IsDBNull(dt.Rows.Item(j)("ROLL_FORCE_F2")) Then
                            row("ROLL_FORCE_F2") = 0
                        Else
                            row("ROLL_FORCE_F2") = dt.Rows.Item(j)("ROLL_FORCE_F2")
                        End If
                        If IsDBNull(dt.Rows.Item(j)("ROLL_FORCE_F3")) Then
                            row("ROLL_FORCE_F3") = 0
                        Else
                            row("ROLL_FORCE_F3") = dt.Rows.Item(j)("ROLL_FORCE_F3")
                        End If
                        If IsDBNull(dt.Rows.Item(j)("ROLL_FORCE_F4")) Then
                            row("ROLL_FORCE_F4") = 0
                        Else
                            row("ROLL_FORCE_F4") = dt.Rows.Item(j)("ROLL_FORCE_F4")
                        End If
                        If IsDBNull(dt.Rows.Item(j)("ROLL_FORCE_F5")) Then
                            row("ROLL_FORCE_F5") = 0
                        Else
                            row("ROLL_FORCE_F5") = dt.Rows.Item(j)("ROLL_FORCE_F5")
                        End If
                        If IsDBNull(dt.Rows.Item(j)("ROLL_FORCE_F6")) Then
                            row("ROLL_FORCE_F6") = 0
                        Else
                            row("ROLL_FORCE_F6") = dt.Rows.Item(j)("ROLL_FORCE_F6")
                        End If
                        '=================
                        If IsDBNull(dt.Rows.Item(j)("F1_INSTND_COOL")) Then
                            row("F1_INSTND_COOL") = 0
                        Else
                            row("F1_INSTND_COOL") = dt.Rows.Item(j)("F1_INSTND_COOL")
                        End If

                        If IsDBNull(dt.Rows.Item(j)("F2_INSTND_COOL")) Then
                            row("F2_INSTND_COOL") = 0
                        Else
                            row("F2_INSTND_COOL") = dt.Rows.Item(j)("F2_INSTND_COOL")
                        End If

                        If IsDBNull(dt.Rows.Item(j)("F3_INSTND_COOL")) Then
                            row("F3_INSTND_COOL") = 0
                        Else
                            row("F3_INSTND_COOL") = dt.Rows.Item(j)("F3_INSTND_COOL")
                        End If
                        '===============================================
                        If IsDBNull(dt.Rows.Item(j)("RGL_F2_TOP_OIL_WATER")) Then
                            row("RGL_F2_TOP_OIL_WATER") = 0
                        Else
                            row("RGL_F2_TOP_OIL_WATER") = dt.Rows.Item(j)("RGL_F2_TOP_OIL_WATER")
                        End If
                        If IsDBNull(dt.Rows.Item(j)("RGL_F2_BOT_OIL_WATER")) Then
                            row("RGL_F2_BOT_OIL_WATER") = 0
                        Else
                            row("RGL_F2_BOT_OIL_WATER") = dt.Rows.Item(j)("RGL_F2_BOT_OIL_WATER")
                        End If
                        If IsDBNull(dt.Rows.Item(j)("RGL_F3_TOP_OIL_WATER")) Then
                            row("RGL_F3_TOP_OIL_WATER") = 0
                        Else
                            row("RGL_F3_TOP_OIL_WATER") = dt.Rows.Item(j)("RGL_F3_TOP_OIL_WATER")
                        End If
                        If IsDBNull(dt.Rows.Item(j)("RGL_F3_BOT_OIL_WATER")) Then
                            row("RGL_F3_BOT_OIL_WATER") = 0
                        Else
                            row("RGL_F3_BOT_OIL_WATER") = dt.Rows.Item(j)("RGL_F3_BOT_OIL_WATER")
                        End If


                        If IsDBNull(dt.Rows.Item(j)("RGL_F4_TOP_OIL_WATER")) Then
                            row("RGL_F4_TOP_OIL_WATER") = 0
                        Else
                            row("RGL_F4_TOP_OIL_WATER") = dt.Rows.Item(j)("RGL_F4_TOP_OIL_WATER")
                        End If

                        If IsDBNull(dt.Rows.Item(j)("RGL_F4_BOT_OIL_WATER")) Then
                            row("RGL_F4_BOT_OIL_WATER") = 0
                        Else
                            row("RGL_F4_BOT_OIL_WATER") = dt.Rows.Item(j)("RGL_F4_BOT_OIL_WATER")
                        End If
                        If IsDBNull(dt1.Rows.Item(i)("DEFECT_TYPE_MEANING")) Then
                            row("DEFECT_TYPE_MEANING") = 0
                        Else
                            row("DEFECT_TYPE_MEANING") = dt1.Rows.Item(i)("DEFECT_TYPE_MEANING")
                        End If

                        If IsDBNull(dt.Rows(j)("SLAB_ID")) Then
                            row("SLAB_ID") = ""
                        Else
                            row("SLAB_ID") = dt.Rows(j)("SLAB_ID")
                        End If
                        '===========================================
                        maindt.Rows.Add(row)


                        'dtfinal.Rows.Add(newRowdefect)
                    End If
                Next
            Next
            ' Next
        End If

        Dim SheetName As String = ""
        Dim filepath As String = AppDomain.CurrentDomain.BaseDirectory & "FRT_Spec.xlsx"
        'ViewState("exfname") = exfname
        'ViewState("filename") = FileUpload1.FileName
        Dim package As New ExcelPackage(New FileInfo(filepath))
        Dim workbook As ExcelWorkbook = package.Workbook
        Dim sheet As ExcelWorksheet = workbook.Worksheets(1)

        Dim dtExcel As New DataTable
        Dim c As Integer = 1
        Dim x As Short = 1

        While Not sheet.Cells(1, c).Value Is Nothing
            Dim colName As String = ""

            dtExcel.Columns.Add(sheet.Cells(1, c).Value)
            c = c + 1

        End While

        'dtExcel.Rows.Add()
        Dim rRR As Integer = 2
        While Not sheet.Cells(rRR, 1).Value Is Nothing
            dtExcel.Rows.Add()
            For i As Integer = 1 To c - 1
                Dim value As String = ""
                Try
                    value = sheet.Cells(rRR, i).Text
                    'value = sheet.Cells(r, i).Value
                Catch ex As Exception
                End Try
                dtExcel.Rows(rRR - 2)(i - 1) = value
            Next
            rRR = rRR + 1
        End While
        Dim dtmainfinal As New DataTable
        Dim Qlty As String = ""
        'Dim Qltymaindt As String = ""
        Dim maincount As Integer = 0
        dtmainfinal.Columns.Add("COIL_ID")
        dtmainfinal.Columns.Add("START_TIME")
        dtmainfinal.Columns.Add("COIL_THICKNESS")
        dtmainfinal.Columns.Add("MILL_ENTRY_TEMP")
        ' maindt.Columns.Add("SPEED_BEFORE_F1")
        dtmainfinal.Columns.Add("ENTRY_DS_PRESSURE")
        dtmainfinal.Columns.Add("EXIT_DS_PRESSURE")
        dtmainfinal.Columns.Add("FRT")
        dtmainfinal.Columns.Add("F1_ROLL_GAP")
        dtmainfinal.Columns.Add("F2_ROLL_GAP")
        dtmainfinal.Columns.Add("F3_ROLL_GAP")
        dtmainfinal.Columns.Add("F4_ROLL_GAP")
        dtmainfinal.Columns.Add("F5_ROLL_GAP")
        dtmainfinal.Columns.Add("F6_ROLL_GAP")
        dtmainfinal.Columns.Add("QLTY_CODE")
        dtmainfinal.Columns.Add("frtcheck")
        dtmainfinal.Columns.Add("ROLL_FORCE_F1")
        dtmainfinal.Columns.Add("ROLL_FORCE_F2")
        dtmainfinal.Columns.Add("ROLL_FORCE_F3")
        dtmainfinal.Columns.Add("ROLL_FORCE_F4")
        dtmainfinal.Columns.Add("ROLL_FORCE_F5")
        dtmainfinal.Columns.Add("ROLL_FORCE_F6")
        dtmainfinal.Columns.Add("F1_INSTND_COOL")
        dtmainfinal.Columns.Add("F2_INSTND_COOL")
        dtmainfinal.Columns.Add("F3_INSTND_COOL")
        dtmainfinal.Columns.Add("RGL_F2_TOP_OIL_WATER")
        dtmainfinal.Columns.Add("RGL_F2_BOT_OIL_WATER")
        dtmainfinal.Columns.Add("RGL_F3_TOP_OIL_WATER")
        dtmainfinal.Columns.Add("RGL_F3_BOT_OIL_WATER")
        dtmainfinal.Columns.Add("RGL_F4_TOP_OIL_WATER")
        dtmainfinal.Columns.Add("RGL_F4_BOT_OIL_WATER")
        dtmainfinal.Columns.Add("DEFECT_TYPE_MEANING")
        dtmainfinal.Columns.Add("SLAB_ID")

        If dtExcel.Rows.Count > 0 Then
            For i As Short = 0 To dtExcel.Rows.Count - 1
                Qlty = dtExcel.Rows.Item(i)("Q.CODE")
                'Qltymaindt = maindt.Rows.Item(i)("QLTY_CODE")
                ' If dtExcel.Rows.Item(i)("THK-MIN") = "1.6" Then
                For count1 As Short = 0 To maindt.Rows.Count - 1
                    If maindt.Rows.Item(count1)("QLTY_CODE") = Qlty Then ' Or maindt.Rows.Item(count1)("QLTY_CODE") = Qltymaindt Then
                        If Math.Abs(dtExcel.Rows.Item(i)("FRT") - maindt.Rows.Item(count1)("FRT")) <= 25 Then
                            'dtmainfinal.Rows.Add = maindt.Rows

                            Dim newRow As DataRow = dtmainfinal.NewRow()
                            newRow("COIL_ID") = maindt.Rows(count1)("COIL_ID").ToString
                            newRow("START_TIME") = maindt.Rows(count1)("START_TIME").ToString
                            newRow("COIL_THICKNESS") = maindt.Rows(count1)("COIL_THICKNESS").ToString '
                            newRow("MILL_ENTRY_TEMP") = maindt.Rows(count1)("MILL_ENTRY_TEMP").ToString
                            newRow("ENTRY_DS_PRESSURE") = maindt.Rows(count1)("ENTRY_DS_PRESSURE").ToString
                            newRow("EXIT_DS_PRESSURE") = maindt.Rows(count1)("EXIT_DS_PRESSURE").ToString
                            newRow("FRT") = maindt.Rows(count1)("FRT").ToString
                            newRow("F1_ROLL_GAP") = maindt.Rows(count1)("F1_ROLL_GAP").ToString
                            newRow("F2_ROLL_GAP") = maindt.Rows(count1)("F2_ROLL_GAP").ToString
                            newRow("F3_ROLL_GAP") = maindt.Rows(count1)("F3_ROLL_GAP").ToString
                            newRow("F4_ROLL_GAP") = maindt.Rows(count1)("F4_ROLL_GAP").ToString
                            newRow("F5_ROLL_GAP") = maindt.Rows(count1)("F5_ROLL_GAP").ToString
                            newRow("F6_ROLL_GAP") = maindt.Rows(count1)("F6_ROLL_GAP").ToString
                            newRow("QLTY_CODE") = maindt.Rows(count1)("QLTY_CODE").ToString
                            newRow("frtcheck") = "0"
                            newRow("ROLL_FORCE_F1") = maindt.Rows(count1)("ROLL_FORCE_F1").ToString
                            newRow("ROLL_FORCE_F2") = maindt.Rows(count1)("ROLL_FORCE_F2").ToString
                            newRow("ROLL_FORCE_F3") = maindt.Rows(count1)("ROLL_FORCE_F3").ToString
                            newRow("ROLL_FORCE_F4") = maindt.Rows(count1)("ROLL_FORCE_F4").ToString
                            newRow("ROLL_FORCE_F5") = maindt.Rows(count1)("ROLL_FORCE_F5").ToString
                            newRow("ROLL_FORCE_F6") = maindt.Rows(count1)("ROLL_FORCE_F6").ToString
                            newRow("F1_INSTND_COOL") = maindt.Rows(count1)("F1_INSTND_COOL").ToString
                            newRow("F2_INSTND_COOL") = maindt.Rows(count1)("F2_INSTND_COOL").ToString
                            newRow("F3_INSTND_COOL") = maindt.Rows(count1)("F3_INSTND_COOL").ToString
                            newRow("RGL_F2_TOP_OIL_WATER") = maindt.Rows(count1)("RGL_F2_TOP_OIL_WATER").ToString
                            newRow("RGL_F2_BOT_OIL_WATER") = maindt.Rows(count1)("RGL_F2_BOT_OIL_WATER").ToString
                            newRow("RGL_F3_TOP_OIL_WATER") = maindt.Rows(count1)("RGL_F3_TOP_OIL_WATER").ToString
                            newRow("RGL_F3_BOT_OIL_WATER") = maindt.Rows(count1)("RGL_F3_BOT_OIL_WATER").ToString
                            newRow("RGL_F4_TOP_OIL_WATER") = maindt.Rows(count1)("RGL_F4_TOP_OIL_WATER").ToString
                            newRow("RGL_F4_BOT_OIL_WATER") = maindt.Rows(count1)("RGL_F4_BOT_OIL_WATER").ToString
                            newRow("DEFECT_TYPE_MEANING") = maindt.Rows(count1)("DEFECT_TYPE_MEANING").ToString
                            newRow("SLAB_ID") = maindt.Rows(count1)("SLAB_ID").ToString
                            dtmainfinal.Rows.Add(newRow)
                            'maincount = maincount + 1
                            ' dtmainfinal.DefaultView.Sort = "START_TIME desc"
                            'frt1 = 0  'green  frt1 = 1

                        Else
                            'frt1 = 1 'red 

                            Dim newRow As DataRow = dtmainfinal.NewRow()
                            newRow("COIL_ID") = maindt.Rows(count1)("COIL_ID").ToString
                            newRow("START_TIME") = maindt.Rows(count1)("START_TIME").ToString
                            newRow("COIL_THICKNESS") = maindt.Rows(count1)("COIL_THICKNESS").ToString
                            newRow("MILL_ENTRY_TEMP") = maindt.Rows(count1)("MILL_ENTRY_TEMP").ToString
                            newRow("ENTRY_DS_PRESSURE") = maindt.Rows(count1)("ENTRY_DS_PRESSURE").ToString
                            newRow("EXIT_DS_PRESSURE") = maindt.Rows(count1)("EXIT_DS_PRESSURE").ToString
                            newRow("FRT") = maindt.Rows(count1)("FRT").ToString
                            newRow("F1_ROLL_GAP") = maindt.Rows(count1)("F1_ROLL_GAP").ToString
                            newRow("F2_ROLL_GAP") = maindt.Rows(count1)("F2_ROLL_GAP").ToString
                            newRow("F3_ROLL_GAP") = maindt.Rows(count1)("F3_ROLL_GAP").ToString
                            newRow("F4_ROLL_GAP") = maindt.Rows(count1)("F4_ROLL_GAP").ToString
                            newRow("F5_ROLL_GAP") = maindt.Rows(count1)("F5_ROLL_GAP").ToString
                            newRow("F6_ROLL_GAP") = maindt.Rows(count1)("F6_ROLL_GAP").ToString
                            newRow("QLTY_CODE") = maindt.Rows(count1)("QLTY_CODE").ToString
                            newRow("frtcheck") = "1"
                            newRow("ROLL_FORCE_F1") = maindt.Rows(count1)("ROLL_FORCE_F1").ToString
                            newRow("ROLL_FORCE_F2") = maindt.Rows(count1)("ROLL_FORCE_F2").ToString
                            newRow("ROLL_FORCE_F3") = maindt.Rows(count1)("ROLL_FORCE_F3").ToString
                            newRow("ROLL_FORCE_F4") = maindt.Rows(count1)("ROLL_FORCE_F4").ToString
                            newRow("ROLL_FORCE_F5") = maindt.Rows(count1)("ROLL_FORCE_F5").ToString
                            newRow("ROLL_FORCE_F6") = maindt.Rows(count1)("ROLL_FORCE_F6").ToString
                            newRow("F1_INSTND_COOL") = maindt.Rows(count1)("F1_INSTND_COOL").ToString
                            newRow("F2_INSTND_COOL") = maindt.Rows(count1)("F2_INSTND_COOL").ToString
                            newRow("F3_INSTND_COOL") = maindt.Rows(count1)("F3_INSTND_COOL").ToString
                            newRow("RGL_F2_TOP_OIL_WATER") = maindt.Rows(count1)("RGL_F2_TOP_OIL_WATER").ToString
                            newRow("RGL_F2_BOT_OIL_WATER") = maindt.Rows(count1)("RGL_F2_BOT_OIL_WATER").ToString
                            newRow("RGL_F3_TOP_OIL_WATER") = maindt.Rows(count1)("RGL_F3_TOP_OIL_WATER").ToString
                            newRow("RGL_F3_BOT_OIL_WATER") = maindt.Rows(count1)("RGL_F3_BOT_OIL_WATER").ToString
                            newRow("RGL_F4_TOP_OIL_WATER") = maindt.Rows(count1)("RGL_F4_TOP_OIL_WATER").ToString
                            newRow("RGL_F4_BOT_OIL_WATER") = maindt.Rows(count1)("RGL_F4_BOT_OIL_WATER").ToString
                            newRow("SLAB_ID") = maindt.Rows(count1)("SLAB_ID")
                            dtmainfinal.Rows.Add(newRow)
                            ' maincount = maincount + 1
                            'dtmainfinal.DefaultView.Sort = "START_TIME desc"
                        End If

                    End If

                Next
                'Else


                'End If

            Next
            For Val As Integer = 0 To maindt.Rows.Count - 1
                If maindt.Rows.Item(Val)("QLTY_CODE") = "0" Then

                    Dim newRow As DataRow = dtmainfinal.NewRow()
                    newRow("COIL_ID") = maindt.Rows(Val)("COIL_ID").ToString
                    newRow("START_TIME") = maindt.Rows(Val)("START_TIME").ToString
                    newRow("COIL_THICKNESS") = maindt.Rows(Val)("COIL_THICKNESS").ToString
                    newRow("MILL_ENTRY_TEMP") = maindt.Rows(Val)("MILL_ENTRY_TEMP").ToString
                    newRow("ENTRY_DS_PRESSURE") = maindt.Rows(Val)("ENTRY_DS_PRESSURE").ToString
                    newRow("EXIT_DS_PRESSURE") = maindt.Rows(Val)("EXIT_DS_PRESSURE").ToString
                    newRow("FRT") = maindt.Rows(Val)("FRT").ToString
                    newRow("F1_ROLL_GAP") = maindt.Rows(Val)("F1_ROLL_GAP").ToString
                    newRow("F2_ROLL_GAP") = maindt.Rows(Val)("F2_ROLL_GAP").ToString
                    newRow("F3_ROLL_GAP") = maindt.Rows(Val)("F3_ROLL_GAP").ToString
                    newRow("F4_ROLL_GAP") = maindt.Rows(Val)("F4_ROLL_GAP").ToString
                    newRow("F5_ROLL_GAP") = maindt.Rows(Val)("F5_ROLL_GAP").ToString
                    newRow("F6_ROLL_GAP") = maindt.Rows(Val)("F6_ROLL_GAP").ToString
                    newRow("QLTY_CODE") = maindt.Rows(Val)("QLTY_CODE").ToString
                    newRow("frtcheck") = ""
                    newRow("ROLL_FORCE_F1") = maindt.Rows(Val)("ROLL_FORCE_F1").ToString
                    newRow("ROLL_FORCE_F2") = maindt.Rows(Val)("ROLL_FORCE_F2").ToString
                    newRow("ROLL_FORCE_F3") = maindt.Rows(Val)("ROLL_FORCE_F3").ToString
                    newRow("ROLL_FORCE_F4") = maindt.Rows(Val)("ROLL_FORCE_F4").ToString
                    newRow("ROLL_FORCE_F5") = maindt.Rows(Val)("ROLL_FORCE_F5").ToString
                    newRow("ROLL_FORCE_F6") = maindt.Rows(Val)("ROLL_FORCE_F6").ToString
                    newRow("F1_INSTND_COOL") = maindt.Rows(Val)("F1_INSTND_COOL").ToString
                    newRow("F2_INSTND_COOL") = maindt.Rows(Val)("F2_INSTND_COOL").ToString
                    newRow("F3_INSTND_COOL") = maindt.Rows(Val)("F3_INSTND_COOL").ToString
                    newRow("RGL_F2_TOP_OIL_WATER") = maindt.Rows(Val)("RGL_F2_TOP_OIL_WATER").ToString
                    newRow("RGL_F2_BOT_OIL_WATER") = maindt.Rows(Val)("RGL_F2_BOT_OIL_WATER").ToString
                    newRow("RGL_F3_TOP_OIL_WATER") = maindt.Rows(Val)("RGL_F3_TOP_OIL_WATER").ToString
                    newRow("RGL_F3_BOT_OIL_WATER") = maindt.Rows(Val)("RGL_F3_BOT_OIL_WATER").ToString
                    newRow("RGL_F4_TOP_OIL_WATER") = maindt.Rows(Val)("RGL_F4_TOP_OIL_WATER").ToString
                    newRow("RGL_F4_BOT_OIL_WATER") = maindt.Rows(Val)("RGL_F4_BOT_OIL_WATER").ToString
                    newRow("DEFECT_TYPE_MEANING") = maindt.Rows(Val)("DEFECT_TYPE_MEANING").ToString
                    newRow("SLAB_ID") = maindt.Rows(Val)("SLAB_ID")
                    dtmainfinal.Rows.Add(newRow)
                End If

            Next
        End If
        dtmainfinal.DefaultView.Sort = "START_TIME desc"
        Dim sum As Double = 0.0
        For column As Integer = 7 To dtmainfinal.Columns.Count - 1
            For splitcol As Integer = 0 To dtmainfinal.Rows.Count - 1
                '  Dim f1val As String
                '   f1val = dtmainfinal.Rows()("F1_ROLL_GAP")
                Dim f1val As String = dtmainfinal.Rows.Item(splitcol)(column).ToString
                Dim f1split() As String = f1val.Split(",")
                If f1split.Length > 1 Then
                    sum = (CDbl(f1split(0).ToString()) + CDbl(f1split(1).ToString())) / 2
                    dtmainfinal.Rows(splitcol)(column) = sum
                Else
                    'dtmainfinal.Rows(splitcol)(column) = sum
                    Continue For
                End If

                'Dim a(f1val.Length) As String

                'For i As Integer = 0 To f1val.Length - 1
                '    a(i) = f1val.Substring(i, 1)
                'Next i
            Next
            Continue For
        Next

        dtmainfinal.DefaultView.Sort = "START_TIME desc"
        'Dim Furnacetbl As New DataTable
        ''------------------furnace data-------------------------------
        'Dim dsFurnace As DataSet = objController.GetSlab_Furnace(startDate, endDate)
        'Dim dtFurnace As DataTable = dsFurnace.Tables(0)
        ''--------------------------------------------------------------------


        'Furnacetbl.Columns.Add("SLAB_ID")
        'Furnacetbl.Columns.Add("FURNACE_NUM")
        'Furnacetbl.Columns.Add("SLAB_CHARGE_TIME")
        'Furnacetbl.Columns.Add("SLAB_DISCHARGE_TIME")
        'Furnacetbl.Columns.Add("SLAB_DURATION")
        'Furnacetbl.Columns.Add("SLAB_ENTRY_HEAD")
        'Furnacetbl.Columns.Add("SLAB_ENTRY_MID")
        'Furnacetbl.Columns.Add("SLAB_ENTRY_TAIL")
        'Furnacetbl.Columns.Add("SLAB_EXIT_HEAD")
        'Furnacetbl.Columns.Add("SLAB_EXIT_MID")
        'Furnacetbl.Columns.Add("SLAB_EXIT_TAIL")
        'Furnacetbl.Columns.Add("SLAB_PYRO_HEAD")
        'Furnacetbl.Columns.Add("SLAB_PYRO_MID")
        'Furnacetbl.Columns.Add("SLAB_PYRO_TAIL")


        'Dim slab_id As String = ""
        '' Dim slab_id As String = ""
        'If dtFurnace.Rows.Count > 0 Then
        '    'OrElse dtFurnace.Rows.Count > 0
        '    For i As Short = 0 To dtFurnace.Rows.Count - 1
        '        'For fur As Short = 0 To dtFurnace.Rows.Count - 1

        '        slab_id = dtFurnace.Rows.Item(i)("slab_id")
        '        For j = 0 To dt.Rows.Count - 1
        '            If dt.Rows.Item(j)("slab_id") = slab_id Then
        '                'Or dt.Rows.Item(j)("slab_id") = slab_id

        '                Dim row = dtFurnace.NewRow

        '            End If
        '        Next
        '    Next
        'End If






        Dim distinctTable As DataTable = dtmainfinal.DefaultView.ToTable(True)

        'joining distinct table and dtFurnace
        Dim dstemp As New DataSet
        dsFurnace.Tables.Add(distinctTable)
        'dstemp.Tables.Add(dtFurnace)

        dsFurnace.Relations.Add("onSlabID", dtFurnace.Columns("SLAB_ID"), distinctTable.Columns("SLAB_ID"), False)
        distinctTable.Columns.Add("FURNACE_NUM", GetType(String), "Parent.FURNACE_NUM")
        distinctTable.Columns.Add("SLAB_CHARGE_TIME", GetType(String), "Parent.SLAB_CHARGE_TIME")
        distinctTable.Columns.Add("SLAB_DISCHARGE_TIME", GetType(String), "Parent.SLAB_DISCHARGE_TIME")
        distinctTable.Columns.Add("SLAB_DURATION", GetType(String), "Parent.SLAB_DURATION")
        distinctTable.Columns.Add("SLAB_ENTRY_HEAD", GetType(String), "Parent.SLAB_ENTRY_HEAD")
        distinctTable.Columns.Add("SLAB_ENTRY_MID", GetType(String), "Parent.SLAB_ENTRY_MID")
        distinctTable.Columns.Add("SLAB_ENTRY_TAIL", GetType(String), "Parent.SLAB_ENTRY_TAIL")
        distinctTable.Columns.Add("SLAB_EXIT_HEAD", GetType(String), "Parent.SLAB_EXIT_HEAD")
        distinctTable.Columns.Add("SLAB_EXIT_MID", GetType(String), "Parent.SLAB_EXIT_MID")
        distinctTable.Columns.Add("SLAB_EXIT_TAIL", GetType(String), "Parent.SLAB_EXIT_TAIL")
        distinctTable.Columns.Add("SLAB_PYRO_HEAD", GetType(String), "Parent.SLAB_PYRO_HEAD")
        distinctTable.Columns.Add("SLAB_PYRO_MID", GetType(String), "Parent.SLAB_PYRO_MID")
        distinctTable.Columns.Add("SLAB_PYRO_TAIL", GetType(String), "Parent.SLAB_PYRO_TAIL")

        For i As Integer = 1 To 6
            ' Dim dsRoll As DataSet = objController.oradata(startDate, endDate, i)

            Dim dtRoll As DataTable = objController.oradataBackupRollTop(startDate, endDate, i)
            Dim dttemp As DataTable = dtRoll.DefaultView.ToTable("T" & i)
            dsFurnace.Tables.Add(dttemp)
            dsFurnace.Relations.Add("onSlabID" & i, dttemp.Columns("SLAB_ID"), distinctTable.Columns("SLAB_ID"), False)
            distinctTable.Columns.Add("ROLL_ID" & i, GetType(String), "Parent(onSlabID" & i & ").roll_id")
            distinctTable.Columns.Add("DIA" & i, GetType(String), "Parent(onSlabID" & i & ").DIA")
            distinctTable.Columns.Add("LENGTH" & i, GetType(String), "Parent(onSlabID" & i & ").LENGTH")
            distinctTable.Columns.Add("WEIGHT" & i, GetType(String), "Parent(onSlabID" & i & ").WEIGHT")
            dsFurnace.Relations.Remove("onSlabID" & i)
            dsFurnace.Tables.Remove("T" & i)
        Next
        For k As Integer = 1 To 6
            ' Dim dsRoll As DataSet = objController.oradata(startDate, endDate, i)

            Dim dtRoll As DataTable = objController.oradataBackupRollBottom(startDate, endDate, k)
            Dim dttemp As DataTable = dtRoll.DefaultView.ToTable("T" & k)
            dsFurnace.Tables.Add(dttemp)
            dsFurnace.Relations.Add("onSlabID" & k, dttemp.Columns("SLAB_ID"), distinctTable.Columns("SLAB_ID"), False)
            distinctTable.Columns.Add("ROLL_IDB" & k, GetType(String), "Parent(onSlabID" & k & ").roll_id")
            distinctTable.Columns.Add("DIAB" & k, GetType(String), "Parent(onSlabID" & k & ").DIA")
            distinctTable.Columns.Add("LENGTHB" & k, GetType(String), "Parent(onSlabID" & k & ").LENGTH")
            distinctTable.Columns.Add("WEIGHTB" & k, GetType(String), "Parent(onSlabID" & k & ").WEIGHT")
            dsFurnace.Relations.Remove("onSlabID" & k)
            dsFurnace.Tables.Remove("T" & k)
        Next
        For wt As Integer = 1 To 6
            ' Dim dsRoll As DataSet = objController.oradata(startDate, endDate, i)

            Dim dtRoll As DataTable = objController.oradataWorkRollTop(startDate, endDate, wt)
            Dim dttemp As DataTable = dtRoll.DefaultView.ToTable("T" & wt)
            dsFurnace.Tables.Add(dttemp)
            dsFurnace.Relations.Add("onSlabID" & wt, dttemp.Columns("SLAB_ID"), distinctTable.Columns("SLAB_ID"), False)
            distinctTable.Columns.Add("ROLL_ID_WT" & wt, GetType(String), "Parent(onSlabID" & wt & ").roll_id")
            distinctTable.Columns.Add("DIA_WT" & wt, GetType(String), "Parent(onSlabID" & wt & ").DIA")
            distinctTable.Columns.Add("LENGTH_WT" & wt, GetType(String), "Parent(onSlabID" & wt & ").LENGTH")
            distinctTable.Columns.Add("WEIGHT_WT" & wt, GetType(String), "Parent(onSlabID" & wt & ").WEIGHT")
            dsFurnace.Relations.Remove("onSlabID" & wt)
            dsFurnace.Tables.Remove("T" & wt)
        Next
        For wb As Integer = 1 To 6
            ' Dim dsRoll As DataSet = objController.oradata(startDate, endDate, i)

            Dim dtRoll As DataTable = objController.oradataWorkRollBottom(startDate, endDate, wb)
            Dim dttemp As DataTable = dtRoll.DefaultView.ToTable("T" & wb)
            dsFurnace.Tables.Add(dttemp)
            dsFurnace.Relations.Add("onSlabID" & wb, dttemp.Columns("SLAB_ID"), distinctTable.Columns("SLAB_ID"), False)
            distinctTable.Columns.Add("ROLL_ID_WB" & wb, GetType(String), "Parent(onSlabID" & wb & ").roll_id")
            distinctTable.Columns.Add("DIA_WB" & wb, GetType(String), "Parent(onSlabID" & wb & ").DIA")
            distinctTable.Columns.Add("LENGTH_WB" & wb, GetType(String), "Parent(onSlabID" & wb & ").LENGTH")
            distinctTable.Columns.Add("WEIGHT_WB" & wb, GetType(String), "Parent(onSlabID" & wb & ").WEIGHT")
            dsFurnace.Relations.Remove("onSlabID" & wb)
            dsFurnace.Tables.Remove("T" & wb)
        Next

       
        'Try


        '    For val As Integer = 0 To distinctTable.Rows.Count - 1
        '        Dim row As DataRow = distinctTable.Rows(val)
        '        count = 0
        '        For COU As Integer = 44 To distinctTable.Columns.Count - 1
        '            If row.Item(COU) Is Nothing Then
        '                count = count + 1
        '            ElseIf row.Item(COU).ToString = "" Then
        '                count = count + 1
        '            End If
        '        Next
        '        If count > 95 Then
        '            distinctTable.Rows.Remove(row)
        '        End If
        '        distinctTable.AcceptChanges()
        '    Next

        'Catch ex As Exception


        'End Try

        'To delete empty  and unwanted rows

        Try
            For i As Integer = distinctTable.Rows.Count - 1 To 0 Step -1
                Dim str As String = ""
                For j As Integer = 45 To distinctTable.Columns.Count - 1
                    str &= distinctTable.Rows(i)(j)
                Next
                Dim row As DataRow = distinctTable.Rows(i)
                If str Is Nothing Then
                    distinctTable.Rows.Remove(row)
                ElseIf str = "" Then
                    distinctTable.Rows.Remove(row)
                End If
            Next
            distinctTable.AcceptChanges()
        Catch ex As Exception
            Throw ex
        End Try





        tblData1.DataSource = distinctTable

        '  tblData1.DataSource = dtmainfinal
        tblData1.DataBind()
        If dtmainfinal.Rows.Count > 0 Then
            'tblData1.UseAccessibleHeader = True
            'tblData1.HeaderRow.TableSection = TableRowSection.TableHeader
        End If
        If tblData1.Rows.Count > 0 Then
            'tblData1.UseAccessibleHeader = True
            'tblData1.HeaderRow.TableSection = TableRowSection.TableHeader
            'tblData1.FooterRow.TableSection = TableRowSection.TableFooter
        End If
        dt.Clear()
        maindt.Clear()
        dtmainfinal.Clear()
    End Sub




    Protected Sub tblData1_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles tblData1.RowCreated
        'If e.Row.RowType = DataControlRowType.Header Then
        '    Dim row As New GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Insert)
        '    Dim cell As New TableHeaderCell()
        '    cell.Text = "Customers"
        '    cell.CssClass = "gridfreeze"
        '    cell.HorizontalAlign = HorizontalAlign.Center
        '    cell.ColumnSpan = e.Row.Cells.Count
        '    row.Controls.Add(cell)
        '    row.CssClass = "gfreeze"
        '    row.BackColor = ColorTranslator.FromHtml("#3AC0F2")
        '    tblData1.Controls(0).Controls.AddAt(0, row)
        'End If





        If e.Row.RowType = DataControlRowType.Header Then
            Dim header As GridView = CType(sender, GridView)
            Dim gvr As New GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Normal)
            Dim gvr1 As New GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Normal)
            Dim gvr2 As New GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Normal)
            Dim tCell As New TableCell
            'tCell.Text = "Names"
            'tCell.ColumnSpan = 1
            'tCell.RowSpan = 2
            'tCell.HorizontalAlign = HorizontalAlign.Center
            ''tCell.BackColor = Drawing.Color.Black
            'tCell.CssClass = "gfreeze"
            'gvr.Cells.Add(tCell)
            tCell = New TableCell
            tCell.Text = "TSCR MILL AREA "
            tCell.ColumnSpan = 28
            ' tc.Attributes("style") = "border-color: #000000"
            'tCell.Attributes("style") = "border-right:1px solid #CC9966"
            tCell.Style.Add("border-right-color", "black")
            tCell.Style.Add("box-shadow", "inset -1px -2px black")
            tCell.Style.Add("vertical-align", "middle")
            tCell.RowSpan = 3
            tCell.Font.Size = 15
            tCell.HorizontalAlign = HorizontalAlign.Center
            tCell.VerticalAlign = VerticalAlign.Middle
            ' tCell.BackColor = Drawing.Color.
            tCell.CssClass = "gfreeze"
            tCell.CssClass = "headerboder"
            '  tCell.CssClass = "headerboder"
            tCell.BackColor = ColorTranslator.FromHtml("#BFE297") '3AC0F2
            gvr.Cells.Add(tCell)



            tCell = New TableCell
            tCell.Text = "FURNACE"
            tCell.ColumnSpan = 15
            tCell.RowSpan = 3
            tCell.Font.Size = 15
            tCell.Style.Add("border-right-color", "black")
            tCell.Style.Add("box-shadow", "inset -1px -2px black")
            tCell.Style.Add("vertical-align", "middle")
            tCell.HorizontalAlign = HorizontalAlign.Center
            tCell.VerticalAlign = VerticalAlign.Middle
            ' tCell.BackColor = Drawing.Color.Black
            tCell.BackColor = ColorTranslator.FromHtml("#CED15F")
            tCell.CssClass = "gfreeze"
            gvr.Cells.Add(tCell)


            tCell = New TableCell
            tCell.Text = "BACKUP ROLL TOP"
            tCell.ColumnSpan = 24
            tCell.Font.Size = 15
            tCell.Style.Add("border-right-color", "black")
            tCell.Style.Add(" box-shadow", "inset -2px -3px 0 0px black")

            tCell.HorizontalAlign = HorizontalAlign.Center
            ' tCell.BackColor = Drawing.Color.Black
            tCell.BackColor = ColorTranslator.FromHtml("#3AC0F2")
            tCell.CssClass = "gfreeze"
            gvr1.Cells.Add(tCell)

            tCell = New TableCell
            tCell.Text = "BACKUP ROLL BOTTOM"
            tCell.ColumnSpan = 24
            tCell.Font.Size = 15
            tCell.Style.Add("border-right-color", "black")
            tCell.Style.Add(" box-shadow", "inset -2px -3px 0 0px black")
            tCell.HorizontalAlign = HorizontalAlign.Center
            ' tCell.BackColor = Drawing.Color.Black
            tCell.BackColor = ColorTranslator.FromHtml("#3AC0F2")
            tCell.CssClass = "gfreeze"
            gvr1.Cells.Add(tCell)

            tCell = New TableCell
            tCell.Text = "WORK ROLL TOP"
            tCell.ColumnSpan = 24
            tCell.Font.Size = 15
            tCell.Style.Add("border-right-color", "black")
            tCell.Style.Add(" box-shadow", "inset -2px -3px 0 0px black")
            tCell.HorizontalAlign = HorizontalAlign.Center
            ' tCell.BackColor = Drawing.Color.Black
            tCell.BackColor = ColorTranslator.FromHtml("#3AC0F2")
            tCell.CssClass = "gfreeze"
            gvr1.Cells.Add(tCell)

            tCell = New TableCell
            tCell.Text = "WORK ROLL BOTTOM"
            tCell.ColumnSpan = 24
            tCell.Font.Size = 15
            tCell.Style.Add("border-right-color", "black")
            tCell.Style.Add(" box-shadow", "inset -2px -3px 0 0px black")
            tCell.HorizontalAlign = HorizontalAlign.Center
            ' tCell.BackColor = Drawing.Color.Black
            tCell.BackColor = ColorTranslator.FromHtml("#3AC0F2")
            tCell.CssClass = "gfreeze"
            gvr1.Cells.Add(tCell)



            For i As Integer = 1 To 4
                For j As Integer = 1 To 6
                    tCell = New TableCell
                    tCell.Text = "STAND#" & j
                    tCell.ColumnSpan = 4
                    tCell.Font.Size = 12

                    tCell.HorizontalAlign = HorizontalAlign.Center
                    tCell.Style.Add("box-shadow", "inset -2px 0px 0 0 black")
                    ' tCell.BackColor = Drawing.Color.Black
                    tCell.BackColor = ColorTranslator.FromHtml("#BBCAC3")
                    tCell.CssClass = "gfreeze"
                    gvr2.Cells.Add(tCell)
                Next
                tCell.Style.Add("box-shadow", "inset -2px 0px 0 0 black")
            Next
            tCell = New TableCell
            tCell.Text = "ROLL DETAILS"
            tCell.ColumnSpan = 105
            tCell.Font.Size = 15
            tCell.Style.Add("box-shadow", "inset -2px -2px 0 1px black")
            tCell.HorizontalAlign = HorizontalAlign.Center
            ' tCell.BackColor = Drawing.Color.Black
            tCell.BackColor = ColorTranslator.FromHtml("#04BCBB")
            tCell.CssClass = "gfreeze"
            tCell.CssClass = "headerboder"
            gvr.Cells.Add(tCell)
            'tCell = New TableCell
            'tCell.Text = ""
            'tCell.ColumnSpan = 1
            'tCell.RowSpan = 2
            '' tCell.BackColor = Drawing.Color.Black
            'tCell.CssClass = "gfreeze"

            'gvr.Cells.Add(tCell)
            gvr.CssClass = "gfreeze"
            gvr1.CssClass = "gfreeze"
            gvr2.CssClass = "gfreeze"

            tblData1.Controls(0).Controls.AddAt(0, gvr)
            tblData1.Controls(0).Controls.AddAt(1, gvr1)
            tblData1.Controls(0).Controls.AddAt(2, gvr2)

            'Dim tbl As Table = TryCast(tblData1.Controls(0), Table)
            'If tbl IsNot Nothing Then
            '    tbl.Rows.AddAt(0, gvr)
            'End If

        End If

    End Sub

    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    'Protected Sub OnDataBound(ByVal sender As Object, ByVal e As EventArgs)
    '    Dim row As New GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Normal)
    '    Dim cell As New TableHeaderCell()
    '    cell.HorizontalAlign = HorizontalAlign.Center
    '    cell.Text = "tscrmill"
    '    cell.ColumnSpan = 28
    '    row.Controls.Add(cell)
    '    ' row.BackColor = ColorTranslator.FromHtml("#00ggdd")
    '    cell = New TableHeaderCell()
    '    cell.HorizontalAlign = HorizontalAlign.Center
    '    cell.ColumnSpan = 15
    '    cell.Text = "furnace"
    '    row.Controls.Add(cell)

    '    row.BackColor = ColorTranslator.FromHtml("#3AC0F2")
    '    tblData1.HeaderRow.Parent.Controls.AddAt(0, row)
    'End Sub


    Sub accessible()
        If tblData1.Rows.Count > 0 Then
            'tblData1.UseAccessibleHeader = True
            'tblData1.HeaderRow.TableSection = TableRowSection.TableHeader
            'tblData1.FooterRow.TableSection = TableRowSection.TableFooter
        End If
    End Sub


    'Private Sub tblData1_RowDataBound(ByVal sender As Object, ByVal e As GridViewRowEventArgs) Handles tblData1.RowDataBound




    '    If e.Row.RowType = DataControlRowType.DataRow Then

    '        'For i As Integer = 0 To e.Row.Cells.Count - 1
    '        ' e.Row.Cells(27).Attributes.Add("style", "border:10px solid #000000")
    '        e.Row.Cells(27).Attributes.Add("style", "border-right:2px solid black")
    '        e.Row.Cells(42).Attributes.Add("style", "border-right:2px solid black")

    '        'e.Row.Cells(46).Attributes.Add("style", "border-right:1px solid green")
    '        'e.Row.Cells(50).Attributes.Add("style", "border-right:1px solid green")
    '        'e.Row.Cells(54).Attributes.Add("style", "border-right:1px solid green")
    '        'e.Row.Cells(58).Attributes.Add("style", "border-right:1px solid green")
    '        'e.Row.Cells(62).Attributes.Add("style", "border-right:1px solid green")
    '        e.Row.Cells(66).Attributes.Add("style", "border-right:2px solid black")

    '        'e.Row.Cells(70).Attributes.Add("style", "border-right:1px solid green")
    '        'e.Row.Cells(74).Attributes.Add("style", "border-right:1px solid green")
    '        'e.Row.Cells(78).Attributes.Add("style", "border-right:1px solid green")
    '        'e.Row.Cells(82).Attributes.Add("style", "border-right:1px solid green")
    '        'e.Row.Cells(86).Attributes.Add("style", "border-right:1px solid green")
    '        e.Row.Cells(90).Attributes.Add("style", "border-right:2px solid black")

    '        'e.Row.Cells(94).Attributes.Add("style", "border-right:1px solid green")
    '        'e.Row.Cells(98).Attributes.Add("style", "border-right:1px solid green")
    '        'e.Row.Cells(102).Attributes.Add("style", "border-right:1px solid green")
    '        'e.Row.Cells(106).Attributes.Add("style", "border-right:1px solid green")
    '        'e.Row.Cells(110).Attributes.Add("style", "border-right:1px solid green")
    '        e.Row.Cells(114).Attributes.Add("style", "border-right:2px solid black")

    '        'e.Row.Cells(118).Attributes.Add("style", "border-right:1px solid green")
    '        'e.Row.Cells(122).Attributes.Add("style", "border-right:1px solid green")
    '        'e.Row.Cells(126).Attributes.Add("style", "border-right:1px solid green")
    '        'e.Row.Cells(130).Attributes.Add("style", "border-right:1px solid green")
    '        'e.Row.Cells(134).Attributes.Add("style", "border-right:1px solid green")
    '        e.Row.Cells(140).Attributes.Add("style", "border-right:2px solid black")
    '        '  e.Row.Cells(144).Attributes.Add("style", "border-right:1px solid green")

    '    End If



    'End Sub





    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try

            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            main(dtStart, dtEnd)


        Catch ex As Exception

        End Try
    End Sub









    'Private Sub tblData1_RowCreated(sender As Object, e As GridViewRowEventArgs) Handles tblData1.RowCreated
    '    If e.Row.RowType = DataControlRowType.Header Then
    '        Dim grid As GridView = CType(sender, GridView)

    '        Dim HeaderGridRow As New GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Insert)
    '        Dim headerCell As New TableCell
    '        headerCell.Text = "Header Text"
    '        headerCell.ColumnSpan = e.Row.Cells.Count
    '        HeaderGridRow.Cells.Add(headerCell)
    '        HeaderGridRow.BackColor = Color.Beige
    '        HeaderGridRow.ForeColor = Color.White
    '        grid.Controls(0).Controls.AddAt(0, HeaderGridRow)

    '    End If
    'End Sub



   

    Protected Sub btnDownload_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDownload.Click

        Response.Clear()
        Response.Buffer = True
        Response.ClearContent()
        Response.ClearHeaders()
        Response.Charset = ""
        Dim FileName = "Mill Deviation" + DateTime.Now + ".xls"
        Dim strwritter As New StringWriter()
        Dim htmltextwrtter As New HtmlTextWriter(strwritter)
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.ContentType = "application/vnd.ms-excel"
        Response.AddHeader("Content-Disposition", "attachment;filename=" + FileName)
        tblData1.GridLines = GridLines.Both
        tblData1.HeaderStyle.Font.Bold = True
        tblData1.RenderControl(htmltextwrtter)
        Response.Write(strwritter.ToString().Replace("border-color:Black;border-width:2px;border-style:Ridge;", "").Replace("border-width:1px;border-style:None;", "").Replace("id=""tblData1""", "id=""tblData1"" border=""2"""))
        Response.End()

    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)
        ' Verifies that the control is rendered 
    End Sub

End Class
