﻿Imports System.Data
Imports System.IO
Imports System.Data.OleDb
Imports System.Data.DataTable
Imports System.Drawing
Imports System.Collections.Generic
Imports System.Web.UI
Imports System.Web.Script.Serialization
Partial Class Coil_tracker
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    txtDate_TextChanged()
                End If
            Catch ex As Exception

            End Try

        End If

        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd HH:mm:ss")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")

                Dim dt As DataTable = objController.HR_CR_PROCED_DATA(dtStart, dtEnd)
              
                DataDetailAnalysis(dt)

            Catch ex As Exception

            End Try

        End If

    End Sub
    Sub DataDetailAnalysis(ByVal tab As DataTable)
        Try

       
        For i As Integer = 0 To tab.Rows.Count - 1

            For j As Integer = 2 To tab.Columns.Count - 1

                    If tab.Rows(i)(j).ToString = "01-Jan-00 12:00:00 AM" Or tab.Rows(i)(j).ToString = "01-01-1900 00:00:00" Then
                        tab.Rows(i)(j) = DBNull.Value
                        'IIf(dt_con3.Rows(i).Item(j) Is DBNull.Value, String.Empty, dt_con3.Rows(i).Item(j))
                    End If
            Next
            Next
        Catch ex As Exception

        End Try
        GRID_HR_CR.DataSource = tab
        GRID_HR_CR.DataBind()

        'If GRID_HR_CR.Rows.Count > 0 Then
        GRID_HR_CR.UseAccessibleHeader = True
        GRID_HR_CR.HeaderRow.TableSection = TableRowSection.TableHeader
        'End If

    End Sub
    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try
            GetData()
        Catch ex As Exception

        End Try
    End Sub
    Sub GetData()
        Try
            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            Dim dt As DataTable = objController.HR_CR_PROCED_DATA(dtStart, dtEnd, ddlFilter.SelectedItem.Value)
            DataDetailAnalysis(dt)

        Catch ex As Exception

        End Try

    End Sub

    Protected Sub btnGo_Click(sender As Object, e As System.EventArgs) Handles btnGo.Click
        GetData()
    End Sub
End Class
