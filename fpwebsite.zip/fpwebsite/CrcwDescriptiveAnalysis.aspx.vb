﻿Imports System.Data
Imports System.IO
Imports System.Data.OleDb


Partial Class CrcwDescriptiveAnalysis
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("CRCW_Ora").ConnectionString
    Dim Oleconnection_ora As New OleDbConnection(strConnectionString)
    Dim OleAdap As New OleDbDataAdapter
    Dim ds As New DataSet
    Dim dt As New DataTable
    Dim OleCom As New OleDbCommand
    Dim dtCutOff As DataTable
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try

                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    txtDate_TextChanged()
                End If
            Catch ex As Exception

            End Try
        End If



        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-5).ToString("yyyy-MM-dd HH:mm")
                'Dim dtStart As DateTime = DateTime.Now.AddMonths(-6).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                Dim dt As New DataTable


                dt = LoadColumnNameForCRCW()
                If dt.Rows.Count > 0 Then
                    ddlXAxisParam.DataSource = dt
                    ddlXAxisParam.DataTextField = "QPM_PARAM_DESC"
                    ddlXAxisParam.DataValueField = "QPM_PARAM_DESC"
                    ddlXAxisParam.DataBind()

                    ddlYAxisParam.DataSource = dt
                    ddlYAxisParam.DataTextField = "QPM_PARAM_DESC"
                    ddlYAxisParam.DataValueField = "QPM_PARAM_DESC"
                    ddlYAxisParam.DataBind()
                    ddlYAxisParam.SelectedIndex = 1
                End If
            Catch ex As Exception

            End Try
        End If
    End Sub






    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try
            ' Dim dtStart As String = hfFrom.Value
            ' Dim dtEnd As String = hfTo.Value
            If (hfIsButton.Value = "false") Then
                'If ddlGrade.SelectedIndex > 0 And ddlTdc.SelectedIndex > 0 And ddlThickness.SelectedIndex > 0 Then

                ' objController.LoadColumnNameForSPMCoilDetail(clbParamTest, Session("ColumnName"))
                ' btnOk_Click(Nothing, Nothing)
                btnGo_Click(Nothing, Nothing)

            End If
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub
    Public Function LoadColumnNameForCRCW() As DataTable
        Try

            CloseConnection()
            Oleconnection_ora.Open()
            ds.Clear()
            dt.Clear()
            Dim OraQuery As String = "select distinct QPM_PARAM_DESC from DBPROD.QST_TRANSACTION,DBPROD.QST_PARAM_MST WHERE  QPM_PARAM_CD=QT_PARAM_CD and qpm_param_status='Y' and QPM_PARAM_CD in ('4','42','43','5','40','41','34','35','37')"
            Ora_selectquery(OraQuery)
            OleAdap.Fill(ds)
            dt = ds.Tables(0)
            Return dt

        Catch ex As Exception

        End Try
    End Function


    Sub CloseConnection()
        Try
            If Oleconnection_ora.State <> ConnectionState.Closed Then
                Oleconnection_ora.Close()
            End If
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

    End Sub
    Public Function Ora_selectquery(ByVal strselect As String) As OleDbDataAdapter
        Try

            OleCom.Connection = Oleconnection_ora
            OleCom.CommandText = strselect
            OleAdap.SelectCommand = OleCom

            Return OleAdap

        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Function


    Public Function GetDataForCRCW(ByVal TableName As String, ByVal FromDate As String, ByVal ToDate As String, ByVal XAxisName As String, ByVal YAxisName As String, ByVal DateColumn As String) As DataTable
        'ColumnName = "'" & ColumnName.Replace(",", "','") & "'"
        Dim str As String = "'" & XAxisName & "','" & YAxisName & "'"
        CloseConnection()
        Oleconnection_ora.Open()
        ds.Clear()
        dt.Clear()
        'Dim OraQuery As String = "select QPM_PARAM_DESC,QT_PARAM_NUM_VAL from " & TableName & " where QPM_PARAM_DESC in(" & str & ") and " & DateColumn & " between to_date('" & CDate(FromDate) & "','DD-MM-YYYY HH24:MI:SS') and to_date('" & CDate(ToDate) & "','DD-MM-YYYY HH24:MI:SS')"
        Dim OraQuery As String = "select QPM_PARAM_DESC,QT_PARAM_NUM_VAL from " & TableName & " where QPM_PARAM_DESC in(" & str & ") and " & DateColumn & " between to_date('" & CDate(FromDate) & "','DD-MM-YYYY HH24:MI:SS') and to_date('" & CDate(ToDate) & "','DD-MM-YYYY HH24:MI:SS') and qpm_param_status='Y' and  QPM_PARAM_CD=QT_PARAM_CD and QT_PARAM_NUM_VAL > 0 order by " & DateColumn & ""
        Ora_selectquery(OraQuery)
        OleAdap.Fill(ds)
        dt = ds.Tables(0)
        Return dt
    End Function

    Protected Sub btnGo_Click(sender As Object, e As System.EventArgs) Handles btnGo.Click
        Try
            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            DrawChart(fromDt, toDt, ddlXAxisParam.SelectedItem.Text, ddlYAxisParam.SelectedItem.Text)
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub
    Sub DrawChart(ByVal FromDt As String, ByVal ToDt As String, ByVal XAxisName As String, ByVal YAxisName As String)
        Try

            Dim strfrmDt As String = FromDt
            Dim strToDt As String = ToDt



            Dim dt As DataTable = GetDataForCRCW("DBPROD.QST_TRANSACTION,DBPROD.QST_PARAM_MST", strfrmDt, strToDt, XAxisName, YAxisName, "QT_DATE")

            Response.Write(dt.Rows.Count)

            If dt.Rows.Count > 0 Then
                Dim XAxisUnit As String = GetUnitForCRCW(XAxisName)
                Dim YAxisUnit As String = GetUnitForCRCW(YAxisName)
                objController.PlotScatterChartForCRCWNew(dt, XAxisName, YAxisName, Lit1, "container1", "plot1", XAxisName & " ,(" & XAxisUnit & ")", YAxisName & " ,(" & YAxisUnit & ")")
                'objController.PlotScatterChartForCRCWNew(dt, XAxisName, YAxisName, Lit1, "container1", "plot1", XAxisName, YAxisName)
            Else
                Lit1.Text = ""
            End If

            ' Dim literal As Literal = CType(Me.Master.FindControl("Lit" & i + 1), Literal)
            ' objController.PlotLineChartForSPM(dt, "COIL_STARTDATETIME", a(i) & "_C", l, a(i), "plot" & i + 1, "", Unit(i), i)
            'objController.PlotLineChartForSPMCoil(dt, "COIL_STARTDATETIME", a(i), l, a(i), "plot" & i + 1, "", "", "DAUGHTER_COILID_NUM")





        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub
    Public Function GetUnitForCRCW(ByVal ColumnName As String) As String
        Dim dsUnit As New DataSet
        Dim Unit As String = ""
        ColumnName = "'" & ColumnName.Replace(",", "','") & "'"
        CloseConnection()
        Oleconnection_ora.Open()
        dsUnit.Clear()
        ' Dim OraQuery As String = "select distinct QPM_PARAM_DESC,QPM_PARAM_UOM from DBPROD.QST_TRANSACTION,DBPROD.QST_PARAM_MST WHERE QPM_PARAM_DESC in(" & ColumnName & ")"
        Dim OraQuery As String = "select distinct QPM_PARAM_DESC,QPM_PARAM_UOM from DBPROD.QST_PARAM_MST WHERE QPM_PARAM_DESC in(" & ColumnName & ")"
        Ora_selectquery(OraQuery)
        OleAdap.Fill(dsUnit)
        Unit = dsUnit.Tables(0).Rows(0)(1)
        Return Unit

    End Function
End Class
