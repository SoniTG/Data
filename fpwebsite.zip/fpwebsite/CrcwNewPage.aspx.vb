﻿Imports System.Data
Imports System.IO
Imports System.Data.OleDb
Imports System.Configuration
Imports System.Web.UI
Imports System

Partial Class CrcwNewPage
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("CRCW_Ora").ConnectionString
    Dim Oleconnection_ora As New OleDbConnection(strConnectionString)
    Dim OleAdap As New OleDbDataAdapter
    Dim dsUnit As New DataSet
    Dim dtUnit As New DataTable
    Dim ds As New DataSet
    Dim dt As New DataTable
    Dim OleCom As New OleDbCommand
    Dim dtCutOff As DataTable
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try

                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    txtDate_TextChanged()
                End If
            Catch ex As Exception

            End Try
        End If



        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-5).ToString("yyyy-MM-dd HH:mm:ss")
                'Dim dtStart As DateTime = DateTime.Now.AddMonths(-6).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                Dim dt As New DataTable


                dt = LoadColumnNameForCRCW()
                If dt.Rows.Count > 0 Then
                    clbParamTest.DataSource = dt

                    clbParamTest.DataTextField = "QPM_PARAM_DESC"
                    clbParamTest.DataValueField = "QPM_PARAM_DESC"
                    clbParamTest.DataBind()
                End If
            Catch ex As Exception

            End Try
        End If
    End Sub


    Protected Sub btnOk_Click(sender As Object, e As EventArgs) Handles btnOk.Click
        Try
            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            Dim str1 As String = ""
            Dim count As Integer = 0
            Dim appendString = ""
            For i As Integer = 0 To clbParamTest.Items.Count - 1
                If clbParamTest.Items(i).Selected Then
                    count += 1
                    str1 &= "," & clbParamTest.Items(i).Value
                    appendString &= "<div class='col-md-2'></div><div class='col-md-10'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>" & clbParamTest.Items(i).Text & "</h3> <span></span></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='" & clbParamTest.Items(i).Value.Replace(" ", "").Replace("%", "").Replace(".", "") & "' style='height: 200px;'></div></div></div></div>"


                End If
            Next
            divHolder.InnerHtml = appendString
            If str1 = "" Then

            Else
                str1 = str1.Substring(1)
                Dim filter As String = " 1=1"

                DrawChartTop(str1, fromDt, toDt, filter)
            End If
        Catch ex As Exception

        End Try
    End Sub

    Sub DrawChartTop(ByVal ColumnName As String, ByVal FromDt As String, ByVal ToDt As String, ByVal Filter As String)
        Try

            Dim strfrmDt As String = CDate(FromDt).ToString("yyyy-MM-dd HH:mm:ss")
            Dim strToDt As String = CDate(ToDt).ToString("yyyy-MM-dd HH:mm:ss")


            'Dim strfrmDt As String = "15-06-2012 11:46:25"
            'Dim strToDt As String = "22-12-2012 11:46:25"

            ' Dim dtUnit As DataTable = GetUnitForCRCW(ColumnName)





            Dim a() As String = ColumnName.Split(",")
            Dim unit(a.Length) As String
            'Dim multiplier As String = "1.0"
            'For k As Integer = 0 To a.Length - 1
            '    Dim c As String = a(k)

            '    Dim row() As DataRow = dtUnit.Select("QPM_PARAM_DESC='" & c & "'")
            '    If row.Length > 0 Then
            '        'multiplier = row(0)(1)
            '        unit(k) = row(0)(1)
            '    Else
            '        'multiplier = "1.0"
            '    End If
            '    dt.Columns.Add(a(k) & "_C", GetType(Double), a(k).Replace("UNIT_", ""))
            'Next



            'Dim yVal As String = ""

            Dim l As Literal
            For i As Integer = 0 To UBound(a)
                Dim literals = Page.Master.FindControl("content_body").Controls.OfType(Of Literal)()
                For Each lit In literals
                    If (lit.ID = "Lit" & i + 1) Then
                        l = lit
                        Exit For
                    End If
                Next
                Dim dt As DataTable = GetDataForCRCW("DBPROD.QST_TRANSACTION,DBPROD.QST_PARAM_MST", strfrmDt, strToDt, "QT_DATE", a(i), Filter)

                ' Dim literal As Literal = CType(Me.Master.FindControl("Lit" & i + 1), Literal)
                objController.PlotLineChartForCRCWNew(dt, "QT_DATE", "QT_PARAM_NUM_VAL", l, a(i).Replace(" ", "").Replace("%", "").Replace(".", ""), "plot" & i + 1, "", dt(0)(3), i)
                'objController.PlotLineChartForSPMCoil(dt, "COIL_STARTDATETIME", a(i), l, a(i), "plot" & i + 1, "", "", "DAUGHTER_COILID_NUM")
            Next




        Catch ex As Exception

        End Try
    End Sub

    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try
            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            If (hfIsButton.Value = "false") Then
                'If ddlGrade.SelectedIndex > 0 And ddlTdc.SelectedIndex > 0 And ddlThickness.SelectedIndex > 0 Then

                ' objController.LoadColumnNameForSPMCoilDetail(clbParamTest, Session("ColumnName"))
                Dim dt As New DataTable
                clbParamTest.Items.Clear()
                dt = LoadColumnNameForCRCW()
                If dt.Rows.Count > 0 Then
                    clbParamTest.DataSource = dt

                    clbParamTest.DataTextField = "QPM_PARAM_DESC"
                    clbParamTest.DataValueField = "QPM_PARAM_DESC"
                    clbParamTest.DataBind()
                End If
                btnOk_Click(Nothing, Nothing)

            End If
        Catch ex As Exception

        End Try
    End Sub
    Public Function LoadColumnNameForCRCW() As DataTable
        Try

            CloseConnection()
            Oleconnection_ora.Open()
            ds.Clear()
            dt.Clear()
            Dim OraQuery As String = "select distinct QPM_PARAM_DESC from DBPROD.QST_TRANSACTION,DBPROD.QST_PARAM_MST WHERE  QPM_PARAM_CD=QT_PARAM_CD and qpm_param_status='Y' and QPM_PARAM_CD in ('4','42','43','5','40','41','34','35','37')"
            Ora_selectquery(OraQuery)
            OleAdap.Fill(ds)
            dt = ds.Tables(0)
            Return dt

        Catch ex As Exception

        End Try
    End Function


    Sub CloseConnection()
        Try
            If Oleconnection_ora.State <> ConnectionState.Closed Then
                Oleconnection_ora.Close()
            End If
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

    End Sub
    Public Function Ora_selectquery(ByVal strselect As String) As OleDbDataAdapter
        Try

            OleCom.Connection = Oleconnection_ora
            OleCom.CommandText = strselect
            OleAdap.SelectCommand = OleCom

            Return OleAdap

        Catch ex As Exception

        End Try
    End Function

    Public Function GetUnitForCRCW(ByVal ColumnName As String) As DataTable
        ColumnName = "'" & ColumnName.Replace(",", "','") & "'"
        CloseConnection()
        Oleconnection_ora.Open()
        dsUnit.Clear()
        dtUnit.Clear()
        ' Dim OraQuery As String = "select distinct QPM_PARAM_DESC,QPM_PARAM_UOM from DBPROD.QST_TRANSACTION,DBPROD.QST_PARAM_MST WHERE QPM_PARAM_DESC in(" & ColumnName & ")"
        Dim OraQuery As String = "select distinct QPM_PARAM_DESC,QPM_PARAM_UOM from DBPROD.QST_PARAM_MST WHERE QPM_PARAM_DESC in(" & ColumnName & ")"
        Ora_selectquery(OraQuery)
        OleAdap.Fill(dsUnit)
        dtUnit = dsUnit.Tables(0)
        Return dtUnit

    End Function
    Public Function GetDataForCRCW(ByVal TableName As String, ByVal FromDate As String, ByVal ToDate As String, ByVal DateColumn As String, ByVal ColumnName As String, ByVal Filter As String) As DataTable
        ColumnName = "'" & ColumnName.Replace(",", "','") & "'"
        CloseConnection()
        Oleconnection_ora.Open()
        ds.Clear()
        dt.Clear()
        Dim OraQuery As String = "select QT_DATE,QPM_PARAM_DESC,QT_PARAM_NUM_VAL,QPM_PARAM_UOM from " & TableName & " where QPM_PARAM_CD=QT_PARAM_CD and qpm_param_status='Y' and QPM_PARAM_DESC in(" & ColumnName & ") and " & DateColumn & " between to_date('" & FromDate & "','YYYY-MM-DD HH24:MI:SS') and to_date('" & ToDate & "','YYYY-MM-DD HH24:MI:SS') and " & Filter & " order by QT_DATE"
        ' Dim OraQuery As String = "select QT_DATE,QPM_PARAM_DESC,QT_PARAM_NUM_VAL,QPM_PARAM_UOM from " & TableName & " where QPM_PARAM_CD=QT_PARAM_CD and qpm_param_status='Y' and QPM_PARAM_DESC in(" & ColumnName & ") and " & DateColumn & " between '" & FromDate & "' and '" & ToDate & "' and " & Filter & " order by QT_DATE"
        Ora_selectquery(OraQuery)
        OleAdap.Fill(ds)
        dt = ds.Tables(0)
        Return dt
    End Function











End Class
