﻿
Imports System.Data
Imports System.Data.OleDb
Imports System.Data.SqlClient
Imports System.IO

Partial Class Crm_excel_to_sql
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim objDataHandler As New DataHandler
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub

    Sub UserMsgBoxSuccess(ByVal Message As String, ByVal Url As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalertandredirect('" + Message + "', '" + Url + "');", True)
    End Sub

    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub

    Dim ipaddress As String = Nothing
    Dim filename As String = Nothing
    Dim sheet_name As String = Nothing

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Session("pagehit") = New Controller().SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
            Dim qry As String = "  select (select max([date]) from Crm_DM_excel_to_sql where filename like'Rinse%') as Rinse,(select max([date]) from Crm_DM_excel_to_sql where filename like'Daily%') as Daily "
            Dim tab As DataSet = objDataHandler.GetDataSetFromQueryAnalysis(qry)
            Label1.Text = tab.Tables(0).Rows(0)("Rinse")
            Label2.Text = tab.Tables(0).Rows(0)("Daily")
        End If
    End Sub

    Protected Sub btnUpload_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnUpload.Click
        If FileUpload1.HasFile Then
            FileUpload1.PostedFile.SaveAs(Server.MapPath("~/Uploads/" + FileUpload1.FileName))
            Dim exfname As String = Server.MapPath("~/Uploads/" + FileUpload1.FileName)
            Dim connString As String = String.Empty
            filename = FileUpload1.FileName.Replace("'", "")

            Dim extension As String = Path.GetExtension(FileUpload1.PostedFile.FileName)
            Dim validFileTypes As String() = {".xls", ".xlsx"}
            Dim isValidFile As Boolean = False
            'To Check Valid file or not
            For i As Integer = 0 To validFileTypes.Length - 1
                If extension = validFileTypes(i) Then
                    isValidFile = True
                    Exit For
                End If
            Next
            If Not isValidFile Then
                UserMsgBoxWarning("Choose .xls or .xlsx file only.Try Again")
            Else
                'ip
                ipaddress = Request.ServerVariables("HTTP_X_FORWARDED_FOR")
                If ipaddress = "" Or ipaddress Is Nothing Then
                    ipaddress = Request.ServerVariables("REMOTE_ADDR")
                End If

                String.Join(",", validFileTypes)
                Select Case extension
                    Case ".xls"
                        'Excel 97-03
                        connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties='Excel 8.0;HDR=NO;IMEX=1'"
                        ' connString = ConfigurationManager.ConnectionStrings("Excel03ConString").ConnectionString
                        Exit Select
                    Case ".xlsx"
                        'Excel 07 or higher
                        connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties='Excel 8.0;HDR=NO;IMEX=1'"
                        Exit Select
                End Select
                connString = String.Format(connString, exfname)
                Using excel_con As New OleDbConnection(connString)
                    excel_con.Open()
                    Dim tempdtInsert As New DataTable()
                    Dim dtInsert As New DataTable()
                    Dim totalsheet As DataTable = excel_con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing)
                    Dim sheet As String = ""

                    For i As Integer = 0 To totalsheet.Rows.Count - 1
                        Try
                            sheet = excel_con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing).Rows(i)("TABLE_NAME").ToString()
                            sheet_name = sheet
                            tempdtInsert.Clear()
                            dtInsert.Clear()
                            Using oda As New OleDbDataAdapter((Convert.ToString("SELECT * FROM [") & sheet) + "]", excel_con)
                                'Using oda As New OleDbDataAdapter((Convert.ToString("SELECT * FROM [" & sheet1 + "A") & n) + "] where [Daughter Coil] is not null", excel_con)
                                oda.Fill(tempdtInsert)
                                'dtInsert = tempdtInsert.Clone()
                                dtInsert = tempdtInsert.Copy()
                                'To delete empty  and unwanted rows
                                If filename.StartsWith("Daily") Then
                                    For j As Integer = dtInsert.Rows.Count - 1 To 0 Step -1
                                        Dim row As DataRow = dtInsert.Rows(j)
                                        If row.Item(3) Is Nothing Then
                                            dtInsert.Rows.Remove(row)
                                        ElseIf row.Item(3).ToString = "" Then
                                            dtInsert.Rows.Remove(row)
                                        End If
                                    Next
                                ElseIf filename.StartsWith("Rinse") Then
                                    For j As Integer = dtInsert.Rows.Count - 1 To 0 Step -1
                                        Dim row As DataRow = dtInsert.Rows(j)
                                        If row.Item(1) Is Nothing And row.Item(2) Is Nothing And row.Item(3) Is Nothing Then
                                            dtInsert.Rows.Remove(row)
                                        ElseIf row.Item(1).ToString = "" And row.Item(2).ToString = "" And row.Item(3).ToString = "" Then
                                            dtInsert.Rows.Remove(row)
                                        End If
                                    Next
                                End If
                                For j As Integer = dtInsert.Rows.Count - 1 To 0 Step -1
                                    Dim row As DataRow = dtInsert.Rows(j)
                                    If row.Item(1) Is Nothing And row.Item(2) Is Nothing And row.Item(3) Is Nothing Then
                                        dtInsert.Rows.Remove(row)
                                    ElseIf row.Item(1).ToString = "" And row.Item(2).ToString = "" And row.Item(3).ToString = "" Then
                                        dtInsert.Rows.Remove(row)
                                    End If
                                Next
                                If dtInsert.Rows(0).Item(0) Is Nothing Then
                                    dtInsert.Columns.Remove(dtInsert.Columns(0))
                                ElseIf dtInsert.Rows(0).Item(0).ToString = "" Then
                                    dtInsert.Columns.Remove(dtInsert.Columns(0))
                                End If

                            End Using
                            For Each column As DataColumn In dtInsert.Columns
                                Dim cName As String = dtInsert.Rows(0)(column.ColumnName).ToString()
                                If Not dtInsert.Columns.Contains(cName) AndAlso cName <> "" Then
                                    column.ColumnName = cName
                                End If
                            Next
                            dtInsert.Rows.Remove(dtInsert.Rows(0))

                            If filename.StartsWith("Daily") Then
                                insert1(dtInsert)
                            ElseIf filename.StartsWith("Rinse") Then
                                insert2(dtInsert)
                            End If
                        Catch ex As Exception
                            Continue For
                        End Try
                    Next

                    ' Dim sheet1 As String = excel_con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing).Rows(0)("TABLE_NAME").ToString()

                    excel_con.Close()
                End Using
            End If
            'to automatically download the uploaded file
            If File.Exists(Server.MapPath("~/Uploads/" + FileUpload1.FileName)) Then
                File.Delete(Server.MapPath("~/Uploads/" + FileUpload1.FileName))
            End If
        Else
            UserMsgBoxWarning("No file selected. Please select the excel file.")
        End If

        Dim qry As String = "  select (select max([date]) from Crm_DM_excel_to_sql where filename like'Rinse%') as Rinse,(select max([date]) from Crm_DM_excel_to_sql where filename like'Daily%') as Daily "
        Dim tab As DataSet = objDataHandler.GetDataSetFromQueryAnalysis(qry)
        Label1.Text = tab.Tables(0).Rows(0)("Rinse")
        Label2.Text = tab.Tables(0).Rows(0)("Daily")
    End Sub

    Public Sub insert1(ByVal dtinsert As DataTable)
        Dim curdate As Date = Date.Now
        Dim d As String = curdate.ToString("yyyy-MM-dd HH:mm:ss")
        If dtinsert.Rows.Count > 0 Then
            If sheet_name.Contains("Tank") And Not sheet_name.Contains("Filter") Then
                For col As Short = 3 To dtinsert.Columns.IndexOf("Remarks") - 1
                    Dim strQuery As String = ""
                    For i As Short = 0 To dtinsert.Rows.Count - 1
                        Dim datecolumn As Date = dtinsert.Rows(i)(0).ToString().Replace("'", "")
                        Dim split() As String = filename.Split(".")
                        Dim date_column As String = ""
                        If dtinsert.Rows(i)(2).ToString() = "A" Then
                            date_column = datecolumn.ToString("" & split(0).Substring(split(0).Length - 4) & "-MM-dd 06:mm:ss")
                        ElseIf dtinsert.Rows(i)(2).ToString() = "B"
                            date_column = datecolumn.ToString("" & split(0).Substring(split(0).Length - 4) & "-MM-dd 14:mm:ss")
                        ElseIf dtinsert.Rows(i)(2).ToString() = "C"
                            date_column = datecolumn.ToString("" & split(0).Substring(split(0).Length - 4) & "-MM-dd 22:mm:ss")
                        End If

                        Dim value As String = dtinsert.Rows(i)(col).ToString().Replace("'", "")
                        If value = "" Then
                            value = "0.0"
                        End If
                        strQuery &= "insert into [Crm_DM_excel_to_sql] ([Date],[Plant],[Area],[Sub_Area], " &
                          " [Parameter],[Shift],[Value],[Sheet_Name],[Filename],[Remarks1],[Remarks2],[Upload_Dt],[Uploader_IP] ) " &
                          " values('" & date_column & "','CRM'," &
                          "'PLTCM','" & dtinsert.Rows(i)(1).ToString().Replace("'", "") & "'," &
                          "'" & dtinsert.Columns(col).ColumnName.ToString().Replace("'", "") & "','" & dtinsert.Rows(i)(2).ToString().Replace("'", "") & "'," &
                          "" & value & ",'" & sheet_name.Replace("'", "") & "','" & filename & "'," &
                          "'" & dtinsert.Rows(i)(dtinsert.Columns.Count - 1).ToString().Replace("'", "") & "',''," &
                          "'" & d & "','" & ipaddress & "');" & vbCrLf
                    Next
                    insert_query(strQuery)
                Next
            End If

        Else
            UserMsgBoxWarning("Data not found.")
        End If
    End Sub
    Public Sub insert2(ByVal dtinsert As DataTable)
        Dim curdate As Date = Date.Now
        Dim d As String = curdate.ToString("yyyy-MM-dd HH:mm:ss")
        Dim date_column As String = ""
        If dtinsert.Rows.Count > 0 Then
            If sheet_name.Contains("D#M") And Not sheet_name.Contains("Filter") Then
                Dim split() As String = filename.Split(".")
                For col As Short = 2 To dtinsert.Columns.IndexOf("Remarks") - 1
                    Dim strQuery As String = ""
                    For i As Short = 0 To dtinsert.Rows.Count - 1
                        Dim datecolumn As Date
                        If Not dtinsert.Rows(i)(0).ToString() = "" Then
                            datecolumn = dtinsert.Rows(i)(0).ToString().Replace("'", "")

                            If dtinsert.Rows(i)(1).ToString() = "A" Then
                                date_column = datecolumn.ToString("" & Split(0).Substring(Split(0).Length - 4) & "-MM-dd 06:mm:ss")
                            ElseIf dtinsert.Rows(i)(1).ToString() = "B"
                                date_column = datecolumn.ToString("" & Split(0).Substring(Split(0).Length - 4) & "-MM-dd 14:mm:ss")
                            ElseIf dtinsert.Rows(i)(1).ToString() = "C"
                                date_column = datecolumn.ToString("" & Split(0).Substring(Split(0).Length - 4) & "-MM-dd 22:mm:ss")
                            End If
                            'date_column = datecolumn.ToString("" & split(0).Substring(split(0).Length - 4) & "-MM-dd HH:mm:ss")
                        Else
                            If dtinsert.Rows(i)(1).ToString() = "A" Then
                                date_column = datecolumn.ToString("" & Split(0).Substring(Split(0).Length - 4) & "-MM-dd 06:mm:ss")
                            ElseIf dtinsert.Rows(i)(1).ToString() = "B"
                                date_column = datecolumn.ToString("" & Split(0).Substring(Split(0).Length - 4) & "-MM-dd 14:mm:ss")
                            ElseIf dtinsert.Rows(i)(1).ToString() = "C"
                                date_column = datecolumn.ToString("" & Split(0).Substring(Split(0).Length - 4) & "-MM-dd 22:mm:ss")
                            End If
                        End If
                        Dim value As String = dtinsert.Rows(i)(col).ToString().Replace("'", "")
                        If value = "" Then
                            value = "0.0"
                        End If
                        strQuery &= "insert into [Crm_DM_excel_to_sql] ([Date],[Plant],[Area],[Sub_Area], " &
                          " [Parameter],[Shift],[Value],[Sheet_Name],[Filename],[Remarks1],[Remarks2],[Upload_Dt],[Uploader_IP] ) " &
                          " values('" & date_column & "','CRM'," &
                          "'PLTCM','D.M WATER'," &
                          "'" & dtinsert.Columns(col).ColumnName.ToString().Replace("'", "") & "','" & dtinsert.Rows(i)(1).ToString().Replace("'", "") & "'," &
                          "" & value & ",'" & sheet_name.Replace("'", "") & "','" & filename & "'," &
                          "'" & dtinsert.Rows(i)("Remarks").ToString().Replace("'", "") & "',''," &
                          "'" & d & "','" & ipaddress & "');" & vbCrLf
                    Next
                    insert_query(strQuery)
                Next
            ElseIf sheet_name.Contains("Rinse") And Not sheet_name.Contains("Filter") Then
                Dim split() As String = filename.Split(".")
                For col As Short = 2 To dtinsert.Columns.IndexOf("Remarks") - 1
                    Dim strQuery As String = ""
                    For i As Short = 0 To dtinsert.Rows.Count - 1
                        Dim datecolumn As Date
                        If Not dtinsert.Rows(i)(0).ToString() = "" Then
                            datecolumn = dtinsert.Rows(i)(0).ToString().Replace("'", "")
                            'Dim split() As String = filename.Split(".")
                            If dtinsert.Rows(i)(1).ToString() = "A" Then
                                date_column = datecolumn.ToString("" & split(0).Substring(split(0).Length - 4) & "-MM-dd 06:mm:ss")
                            ElseIf dtinsert.Rows(i)(1).ToString() = "B"
                                date_column = datecolumn.ToString("" & split(0).Substring(split(0).Length - 4) & "-MM-dd 14:mm:ss")
                            ElseIf dtinsert.Rows(i)(1).ToString() = "C"
                                date_column = datecolumn.ToString("" & split(0).Substring(split(0).Length - 4) & "-MM-dd 22:mm:ss")
                            End If
                            'date_column = datecolumn.ToString("" & split(0).Substring(split(0).Length - 4) & "-MM-dd HH:mm:ss")
                        Else
                            If dtinsert.Rows(i)(1).ToString() = "A" Then
                                date_column = datecolumn.ToString("" & split(0).Substring(split(0).Length - 4) & "-MM-dd 06:mm:ss")
                            ElseIf dtinsert.Rows(i)(1).ToString() = "B"
                                date_column = datecolumn.ToString("" & split(0).Substring(split(0).Length - 4) & "-MM-dd 14:mm:ss")
                            ElseIf dtinsert.Rows(i)(1).ToString() = "C"
                                date_column = datecolumn.ToString("" & split(0).Substring(split(0).Length - 4) & "-MM-dd 22:mm:ss")
                            End If
                        End If
                        Dim value As String = dtinsert.Rows(i)(col).ToString().Replace("'", "")
                        If value = "" Then
                            value = "0.0"
                        End If
                        strQuery &= "insert into [Crm_DM_excel_to_sql] ([Date],[Plant],[Area],[Sub_Area], " &
                          " [Parameter],[Shift],[Value],[Sheet_Name],[Filename],[Remarks1],[Remarks2],[Upload_Dt],[Uploader_IP] ) " &
                          " values('" & date_column & "','CRM'," &
                          "'PLTCM','Rinse Water'," &
                          "'" & dtinsert.Columns(col).ColumnName.ToString().Replace("'", "") & "','" & dtinsert.Rows(i)(1).ToString().Replace("'", "") & "'," &
                          "'" & value & "','" & sheet_name.Replace("'", "") & "','" & filename & "'," &
                          "'" & dtinsert.Rows(i)(dtinsert.Columns.Count - 1).ToString().Replace("'", "") & "',''," &
                          "'" & d & "','" & ipaddress & "');" & vbCrLf
                    Next
                    insert_query(strQuery)
                Next
            End If


        Else
            UserMsgBoxWarning("Data not found.")
        End If
    End Sub
    Sub insert_query(ByVal query As String)
        Dim insquery As String = ""
        Try
            Using sqlConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString)
                Using sqlCommand As New SqlCommand
                    sqlConnection.Open()
                    insquery = query
                    sqlCommand.Connection = sqlConnection
                    sqlCommand.CommandText = query
                    sqlCommand.CommandTimeout = 10000
                    sqlCommand.ExecuteNonQuery()
                    sqlConnection.Close()
                    UserMsgBoxSuccess("Data inserted.")
                End Using
            End Using
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

End Class
