﻿Imports System.Data
Imports System.IO
Imports System.Drawing

Partial Class Current_Status_Summary
    Inherits System.Web.UI.Page
    Dim objController As New Controller_Status

    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub

    Sub UserMsgBoxSuccess(ByVal Message As String, ByVal Url As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalertandredirect('" + Message + "', '" + Url + "');", True)
    End Sub

    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub


    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
            Dim dtStart As String = DateTime.Now.AddDays(-29).ToString("yyyy-MM-dd HH:mm")
            'Dim dtStart As DateTime = DateTime.Now.AddMonths(-4).ToString("yyyy-MM-dd HH:mm")
            Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

            objController.Populate_Status(ddlStatus)
            objController.Populate_ProductSegment(ddlProduct)
            objController.Populate_PendingAgency(ddlPendAgency)

        End If
    End Sub

    Protected Sub btnOk_Click(sender As Object, e As System.EventArgs) Handles btnOk.Click
        Dim fromDt As String = hfFrom.Value
        Dim toDt As String = hfTo.Value

        Dim filter As String = " "

        Dim pendDays As String = ddlpendDays.SelectedItem.Text
        If Not pendDays.Trim.Contains(">") Then
            pendDays = "=" & pendDays.Trim

        End If
        If ddlProduct.SelectedIndex > 0 Then
            filter &= " and DDT_PRODUCT_SEGMENT='" & ddlProduct.SelectedItem.Text & "' "
        End If

        If ddlPendAgency.SelectedIndex > 0 Then
            filter &= " and (DDT_ORIGIN_PLANT='" & ddlPendAgency.SelectedItem.Text & "' or DDT_DETECTION_PLANT='" & ddlPendAgency.SelectedItem.Text & "') "
        End If

        If ddlStatus.SelectedIndex > 0 Then

            If ddlStatus.SelectedItem.Text = "Assigned to Central Pag" Then
                filter &= " and datediff(day,DDT_LOGGED_DATE,DDT_CPAG_FORWARDING_DATE)" & pendDays
            ElseIf ddlStatus.SelectedItem.Text = "Summarised" Then
                filter &= " and datediff(day,case when [DDT_ORIGIN_INV_DATE]>=[DDT_DETECTION_INV_DATE] then [DDT_ORIGIN_INV_DATE] else [DDT_DETECTION_INV_DATE] end,[DDT_CENTRAL_PAG_SUMMARY_DATE])" & pendDays
            ElseIf ddlStatus.SelectedItem.Text = "QA Plant Investigation" Then
                filter &= " and "

            End If

        End If

        'filter &= " and DDT_LOGGED_DATE between '" & fromDt & "' and '" & toDt & "'"

        LoadDummyData(filter)
        ' objController.Populate_Status(ddlStatus, fromDt, toDt)
    End Sub

    Sub LoadDummyData(ByVal filter As String)

        Dim dt1 As DataTable = objController.getDataForDPCR(filter)


        grid_Summary.DataSource = dt1
        grid_Summary.DataBind()
    End Sub

    Protected Sub grid_Summary_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles grid_Summary.DataBound
        Dim row As New GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Normal)
        Dim cell As New TableHeaderCell()
        cell.Text = ""
        cell.ColumnSpan = 1
        row.Controls.Add(cell)

        cell = New TableHeaderCell()
        cell.ColumnSpan = 3
        cell.Text = "CPAG Issue Summarization"
        row.Controls.Add(cell)

        cell = New TableHeaderCell()
        cell.ColumnSpan = 4
        cell.Text = "Origin QA Plant Investigation"
        row.Controls.Add(cell)

        cell = New TableHeaderCell()
        cell.ColumnSpan = 5
        cell.Text = "Detection QA Plant Investigation, Days"
        row.Controls.Add(cell)

        cell = New TableHeaderCell()
        cell.ColumnSpan = 3
        cell.Text = "CPAG Investigation Summarization, Days"
        row.Controls.Add(cell)

        cell = New TableHeaderCell()
        cell.ColumnSpan = 3
        cell.Text = "Closed by Requestor"
        row.Controls.Add(cell)


        cell = New TableHeaderCell()
        cell.ColumnSpan = 3
        cell.Text = "Response Cycle Time, Days"
        row.Controls.Add(cell)

        cell = New TableHeaderCell()
        cell.ColumnSpan = 3
        cell.Text = "Total time to Close DPCR, Days"
        row.Controls.Add(cell)



        row.BackColor = ColorTranslator.FromHtml("#08B89E")
        grid_Summary.HeaderRow.Parent.Controls.AddAt(0, row)



    End Sub

    Protected Sub grid_Summary_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles grid_Summary.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim t1_act As Integer = DataBinder.Eval(e.Row.DataItem, "CPAG_Days")
            If t1_act <= 1 Then
                e.Row.Cells(3).BackColor = Color.Green
            Else
                e.Row.Cells(3).BackColor = Color.Red
            End If
            Dim t2_act As Integer = DataBinder.Eval(e.Row.DataItem, "Origin_days")
            If t2_act <= 5 Then
                e.Row.Cells(6).BackColor = Color.Green
            Else
                e.Row.Cells(6).BackColor = Color.Red
            End If

            Dim t3_act As Integer = DataBinder.Eval(e.Row.DataItem, "DetectionDays")
            If t3_act <= 5 Then
                e.Row.Cells(10).BackColor = Color.Green
            Else
                e.Row.Cells(10).BackColor = Color.Red
            End If
            Dim t4_act As Integer = DataBinder.Eval(e.Row.DataItem, "CPAG_Summ_Days")
            If t4_act <= 1 Then
                e.Row.Cells(15).BackColor = Color.Green
            Else
                e.Row.Cells(15).BackColor = Color.Red
            End If
            Dim t6_act As Integer = DataBinder.Eval(e.Row.DataItem, "CloseDays")
            If t6_act <= 7 Then
                e.Row.Cells(21).BackColor = Color.Green
            Else
                e.Row.Cells(21).BackColor = Color.Red
            End If
            Dim t7_act As Integer = DataBinder.Eval(e.Row.DataItem, "TotalDays")
            If t7_act <= 10 Then
                e.Row.Cells(24).BackColor = Color.Green
            Else
                e.Row.Cells(24).BackColor = Color.Red
            End If
        End If
    End Sub
End Class
