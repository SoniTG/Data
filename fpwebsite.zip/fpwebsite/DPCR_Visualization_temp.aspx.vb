﻿Imports System.Data
Imports System.IO
Imports OfficeOpenXml
Imports OfficeOpenXml.Style
Imports System.Globalization
Imports System.Data.SqlClient

Partial Class DPCR_Visualization_temp
    Inherits System.Web.UI.Page
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub

    Sub UserMsgBoxSuccess(ByVal Message As String, ByVal Url As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalertandredirect('" + Message + "', '" + Url + "');", True)
    End Sub

    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Request.UrlReferrer Is Nothing Then
            Dim url As String = Request.UrlReferrer.ToString()
            'Response.Write(url)
            If url.ToUpper.Contains("PTG") Then
                Session("homeurl") = url
                Session("SubDivId") = "21"
                Session("CustomMenu") = "yes"
                Session("Department") = "DPCR"
            End If

        Else

        End If
        If Not Page.IsPostBack Then
            Session("pagehit") = New Controller().SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
            Dim dtStart As String = DateTime.Now.AddDays(-29).ToString("yyyy-MM-dd HH:mm")
            Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
            LoadDropdownFilters()
            PopulateGrid(dtStart, dtEnd, ddl1.SelectedItem.Text, ddl2.SelectedItem.Text, ddl3.SelectedItem.Text)
        End If
    End Sub

    Sub LoadDropdownFilters()
        ddl1.Items.Clear()
        ddl1.DataSource = Nothing
        ddl1.DataBind()
        ddl2.Items.Clear()
        ddl2.DataSource = Nothing
        ddl2.DataBind()
        ddl3.Items.Clear()
        ddl3.DataSource = Nothing
        ddl3.DataBind()
        Using sqlConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString)
            Dim strSelect As String = "select distinct DDT_ZONE from T_DPCR_DATA_TIMELINE where DDT_ZONE<>'' " & vbCrLf & "select distinct DDT_VERTICAL from T_DPCR_DATA_TIMELINE where DDT_VERTICAL<>'' " & vbCrLf & "select distinct DDT_PRODUCT_SEGMENT from T_DPCR_DATA_TIMELINE where DDT_PRODUCT_SEGMENT<>'' "
            Using sqlAdapter As New SqlDataAdapter(strSelect, sqlConnection)
                Using ds As New DataSet
                    sqlAdapter.Fill(ds)
                    ddl1.DataSource = ds.Tables(0)
                    ddl1.DataTextField = "DDT_ZONE"
                    ddl1.DataValueField = "DDT_ZONE"
                    ddl1.DataBind()
                    ddl1.Items.Add("ALL")
                    ddl1.Items.FindByValue("ALL").Selected = True
                    ddl2.DataSource = ds.Tables(1)
                    ddl2.DataTextField = "DDT_VERTICAL"
                    ddl2.DataValueField = "DDT_VERTICAL"
                    ddl2.DataBind()
                    ddl2.Items.Add("ALL")
                    ddl2.Items.FindByValue("ALL").Selected = True
                    ddl3.DataSource = ds.Tables(2)
                    ddl3.DataTextField = "DDT_PRODUCT_SEGMENT"
                    ddl3.DataValueField = "DDT_PRODUCT_SEGMENT"
                    ddl3.DataBind()
                    ddl3.Items.Add("ALL")
                    ddl3.Items.FindByValue("ALL").Selected = True
                End Using
            End Using
        End Using
    End Sub

    Function PopulateGrid(ByVal FromDate As String, ByVal ToDate As String, ByVal Zone As String, ByVal Vertical As String, ByVal ProductSegment As String) As DataTable
        Dim strCondition As String = ""
        If Zone <> "ALL" Then
            strCondition &= " and DDT_ZONE = '" & Zone & "' "
        End If
        If Vertical <> "ALL" Then
            strCondition &= " and DDT_VERTICAL = '" & Vertical & "' "
        End If
        If ProductSegment <> "ALL" Then
            strCondition &= " and DDT_PRODUCT_SEGMENT = '" & ProductSegment & "' "
        End If
        strCondition &= " AND DDT_LOGGED_DATE BETWEEN '" & FromDate & "' and '" & ToDate & "' "

        Using dt As New DataTable
            dt.Columns.Add("DDT_DPCR_ID")
            dt.Columns.Add("DDT_CUST_NAME_CODE_CITY")
            dt.Columns.Add("DDT_ZONE")
            dt.Columns.Add("DDT_LOGGED_DATE")
            dt.Columns.Add("DDT_PRODUCT_SEGMENT")
            dt.Columns.Add("DDT_ORIGIN_PLANT")
            dt.Columns.Add("DDT_DETECTION_PLANT")
            dt.Columns.Add("DDT_CATEGORY")
            dt.Columns.Add("DDT_VERTICAL")
            dt.Columns.Add("DDT_DEFECT")
            dt.Columns.Add("DDT_ISSUE_DETAILING1")
            dt.Columns.Add("DDT_ISSUE_DETAILING2")
            dt.Columns.Add("DDT_ISSUE_DETAILING3")
            dt.Columns.Add("DDT_ISSUE_DETAILING4")
            dt.Columns.Add("DDT_ISSUE_DETAILING5")
            dt.Columns.Add("DDT_OPI_FINDINGS")
            dt.Columns.Add("DDT_OPI_ACTION_INIT1")
            dt.Columns.Add("DDT_OPI_ACTION_INIT2")
            dt.Columns.Add("DDT_OPI_ACTION_PLAN1")
            dt.Columns.Add("DDT_OPI_ACTION_PLAN2")
            dt.Columns.Add("DDT_DPI_FINDINGS")
            dt.Columns.Add("DDT_DPI_ACTION_INIT1")
            dt.Columns.Add("DDT_DPI_ACTION_INIT2")
            dt.Columns.Add("DDT_DPI_ACTION_PLAN1")
            dt.Columns.Add("DDT_DPI_ACTION_PLAN2")
            dt.Columns.Add("DDT_CUST_PRIORITY_NO")
            dt.Columns.Add("DDT_WEEK_NO")
            dt.Columns.Add("DDT_LOGGED_BY")
            dt.Columns.Add("DDT_DPCR_PRIORITY")
            dt.Columns.Add("DDT_CUST_CODE")
            dt.Columns.Add("DDT_NS_CUST_NAME")
            dt.Columns.Add("DDT_BROAD_APPLICATION")
            dt.Columns.Add("DDT_NS_BROAD_APP")
            dt.Columns.Add("DDT_END_COMPONENT_FLAT")
            dt.Columns.Add("DDT_END_COMPONENT_LONG")
            dt.Columns.Add("DDT_NS_DEFECT")
            dt.Columns.Add("DDT_BATCH_NO")
            dt.Columns.Add("DDT_TDC")
            dt.Columns.Add("DDT_WIDTH")
            dt.Columns.Add("DDT_THICKNESS")
            dt.Columns.Add("DDT_NS_END_USE")
            dt.Columns.Add("DDT_COIL_NO")
            dt.Columns.Add("DDT_SPC_TYPE")
            dt.Columns.Add("DDT_STATUS")
            dt.Columns.Add("DDT_IS_CAPA_REQUIRED")
            dt.Columns.Add("DDT_IS_CAPA_ATTACHED")
            dt.Columns.Add("DDT_AUDITED")
            dt.Columns.Add("DDT_AUDITED_SUMMARY")
            dt.Columns.Add("DDT_CPAG_BY")
            dt.Columns.Add("DDT_CPAG_FORWARDING_DATE")
            dt.Columns.Add("DDT_CPAG_DAYS")
            dt.Columns.Add("DDT_ORIGIN_INV_BY")
            dt.Columns.Add("DDT_ORIGIN_INV_DATE")
            dt.Columns.Add("DDT_ORIGIN_INV_DAYS")
            dt.Columns.Add("DDT_DETECTION_INV_BY")
            dt.Columns.Add("DDT_DETECTION_INV_DATE")
            dt.Columns.Add("DDT_DETECTION_INV_DAYS")
            dt.Columns.Add("DDT_CENTRAL_PAG_SUMMARY_BY")
            dt.Columns.Add("DDT_CENTRAL_PAG_SUMMARY_DATE")
            dt.Columns.Add("DDT_CENTRAL_PAG_SUMMARY_DAYS")
            dt.Columns.Add("DDT_CLOSE_BY")
            dt.Columns.Add("DDT_CLOSE_DATE")
            dt.Columns.Add("DDT_CLOSE_DAYS")
            dt.Columns.Add("DDT_TOTAL_DAYS")
            dt.Columns.Add("COLUMN1")
            dt.Columns.Add("COLUMN2")
            dt.Columns.Add("COLUMN3")
            Using sqlConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString)
                Using sqlCommand As New SqlCommand("SELECT DDT_DPCR_ID,DDT_CUST_NAME_CODE_CITY,DDT_ZONE,format(DDT_LOGGED_DATE,'dd-MMM-yyyy') as DDT_LOGGED_DATE," & _
                                                   "DDT_PRODUCT_SEGMENT,DDT_ORIGIN_PLANT,DDT_DETECTION_PLANT,DDT_CATEGORY,DDT_VERTICAL,DDT_DEFECT,DDT_ISSUE_DETAILING1," & _
                                                   "DDT_ISSUE_DETAILING2,DDT_ISSUE_DETAILING3,DDT_ISSUE_DETAILING4,DDT_ISSUE_DETAILING5,DDT_OPI_FINDINGS," & _
                                                   "DDT_OPI_ACTION_INIT1,DDT_OPI_ACTION_INIT2,DDT_OPI_ACTION_PLAN1,DDT_OPI_ACTION_PLAN2,DDT_DPI_FINDINGS," & _
                                                   "DDT_DPI_ACTION_INIT1,DDT_DPI_ACTION_INIT2,DDT_DPI_ACTION_PLAN1,DDT_DPI_ACTION_PLAN2,DDT_CUST_PRIORITY_NO,DDT_WEEK_NO," & _
                                                   "DDT_LOGGED_BY,DDT_DPCR_PRIORITY,DDT_CUST_CODE,DDT_NS_CUST_NAME,DDT_BROAD_APPLICATION,DDT_NS_BROAD_APP," & _
                                                   "DDT_END_COMPONENT_FLAT,DDT_END_COMPONENT_LONG,DDT_NS_DEFECT,DDT_BATCH_NO,DDT_TDC,DDT_WIDTH,DDT_THICKNESS," & _
                                                   "DDT_NS_END_USE,DDT_COIL_NO,DDT_SPC_TYPE,DDT_STATUS,DDT_IS_CAPA_REQUIRED,DDT_IS_CAPA_ATTACHED,DDT_AUDITED," & _
                                                   "DDT_AUDITED_SUMMARY,DDT_CPAG_BY,DDT_CPAG_FORWARDING_DATE,DDT_CPAG_DAYS,DDT_ORIGIN_INV_BY,DDT_ORIGIN_INV_DATE," & _
                                                   "DDT_ORIGIN_INV_DAYS,DDT_DETECTION_INV_BY,DDT_DETECTION_INV_DATE,DDT_DETECTION_INV_DAYS,DDT_CENTRAL_PAG_SUMMARY_BY," & _
                                                   "DDT_CENTRAL_PAG_SUMMARY_DATE,DDT_CENTRAL_PAG_SUMMARY_DAYS,DDT_CLOSE_BY,DDT_CLOSE_DATE,DDT_CLOSE_DAYS,DDT_TOTAL_DAYS," & _
                                                   "COLUMN1,COLUMN2,COLUMN3 " & _
                                                   "from [FP_PROCESS_DATA].[dbo].[T_DPCR_DATA_TIMELINE] where 1=1" & _
                                                   strCondition & " ORDER BY DDT_LOGGED_DATE DESC", sqlConnection)
                    sqlConnection.Open()
                    Using sqlReader As SqlDataReader = sqlCommand.ExecuteReader
                        While sqlReader.Read
                            Dim row As DataRow = dt.NewRow
                            row("DDT_DPCR_ID") = sqlReader("DDT_DPCR_ID")
                            row("DDT_CUST_NAME_CODE_CITY") = sqlReader("DDT_CUST_NAME_CODE_CITY")
                            row("DDT_ZONE") = sqlReader("DDT_ZONE")
                            row("DDT_LOGGED_DATE") = sqlReader("DDT_LOGGED_DATE")
                            row("DDT_PRODUCT_SEGMENT") = sqlReader("DDT_PRODUCT_SEGMENT")
                            row("DDT_ORIGIN_PLANT") = sqlReader("DDT_ORIGIN_PLANT")
                            row("DDT_DETECTION_PLANT") = sqlReader("DDT_DETECTION_PLANT")
                            row("DDT_CATEGORY") = sqlReader("DDT_CATEGORY")
                            row("DDT_VERTICAL") = sqlReader("DDT_VERTICAL")
                            row("DDT_DEFECT") = sqlReader("DDT_DEFECT")
                            row("DDT_ISSUE_DETAILING1") = sqlReader("DDT_ISSUE_DETAILING1")
                            row("DDT_ISSUE_DETAILING2") = sqlReader("DDT_ISSUE_DETAILING2")
                            row("DDT_ISSUE_DETAILING3") = sqlReader("DDT_ISSUE_DETAILING3")
                            row("DDT_ISSUE_DETAILING4") = sqlReader("DDT_ISSUE_DETAILING4")
                            row("DDT_ISSUE_DETAILING5") = sqlReader("DDT_ISSUE_DETAILING5")
                            row("DDT_OPI_FINDINGS") = sqlReader("DDT_OPI_FINDINGS")
                            row("DDT_OPI_ACTION_INIT1") = sqlReader("DDT_OPI_ACTION_INIT1")
                            row("DDT_OPI_ACTION_INIT2") = sqlReader("DDT_OPI_ACTION_INIT2")
                            row("DDT_OPI_ACTION_PLAN1") = sqlReader("DDT_OPI_ACTION_PLAN1")
                            row("DDT_OPI_ACTION_PLAN2") = sqlReader("DDT_OPI_ACTION_PLAN2")
                            row("DDT_DPI_FINDINGS") = sqlReader("DDT_DPI_FINDINGS")
                            row("DDT_DPI_ACTION_INIT1") = sqlReader("DDT_DPI_ACTION_INIT1")
                            row("DDT_DPI_ACTION_INIT2") = sqlReader("DDT_DPI_ACTION_INIT2")
                            row("DDT_DPI_ACTION_PLAN1") = sqlReader("DDT_DPI_ACTION_PLAN1")
                            row("DDT_DPI_ACTION_PLAN2") = sqlReader("DDT_DPI_ACTION_PLAN2")
                            row("DDT_CUST_PRIORITY_NO") = sqlReader("DDT_CUST_PRIORITY_NO")
                            row("DDT_WEEK_NO") = sqlReader("DDT_WEEK_NO")
                            row("DDT_LOGGED_BY") = sqlReader("DDT_LOGGED_BY")
                            row("DDT_DPCR_PRIORITY") = sqlReader("DDT_DPCR_PRIORITY")
                            row("DDT_CUST_CODE") = sqlReader("DDT_CUST_CODE")
                            row("DDT_NS_CUST_NAME") = sqlReader("DDT_NS_CUST_NAME")
                            row("DDT_BROAD_APPLICATION") = sqlReader("DDT_BROAD_APPLICATION")
                            row("DDT_NS_BROAD_APP") = sqlReader("DDT_NS_BROAD_APP")
                            row("DDT_END_COMPONENT_FLAT") = sqlReader("DDT_END_COMPONENT_FLAT")
                            row("DDT_END_COMPONENT_LONG") = sqlReader("DDT_END_COMPONENT_LONG")
                            row("DDT_NS_DEFECT") = sqlReader("DDT_NS_DEFECT")
                            row("DDT_BATCH_NO") = sqlReader("DDT_BATCH_NO")
                            row("DDT_TDC") = sqlReader("DDT_TDC")
                            row("DDT_WIDTH") = sqlReader("DDT_WIDTH")
                            row("DDT_THICKNESS") = sqlReader("DDT_THICKNESS")
                            row("DDT_NS_END_USE") = sqlReader("DDT_NS_END_USE")
                            row("DDT_COIL_NO") = sqlReader("DDT_COIL_NO")
                            row("DDT_SPC_TYPE") = sqlReader("DDT_SPC_TYPE")
                            row("DDT_STATUS") = sqlReader("DDT_STATUS")
                            row("DDT_IS_CAPA_REQUIRED") = sqlReader("DDT_IS_CAPA_REQUIRED")
                            row("DDT_IS_CAPA_ATTACHED") = sqlReader("DDT_IS_CAPA_ATTACHED")
                            row("DDT_AUDITED") = sqlReader("DDT_AUDITED")
                            row("DDT_AUDITED_SUMMARY") = sqlReader("DDT_AUDITED_SUMMARY")
                            row("DDT_CPAG_BY") = sqlReader("DDT_CPAG_BY")
                            row("DDT_CPAG_FORWARDING_DATE") = sqlReader("DDT_CPAG_FORWARDING_DATE")
                            row("DDT_CPAG_DAYS") = sqlReader("DDT_CPAG_DAYS")
                            row("DDT_ORIGIN_INV_BY") = sqlReader("DDT_ORIGIN_INV_BY")
                            row("DDT_ORIGIN_INV_DATE") = sqlReader("DDT_ORIGIN_INV_DATE")
                            row("DDT_ORIGIN_INV_DAYS") = sqlReader("DDT_ORIGIN_INV_DAYS")
                            row("DDT_DETECTION_INV_BY") = sqlReader("DDT_DETECTION_INV_BY")
                            row("DDT_DETECTION_INV_DATE") = sqlReader("DDT_DETECTION_INV_DATE")
                            row("DDT_DETECTION_INV_DAYS") = sqlReader("DDT_DETECTION_INV_DAYS")
                            row("DDT_CENTRAL_PAG_SUMMARY_BY") = sqlReader("DDT_CENTRAL_PAG_SUMMARY_BY")
                            row("DDT_CENTRAL_PAG_SUMMARY_DATE") = sqlReader("DDT_CENTRAL_PAG_SUMMARY_DATE")
                            row("DDT_CENTRAL_PAG_SUMMARY_DAYS") = sqlReader("DDT_CENTRAL_PAG_SUMMARY_DAYS")
                            row("DDT_CLOSE_BY") = sqlReader("DDT_CLOSE_BY")
                            row("DDT_CLOSE_DATE") = sqlReader("DDT_CLOSE_DATE")
                            row("DDT_CLOSE_DAYS") = sqlReader("DDT_CLOSE_DAYS")
                            row("DDT_TOTAL_DAYS") = sqlReader("DDT_TOTAL_DAYS")
                            row("COLUMN1") = sqlReader("COLUMN1")
                            row("COLUMN2") = sqlReader("COLUMN2")
                            row("COLUMN3") = sqlReader("COLUMN3")
                            'row("TDD_WEEK_NO") = "<a href='#' onclick='showMail()'>" & sqlReader("TDD_WEEK_NO") & "</a>"
                            'row("TDD_REMARKS") = "<a href='#' onclick='showMail()'>" & sqlReader("TDD_REMARKS") & "</a>"
                            dt.Rows.Add(row)
                        End While
                    End Using
                    sqlConnection.Close()
                End Using
            End Using
            gvCustomer.DataSource = dt
            gvCustomer.DataBind()
            Return dt
        End Using
    End Function

    Function GetPriorityData() As DataTable
        Dim dt As New DataTable
        Using sqlConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString)
            Using sqlAdapter As New SqlDataAdapter("select * from T_DPCR_CUST_PRIORITY", sqlConnection)
                sqlAdapter.Fill(dt)
            End Using
        End Using
        Return dt
    End Function

    Function GetPriorityNumber(ByVal PriorityData As DataTable, ByVal Customer As String, ByVal Vertical As String) As Short
        Dim num As String = ""
        Dim dv As DataView = PriorityData.DefaultView
        dv.RowFilter = "TDC_CUSTOMER='" & Customer & "' AND TDC_MARKET_SEGMENT='" & Vertical & "'"
        Dim tbl As DataTable = dv.ToTable
        'Dim tbl As DataTable = (From val In PriorityData.AsEnumerable().Where(Function(col) col.Field(Of String)("TDC_CUSTOMER") = Customer And col.Field(Of String)("TDC_MARKET_SEGMENT") = MarketSegment) Select val).CopyToDataTable
        If tbl.Rows.Count > 0 Then
            num = tbl.Rows(0)("TDC_PRIORITY_NUM")
        End If
        Return num
    End Function

    Protected Sub btnUpload_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnUpload.Click
        If FileUpload1.HasFile Then

            FileUpload1.PostedFile.SaveAs(Server.MapPath("~/Uploads_TimeLine/" + FileUpload1.FileName))
            Dim exfname As String = Server.MapPath("~/Uploads_TimeLine/" + FileUpload1.FileName)
            'ViewState("exfname") = exfname
            'ViewState("filename") = FileUpload1.FileName
            Dim package As New ExcelPackage(New FileInfo(exfname))
            Dim workbook As ExcelWorkbook = package.Workbook
            Dim sheet As ExcelWorksheet = workbook.Worksheets(1)
            Dim dtExcel As New DataTable
            Dim c As Integer = 1
            Dim x As Short = 1

            While Not sheet.Cells(1, c).Value Is Nothing
                'If sheet.Cells(1, c).Value.ToString.ToLower.Contains("date") Then
                '    dtExcel.Columns.Add(sheet.Cells(1, c).Value, GetType(Date))
                'Else
                dtExcel.Columns.Add(sheet.Cells(1, c).Value)
                'End If

                c = c + 1
            End While
            If dtExcel.Columns(dtExcel.Columns.Count - 41).ColumnName.ToLower.Trim = "status" Then 'Checking if there is status column.
                Dim dt As DataTable = GetPriorityData()
                'Dim priority_num As Short = GetPriorityNumber(dt, "TATA STEEL PROCESSING / 263153 RUDRAPUR", "IPPE")
                Dim r As Integer = 2
                While Not sheet.Cells(r, 1).Value Is Nothing
                    dtExcel.Rows.Add()
                    For i As Integer = 1 To c - 1
                        If sheet.Cells(r, 28).Value = "N" Then 'Adding to datatable only if Status is N.
                            'dtExcel.Rows(r - 2)(i - 1) = sheet.Cells(r, i).Value
                            Dim value As String = ""
                            Try
                                value = sheet.Cells(r, i).Text
                                'value = sheet.Cells(r, i).Value
                            Catch ex As Exception
                            End Try
                            'If sheet.Cells(1, i).Value = "Logged Date" Then 'If the column is Logged Date, then changing the date format to yyyy-MM-dd
                            '    Dim arr() As String = value.Split(".")
                            '    value = arr(2) & "-" & arr(1) & "-" & arr(0)
                            'End If
                            'If sheet.Cells(50, i).Value = "DDT_CPAG_FORWARDING_DATE" Then
                            '    sheet.Column(50).Style.Numberformat.Format = "dd-MM-yyyy"
                            'End If
                            'If sheet.Cells(53, i).Value = "DDT_ORIGIN_INV_DATE" Then
                            '    sheet.Column(53).Style.Numberformat.Format = "dd-MM-yyyy"
                            'End If
                            'If sheet.Cells(56, i).Value = "DDT_DETECTION_INV_DATE" Then
                            '    sheet.Column(56).Style.Numberformat.Format = "dd-MM-yyyy"
                            'End If
                            'If sheet.Cells(59, i).Value = "DDT_CENTRAL_PAG_SUMMARY_DATE" Then
                            '    sheet.Column(59).Style.Numberformat.Format = "dd-MM-yyyy"
                            'End If
                            'If sheet.Cells(62, i).Value = "DDT_CLOSE_DATE" Then
                            '    sheet.Column(62).Style.Numberformat.Format = "dd-MM-yyyy"
                            'End If
                            If sheet.Cells(1, i).Value = "Customer Priority Number" Then
                                value = GetPriorityNumber(dt, sheet.Cells(r, 2).Value, sheet.Cells(r, 8).Value)
                            End If
                            'If sheet.Cells(1, i).Value = "Logged by" Then
                            '    value = GetPriorityNumber(dt, sheet.Cells(r, 2).Value, sheet.Cells(r, 8).Value)
                            'End If
                            dtExcel.Rows(r - 2)(i - 1) = value
                        End If

                    Next
                    r = r + 1
                End While
                Dim query = dtExcel.AsEnumerable().Where(Function(row) row.Field(Of String)("DPCR ID") = "") 'Getting all the blank rows (based on DPCR ID).
                For Each row In query.ToList 'Loop to delete the blank rows.
                    row.Delete()
                Next
                query = Nothing
                If dtExcel.Rows.Count > 0 Then
                    'For i As Short = 0 To dtExcel.Rows.Count - 1 'Loop to change the format of the date column.
                    '    Dim arr() As String = dtExcel.Rows(i)("Logged Date").ToString().Split(".")
                    '    dtExcel.Rows(i)("Logged Date") = arr(2) & "-" & arr(1) & "-" & arr(0)
                    'Next
                    Dim arrDPCRIDsToInsert() As String = (From row In dtExcel Select col = row.Field(Of String)("DPCR ID") Distinct).ToArray 'Storing DPCR IDs in an array.
                    Dim strDPCRIDs As String = "('" & String.Join("','", arrDPCRIDsToInsert) & "')"
                    Using sqlConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString)
                        Using sqlCommand As New SqlCommand("select DDT_DPCR_ID from  [FP_PROCESS_DATA].[dbo].[T_DPCR_DATA_TIMELINE] where DDT_DPCR_ID in " & strDPCRIDs, sqlConnection)
                            Dim count As Short = 0
                            Dim arrExistingDPCRIDs As New ArrayList
                            sqlConnection.Open()
                            Using sqlReader As SqlDataReader = sqlCommand.ExecuteReader
                                While sqlReader.Read
                                    arrExistingDPCRIDs.Add(sqlReader(0))
                                End While
                            End Using
                            Dim strQuery As String = ""
                            Dim dtInsert As DataTable = dtExcel
                            If arrExistingDPCRIDs.Count > 0 Then
                                Dim strDPCRIDsTemp As String = "('" & String.Join("','", arrExistingDPCRIDs.ToArray) & "')"
                                Dim dtTemp As DataTable = dtExcel
                                Dim dv As DataView = dtTemp.DefaultView
                                dv.RowFilter = "[DPCR ID] in " & strDPCRIDsTemp
                                dtTemp = dv.ToTable
                                dv.RowFilter = ""
                                dv = Nothing
                                If dtTemp.Rows.Count > 0 Then
                                    For i As Short = 0 To dtTemp.Rows.Count - 1

                                        Dim col_default As String = "1990-01-01"
                                        If IsDBNull(dtTemp.Rows(i)(50)) OrElse dtTemp.Rows(i)(50).ToString.Trim = "" Then
                                            dtTemp.Rows(i)(50) = col_default
                                        End If
                                        If IsDBNull(dtTemp.Rows(i)(53)) OrElse dtTemp.Rows(i)(53).ToString.Trim = "" Then
                                            dtTemp.Rows(i)(53) = col_default
                                        End If
                                        If IsDBNull(dtTemp.Rows(i)(56)) OrElse dtTemp.Rows(i)(56).ToString.Trim = "" Then
                                            dtTemp.Rows(i)(56) = col_default
                                        End If
                                        If IsDBNull(dtTemp.Rows(i)(59)) OrElse dtTemp.Rows(i)(59).ToString.Trim = "" Then
                                            dtTemp.Rows(i)(59) = col_default
                                        End If
                                        If IsDBNull(dtTemp.Rows(i)(62)) OrElse dtTemp.Rows(i)(62).ToString.Trim = "" Then
                                            dtTemp.Rows(i)(62) = col_default

                                        End If

                                        strQuery &= "update [FP_PROCESS_DATA].[dbo].[T_DPCR_DATA_TIMELINE] set DDT_CUST_NAME_CODE_CITY='" & dtTemp.Rows(i)(1).ToString().Replace("'", "") & "', DDT_ZONE='" & dtTemp.Rows(i)(2).ToString().Replace("'", "") & "', " & _
                                        "DDT_LOGGED_DATE='" & CDate(dtTemp.Rows(i)(3).ToString().Replace("'", "")).ToString("yyyy-MM-dd HH:mm:ss") & "', DDT_PRODUCT_SEGMENT='" & dtTemp.Rows(i)(4).ToString().Replace("'", "") & "', DDT_ORIGIN_PLANT='" & dtTemp.Rows(i)(5).ToString().Replace("'", "") & "', DDT_DETECTION_PLANT='" & dtTemp.Rows(i)(6).ToString().Replace("'", "") & "', " & _
                                        "DDT_CATEGORY='" & dtTemp.Rows(i)(7).ToString().Replace("'", "") & "', DDT_VERTICAL='" & dtTemp.Rows(i)(8).ToString().Replace("'", "") & "', DDT_DEFECT='" & dtTemp.Rows(i)(9).ToString().Replace("'", "") & "', " & _
                                        "DDT_ISSUE_DETAILING1='" & dtTemp.Rows(i)(10).ToString().Replace("'", "") & "', DDT_ISSUE_DETAILING2='" & dtTemp.Rows(i)(11).ToString().Replace("'", "") & "', DDT_ISSUE_DETAILING3='" & dtTemp.Rows(i)(12).ToString().Replace("'", "") & "', " & _
                                        "DDT_ISSUE_DETAILING4='" & dtTemp.Rows(i)(13).ToString().Replace("'", "") & "', DDT_ISSUE_DETAILING5='" & dtTemp.Rows(i)(14).ToString().Replace("'", "") & "', DDT_OPI_FINDINGS='" & dtTemp.Rows(i)(15).ToString().Replace("'", "") & "', " & _
                                        "DDT_OPI_ACTION_INIT1='" & dtTemp.Rows(i)(16).ToString().Replace("'", "") & "', DDT_OPI_ACTION_INIT2='" & dtTemp.Rows(i)(17).ToString().Replace("'", "") & "', DDT_OPI_ACTION_PLAN1='" & dtTemp.Rows(i)(18).ToString().Replace("'", "") & "', " & _
                                        "DDT_OPI_ACTION_PLAN2='" & dtTemp.Rows(i)(19).ToString().Replace("'", "") & "', DDT_DPI_FINDINGS='" & dtTemp.Rows(i)(20).ToString().Replace("'", "") & "', DDT_DPI_ACTION_INIT1='" & dtTemp.Rows(i)(21).ToString().Replace("'", "") & "', " & _
                                        "DDT_DPI_ACTION_INIT2='" & dtTemp.Rows(i)(22).ToString().Replace("'", "") & "', DDT_DPI_ACTION_PLAN1='" & dtTemp.Rows(i)(23).ToString().Replace("'", "") & "', DDT_DPI_ACTION_PLAN2='" & dtTemp.Rows(i)(24).ToString().Replace("'", "") & "', " & _
                                        "DDT_CUST_PRIORITY_NO='" & dtTemp.Rows(i)(25).ToString().Replace("'", "") & "', DDT_WEEK_NO='" & dtTemp.Rows(i)(26).ToString().Replace("'", "") & "', DDT_LOGGED_BY='" & dtTemp.Rows(i)(28).ToString().Replace("'", "") & "' ," & _
                                        "DDT_DPCR_PRIORITY='" & dtTemp.Rows(i)(29).ToString.Replace("'", "'") & "', DDT_CUST_CODE='" & dtTemp.Rows(i)(30).ToString.Replace("'", "'") & "', DDT_NS_CUST_NAME='" & dtTemp.Rows(i)(31).ToString().Replace("'", "") & "' ," & _
                                        "DDT_BROAD_APPLICATION='" & dtTemp.Rows(i)(32).ToString.Replace("'", "'") & "', DDT_NS_BROAD_APP='" & dtTemp.Rows(i)(33).ToString.Replace("'", "'") & "', DDT_END_COMPONENT_FLAT='" & dtTemp.Rows(i)(34).ToString().Replace("'", "") & "' ," & _
                                        "DDT_END_COMPONENT_LONG='" & dtTemp.Rows(i)(35).ToString.Replace("'", "'") & "', DDT_NS_DEFECT='" & dtTemp.Rows(i)(36).ToString.Replace("'", "'") & "', DDT_BATCH_NO='" & dtTemp.Rows(i)(37).ToString().Replace("'", "") & "' ," & _
                                        "DDT_TDC='" & dtTemp.Rows(i)(38).ToString.Replace("'", "'") & "', DDT_WIDTH='" & dtTemp.Rows(i)(39).ToString.Replace("'", "'") & "', DDT_THICKNESS='" & dtTemp.Rows(i)(40).ToString().Replace("'", "") & "' ," & _
                                        "DDT_NS_END_USE='" & dtTemp.Rows(i)(41).ToString.Replace("'", "'") & "', DDT_COIL_NO='" & dtTemp.Rows(i)(42).ToString.Replace("'", "'") & "', DDT_SPC_TYPE='" & dtTemp.Rows(i)(43).ToString.Replace("'", "'") & "'," & _
                                        "DDT_STATUS='" & dtTemp.Rows(i)(44).ToString.Replace("'", "'") & "', DDT_IS_CAPA_REQUIRED='" & dtTemp.Rows(i)(45).ToString.Replace("'", "'") & "', DDT_IS_CAPA_ATTACHED='" & dtTemp.Rows(i)(46).ToString.Replace("'", "'") & "', " & _
                                        "DDT_AUDITED='" & dtTemp.Rows(i)(47).ToString.Replace("'", "'") & "', DDT_AUDITED_SUMMARY='" & dtTemp.Rows(i)(48).ToString.Replace("'", "'") & "', DDT_CPAG_BY='" & dtTemp.Rows(i)(49).ToString.Replace("'", "'") & "', " & _
                                        "DDT_CPAG_FORWARDING_DATE='" & CDate(dtTemp.Rows(i)(50).ToString.Replace("'", "'")).ToString("yyyy-MM-dd HH:mm:ss") & "', DDT_CPAG_DAYS='" & dtTemp.Rows(i)(51).ToString.Replace("'", "'") & "', DDT_ORIGIN_INV_BY='" & dtTemp.Rows(i)(52).ToString.Replace("'", "'") & "', " & _
                                        "DDT_ORIGIN_INV_DATE='" & CDate(dtTemp.Rows(i)(53).ToString.Replace("'", "'")).ToString("yyyy-MM-dd HH:mm:ss") & "', DDT_ORIGIN_INV_DAYS='" & dtTemp.Rows(i)(54).ToString.Replace("'", "'") & "', DDT_DETECTION_INV_BY='" & dtTemp.Rows(i)(55).ToString.Replace("'", "'") & "', " & _
                                        "DDT_DETECTION_INV_DATE='" & CDate(dtTemp.Rows(i)(56).ToString.Replace("'", "'")).ToString("yyyy-MM-dd HH:mm:ss") & "', DDT_DETECTION_INV_DAYS='" & dtTemp.Rows(i)(57).ToString.Replace("'", "'") & "', DDT_CENTRAL_PAG_SUMMARY_BY='" & dtTemp.Rows(i)(58).ToString.Replace("'", "'") & "', " & _
                                        "DDT_CENTRAL_PAG_SUMMARY_DATE='" & CDate(dtTemp.Rows(i)(59).ToString.Replace("'", "'")).ToString("yyyy-MM-dd HH:mm:ss") & "', DDT_CENTRAL_PAG_SUMMARY_DAYS='" & dtTemp.Rows(i)(60).ToString.Replace("'", "'") & "', DDT_CLOSE_BY='" & dtTemp.Rows(i)(61).ToString.Replace("'", "'") & "', " & _
                                        "DDT_CLOSE_DATE='" & CDate(dtTemp.Rows(i)(62).ToString.Replace("'", "'")).ToString("yyyy-MM-dd HH:mm:ss") & "', DDT_CLOSE_DAYS='" & dtTemp.Rows(i)(63).ToString.Replace("'", "'") & "', DDT_TOTAL_DAYS='" & dtTemp.Rows(i)(64).ToString.Replace("'", "'") & "',  " & _
                                        "COLUMN1='" & dtTemp.Rows(i)(65).ToString.Replace("'", "'") & "', COLUMN2='" & dtTemp.Rows(i)(66).ToString.Replace("'", "'") & "', COLUMN3='" & dtTemp.Rows(i)(67).ToString.Replace("'", "'") & "'  " & _
                                         "where DDT_DPCR_ID ='" & dtTemp.Rows(i)(0) & "' " & vbCrLf

                                    Next
                                    dv = dtInsert.DefaultView
                                    dv.RowFilter = "[DPCR ID] not in " & strDPCRIDsTemp
                                    dtInsert = dv.ToTable
                                End If
                            End If
                            If dtInsert.Rows.Count > 0 Then

                                For i As Short = 0 To dtInsert.Rows.Count - 1

                                    Dim col_default As String = "1990-01-01"
                                    If IsDBNull(dtInsert.Rows(i)(50)) OrElse dtInsert.Rows(i)(50).ToString.Trim = "" Then
                                        dtInsert.Rows(i)(50) = col_default
                                    End If
                                    If IsDBNull(dtInsert.Rows(i)(53)) OrElse dtInsert.Rows(i)(53).ToString.Trim = "" Then
                                        dtInsert.Rows(i)(53) = col_default
                                    End If
                                    If IsDBNull(dtInsert.Rows(i)(56)) OrElse dtInsert.Rows(i)(56).ToString.Trim = "" Then
                                        dtInsert.Rows(i)(56) = col_default
                                    End If
                                    If IsDBNull(dtInsert.Rows(i)(59)) OrElse dtInsert.Rows(i)(59).ToString.Trim = "" Then
                                        dtInsert.Rows(i)(59) = col_default
                                    End If
                                    If IsDBNull(dtInsert.Rows(i)(62)) OrElse dtInsert.Rows(i)(62).ToString.Trim = "" Then
                                        dtInsert.Rows(i)(62) = col_default

                                    End If
                                    'dtInsert.Rows(i)(50).Format(Now, "yyyy-MM-dd")
                                    'dtInsert.Rows(i)(53).Format(Now, "yyyy-MM-dd")
                                    'dtInsert.Rows(i)(56).Format(Now, "yyyy-MM-dd")
                                    'dtInsert.Rows(i)(59).Format(Now, "yyyy-MM-dd")
                                    'dtInsert.Rows(i)(62).Format(Now, "yyyy-MM-dd")

                                    strQuery &= "insert into [FP_PROCESS_DATA].[dbo].[T_DPCR_DATA_TIMELINE] (DDT_DPCR_ID, DDT_CUST_NAME_CODE_CITY, DDT_ZONE, DDT_LOGGED_DATE, DDT_PRODUCT_SEGMENT, " & _
                                "DDT_ORIGIN_PLANT, DDT_DETECTION_PLANT, DDT_CATEGORY, DDT_VERTICAL, DDT_DEFECT, DDT_ISSUE_DETAILING1, DDT_ISSUE_DETAILING2, DDT_ISSUE_DETAILING3, " & _
                                "DDT_ISSUE_DETAILING4, DDT_ISSUE_DETAILING5, DDT_OPI_FINDINGS, DDT_OPI_ACTION_INIT1, DDT_OPI_ACTION_INIT2, DDT_OPI_ACTION_PLAN1, " & _
                                "DDT_OPI_ACTION_PLAN2, DDT_DPI_FINDINGS, DDT_DPI_ACTION_INIT1, DDT_DPI_ACTION_INIT2, DDT_DPI_ACTION_PLAN1, DDT_DPI_ACTION_PLAN2, " & _
                                "DDT_CUST_PRIORITY_NO, DDT_WEEK_NO,DDT_LOGGED_BY,DDT_DPCR_PRIORITY,DDT_CUST_CODE,DDT_NS_CUST_NAME,DDT_BROAD_APPLICATION, " & _
                                "DDT_NS_BROAD_APP,DDT_END_COMPONENT_FLAT,DDT_END_COMPONENT_LONG,DDT_NS_DEFECT,DDT_BATCH_NO,DDT_TDC,DDT_WIDTH,DDT_THICKNESS,DDT_NS_END_USE, " & _
                                "DDT_COIL_NO,DDT_SPC_TYPE,DDT_STATUS,DDT_IS_CAPA_REQUIRED,DDT_IS_CAPA_ATTACHED,DDT_AUDITED,DDT_AUDITED_SUMMARY,DDT_CPAG_BY,DDT_CPAG_FORWARDING_DATE, " & _
                                "DDT_CPAG_DAYS,DDT_ORIGIN_INV_BY,DDT_ORIGIN_INV_DATE,DDT_ORIGIN_INV_DAYS,DDT_DETECTION_INV_BY,DDT_DETECTION_INV_DATE,DDT_DETECTION_INV_DAYS, " & _
                                "DDT_CENTRAL_PAG_SUMMARY_BY,DDT_CENTRAL_PAG_SUMMARY_DATE,DDT_CENTRAL_PAG_SUMMARY_DAYS,DDT_CLOSE_BY,DDT_CLOSE_DATE,DDT_CLOSE_DAYS,DDT_TOTAL_DAYS, " & _
                                "COLUMN1,COLUMN2,COLUMN3) values('" & dtInsert.Rows(i)(0).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(1).ToString().Replace("'", "") & "'," & _
                                "'" & dtInsert.Rows(i)(2).ToString().Replace("'", "") & "','" & CDate(dtInsert.Rows(i)(3).ToString().Replace("'", "")).ToString("yyyy-MM-dd HH:mm:ss") & "'," & _
                                "'" & dtInsert.Rows(i)(4).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(5).ToString().Replace("'", "") & "'," & _
                                "'" & dtInsert.Rows(i)(6).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(7).ToString().Replace("'", "") & "'," & _
                                "'" & dtInsert.Rows(i)(8).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(9).ToString().Replace("'", "") & "'," & _
                                "'" & dtInsert.Rows(i)(10).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(11).ToString().Replace("'", "") & "'," & _
                                "'" & dtInsert.Rows(i)(12).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(13).ToString().Replace("'", "") & "'," & _
                                "'" & dtInsert.Rows(i)(14).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(15).ToString().Replace("'", "") & "'," & _
                                "'" & dtInsert.Rows(i)(16).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(17).ToString().Replace("'", "") & "'," & _
                                "'" & dtInsert.Rows(i)(18).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(19).ToString().Replace("'", "") & "'," & _
                                "'" & dtInsert.Rows(i)(20).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(21).ToString().Replace("'", "") & "'," & _
                                "'" & dtInsert.Rows(i)(22).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(23).ToString().Replace("'", "") & "'," & _
                                "'" & dtInsert.Rows(i)(24).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(25).ToString().Replace("'", "") & "'," & _
                                "'" & dtInsert.Rows(i)(26).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(28).ToString().Replace("'", "") & "'," & _
                                 "'" & dtInsert.Rows(i)(29).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(30).ToString().Replace("'", "") & "'," & _
                                 "'" & dtInsert.Rows(i)(31).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(32).ToString().Replace("'", "") & "'," & _
                                 "'" & dtInsert.Rows(i)(33).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(34).ToString().Replace("'", "") & "'," & _
                                 "'" & dtInsert.Rows(i)(35).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(36).ToString().Replace("'", "") & "'," & _
                                 "'" & dtInsert.Rows(i)(37).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(38).ToString().Replace("'", "") & "'," & _
                                 "'" & dtInsert.Rows(i)(39).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(40).ToString().Replace("'", "") & "'," & _
                                 "'" & dtInsert.Rows(i)(41).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(42).ToString().Replace("'", "") & "'," & _
                                 "'" & dtInsert.Rows(i)(43).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(44).ToString().Replace("'", "") & "'," & _
                                 "'" & dtInsert.Rows(i)(45).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(46).ToString().Replace("'", "") & "'," & _
                                 "'" & dtInsert.Rows(i)(47).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(48).ToString().Replace("'", "") & "'," & _
                                 "'" & dtInsert.Rows(i)(49).ToString().Replace("'", "") & "','" & CDate(dtInsert.Rows(i)(50)).ToString("yyyy-MM-dd HH:mm:ss").Replace("'", "") & "'," & _
                                 "'" & dtInsert.Rows(i)(51).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(52).ToString().Replace("'", "") & "'," & _
                                 "'" & CDate(dtInsert.Rows(i)(53)).ToString("yyyy-MM-dd HH:mm:ss").Replace("'", "") & "','" & dtInsert.Rows(i)(54).ToString().Replace("'", "") & "'," & _
                                 "'" & dtInsert.Rows(i)(55).ToString().Replace("'", "") & "','" & CDate(dtInsert.Rows(i)(56)).ToString("yyyy-MM-dd HH:mm:ss").Replace("'", "") & "'," & _
                                 "'" & dtInsert.Rows(i)(57).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(58).ToString().Replace("'", "") & "'," & _
                                "'" & CDate(dtInsert.Rows(i)(59)).ToString("yyyy-MM-dd HH:mm:ss").Replace("'", "") & "','" & dtInsert.Rows(i)(60).ToString().Replace("'", "") & "'," & _
                               "'" & dtInsert.Rows(i)(61).ToString().Replace("'", "") & "','" & CDate(dtInsert.Rows(i)(62)).ToString("yyyy-MM-dd HH:mm:ss").Replace("'", "") & "'," & _
                              "'" & dtInsert.Rows(i)(63).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(64).ToString().Replace("'", "") & "'," & _
                               "'" & dtInsert.Rows(i)(65).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(66).ToString().Replace("'", "") & "'," & _
                                  "'" & dtInsert.Rows(i)(67).ToString().Replace("'", "") & "'); " & vbCrLf




                                Next

                            End If

                            sqlCommand.CommandText = strQuery
                            Try
                                count = sqlCommand.ExecuteNonQuery()
                            Catch ex As Exception
                                UserMsgBoxError("Task failed to completed. Try again.")
                            End Try
                            sqlConnection.Close()
                            If count > 0 Then
                                Try
                                    r = 2
                                    While Not sheet.Cells(r, 1).Value Is Nothing
                                        If arrDPCRIDsToInsert.Contains(CStr(sheet.Cells(r, 1).Value)) Then
                                            sheet.Cells(r, 28).Value = "Y"
                                        End If
                                        r = r + 1
                                    End While
                                    package.Save()
                                    UserMsgBoxSuccess("You MUST download the new Excel file.")
                                    LoadDropdownFilters()
                                    PopulateGrid(hfFrom.Value, hfTo.Value, ddl1.SelectedItem.Text, ddl2.SelectedItem.Text, ddl3.SelectedItem.Text)
                                Catch ex As Exception
                                    UserMsgBoxError("Records saved, but failed to change the status in excel file.")
                                End Try
                            End If
                        End Using
                    End Using
                Else
                    UserMsgBoxWarning("Data with status as 'N' not found.")
                End If
            Else
                UserMsgBoxWarning("Status column not found in the excel file.")
            End If
            sheet.Dispose()
            workbook.Dispose()
            package.Dispose()
        Else
            UserMsgBoxWarning("No file selected. Please select the excel file.")
        End If
    End Sub

    Public Property direction As SortDirection
        Get
            If ViewState("directionState") Is Nothing Then
                ViewState("directionState") = SortDirection.Ascending
            End If

            Return CType(ViewState("directionState"), SortDirection)
        End Get
        Set(ByVal value As SortDirection)
            ViewState("directionState") = value
        End Set
    End Property

    Protected Sub gvCustomer_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gvCustomer.Sorting
        Dim sortingDirection As String = String.Empty

        If direction = SortDirection.Ascending Then
            direction = SortDirection.Descending
            sortingDirection = "Desc"
        Else
            direction = SortDirection.Ascending
            sortingDirection = "Asc"
        End If

        Dim sortedView As DataView = New DataView(PopulateGrid(hfFrom.Value, hfTo.Value, ddl1.SelectedItem.Text, ddl2.SelectedItem.Text, ddl3.SelectedItem.Text))
        sortedView.Sort = e.SortExpression & " " & sortingDirection
        Session("SortedView") = sortedView
        gvCustomer.DataSource = sortedView
        gvCustomer.DataBind()
    End Sub

    Protected Sub btnOk_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnOk.Click
        PopulateGrid(hfFrom.Value, hfTo.Value, ddl1.SelectedItem.Text, ddl2.SelectedItem.Text, ddl3.SelectedItem.Text)
    End Sub

    Protected Sub btnDownload_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDownload.Click
        Try
            Dim excelFile = Directory.GetFiles(Server.MapPath("~/Uploads_TimeLine/")).OrderByDescending(Function(f) New FileInfo(f).LastWriteTime).First()
            Dim fName As String = excelFile.Substring(excelFile.LastIndexOf("\") + 1)
            Response.Clear()
            Response.Buffer = True
            Response.Charset = ""
            Response.ContentType = "application/vnd.ms-excel"
            Response.AddHeader("content-disposition", "attachment; filename=" + fName)
            Response.WriteFile(excelFile)
            Response.End()
        Catch ex As Exception
            UserMsgBoxError("Failed to download the new file.")
        End Try
    End Sub
End Class
