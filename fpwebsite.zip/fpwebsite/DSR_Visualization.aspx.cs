﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;


public partial class DSR_Visualization : System.Web.UI.Page
{
    DataHandler objdatahandler = new DataHandler();
    Controller objController = new Controller();
    

    

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            /* Session["pagehit"] = objController.SaveAndRetrievePageHits(Session["LoginTime"].ToString(), Path.GetFileName(Request.Path)); */
            hfFrom.Value = DateTime.Now.AddDays(-30).ToString("yyyy-MM-dd HH:mm:ss");
            hfTo.Value = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            GetData_slab_id(hfFrom.Value, hfTo.Value);
            GetData();

        }
       


    }


    protected DataTable GetData_Grade(string sladid)
    {
        DataTable dt1 = new DataTable();
        //string cs = ConfigurationManager.ConnectionStrings["TG-GWL"].ConnectionString;
        //using (SqlConnection connection = new SqlConnection(cs))
        //{
            //SqlCommand sqlCmd = new SqlCommand("select GRADE_CODE from T_SLABCUT_INFO WHERE slab_id='" + sladid + "'", connection);
            //SqlCommand sqlCmd = new SqlCommand("spGetGarde_code", connection);
            //connection.Open();
            //sqlCmd.CommandType = CommandType.StoredProcedure;
            //SqlParameter parameterSladID = new SqlParameter();
            //parameterSladID.ParameterName = "@slab_id";
            //parameterSladID.Value = sladid;
            //sqlCmd.Parameters.Add(parameterSladID);
            //sqlCmd.CommandTimeout = 3000;
            //SqlDataAdapter da = new SqlDataAdapter(sqlCmd);
            //dt1.Clear();
            //da.Fill(dt1);

            dt1 = objdatahandler.GetDataSetFromQuery("select GRADE_CODE from T_SLABCUT_INFO WHERE slab_id='" + sladid + "'").Tables[0];
            return dt1;
        //}
    }
    public DataTable BindData(string sladid)
    {
        DataTable dt = new DataTable();
        //string cs = ConfigurationManager.ConnectionStrings["TG-GWL"].ConnectionString;
        //using (SqlConnection connection = new SqlConnection(cs))
        //{
        //    SqlCommand sqlCmd = new SqlCommand("SELECT [slab_id],[iba_slab_cut_time],total_soft_reduction_act_out,total_soft_reduction_act_q4,total_soft_reduction_act_q3,total_soft_reduction_act_mean,total_soft_reduction_act_q2,total_soft_reduction_act_q1,total_soft_reduction_act_q0,total_soft_reduction_ref_out,total_soft_reduction_ref_q4,total_soft_reduction_ref_q3,total_soft_reduction_ref_mean,total_soft_reduction_ref_q2,total_soft_reduction_ref_q1,total_soft_reduction_ref_q0,[solid_seg_min] AS j_min,ROUND(solid_seg_mean,0)AS j_mode,[solid_seg_max] AS j_max,dsr_on_mean*100 AS [Dynamic soft reduction],therm_tap_tab_no_min AS [Thermal taper table number_Min],therm_tap_tab_no_max AS [Thermal taper table number_Max],sr_tab_no_min AS [Soft reduction table number_Min],sr_tab_no_max AS [Soft reduction table number_Max],ISNULL(hsa_speed_min,99)AS hsa_min,ISNULL(hsa_speed_mean,99)AS hsa_mean,ISNULL(hsa_speed_max,99)AS hsa_max,ISNULL(hsa_speed_stddev,99)AS hsa_stddev,CASE WHEN(abs(solid_len_act_mean - solid_len_dsc_mean)<= abs(solid_len_act_mean - solid_len_k_mean))THEN 'DSC' ELSE 'KF' END AS [Soft reduction mode],CASE WHEN scw_dsc_mode_mean >= 0.5 THEN 'DSC' ELSE 'L1' END AS [Secondary cooling mode],scw_l1_curve_min AS [Secondary cooling curve min],scw_l1_curve_max AS [Secondary cooling curve max],hsa_tap_act_10_min as hsa_tap_act_10_min,hsa_tap_act_10_max as hsa_tap_act_10_max,hsa_tap_act_10_mean as hsa_tap_act_10_mean,hsa_gap_10_e_min as hsa_gap_10_e_min,hsa_gap_10_e_max as hsa_gap_10_e_max,hsa_gap_10_e_mean as hsa_gap_10_e_mean,hsa_gap_10_d_min as hsa_gap_10_d_min,hsa_gap_10_d_max as hsa_gap_10_d_max,hsa_gap_10_d_mean as hsa_gap_10_d_mean,hsa_force_10_el_min as hsa_force_10_el_min,hsa_force_10_el_max as hsa_force_10_el_max,hsa_force_10_el_mean as hsa_force_10_el_mean,hsa_force_10_er_min as hsa_force_10_er_min,hsa_force_10_er_max as hsa_force_10_er_max,hsa_force_10_er_mean as hsa_force_10_er_mean,hsa_force_10_dl_min as hsa_force_10_dl_min,hsa_force_10_dl_max as hsa_force_10_dl_max,hsa_force_10_dl_mean as hsa_force_10_dl_mean,hsa_force_10_dr_min as hsa_force_10_dr_min,hsa_force_10_dr_max as hsa_force_10_dr_max,hsa_force_10_dr_mean as hsa_force_10_dr_mean,hsa_tap_act_11_min as hsa_tap_act_11_min,hsa_tap_act_11_max as hsa_tap_act_11_max,hsa_tap_act_11_mean as hsa_tap_act_11_mean,hsa_gap_11_e_min as hsa_gap_11_e_min,hsa_gap_11_e_max as hsa_gap_11_e_max,hsa_gap_11_e_mean as hsa_gap_11_e_mean,hsa_gap_11_d_min as hsa_gap_11_d_min,hsa_gap_11_d_max as hsa_gap_11_d_max,hsa_gap_11_d_mean as hsa_gap_11_d_mean,hsa_force_11_el_min as hsa_force_11_el_min,hsa_force_11_el_max as hsa_force_11_el_max,hsa_force_11_el_mean as hsa_force_11_el_mean,hsa_force_11_er_min as hsa_force_11_er_min,hsa_force_11_er_max as hsa_force_11_er_max,hsa_force_11_er_mean as hsa_force_11_er_mean,hsa_force_11_dl_min as hsa_force_11_dl_min,hsa_force_11_dl_max as hsa_force_11_dl_max,hsa_force_11_dl_mean as hsa_force_11_dl_mean,hsa_force_11_dr_min as hsa_force_11_dr_min,hsa_force_11_dr_max as hsa_force_11_dr_max,hsa_force_11_dr_mean as hsa_force_11_dr_mean,hsa_tap_act_12_min as hsa_tap_act_12_min,hsa_tap_act_12_max as hsa_tap_act_12_max,hsa_tap_act_12_mean as hsa_tap_act_12_mean,hsa_gap_12_e_min as hsa_gap_12_e_min,hsa_gap_12_e_max as hsa_gap_12_e_max,hsa_gap_12_e_mean as hsa_gap_12_e_mean,hsa_gap_12_d_min as hsa_gap_12_d_min,hsa_gap_12_d_max as hsa_gap_12_d_max,hsa_gap_12_d_mean as hsa_gap_12_d_mean,hsa_force_12_el_min as hsa_force_12_el_min,hsa_force_12_el_max as hsa_force_12_el_max,hsa_force_12_el_mean as hsa_force_12_el_mean,hsa_force_12_er_min as hsa_force_12_er_min,hsa_force_12_er_max as hsa_force_12_er_max,hsa_force_12_er_mean as hsa_force_12_er_mean,hsa_force_12_dl_min as hsa_force_12_dl_min,hsa_force_12_dl_max as hsa_force_12_dl_max,hsa_force_12_dl_mean as hsa_force_12_dl_mean,hsa_force_12_dr_min as hsa_force_12_dr_min,hsa_force_12_dr_max as hsa_force_12_dr_max,hsa_force_12_dr_mean as hsa_force_12_dr_mean,hsa_tap_act_13_min as hsa_tap_act_13_min,hsa_tap_act_13_max as hsa_tap_act_13_max,hsa_tap_act_13_mean as hsa_tap_act_13_mean,hsa_gap_13_e_min as hsa_gap_13_e_min,hsa_gap_13_e_max as hsa_gap_13_e_max,hsa_gap_13_e_mean as hsa_gap_13_e_mean,hsa_gap_13_d_min as hsa_gap_13_d_min,hsa_gap_13_d_max as hsa_gap_13_d_max,hsa_gap_13_d_mean as hsa_gap_13_d_mean,hsa_force_13_el_min as hsa_force_13_el_min,hsa_force_13_el_max as hsa_force_13_el_max,hsa_force_13_el_mean as hsa_force_13_el_mean,hsa_force_13_er_min as hsa_force_13_er_min,hsa_force_13_er_max as hsa_force_13_er_max,hsa_force_13_er_mean as hsa_force_13_er_mean,hsa_force_13_dl_min as hsa_force_13_dl_min,hsa_force_13_dl_max as hsa_force_13_dl_max,hsa_force_13_dl_mean as hsa_force_13_dl_mean,hsa_force_13_dr_min as hsa_force_13_dr_min,hsa_force_13_dr_max as hsa_force_13_dr_max,hsa_force_13_dr_mean as hsa_force_13_dr_mean,hsa_tap_act_14_min as hsa_tap_act_14_min,hsa_tap_act_14_max as hsa_tap_act_14_max,hsa_tap_act_14_mean as hsa_tap_act_14_mean,hsa_gap_14_e_min as hsa_gap_14_e_min,hsa_gap_14_e_max as hsa_gap_14_e_max,hsa_gap_14_e_mean as hsa_gap_14_e_mean,hsa_gap_14_d_min as hsa_gap_14_d_min,hsa_gap_14_d_max as hsa_gap_14_d_max,hsa_gap_14_d_mean as hsa_gap_14_d_mean,hsa_force_14_el_min as hsa_force_14_el_min,hsa_force_14_el_max as hsa_force_14_el_max,hsa_force_14_el_mean as hsa_force_14_el_mean,hsa_force_14_er_min as hsa_force_14_er_min,hsa_force_14_er_max as hsa_force_14_er_max,hsa_force_14_er_mean as hsa_force_14_er_mean,hsa_force_14_dl_min as hsa_force_14_dl_min,hsa_force_14_dl_max as hsa_force_14_dl_max,hsa_force_14_dl_mean as hsa_force_14_dl_mean,hsa_force_14_dr_min as hsa_force_14_dr_min,hsa_force_14_dr_max as hsa_force_14_dr_max,hsa_force_14_dr_mean as hsa_force_14_dr_mean,hsa_tap_act_15_min as hsa_tap_act_15_min,hsa_tap_act_15_max as hsa_tap_act_15_max,hsa_tap_act_15_mean as hsa_tap_act_15_mean,hsa_gap_15_e_min as hsa_gap_15_e_min,hsa_gap_15_e_max as hsa_gap_15_e_max,hsa_gap_15_e_mean as hsa_gap_15_e_mean,hsa_gap_15_d_min as hsa_gap_15_d_min,hsa_gap_15_d_max as hsa_gap_15_d_max,hsa_gap_15_d_mean as hsa_gap_15_d_mean,hsa_force_15_el_min as hsa_force_15_el_min,hsa_force_15_el_max as hsa_force_15_el_max,hsa_force_15_el_mean as hsa_force_15_el_mean,hsa_force_15_er_min as hsa_force_15_er_min,hsa_force_15_er_max as hsa_force_15_er_max,hsa_force_15_er_mean as hsa_force_15_er_mean,hsa_force_15_dl_min as hsa_force_15_dl_min,hsa_force_15_dl_max as hsa_force_15_dl_max,hsa_force_15_dl_mean as hsa_force_15_dl_mean,hsa_force_15_dr_min as hsa_force_15_dr_min,hsa_force_15_dr_max as hsa_force_15_dr_max,hsa_force_15_dr_mean as hsa_force_15_dr_mean,hsa_tap_act_16_min as hsa_tap_act_16_min,hsa_tap_act_16_max as hsa_tap_act_16_max,hsa_tap_act_16_mean as hsa_tap_act_16_mean,hsa_gap_16_e_min as hsa_gap_16_e_min,hsa_gap_16_e_max as hsa_gap_16_e_max,hsa_gap_16_e_mean as hsa_gap_16_e_mean,hsa_gap_16_d_min as hsa_gap_16_d_min,hsa_gap_16_d_max as hsa_gap_16_d_max,hsa_gap_16_d_mean as hsa_gap_16_d_mean,hsa_force_16_el_min as hsa_force_16_el_min,hsa_force_16_el_max as hsa_force_16_el_max,hsa_force_16_el_mean as hsa_force_16_el_mean,hsa_force_16_er_min as hsa_force_16_er_min,hsa_force_16_er_max as hsa_force_16_er_max,hsa_force_16_er_mean as hsa_force_16_er_mean,hsa_force_16_dl_min as hsa_force_16_dl_min,hsa_force_16_dl_max as hsa_force_16_dl_max,hsa_force_16_dl_mean as hsa_force_16_dl_mean,hsa_force_16_dr_min as hsa_force_16_dr_min,hsa_force_16_dr_max as hsa_force_16_dr_max,hsa_force_16_dr_mean as hsa_force_16_dr_mean FROM [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB] WHERE slab_id='" + sladid + "' order by [iba_slab_cut_time] desc", connection);
            //SqlCommand sqlCmd = new SqlCommand("spDSR_Visualization", connection);
            ////if (connection.State == ConnectionState.Closed) connection.Open();
            //sqlCmd.CommandType = CommandType.StoredProcedure;
            //SqlParameter parameterSladID = new SqlParameter();
            //parameterSladID.ParameterName = "@slab_id";
            //parameterSladID.Value = sladid;
            //sqlCmd.Parameters.Add(parameterSladID);
            //sqlCmd.CommandTimeout = 3000;
            //SqlDataAdapter da = new SqlDataAdapter(sqlCmd);
            //dt.Clear();
            //da.Fill(dt);

            dt = objdatahandler.GetDataSetFromQuery("SELECT [slab_id],[l2_slab_cut_time],total_soft_reduction_act_out,total_soft_reduction_act_q4,total_soft_reduction_act_q3,total_soft_reduction_act_mean,total_soft_reduction_act_q2,total_soft_reduction_act_q1,total_soft_reduction_act_q0,total_soft_reduction_ref_out,total_soft_reduction_ref_q4,total_soft_reduction_ref_q3,total_soft_reduction_ref_mean,total_soft_reduction_ref_q2,total_soft_reduction_ref_q1,total_soft_reduction_ref_q0,[solid_seg_min] AS j_min,ROUND(solid_seg_mean,0)AS j_mode,[solid_seg_max] AS j_max,dsr_on_mean*100 AS [Dynamic soft reduction],therm_tap_tab_no_min AS [Thermal taper table number_Min],therm_tap_tab_no_max AS [Thermal taper table number_Max],sr_tab_no_min AS [Soft reduction table number_Min],sr_tab_no_max AS [Soft reduction table number_Max],ISNULL(hsa_speed_min,99)AS hsa_min,ISNULL(hsa_speed_mean,99)AS hsa_mean,ISNULL(hsa_speed_max,99)AS hsa_max,ISNULL(hsa_speed_stddev,99)AS hsa_stddev,CASE WHEN(abs(solid_len_act_mean - solid_len_dsc_mean)<= abs(solid_len_act_mean - solid_len_k_mean))THEN 'DSC' ELSE 'KF' END AS [Soft reduction mode],CASE WHEN scw_dsc_mode_mean >= 0.5 THEN 'DSC' ELSE 'L1' END AS [Secondary cooling mode],scw_l1_curve_min AS [Secondary cooling curve min],scw_l1_curve_max AS [Secondary cooling curve max],hsa_tap_act_10_min as hsa_tap_act_10_min,hsa_tap_act_10_max as hsa_tap_act_10_max,hsa_tap_act_10_mean as hsa_tap_act_10_mean,hsa_gap_10_e_min as hsa_gap_10_e_min,hsa_gap_10_e_max as hsa_gap_10_e_max,hsa_gap_10_e_mean as hsa_gap_10_e_mean,hsa_gap_10_d_min as hsa_gap_10_d_min,hsa_gap_10_d_max as hsa_gap_10_d_max,hsa_gap_10_d_mean as hsa_gap_10_d_mean,hsa_force_10_el_min as hsa_force_10_el_min,hsa_force_10_el_max as hsa_force_10_el_max,hsa_force_10_el_mean as hsa_force_10_el_mean,hsa_force_10_er_min as hsa_force_10_er_min,hsa_force_10_er_max as hsa_force_10_er_max,hsa_force_10_er_mean as hsa_force_10_er_mean,hsa_force_10_dl_min as hsa_force_10_dl_min,hsa_force_10_dl_max as hsa_force_10_dl_max,hsa_force_10_dl_mean as hsa_force_10_dl_mean,hsa_force_10_dr_min as hsa_force_10_dr_min,hsa_force_10_dr_max as hsa_force_10_dr_max,hsa_force_10_dr_mean as hsa_force_10_dr_mean,hsa_tap_act_11_min as hsa_tap_act_11_min,hsa_tap_act_11_max as hsa_tap_act_11_max,hsa_tap_act_11_mean as hsa_tap_act_11_mean,hsa_gap_11_e_min as hsa_gap_11_e_min,hsa_gap_11_e_max as hsa_gap_11_e_max,hsa_gap_11_e_mean as hsa_gap_11_e_mean,hsa_gap_11_d_min as hsa_gap_11_d_min,hsa_gap_11_d_max as hsa_gap_11_d_max,hsa_gap_11_d_mean as hsa_gap_11_d_mean,hsa_force_11_el_min as hsa_force_11_el_min,hsa_force_11_el_max as hsa_force_11_el_max,hsa_force_11_el_mean as hsa_force_11_el_mean,hsa_force_11_er_min as hsa_force_11_er_min,hsa_force_11_er_max as hsa_force_11_er_max,hsa_force_11_er_mean as hsa_force_11_er_mean,hsa_force_11_dl_min as hsa_force_11_dl_min,hsa_force_11_dl_max as hsa_force_11_dl_max,hsa_force_11_dl_mean as hsa_force_11_dl_mean,hsa_force_11_dr_min as hsa_force_11_dr_min,hsa_force_11_dr_max as hsa_force_11_dr_max,hsa_force_11_dr_mean as hsa_force_11_dr_mean,hsa_tap_act_12_min as hsa_tap_act_12_min,hsa_tap_act_12_max as hsa_tap_act_12_max,hsa_tap_act_12_mean as hsa_tap_act_12_mean,hsa_gap_12_e_min as hsa_gap_12_e_min,hsa_gap_12_e_max as hsa_gap_12_e_max,hsa_gap_12_e_mean as hsa_gap_12_e_mean,hsa_gap_12_d_min as hsa_gap_12_d_min,hsa_gap_12_d_max as hsa_gap_12_d_max,hsa_gap_12_d_mean as hsa_gap_12_d_mean,hsa_force_12_el_min as hsa_force_12_el_min,hsa_force_12_el_max as hsa_force_12_el_max,hsa_force_12_el_mean as hsa_force_12_el_mean,hsa_force_12_er_min as hsa_force_12_er_min,hsa_force_12_er_max as hsa_force_12_er_max,hsa_force_12_er_mean as hsa_force_12_er_mean,hsa_force_12_dl_min as hsa_force_12_dl_min,hsa_force_12_dl_max as hsa_force_12_dl_max,hsa_force_12_dl_mean as hsa_force_12_dl_mean,hsa_force_12_dr_min as hsa_force_12_dr_min,hsa_force_12_dr_max as hsa_force_12_dr_max,hsa_force_12_dr_mean as hsa_force_12_dr_mean,hsa_tap_act_13_min as hsa_tap_act_13_min,hsa_tap_act_13_max as hsa_tap_act_13_max,hsa_tap_act_13_mean as hsa_tap_act_13_mean,hsa_gap_13_e_min as hsa_gap_13_e_min,hsa_gap_13_e_max as hsa_gap_13_e_max,hsa_gap_13_e_mean as hsa_gap_13_e_mean,hsa_gap_13_d_min as hsa_gap_13_d_min,hsa_gap_13_d_max as hsa_gap_13_d_max,hsa_gap_13_d_mean as hsa_gap_13_d_mean,hsa_force_13_el_min as hsa_force_13_el_min,hsa_force_13_el_max as hsa_force_13_el_max,hsa_force_13_el_mean as hsa_force_13_el_mean,hsa_force_13_er_min as hsa_force_13_er_min,hsa_force_13_er_max as hsa_force_13_er_max,hsa_force_13_er_mean as hsa_force_13_er_mean,hsa_force_13_dl_min as hsa_force_13_dl_min,hsa_force_13_dl_max as hsa_force_13_dl_max,hsa_force_13_dl_mean as hsa_force_13_dl_mean,hsa_force_13_dr_min as hsa_force_13_dr_min,hsa_force_13_dr_max as hsa_force_13_dr_max,hsa_force_13_dr_mean as hsa_force_13_dr_mean,hsa_tap_act_14_min as hsa_tap_act_14_min,hsa_tap_act_14_max as hsa_tap_act_14_max,hsa_tap_act_14_mean as hsa_tap_act_14_mean,hsa_gap_14_e_min as hsa_gap_14_e_min,hsa_gap_14_e_max as hsa_gap_14_e_max,hsa_gap_14_e_mean as hsa_gap_14_e_mean,hsa_gap_14_d_min as hsa_gap_14_d_min,hsa_gap_14_d_max as hsa_gap_14_d_max,hsa_gap_14_d_mean as hsa_gap_14_d_mean,hsa_force_14_el_min as hsa_force_14_el_min,hsa_force_14_el_max as hsa_force_14_el_max,hsa_force_14_el_mean as hsa_force_14_el_mean,hsa_force_14_er_min as hsa_force_14_er_min,hsa_force_14_er_max as hsa_force_14_er_max,hsa_force_14_er_mean as hsa_force_14_er_mean,hsa_force_14_dl_min as hsa_force_14_dl_min,hsa_force_14_dl_max as hsa_force_14_dl_max,hsa_force_14_dl_mean as hsa_force_14_dl_mean,hsa_force_14_dr_min as hsa_force_14_dr_min,hsa_force_14_dr_max as hsa_force_14_dr_max,hsa_force_14_dr_mean as hsa_force_14_dr_mean,hsa_tap_act_15_min as hsa_tap_act_15_min,hsa_tap_act_15_max as hsa_tap_act_15_max,hsa_tap_act_15_mean as hsa_tap_act_15_mean,hsa_gap_15_e_min as hsa_gap_15_e_min,hsa_gap_15_e_max as hsa_gap_15_e_max,hsa_gap_15_e_mean as hsa_gap_15_e_mean,hsa_gap_15_d_min as hsa_gap_15_d_min,hsa_gap_15_d_max as hsa_gap_15_d_max,hsa_gap_15_d_mean as hsa_gap_15_d_mean,hsa_force_15_el_min as hsa_force_15_el_min,hsa_force_15_el_max as hsa_force_15_el_max,hsa_force_15_el_mean as hsa_force_15_el_mean,hsa_force_15_er_min as hsa_force_15_er_min,hsa_force_15_er_max as hsa_force_15_er_max,hsa_force_15_er_mean as hsa_force_15_er_mean,hsa_force_15_dl_min as hsa_force_15_dl_min,hsa_force_15_dl_max as hsa_force_15_dl_max,hsa_force_15_dl_mean as hsa_force_15_dl_mean,hsa_force_15_dr_min as hsa_force_15_dr_min,hsa_force_15_dr_max as hsa_force_15_dr_max,hsa_force_15_dr_mean as hsa_force_15_dr_mean,hsa_tap_act_16_min as hsa_tap_act_16_min,hsa_tap_act_16_max as hsa_tap_act_16_max,hsa_tap_act_16_mean as hsa_tap_act_16_mean,hsa_gap_16_e_min as hsa_gap_16_e_min,hsa_gap_16_e_max as hsa_gap_16_e_max,hsa_gap_16_e_mean as hsa_gap_16_e_mean,hsa_gap_16_d_min as hsa_gap_16_d_min,hsa_gap_16_d_max as hsa_gap_16_d_max,hsa_gap_16_d_mean as hsa_gap_16_d_mean,hsa_force_16_el_min as hsa_force_16_el_min,hsa_force_16_el_max as hsa_force_16_el_max,hsa_force_16_el_mean as hsa_force_16_el_mean,hsa_force_16_er_min as hsa_force_16_er_min,hsa_force_16_er_max as hsa_force_16_er_max,hsa_force_16_er_mean as hsa_force_16_er_mean,hsa_force_16_dl_min as hsa_force_16_dl_min,hsa_force_16_dl_max as hsa_force_16_dl_max,hsa_force_16_dl_mean as hsa_force_16_dl_mean,hsa_force_16_dr_min as hsa_force_16_dr_min,hsa_force_16_dr_max as hsa_force_16_dr_max,hsa_force_16_dr_mean as hsa_force_16_dr_mean FROM [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB] WHERE slab_id='" + sladid + "' order by [l2_slab_cut_time] desc").Tables[0];
            return dt;
        //}

    }
    //Commented on 07-Oct-2022
    //protected void ddlSlab_id_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    //GetData_slab_id(hfFrom.Value, hfTo.Value);
    //    DataTable dt = BindData(ddlSlab_id.SelectedItem.Value);
    //    GetData_Grade(ddlSlab_id.SelectedItem.Value);
    //    GetData();

    //}

    protected void txtDate1_TextChanged(object sender, EventArgs e)
    {
        GetData_slab_id(hfFrom.Value, hfTo.Value);
    }
    protected void GetData_slab_id(string strfrmDt, string strToDt)
    {
        DataTable dt = new DataTable();
        string cs = ConfigurationManager.ConnectionStrings["TG-GWL"].ConnectionString;

        //using (SqlConnection con = new SqlConnection(cs))
        //{
        //    SqlCommand cmd = new SqlCommand("SELECT [slab_id],[iba_slab_cut_time]   FROM [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB] where mod_status IN(11, 1, 21, 31) and [iba_slab_cut_time] between '" + strfrmDt + "' and '" + strToDt + "' order by [iba_slab_cut_time] desc", con); 
            //SqlCommand cmd = new SqlCommand("spDSR_SlabID", con);
            //cmd.CommandType = CommandType.StoredProcedure;

            //SqlParameter parameterFrom = new SqlParameter();
            //parameterFrom.ParameterName = "@DateFrom";
            //parameterFrom.Value = strfrmDt;
            //cmd.Parameters.Add(parameterFrom);

            //SqlParameter parameterTo = new SqlParameter();
            //parameterTo.ParameterName = "@DateTo";
            //parameterTo.Value = strToDt;
            //cmd.Parameters.Add(parameterTo);
            //if (con.State==ConnectionState.Closed) con.Open();
            //cmd.CommandTimeout = 3000;
            //SqlDataAdapter da = new SqlDataAdapter(cmd);
            //da.Fill(dt);

            dt = objdatahandler.GetDataSetFromQuery("SELECT [slab_id],[l2_slab_cut_time]   FROM [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB] where mod_status IN(11, 1, 21, 31) and [l2_slab_cut_time] between '" + strfrmDt + "' and '" + strToDt + "' order by[l2_slab_cut_time] desc").Tables[0];

            
            //SqlDataReader rdr = cmd.ExecuteReader();
            ddlSlab_id.DataSource = dt;
                        ddlSlab_id.DataTextField = "slab_id";
            ddlSlab_id.DataValueField = "slab_id";
            //ddlSlab_id.DataSource = rdr;
            ddlSlab_id.DataBind();

            //SqlDataAdapter da = new SqlDataAdapter(cmd);
            //dt.Clear();
            //da.Fill(dt);
            //return dt;

        //}
        //string qry = "SELECT [slab_id],[iba_slab_cut_time]   FROM [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB] where mod_status IN(11,1,21) and [iba_slab_cut_time] between '" + strfrmDt + "' and '" + strToDt + "' order by [iba_slab_cut_time] desc";

        //string cs = ConfigurationManager.ConnectionStrings["TG-GWL"].ConnectionString;
        //using (SqlConnection con = new SqlConnection(cs))
        //{
        //    SqlCommand cmd = new SqlCommand(qry, con);
        //    con.Open();
        //    SqlDataReader rdr = cmd.ExecuteReader();
        //    ddlSlab_id.DataTextField = "slab_id";
        //    ddlSlab_id.DataSource = rdr;
        //    ddlSlab_id.DataBind();

        //}
    }

    protected void GetData()
    {
        DataTable dt_DSR;
        DataTable dt_Grade;

        if (txtSlabId.Text!="")
        {
            dt_DSR = BindData(txtSlabId.Text);
            dt_Grade = GetData_Grade(txtSlabId.Text);
        }
        else
        {
            dt_DSR = BindData(ddlSlab_id.SelectedItem.Value);
            dt_Grade = GetData_Grade(ddlSlab_id.SelectedItem.Value);
        }
        if (dt_Grade.Rows.Count > 0)
        {
            lblGrade.Text = dt_Grade.Rows[0]["GRADE_CODE"].ToString();
        }

        if (dt_DSR.Rows.Count > 0)
        {
            litChart1.Text = BoxPlot(dt_DSR);
			litChart2.Text = LinePlot(dt_DSR);
			litChart3.Text = LinePlot1(dt_DSR);
            lblJmode.Text = dt_DSR.Rows[0]["j_mode"].ToString();
            int J_Mode = (int)Convert.ToDouble(lblJmode.Text);
            string prepend = DateTime.Now.Ticks.ToString();
            if (J_Mode == 10)
            {

                Image1.ImageUrl = "images/Caster_DSR3_J1.png?" + prepend;
                Image2.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image3.ImageUrl = "images/Caster_DSR3_J1.png?" + prepend;
                Image4.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image5.ImageUrl = "images/Caster_DSR3_J1.png?" + prepend;
                Image6.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image7.ImageUrl = "images/Caster_DSR3_J1.png?" + prepend;
                Image8.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image9.ImageUrl = "images/Caster_DSR3_J1.png?" + prepend;
                Image10.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image11.ImageUrl = "images/Caster_DSR3_J1.png?" + prepend;
                Image12.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image13.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image14.ImageUrl = "images/Caster_DSR3_J1.png?" + prepend;
                Image15.ImageUrl = "images/Line_Verticle.png?" + prepend;

                TextBox1.Text = "J";
                TextBox2.Text = "";
                TextBox3.Text = "";
                TextBox4.Text = "";
                TextBox5.Text = "";
                TextBox6.Text = "";
                TextBox7.Text = "";
            }

            if (J_Mode == 11)
            {
                Image1.ImageUrl = "images/Caster_DSR3_J.png?" + prepend;
                Image2.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image3.ImageUrl = "images/Caster_DSR3_J1.png?" + prepend;
                Image4.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image5.ImageUrl = "images/Caster_DSR3_J1.png?" + prepend;
                Image6.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image7.ImageUrl = "images/Caster_DSR3_J1.png?" + prepend;
                Image8.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image9.ImageUrl = "images/Caster_DSR3_J1.png?" + prepend;
                Image10.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image11.ImageUrl = "images/Caster_DSR3_J1.png?" + prepend;
                Image12.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image13.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image14.ImageUrl = "images/Caster_DSR3_J1.png?" + prepend;
                Image15.ImageUrl = "images/Line_Verticle.png?" + prepend;

                TextBox1.Text = "J-1";
                TextBox2.Text = "J";
                TextBox3.Text = "";
                TextBox4.Text = "";
                TextBox5.Text = "";
                TextBox6.Text = "";
                TextBox7.Text = "";
            }
            if (J_Mode == 12)
            {
                Image1.ImageUrl = "images/Caster_DSR3_J-1.png?" + prepend;
                Image2.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image3.ImageUrl = "images/Caster_DSR3_J.png?" + prepend;
                Image4.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image5.ImageUrl = "images/Caster_DSR3_J1.png?" + prepend;
                Image6.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image7.ImageUrl = "images/Caster_DSR3_J1.png?" + prepend;
                Image8.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image9.ImageUrl = "images/Caster_DSR3_J1.png?" + prepend;
                Image10.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image11.ImageUrl = "images/Caster_DSR3_J1.png?" + prepend;
                Image12.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image13.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image14.ImageUrl = "images/Caster_DSR3_J1.png?" + prepend;
                Image15.ImageUrl = "images/Line_Verticle.png?" + prepend;

                TextBox1.Text = "J-2";
                TextBox2.Text = "J-1";
                TextBox3.Text = "J";
                TextBox4.Text = "";
                TextBox5.Text = "";
                TextBox6.Text = "";
                TextBox7.Text = "";
            }
            if (J_Mode == 13)
            {

                Image1.ImageUrl = "images/Caster_DSR3_J-1.png?" + prepend;
                Image2.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image3.ImageUrl = "images/Caster_DSR3_J-1.png?" + prepend;
                Image4.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image5.ImageUrl = "images/Caster_DSR3_J.png?" + prepend;
                Image6.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image7.ImageUrl = "images/Caster_DSR3_J1.png?" + prepend;
                Image8.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image9.ImageUrl = "images/Caster_DSR3_J1.png?" + prepend;
                Image10.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image11.ImageUrl = "images/Caster_DSR3_J1.png?" + prepend;
                Image12.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image13.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image14.ImageUrl = "images/Caster_DSR3_J1.png?" + prepend;
                Image15.ImageUrl = "images/Line_Verticle.png?" + prepend;

                TextBox1.Text = "J-3";
                TextBox2.Text = "J-2";
                TextBox3.Text = "J-1";
                TextBox4.Text = "J";
                TextBox5.Text = "";
                TextBox6.Text = "";
                TextBox7.Text = "";
            }
            if (J_Mode == 14)
            {
                Image1.ImageUrl = "images/Caster_DSR3_J-1.png?" + prepend;
                Image2.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image3.ImageUrl = "images/Caster_DSR3_J-1.png?" + prepend;
                Image4.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image5.ImageUrl = "images/Caster_DSR3_J-1.png?" + prepend;
                Image6.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image7.ImageUrl = "images/Caster_DSR3_J.png?" + prepend;
                Image8.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image9.ImageUrl = "images/Caster_DSR3_J1.png?" + prepend;
                Image10.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image11.ImageUrl = "images/Caster_DSR3_J1.png?" + prepend;
                Image12.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image13.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image14.ImageUrl = "images/Caster_DSR3_J1.png?" + prepend;
                Image15.ImageUrl = "images/Line_Verticle.png?" + prepend;

                TextBox1.Text = "J-4";
                TextBox2.Text = "J-3";
                TextBox3.Text = "J-2";
                TextBox4.Text = "J-1";
                TextBox5.Text = "J";
                TextBox6.Text = "";
                TextBox7.Text = "";
            }
            if (J_Mode == 15)
            {
                Image1.ImageUrl = "images/Caster_DSR3_J-1.png?" + prepend;
                Image2.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image3.ImageUrl = "images/Caster_DSR3_J-1.png?" + prepend;
                Image4.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image5.ImageUrl = "images/Caster_DSR3_J-1.png?" + prepend;
                Image6.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image7.ImageUrl = "images/Caster_DSR3_J-1.png?" + prepend;
                Image8.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image9.ImageUrl = "images/Caster_DSR3_J.png?" + prepend;
                Image10.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image11.ImageUrl = "images/Caster_DSR3_J1.png?" + prepend;
                Image12.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image13.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image14.ImageUrl = "images/Caster_DSR3_J1.png?" + prepend;
                Image15.ImageUrl = "images/Line_Verticle.png?" + prepend;

                TextBox1.Text = "J-5";
                TextBox2.Text = "J-4";
                TextBox3.Text = "J-3";
                TextBox4.Text = "J-2";
                TextBox5.Text = "J-1";
                TextBox6.Text = "J";
                TextBox7.Text = "";
            }
            if (J_Mode == 16)
            {

                Image1.ImageUrl = "images/Caster_DSR3_J-1.png?" + prepend;
                Image2.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image3.ImageUrl = "images/Caster_DSR3_J-1.png?" + prepend;
                Image4.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image5.ImageUrl = "images/Caster_DSR3_J-1.png?" + prepend;
                Image6.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image7.ImageUrl = "images/Caster_DSR3_J-1.png?" + prepend;
                Image8.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image9.ImageUrl = "images/Caster_DSR3_J-1.png?" + prepend;
                Image10.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image11.ImageUrl = "images/Caster_DSR3_J.png?" + prepend;
                Image12.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image13.ImageUrl = "images/Line_Verticle.png?" + prepend;
                Image14.ImageUrl = "images/Caster_DSR3_J1.png?" + prepend;
                Image15.ImageUrl = "images/Line_Verticle.png?" + prepend;

                TextBox1.Text = "J-6";
                TextBox2.Text = "J-5";
                TextBox3.Text = "J-4";
                TextBox4.Text = "J-3";
                TextBox5.Text = "J-2";
                TextBox6.Text = "J-1";
                TextBox7.Text = "J";
            }
        }



        if (dt_DSR.Rows.Count > 0)
        {
            lblSlab_ID.Text = dt_DSR.Rows[0]["slab_id"].ToString();

            lblDSR.Text = dt_DSR.Rows[0]["Dynamic soft reduction"].ToString();
            lblTTN_min.Text = dt_DSR.Rows[0]["Thermal taper table number_Min"].ToString();
            lblTTN_max.Text = dt_DSR.Rows[0]["Thermal taper table number_Max"].ToString();
            lblSRT_min.Text = dt_DSR.Rows[0]["Soft reduction table number_Min"].ToString();
            lblSRT_max.Text = dt_DSR.Rows[0]["Soft reduction table number_Max"].ToString();
            lblSRM.Text = dt_DSR.Rows[0]["Soft reduction mode"].ToString();
            lblSCM.Text = dt_DSR.Rows[0]["Secondary cooling mode"].ToString();
            lblSCC_min.Text = dt_DSR.Rows[0]["Secondary cooling curve min"].ToString();
            lblSCC_max.Text = dt_DSR.Rows[0]["Secondary cooling curve max"].ToString();

            lblJmin.Text = dt_DSR.Rows[0]["j_min"].ToString();
            lblJmax.Text = dt_DSR.Rows[0]["j_max"].ToString();
            lblJmode.Text = dt_DSR.Rows[0]["j_mode"].ToString();

            //HSA casting speed
            lblHSAMax.Text = dt_DSR.Rows[0]["hsa_max"].ToString();
            int HSAMax = (int)Convert.ToDouble(lblHSAMax.Text);
            if(HSAMax==99)
            {
                lblHSAMax.Text = "NA";
            }
            
            lblHSAMean.Text = dt_DSR.Rows[0]["hsa_mean"].ToString();
            int HSAMean = (int)Convert.ToDouble(lblHSAMean.Text);
            if (HSAMean == 99)
            {
                lblHSAMean.Text = "NA";
            }

            lblHSAMin.Text = dt_DSR.Rows[0]["hsa_min"].ToString();
            int HSAMin = (int)Convert.ToDouble(lblHSAMin.Text);
            if (HSAMin == 99)
            {
                lblHSAMin.Text = "NA";
            }
            lblHSAStdDev.Text = dt_DSR.Rows[0]["hsa_stddev"].ToString();
            int HSAStdDev = (int)Convert.ToDouble(lblHSAStdDev.Text);
            if (HSAStdDev == 99)
            {
                lblHSAStdDev.Text = "NA";
            }
            //HSA taper
            lblHSA_10_min.Text = dt_DSR.Rows[0]["hsa_tap_act_10_min"].ToString();
            lblHSA_10_max.Text = dt_DSR.Rows[0]["hsa_tap_act_10_max"].ToString();
            lblHSA_10_mean.Text = dt_DSR.Rows[0]["hsa_tap_act_10_mean"].ToString();
            lblHSA_11_min.Text = dt_DSR.Rows[0]["hsa_tap_act_11_min"].ToString();
            lblHSA_11_max.Text = dt_DSR.Rows[0]["hsa_tap_act_11_max"].ToString();
            lblHSA_11_mean.Text = dt_DSR.Rows[0]["hsa_tap_act_11_mean"].ToString();
            lblHSA_12_min.Text = dt_DSR.Rows[0]["hsa_tap_act_12_min"].ToString();
            lblHSA_12_max.Text = dt_DSR.Rows[0]["hsa_tap_act_12_max"].ToString();
            lblHSA_12_mean.Text = dt_DSR.Rows[0]["hsa_tap_act_12_mean"].ToString();
            lblHSA_13_min.Text = dt_DSR.Rows[0]["hsa_tap_act_13_min"].ToString();
            lblHSA_13_max.Text = dt_DSR.Rows[0]["hsa_tap_act_13_max"].ToString();
            lblHSA_13_mean.Text = dt_DSR.Rows[0]["hsa_tap_act_13_mean"].ToString();
            lblHSA_14_min.Text = dt_DSR.Rows[0]["hsa_tap_act_14_min"].ToString();
            lblHSA_14_max.Text = dt_DSR.Rows[0]["hsa_tap_act_14_max"].ToString();
            lblHSA_14_mean.Text = dt_DSR.Rows[0]["hsa_tap_act_14_mean"].ToString();
            lblHSA_15_min.Text = dt_DSR.Rows[0]["hsa_tap_act_15_min"].ToString();
            lblHSA_15_max.Text = dt_DSR.Rows[0]["hsa_tap_act_15_max"].ToString();
            lblHSA_15_mean.Text = dt_DSR.Rows[0]["hsa_tap_act_15_mean"].ToString();
            lblHSA_16_min.Text = dt_DSR.Rows[0]["hsa_tap_act_16_min"].ToString();
            lblHSA_16_max.Text = dt_DSR.Rows[0]["hsa_tap_act_16_max"].ToString();
            lblHSA_16_mean.Text = dt_DSR.Rows[0]["hsa_tap_act_16_mean"].ToString();
            //Entry gap mm
            lblEntrygap_10_min.Text = dt_DSR.Rows[0]["hsa_gap_10_e_min"].ToString();
            lblEntrygap_10_max.Text = dt_DSR.Rows[0]["hsa_gap_10_e_max"].ToString();
            lblEntrygap_10_mean.Text = dt_DSR.Rows[0]["hsa_gap_10_e_mean"].ToString();
            lblEntrygap_11_min.Text = dt_DSR.Rows[0]["hsa_gap_11_e_min"].ToString();
            lblEntrygap_11_max.Text = dt_DSR.Rows[0]["hsa_gap_11_e_max"].ToString();
            lblEntrygap_11_mean.Text = dt_DSR.Rows[0]["hsa_gap_11_e_mean"].ToString();
            lblEntrygap_12_min.Text = dt_DSR.Rows[0]["hsa_gap_12_e_min"].ToString();
            lblEntrygap_12_max.Text = dt_DSR.Rows[0]["hsa_gap_12_e_max"].ToString();
            lblEntrygap_12_mean.Text = dt_DSR.Rows[0]["hsa_gap_12_e_mean"].ToString();
            lblEntrygap_13_min.Text = dt_DSR.Rows[0]["hsa_gap_13_e_min"].ToString();
            lblEntrygap_13_max.Text = dt_DSR.Rows[0]["hsa_gap_13_e_max"].ToString();
            lblEntrygap_13_mean.Text = dt_DSR.Rows[0]["hsa_gap_13_e_mean"].ToString();
            lblEntrygap_14_min.Text = dt_DSR.Rows[0]["hsa_gap_14_e_min"].ToString();
            lblEntrygap_14_max.Text = dt_DSR.Rows[0]["hsa_gap_14_e_max"].ToString();
            lblEntrygap_14_mean.Text = dt_DSR.Rows[0]["hsa_gap_14_e_mean"].ToString();
            lblEntrygap_15_min.Text = dt_DSR.Rows[0]["hsa_gap_15_e_min"].ToString();
            lblEntrygap_15_max.Text = dt_DSR.Rows[0]["hsa_gap_15_e_max"].ToString();
            lblEntrygap_15_mean.Text = dt_DSR.Rows[0]["hsa_gap_15_e_mean"].ToString();
            lblEntrygap_16_min.Text = dt_DSR.Rows[0]["hsa_gap_16_e_min"].ToString();
            lblEntrygap_16_max.Text = dt_DSR.Rows[0]["hsa_gap_16_e_max"].ToString();
            lblEntrygap_16_mean.Text = dt_DSR.Rows[0]["hsa_gap_16_e_mean"].ToString();
            //Exit gap mm
            lblExitgap_10_min.Text = dt_DSR.Rows[0]["hsa_gap_10_d_min"].ToString();
            lblExitgap_10_max.Text = dt_DSR.Rows[0]["hsa_gap_10_d_max"].ToString();
            lblExitgap_10_mean.Text = dt_DSR.Rows[0]["hsa_gap_10_d_mean"].ToString();
            lblExitgap_11_min.Text = dt_DSR.Rows[0]["hsa_gap_11_d_min"].ToString();
            lblExitgap_11_max.Text = dt_DSR.Rows[0]["hsa_gap_11_d_max"].ToString();
            lblExitgap_11_mean.Text = dt_DSR.Rows[0]["hsa_gap_11_d_mean"].ToString();
            lblExitgap_12_min.Text = dt_DSR.Rows[0]["hsa_gap_12_d_min"].ToString();
            lblExitgap_12_max.Text = dt_DSR.Rows[0]["hsa_gap_12_d_max"].ToString();
            lblExitgap_12_mean.Text = dt_DSR.Rows[0]["hsa_gap_12_d_mean"].ToString();
            lblExitgap_13_min.Text = dt_DSR.Rows[0]["hsa_gap_13_d_min"].ToString();
            lblExitgap_13_max.Text = dt_DSR.Rows[0]["hsa_gap_13_d_max"].ToString();
            lblExitgap_13_mean.Text = dt_DSR.Rows[0]["hsa_gap_13_d_mean"].ToString();
            lblExitgap_14_min.Text = dt_DSR.Rows[0]["hsa_gap_14_d_min"].ToString();
            lblExitgap_14_max.Text = dt_DSR.Rows[0]["hsa_gap_14_d_max"].ToString();
            lblExitgap_14_mean.Text = dt_DSR.Rows[0]["hsa_gap_14_d_mean"].ToString();
            lblExitgap_15_min.Text = dt_DSR.Rows[0]["hsa_gap_15_d_min"].ToString();
            lblExitgap_15_max.Text = dt_DSR.Rows[0]["hsa_gap_15_d_max"].ToString();
            lblExitgap_15_mean.Text = dt_DSR.Rows[0]["hsa_gap_15_d_mean"].ToString();
            lblExitgap_16_min.Text = dt_DSR.Rows[0]["hsa_gap_16_d_min"].ToString();
            lblExitgap_16_max.Text = dt_DSR.Rows[0]["hsa_gap_16_d_max"].ToString();
            lblExitgap_16_mean.Text = dt_DSR.Rows[0]["hsa_gap_16_d_mean"].ToString();

            //HSA force entry Left kN
            lblForceEntryLeft_10_min.Text = dt_DSR.Rows[0]["hsa_force_10_el_min"].ToString();
            lblForceEntryLeft_10_max.Text = dt_DSR.Rows[0]["hsa_force_10_el_max"].ToString();
            lblForceEntryLeft_10_mean.Text = dt_DSR.Rows[0]["hsa_force_10_el_mean"].ToString();
            lblForceEntryLeft_11_min.Text = dt_DSR.Rows[0]["hsa_force_11_el_min"].ToString();
            lblForceEntryLeft_11_max.Text = dt_DSR.Rows[0]["hsa_force_11_el_max"].ToString();
            lblForceEntryLeft_11_mean.Text = dt_DSR.Rows[0]["hsa_force_11_el_mean"].ToString();
            lblForceEntryLeft_12_min.Text = dt_DSR.Rows[0]["hsa_force_12_el_min"].ToString();
            lblForceEntryLeft_12_max.Text = dt_DSR.Rows[0]["hsa_force_12_el_max"].ToString();
            lblForceEntryLeft_12_mean.Text = dt_DSR.Rows[0]["hsa_force_12_el_mean"].ToString();
            lblForceEntryLeft_13_min.Text = dt_DSR.Rows[0]["hsa_force_13_el_min"].ToString();
            lblForceEntryLeft_13_max.Text = dt_DSR.Rows[0]["hsa_force_13_el_max"].ToString();
            lblForceEntryLeft_13_mean.Text = dt_DSR.Rows[0]["hsa_force_13_el_mean"].ToString();
            lblForceEntryLeft_14_min.Text = dt_DSR.Rows[0]["hsa_force_14_el_min"].ToString();
            lblForceEntryLeft_14_max.Text = dt_DSR.Rows[0]["hsa_force_14_el_max"].ToString();
            lblForceEntryLeft_14_mean.Text = dt_DSR.Rows[0]["hsa_force_14_el_mean"].ToString();
            lblForceEntryLeft_15_min.Text = dt_DSR.Rows[0]["hsa_force_15_el_min"].ToString();
            lblForceEntryLeft_15_max.Text = dt_DSR.Rows[0]["hsa_force_15_el_max"].ToString();
            lblForceEntryLeft_15_mean.Text = dt_DSR.Rows[0]["hsa_force_15_el_mean"].ToString();
            lblForceEntryLeft_16_min.Text = dt_DSR.Rows[0]["hsa_force_16_el_min"].ToString();
            lblForceEntryLeft_16_max.Text = dt_DSR.Rows[0]["hsa_force_16_el_max"].ToString();
            lblForceEntryLeft_16_mean.Text = dt_DSR.Rows[0]["hsa_force_16_el_mean"].ToString();

            //HSA force entry right kN
            lblForceEntryRight_10_min.Text = dt_DSR.Rows[0]["hsa_force_10_er_min"].ToString();
            lblForceEntryRight_10_max.Text = dt_DSR.Rows[0]["hsa_force_10_er_max"].ToString();
            lblForceEntryRight_10_mean.Text = dt_DSR.Rows[0]["hsa_force_10_er_mean"].ToString();
            lblForceEntryRight_11_min.Text = dt_DSR.Rows[0]["hsa_force_11_er_min"].ToString();
            lblForceEntryRight_11_max.Text = dt_DSR.Rows[0]["hsa_force_11_er_max"].ToString();
            lblForceEntryRight_11_mean.Text = dt_DSR.Rows[0]["hsa_force_11_er_mean"].ToString();
            lblForceEntryRight_12_min.Text = dt_DSR.Rows[0]["hsa_force_12_er_min"].ToString();
            lblForceEntryRight_12_max.Text = dt_DSR.Rows[0]["hsa_force_12_er_max"].ToString();
            lblForceEntryRight_12_mean.Text = dt_DSR.Rows[0]["hsa_force_12_er_mean"].ToString();
            lblForceEntryRight_13_min.Text = dt_DSR.Rows[0]["hsa_force_13_er_min"].ToString();
            lblForceEntryRight_13_max.Text = dt_DSR.Rows[0]["hsa_force_13_er_max"].ToString();
            lblForceEntryRight_13_mean.Text = dt_DSR.Rows[0]["hsa_force_13_er_mean"].ToString();
            lblForceEntryRight_14_min.Text = dt_DSR.Rows[0]["hsa_force_14_er_min"].ToString();
            lblForceEntryRight_14_max.Text = dt_DSR.Rows[0]["hsa_force_14_er_max"].ToString();
            lblForceEntryRight_14_mean.Text = dt_DSR.Rows[0]["hsa_force_14_er_mean"].ToString();
            lblForceEntryRight_15_min.Text = dt_DSR.Rows[0]["hsa_force_15_er_min"].ToString();
            lblForceEntryRight_15_max.Text = dt_DSR.Rows[0]["hsa_force_15_er_max"].ToString();
            lblForceEntryRight_15_mean.Text = dt_DSR.Rows[0]["hsa_force_15_er_mean"].ToString();
            lblForceEntryRight_16_min.Text = dt_DSR.Rows[0]["hsa_force_16_er_min"].ToString();
            lblForceEntryRight_16_max.Text = dt_DSR.Rows[0]["hsa_force_16_er_max"].ToString();
            lblForceEntryRight_16_mean.Text = dt_DSR.Rows[0]["hsa_force_16_er_mean"].ToString();

            //HSA force exit left kN
            lblForceExitLeft_10_min.Text = dt_DSR.Rows[0]["hsa_force_10_dl_min"].ToString();
            lblForceExitLeft_10_max.Text = dt_DSR.Rows[0]["hsa_force_10_dl_max"].ToString();
            lblForceExitLeft_10_mean.Text = dt_DSR.Rows[0]["hsa_force_10_dl_mean"].ToString();
            lblForceExitLeft_11_min.Text = dt_DSR.Rows[0]["hsa_force_11_dl_min"].ToString();
            lblForceExitLeft_11_max.Text = dt_DSR.Rows[0]["hsa_force_11_dl_max"].ToString();
            lblForceExitLeft_11_mean.Text = dt_DSR.Rows[0]["hsa_force_11_dl_mean"].ToString();
            lblForceExitLeft_12_min.Text = dt_DSR.Rows[0]["hsa_force_12_dl_min"].ToString();
            lblForceExitLeft_12_max.Text = dt_DSR.Rows[0]["hsa_force_12_dl_max"].ToString();
            lblForceExitLeft_12_mean.Text = dt_DSR.Rows[0]["hsa_force_12_dl_mean"].ToString();
            lblForceExitLeft_13_min.Text = dt_DSR.Rows[0]["hsa_force_13_dl_min"].ToString();
            lblForceExitLeft_13_max.Text = dt_DSR.Rows[0]["hsa_force_13_dl_max"].ToString();
            lblForceExitLeft_13_mean.Text = dt_DSR.Rows[0]["hsa_force_13_dl_mean"].ToString();
            lblForceExitLeft_14_min.Text = dt_DSR.Rows[0]["hsa_force_14_dl_min"].ToString();
            lblForceExitLeft_14_max.Text = dt_DSR.Rows[0]["hsa_force_14_dl_max"].ToString();
            lblForceExitLeft_14_mean.Text = dt_DSR.Rows[0]["hsa_force_14_dl_mean"].ToString();
            lblForceExitLeft_15_min.Text = dt_DSR.Rows[0]["hsa_force_15_dl_min"].ToString();
            lblForceExitLeft_15_max.Text = dt_DSR.Rows[0]["hsa_force_15_dl_max"].ToString();
            lblForceExitLeft_15_mean.Text = dt_DSR.Rows[0]["hsa_force_15_dl_mean"].ToString();
            lblForceExitLeft_16_min.Text = dt_DSR.Rows[0]["hsa_force_16_dl_min"].ToString();
            lblForceExitLeft_16_max.Text = dt_DSR.Rows[0]["hsa_force_16_dl_max"].ToString();
            lblForceExitLeft_16_mean.Text = dt_DSR.Rows[0]["hsa_force_16_dl_mean"].ToString();

            //HSA force exit right kN
            lblForceExitRight_10_min.Text = dt_DSR.Rows[0]["hsa_force_10_dr_min"].ToString();
            lblForceExitRight_10_max.Text = dt_DSR.Rows[0]["hsa_force_10_dr_max"].ToString();
            lblForceExitRight_10_mean.Text = dt_DSR.Rows[0]["hsa_force_10_dr_mean"].ToString();
            lblForceExitRight_11_min.Text = dt_DSR.Rows[0]["hsa_force_11_dr_min"].ToString();
            lblForceExitRight_11_max.Text = dt_DSR.Rows[0]["hsa_force_11_dr_max"].ToString();
            lblForceExitRight_11_mean.Text = dt_DSR.Rows[0]["hsa_force_11_dr_mean"].ToString();
            lblForceExitRight_12_min.Text = dt_DSR.Rows[0]["hsa_force_12_dr_min"].ToString();
            lblForceExitRight_12_max.Text = dt_DSR.Rows[0]["hsa_force_12_dr_max"].ToString();
            lblForceExitRight_12_mean.Text = dt_DSR.Rows[0]["hsa_force_12_dr_mean"].ToString();
            lblForceExitRight_13_min.Text = dt_DSR.Rows[0]["hsa_force_13_dr_min"].ToString();
            lblForceExitRight_13_max.Text = dt_DSR.Rows[0]["hsa_force_13_dr_max"].ToString();
            lblForceExitRight_13_mean.Text = dt_DSR.Rows[0]["hsa_force_13_dr_mean"].ToString();
            lblForceExitRight_14_min.Text = dt_DSR.Rows[0]["hsa_force_14_dr_min"].ToString();
            lblForceExitRight_14_max.Text = dt_DSR.Rows[0]["hsa_force_14_dr_max"].ToString();
            lblForceExitRight_14_mean.Text = dt_DSR.Rows[0]["hsa_force_14_dr_mean"].ToString();
            lblForceExitRight_15_min.Text = dt_DSR.Rows[0]["hsa_force_15_dr_min"].ToString();
            lblForceExitRight_15_max.Text = dt_DSR.Rows[0]["hsa_force_15_dr_max"].ToString();
            lblForceExitRight_15_mean.Text = dt_DSR.Rows[0]["hsa_force_15_dr_mean"].ToString();
            lblForceExitRight_16_min.Text = dt_DSR.Rows[0]["hsa_force_16_dr_min"].ToString();
            lblForceExitRight_16_max.Text = dt_DSR.Rows[0]["hsa_force_16_dr_max"].ToString();
            lblForceExitRight_16_mean.Text = dt_DSR.Rows[0]["hsa_force_16_dr_mean"].ToString();
        }
    }

    string BoxPlot(DataTable dt)
    {
        string s = "<script>";

        string data_1, data_2, data_1_mean, data_2_mean, outlier = "";

        data_1 = "[" + dt.Rows[0]["total_soft_reduction_act_q0"] + "," + dt.Rows[0]["total_soft_reduction_act_q1"] + "," + dt.Rows[0]["total_soft_reduction_act_q2"] + "," + dt.Rows[0]["total_soft_reduction_act_q3"] + "," + dt.Rows[0]["total_soft_reduction_act_q4"] + "]";
        data_2 = "[" + dt.Rows[0]["total_soft_reduction_ref_q0"] + "," + dt.Rows[0]["total_soft_reduction_ref_q1"] + "," + dt.Rows[0]["total_soft_reduction_ref_q2"] + "," + dt.Rows[0]["total_soft_reduction_ref_q3"] + "," + dt.Rows[0]["total_soft_reduction_ref_q4"] + "]";
        data_1_mean = dt.Rows[0]["total_soft_reduction_act_mean"].ToString();
        data_2_mean = dt.Rows[0]["total_soft_reduction_ref_mean"].ToString();
        string temp = dt.Rows[0]["total_soft_reduction_act_out"].ToString();
        if (temp != "NA")
        {
            foreach (string oliers in temp.Split(','))
            {
                outlier += ",[0," + oliers + "]";
            }
        }
        temp = dt.Rows[0]["total_soft_reduction_ref_out"].ToString();
        if (temp != "NA")
        {
            foreach (string oliers in temp.Split(','))
            {
                outlier += ",[1," + oliers + "]";
            }
        }

        if (outlier == "") { outlier = ","; }
        s += "option = {toolbox: {show: true, feature: {dataZoom: {}}}, backgroundColor:'#FFF9CA', title: [{text: 'Total Soft Reduction mm',left: 'center', textStyle:{fontSize:15}},], tooltip:{trigger:'item',axisPointer:{type:'shadow'}},xAxis: {type: 'category',data: ['Actual','Set Point'],boundaryGap: true,nameGap: 30},yAxis: {type: 'value', scale: true, name: 'mm'},series: [{name: 'Actual',type: 'boxplot', itemStyle:{borderColor:'#007ACC'},";
        s += "data: [" + data_1 + "," + data_2 + "],markPoint:{symbol:'triangle',symbolSize:10,data:[{name:'SetPt_Mean',coord: [1, " + data_2_mean + "],value:" + data_2_mean + ",label:{show:false}},{name:'Actual_mean',coord: [0, " + data_1_mean + "],value:" + data_1_mean + ",label:{show:false}}]},";
        s += "tooltip:{formatter:function(param){return['Experiment'+param.name+':','total_soft_reduction_q4:'+param.data[5],'total_soft_reduction_q3:'+param.data[4],'total_soft_reduction_q2:'+param.data[3],'total_soft_reduction_q1:'+param.data[2],'total_soft_reduction_q0:'+param.data[1]].join('<br/>');}}";
        s += "},{name:'outlier',type:'scatter', color: '#007ACC', symbolSize: 5, data:[" + outlier.Substring(1) + "]}]";
        s += "};var myChart = echarts.init(document.getElementById('chart'));myChart.setOption(option);</script>";
        return s;

    }

    string LinePlot(DataTable dt)
    {
        string s = "<script>";

        string data_1, data_2, data_x;

        data_1 = "[" + dt.Rows[0]["hsa_force_10_el_mean"] + "," + dt.Rows[0]["hsa_force_10_dl_mean"] + "," + dt.Rows[0]["hsa_force_11_el_mean"] + "," + dt.Rows[0]["hsa_force_11_dl_mean"] + "," + dt.Rows[0]["hsa_force_12_el_mean"] + "," + dt.Rows[0]["hsa_force_12_dl_mean"] + "," + dt.Rows[0]["hsa_force_13_el_mean"] + "," + dt.Rows[0]["hsa_force_13_dl_mean"] + "," + dt.Rows[0]["hsa_force_14_el_mean"] + "," + dt.Rows[0]["hsa_force_14_dl_mean"] + "," + dt.Rows[0]["hsa_force_15_el_mean"] + "," + dt.Rows[0]["hsa_force_15_dl_mean"] + "," + dt.Rows[0]["hsa_force_16_el_mean"] + "," + dt.Rows[0]["hsa_force_16_dl_mean"] + "]";
        data_2 = "[" + dt.Rows[0]["hsa_force_10_er_mean"] + "," + dt.Rows[0]["hsa_force_10_dr_mean"] + "," + dt.Rows[0]["hsa_force_11_er_mean"] + "," + dt.Rows[0]["hsa_force_11_dr_mean"] + "," + dt.Rows[0]["hsa_force_12_er_mean"] + "," + dt.Rows[0]["hsa_force_12_dr_mean"] + "," + dt.Rows[0]["hsa_force_13_er_mean"] + "," + dt.Rows[0]["hsa_force_13_dr_mean"] + "," + dt.Rows[0]["hsa_force_14_er_mean"] + "," + dt.Rows[0]["hsa_force_14_dr_mean"] + "," + dt.Rows[0]["hsa_force_15_er_mean"] + "," + dt.Rows[0]["hsa_force_15_dr_mean"] + "," + dt.Rows[0]["hsa_force_16_er_mean"] + "," + dt.Rows[0]["hsa_force_16_dr_mean"] + "]";
		data_x = "[\"Seg. 10 entry\", \"Seg. 10 exit\", \"Seg. 11 entry\", \"Seg. 11 exit\", \"Seg. 12 entry\", \"Seg. 12 exit\", \"Seg. 13 entry\", \"Seg. 13 exit\", \"Seg. 14 entry\", \"Seg. 14 exit\", \"Seg. 15 entry\", \"Seg. 15 exit\", \"Seg. 16 entry\", \"Seg. 16 exit\"]";
			
		s += @"option = {
				  backgroundColor:'#FFF9CA',	
				  title: {
					text: 'HSA Force mean at Segment Entry-Exit'
				  },
				  tooltip: {
					trigger: 'axis'
				  },
				  legend: {
					data: ['Force left', 'Force right']
				  },
				  grid: {
					left: '3%',
					right: '4%',
					bottom: '3%',
					containLabel: true
				  },
				  toolbox: {
					feature: {
					  saveAsImage: {}
					}
				  },
				  xAxis: {
					type: 'category',
					boundaryGap: false,				
					data: ";
					//['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
		s += data_x;		
		s += @"		  },
				  yAxis: {
					type: 'value',
					scale: true,
					name: 'kN'
				  },
				  series: [
					{
					  name: 'Force left',
					  type: 'line',
					  data: ";
					  //[120, 132, 101, 134, 90, 230, 210]
		s += data_1;		  
		s += @"			},
					{
					  name: 'Force right',
					  type: 'line',
					  data: ";
					  //[220, 182, 191, 234, 290, 330, 310]
		s += data_2;
		s += @"
					}
				  ]
				};";
		s += "var myChart = echarts.init(document.getElementById('chart1'));myChart.setOption(option);</script>";	
        return s;

    }

    string LinePlot1(DataTable dt)
    {
        string s = "<script>";

        string data_1, data_x;

        data_1 = "[" + dt.Rows[0]["hsa_gap_10_e_mean"] + "," + dt.Rows[0]["hsa_gap_10_d_mean"] + "," + dt.Rows[0]["hsa_gap_11_e_mean"] + "," + dt.Rows[0]["hsa_gap_11_d_mean"] + "," + dt.Rows[0]["hsa_gap_12_e_mean"] + "," + dt.Rows[0]["hsa_gap_12_d_mean"] + "," + dt.Rows[0]["hsa_gap_13_e_mean"] + "," + dt.Rows[0]["hsa_gap_13_d_mean"] + "," + dt.Rows[0]["hsa_gap_14_e_mean"] + "," + dt.Rows[0]["hsa_gap_14_d_mean"] + "," + dt.Rows[0]["hsa_gap_15_e_mean"] + "," + dt.Rows[0]["hsa_gap_15_d_mean"] + "," + dt.Rows[0]["hsa_gap_16_e_mean"] + "," + dt.Rows[0]["hsa_gap_16_d_mean"] + "]";
		data_x = "[\"Seg. 10 entry\", \"Seg. 10 exit\", \"Seg. 11 entry\", \"Seg. 11 exit\", \"Seg. 12 entry\", \"Seg. 12 exit\", \"Seg. 13 entry\", \"Seg. 13 exit\", \"Seg. 14 entry\", \"Seg. 14 exit\", \"Seg. 15 entry\", \"Seg. 15 exit\", \"Seg. 16 entry\", \"Seg. 16 exit\"]";
			
		s += @"option = {
				  backgroundColor:'#FFF9CA',
				  title: {
					text: 'HSA Gap mean at Segment Entry-Exit'
				  },
				  tooltip: {
					trigger: 'axis'
				  },
				  legend: {
					data: ['Gap']
				  },
				  grid: {
					left: '3%',
					right: '4%',
					bottom: '3%',
					containLabel: true
				  },
				  toolbox: {
					feature: {
					  saveAsImage: {}
					}
				  },
				  xAxis: {
					type: 'category',
					boundaryGap: false,				
					data: ";
					//['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
		s += data_x;		
		s += @"		  },
				  yAxis: {
					type: 'value',
					scale: true,
					name: 'mm'
				  },
				  series: [
					{
					  name: 'Gap',
					  type: 'line',
					  data: ";
					  //[120, 132, 101, 134, 90, 230, 210]
		s += data_1;		  
		s += @"
					}
				  ]
				};";
		s += "var myChart = echarts.init(document.getElementById('chart2'));myChart.setOption(option);</script>";	
        return s;

    }

    protected void DownloadData(string Fromdate, string Todate)
    {
        //slabid= ddlSlab_id.SelectedItem.Value;
        DataTable dt = new DataTable();
        string cs = ConfigurationManager.ConnectionStrings["TG-GWL"].ConnectionString;

        //using (SqlConnection con = new SqlConnection(cs))
        //{
        //    SqlCommand cmd = new SqlCommand("select slab_id, l2_slab_cut_time, iba_slab_cut_time, total_soft_reduction_ref_q1, total_soft_reduction_ref_q2, total_soft_reduction_ref_q3, total_soft_reduction_ref_q0, total_soft_reduction_ref_q4, total_soft_reduction_act_q1, total_soft_reduction_act_q2, total_soft_reduction_act_q3, total_soft_reduction_act_q0, total_soft_reduction_act_q4, hsa_force_10_el_mean, hsa_force_10_er_mean, hsa_force_10_dl_mean, hsa_force_10_dr_mean, hsa_force_11_el_mean, hsa_force_11_er_mean, hsa_force_11_dl_mean, hsa_force_11_dr_mean, hsa_force_12_el_mean, hsa_force_12_er_mean, hsa_force_12_dl_mean, hsa_force_12_dr_mean, hsa_force_13_el_mean, hsa_force_13_er_mean, hsa_force_13_dl_mean, hsa_force_13_dr_mean, hsa_force_14_el_mean, hsa_force_14_er_mean, hsa_force_14_dl_mean, hsa_force_14_dr_mean, hsa_force_15_el_mean, hsa_force_15_er_mean, hsa_force_15_dl_mean, hsa_force_15_dr_mean, hsa_force_16_el_mean, hsa_force_16_er_mean, hsa_force_16_dl_mean, hsa_force_16_dr_mean, dsr_on_mean, therm_tap_tab_no_mean, therm_tap_tab_no_min, therm_tap_tab_no_max, solid_seg_mean, solid_seg_min, solid_seg_max, solid_len_act_mean, solid_len_act_min, solid_len_act_max, sr_tab_no_mean, sr_tab_no_min, sr_tab_no_max, hsa_gap_10_e_mean, hsa_gap_10_d_mean, hsa_gap_11_e_mean, hsa_gap_11_d_mean, hsa_gap_12_e_mean, hsa_gap_12_d_mean, hsa_gap_13_e_mean, hsa_gap_13_d_mean, hsa_gap_14_e_mean, hsa_gap_14_d_mean, hsa_gap_15_e_mean, hsa_gap_15_d_mean, hsa_gap_16_e_mean, hsa_gap_16_d_mean, scw_dsc_mode_mean, hsa_tap_ref_10_mean, hsa_tap_act_10_mean, hsa_tap_ref_11_mean, hsa_tap_act_11_mean, hsa_tap_ref_12_mean, hsa_tap_act_12_mean, hsa_tap_ref_13_mean, hsa_tap_act_13_mean, hsa_tap_ref_14_mean, hsa_tap_act_14_mean, hsa_tap_ref_15_mean, hsa_tap_act_15_mean, hsa_tap_ref_16_mean, hsa_tap_act_16_mean, hsa_speed_mean, hsa_speed_min, hsa_speed_max, hsa_speed_stddev FROM[FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB] where mod_status IN (11, 1, 21) and [iba_slab_cut_time] between '" + Fromdate + "' AND '" + Todate + "' order by[iba_slab_cut_time] desc", con);
        //SqlCommand cmd = new SqlCommand("spDSR_ExcelSheetData", con);
        //cmd.CommandType = CommandType.StoredProcedure;

        //SqlParameter parameterFrom = new SqlParameter();
        //parameterFrom.ParameterName = "@DateFrom";
        //parameterFrom.Value = Fromdate;
        //cmd.Parameters.Add(parameterFrom);

        //SqlParameter parameterTo = new SqlParameter();
        //parameterTo.ParameterName = "@DateTo";
        //parameterTo.Value = Todate;
        //cmd.Parameters.Add(parameterTo);'
        //cmd.CommandTimeout = 3000;
        //SqlDataAdapter da = new SqlDataAdapter(cmd);
        //dt.Clear();
        //da.Fill(dt);
        //return dt;
        dt = objdatahandler.GetDataSetFromQuery("select slab_id, l2_slab_cut_time, l2_slab_cut_time, total_soft_reduction_ref_q1, total_soft_reduction_ref_q2, total_soft_reduction_ref_q3, total_soft_reduction_ref_q0, total_soft_reduction_ref_q4, total_soft_reduction_act_q1, total_soft_reduction_act_q2, total_soft_reduction_act_q3, total_soft_reduction_act_q0, total_soft_reduction_act_q4, hsa_force_10_el_mean, hsa_force_10_er_mean, hsa_force_10_dl_mean, hsa_force_10_dr_mean, hsa_force_11_el_mean, hsa_force_11_er_mean, hsa_force_11_dl_mean, hsa_force_11_dr_mean, hsa_force_12_el_mean, hsa_force_12_er_mean, hsa_force_12_dl_mean, hsa_force_12_dr_mean, hsa_force_13_el_mean, hsa_force_13_er_mean, hsa_force_13_dl_mean, hsa_force_13_dr_mean, hsa_force_14_el_mean, hsa_force_14_er_mean, hsa_force_14_dl_mean, hsa_force_14_dr_mean, hsa_force_15_el_mean, hsa_force_15_er_mean, hsa_force_15_dl_mean, hsa_force_15_dr_mean, hsa_force_16_el_mean, hsa_force_16_er_mean, hsa_force_16_dl_mean, hsa_force_16_dr_mean, dsr_on_mean, therm_tap_tab_no_mean, therm_tap_tab_no_min, therm_tap_tab_no_max, solid_seg_mean, solid_seg_min, solid_seg_max, solid_len_act_mean, solid_len_act_min, solid_len_act_max, sr_tab_no_mean, sr_tab_no_min, sr_tab_no_max, hsa_gap_10_e_mean, hsa_gap_10_d_mean, hsa_gap_11_e_mean, hsa_gap_11_d_mean, hsa_gap_12_e_mean, hsa_gap_12_d_mean, hsa_gap_13_e_mean, hsa_gap_13_d_mean, hsa_gap_14_e_mean, hsa_gap_14_d_mean, hsa_gap_15_e_mean, hsa_gap_15_d_mean, hsa_gap_16_e_mean, hsa_gap_16_d_mean, scw_dsc_mode_mean, hsa_tap_ref_10_mean, hsa_tap_act_10_mean, hsa_tap_ref_11_mean, hsa_tap_act_11_mean, hsa_tap_ref_12_mean, hsa_tap_act_12_mean, hsa_tap_ref_13_mean, hsa_tap_act_13_mean, hsa_tap_ref_14_mean, hsa_tap_act_14_mean, hsa_tap_ref_15_mean, hsa_tap_act_15_mean, hsa_tap_ref_16_mean, hsa_tap_act_16_mean, hsa_speed_mean, hsa_speed_min, hsa_speed_max, hsa_speed_stddev FROM[FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB] where mod_status IN(11, 1, 21)and[l2_slab_cut_time] between '" + Fromdate + "' AND '" + Todate + "' order by[l2_slab_cut_time] desc").Tables[0];
        if (dt.Rows.Count == 0)
            {
                ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert('Data Not Available')", true);
            }
            else
            {
                string filename = "DSR_Visualization_" + DateTime.Now.ToString("yyyy-MM-dd") + ".xlsx";
                Response.Clear();
                Response.Clear();
                Response.ClearContent();
                Response.ClearHeaders();
                Response.Buffer = true;
                Response.ContentEncoding = System.Text.Encoding.UTF8;
                Response.Cache.SetCacheability(HttpCacheability.NoCache);
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                Response.AddHeader("content-disposition", "attachment;filename=" + filename);

                using (OfficeOpenXml.ExcelPackage pck = new OfficeOpenXml.ExcelPackage())
                {
                    OfficeOpenXml.ExcelWorksheet ws = pck.Workbook.Worksheets.Add("Logs");
                    ws.Cells["A1"].LoadFromDataTable(dt, true);
                    ws.Cells.AutoFitColumns();
                    var ms = new System.IO.MemoryStream();
                    pck.SaveAs(ms);
                    ms.WriteTo(Response.OutputStream);
                }

                Response.Flush();
                Response.End();

                //Response.Clear();
                //Response.Buffer = true;
                //Response.ClearContent();
                //Response.ClearHeaders();
                //Response.Charset = "";
                //string filename = "DSR_Visualization_" + DateTime.Now.ToString("yyyy-MM-dd") + ".xls";
                //StringWriter sw = new StringWriter();
                //HtmlTextWriter hw = new HtmlTextWriter(sw);
                //Response.Cache.SetCacheability(HttpCacheability.NoCache);
                //Response.ContentType = "application/vnd.ms-excel";
                //Response.AddHeader("Content-Disposition", "attachment; filename=" + filename);

                //GridView gv = new GridView();
                //gv.DataSource = dt;
                //gv.DataBind();

                //gv.GridLines = GridLines.Both;
                //gv.HeaderStyle.Font.Bold = true;
                //gv.RenderControl(hw);
                //Response.Write(sw.ToString());
                //Response.End();
            }
        
    }
    protected void btnDownload_Click(object sender, EventArgs e)
    {
        //if()
        //{

        //}
        DownloadData(hfFrom.Value, hfTo.Value);
    }

    protected void btnDisplay_Click(object sender, EventArgs e)
    {
        if (txtSlabId.Text != "")
        {            
            DataTable dt = BindData(txtSlabId.Text);
            GetData_Grade(txtSlabId.Text);
            Boolean IfValidSlabId = Check_slab_id();
            if (IfValidSlabId == true)
            {
                GetData();
            }
            else
            {
                return;
            }
        }
        else
        {
            DataTable dt = BindData(ddlSlab_id.SelectedItem.Value);
            GetData_Grade(ddlSlab_id.SelectedItem.Value);
            GetData();
        }

        //Check_slab_id(hfFrom.Value, hfTo.Value,txtSlabId.Text);
    }
    //protected void Check_slab_id(string strfrmDt, string strToDt, string SlabId)
    protected Boolean Check_slab_id()
    {
        DataTable dt = new DataTable();
        string cs = ConfigurationManager.ConnectionStrings["TG-GWL"].ConnectionString;
        int IdCounter = 0;

        using (SqlConnection con = new SqlConnection(cs))
        {
            SqlCommand cmd = new SqlCommand("spDSR_ValidSlabID", con);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlParameter parameterFrom = new SqlParameter();
            parameterFrom.ParameterName = "@SlabId";
            parameterFrom.Value = txtSlabId.Text ;
            cmd.Parameters.Add(parameterFrom);

            ////SqlParameter parameterTo = new SqlParameter();
            ////parameterTo.ParameterName = "@DateTo";
            ////parameterTo.Value = strToDt;
            ////cmd.Parameters.Add(parameterTo);
            //if (con.State==ConnectionState.Closed) con.Open();
            cmd.CommandTimeout = 300;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);

            if (dt.Rows.Count < 1)
            {
                //Response.Write("Please check for Valid Slab Id.");
                ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Slab Data Not Found!');", true);
                return false;
            }
            else
            {
                return true;
            }
            ////foreach(DataRow row in dt.Rows)
            ////{
            ////    if (row[0].ToString() == SlabId)
            ////    {
            ////        ddlSlab_id.SelectedItem.Value = SlabId;
            ////         DataTable dt1 = BindData(ddlSlab_id.SelectedItem.Value);
            ////        GetData_Grade(ddlSlab_id.SelectedItem.Value);
            ////        GetData();
            ////        return;
            ////    }
            ////}
            ////    if (IdCounter == 0)
            ////    {
            ////        Response.Write("Slab id is not valid");
            ////    }                

            ////SqlDataReader rdr = cmd.ExecuteReader();
            //ddlSlab_id.DataSource = dt;
            //ddlSlab_id.DataTextField = "slab_id";
            //ddlSlab_id.DataValueField = "slab_id";
            ////ddlSlab_id.DataSource = rdr;
            //ddlSlab_id.DataBind();

            ////SqlDataAdapter da = new SqlDataAdapter(cmd);
            ////dt.Clear();
            ////da.Fill(dt);
            ////return dt;

        }
        //string qry = "SELECT [slab_id],[iba_slab_cut_time]   FROM [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB] where mod_status IN(11,1,21) and [iba_slab_cut_time] between '" + strfrmDt + "' and '" + strToDt + "' order by [iba_slab_cut_time] desc";

        //string cs = ConfigurationManager.ConnectionStrings["TG-GWL"].ConnectionString;
        //using (SqlConnection con = new SqlConnection(cs))
        //{
        //    SqlCommand cmd = new SqlCommand(qry, con);
        //    con.Open();
        //    SqlDataReader rdr = cmd.ExecuteReader();
        //    ddlSlab_id.DataTextField = "slab_id";
        //    ddlSlab_id.DataSource = rdr;
        //    ddlSlab_id.DataBind();

        //}
    }
}