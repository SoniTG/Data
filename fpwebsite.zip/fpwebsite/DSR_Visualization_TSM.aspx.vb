﻿Imports System.Data
Imports System.IO
Partial Class DSR_Visualization_TSM
    Inherits System.Web.UI.Page
	Dim objController as new Controller
    Dim objDataHandler As New DataHandler
    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        ClearFields
        ShowData()
    End Sub

    Private Sub ClearFields()
        lblTTN_min.Text = ""
        lblTTN_max.Text = ""
        lblSRT_min.Text = ""
        lblSRT_max.Text = ""
        lblGrade.Text = ""
        lblSlab_ID.Text = ""
        lblDSC.Text = ""
        lblJmin.Text = ""
        lblJmode.Text = ""
        lblJmax.Text = ""

        litChart1.Text = ""
        litChart2.Text = ""
        litChart3.Text = "'"

        For i As Integer = 9 To 19

            CType(Master.FindControl("content_body").FindControl("Image" & i), Image).ImageUrl = Nothing

        Next

        For i As Integer = 9 To 19
            CType(Master.FindControl("content_body").FindControl("Label" & i), Label).Text = ""
        Next

        Dim c As Integer = 0
        For i As Integer = 0 To 6
            Dim row As HtmlTableRow = CType(Master.FindControl("content_body").FindControl("tr" & i + 1), HtmlTableRow)
            For j As Integer = 1 To 33
                row.Cells(j).InnerText = ""
                c += 1
            Next
        Next
    End Sub

    Private Sub ShowData()
        Dim slabid As String = ""
        If txtSlabId.Text.Trim <> "" Then
            slabid = txtSlabId.Text.Trim
        Else
            If ddlSlab_id.SelectedIndex > 0 Then
                slabid = ddlSlab_id.SelectedItem.Text
            End If
        End If

        If slabid = "" Then
            UserMsgBoxWarning("Input Slab Id")
            Return
        End If

        Dim extracols As String = ""
        For k As Integer = 9 To 19
            extracols &= ",[hsa_force_" & k & "_el_mean],[hsa_force_" & k & "_er_mean],[hsa_gap_" & k & "_e_mean],[hsa_force_" & k & "_dl_mean],[hsa_force_" & k & "_dr_mean],[hsa_gap_" & k & "_d_mean]"
        Next

        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select [solid_seg_min],[solid_seg_max],[solid_seg_mode],[therm_tap_tab_no_min],[therm_tap_tab_no_max],[sr_tab_no_min],[sr_tab_no_max],total_sr_boxplot,total_sr_ref_boxplot,total_sr_mean,total_sr_ref_mean,hsa_speed_boxplot,hsa_speed_mean" & extracols & " from [TSM_SMS].[dbo].[T_SLAB_C2_3] where [MARKID_ACT]='" & slabid & "'").Tables(0)
        If dt.Rows.Count > 0 Then
            lblTTN_min.Text = dt.Rows(0)("therm_tap_tab_no_min").ToString.trimend("0").trimend(".")
            lblTTN_max.Text = dt.Rows(0)("therm_tap_tab_no_max").ToString.trimend("0").trimend(".")
            lblSRT_min.Text = dt.Rows(0)("sr_tab_no_min").ToString.trimend("0").trimend(".")
            lblSRT_max.Text = dt.Rows(0)("sr_tab_no_max").ToString.trimend("0").trimend(".")
            lblGrade.Text = slabid.Substring(7, 4)
            lblSlab_ID.Text = slabid
            lblDSC.Text = FetchDSC(slabid)
            lblJmin.Text = dt.Rows(0)("solid_seg_min").ToString.trimend("0").trimend(".")
            lblJmode.Text = dt.Rows(0)("solid_seg_mode").ToString.trimend("0").trimend(".")
            lblJmax.Text = dt.Rows(0)("solid_seg_max").ToString.trimend("0").trimend(".")

            ShowImages(lblJmode.Text)

            BoxPlot(dt.Rows(0)("total_sr_boxplot").ToString, dt.Rows(0)("total_sr_ref_boxplot").ToString, dt.Rows(0)("total_sr_mean").ToString, dt.Rows(0)("total_sr_ref_mean").ToString)
            BoxPlot_CastingSpeed(dt.Rows(0)("hsa_speed_boxplot").ToString, dt.Rows(0)("hsa_speed_mean").ToString)

            LineChart(dt, 13)

            Dim colnames(6) As String
            For i As Integer = 9 To 19
                colnames(0) &= ",hsa_tap_act_" & i & "_min,hsa_tap_act_" & i & "_max,hsa_tap_act_" & i & "_mean"
                colnames(1) &= ",hsa_gap_" & i & "_e_min,hsa_gap_" & i & "_e_max,hsa_gap_" & i & "_e_mean"
                colnames(2) &= ",hsa_gap_" & i & "_d_min,hsa_gap_" & i & "_d_max,hsa_gap_" & i & "_d_mean"
                colnames(3) &= ",hsa_force_" & i & "_el_min,hsa_force_" & i & "_el_max,hsa_force_" & i & "_el_mean"
                colnames(4) &= ",hsa_force_" & i & "_er_min,hsa_force_" & i & "_er_max,hsa_force_" & i & "_er_mean"
                colnames(5) &= ",hsa_force_" & i & "_dl_min,hsa_force_" & i & "_dl_max,hsa_force_" & i & "_dl_mean"
                colnames(6) &= ",hsa_force_" & i & "_dr_min,hsa_force_" & i & "_dr_max,hsa_force_" & i & "_dr_mean"
            Next
            Dim dt1 As DataTable = objDataHandler.GetDataSetFromQuery("select " & colnames(0).Substring(1) & colnames(1) & colnames(2) & colnames(3) & colnames(4) & colnames(5) & colnames(6) & " from [TSM_SMS].[dbo].[T_SLAB_C2_3] where [MARKID_ACT]='" & slabid & "'").Tables(0)

            PopulateGrid(dt1)
        End If
    End Sub

    Private Function FetchDSC(slabid As String) As String
        Dim retval As String = "OFF"
        Try
            Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select [scw_dsc_mode_mean] from [TSM_SMS].[dbo].[T_SLAB_C2_2] where [MARKID_ACT]='" & slabid & "'").Tables(0)
            If dt.Rows.Count > 0 Then
                If Not IsDBNull(dt.Rows(0)(0)) Then
                    If dt.Rows(0)(0) > 0.5 Then
                        retval = "ON"
                    End If
                End If
            End If
        Catch ex As Exception

        End Try

        Return retval
    End Function

    Private Sub PopulateGrid(dt1 As DataTable)
        Dim c As Integer = 0
        For i As Integer = 0 To 6
            Dim row As HtmlTableRow = CType(Master.FindControl("content_body").FindControl("tr" & i + 1), HtmlTableRow)
            For j As Integer = 1 To 33
                row.Cells(j).InnerText = dt1.Rows(0)(c)
                c += 1
            Next
        Next

    End Sub

    Private Sub LineChart(ByRef dt As DataTable, ByVal colidx As Integer)
        Dim s As New StringBuilder

        Dim s1, s2, s3, xaxis As String

        For c As Integer = colidx To dt.Columns.Count - 1 Step 3
            s1 &= ", " & dt.Rows(0)(c).ToString
            s2 &= ", " & dt.Rows(0)(c + 1).ToString
            s3 &= ", " & dt.Rows(0)(c + 2).ToString
        Next

        For i As Integer = 9 To 19
            xaxis &= ",'" & "Seg. " & i & " entry'," & "'Seg. " & i & " exit'"
        Next

        ',axisLabel: {interval:0,rotate: 30}

        s.Append("<script>")
        s.Append("echarts.init(document.getElementById('chart3')).setOption({grid:{top:'15%', bottom:'10%',left: '3%',right: '4%',containLabel: true},legend:{data: ['Force left', 'Force right']},  tooltip:{trigger: 'axis'},xAxis: {type: 'category',boundaryGap: false,	data:[" & xaxis.Substring(1) & "]},yAxis: {type: 'value', scale: true, name: 'kN'},series: [{name: 'Force left',type: 'line', data: [" & s1.Substring(1) & "]},")
        s.Append("{name: 'Force right',type: 'line', data: [" & s2.Substring(1) & "]}],")
        s.Append("});")

        s.Append("echarts.init(document.getElementById('chart4')).setOption({grid:{top:'15%', bottom:'10%',left: '3%',right: '4%',containLabel: true},legend:{data: ['Gap']},  tooltip:{trigger: 'axis'},xAxis: {type: 'category',boundaryGap: false,	data:[" & xaxis.Substring(1) & "]},yAxis: {type: 'value', scale: true, name: 'mm'},series: [{name: 'Gap',type: 'line', data: [" & s3.Substring(1) & "]}],")
        s.Append("});")
        s.Append("</script>")

        litChart3.Text = s.ToString
    End Sub

    Private Sub ShowImages(text As String)
        Dim idx As Integer = text

        Dim hash As String = DateTime.Now.ToString("MMddHHmmss")

        For i As Integer = 9 To 19
            If i < idx - 1 Then
                CType(Master.FindControl("content_body").FindControl("Image" & i), Image).ImageUrl = "images/Caster_DSR3_J-1.png?" & hash
            ElseIf i = idx - 1
                CType(Master.FindControl("content_body").FindControl("Image" & i), Image).ImageUrl = "images/Caster_DSR3_J.png?" & hash

            ElseIf i > idx - 1
                CType(Master.FindControl("content_body").FindControl("Image" & i), Image).ImageUrl = "images/Caster_DSR3_J1.png?" & hash
            End If
        Next

        Dim lbl As String = "J"

        For i As Integer = idx To idx - 3 Step -1
            If i < 9 Then
                Exit For
            End If
            CType(Master.FindControl("content_body").FindControl("Label" & i), Label).Text = lbl & " " & IIf(idx - i = 0, "", i - idx)
        Next

    End Sub

    Private Sub BoxPlot(ByVal s1 As String, ByVal s2 As String, ByVal data_1_mean As String, ByVal data_2_mean As String)
        '{'q1': 0.0, 'q2': 0.0, 'q3': 0.0, 'q0': 0.0, 'q4': 0.0, 'out': ''}

        If s1 = "" AndAlso s2 = "" Then
            Return
        End If

        Dim obj1 As BoxPlotValues
        If s1 <> "" Then
            obj1 = Newtonsoft.Json.JsonConvert.DeserializeObject(Of BoxPlotValues)(s1)
        End If
        Dim obj2 As BoxPlotValues
        If s2 <> "" Then
            obj2 = Newtonsoft.Json.JsonConvert.DeserializeObject(Of BoxPlotValues)(s2)
        End If

        Dim data_1, data_2, outlier As String
        data_1 = "[]"
        data_2 = "[]"

        Try
            data_1 = String.Format("[{0},{1},{2},{3},{4}]", obj1.q0, obj1.q1, obj1.q2, obj1.q3, obj1.q4)
        Catch ex As Exception
        End Try

        Try
            data_2 = String.Format("[{0},{1},{2},{3},{4}]", obj2.q0, obj2.q1, obj2.q2, obj2.q3, obj2.q4)
        Catch ex As Exception
        End Try

        Dim temp As String = obj1.out
        For Each v As String In temp.Split(",")
            outlier &= ",[0," + v + "]"
        Next

        temp = obj2.out
        For Each v As String In temp.Split(",")
            outlier &= ",[1," + v + "]"
        Next

        If (outlier = "") Then outlier = ","

        Dim s As New StringBuilder
        s.Append("<script>")
        s.Append("")

        s.Append("echarts.init(document.getElementById('chart1')).setOption({grid:{top:'15%', bottom:'10%'},  tooltip:{trigger:'item',axisPointer:{type:'shadow'}},xAxis: {type: 'category',data: ['Actual','Set Point'],boundaryGap: true,nameGap: 30},yAxis: {type: 'value', scale: true, name: 'mm'},series: [{name: 'Actual',type: 'boxplot', itemStyle:{borderColor:'#007ACC'},")
        s.Append("data: [" + data_1 + "," + data_2 + "],markPoint:{symbol:'triangle',symbolSize:10,data:[{name:'SetPt_Mean',coord: [1, " + data_2_mean + "],value:" + data_2_mean + ",label:{show:false}},{name:'Actual_mean',coord: [0, " + data_1_mean + "],value:" + data_1_mean + ",label:{show:false}}]},")
        s.Append("tooltip:{formatter:function(param){return[''+param.name+':','total_soft_reduction_q4:'+param.data[5],'total_soft_reduction_q3:'+param.data[4],'total_soft_reduction_q2:'+param.data[3],'total_soft_reduction_q1:'+param.data[2],'total_soft_reduction_q0:'+param.data[1]].join('<br/>');}}")
        s.Append("},{name:'outlier',type:'scatter', color: '#007ACC', symbolSize: 5, data:[" + outlier.Substring(1) + "]}]")
        s.Append("});")

        s.Append("</script>")

        litChart1.Text = s.ToString
    End Sub

    Private Sub BoxPlot_CastingSpeed(ByVal s1 As String, ByVal data_1_mean As String)
        '{'q1': 0.0, 'q2': 0.0, 'q3': 0.0, 'q0': 0.0, 'q4': 0.0, 'out': ''}

        If s1 = "" Then
            Return
        End If

        Dim obj1 As BoxPlotValues
        If s1 <> "" Then
            obj1 = Newtonsoft.Json.JsonConvert.DeserializeObject(Of BoxPlotValues)(s1)
        End If

        Dim data_1, outlier As String
        data_1 = "[]"

        Try
            data_1 = String.Format("[{0},{1},{2},{3},{4}]", obj1.q0, obj1.q1, obj1.q2, obj1.q3, obj1.q4)
        Catch ex As Exception
        End Try

        Dim temp As String = obj1.out
        For Each v As String In temp.Split(",")
            outlier &= ",[0," + v + "]"
        Next

        If (outlier = "") Then outlier = ","

        Dim s As New StringBuilder
        s.Append("<script>")
        s.Append("")

        s.Append("echarts.init(document.getElementById('chart2')).setOption({grid:{top:'15%', bottom:'10%', left:'20%'},  tooltip:{trigger:'item',axisPointer:{type:'shadow'}},xAxis: {type: 'category',show:false,boundaryGap: true,nameGap: 30},yAxis: {type: 'value', scale: true, name: 'm/min'},series: [{name: 'HSA Speed',type: 'boxplot', itemStyle:{borderColor:'#007ACC'},")
        s.Append("data: [" + data_1 + "],markPoint:{symbol:'triangle',symbolSize:10,data:[{name:'HSA_Speed_mean',coord: [0, " + data_1_mean + "],value:" + data_1_mean + ",label:{show:false}}]},")
        s.Append("tooltip:{formatter:function(param){return['hsa_speed_q4:'+param.data[5],'hsa_speed_q3:'+param.data[4],'hsa_speed_q2:'+param.data[3],'hsa_speed_q1:'+param.data[2],'hsa_speed_q0:'+param.data[1]].join('<br/>');}}")
        s.Append("},{name:'outlier',type:'scatter', color: '#007ACC', symbolSize: 5, data:[" + outlier.Substring(1) + "]}]")
        s.Append("});")

        s.Append("</script>")

        litChart2.Text = s.ToString
    End Sub

    Private Sub DSR_Visualization_TSM_Load(sender As Object, e As EventArgs) Handles Me.Load
        Try
            Dim p As String = Request("__EVENTARGUMENT")
            If p = "txtDate1" Then
                ClearFields()
                FillGrade()
                FillSlabID()
            End If
        Catch ex As Exception

        End Try
        If Not Page.IsPostBack Then
		Session("pagehit") = objController.SaveAndRetrievePageHits("", Path.GetFileName(Request.Path))
            hfFrom.Value = DateTime.Now.AddDays(-7).ToString("yyyy-MM-dd HH:mm:ss")
            hfTo.Value = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            FillGrade()
            FillSlabID()
        End If

    End Sub

    Private Sub FillGrade()
        Dim fromdt As String = hfFrom.Value
        Dim todt As String = hfTo.Value
        Dim q As String = "select distinct substring(MARKID_ACT,8,4) as GRADE from [TSM_SMS].[dbo].[T_SLAB_C2_1] where ([dsr]=1 or [all_params]=1) and [CUT_TIME] between '" & fromdt & "' and '" & todt & "' order by 1"

        Dim dt As New DataTable

        dt = objDataHandler.GetDataSetFromQuery(q).Tables(0)

        ddlGrade.DataSource = dt
        ddlGrade.DataTextField = "GRADE"
        ddlGrade.DataValueField = "GRADE"
        ddlGrade.DataBind()

        ddlGrade.Items.Insert(0, New ListItem("Select", "Select"))
    End Sub
    Private Sub FillSlabID(Optional ByVal grade As String = "")
        Dim fromdt As String = hfFrom.Value
        Dim todt As String = hfTo.Value
        Dim q As String
        If grade = "" Then
            q = "select MARKID_ACT,[CUT_TIME] from [TSM_SMS].[dbo].[T_SLAB_C2_1] where ([dsr]=1 or [all_params]=1) and [CUT_TIME] between '" & fromdt & "' and '" & todt & "' order by [CUT_TIME] desc"
        Else
            q = "select MARKID_ACT,[CUT_TIME] from [TSM_SMS].[dbo].[T_SLAB_C2_1] where ([dsr]=1 or [all_params]=1) and substring(MARKID_ACT,8,4)='" & grade & "' and [CUT_TIME] between '" & fromdt & "' and '" & todt & "' order by [CUT_TIME] desc"
        End If

        Dim dt As New DataTable

        dt = objDataHandler.GetDataSetFromQuery(q).Tables(0)

        ddlSlab_id.DataSource = dt
        ddlSlab_id.DataTextField = "MARKID_ACT"
        ddlSlab_id.DataValueField = "MARKID_ACT"
        ddlSlab_id.DataBind()

        ddlSlab_id.Items.Insert(0, New ListItem("Select", "Select"))
    End Sub

    Private Sub ddlGrade_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlGrade.SelectedIndexChanged
        If ddlGrade.SelectedIndex > 0 Then
            FillSlabID(ddlGrade.SelectedItem.Text)
        Else
            FillSlabID()
        End If
    End Sub
End Class

Public Class BoxPlotValues
    Private _q0 As Double
    Public Property q0() As Double
        Get
            Return _q0
        End Get
        Set(ByVal value As Double)
            _q0 = value
        End Set
    End Property

    Private _q1 As Double
    Public Property q1() As Double
        Get
            Return _q1
        End Get
        Set(ByVal value As Double)
            _q1 = value
        End Set
    End Property

    Private _q2 As Double
    Public Property q2() As Double
        Get
            Return _q2
        End Get
        Set(ByVal value As Double)
            _q2 = value
        End Set
    End Property

    Private _q3 As Double
    Public Property q3() As Double
        Get
            Return _q3
        End Get
        Set(ByVal value As Double)
            _q3 = value
        End Set
    End Property

    Private _q4 As Double
    Public Property q4() As Double
        Get
            Return _q4
        End Get
        Set(ByVal value As Double)
            _q4 = value
        End Set
    End Property

    Private _out As String
    Public Property out() As String
        Get
            Return _out
        End Get
        Set(ByVal value As String)
            _out = value
        End Set
    End Property
End Class
