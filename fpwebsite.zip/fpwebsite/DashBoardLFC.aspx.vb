﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO

Partial Class TempDashboard
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim maindt As New DataTable
    'Dim rptGrid1 As New DataSet
    Dim maindt1 As New DataTable
    Dim fl1 As Integer = 0
    Dim fl2 As Integer = 0


    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
            fl1 = 0
            fl2 = 0
            lbl1.Visible = False
            lbl1.Text = ""
            lbl2.Visible = False
            lbl2.Text = ""
            lbl3.Visible = False
            lbl3.Text = ""
            lbl4.Visible = False
            lbl4.Text = ""

            Dim datetime As DateTime = Date.Now.AddDays(0)
            Dim newdatetime As DateTime = datetime.AddDays(0).AddMinutes(-30)

            Dim ds1 As DataSet = objController.GetLFCData1(1)
            Dim ds2 As DataSet = objController.GetLFCData1(2)




            Dim C1Heat_id As String = ds1.Tables(0)(0)(0)
            Dim C1Start As String = CDate(ds1.Tables(0)(0)(1)).ToString("yyyy-MM-dd HH:mm:ss")
            Dim C1End As String = CDate(ds1.Tables(0)(0)(2)).ToString("yyyy-MM-dd HH:mm:ss")

            Dim C2Heat_id As String = ds2.Tables(0)(0)(0)
            Dim C2Start As String = CDate(ds2.Tables(0)(0)(1)).ToString("yyyy-MM-dd HH:mm:ss")
            Dim C2End As String = CDate(ds2.Tables(0)(0)(2)).ToString("yyyy-MM-dd HH:mm:ss")

            Label1.Text = " Heat No : " & C1Heat_id
            Label2.Text = " Heat No : " & C2Heat_id

            Dim ds3 As DataSet = objController.GetLFCChartData(C1Start, C1End, C1Heat_id, 1)
            Dim ds4 As DataSet = objController.GetLFCChartData(C2Start, C2End, C2Heat_id, 2)

            Dim dts1 As DataTable = ds3.Tables(0)
            Dim dts2 As DataTable = ds3.Tables(1)

            If dts2.Rows.Count <> 0 Then
                chart(ds3, dts1, dts2, C1Start, C1End, "chart1", "chart3", maindt, Literal1, New String() {"line1", "line2", "line3", "line4", "plot1", "plot2"}, rptGRID)
            End If
            If fl1 = 1 Then
                lbl1.Visible = True
                lbl1.Text = "No LFC Found"
                fl1 = 0
            End If
            If fl2 = 1 Then
                lbl3.Visible = True
                lbl3.Text = "No LFC Found"
                fl2 = 0
            End If
            Dim dts3 As DataTable = ds4.Tables(0)
            Dim dts4 As DataTable = ds4.Tables(1)

            If dts4.Rows.Count <> 0 Then
                chart(ds4, dts3, dts4, C2Start, C2End, "chart2", "chart4", maindt1, Literal2, New String() {"line5", "line6", "line7", "line8", "plot3", "plot4"}, rptGrid1)
            End If
            If fl1 = 1 Then
                lbl2.Visible = True
                lbl2.Text = "No LFC Found"
                fl1 = 0
            End If
            If fl2 = 1 Then
                lbl4.Visible = True
                lbl4.Text = "No LFC Found"
                fl2 = 0
            End If
        End If

    End Sub

    Function getdatatable(ByVal query As String) As DataTable
        Dim fndatatable As New DataTable
        Dim connection As String = "Password=Welcome@135;Persist Security Info=True;User ID=153521;Initial Catalog=FP_PROCESS_DATA;Data Source=176.0.0.60\lptgsqldev"
        Using con As New SqlConnection(connection)
            Using cmd As New SqlCommand(query, con)
                cmd.CommandType = CommandType.Text
                Using sda As New SqlDataAdapter(cmd)
                    'Using dt As New DataTable()
                    sda.Fill(fndatatable)
                    'End Using
                End Using
            End Using
        End Using
        Return fndatatable
    End Function
    Sub chart(ByRef ds As DataSet, ByRef dt As DataTable, ByRef dt1 As DataTable, ByVal stDate As String, ByVal enDate As String, ByVal c1 As String, ByVal c2 As String, ByRef mdt As DataTable, ByRef lit As Literal, ByVal a() As String, ByRef rg As Repeater)
        Dim slabid As New DataTable
        dt.DefaultView.Sort = "LFC_TIMESTAMP ASC"
        dt = dt.DefaultView.ToTable

        dt1.DefaultView.Sort = "TSM_PROD_START ASC"
        dt1 = dt1.DefaultView.ToTable

        mdt.Columns.Add("Slab_ID")
        mdt.Columns.Add("LFC_DS_T")
        mdt.Columns.Add("LFC_Tail_T")
        mdt.Columns.Add("LFC_time_T")
        mdt.Columns.Add("LFC_DS_B")
        mdt.Columns.Add("LFC_Tail_B")
        mdt.Columns.Add("LFC_time_B")
        mdt.Columns.Add("Grade")
        mdt.Columns.Add("Slab_width")

        mdt.Columns.Add("RESULT")
        mdt.Columns.Add("REMARKS")
        mdt.Columns.Add("LFC_TIMESTAMP")


        Dim count As Short = 0
        'For i As Integer = 0 To dt.Rows.Count - 1
        Dim nulldt As New DataTable
        nulldt.Columns.Add("Datetime")
        nulldt.Columns.Add("Remarks")
        Dim count2 As Short = 0
        Dim prevSLID1, prevSLID2 As String
        prevSLID1 = "" : prevSLID2 = ""
        For i As Integer = 0 To dt.Rows.Count - 1
            'Dim nullarry As New ArrayList
            If IsDBNull(dt.Rows.Item(i)(2)) Then
                nulldt.Rows.Add()
                nulldt(count2)("Datetime") = dt.Rows.Item(i)(0)
                nulldt(count2)("Remarks") = dt.Rows.Item(i)(1)
                count2 += 1
                Continue For
            End If



            For j As Integer = 0 To dt1.Rows.Count - 1
                If IsDBNull(dt.Rows.Item(i)(2)) Then
                    Continue For
                End If
                Dim query As String = "select decision,SLAB_ID from TSCR_LFC_DECISION where SLAB_ID='" & dt1.Rows.Item(j)(0) & "'"
                Dim decisiondt As DataTable = getdatatable(query)
                If decisiondt.Rows.Count > 0 Then
                    If j = 0 Then
                        slabid = decisiondt.Copy()
                    Else
                        slabid.Merge(decisiondt)
                    End If
                    If decisiondt.Rows(0)(0) = "LFC Predicted" Then
                        If dt.Rows.Item(i)(0) >= dt1.Rows.Item(j)(1) And dt.Rows.Item(i)(0) <= dt1.Rows.Item(j)(2) And dt.Rows.Item(i)(2) < 10 Then
                            mdt.Rows.Add()
                            'If prevSLID1.Equals(dt1.Rows.Item(j)(0)) Then
                            '    mdt(count)("Slab_ID") = ""
                            'Else
                            '    mdt(count)("Slab_ID") = dt1.Rows.Item(j)(0)
                            '    prevSLID1 = dt1.Rows.Item(j)(0)
                            'End If
                            mdt(count)("Slab_ID") = dt1.Rows.Item(j)(0)
                            mdt(count)("LFC_Tail_T") = dt.Rows.Item(i)(3)
                            mdt(count)("LFC_time_T") = dt.Rows.Item(i)(0)
                            mdt(count)("Grade") = dt1.Rows.Item(j)(5)
                            mdt(count)("Slab_width") = dt1.Rows.Item(j)(4)

                            mdt(count)("RESULT") = dt.Rows.Item(i)(2)
                            mdt(count)("REMARKS") = dt.Rows.Item(i)(1)
                            mdt(count)("LFC_TIMESTAMP") = dt.Rows.Item(i)(0)

                            If dt.Rows.Item(i)(2) = 4 Then
                                mdt(count)("LFC_DS_T") = ((dt1.Rows.Item(j)(4) / 2) - 500) / 1000
                            ElseIf dt.Rows.Item(i)(2) = 5 Then
                                mdt(count)("LFC_DS_T") = ((dt1.Rows.Item(j)(4) / 2) - 300) / 1000
                            ElseIf dt.Rows.Item(i)(2) = 6 Then
                                mdt(count)("LFC_DS_T") = ((dt1.Rows.Item(j)(4) / 2) - 100) / 1000
                            ElseIf dt.Rows.Item(i)(2) = 7 Then
                                mdt(count)("LFC_DS_T") = ((dt1.Rows.Item(j)(4) / 2) + 100) / 1000
                            ElseIf dt.Rows.Item(i)(2) = 8 Then
                                mdt(count)("LFC_DS_T") = ((dt1.Rows.Item(j)(4) / 2) + 300) / 1000
                            ElseIf dt.Rows.Item(i)(2) = 9 Then
                                mdt(count)("LFC_DS_T") = ((dt1.Rows.Item(j)(4) / 2) + 500) / 1000
                            End If
                            count += 1
                        ElseIf dt.Rows.Item(i)(0) >= dt1.Rows.Item(j)(1) And dt.Rows.Item(i)(0) <= dt1.Rows.Item(j)(2) And dt.Rows.Item(i)(2) > 10 Then
                            mdt.Rows.Add()
                            'If prevSLID1.Equals(dt1.Rows.Item(j)(0)) Then
                            '    mdt(count)("Slab_ID") = ""
                            'Else
                            '    mdt(count)("Slab_ID") = dt1.Rows.Item(j)(0)
                            '    prevSLID1 = dt1.Rows.Item(j)(0)
                            'End If
                            mdt(count)("Slab_ID") = dt1.Rows.Item(j)(0)
                            mdt(count)("LFC_Tail_B") = dt.Rows.Item(i)(3)
                            mdt(count)("LFC_time_B") = dt.Rows.Item(i)(0)
                            mdt(count)("Grade") = dt1.Rows.Item(j)(5)
                            mdt(count)("Slab_width") = dt1.Rows.Item(j)(4)

                            mdt(count)("RESULT") = dt.Rows.Item(i)(2)
                            mdt(count)("REMARKS") = dt.Rows.Item(i)(1)
                            mdt(count)("LFC_TIMESTAMP") = dt.Rows.Item(i)(0)

                            If dt.Rows.Item(i)(2) = 19 Then
                                mdt(count)("LFC_DS_B") = ((dt1.Rows.Item(j)(4) / 2) - 500) / 1000
                            ElseIf dt.Rows.Item(i)(2) = 18 Then
                                mdt(count)("LFC_DS_B") = ((dt1.Rows.Item(j)(4) / 2) - 300) / 1000
                            ElseIf dt.Rows.Item(i)(2) = 17 Then
                                mdt(count)("LFC_DS_B") = ((dt1.Rows.Item(j)(4) / 2) - 100) / 1000
                            ElseIf dt.Rows.Item(i)(2) = 16 Then
                                mdt(count)("LFC_DS_B") = ((dt1.Rows.Item(j)(4) / 2) + 100) / 1000
                            ElseIf dt.Rows.Item(i)(2) = 15 Then
                                mdt(count)("LFC_DS_B") = ((dt1.Rows.Item(j)(4) / 2) + 300) / 1000
                            ElseIf dt.Rows.Item(i)(2) = 14 Then
                                mdt(count)("LFC_DS_B") = ((dt1.Rows.Item(j)(4) / 2) + 500) / 1000
                            End If
                            count += 1
                        End If
                    End If
                End If
            Next
        Next


        Dim dt_summary As New DataTable
        dt_summary.Columns.Add("SLAB_ID")
        dt_summary.Columns.Add("TOP_SIDE")
        dt_summary.Columns.Add("BOT_SIDE")
        dt_summary.Columns.Add("Grade")
        dt_summary.Columns.Add("Slab_width")
        Dim count1 As Short = 0

        Dim mdt_view As DataView = mdt.DefaultView

        For i As Integer = 0 To dt1.Rows.Count - 1
            Dim topside As Integer
            Dim botside As Integer
            topside = mdt.Compute("count(LFC_DS_T)", "Convert(LFC_DS_T,'System.Double')>0 and Slab_ID='" & dt1.Rows.Item(i)(0) & "'")
            botside = mdt.Compute("count(LFC_DS_B)", "Convert(LFC_DS_B,'System.Double')>0 and Slab_ID='" & dt1.Rows.Item(i)(0) & "'")
            'If Not (topside = 0 And botside = 0) Then
            dt_summary.Rows.Add()
            dt_summary(count1)("TOP_SIDE") = topside
            dt_summary(count1)("BOT_SIDE") = botside
            dt_summary(count1)("SLAB_ID") = dt1.Rows.Item(i)(0)
            dt_summary(count1)("Grade") = dt1.Rows.Item(i)(5)
            dt_summary(count1)("Slab_width") = dt1.Rows.Item(i)(4)
            count1 += 1
            'End If


        Next

        rg.DataSource = mdt
        rg.DataBind()


        'If mdt.Rows.Count = 0 Then
        '    Dim FooterTemplate As Control = rptGrid1.Controls(rptGrid1.Controls.Count - 1).Controls(0)
        '    FooterTemplate.FindControl("trEmpty").Visible = True
        'End If


        'Dim dv As DataView = dt.DefaultView
        'dv.RowFilter = "LEN(RESULT) = 1"
        'Dim dtSingle As DataTable = dv.ToTable
        'dv.RowFilter = ""
        'dv = dt.DefaultView
        'dv.RowFilter = "LEN(RESULT) = 2"
        'Dim dtDouble As DataTable = dv.ToTable
        'dv.RowFilter = ""

        'dv = dtSingle.DefaultView
        'dv.RowFilter = "SUBSTRING(REMARKS,1,3)='LFC'"
        'Dim dtSingle_LFC As DataTable = dv.ToTable
        'dv.RowFilter = ""

        'dv = dtSingle.DefaultView
        'dv.RowFilter = "SUBSTRING(REMARKS,1,3)='Ori'"
        'Dim dtSingle_Orig As DataTable = dv.ToTable
        'dv.RowFilter = ""

        'dv = dtDouble.DefaultView
        'dv.RowFilter = "SUBSTRING(REMARKS,1,3)='LFC'"
        'Dim dtDouble_LFC As DataTable = dv.ToTable
        'dv.RowFilter = ""

        'dv = dtDouble.DefaultView
        'dv.RowFilter = "SUBSTRING(REMARKS,1,3)='Ori'"
        'Dim dtDouble_Orig As DataTable = dv.ToTable



        'dv = nulldt.DefaultView
        'dv.RowFilter = "SUBSTRING(REMARKS,1,10)='Incomplete'"
        'Dim dtSingleIncompete As DataTable = dv.ToTable
        'dv.RowFilter = ""


        'dv = nulldt.DefaultView
        'dv.RowFilter = "SUBSTRING(REMARKS,1,10)='Incomplete'"
        'Dim dtDoubleIncompete As DataTable = dv.ToTable
        'dv.RowFilter = ""

        'dv = nulldt.DefaultView
        'dv.RowFilter = "SUBSTRING(REMARKS,1,2)='TC'"
        'Dim TCSingleDt As DataTable = dv.ToTable
        'dv.RowFilter = ""

        'dv = nulldt.DefaultView
        'dv.RowFilter = "SUBSTRING(REMARKS,1,2)='TC'"
        'Dim TCDoubleDt As DataTable = dv.ToTable
        'dv.RowFilter = ""

        Dim dv As DataView = mdt.DefaultView
        dv.RowFilter = "LEN(RESULT) = 1"
        Dim dtSingle As DataTable = dv.ToTable
        dv.RowFilter = ""
        dv = mdt.DefaultView
        dv.RowFilter = "LEN(RESULT) = 2"
        Dim dtDouble As DataTable = dv.ToTable
        dv.RowFilter = ""

        dv = dtSingle.DefaultView
        dv.RowFilter = "SUBSTRING(REMARKS,1,3)='LFC'"
        Dim dtSingle_LFC As DataTable = dv.ToTable
        dv.RowFilter = ""

        dv = dtSingle.DefaultView
        dv.RowFilter = "SUBSTRING(REMARKS,1,3)='Ori'"
        Dim dtSingle_Orig As DataTable = dv.ToTable
        dv.RowFilter = ""

        dv = dtDouble.DefaultView
        dv.RowFilter = "SUBSTRING(REMARKS,1,3)='LFC'"
        Dim dtDouble_LFC As DataTable = dv.ToTable
        dv.RowFilter = ""

        dv = dtDouble.DefaultView
        dv.RowFilter = "SUBSTRING(REMARKS,1,3)='Ori'"
        Dim dtDouble_Orig As DataTable = dv.ToTable



        dv = nulldt.DefaultView
        dv.RowFilter = "SUBSTRING(REMARKS,1,10)='Incomplete'"
        Dim dtSingleIncompete As DataTable = dv.ToTable
        dv.RowFilter = ""


        dv = nulldt.DefaultView
        dv.RowFilter = "SUBSTRING(REMARKS,1,10)='Incomplete'"
        Dim dtDoubleIncompete As DataTable = dv.ToTable
        dv.RowFilter = ""

        dv = nulldt.DefaultView
        dv.RowFilter = "SUBSTRING(REMARKS,1,2)='TC'"
        Dim TCSingleDt As DataTable = dv.ToTable
        dv.RowFilter = ""

        dv = nulldt.DefaultView
        dv.RowFilter = "SUBSTRING(REMARKS,1,2)='TC'"
        Dim TCDoubleDt As DataTable = dv.ToTable
        dv.RowFilter = ""


        Dim line1 As String = "var " & a(0) & "=["
        Dim line2 As String = "var " & a(1) & "=["
        Dim line3 As String = "var " & a(2) & "=["
        Dim line4 As String = "var " & a(3) & "=["

        Dim line5 As String = "var " & a(4) & "=["

        Dim line6 As String = "var " & a(5) & "=["
        'Dim line7 As String = "var " & a(6) & "=["
        'Dim line8 As String = "var " & a(7) & "=["


        For i As Short = 0 To dtSingle_LFC.Rows.Count - 1
            If i > 0 Then
                line1 &= ", "
            End If
            line1 &= "['" & CDate(dtSingle_LFC.Rows(i)("LFC_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm:ss") & "'," & dtSingle_LFC.Rows(i)("RESULT") & "]"
        Next
        line1 &= "]; "
        For i As Short = 0 To dtSingle_Orig.Rows.Count - 1
            If i > 0 Then
                line2 &= ", "
            End If
            line2 &= "['" & CDate(dtSingle_Orig.Rows(i)("LFC_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm:ss") & "'," & dtSingle_Orig.Rows(i)("RESULT") & "]"
        Next
        line2 &= "]; "
        For i As Short = 0 To dtDouble_LFC.Rows.Count - 1
            If i > 0 Then
                line3 &= ", "
            End If
            line3 &= "['" & CDate(dtDouble_LFC.Rows(i)("LFC_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm:ss") & "'," & dtDouble_LFC.Rows(i)("RESULT") & "]"
        Next
        line3 &= "]; "
        For i As Short = 0 To dtDouble_Orig.Rows.Count - 1
            If i > 0 Then
                line4 &= ", "
            End If
            line4 &= "['" & CDate(dtDouble_Orig.Rows(i)("LFC_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm:ss") & "'," & dtDouble_Orig.Rows(i)("RESULT") & "]"
        Next
        line4 &= "]; "
        For i As Short = 0 To dtSingleIncompete.Rows.Count - 1
            If i > 0 Then
                line5 &= ", "
            End If

            line5 &= "['" & CDate(dtSingleIncompete.Rows(i)("Datetime")).ToString("yyyy-MM-dd HH:mm:ss") & "','']"
        Next
        line5 &= "]; "

        For i As Short = 0 To TCSingleDt.Rows.Count - 1
            If i > 0 Then
                line6 &= ", "
            End If
            line6 &= "['" & CDate(TCSingleDt.Rows(i)("Datetime")).ToString("yyyy-MM-dd HH:mm:ss") & "','']"
        Next
        line6 &= "]; "

        Dim strLine1 As String = ""
        Dim strLine2 As String = ""
        Dim strLine3 As String = ""
        Dim strLine4 As String = ""
        Dim strLine5 As String = ""
        Dim strLine6 As String = ""


        Dim strColour1 As String = ""
        Dim strColour2 As String = ""
        Dim strColour3 As String = ""
        Dim strColour4 As String = ""
        Dim strColour5 As String = ""
        Dim strColour6 As String = ""


        Dim strLegend1 As String = ""
        Dim strLegend2 As String = ""
        Dim strLegend3 As String = ""
        Dim strLegend4 As String = ""
        Dim strLegend5 As String = ""
        Dim strLegend6 As String = ""

        Dim noDataIndicator As String = ""
        If maindt.Rows.Count = 0 Then
            noDataIndicator = "noDataIndicator: { show: true, indicator: 'No LFC Found.' },"
        End If
        If dtSingle_LFC.Rows.Count > 0 Then
            strLine1 &= "" & a(0) & ","
            strColour1 &= "'#EDC938',"
            strLegend1 &= "'Speed Change',"
        End If
        If dtSingle_Orig.Rows.Count > 0 Then
            strLine1 &= "" & a(1) & ","
            strColour1 &= "'#FF0000',"
            strLegend1 &= "'LFC',"
        End If
        If dtDouble_LFC.Rows.Count > 0 Then
            strLine2 &= "" & a(2) & ","
            strColour2 &= "'#EDC938',"
            strLegend2 &= "'Speed Change',"
        End If
        If dtDouble_Orig.Rows.Count > 0 Then
            strLine2 &= "" & a(3) & ","
            strColour2 &= "'#FF0000',"
            strLegend2 &= "'LFC',"
        End If



        If dtSingleIncompete.Rows.Count > 0 Then
            strLine3 &= "" & a(4) & ","
            strColour3 &= "'#FFFF00',"
            strLegend3 &= "'Incomplete TC Data',"
        End If

        If TCSingleDt.Rows.Count > 0 Then
            strLine4 &= "" & a(5) & ","
            strColour4 &= "'#FFFF00',"
            strLegend4 &= "'TC Data Not Available',"
        End If


        'If dtDoubleIncompete.Rows.Count > 0 Then
        '    strLine4 &= "" & a(6) & ","
        '    strColour4 &= "'#FFFF00',"
        '    strLegend4 &= "'Incomplete TC Data',"
        'End If

        'If TCDoubleDt.Rows.Count > 0 Then
        '    strLine4 &= "" & a(7) & ","
        '    strColour4 &= "'#FFFF00',"
        '    strLegend4 &= "'TC Data Not Available',"
        'End If




        If Trim(strLine1) <> "" Then
            strLine1 = strLine1.Remove(strLine1.LastIndexOf(","))
        End If
        If Trim(strLine2) <> "" Then
            strLine2 = strLine2.Remove(strLine2.LastIndexOf(","))
        End If
        If Trim(strLine3) <> "" Then
            strLine3 = strLine3.Remove(strLine3.LastIndexOf(","))
        End If

        If Trim(strLine4) <> "" Then
            strLine4 = strLine4.Remove(strLine4.LastIndexOf(","))
        End If
        If Trim(strLine5) <> "" Then
            strLine5 = strLine5.Remove(strLine5.LastIndexOf(","))
        End If


        If Trim(strLine6) <> "" Then
            strLine6 = strLine6.Remove(strLine6.LastIndexOf(","))
        End If

        If Trim(strColour1) <> "" Then
            strColour1 = strColour1.Remove(strColour1.LastIndexOf(","))
        End If
        If Trim(strColour2) <> "" Then
            strColour2 = strColour2.Remove(strColour2.LastIndexOf(","))
        End If

        If Trim(strColour3) <> "" Then
            strColour3 = strColour3.Remove(strColour3.LastIndexOf(","))
        End If


        If Trim(strColour4) <> "" Then
            strColour4 = strColour4.Remove(strColour4.LastIndexOf(","))
        End If
        If Trim(strColour5) <> "" Then
            strColour5 = strColour5.Remove(strColour5.LastIndexOf(","))
        End If
        If Trim(strColour6) <> "" Then
            strColour6 = strColour6.Remove(strColour6.LastIndexOf(","))
        End If

        If Trim(strLegend1) <> "" Then
            strLegend1 = strLegend1.Remove(strLegend1.LastIndexOf(","))
        End If
        If Trim(strLegend2) <> "" Then
            strLegend2 = strLegend2.Remove(strLegend2.LastIndexOf(","))
        End If

        If Trim(strLegend3) <> "" Then
            strLegend3 = strLegend3.Remove(strLegend3.LastIndexOf(","))
        End If

        If Trim(strLegend4) <> "" Then
            strLegend4 = strLegend4.Remove(strLegend4.LastIndexOf(","))
        End If

        If Trim(strLegend5) <> "" Then
            strLegend5 = strLegend5.Remove(strLegend5.LastIndexOf(","))
        End If


        If Trim(strLegend6) <> "" Then
            strLegend6 = strLegend6.Remove(strLegend6.LastIndexOf(","))
        End If


        dtSingle.Clear()
        dtSingle_LFC.Clear()
        dtSingle_Orig.Clear()
        dtDouble.Clear()
        dtDouble_LFC.Clear()
        dtDouble_Orig.Clear()
        mdt.Clear()
        dtSingleIncompete.Clear()
        dtDoubleIncompete.Clear()
        TCDoubleDt.Clear()
        TCDoubleDt.Clear()
        maindt.Clear()



        Dim s As New StringBuilder("")
        s.Append("<script>$(document).ready(function () {var " & a(4) & "," & a(5) & ";")
        s.Append(line1)
        s.Append(line2)
        s.Append(line3)
        s.Append(line4)
        s.Append(line5)
        s.Append(line6)

        s.Append("var endDt = moment('" & enDate & "').add(10, 'minutes').format('YYYY-MM-DD hh:mm:ss a');")
        s.Append("var stDt = moment('" & stDate & "').add(-10, 'minutes').format('YYYY-MM-DD hh:mm:ss a');")
        If Trim(strLine1) <> "" Then
            s.Append("" & a(4) & " = $.jqplot('" & c2 & "', [" & strLine1 & "," & strLine3 & "], {title: 'LFC POSITION TOP SIDE IN CASTER',seriesColors: [" & strColour1 & "," & strColour3 & "], grid: { backgroundColor: ['#ecf0f1'] },axes: {")
            s.Append("xaxis: {renderer: $.jqplot.DateAxisRenderer,tickRenderer: $.jqplot.CanvasAxisTickRenderer,tickOptions:{formatString: '%H:%M:%S',fontSize: '10pt',angle: -40},")
            s.Append("min:stDt,max: endDt,}, yaxis: {label: 'Thermocouple Number',labelRenderer: $.jqplot.CanvasAxisLabelRenderer,labelOptions: {fontFamily: 'Helvetica',fontSize: '12pt'")
            s.Append(" },tickOptions: {fontSize: '10pt',labelPosition: 'middle'},min: 3,max: 10,tickInterval: '1'},},seriesDefaults: {showLine: false,showMarkers: true,seriesColors: true},legend:{show:true,placement: 'outsideGrid',rendererOptions: {numberRows: 1, marginTop: 10 }, location: 's', labels: [" & strLegend1 & "," & strLegend3 & "], renderer: $.jqplot.EnhancedLegendRenderer }, ")
            s.Append("grid: true,highlighter: {show: true,sizeAdjust: 5.0,},cursor: {show: true,zoom: true}});")
        Else
            fl1 = 1
        End If
        ' line2
        If Trim(strLine2) <> "" Then
            s.Append("" & a(5) & " = $.jqplot('" & c1 & "', [" & strLine2 & "," & strLine4 & "], {title: 'LFC POSITION BOTTOM SIDE IN CASTER',seriesColors: [" & strColour2 & "," & strColour4 & "], grid: { backgroundColor: ['#ecf0f1'] },axes: {xaxis: {renderer: $.jqplot.DateAxisRenderer,tickRenderer: $.jqplot.CanvasAxisTickRenderer,tickOptions:")
            s.Append("{formatString: '%H:%M:%S',fontSize: '10pt',angle: -40},min:stDt,max: endDt,},yaxis: {label: 'Thermocouple Number',labelRenderer: $.jqplot.CanvasAxisLabelRenderer,labelOptions: {fontFamily: 'Helvetica',fontSize: '12pt'},")
            s.Append("tickOptions: {fontSize: '10pt',labelPosition: 'middle'},min: 13,max: 20,tickInterval: '1'},},seriesDefaults: {showLine: false,showMarkers: true,seriesColors: true},legend:{show:true,placement: 'outsideGrid',rendererOptions: {numberRows: 1, marginTop: 10 }, location: 's', labels: [" & strLegend2 & "," & strLegend4 & "], renderer: $.jqplot.EnhancedLegendRenderer }, ")
            s.Append("grid: true,highlighter: {show: true,sizeAdjust: 5.0,},cursor: {show: true,zoom: true}});")
        Else
            fl2 = 1
        End If
        s.Append("var vline1=[];")




        Dim dtime As DateTime
        For row As Integer = 0 To ds.Tables(1).Rows.Count - 1
            For slabs As Integer = 0 To slabid.Rows.Count - 1
                If ds.Tables(1).Rows(row)(0) = slabid.Rows(slabs)(1) Then
                    If slabid.Rows(slabs)(0) = "LFC Predicted" Then
                        s.Append("var o = {                dashedVerticalLine: {                    name: '" & ds.Tables(1).Rows(row)(0) & "',                    x: new $.jsDate('" & CDate(ds.Tables(1).Rows(row)(1)).ToString("yyyy-MM-dd HH:mm:ss") & "').getTime(),        color: 'rgb(255,0,0)',           lineWidth: 4,                    showTooltip: true,                    tooltipFormatString: '<table style=""background-color:#77F486; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>Slab Id</td><td>:</td><td>&nbsp;</td><td>" & ds.Tables(1).Rows(row)(0) & "</td></tr></table>' }            };")
                        '  s.Append("var o = {                dashedVerticalLine: {                    name: '" & ds.Tables(1).Rows(row)(0) & "',                    x: new $.jsDate('" & CDate(ds.Tables(1).Rows(row)(1)).ToString("yyyy-MM-dd HH:mm:ss") & "').getTime(),                    lineWidth: 2,                    showTooltip: true,                   tooltipFormatString:'" & ds.Tables(1).Rows(row)(0) & "',                    color: 'rgb(153, 120, 24)',                    shadow: false       }            };")
                        s.Append("vline1.push(o);")
                    Else
                        s.Append("var o = {                dashedVerticalLine: {                    name: '" & ds.Tables(1).Rows(row)(0) & "',                    x: new $.jsDate('" & CDate(ds.Tables(1).Rows(row)(1)).ToString("yyyy-MM-dd HH:mm:ss") & "').getTime(),                   lineWidth: 2,                    showTooltip: true,                    tooltipFormatString: '<table style=""background-color:#77F486; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>Slab Id</td><td>:</td><td>&nbsp;</td><td>" & ds.Tables(1).Rows(row)(0) & "</td></tr></table>' }            };")
                        '  s.Append("var o = {                dashedVerticalLine: {                    name: '" & ds.Tables(1).Rows(row)(0) & "',                    x: new $.jsDate('" & CDate(ds.Tables(1).Rows(row)(1)).ToString("yyyy-MM-dd HH:mm:ss") & "').getTime(),                    lineWidth: 2,                    showTooltip: true,                   tooltipFormatString:'" & ds.Tables(1).Rows(row)(0) & "',                    color: 'rgb(153, 120, 24)',                    shadow: false       }            };")
                        s.Append("vline1.push(o);")
                    End If
                End If
            Next
            's.Append("var o = {dashedVerticalLine: { name: '" & ds.Tables(1).Rows(row)(0) & "', x: new $.jsDate('" & CDate(ds.Tables(1).Rows(row)(1)).ToString("yyyy-MM-dd HH:mm:ss") & "').getTime(), lineWidth: 2, showTooltip: true, tooltipFormatString: '<table style=""background-color:#77F486; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>Slab Id</td><td>:</td><td>&nbsp;</td><td>" & ds.Tables(1).Rows(row)(0) & "</td></tr></table>' }};")
            '' s.Append("var o = { dashedVerticalLine: { name: '" & ds.Tables(1).Rows(row)(0) & "', x: new $.jsDate('" & CDate(ds.Tables(1).Rows(row)(1)).ToString("yyyy-MM-dd HH:mm:ss") & "').getTime(), lineWidth: 2, showTooltip: true, tooltipFormatString:'" & ds.Tables(1).Rows(row)(0) & "', color: 'rgb(153, 120, 24)', shadow: false } };")
            's.Append("vline1.push(o);")
            If row = 0 Then
                dtime = CDate(ds.Tables(1).Rows(row)(2))
            Else
                If dtime < CDate(ds.Tables(1).Rows(row)(2)) Then
                    dtime = CDate(ds.Tables(1).Rows(row)(2))
                End If
            End If


            If row = ds.Tables(1).Rows.Count - 1 Then
                s.Append("var o = { verticalLine: { name: '" & ds.Tables(1).Rows(row)(0) & "', x: new $.jsDate('" & dtime.ToString("yyyy-MM-dd HH:mm:ss") & "').getTime(), lineWidth: 4, showTooltip: true, tooltipFormatString:'" & ds.Tables(1).Rows(row)(0) & "', color: 'rgb(255, 0, 0)', shadow: false } };")
                s.Append("vline1.push(o);")

            End If



        Next

        For k As Integer = 0 To ds.Tables(0).Rows.Count - 1

            If IsDBNull(ds.Tables(0).Rows.Item(k)(2)) OrElse String.IsNullOrEmpty(ds.Tables(0).Rows.Item(k)(2)) Then
                s.Append("var o = { verticalLine: { name: '', x: new $.jsDate('" & CDate(ds.Tables(0).Rows(k)(0)).ToString("yyyy-MM-dd HH:mm:ss") & "').getTime(), lineWidth: 5, showTooltip: true, tooltipFormatString:'" & ds.Tables(0).Rows(k)(0) & "', color: 'rgb(255,255,0)', shadow: false } };")
                s.Append("vline1.push(o);")
            End If



        Next
        If Trim(strLine1) <> "" Then
            s.Append("if (vline1.length > 0) { " & a(4) & ".plugins.canvasOverlay = new $.jqplot.CanvasOverlay({ show: true, objects: vline1 }); " & a(4) & ".replot(); }")
        End If
        If Trim(strLine2) <> "" Then
            s.Append("if (vline1.length > 0) { " & a(5) & ".plugins.canvasOverlay = new $.jqplot.CanvasOverlay({ show: true, objects: vline1 }); " & a(5) & ".replot(); }")
        End If

        ' s.Append("if (vline1.length > 0) { " & a(4) & ".plugins.canvasOverlay = new $.jqplot.CanvasOverlay({ show: true, objects: vline1 }); " & a(4) & ".replot(); " & a(5) & ".plugins.canvasOverlay = new $.jqplot.CanvasOverlay({ show: true, objects: vline1 }); " & a(5) & ".replot(); }")
        s.Append("});</script>")

        lit.Text = s.ToString



    End Sub

End Class
