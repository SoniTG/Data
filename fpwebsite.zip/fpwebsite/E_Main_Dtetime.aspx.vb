﻿
Partial Class E_Main_Dtetime
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Try
                TextBox4.Text = Now.ToString("yyyy-MM-dd HH:mm:ss")
            Catch ex As Exception

            End Try

        End If
    End Sub
End Class
