﻿Imports System.Data
Imports System.IO
Imports System.Web.Services
Imports System.Data.SqlClient

Partial Class Equipment_Business_Rule
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                objController.PopulateBusinessRule(gvBusinessRule)
            Catch ex As Exception

            End Try
        End If
    End Sub

    Private Sub btnLoginSave_Click(sender As Object, e As EventArgs) Handles btnLoginSave.Click

        Try

            If txtUsername.Text.Trim() IsNot "" Then

                If txtPassword.Text.Trim() = "" Then
                    ' UserMsgBoxWarning("Enter password.")
                    UserMsgBoxError("Enter password.")
                    txtPassword.Focus()
                Else
                    If objController.IsAValidUserForShearMultiEqup(txtUsername.Text.Trim(), txtPassword.Text.Trim()) Then
                        hfLogin.Value = "Yes"
                        Session("UserName") = txtUsername.Text.Trim()
                        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "Pop", "$('#LoginModal').modal('hide');", True)
                        txtUsername.Text = ""
                        txtPassword.Text = ""
                    Else
                        hfLogin.Value = "No"
                        txtUsername.Text = ""
                        txtPassword.Text = ""
                        ' UserMsgBoxWarning("Incorrect login details.")
                        UserMsgBoxError("Incorrect login details.")
                        Exit Sub
                    End If
                End If
            Else
                '  UserMsgBoxWarning("Enter username.")
                UserMsgBoxError("Enter username.")
                txtUsername.Focus()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        'Response.Redirect("index.aspx")
        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "Pop", "$('#LoginModal').modal('hide');", True)
        hfLogin.Value = "No"
        gvBusinessRule.EditIndex = -1
        objController.PopulateBusinessRule(gvBusinessRule)

    End Sub

    Private Sub gvBusinessRule_RowEditing(sender As Object, e As GridViewEditEventArgs) Handles gvBusinessRule.RowEditing
        If hfLogin.Value = "Yes" Then
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "Pop", "$('#LoginModal').modal('hide');", True)
            gvBusinessRule.EditIndex = e.NewEditIndex
            objController.PopulateBusinessRule(gvBusinessRule)
        Else
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "Pop", "$('#LoginModal').modal('show');", True)

        End If

    End Sub

    Private Sub gvBusinessRule_RowUpdating(sender As Object, e As GridViewUpdateEventArgs) Handles gvBusinessRule.RowUpdating
        If hfLogin.Value = "Yes" Then
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "Pop", "$('#LoginModal').modal('hide');", True)
            Dim index = Convert.ToInt32(e.RowIndex)
            Session("EQUIPMENT") = CType(gvBusinessRule.Rows(index).Cells(2).FindControl("lblEQUIPMENT"), Label).Text.Trim()
            Session("BUSINESS_RULE") = CType(gvBusinessRule.Rows(index).Cells(3).FindControl("lblB_RULE"), Label).Text.Trim()
            Session("CASTER") = CType(gvBusinessRule.Rows(index).Cells(4).FindControl("lblCaster"), Label).Text.Trim()
            If CType(gvBusinessRule.Rows(index).Cells(5).FindControl("txtALARM_LOW"), TextBox).Text.Trim() = "" Then
                Session("ALARM_LOW") = 0
            Else
                Session("ALARM_LOW") = CType(gvBusinessRule.Rows(index).Cells(5).FindControl("txtALARM_LOW"), TextBox).Text.Trim()
            End If
            If CType(gvBusinessRule.Rows(index).Cells(6).FindControl("txtALARM_HIGH"), TextBox).Text.Trim() = "" Then
                Session("ALARM_HIGH") = 0
            Else
                Session("ALARM_HIGH") = CType(gvBusinessRule.Rows(index).Cells(6).FindControl("txtALARM_HIGH"), TextBox).Text.Trim()
            End If
            'If CType(gvBusinessRule.Rows(index).Cells(6).FindControl("txtLCL"), TextBox).Text.Trim() = "" Then
            '    Session("LCL") = 0
            'Else
            '    Session("LCL") = CType(gvBusinessRule.Rows(index).Cells(6).FindControl("txtLCL"), TextBox).Text.Trim()
            'End If
            'If CType(gvBusinessRule.Rows(index).Cells(7).FindControl("txtUCL"), TextBox).Text.Trim() = "" Then
            '    Session("UCL") = 0
            'Else
            '    Session("UCL") = CType(gvBusinessRule.Rows(index).Cells(7).FindControl("txtUCL"), TextBox).Text.Trim()
            'End If

            Dim val As Integer = 0
            Dim val1 As Integer = 0
            val = objController.UpdateBusinessRule(Session("EQUIPMENT"), Session("BUSINESS_RULE"), Session("CASTER"), Session("ALARM_LOW"), Session("ALARM_HIGH"))
            If val > 0 Then
                val1 = objController.InsertBusinessRuleLog(Session("BUSINESS_RULE"), Session("ALARM_LOW"), Session("ALARM_HIGH"), Session("UserName"), Session("CASTER"))
                If val1 > 0 Then
                    gvBusinessRule.EditIndex = -1
                    objController.PopulateBusinessRule(gvBusinessRule)
                End If

            End If
            'Else
            '    UserMsgBoxError("To update records please login.")
        End If




    End Sub

    Private Sub gvBusinessRule_RowCancelingEdit(sender As Object, e As GridViewCancelEditEventArgs) Handles gvBusinessRule.RowCancelingEdit
        'If hfLogin.Value = "Yes" Then
        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "Pop", "$('#LoginModal').modal('hide');", True)
        gvBusinessRule.EditIndex = -1
        objController.PopulateBusinessRule(gvBusinessRule)
        'End If


    End Sub

    Private Sub gvBusinessRule_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles gvBusinessRule.RowCommand
        Try
            If hfLogin.Value = "Yes" Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "Pop", "$('#LoginModal').modal('hide');", True)
                'gvBusinessRule.EditIndex = e.NewEditIndex
                'objController.PopulateBusinessRule(gvBusinessRule)
                'Dim index As Integer = CType(CType(e.CommandSource, Button).NamingContainer, GridViewRow).RowIndex
                'Dim BRule As String = CType(gvBusinessRule.Rows(index).Cells(0).FindControl("lblB_RULE"), Label).Text.Trim()
                Dim index As Integer = CType(CType(e.CommandSource, Button).NamingContainer, GridViewRow).RowIndex
                Dim BRule As String = CType(gvBusinessRule.Rows(index).Cells(2).FindControl("lblB_RULE"), Label).Text.Trim()
                Dim Caster As String = CType(gvBusinessRule.Rows(index).Cells(3).FindControl("lblCaster"), Label).Text.Trim()
                'Dim Flag As String = CType(gvBusinessRule.Rows(index).Cells(5).FindControl("btnON"), Button).Text.Trim()
                'Dim Flag1 As String = CType(gvBusinessRule.Rows(index).Cells(6).FindControl("btnOFF"), Button).Text.Trim()
                Dim Flag As String = CType(e.CommandSource, Button).Text.Trim()
                Dim val As Integer = 0
                If Flag = "ON" Then
                    val = objController.UpdateBusinessRuleForSMS("FLAG", BRule, "Y", Caster)
                    If val > 0 Then
                        UserMsgBoxSuccess("SMS alert on successful.")
                        gvBusinessRule.EditIndex = -1
                        objController.PopulateBusinessRule(gvBusinessRule)
                    End If

                ElseIf Flag = "OFF"
                    val = objController.UpdateBusinessRuleForSMS("FLAG", BRule, "N", Caster)
                    If val > 0 Then
                        UserMsgBoxSuccess("SMS alert off successful.")
                        gvBusinessRule.EditIndex = -1
                        objController.PopulateBusinessRule(gvBusinessRule)
                    End If
                End If

            Else
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "Pop", "$('#LoginModal').modal('show');", True)

            End If



        Catch ex As Exception

        End Try
    End Sub
End Class
