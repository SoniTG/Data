﻿Imports System.Data
Imports System.IO
Imports System.Math
Partial Class FeDissolutionModel
    Inherits System.Web.UI.Page
    Dim objcontroller As New Controller
    Sub UserMsgBox(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objcontroller.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As DateTime = DateTime.Now.AddDays(-29)
                'Dim dtStart As Date = Date.Today.AddDays(-29)
                Dim dst As String = dtStart.ToString("yyyy-MM-dd 00:00:01")
                Dim dtEnd As DateTime = DateTime.Now
                'Dim dtEnd As Date = Date.Today
                Dim det As String = dtEnd.ToString("yyyy-MM-dd 23:59:59")
                Dim dt As DataTable = objcontroller.CalFeDisso_Weight(dst, det)
                Dim weight As Double = Round(dt.Rows(0)(0))
                lblGAWeight.Text = weight
                Dim RaiseLevel As Double = Round((0.13 * 200 * 1000 / 100))
                lblAlReqToRaiseAlLevel.Text = RaiseLevel
                Dim FeSolubility As Double = Round((0.022 * 200 * 1000 / 100 * 135 / 112))
                lblAlReqFeSolubility.Text = FeSolubility
                Dim dt1 As DataTable = objcontroller.Cal_STRIP_FE_KG_DISSOLVED(dst, det)
                'Dim Fedross As Double = Round(dt1.Rows(0)(0))
                'Dim Fedross As Double = Round(dt1.Compute("sum(Fe)", ""))
                Dim Fedross As Double = dt1.Compute("sum(Fe)", "")

                lblCalFeInDross.Text = String.Format("{0:0.000}", Fedross)
                '            lblCalDross.Text = Round(Fedross * 10 / 1000, 2)
                lblCalDross.Text = Round(Fedross * 10, 2)
                'Dim AlDross As Double = Round(dt1.Rows(0)(1))
                'Dim AlDross As Double = Round(dt1.Compute("sum(Al)", ""))
                Dim AlDross As Double = dt1.Compute("sum(Al)", "")
                lblAlReqConvrtBottomDross.Text = String.Format("{0:0.000}", AlDross)
                Dim totalAlCharged As Double = Round(FeSolubility + AlDross + RaiseLevel)
                lblTotalAlCharged.Text = totalAlCharged
                Dim recoveryloss As Double = Round(totalAlCharged * 10 / 100)
                lblRecoveryLossError.Text = recoveryloss
                Dim blockcharge As Double = Round((totalAlCharged + recoveryloss)) * 100 / 5 / 100
                lblMinAlBlocksCharged.Text = Round(blockcharge)
                lblNoOfDaysGACampaign.Text = objcontroller.CalGANoOfDays(dst, det)

                objcontroller.CalGAStartEndDate(lblGAStartDate, lblGAEndDate, dst, det)
                Dim DoublePreviousDross As Double = objcontroller.CalPreviousDross(dst, det) * 10
                'DrawChart(dst, det, DoublePreviousDross)
                DrawChart(dst, det, 0.0)

            Catch ex As Exception

            End Try
        End If


    End Sub

    Sub DrawChart(ByVal stDate As String, ByVal endDt As String, ByVal PreviousDross As Double)
        Try

            Dim ds As DataSet = objcontroller.CalChartData(stDate, endDt)
            Dim dt As DataTable = ds.Tables(0)
            Dim stAlphabet As Integer = Asc("a")
            Dim s As New StringBuilder("<script>")
            s.Append("FeTank = Morris.Area({element:  'chart',data: [{y:'0',")
            s.Append(Chr(stAlphabet) & "0:null")
            For row As Integer = 0 To dt.Rows.Count - 1
                'If row > 0 Then
                s.Append(",")
                'End If
                s.Append(Chr(stAlphabet) & ((row + 1).ToString) & ":null")
            Next


            Dim tankHeight As Integer = 2200
            Dim unitHeight As Double = (100 / 2200)
            s.Append("},{y:'1',")
            Dim ykeys As String = ""
            Dim labels As String = ""
            For row As Integer = 0 To dt.Rows.Count - 1
                If row > 0 Then
                    s.Append(",")
                    ykeys &= ","
                    labels &= ","
                End If
                s.Append("" & Chr(stAlphabet) & ((row + 1).ToString) & ":" & dt.Rows(row)(0) * unitHeight)
                ykeys &= "'" & Chr(stAlphabet) & ((row + 1).ToString) & "'"
                labels &= "'Day" & (row + 1) & "'"
            Next
            s.Append("},{y:'2',")
            s.Append(Chr(stAlphabet) & "0:null")
            For row As Integer = 0 To dt.Rows.Count - 1
                'If row > 0 Then
                s.Append(",")
                'End If
                s.Append(Chr(stAlphabet) & ((row + 1).ToString) & ":null")
            Next
            s.Append("}],xkey:   'y', padding: 0,ykeys: [")
            s.Append(ykeys)
            s.Append("],labels: [")
            s.Append(labels)
            s.Append("],ymin: 0,ymax: 100,axes: false,hideHover: true,grid:false,resize: true,pointSize:0,lineColors: colors});")
            If dt.Rows.Count > 10 Then
                s.Append("</script>")
            Else
                s.Append("prepareLegendFe();</script>")
            End If
            litChart.Text = s.ToString()

            'Cummulative Chart
            s.Clear()
            s.Append("<script> Morris.Bar({element:  'chart1',data: [")
            Dim cummulative As Double = PreviousDross
            Dim dt1 As DataTable = ds.Tables(1)
            's.Append("{x:'Prev',y:" & PreviousDross & "}")
            For row As Integer = 0 To dt1.Rows.Count - 1
                If row > 0 Then
                    s.Append(",")
                End If
                cummulative += Math.Round(dt1.Rows(row)(0), 3)
                s.Append("{x:'Day" & (row + 1) & "',y:" & cummulative & "}")
            Next
            s.Append("],xkey: 'x', ykeys: ['y'],labels: ['y'],barRatio: 0.4,barColors:function(row,series,type){if (row.label=='Prev') return '#696969'; else return '#0b62a4';},xLabelAngle: 35,hideHover:  'auto'});</script>")

            litChart1.Text = s.ToString

        Catch ex As Exception

        End Try
    End Sub

    Sub Calculate()
        Try

            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            Dim dt As DataTable = objcontroller.CalFeDisso_Weight(dtStart, dtEnd)
            Dim weight As Double = Round(dt.Rows(0)(0))
            lblGAWeight.Text = weight
            Dim RaiseLevel As Double = Round((0.13 * 200 * 1000 / 100))
            lblAlReqToRaiseAlLevel.Text = RaiseLevel
            Dim FeSolubility As Double = Round((0.022 * 200 * 1000 / 100 * 135 / 112))
            lblAlReqFeSolubility.Text = FeSolubility
            Dim dt1 As DataTable = objcontroller.Cal_STRIP_FE_KG_DISSOLVED(dtStart, dtEnd)
            'Dim Fedross As Double = Round(dt1.Rows(0)(0))
            Dim Fedross As Double = dt1.Compute("sum(Fe)", "")

            lblCalFeInDross.Text = String.Format("{0:0.000}", Fedross)
            'lblCalDross.Text = Round(Fedross * 10 / 1000, 2)
            lblCalDross.Text = Round(Fedross * 10, 2)
            'Dim AlDross As Double = Round(dt1.Rows(0)(1))
            Dim AlDross As Double = dt1.Compute("sum(Al)", "")
            lblAlReqConvrtBottomDross.Text = String.Format("{0:0.000}", AlDross)
            Dim totalAlCharged As Double = Round(FeSolubility + AlDross + RaiseLevel)
            lblTotalAlCharged.Text = totalAlCharged
            Dim recoveryloss As Double = Round(totalAlCharged * 10 / 100)
            lblRecoveryLossError.Text = recoveryloss
            Dim blockcharge As Double = Round((totalAlCharged + recoveryloss)) * 100 / 5 / 100
            lblMinAlBlocksCharged.Text = Round(blockcharge)
            lblNoOfDaysGACampaign.Text = objcontroller.CalGANoOfDays(dtStart, dtEnd)
            objcontroller.CalGAStartEndDate(lblGAStartDate, lblGAEndDate, dtStart, dtEnd)

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click
        Try
            Calculate()
            Dim DoublePreviousDross As Double = objcontroller.CalPreviousDross(hfFrom.Value, hfTo.Value) * 10
            DrawChart(hfFrom.Value, hfTo.Value, DoublePreviousDross)
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Try
            objcontroller.SaveResetDateTime()
            UserMsgBox("Reset Datetime Saved Successfully.")
        Catch ex As Exception

        End Try

    End Sub
End Class
