﻿Imports System.Data
Imports System.IO

Imports System.Web
Imports System.Web.Services

Imports System.Net
Imports System.Data.SqlClient
Imports System.Web.Script.Serialization
Imports System.Drawing
Imports System.Web.UI

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
<System.Web.Script.Services.ScriptService()>
<WebService(Namespace:="http://tempuri.org/")>
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)>
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Furnace_Equipment_Tracker
    Inherits System.Web.UI.Page

    Dim objController As New Controller
    Dim objdatahandler As New DataHandler

    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "alert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString
    Dim maindt As New DataTable
    '  Public Property responseObj As Object
    Function getdatatable(ByVal query As String) As DataTable
        Dim fndatatable As New DataTable
        'Dim connection As String = "Password=Welcome@135;Persist Security Info=True;User ID=153521;Initial Catalog=WRM_blt_data;Data Source=176.0.0.60\lptgsqldev"
        Dim connection As String = "Password=Welcome@135;Persist Security Info=True;User ID=153521;Initial Catalog=FP_PROCESS_DATA;Data Source=176.0.0.60\lptgsqldev"

        Using con As New SqlConnection(connection)
            Using cmd As New SqlCommand(query, con)
                cmd.CommandType = CommandType.Text
                Using sda As New SqlDataAdapter(cmd)
                    sda.SelectCommand.CommandTimeout = 100000

                    'Using dt As New DataTable()
                    sda.Fill(fndatatable)
                    'End Using
                End Using
            End Using
        End Using
        Return fndatatable
    End Function

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    txtDate_TextChanged()
                End If

            Catch ex As Exception

            End Try

        End If
        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                'Dim dtStart As String = Now.AddDays(-7).ToString("yyyy-MM-dd HH:mm:ss")
                'Dim dtEnd As String = Now.ToString("yyyy-MM-dd HH:mm:ss")

                'Now.ToString("yyyy-MM-dd HH:mm:ss")
                Dim dtStart As String = DateTime.Now.AddDays(-29).ToString("yyyy-MM-dd HH:mm")
                'Dim dtStart As DateTime = DateTime.Now.AddMonths(-4).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

                DrawChart__SEC1_CHART1(dtStart, dtEnd)
                DrawChart__SEC1_CHART1_LINEB(dtStart, dtEnd)
                DrawChart__SEC2_CHART2(dtStart, dtEnd)
                DrawChart__SEC2_CHART2_LINEB(dtStart, dtEnd)
                DrawChart__SEC3_CHART3(dtStart, dtEnd)
                DrawChart__SEC3_CHART3_LINEB(dtStart, dtEnd)
                DrawChart__MANIFOLD_LINEA(dtStart, dtEnd)
                DrawChart__MANIFOLD_LINEB(dtStart, dtEnd)


                ''===================================Added for Gas Monitoring By Tirthankar 10-July-23 ====================================

                DrawChart__SECGasMonitr_LineA(dtStart, dtEnd)
                DrawChart__SECGasMonitr_LineB(dtStart, dtEnd)

                '============================GRID VALUES===================================
                ''===================================Added for Damper Opening Monitoring By Tirthankar 31-Aug-23 ====================================

                DrawChart__DamperOpenSec1_Furn1()
                DrawChart__DamperOpenSec2_Furn1()
                DrawChart__DamperOpenSec3_Furn1()

                DrawChart__DamperOpenSec1_Furn2()
                DrawChart__DamperOpenSec2_Furn2()
                DrawChart__DamperOpenSec3_Furn2()

                DrawChart__CvValidation_Furn1()
                DrawChart__CvValidation_Furn2()


                Dim dtStartForBTP As String = DateTime.Now.AddYears(-1).ToString("yyyy-MM-dd HH:mm")
                Dim dtEndForBTP As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

                BestTimePerformance_Sec1LineA(dtStartForBTP, dtEndForBTP)
                BestTimePerformance_Sec2LineA(dtStartForBTP, dtEndForBTP)
                BestTimePerformance_Sec3LineA(dtStartForBTP, dtEndForBTP)

                BestTimePerformance_Sec1LineB(dtStartForBTP, dtEndForBTP)
                BestTimePerformance_Sec2LineB(dtStartForBTP, dtEndForBTP)
                BestTimePerformance_Sec3LineB(dtStartForBTP, dtEndForBTP)

                'DrawChart__DamperOpenSec2_Furn1(dtStart, dtEnd)
                'DrawChart__DamperOpenSec3_Furn1(dtStart, dtEnd)

                'DrawChart__DamperOpenSec1_Furn2(dtStart, dtEnd)
                'DrawChart__DamperOpenSec2_Furn2(dtStart, dtEnd)
                'DrawChart__DamperOpenSec3_Furn2(dtStart, dtEnd)

                '============================GRID VALUES===================================


                Try
                    Dim DTZONE1_LINEA As DataTable = objController.populate_zone1_LINEA()
                    Dim DTZONE1_LINEB As DataTable = objController.populate_zone1_LINEB()

                    Dim DTZONE2_LINEA As DataTable = objController.populate_zone2_LINEA()
                    Dim DTZONE2_LINEB As DataTable = objController.populate_zone2_LINEB()

                    Dim DTZONE3_LINEA As DataTable = objController.populate_zone3_LINEA()
                    Dim DTZONE3_LINEB As DataTable = objController.populate_zone3_LINEB()

                    Dim DTZONE4_LINEA As DataTable = objController.populate_zone4_LINEA()
                    Dim DTZONE4_LINEB As DataTable = objController.populate_zone4_LINEB()

                    Dim DTZONE5_LINEA As DataTable = objController.populate_zone5_LINEA()
                    Dim DTZONE5_LINEB As DataTable = objController.populate_zone5_LINEB()

                    Dim DTZONE6_LINEA As DataTable = objController.populate_zone6_LINEA()
                    Dim DTZONE6_LINEB As DataTable = objController.populate_zone6_LINEB()

                    Dim DTZONE7_LINEA As DataTable = objController.populate_zone7_LINEA()
                    Dim DTZONE7_LINEB As DataTable = objController.populate_zone7_LINEB()

                    Dim DTZONE8_LINEA As DataTable = objController.populate_zone8_LINEA()
                    Dim DTZONE8_LINEB As DataTable = objController.populate_zone8_LINEB()

                    Dim DTZONE9_LINEA As DataTable = objController.populate_zone9_LINEA()
                    Dim DTZONE9_LINEB As DataTable = objController.populate_zone9_LINEB()




                    If DTZONE1_LINEA.Rows.Count > 0 Then
                        '===============ZONE1=====================================
                        valveopen_A_zone1.Text = DTZONE1_LINEA.Rows(0)("ZONE1_GAS_VLV").ToString()
                        line_zoneA_1.Text = DTZONE1_LINEA.Rows(0)("ZONE1_GAS_FLOW").ToString()

                        valveopen_B_zone1.Text = DTZONE1_LINEB.Rows(0)("ZONE1_GAS_VLV").ToString()
                        line_B_zone1.Text = DTZONE1_LINEB.Rows(0)("ZONE1_GAS_FLOW").ToString()
                        '===============ZONE2=====================================
                        valveopen_A_zone2.Text = DTZONE2_LINEA.Rows(0)("ZONE2_GAS_VLV").ToString()
                        line_zoneA_2.Text = DTZONE2_LINEA.Rows(0)("ZONE2_GAS_FLOW").ToString()

                        valveopen_B_zone2.Text = DTZONE2_LINEB.Rows(0)("ZONE2_GAS_VLV").ToString()
                        line_B_zone2.Text = DTZONE2_LINEB.Rows(0)("ZONE2_GAS_FLOW").ToString()
                        '===============ZONE3=====================================
                        valveopen_A_zone3.Text = DTZONE3_LINEA.Rows(0)("ZONE3_GAS_VLV").ToString()
                        line_zoneA_3.Text = DTZONE3_LINEA.Rows(0)("ZONE3_GAS_FLOW").ToString()

                        valveopen_B_zone3.Text = DTZONE3_LINEB.Rows(0)("ZONE3_GAS_VLV").ToString()
                        line_B_zone3.Text = DTZONE3_LINEB.Rows(0)("ZONE3_GAS_FLOW").ToString()
                        '===============ZONE4=====================================
                        valveopen_A_zone4.Text = DTZONE4_LINEA.Rows(0)("ZONE4_GAS_VLV").ToString()
                        line_zoneA_4.Text = DTZONE4_LINEA.Rows(0)("ZONE4_GAS_FLOW").ToString()

                        valveopen_B_zone4.Text = DTZONE4_LINEB.Rows(0)("ZONE4_GAS_VLV").ToString()
                        line_B_zone4.Text = DTZONE4_LINEB.Rows(0)("ZONE4_GAS_FLOW").ToString()
                        '===============ZONE5=====================================
                        valveopen_A_zone5.Text = DTZONE5_LINEA.Rows(0)("ZONE5_GAS_VLV").ToString()
                        line_zoneA_5.Text = DTZONE5_LINEA.Rows(0)("ZONE5_GAS_FLOW").ToString()

                        valveopen_B_zone5.Text = DTZONE5_LINEB.Rows(0)("ZONE5_GAS_VLV").ToString()
                        line_B_zone5.Text = DTZONE5_LINEB.Rows(0)("ZONE5_GAS_FLOW").ToString()
                        '===============ZONE6=====================================
                        valveopen_A_zone6.Text = DTZONE6_LINEA.Rows(0)("ZONE6_GAS_VLV").ToString()
                        line_zoneA_6.Text = DTZONE6_LINEA.Rows(0)("ZONE6_GAS_FLOW").ToString()

                        valveopen_B_zone6.Text = DTZONE6_LINEB.Rows(0)("ZONE6_GAS_VLV").ToString()
                        line_B_zone6.Text = DTZONE6_LINEB.Rows(0)("ZONE6_GAS_FLOW").ToString()
                        '===============ZONE7=====================================
                        valveopen_A_zone7.Text = DTZONE7_LINEA.Rows(0)("ZONE7_GAS_VLV").ToString()
                        line_zoneA_7.Text = DTZONE7_LINEA.Rows(0)("ZONE7_GAS_FLOW").ToString()

                        valveopen_B_zone7.Text = DTZONE7_LINEB.Rows(0)("ZONE7_GAS_VLV").ToString()
                        line_B_zone7.Text = DTZONE7_LINEB.Rows(0)("ZONE7_GAS_FLOW").ToString()
                        '===============ZONE8=====================================
                        valveopen_A_zone8.Text = DTZONE8_LINEA.Rows(0)("ZONE8_GAS_VLV").ToString()
                        line_zoneA_8.Text = DTZONE8_LINEA.Rows(0)("ZONE8_GAS_VLV").ToString()

                        valveopen_B_zone8.Text = DTZONE8_LINEB.Rows(0)("ZONE8_GAS_VLV").ToString()
                        line_B_zone8.Text = DTZONE8_LINEB.Rows(0)("ZONE8_GAS_FLOW").ToString()
                        '===============ZONE9=====================================
                        valveopen_A_zone9.Text = DTZONE9_LINEA.Rows(0)("ZONE9_GAS_VLV").ToString()
                        line_zoneA_9.Text = DTZONE9_LINEA.Rows(0)("ZONE9_GAS_FLOW").ToString()

                        valveopen_B_zone9.Text = DTZONE9_LINEB.Rows(0)("ZONE9_GAS_VLV").ToString()
                        line_B_zone9.Text = DTZONE9_LINEB.Rows(0)("ZONE9_GAS_FLOW").ToString()

                    Else

                    End If




                Catch ex As Exception
                    Throw ex
                End Try










            Catch ex As Exception
                Dim tem As String = ex.Message
            End Try
        End If
    End Sub

    '<WebMethod>
    'Public Shared Function SetAllValuesGridTables() As String
    '    Dim dh As New DataHandler
    '    Dim oc As New Controller
    '    Dim DTZONE1_LINEA As DataTable = oc.populate_zone1_LINEA()
    '    Dim DTZONE1_LINEB As DataTable = oc.populate_zone1_LINEB()

    '    Dim DTZONE2_LINEA As DataTable = oc.populate_zone2_LINEA()
    '    Dim DTZONE2_LINEB As DataTable = oc.populate_zone2_LINEB()

    '    Dim DTZONE3_LINEA As DataTable = oc.populate_zone3_LINEA()
    '    Dim DTZONE3_LINEB As DataTable = oc.populate_zone3_LINEB()

    '    Dim DTZONE4_LINEA As DataTable = oc.populate_zone4_LINEA()
    '    Dim DTZONE4_LINEB As DataTable = oc.populate_zone4_LINEB()

    '    Dim DTZONE5_LINEA As DataTable = oc.populate_zone5_LINEA()
    '    Dim DTZONE5_LINEB As DataTable = oc.populate_zone5_LINEB()

    '    Dim DTZONE6_LINEA As DataTable = oc.populate_zone6_LINEA()
    '    Dim DTZONE6_LINEB As DataTable = oc.populate_zone6_LINEB()

    '    Dim DTZONE7_LINEA As DataTable = oc.populate_zone7_LINEA()
    '    Dim DTZONE7_LINEB As DataTable = oc.populate_zone7_LINEB()

    '    Dim DTZONE8_LINEA As DataTable = oc.populate_zone8_LINEA()
    '    Dim DTZONE8_LINEB As DataTable = oc.populate_zone8_LINEB()

    '    Dim DTZONE9_LINEA As DataTable = oc.populate_zone9_LINEA()
    '    Dim DTZONE9_LINEB As DataTable = oc.populate_zone9_LINEB()




    '    'If DTZONE1_LINEA.Rows.Count > 0 Then
    '    '    '===============ZONE1=====================================
    '    '    valveopen_A_zone1.Text = DTZONE1_LINEA.Rows(0)("ZONE1_GAS_VLV") & "%"
    '    '    line_zoneA_1.Text = DTZONE1_LINEA.Rows(0)("ZONE1_GAS_FLOW") & "%"

    '    '    valveopen_B_zone1.Text = DTZONE1_LINEB.Rows(0)("ZONE1_GAS_VLV") & "%"
    '    '    line_B_zone1.Text = DTZONE1_LINEB.Rows(0)("ZONE1_GAS_VLV") & "%"

    '    'Else

    '    'End If


    '    If DTZONE1_LINEA.Rows.Count > 0 Then
    '        Dim retLabel As New StringBuilder
    '        '  ret.Append(dt.Rows(0)("CV") & "%,")
    '        retLabel.Append(DTZONE1_LINEA.Rows(0)("ZONE1_GAS_VLV") & ",")
    '        retLabel.Append(DTZONE1_LINEA.Rows(0)("ZONE1_GAS_FLOW") & ",")
    '        retLabel.Append(DTZONE1_LINEB.Rows(0)("ZONE1_GAS_VLV") & ",")
    '        retLabel.Append(DTZONE1_LINEB.Rows(0)("ZONE1_GAS_FLOW") & ",")
    '        ' retLabel.Append(DTZONE2_LINEB.Rows(0)("HEAT_INPUT_RECOM") & ",")
    '        'retLabel.Append(dtlabel.Rows(0)("SPC_FUEL_CON_ONLINE") & ",")
    '        'retLabel.Append(dtlabel.Rows(0)("SPC_FUEL_CON_CAL") & ",")
    '        'retLabel.Append(dtlabel.Rows(0)("SPEC_FUEL_CON_RECOM") & ",")
    '        'retLabel.Append(dtlabel.Rows(0)("TOTAL_GAS_FLOW_ONLINE") & ",")
    '        'retLabel.Append(dtlabel.Rows(0)("TOTAL_GAS_FLOW_CAL") & ",")
    '        'retLabel.Append(dtlabel.Rows(0)("TOTAL_GAS_FLOW_RECOM") & ",")
    '        'retLabel.Append(dtlabel.Rows(0)("TOTAL_AIR_FLOW_ONLINE") & ",")
    '        'retLabel.Append(dtlabel.Rows(0)("TOTAL_AIR_FLOW_CAL") & ",")
    '        'retLabel.Append(dtlabel.Rows(0)("TOTAL_AIR_FLOW_RECOM") & ",")

    '        Return (retLabel.ToString)
    '    Else
    '        Return "novalues"
    '    End If


    'End Function


    Protected Sub txtDate_TextChanged() Handles txtDate.TextChanged
        Try


            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            'Try
            'Dim dtStart As String = hfFrom.Value
            'Dim dtEnd As String = hfTo.Value

            'hfFrom.Value = dtStart
            'hfTo.Value = dtEnd


            '=================

            DrawChart__SECGasMonitr_LineA(fromDt, toDt)
            DrawChart__SECGasMonitr_LineB(fromDt, toDt)

            DrawChart__SEC1_CHART1(fromDt, toDt)
            DrawChart__SEC1_CHART1_LINEB(fromDt, toDt)
            DrawChart__SEC2_CHART2(fromDt, toDt)

            DrawChart__SEC2_CHART2_LINEB(fromDt, toDt)
            DrawChart__SEC3_CHART3(fromDt, toDt)
            DrawChart__SEC3_CHART3_LINEB(fromDt, toDt)
            DrawChart__MANIFOLD_LINEA(fromDt, toDt)
            DrawChart__MANIFOLD_LINEB(fromDt, toDt)

        Catch ex As Exception
            ' Lit1.Text = ""
            Dim tem As String = ex.Message
            Exit Sub
        End Try

    End Sub

    Sub DrawChart__SECGasMonitr_LineA(ByVal FromDt As String, ByVal ToDt As String)
        Try

            Dim strfrmDt As String = FromDt
            Dim strToDt As String = ToDt

            Dim dt As DataTable = objController.POPULATE_FURNACE_SEC1_LINEA_GasMonitor(strfrmDt, strToDt)
            objController.FURNACE_CHART1_SEC1GasMonitorMultiX(dt, Lit18, "container11", "plot1", "")

        Catch ex As Exception

        End Try
    End Sub


    Sub DrawChart__SECGasMonitr_LineB(ByVal FromDt As String, ByVal ToDt As String)
        Try

            Dim strfrmDt As String = FromDt
            Dim strToDt As String = ToDt

            Dim dt As DataTable = objController.POPULATE_FURNACE_SEC1_LINEB_GasMonitor(strfrmDt, strToDt)
            objController.FURNACE_CHART1_SEC1GasMonitorMultiXLineB(dt, Lit19, "container22", "plot1", "")

        Catch ex As Exception

        End Try
    End Sub
    'Sub DrawChart__DamperOpenSec1_Furn1(ByVal FromDt As String, ByVal ToDt As String)
    Sub DrawChart__DamperOpenSec1_Furn1()
        Try
            Dim dtStart As String = DateTime.Now.AddHours(-48).ToString("yyyy-MM-dd HH:mm")
            Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

            Dim strfrmDt As String = dtStart
            Dim strToDt As String = dtEnd

            Dim dt As DataTable = objController.POPULATE_SEC1_FURN1_DamperOpenMonitor(strfrmDt, strToDt)
            objController.FURNACE_CHART_DamperOpenSec1Furnc1(dt, Lit20, "container12", "plot1", "")

        Catch ex As Exception

        End Try
    End Sub

    Sub DrawChart__DamperOpenSec2_Furn1()
        Try

            Dim dtStart As String = DateTime.Now.AddHours(-48).ToString("yyyy-MM-dd HH:mm")
            Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

            Dim strfrmDt As String = dtStart
            Dim strToDt As String = dtEnd

            Dim dt As DataTable = objController.POPULATE_SEC2_FURN1_DamperOpenMonitor(strfrmDt, strToDt)
            objController.FURNACE_CHART_DamperOpenSec2Furnc1(dt, Lit21, "container13", "plot1", "")

        Catch ex As Exception

        End Try
    End Sub
    Sub DrawChart__DamperOpenSec3_Furn1()
        Try
            Dim dtStart As String = DateTime.Now.AddHours(-48).ToString("yyyy-MM-dd HH:mm")
            Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

            Dim strfrmDt As String = dtStart
            Dim strToDt As String = dtEnd

            Dim dt As DataTable = objController.POPULATE_SEC3_FURN1_DamperOpenMonitor(strfrmDt, strToDt)
            objController.FURNACE_CHART_DamperOpenSec3Furnc1(dt, Lit22, "container14", "plot1", "")

        Catch ex As Exception

        End Try
    End Sub

    Sub DrawChart__DamperOpenSec1_Furn2()
        Try

            Dim dtStart As String = DateTime.Now.AddHours(-48).ToString("yyyy-MM-dd HH:mm")
            Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

            Dim strfrmDt As String = dtStart
            Dim strToDt As String = dtEnd

            Dim dt As DataTable = objController.POPULATE_SEC1_FURN2_DamperOpenMonitor(strfrmDt, strToDt)
            objController.FURNACE_CHART_DamperOpenSec1Furnc2(dt, Lit23, "container15", "plot1", "")

        Catch ex As Exception

        End Try
    End Sub

    Sub DrawChart__DamperOpenSec2_Furn2()
        Try

            Dim dtStart As String = DateTime.Now.AddHours(-48).ToString("yyyy-MM-dd HH:mm")
            Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

            Dim strfrmDt As String = dtStart
            Dim strToDt As String = dtEnd

            Dim dt As DataTable = objController.POPULATE_SEC2_FURN2_DamperOpenMonitor(strfrmDt, strToDt)
            objController.FURNACE_CHART_DamperOpenSec2Furnc2(dt, Lit24, "container16", "plot1", "")

        Catch ex As Exception

        End Try
    End Sub
    Sub DrawChart__DamperOpenSec3_Furn2()
        Try

            Dim dtStart As String = DateTime.Now.AddHours(-48).ToString("yyyy-MM-dd HH:mm")
            Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

            Dim strfrmDt As String = dtStart
            Dim strToDt As String = dtEnd

            Dim dt As DataTable = objController.POPULATE_SEC3_FURN2_DamperOpenMonitor(strfrmDt, strToDt)
            objController.FURNACE_CHART_DamperOpenSec3Furnc2(dt, Lit25, "container17", "plot1", "")

        Catch ex As Exception

        End Try
    End Sub
    Sub DrawChart__CvValidation_Furn1()
        Try

            Dim dtStart As String = DateTime.Now.AddHours(-48).ToString("yyyy-MM-dd HH:mm")
            Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

            Dim strfrmDt As String = dtStart
            Dim strToDt As String = dtEnd

            Dim dt As DataTable = objController.POPULATE_CvValidationLineA(strfrmDt, strToDt)
            objController.FURNACE_CHART_CvValidationLineA(dt, Lit26, "container18", "plot1", "")

        Catch ex As Exception

        End Try
    End Sub

    Sub DrawChart__CvValidation_Furn2()
        Try

            Dim dtStart As String = DateTime.Now.AddHours(-48).ToString("yyyy-MM-dd HH:mm")
            Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

            Dim strfrmDt As String = dtStart
            Dim strToDt As String = dtEnd

            Dim dt As DataTable = objController.POPULATE_CvValidationLineB(strfrmDt, strToDt)
            objController.FURNACE_CHART_CvValidationLineB(dt, Lit27, "container19", "plot1", "")

        Catch ex As Exception

        End Try
    End Sub

    Sub DrawChart__SEC1_CHART1(ByVal FromDt As String, ByVal ToDt As String)
        Try

            Dim strfrmDt As String = FromDt
            Dim strToDt As String = ToDt



            Dim dt As DataTable = objController.POPULATE_FURNACE_SEC1_ZONE1(strfrmDt, strToDt)
            Dim dt1 As DataTable = objController.POPULATE_FURNACE_SEC1_ZONE2(strfrmDt, strToDt)
            Dim dt2 As DataTable = objController.POPULATE_FURNACE_SEC1_ZONE3(strfrmDt, strToDt)
            Dim dt3 As DataTable = objController.POPULATE_FURNACE_SEC1_oxy(strfrmDt, strToDt)


            If dt.Rows.Count > 0 Then

                objController.FURNACE_CHART1_SEC1(dt, dt1, dt2, dt3, Lit1, "container1", "plot1", "", "LINE1", "LINE2", "LINE3", "LINE4")

            End If




        Catch ex As Exception

        End Try
    End Sub


    Sub DrawChart__SEC1_CHART1_LINEB(ByVal FromDt As String, ByVal ToDt As String)
        Try

            Dim strfrmDt As String = FromDt
            Dim strToDt As String = ToDt



            Dim dt As DataTable = objController.POPULATE_FURNACE_SEC1_ZONE1_LINEB(strfrmDt, strToDt)
            Dim dt1 As DataTable = objController.POPULATE_FURNACE_SEC1_ZONE2_LINEB(strfrmDt, strToDt)
            Dim dt2 As DataTable = objController.POPULATE_FURNACE_SEC1_ZONE3_LINEB(strfrmDt, strToDt)
            Dim dt3 As DataTable = objController.POPULATE_FURNACE_SEC1_oxy_lineb(strfrmDt, strToDt)


            If dt.Rows.Count > 0 Then

                objController.FURNACE_CHART1_SEC1(dt, dt1, dt2, dt3, Lit4, "container4", "plot4", "", "LINE1", "LINE2", "LINE3", "LINE4")

            End If




        Catch ex As Exception

        End Try
    End Sub

    Sub DrawChart__SEC2_CHART2(ByVal FromDt As String, ByVal ToDt As String)
        Try

            Dim strfrmDt As String = FromDt
            Dim strToDt As String = ToDt



            Dim dt As DataTable = objController.POPULATE_FURNACE_SEC2_ZONE4(strfrmDt, strToDt)
            Dim dt1 As DataTable = objController.POPULATE_FURNACE_SEC2_ZONE5(strfrmDt, strToDt)
            Dim dt2 As DataTable = objController.POPULATE_FURNACE_SEC2_ZONE6(strfrmDt, strToDt)
            Dim dt3 As DataTable = objController.POPULATE_FURNACE_SEC2_ZONE7(strfrmDt, strToDt)
            Dim dt4 As DataTable = objController.POPULATE_FURNACE_SEC2_oxy(strfrmDt, strToDt)

            If dt.Rows.Count > 0 Then

                objController.FURNACE_CHART2_SEC2(dt, dt1, dt2, dt3, dt4, Lit2, "container2", "plot2", "", "LINE1", "LINE2", "LINE3", "LINE4", "LINE5")

            End If




        Catch ex As Exception

        End Try
    End Sub



    Sub DrawChart__SEC2_CHART2_LINEB(ByVal FromDt As String, ByVal ToDt As String)
        Try

            Dim strfrmDt As String = FromDt
            Dim strToDt As String = ToDt



            Dim dt As DataTable = objController.POPULATE_FURNACE_SEC2_ZONE4_LINEB(strfrmDt, strToDt)
            Dim dt1 As DataTable = objController.POPULATE_FURNACE_SEC2_ZONE5_LINEB(strfrmDt, strToDt)
            Dim dt2 As DataTable = objController.POPULATE_FURNACE_SEC2_ZONE6_LINEB(strfrmDt, strToDt)
            Dim dt3 As DataTable = objController.POPULATE_FURNACE_SEC2_ZONE7_LINEB(strfrmDt, strToDt)
            Dim dt4 As DataTable = objController.POPULATE_FURNACE_SEC2_oxy_LINEB(strfrmDt, strToDt)

            If dt.Rows.Count > 0 Then

                objController.FURNACE_CHART2_SEC2(dt, dt1, dt2, dt3, dt4, Lit5, "container5", "plot5", "", "LINE1", "LINE2", "LINE3", "LINE4", "LINE5")

            End If
            'If dt.Rows.Count > 0 Then

            '    objController.FURNACE_CHART2_SEC2(dt, dt1, dt2, dt3, Lit5, "container5", "plot5", "", "LINE1", "LINE2", "LINE3", "LINE4")

            'End If




        Catch ex As Exception

        End Try
    End Sub

    Sub DrawChart__SEC3_CHART3(ByVal FromDt As String, ByVal ToDt As String)
        Try

            Dim strfrmDt As String = FromDt
            Dim strToDt As String = ToDt



            Dim dt As DataTable = objController.POPULATE_FURNACE_SEC3_ZONE8(strfrmDt, strToDt)
            Dim dt1 As DataTable = objController.POPULATE_FURNACE_SEC3_ZONE9(strfrmDt, strToDt)

            Dim dt2 As DataTable = objController.POPULATE_FURNACE_SEC3_oxy(strfrmDt, strToDt)


            If dt.Rows.Count > 0 Then

                objController.FURNACE_CHART3_SEC3(dt, dt1, dt2, Lit3, "container3", "plot3", "", "LINE1", "LINE2", "LINE3")

            End If




        Catch ex As Exception

        End Try
    End Sub



    Sub DrawChart__SEC3_CHART3_LINEB(ByVal FromDt As String, ByVal ToDt As String)
        Try

            Dim strfrmDt As String = FromDt
            Dim strToDt As String = ToDt



            Dim dt As DataTable = objController.POPULATE_FURNACE_SEC3_ZONE8_LINEB(strfrmDt, strToDt)
            Dim dt1 As DataTable = objController.POPULATE_FURNACE_SEC3_ZONE9_LINEB(strfrmDt, strToDt)
            'Dim dt2 As DataTable = objController.POPULATE_FURNACE_SEC1_ZONE3(strfrmDt, strToDt)


            Dim dt2 As DataTable = objController.POPULATE_FURNACE_SEC3_oxy_LINEB(strfrmDt, strToDt)


            If dt.Rows.Count > 0 Then

                objController.FURNACE_CHART3_SEC3(dt, dt1, dt2, Lit6, "container6", "plot6", "", "LINE1", "LINE2", "LINE3")

            End If

            'If dt.Rows.Count > 0 Then

            '    objController.FURNACE_CHART3_SEC3(dt, dt1, Lit6, "container6", "plot6", "", "LINE1", "LINE2")

            'End If




        Catch ex As Exception

        End Try
    End Sub


    Sub DrawChart__MANIFOLD_LINEA(ByVal FromDt As String, ByVal ToDt As String)
        Try

            Dim strfrmDt As String = FromDt
            Dim strToDt As String = ToDt



            Dim dt As DataTable = objController.POPULATE_FURNACE_SEC1_LINEA_MANIFOLD(strfrmDt, strToDt)
            Dim dt1 As DataTable = objController.POPULATE_FURNACE_SEC2_LINEA_MANIFOLD(strfrmDt, strToDt)
            Dim dt2 As DataTable = objController.POPULATE_FURNACE_SEC3_LINEA_MANIFOLD(strfrmDt, strToDt)


            If dt.Rows.Count > 0 Then

                objController.FURNACE_CHART1_SEC1_2_3_MANIFOLD(dt, dt1, dt2, Lit7, "container7", "plot7", "", "SEC1", "SEC2", "SEC3")

            End If




        Catch ex As Exception

        End Try
    End Sub
    Sub DrawChart__MANIFOLD_LINEB(ByVal FromDt As String, ByVal ToDt As String)
        Try

            Dim strfrmDt As String = FromDt
            Dim strToDt As String = ToDt



            Dim dt As DataTable = objController.POPULATE_FURNACE_SEC1_LINEB_MANIFOLD(strfrmDt, strToDt)
            Dim dt1 As DataTable = objController.POPULATE_FURNACE_SEC2_LINEB_MANIFOLD(strfrmDt, strToDt)
            Dim dt2 As DataTable = objController.POPULATE_FURNACE_SEC3_LINEB_MANIFOLD(strfrmDt, strToDt)


            If dt.Rows.Count > 0 Then

                objController.FURNACE_CHART1_SEC1_2_3_MANIFOLD(dt, dt1, dt2, Lit8, "container8", "plot8", "", "SEC1", "SEC2", "SEC3")

            End If




        Catch ex As Exception

        End Try
    End Sub

    Sub BestTimePerformance_Sec1LineA(ByVal FromDt As DateTime, ByVal ToDt As DateTime)
        Try

            Dim dt As DataTable
            Dim dt1 As DataTable
            Dim currntMaxMeanVal As Integer
            Dim existMaxMeanVal As Integer
            Dim qr1 As String = ""


            'Selects Max Value  CURRENTLY
            dt = objdatahandler.GetDataSetFromQuery("Select MAX(mean) as max_mean from ( sELECT CAST(timestamp AS DATE) AS  timestamp, CAST(avg(mean) AS DECIMAL (10,4)) AS mean,sec_zone,line FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ADD_STAT_PARAM]  where line = 'A'  AND SEC_ZONE = 1  AND parameter= 'Manifold' AND   timestamp  between '" & FromDt.ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & ToDt.ToString("yyyy-MM-dd HH:mm:ss") & "'  GROUP BY CAST(timestamp AS DATE), SEC_ZONE,sec_zone,line ) as inner_query").Tables(0)
            currntMaxMeanVal = dt(0)(0)

            'Selects already EXISTING value in table
            dt1 = objdatahandler.GetDataSetFromQuery("SELECT * FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_BTP_DATA] WHERE sec_zone=1 and line='A' and parameter='manifold'").Tables(0)
            If dt1.Rows.Count > 0 Then
                existMaxMeanVal = dt1(0)("max_mean")
                If currntMaxMeanVal > existMaxMeanVal Then
                    ''Update Query
                    qr1 = "UPDATE [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_BTP_DATA] SET max_mean='" & currntMaxMeanVal & "' where sec_zone=1 and line='A' and parameter='manifold'"
                    objdatahandler.RunSimpleQuery(qr1)
                    lblBtpSec1LA.Text = currntMaxMeanVal.ToString()
                Else
                    lblBtpSec1LA.Text = existMaxMeanVal.ToString()
                End If

            Else
                ''Insert Query
                qr1 = "INSERT INTO [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_BTP_DATA] (TIMESTAMP,MAX_MEAN,SEC_ZONE,LINE,PARAMETER) VALUES ('" & Now.ToString("dd-MMM-yy hh:mm:ss tt") & "'," & dt(0)(0) & ",1,'A','Manifold') "
                objdatahandler.RunSimpleQuery(qr1)
                lblBtpSec1LA.Text = currntMaxMeanVal.ToString()
            End If

        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub

    Sub BestTimePerformance_Sec2LineA(ByVal FromDt As DateTime, ByVal ToDt As DateTime)
        Try

            Dim dt As DataTable
            Dim dt1 As DataTable
            Dim currntMaxMeanVal As Integer
            Dim existMaxMeanVal As Integer
            Dim qr1 As String = ""


            'Selects Max Value  CURRENTLY
            dt = objdatahandler.GetDataSetFromQuery("Select MAX(mean) as max_mean from ( sELECT CAST(timestamp AS DATE) AS  timestamp, CAST(avg(mean) AS DECIMAL (10,4)) AS mean,sec_zone,line FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ADD_STAT_PARAM]  where line = 'A'  AND SEC_ZONE = 2  AND parameter= 'Manifold' AND   timestamp  between '" & FromDt.ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & ToDt.ToString("yyyy-MM-dd HH:mm:ss") & "'  GROUP BY CAST(timestamp AS DATE), SEC_ZONE,sec_zone,line ) as inner_query").Tables(0)
            currntMaxMeanVal = dt(0)(0)

            'Selects already EXISTING value in table
            dt1 = objdatahandler.GetDataSetFromQuery("SELECT * FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_BTP_DATA] WHERE sec_zone=2 and line='A' and parameter='manifold'").Tables(0)
            If dt1.Rows.Count > 0 Then
                existMaxMeanVal = dt1(0)("max_mean")
                If currntMaxMeanVal > existMaxMeanVal Then
                    ''Update Query
                    qr1 = "UPDATE [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_BTP_DATA] SET max_mean='" & currntMaxMeanVal & "' where sec_zone=2 and line='A' and parameter='manifold'"
                    objdatahandler.RunSimpleQuery(qr1)
                    lblBtpSec2LA.Text = currntMaxMeanVal.ToString()
                Else
                    lblBtpSec2LA.Text = existMaxMeanVal.ToString()
                End If

            Else
                ''Insert Query
                qr1 = "INSERT INTO [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_BTP_DATA] (TIMESTAMP,MAX_MEAN,SEC_ZONE,LINE,PARAMETER) VALUES ('" & Now.ToString("dd-MMM-yy hh:mm:ss tt") & "'," & dt(0)(0) & ",2,'A','Manifold') "
                objdatahandler.RunSimpleQuery(qr1)
                lblBtpSec2LA.Text = currntMaxMeanVal.ToString()
            End If

        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub

    Sub BestTimePerformance_Sec3LineA(ByVal FromDt As DateTime, ByVal ToDt As DateTime)
        Try

            Dim dt As DataTable
            Dim dt1 As DataTable
            Dim currntMaxMeanVal As Integer
            Dim existMaxMeanVal As Integer
            Dim qr1 As String = ""


            'Selects Max Value  CURRENTLY
            dt = objdatahandler.GetDataSetFromQuery("Select MAX(mean) as max_mean from ( sELECT CAST(timestamp AS DATE) AS  timestamp, CAST(avg(mean) AS DECIMAL (10,4)) AS mean,sec_zone,line FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ADD_STAT_PARAM]  where line = 'A'  AND SEC_ZONE = 3  AND parameter= 'Manifold' AND   timestamp  between '" & FromDt.ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & ToDt.ToString("yyyy-MM-dd HH:mm:ss") & "'  GROUP BY CAST(timestamp AS DATE), SEC_ZONE,sec_zone,line ) as inner_query").Tables(0)
            currntMaxMeanVal = dt(0)(0)

            'Selects already EXISTING value in table
            dt1 = objdatahandler.GetDataSetFromQuery("SELECT * FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_BTP_DATA] WHERE sec_zone=3 and line='A' and parameter='manifold'").Tables(0)
            If dt1.Rows.Count > 0 Then
                existMaxMeanVal = dt1(0)("max_mean")
                If currntMaxMeanVal > existMaxMeanVal Then
                    ''Update Query
                    qr1 = "UPDATE [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_BTP_DATA] SET max_mean='" & currntMaxMeanVal & "' where sec_zone=3 and line='A' and parameter='manifold'"
                    objdatahandler.RunSimpleQuery(qr1)
                    lblBtpSec3LA.Text = currntMaxMeanVal.ToString()
                Else
                    lblBtpSec3LA.Text = existMaxMeanVal.ToString()
                End If

            Else
                ''Insert Query
                qr1 = "INSERT INTO [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_BTP_DATA] (TIMESTAMP,MAX_MEAN,SEC_ZONE,LINE,PARAMETER) VALUES ('" & Now.ToString("dd-MMM-yy hh:mm:ss tt") & "'," & dt(0)(0) & ",3,'A','Manifold') "
                objdatahandler.RunSimpleQuery(qr1)
                lblBtpSec3LA.Text = currntMaxMeanVal.ToString()
            End If

        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub

    Sub BestTimePerformance_Sec1LineB(ByVal FromDt As DateTime, ByVal ToDt As DateTime)
        Try

            Dim dt As DataTable
            Dim dt1 As DataTable
            Dim currntMaxMeanVal As Integer
            Dim existMaxMeanVal As Integer
            Dim qr1 As String = ""


            'Selects Max Value  CURRENTLY
            dt = objdatahandler.GetDataSetFromQuery("Select MAX(mean) as max_mean from ( sELECT CAST(timestamp AS DATE) AS  timestamp, CAST(avg(mean) AS DECIMAL (10,4)) AS mean,sec_zone,line FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ADD_STAT_PARAM]  where line = 'B'  AND SEC_ZONE = 1  AND parameter= 'Manifold' AND   timestamp  between '" & FromDt.ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & ToDt.ToString("yyyy-MM-dd HH:mm:ss") & "'  GROUP BY CAST(timestamp AS DATE), SEC_ZONE,sec_zone,line ) as inner_query").Tables(0)
            currntMaxMeanVal = dt(0)(0)

            'Selects already EXISTING value in table
            dt1 = objdatahandler.GetDataSetFromQuery("SELECT * FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_BTP_DATA] WHERE sec_zone=1 and line='B' and parameter='manifold'").Tables(0)
            If dt1.Rows.Count > 0 Then
                existMaxMeanVal = dt1(0)("max_mean")
                If currntMaxMeanVal > existMaxMeanVal Then
                    ''Update Query
                    qr1 = "UPDATE [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_BTP_DATA] SET max_mean='" & currntMaxMeanVal & "' where sec_zone='1' and line='B' and parameter='manifold'"
                    objdatahandler.RunSimpleQuery(qr1)
                    lblBtpSec1LB.Text = currntMaxMeanVal.ToString()
                Else
                    lblBtpSec1LB.Text = existMaxMeanVal.ToString()
                End If

            Else
                ''Insert Query
                qr1 = "INSERT INTO [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_BTP_DATA] (TIMESTAMP,MAX_MEAN,SEC_ZONE,LINE,PARAMETER) VALUES ('" & Now.ToString("dd-MMM-yy hh:mm:ss tt") & "'," & dt(0)(0) & ",1,'B','Manifold') "
                objdatahandler.RunSimpleQuery(qr1)
                lblBtpSec1LB.Text = currntMaxMeanVal.ToString()
            End If

        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub

    Sub BestTimePerformance_Sec2LineB(ByVal FromDt As DateTime, ByVal ToDt As DateTime)
        Try

            Dim dt As DataTable
            Dim dt1 As DataTable
            Dim currntMaxMeanVal As Integer
            Dim existMaxMeanVal As Integer
            Dim qr1 As String = ""


            'Selects Max Value  CURRENTLY
            dt = objdatahandler.GetDataSetFromQuery("Select MAX(mean) as max_mean from ( sELECT CAST(timestamp AS DATE) AS  timestamp, CAST(avg(mean) AS DECIMAL (10,4)) AS mean,sec_zone,line FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ADD_STAT_PARAM]  where line = 'B'  AND SEC_ZONE = 2  AND parameter= 'Manifold' AND   timestamp  between '" & FromDt.ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & ToDt.ToString("yyyy-MM-dd HH:mm:ss") & "'  GROUP BY CAST(timestamp AS DATE), SEC_ZONE,sec_zone,line ) as inner_query").Tables(0)
            currntMaxMeanVal = dt(0)(0)

            'Selects already EXISTING value in table
            dt1 = objdatahandler.GetDataSetFromQuery("SELECT * FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_BTP_DATA] WHERE sec_zone=2 and line='B' and parameter='manifold'").Tables(0)
            If dt1.Rows.Count > 0 Then
                existMaxMeanVal = dt1(0)("max_mean")
                If currntMaxMeanVal > existMaxMeanVal Then
                    ''Update Query
                    qr1 = "UPDATE [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_BTP_DATA] SET max_mean='" & currntMaxMeanVal & "' where sec_zone=2 and line='B' and parameter='manifold'"
                    objdatahandler.RunSimpleQuery(qr1)
                    lblBtpSec2LB.Text = currntMaxMeanVal.ToString()
                Else
                    lblBtpSec2LB.Text = existMaxMeanVal.ToString()
                End If

            Else
                ''Insert Query
                qr1 = "INSERT INTO [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_BTP_DATA] (TIMESTAMP,MAX_MEAN,SEC_ZONE,LINE,PARAMETER) VALUES ('" & Now.ToString("dd-MMM-yy hh:mm:ss tt") & "'," & dt(0)(0) & ",2,'B','Manifold') "
                objdatahandler.RunSimpleQuery(qr1)
                lblBtpSec2LB.Text = currntMaxMeanVal.ToString()
            End If

        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub

    Sub BestTimePerformance_Sec3LineB(ByVal FromDt As DateTime, ByVal ToDt As DateTime)
        Try

            Dim dt As DataTable
            Dim dt1 As DataTable
            Dim currntMaxMeanVal As Integer
            Dim existMaxMeanVal As Integer
            Dim qr1 As String = ""


            'Selects Max Value  CURRENTLY
            dt = objdatahandler.GetDataSetFromQuery("Select MAX(mean) as max_mean from ( sELECT CAST(timestamp AS DATE) AS  timestamp, CAST(avg(mean) AS DECIMAL (10,4)) AS mean,sec_zone,line FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ADD_STAT_PARAM]  where line = 'B'  AND SEC_ZONE = 3  AND parameter= 'Manifold' AND   timestamp  between '" & FromDt.ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & ToDt.ToString("yyyy-MM-dd HH:mm:ss") & "'  GROUP BY CAST(timestamp AS DATE), SEC_ZONE,sec_zone,line ) as inner_query").Tables(0)
            currntMaxMeanVal = dt(0)(0)

            'Selects already EXISTING value in table
            dt1 = objdatahandler.GetDataSetFromQuery("SELECT * FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_BTP_DATA] WHERE sec_zone=3 and line='B' and parameter='manifold'").Tables(0)
            If dt1.Rows.Count > 0 Then
                existMaxMeanVal = dt1(0)("max_mean")
                If currntMaxMeanVal > existMaxMeanVal Then
                    ''Update Query
                    qr1 = "UPDATE [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_BTP_DATA] SET max_mean='" & currntMaxMeanVal & "' where sec_zone=3 and line='B' and parameter='manifold'"
                    objdatahandler.RunSimpleQuery(qr1)
                    lblBtpSec3LB.Text = currntMaxMeanVal.ToString()
                Else
                    lblBtpSec3LB.Text = existMaxMeanVal.ToString()
                End If

            Else
                ''Insert Query
                qr1 = "INSERT INTO [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_BTP_DATA] (TIMESTAMP,MAX_MEAN,SEC_ZONE,LINE,PARAMETER) VALUES ('" & Now.ToString("dd-MMM-yy hh:mm:ss tt") & "'," & dt(0)(0) & ",3,'B','Manifold') "
                objdatahandler.RunSimpleQuery(qr1)
                lblBtpSec3LB.Text = currntMaxMeanVal.ToString()
            End If

        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub

    Private Sub btnzone1_click(sender As System.Object, e As System.EventArgs) Handles btnzone1.Click
        Session("checkLineChartVLV") = "VALVE_OPEN"
        Session("checkLineChartFLOW") = "GAS_FLOW"
        Session("zoneFT") = "1"
        Dim url As String = "Furnace_Zone_Temp.aspx"
        'btnCV.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.GetType(), Guid.NewGuid().ToString(), "openWindow('" & url & "');", True)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "openpage", "openWindow('" & url & "');", True)
    End Sub
    Private Sub btnzone2_click(sender As System.Object, e As System.EventArgs) Handles btnzone2.Click
        'Session("checkLineChartVLV") = "ZONE2_GAS_VLV"
        'Session("checkLineChartFLOW") = "ZONE2_GAS_FLOW_PERC"
        Session("checkLineChartVLV") = "VALVE_OPEN"
        Session("checkLineChartFLOW") = "GAS_FLOW"
        Session("zoneFT") = "2"
        Dim url As String = "Furnace_Zone_Temp.aspx"
        'btnCV.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.GetType(), Guid.NewGuid().ToString(), "openWindow('" & url & "');", True)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "openpage", "openWindow('" & url & "');", True)
    End Sub
    Private Sub btnzone3_click(sender As System.Object, e As System.EventArgs) Handles btnzone3.Click
        'Session("checkLineChartVLV") = "ZONE3_GAS_VLV"
        'Session("checkLineChartFLOW") = "ZONE3_GAS_FLOW_PERC"
        Session("checkLineChartVLV") = "VALVE_OPEN"
        Session("checkLineChartFLOW") = "GAS_FLOW"
        Session("zoneFT") = "3"
        Dim url As String = "Furnace_Zone_Temp.aspx"
        'btnCV.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.GetType(), Guid.NewGuid().ToString(), "openWindow('" & url & "');", True)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "openpage", "openWindow('" & url & "');", True)
    End Sub
    Private Sub btnzone4_click(sender As System.Object, e As System.EventArgs) Handles btnzone4.Click
        'Session("checkLineChartVLV") = "ZONE4_GAS_VLV"
        'Session("checkLineChartFLOW") = "ZONE4_GAS_FLOW_PERC"
        Session("checkLineChartVLV") = "VALVE_OPEN"
        Session("checkLineChartFLOW") = "GAS_FLOW"
        Session("zoneFT") = "4"
        Dim url As String = "Furnace_Zone_Temp.aspx"
        'btnCV.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.GetType(), Guid.NewGuid().ToString(), "openWindow('" & url & "');", True)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "openpage", "openWindow('" & url & "');", True)
    End Sub
    Private Sub btnzone5_click(sender As System.Object, e As System.EventArgs) Handles btnzone5.Click
        'Session("checkLineChartVLV") = "ZONE5_GAS_VLV"
        'Session("checkLineChartFLOW") = "ZONE5_GAS_FLOW_PERC"
        Session("checkLineChartVLV") = "VALVE_OPEN"
        Session("checkLineChartFLOW") = "GAS_FLOW"
        Session("zoneFT") = "5"
        Dim url As String = "Furnace_Zone_Temp.aspx"
        'btnCV.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.GetType(), Guid.NewGuid().ToString(), "openWindow('" & url & "');", True)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "openpage", "openWindow('" & url & "');", True)
    End Sub
    Private Sub btnzone6_click(sender As System.Object, e As System.EventArgs) Handles btnzone6.Click
        'Session("checkLineChartVLV") = "ZONE6_GAS_VLV"
        'Session("checkLineChartFLOW") = "ZONE6_GAS_FLOW_PERC"
        Session("checkLineChartVLV") = "VALVE_OPEN"
        Session("checkLineChartFLOW") = "GAS_FLOW"
        Session("zoneFT") = "6"
        Dim url As String = "Furnace_Zone_Temp.aspx"
        'btnCV.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.GetType(), Guid.NewGuid().ToString(), "openWindow('" & url & "');", True)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "openpage", "openWindow('" & url & "');", True)
    End Sub
    Private Sub btnzone7_click(sender As System.Object, e As System.EventArgs) Handles btnzone7.Click
        'Session("checkLineChartVLV") = "ZONE7_GAS_VLV"
        'Session("checkLineChartFLOW") = "ZONE7_GAS_FLOW_PERC"
        Session("checkLineChartVLV") = "VALVE_OPEN"
        Session("checkLineChartFLOW") = "GAS_FLOW"
        Session("zoneFT") = "7"
        Dim url As String = "Furnace_Zone_Temp.aspx"
        'btnCV.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.GetType(), Guid.NewGuid().ToString(), "openWindow('" & url & "');", True)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "openpage", "openWindow('" & url & "');", True)
    End Sub
    Private Sub btnzone8_click(sender As System.Object, e As System.EventArgs) Handles btnzone8.Click
        'Session("checkLineChartVLV") = "ZONE8_GAS_VLV"
        'Session("checkLineChartFLOW") = "ZONE8_GAS_FLOW_PERC"
        Session("checkLineChartVLV") = "VALVE_OPEN"
        Session("checkLineChartFLOW") = "GAS_FLOW"
        Session("zoneFT") = "8"
        Dim url As String = "Furnace_Zone_Temp.aspx"
        'btnCV.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.GetType(), Guid.NewGuid().ToString(), "openWindow('" & url & "');", True)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "openpage", "openWindow('" & url & "');", True)
    End Sub
    Private Sub btnzone9_click(sender As System.Object, e As System.EventArgs) Handles btnzone9.Click
        'Session("checkLineChartVLV") = "ZONE9_GAS_VLV"
        'Session("checkLineChartFLOW") = "ZONE9_GAS_FLOW_PERC"
        Session("checkLineChartVLV") = "VALVE_OPEN"
        Session("checkLineChartFLOW") = "GAS_FLOW"
        Session("zoneFT") = "9"
        Dim url As String = "Furnace_Zone_Temp.aspx"
        'btnCV.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.GetType(), Guid.NewGuid().ToString(), "openWindow('" & url & "');", True)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "openpage", "openWindow('" & url & "');", True)
    End Sub

End Class
