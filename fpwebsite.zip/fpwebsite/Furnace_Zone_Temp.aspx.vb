﻿Imports System.Data
Imports System.IO
Imports OfficeOpenXml
Partial Class Furnace_Zone_Temp
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim objdatahandler As New DataHandler
    Dim SELECT_LINE As String = ""
    Dim VLVEOPEN As String = ""
    Dim VLVFLOW As String = ""
    Dim ZONEFT As String = ""

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load


        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                'Dim dtStart As String = DateTime.Now.AddDays(-29).ToString("yyyy-MM-dd HH:mm")
                'Dim dtStart As String = DateTime.Now.AddMonths(-12).ToString("yyyy-MM-dd HH:mm")
                Dim dtStart As DateTime = DateTime.Now.AddMonths(-3).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")



                DrawChart__SEC1_CHART1(dtStart, dtEnd)
                '  txtDate_TextChanged()











                '=============LINEA AND B
                '' SELECT_LINE = Session("checkboxval")
                'VLVEOPEN = Session("checkLineChartVLV")
                'VLVFLOW = Session("checkLineChartFLOW")

                'Dim ds As DataSet = objdatahandler.GetDataSetFromQuery("SELECT   [TIMESTAMP], " & VLVEOPEN & " ," & VLVFLOW & "  FROM  [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ZONE_TEMP] where LINE =  'A'  AND  [datetime] between '" & toDate & "' and '" & frmDate & "' ")
                ''  Select Case cast(AVG(ZONE1_GAS_VLV) As Decimal(10, 3)) As ZONE1_GAS_VLV  , cast(AVG([ZONE1_GAS_FLOW]) As Decimal(10,3)) As [ZONE1_GAS_FLOW]  FROM  [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ZONE_TEMP] where  DATEPART(DAY, TIMESTAMP) = DATEPART(DAY, DATEADD(DAY, 0, getdate())) And line = 'A' GROUP BY DATENAME(DAY,TIMESTAMP) order by DATENAME(DAY,TIMESTAMP) asc")

                'Dim dt As DataTable = ds.Tables(0)
                ''between '" & frmDate & "' and '" & toDate & "'
                'Try
                '    Lit1.Text = ""

                '    Dim yVal(), yVal1() As Decimal
                '    yVal = (From row In dt Select col = CDec(row(VLVEOPEN))).ToArray()
                '    yVal1 = (From row In dt Select col = CDec(row(VLVFLOW))).ToArray()

                '    Dim y_min As String = -1
                '    Dim y_max As String = yVal.Max() + 1


                '    Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                '     "$.jqplot.config.enablePlugins = true;" & vbCrLf
                '    js &= "var line1 = ["
                '    For i As Integer = 0 To dt.Rows.Count - 1
                '        js &= "['" & CDate(dt.Rows(i)("DATETIME")).ToString("yyyy-MM-dd HH:mm:ss") & "'," & dt.Rows(i)(VLVEOPEN) & "," & dt.Rows(i)(VLVFLOW) & "],"

                '    Next
                '    js &= "];"
                '    'js &= "var line2 = ["
                '    'For i As Integer = 0 To dt.Rows.Count - 1
                '    '    js &= "['" & dt.Rows(i)("DATETIME") & "'," & dt.Rows(i)("BASE_VALUE_RECOM") & "],"

                '    'Next
                '    'js &= "];"
                '    Dim plotname = "plot1"
                '    Dim ContainerName = "container1"
                '    js &= "var " & plotname & " = $.jqplot('" & ContainerName & "',[line1],[line2], {"
                '    js &= "series:[{  showMarker:true,pointLabels: { show:false } ,label:'" & VLVEOPEN & "','" & VLVFLOW & "'  }],"
                '    js &= "axesDefaults: { tickRenderer: $.jqplot.CanvasAxisTickRenderer ,tickOptions: {  angle: 30 ,fontSize:  '8pt'  }},"
                '    js &= "seriesColors:['#0B62A4'],"
                '    js &= "axes: {labelOptions:{fontSize:  '8pt'},"
                '    js &= "xaxis: {   label : " & """Time""" & ",labelOptions:{fontSize:  '8pt'},renderer:$.jqplot.DateAxisRenderer,tickOptions:{formatString:'%Y/%#m/%#d %H:%M:%S'}},"
                '    js &= "yaxis: {type: 'value',min:" & y_min & ", max: " & y_max & " , label:'Parameters',labelRenderer: $.jqplot.CanvasAxisLabelRenderer }"
                '    js &= "}, highlighter: {show: true}, cursor: { show: true, zoom:true,},grid: {backgroundColor:  'rgb(255,255,255)'} ,legend:{show:true,placement: 'OutsideGrid',rendererOptions: {numberRows: 1, marginTop: 10 },  renderer: $.jqplot.EnhancedLegendRenderer } });"
                '    js &= "</script>"
                '    Lit1.Text = js
                'Catch ex As Exception

                '    Throw ex
                'End Try



            Catch ex As Exception

            End Try
        End If
    End Sub



    Sub DrawChart__SEC1_CHART1(ByVal FromDt As String, ByVal ToDt As String)
        Try

            Dim strfrmDt As String = FromDt
            Dim strToDt As String = ToDt

            SELECT_LINE = Session("checkboxval")
            VLVEOPEN = Session("checkLineChartVLV")
            VLVFLOW = Session("checkLineChartFLOW")
            ZONEFT = Session("zoneFT")



            Dim dt As DataTable = objController.POPULATE_redirectpagelineBvalveopenLINEA(strfrmDt, strToDt, VLVEOPEN, ZONEFT) 'Valve Open
            Dim dt1 As DataTable = objController.POPULATE_redirectpagelineAGASFLOW(strfrmDt, strToDt, VLVFLOW, ZONEFT) 'Gas Flow
            Dim dtlineB As DataTable = objController.POPULATE_redirectpagelineBvalveopenLINEB(strfrmDt, strToDt, VLVEOPEN, ZONEFT) 'Valve Open
            Dim dt1LINEB As DataTable = objController.POPULATE_redirectpagelineBGASFLOW(strfrmDt, strToDt, VLVFLOW, ZONEFT) 'Gas Flow


            If dt.Rows.Count > 0 Then

                objController.redirect_zone1_chart(dt, dt1, Lit1, "container1", "plot1", "", "VLVEOPEN", "VLVFLOW")
                objController.redirect_zone1_chart(dtlineB, dt1LINEB, Lit2, "container2", "plot2", "", "VLVEOPEN", "VLVFLOW")

            End If




        Catch ex As Exception

        End Try
    End Sub




    Protected Sub txtDate_TextChanged(sender As Object, e As System.EventArgs) Handles txtDate.TextChanged

        Dim fromDt As DateTime = hfFrom.Value
            Dim toDt As DateTime = hfTo.Value
            Try

                Dim strfrmDt As String = fromDt
                Dim strToDt As String = toDt

            SELECT_LINE = Session("checkboxval")
            VLVEOPEN = Session("checkLineChartVLV")
            VLVFLOW = Session("checkLineChartFLOW")
            ZONEFT = Session("zoneFT")


            ' Dim dt As DataTable = objController.POPULATE_redirectpagelineAvalveopenzone1(strfrmDt, strToDt, VLVEOPEN, VLVFLOW)
            'Dim dt As DataTable = objController.POPULATE_redirectpagelineBvalveopenLINEA(strfrmDt, strToDt, VLVEOPEN)
            'Dim dt1 As DataTable = objController.POPULATE_redirectpagelineAGASFLOW(strfrmDt, strToDt, VLVFLOW)
            'Dim dtlineB As DataTable = objController.POPULATE_redirectpagelineBvalveopenLINEB(strfrmDt, strToDt, VLVEOPEN)
            'Dim dt1LINEB As DataTable = objController.POPULATE_redirectpagelineBGASFLOW(strfrmDt, strToDt, VLVFLOW)


            Dim dt As DataTable = objController.POPULATE_redirectpagelineBvalveopenLINEA(strfrmDt, strToDt, VLVEOPEN, ZONEFT)
            Dim dt1 As DataTable = objController.POPULATE_redirectpagelineAGASFLOW(strfrmDt, strToDt, VLVFLOW, ZONEFT)
            Dim dtlineB As DataTable = objController.POPULATE_redirectpagelineBvalveopenLINEB(strfrmDt, strToDt, VLVEOPEN, ZONEFT)
            Dim dt1LINEB As DataTable = objController.POPULATE_redirectpagelineBGASFLOW(strfrmDt, strToDt, VLVFLOW, ZONEFT)




            If dt.Rows.Count > 0 Then

                objController.redirect_zone1_chart(dt, dt1, Lit1, "container1", "plot1", "", "VLVEOPEN", "VLVFLOW")
                objController.redirect_zone1_chart(dtlineB, dt1LINEB, Lit2, "container2", "plot2", "", "VLVEOPEN", "VLVFLOW")

            End If




            Catch ex As Exception

            End Try
    End Sub

    'Private Sub lnkDownload_Click(sender As Object, e As EventArgs) Handles lnkDownload.Click
    '    Try
    '        Dim fromDt As String = hfFrom.Value
    '        Dim toDt As String = hfTo.Value

    '        SELECT_LINE = Session("checkboxval")
    '        VLVEOPEN = Session("checkLineChartVLV")
    '        VLVFLOW = Session("checkLineChartFLOW")


    '        Dim ds As DataSet = objdatahandler.GetDataSetFromQuery("SELECT   [TIMESTAMP], " & VLVEOPEN & " ," & VLVFLOW & "  FROM  [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ZONE_TEMP] where LINE =  'A'  AND  [datetime] between '" & fromDt & "' and '" & toDt & "' ")


    '        Dim dt1 As DataTable = ds.Tables(0)
    '        Dim i As Integer = 1
    '        Using ep As New ExcelPackage()
    '            'For Each dt As DataTable In ds.Tables
    '            'Dim ws As ExcelWorksheet = ep.Workbook.Worksheets.Add("s" & i)
    '            Dim ws As ExcelWorksheet = ep.Workbook.Worksheets.Add("Download")
    '            ws.Cells("A1").LoadFromDataTable(dt1, True)

    '            'i += 1
    '            'Next
    '            Using ms As New MemoryStream
    '                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    '                Response.AddHeader("content-disposition", "attachment; filename=download.xlsx")
    '                ep.SaveAs(ms)
    '                ms.WriteTo(Response.OutputStream)
    '                Response.Flush()
    '                Response.End()
    '            End Using
    '        End Using



    '    Catch ex As Exception

    '    End Try
    'End Sub
End Class
