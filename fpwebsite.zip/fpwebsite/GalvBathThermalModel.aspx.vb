﻿Imports System.Data
Imports System.IO
Partial Class GalvBathThermalModel
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim objThermalModel As New ACPM_MODEL
    Dim Qstrip As Double
    Dim Mass_Ingot, Mass_Coil, Tmelt, Tamb, Cp_Zn_l, Tbath_C, Tbath_K, sum_t, duration, PI, T_strip_K, T_strip_C, thickness, width, StripTemp, ZinPotTemp As Decimal
    Dim a1, b1, c1, Lmelt, Qloss_avg, SteelDensity, coil_len As Double

    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Sub OpenModal(ByVal DivId As String)
        Dim sb As New StringBuilder()
        sb.Append("<script type='text/javascript'>")
        sb.Append("$('#" & DivId & "').modal('show');")
        sb.Append("</script>")
        ScriptManager.RegisterClientScriptBlock(Me, Me.GetType(), "ShowModal", sb.ToString(), False)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd HH:mm")
                'Dim dtStart As String = DateTime.Now.AddDays(-29).ToString("yyyy-MM-dd")

                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                Dim avgDT As Double = 0.0
                ' Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd")
                objController.PopulateAcpmData(dtStart, dtEnd, gdvDetails, "ThermalModel", avgDT)

                If gdvDetails.Rows.Count > 0 Then
                    gdvDetails.Columns(15).Visible = False
                    btnRun.Visible = True
                End If

                'DrawEffectiveAlFe(dtStart, dtEnd)
                'DrawTotalAlFe(dtStart, dtEnd)

            Catch ex As Exception

            End Try
        End If
    End Sub

    Protected Sub txtDate_TextChanged(sender As Object, e As System.EventArgs) Handles txtDate.TextChanged
        Try
            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            Dim avgDT As Double = 0.0
            objController.PopulateAcpmData(fromDt, toDt, gdvDetails, "ThermalModel", avgDT)

            If gdvDetails.Rows.Count > 0 Then
                gdvDetails.Columns(15).Visible = False
                btnRun.Visible = True
            End If
            btnRun_Click(sender, e)
        Catch ex As Exception

        End Try
       
    End Sub
 
    Protected Sub gdvDetails_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles gdvDetails.RowCommand
        Try
            Dim index = Convert.ToInt32(e.CommandArgument)
            If e.CommandName = "lnkEdit" Then


                CType(gdvDetails.Rows(index).FindControl("txtSHG"), TextBox).ReadOnly = False
                CType(gdvDetails.Rows(index).FindControl("txtCGG"), TextBox).ReadOnly = False
                CType(gdvDetails.Rows(index).FindControl("txtFivePer"), TextBox).ReadOnly = False
                CType(gdvDetails.Rows(index).FindControl("txtSHG"), TextBox).Enabled = True
                CType(gdvDetails.Rows(index).FindControl("txtCGG"), TextBox).Enabled = True
                CType(gdvDetails.Rows(index).FindControl("txtFivePer"), TextBox).Enabled = True


            End If
        Catch ex As Exception

        End Try
       

    End Sub

  
    Protected Sub btnRun_Click(sender As Object, e As EventArgs) Handles btnRun.Click
        Try

            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            Dim dt As DataTable = objController.GetDataForAcpmThermalGalvBath(fromDt, toDt)

            Dim avgDT As Double = 0.0

            If dt.Rows.Count > 0 Then

                For r = 0 To dt.Rows.Count - 1

                    objThermalModel.ThermalModel(dt, r, gdvDetails, avgDT)
                Next
            End If
            If gdvDetails.Rows.Count > 0 Then
                avgDT = avgDT / gdvDetails.Rows.Count
                If avgDT > 0.0 Then
                    Literal1.Text = "Avg(∆T): " & Math.Round(avgDT, 1)
                End If
            End If

            gdvDetails.Rows(dt.Rows.Count - 1).Cells(15).Text = gdvDetails.Rows(dt.Rows.Count - 1).Cells(14).Text
            For r = dt.Rows.Count - 2 To 0 Step -1
                Dim p, p1 As Decimal
                Try
                    p = gdvDetails.Rows(r).Cells(14).Text
                    p1 = gdvDetails.Rows(r + 1).Cells(15).Text
                    'gdvDetails.Rows(r).Cells(13).Text = gdvDetails.Rows(r).Cells(12).Text + gdvDetails.Rows(r + 1).Cells(13).Text
                    gdvDetails.Rows(r).Cells(15).Text = p + p1
                Catch ex As Exception

                End Try

            Next
            DrawChart()

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub gdvDetails_RowEditing(sender As Object, e As GridViewEditEventArgs) Handles gdvDetails.RowEditing
        Try
            gdvDetails.EditIndex = e.NewEditIndex
        Catch ex As Exception

        End Try

    End Sub

    Sub DrawChart()
        Try

            chartdiv.Visible = True
            Dim int As Integer = gdvDetails.Rows.Count - 1
            Dim tAct() As String = New String(int) {}
            Dim tCalc() As String = New String(int) {}
            Dim time() As String = New String(int) {}
            For i As Integer = gdvDetails.Rows.Count - 1 To 0 Step -1

                tAct(i) = gdvDetails.Rows(i).Cells(12).Text.ToString

                tCalc(i) = gdvDetails.Rows(i).Cells(13).Text.ToString

                time(i) = gdvDetails.Rows(i).Cells(3).Text.ToString


            Next

            objController.PlotLineChartForThermaAcpm_GalvBathThermalModel(time, tAct, tCalc, Lit1, "container1", "plot1", "")
            ' objController.PlotLineChartForThermaAcpm(time, time, time, tAct, tCalc, tCalc, Lit1, "container1", "plot1", "")

        Catch ex As Exception

        End Try


    End Sub


End Class

