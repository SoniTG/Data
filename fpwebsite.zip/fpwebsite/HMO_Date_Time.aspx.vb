﻿Imports System.Data
Imports System.Data.OleDb
Imports System.IO
Partial Class HMO_Date_Time
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("ACPM_Ora").ConnectionString
    Dim Oleconnection_ora As New OleDbConnection(strConnectionString)
    Dim OleAdap As New OleDbDataAdapter
    Dim ds, ds1, ds2, ds3, ds4, ds5, ds6, ds7, ds10 As New DataSet
    Dim dt, dt1, dt2, dt3, dt4, dt5, dt6, dt7, dt10 As New DataTable
    Dim OleCom As New OleDbCommand
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        ' Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))

        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))

                'Dim dtfrom As String = DateTime.Now.AddHours(-3).ToString("yyyy-MM-dd HH:mm")
                ''Dim dtStart As DateTime = DateTime.Now.AddMonths(-4).ToString("yyyy-MM-dd HH:mm")
                'Dim dtto As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                'Dim dtStart As String = hfFrom.Value
                'Dim dtEnd As String = hfTo.Value
                '' Dim filter As String = " 1=1"
                'DrawChartTop(dtStart, dtEnd)
                Dim fromDt As String = DateTime.Now.AddHours(-3).ToString("yyyy-MM-dd HH:mm")
                Dim toDt As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

                DrawChartTop(fromDt, toDt)
                ' LoadTdc(orfrom, orto)

                hfFrom.Value = fromDt
                hfTo.Value = toDt

            Catch ex As Exception

            End Try
        End If

        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
                If (p = "d") Then
                    Dim fromDt As String = hfFrom.Value
                    Dim toDt As String = hfTo.Value 'CDate(hfTo.Value).ToString("yyyy-MM-dd 06:00:00")
                    DrawChartTop(fromDt, toDt)

                End If
            Catch ex As Exception
                Throw ex
            End Try

        End If
        'If Not Page.IsPostBack Then
        '    Try
        '        'Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))

        '        Dim dtStart As DateTime = DateTime.Now.AddHours(-3).ToString("yyyy-MM-dd HH:mm")
        '        Dim dtEnd As DateTime = DateTime.Now.ToString
        '        DrawChartTop(dtStart, dtEnd)


        '    Catch ex As Exception

        '    End Try

        'End If
    End Sub



    Sub DrawChartTop(ByVal FromDt As String, ByVal ToDt As String)
        Try

            Dim dtStart As String = FromDt
            Dim dtEnd As String = ToDt

            'Dim DTCGL1 As DataTable = GetDataForCGL1()
            Dim dt As DataTable = objController.POPULATELD3DATA(dtStart, dtEnd)

            Dim dtcast2 As DataTable = objController.POPULATELD3DATAforcaster2(dtStart, dtEnd)
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

            Dim dtcast1chart3 As DataTable = objController.LD3_DataCaster1_chart3(dtStart, dtEnd)
            Dim dtcast2chart3 As DataTable = objController.LD3_DataCaster2_chart3(dtStart, dtEnd)

            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            Dim dtcast1Ref_vs_lsrs As DataTable = objController.LD3_DataCaster1_chart_Ref_LSvsRS(dtStart, dtEnd)
            Dim dtcast2Ref_vs_lsrs As DataTable = objController.LD3_DataCaster2_chart_Ref_LSvsRS(dtStart, dtEnd)
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

            'Dim dtchart5 As DataTable = objController.POPULATELD3DATA(dtStart, dtEnd)
            'Dim dtchart6 As DataTable = objController.POPULATELD3DATAforcaster2(dtStart, dtEnd)
            '======================================================================
            'Dim RS As DataTable = objController.POPULATELD3DATAforcaster2RS(dtStart, dtEnd)
            'Dim LS As DataTable = objController.POPULATELD3DATAforcaster2LS(dtStart, dtEnd)

            '======================================================================
            '  POPULATELD3DATAforcaster2LS
            '   PlotLineChart(dt, "HMO_TIMESTAMP", "HMO_DEV", Lit1, "container1", "plot1", "", "", "SIDE")
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            If dt.Rows.Count > 0 Then
                'objController.lineForLD3MILL(dt, Lit1, "container1", "plot", "", "SIDE")

                '  PlotLineChart(dt, "HMO_TIMESTAMP", "HMO_DEV", Lit1, "container1", "plot1", "", "", "SIDE")
                objController.LD3LINECHART(dt, Lit1, "container1", "plot1", "")

            End If

            If dtcast2.Rows.Count > 0 Then

                objController.LD3LINECHART(dtcast2, Lit2, "container2", "plot2", "")

            End If

            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            If dtcast1chart3.Rows.Count > 0 Then
                objController.LD3LINECHART3(dtcast1chart3, Lit3, "container3", "plot3", "")

            End If
            If dtcast2chart3.Rows.Count > 0 Then
                objController.LD3LINECHART3(dtcast2chart3, Lit4, "container4", "plot4", "")

            End If


            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            If dtcast1Ref_vs_lsrs.Rows.Count > 0 Then
                objController.LD3LINECHARTfor_refrence_side(dtcast1Ref_vs_lsrs, Lit5, "container5", "plot5", "")

            End If
            If dtcast2Ref_vs_lsrs.Rows.Count > 0 Then
                objController.LD3LINECHARTfor_refrence_side(dtcast2Ref_vs_lsrs, Lit6, "container6", "plot6", "")

            End If
        Catch ex As Exception

        End Try
    End Sub







    Public Sub PlotLineChart(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String, ByVal GroupByColName As String)
        Try
            'For i As Integer = 0 To dt.Rows.Count - 1
            '    If IsDBNull(dt.Rows(i)("LTRI_PARA_MIN")) Then
            '        dt.Rows(i)("LTRI_PARA_MIN") = dt.Rows(i)("LTRI_PARA_MIN").ToString().Replace(vbNull, vbDecimal)
            '    End If
            'Next
            LiteralName.Text = ""
            ' Dim min_time, max_time As String

            'Dim xTimestampVal(), yVal() As String
            Dim yVal() As Decimal

            'xTimestampVal = (From row In dt Select col = row(XAxisColName).ToString).ToArray
            yVal = (From row In dt Select col = CDec(row(YAxisColName))).ToArray()

            'Dim y_min As String = yVal.Min()
            'Dim y_max As String = yVal.Max()
            Dim y_min As String = yVal.Min()
            Dim y_max As String = yVal.Max()

            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf
            dt.DefaultView.RowFilter = ""
            Dim dtGrades As DataTable = dt.DefaultView.ToTable(True, GroupByColName) 'All distinct Grades
            Dim dvDefault As DataView = dt.DefaultView
            Dim flag As Boolean = False
            For i As Integer = 0 To dtGrades.Rows.Count - 1
                js &= "var line" & (i + 1).ToString & " = ["
                dvDefault.RowFilter = "" & GroupByColName & "='" & dtGrades.Rows(i)(0) & "'"
                For j As Integer = 0 To dvDefault.Count - 1
                    If j > 0 Then
                        js &= ","
                    End If
                    js &= "["
                    Dim dtTime As DateTime = dvDefault.Item(j)("HMO_TIMESTAMP")
                    If IsDBNull(dvDefault.Item(j)(GroupByColName)) Then
                        If IsDBNull(dvDefault.Item(j)("HMO_DEV")) = False Then
                            js &= "'" & dtTime.ToString("yyyy-MM-dd") & "', " & dvDefault.Item(j)("HMO_DEV") & ", " & "null"
                        Else
                            js &= "'" & dtTime.ToString("yyyy-MM-dd") & "', " & "null, null"
                        End If
                    Else
                        If IsDBNull(dvDefault.Item(j)("HMO_DEV")) = False Then
                            js &= "'" & dtTime.ToString("yyyy-MM-dd") & "', " & dvDefault.Item(j)("HMO_DEV") & ", '(" & dvDefault.Item(j)(GroupByColName).ToString().Trim & ")'"
                            'js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)("CLR_TEST_VALUE") & ", 'Pot'"
                        End If
                    End If
                    js &= "]"
                Next
                js &= "];" & vbCrLf
                flag = True
            Next

            Dim strg As String = ""
            Dim strseries As String = ""
            If flag Then
                strg = "[line1"
                strseries = " {pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
                For i As Integer = 1 To dtGrades.Rows.Count - 1
                    strg = strg + ",line" & i + 1
                    strseries = strseries + ", {pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
                Next
                strg &= "]"
            End If
            js &= "var seriesName = ['"
            Dim str As String = ""
            For i As Integer = 0 To dtGrades.Rows.Count - 1
                str &= dtGrades.Rows(i)(0).ToString().Trim() + "', '"
            Next
            str = str.Remove(str.LastIndexOf(", '"))
            str &= "];"
            js &= str
            js &= "opts = {" & vbCrLf &
            "title: '" & ChartTitle & "',highlighter: {show: true,tooltipContentEditor: function (str, seriesIndex, pointIndex, plot) {var html = '<div>Month: ' + plot.data[seriesIndex][pointIndex][0] + '<br/>Data: ' + Math.round(plot.data[seriesIndex][pointIndex][1]); return html;}}," & vbCrLf &
            "series:[" & strseries & "]," & vbCrLf &
            "seriesColors: ['#4C4ED8','#EF3862','#8A1EEE','#0982EC','#0FBDE3','#043D1D','#059B11','#E1EB05','#666699','#F4ED03','#EF8355','#818181','#FFA500', '#006400','#F10000','#996633','#ECAE06','#009999','#800000','#F05904']," & vbCrLf &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            " angle: 30,fontSize:   '10pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "renderer: $.jqplot.CategoryAxisRenderer" & vbCrLf &
            "}," & vbCrLf &
            "yaxis: { " & vbCrLf &
            "tickOptions: { formatString: '%d' }," & vbCrLf &
            "min: " & y_min & "," & vbCrLf &
            "max: " & y_max & "," & vbCrLf &
            "autoscale:true," & vbCrLf &
            "label: '" & YAxisLabelName & "'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "showTooltip: false," & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "animate: true," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
            "legend: {" & vbCrLf &
            "show: true," & vbCrLf &
            "location: 's'," & vbCrLf &
            "labels: seriesName," & vbCrLf &
            "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
            "placement: 'outsideGrid'," & vbCrLf &
            "rendererOptions: {" & vbCrLf &
            "numberRows: 1," & vbCrLf &
            "marginTop: 10" & vbCrLf &
            "}" & vbCrLf &
            "}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "', " & strg & ", opts);" & vbCrLf &
            "</script>" & vbCrLf

            LiteralName.Text = js
        Catch ex As Exception

        End Try
    End Sub




    Public Function GetDataForCGL1() As DataTable
        CloseConnection()
        Oleconnection_ora.Open()
        Dim OraQuery As String = " SELECT COUNT(*) AS CNT,decode(dcc_prod_cd,'C02' ,'SOFT' ,'C05' ,'HARD') AS PRODCD from v_cg1_galv_coil where DCC_TS_END > to_date('2020-12-01', 'YYYY-MM-DD') and  DCC_TS_END < to_date('2021-01-01 06:00', 'YYYY-MM-DD HH24:MI') GROUP BY decode(dcc_prod_cd,'C02' ,'SOFT' ,'C05' ,'HARD')"
        Ora_selectquery(OraQuery)
        OleAdap.Fill(ds)
        dt = ds.Tables(0)
        Return dt
    End Function

    Sub CloseConnection()
        Try
            'If sqlconnection.State <> ConnectionState.Closed Then
            '    Oleconnection_ora.Close()
            'End If
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

    End Sub
    Public Function Ora_selectquery(ByVal strselect As String) As OleDbDataAdapter
        Try

            OleCom.Connection = Oleconnection_ora
            OleCom.CommandText = strselect
            OleAdap.SelectCommand = OleCom

            Return OleAdap

        Catch ex As Exception

        End Try
    End Function
End Class
