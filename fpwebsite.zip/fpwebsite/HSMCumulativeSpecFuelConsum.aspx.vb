﻿Imports System.Data
Imports System.IO

Imports System.Web
Imports System.Web.Services

Imports System.Net
Imports System.Data.SqlClient
Imports System.Web.Script.Serialization
Imports System.Drawing
Imports System.Web.UI

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
<System.Web.Script.Services.ScriptService()>
<WebService(Namespace:="http://tempuri.org/")>
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)>
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class HSMCumulativeSpecFuelConsum
    Inherits System.Web.UI.Page

    Dim objController As New Controller
    Dim objdatahandler As New DataHandler

    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "alert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString
    Dim maindt As New DataTable
    '  Public Property responseObj As Object
    Function getdatatable(ByVal query As String) As DataTable
        Dim fndatatable As New DataTable
        'Dim connection As String = "Password=Welcome@135;Persist Security Info=True;User ID=153521;Initial Catalog=WRM_blt_data;Data Source=176.0.0.60\lptgsqldev"
        Dim connection As String = "Password=Welcome@135;Persist Security Info=True;User ID=153521;Initial Catalog=FP_PROCESS_DATA;Data Source=176.0.0.60\lptgsqldev"

        Using con As New SqlConnection(connection)
            Using cmd As New SqlCommand(query, con)
                cmd.CommandType = CommandType.Text
                Using sda As New SqlDataAdapter(cmd)
                    sda.SelectCommand.CommandTimeout = 100000

                    'Using dt As New DataTable()
                    sda.Fill(fndatatable)
                    'End Using
                End Using
            End Using
        End Using
        Return fndatatable
    End Function

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    txtDate_TextChanged()
                End If

            Catch ex As Exception

            End Try

        End If
        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                'Session("Department") = "HSM Furnace Heat Distribution Model"
                'Dim dtStart As String = Now.AddDays(-7).ToString("yyyy-MM-dd HH:mm:ss")
                'Dim dtEnd As String = Now.ToString("yyyy-MM-dd HH:mm:ss")

                'Now.ToString("yyyy-MM-dd HH:mm:ss")
                Dim dtStart As String = DateTime.Now.AddDays(-29).ToString("yyyy-MM-dd HH:mm")
                'Dim dtStart As DateTime = DateTime.Now.AddMonths(-4).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")


                ''===================================Added for Gas Monitoring By Tirthankar 10-July-23 ====================================

                'HSM_GAS_LOSS_FURNACE_A(dtStart, dtEnd)
                'HSM_GAS_LOSS_FURNACE_B(dtStart, dtEnd)
                'DrawChart__SECGasMonitr_LineB(dtStart, dtEnd)
                CumulativeFuelCon(dtStart, dtEnd)

                '============================GRID VALUES===================================


            Catch ex As Exception
                Dim tem As String = ex.Message
            End Try
        End If
    End Sub

    Protected Sub txtDate_TextChanged() Handles txtDate.TextChanged
        Try

            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            Dim furid As String = Request.QueryString("Furnace")
            '=================

            Dim dt As DataTable = objController.CumulativeSpecFuelConData(furid, fromDt, toDt)
            objController.CUMULATIVE_Spec_Fuel_Monitor_Chart(dt, Lit18, "container11", "plot1", "")


        Catch ex As Exception
            ' Lit1.Text = ""
            Dim tem As String = ex.Message
            Exit Sub
        End Try

    End Sub

    Private Sub CumulativeFuelCon(ByVal FromDt As String, ByVal ToDt As String)
        Try

            Dim strfrmDt As String = FromDt
            Dim strToDt As String = ToDt
            Dim furid As String = Request.QueryString("Furnace")

            Dim dt As DataTable = objController.CumulativeSpecFuelConData(furid, strfrmDt, strToDt)
            objController.CUMULATIVE_Spec_Fuel_Monitor_Chart(dt, Lit18, "container11", "plot1", "")

        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub

    'Sub HSM_GAS_LOSS_FURNACE_A(ByVal FromDt As String, ByVal ToDt As String)
    '    Try

    '        Dim strfrmDt As String = FromDt
    '        Dim strToDt As String = ToDt

    '        'Dim dt As DataTable = objController.POPULATE_FURNACE_SEC1_LINEA_GasMonitor(strfrmDt, strToDt)
    '        Dim dt As DataTable = objController.POPULATE_FURNACE_GasLossMonitor("1", strfrmDt, strToDt)
    '        objController.FURNACE_CHART_GasLossMonitor(dt, Lit18, "container11", "plot1", "")

    '    Catch ex As Exception
    '        Throw New Exception(ex.ToString())
    '    End Try
    'End Sub

    'Sub HSM_GAS_LOSS_FURNACE_B(ByVal FromDt As String, ByVal ToDt As String)
    '    Try

    '        Dim strfrmDt As String = FromDt
    '        Dim strToDt As String = ToDt

    '        'Dim dt As DataTable = objController.POPULATE_FURNACE_SEC1_LINEA_GasMonitor(strfrmDt, strToDt)
    '        Dim dt As DataTable = objController.POPULATE_FURNACE_GasLossMonitor("2", strfrmDt, strToDt)
    '        objController.FURNACE_CHART_GasLossMonitor(dt, Lit19, "container22", "plot2", "")

    '    Catch ex As Exception
    '        Throw New Exception(ex.ToString())
    '    End Try
    'End Sub


End Class
