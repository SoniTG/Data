﻿Imports System.Data
Imports System.IO

Imports System.Web
Imports System.Web.Services

Imports System.Net
Imports System.Data.SqlClient
Imports System.Web.Script.Serialization
Imports System.Drawing
Imports System.Web.UI

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
<System.Web.Script.Services.ScriptService()>
<WebService(Namespace:="http://tempuri.org/")>
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)>
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class HSMReheatingFurnace
    Inherits System.Web.UI.Page

    Dim objController As New Controller
    Dim objdatahandler As New DataHandler

    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Dim TOTAL_SPEC As String = ""
    Dim SPECTOTAL As Decimal
    Function getdatatable(ByVal query As String) As DataTable
        Dim fndatatable As New DataTable
        Dim connection As String = "Password=Welcome@135;Persist Security Info=True;User ID=153521;Initial Catalog=FP_PROCESS_DATA;Data Source=176.0.0.60\lptgsqldev"
        Using con As New SqlConnection(connection)
            Using cmd As New SqlCommand(query, con)
                cmd.CommandType = CommandType.Text
                Using sda As New SqlDataAdapter(cmd)
                    'Using dt As New DataTable()
                    sda.Fill(fndatatable)
                    'End Using
                End Using
            End Using
        End Using
        Return fndatatable
    End Function


    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                MultiView1.ActiveViewIndex = 0
                'DrawChartFor_on_toDate()
                DrawSpecFuelChart()
                'btnRecup1.Attributes.Add("style", "text-decoration:blink")
                'btnRecup1.BackColor = Color.Red
                'btnRecup1.CssClass &= " blink"

                ''Commented Tirthankar 12-Jun-23
                ''If rbdChartLineA.Checked Then
                ''    If rbdChartAvgValue.Checked Then
                ''        DrawChartForLINEA()
                ''    ElseIf rbdChartthisMonthValue.Checked Then
                ''        DrawChartForLINEA()
                ''    End If
                ''    '===========================
                ''ElseIf rbdChartLineB.Checked Then
                ''    ' DrawChartForLINEB()
                ''    If rbdChartAvgValue.Checked Then
                ''        DrawChartForLINEB()
                ''    ElseIf rbdChartthisMonthValue.Checked Then
                ''        DrawChartForLINEB()
                ''    End If

                ''    ' DrawChartForLINEA_LINEB()
                ''    '=====================================
                ''ElseIf rbdChartLineA_LineB.Checked Then
                ''    '  DrawChartForLINEA_LINEB()
                ''    If rbdChartAvgValue.Checked Then
                ''        ' DrawChartForLINEA()
                ''        DrawChartForLINEA_LINEB()
                ''    ElseIf rbdChartthisMonthValue.Checked Then
                ''        DrawChartForLINEA_LINEB()
                ''    End If
                ''    '====================================
                ''End If
                ''End Commented Tirthankar 12-Jun-23
                '=========================================
                ' GETSPEC_TOTAL(stdategrid, enddategrid)

                'TC and Zone Temperature Code Start

                'Dim sqlQuery As String = "Select Top 1 TIMESTAMP,LINE,"
                'sqlQuery &= " ZONE1_TC1, ZONE1_TC2, ZONE1_TC3, Cast((ZONE1_TC1 + ZONE1_TC2 + ZONE1_TC3) / 3 As Integer) As AvgZone1,"
                'sqlQuery &= " ZONE2_TC1, ZONE2_TC2, ZONE2_TC3, Cast((ZONE2_TC1 + ZONE2_TC2 + ZONE2_TC3) / 3 As Integer) As AvgZone2,"
                'sqlQuery &= " ZONE3_TC1, ZONE3_TC2, ZONE3_TC3, Cast((ZONE3_TC1 + ZONE3_TC2 + ZONE3_TC3) / 3 As Integer) As AvgZone3,"
                'sqlQuery &= " ZONE4_TC1, ZONE4_TC2, ZONE4_TC3, Cast((ZONE4_TC1 + ZONE4_TC2 + ZONE4_TC3) / 3 As Integer) As AvgZone4,"
                'sqlQuery &= " ZONE5_TC1, ZONE5_TC2, ZONE5_TC3, Cast((ZONE5_TC1 + ZONE5_TC2 + ZONE5_TC3) / 3 As Integer) As AvgZone5,"
                'sqlQuery &= " ZONE6_TC1, ZONE6_TC2, ZONE6_TC3, Cast((ZONE6_TC1 + ZONE6_TC2 + ZONE6_TC3) / 3 As Integer) As AvgZone6,"
                'sqlQuery &= " ZONE7_TC1, ZONE7_TC2, ZONE7_TC3, Cast((ZONE7_TC1 + ZONE7_TC2 + ZONE7_TC3) / 3 As Integer) As AvgZone7,"
                'sqlQuery &= " ZONE8_TC1, ZONE8_TC2, ZONE8_TC3, Cast((ZONE8_TC1 + ZONE8_TC2 + ZONE8_TC3) / 3 As Integer) As AvgZone8,"
                'sqlQuery &= " ZONE9_TC1, ZONE9_TC2, ZONE9_TC3, Cast((ZONE9_TC1 + ZONE9_TC2 + ZONE9_TC3) / 3 As Integer) as AvgZone9"
                'sqlQuery &= " From TSCR_FURNACE_ZONE_TEMP  Where Line = 'A' Order By TIMESTAMP desc"

                'Dim dt As DataTable = New DataTable()
                'dt = getdatatable(sqlQuery)
                'For Each row As DataRow In dt.Rows
                '    btnZ1TC1.Text = "TC101: " & row("ZONE1_TC1")
                '    btnZ1TC2.Text = "TC102: " & row("ZONE1_TC2")
                '    btnZ1TC3.Text = "TC103: " & row("ZONE1_TC3")
                '    btnZ1Avg.Text = "Avg Temp : " & row("AvgZone1")
                '    btnZ2TC1.Text = "TC201: " & row("ZONE2_TC1")
                '    btnZ2TC2.Text = "TC202: " & row("ZONE2_TC2")
                '    btnZ2TC3.Text = "TC203: " & row("ZONE2_TC3")
                '    btnZ2Avg.Text = "Avg Temp : " & row("AvgZone2")
                '    btnZ3TC1.Text = "TC301: " & row("ZONE3_TC1")
                '    btnZ3TC2.Text = "TC302: " & row("ZONE3_TC2")
                '    btnZ3TC3.Text = "TC303: " & row("ZONE3_TC3")
                '    btnZ3Avg.Text = "Avg Temp : " & row("AvgZone3")
                '    btnZ4TC1.Text = "TC401: " & row("ZONE4_TC1")
                '    btnZ4TC2.Text = "TC402: " & row("ZONE4_TC2")
                '    btnZ4TC3.Text = "TC403: " & row("ZONE4_TC3")
                '    btnZ4Avg.Text = "Avg Temp : " & row("AvgZone4")
                '    btnZ5TC1.Text = "TC501: " & row("ZONE5_TC1")
                '    btnZ5TC2.Text = "TC502: " & row("ZONE5_TC2")
                '    btnZ5TC3.Text = "TC503: " & row("ZONE5_TC3")
                '    btnZ5Avg.Text = "Avg Temp : " & row("AvgZone5")
                '    btnZ6TC1.Text = "TC601: " & row("ZONE6_TC1")
                '    btnZ6TC2.Text = "TC602: " & row("ZONE6_TC2")
                '    btnZ6TC3.Text = "TC603: " & row("ZONE6_TC3")
                '    btnZ6Avg.Text = "Avg Temp : " & row("AvgZone6")
                '    btnZ7TC1.Text = "TC701: " & row("ZONE7_TC1")
                '    btnZ7TC2.Text = "TC702: " & row("ZONE7_TC2")
                '    btnZ7TC3.Text = "TC703: " & row("ZONE7_TC3")
                '    btnZ7Avg.Text = "Avg Temp : " & row("AvgZone7")
                '    btnZ8TC1.Text = "TC801: " & row("ZONE8_TC1")
                '    btnZ8TC2.Text = "TC802: " & row("ZONE8_TC2")
                '    btnZ8TC3.Text = "TC803: " & row("ZONE8_TC3")
                '    btnZ8Avg.Text = "Avg Temp : " & row("AvgZone8")
                '    btnZ9TC1.Text = "TC901: " & row("ZONE9_TC1")
                '    btnZ9TC2.Text = "TC902: " & row("ZONE9_TC2")
                '    btnZ9TC3.Text = "TC903: " & row("ZONE9_TC3")
                '    btnZ9Avg.Text = "Avg Temp : " & row("AvgZone9")
                'Next row
                ''TC and Zone Temperature Code End

                'Dim sqlQueryLB As String = "Select Top 1 TIMESTAMP,LINE,"
                'sqlQueryLB &= " ZONE1_TC1, ZONE1_TC2, ZONE1_TC3, Cast((ZONE1_TC1 + ZONE1_TC2 + ZONE1_TC3) / 3 As Integer) As AvgZone1,"
                'sqlQueryLB &= " ZONE2_TC1, ZONE2_TC2, ZONE2_TC3, Cast((ZONE2_TC1 + ZONE2_TC2 + ZONE2_TC3) / 3 As Integer) As AvgZone2,"
                'sqlQueryLB &= " ZONE3_TC1, ZONE3_TC2, ZONE3_TC3, Cast((ZONE3_TC1 + ZONE3_TC2 + ZONE3_TC3) / 3 As Integer) As AvgZone3,"
                'sqlQueryLB &= " ZONE4_TC1, ZONE4_TC2, ZONE4_TC3, Cast((ZONE4_TC1 + ZONE4_TC2 + ZONE4_TC3) / 3 As Integer) As AvgZone4,"
                'sqlQueryLB &= " ZONE5_TC1, ZONE5_TC2, ZONE5_TC3, Cast((ZONE5_TC1 + ZONE5_TC2 + ZONE5_TC3) / 3 As Integer) As AvgZone5,"
                'sqlQueryLB &= " ZONE6_TC1, ZONE6_TC2, ZONE6_TC3, Cast((ZONE6_TC1 + ZONE6_TC2 + ZONE6_TC3) / 3 As Integer) As AvgZone6,"
                'sqlQueryLB &= " ZONE7_TC1, ZONE7_TC2, ZONE7_TC3, Cast((ZONE7_TC1 + ZONE7_TC2 + ZONE7_TC3) / 3 As Integer) As AvgZone7,"
                'sqlQueryLB &= " ZONE8_TC1, ZONE8_TC2, ZONE8_TC3, Cast((ZONE8_TC1 + ZONE8_TC2 + ZONE8_TC3) / 3 As Integer) As AvgZone8"
                ''sqlQueryLB &= " ZONE9_TC1, ZONE9_TC2, ZONE9_TC3, Cast((ZONE9_TC1 + ZONE9_TC2 + ZONE9_TC3) / 3 As Integer) as AvgZone9"
                'sqlQueryLB &= " From TSCR_FURNACE_ZONE_TEMP  Where Line = 'B' Order By TIMESTAMP desc"

                'Dim dtLB As DataTable = New DataTable()
                'dtLB = getdatatable(sqlQueryLB)
                'For Each row As DataRow In dtLB.Rows
                '    btnLBZ1TC1.Text = "TC101: " & row("ZONE1_TC1")
                '    btnLBZ1TC2.Text = "TC102: " & row("ZONE1_TC2")
                '    btnLBZ1TC3.Text = "TC103: " & row("ZONE1_TC3")
                '    btnLBZ1Avg.Text = "Avg Temp : " & row("AvgZone1")
                '    btnLBZ2TC1.Text = "TC201: " & row("ZONE2_TC1")
                '    btnLBZ2TC2.Text = "TC202: " & row("ZONE2_TC2")
                '    btnLBZ2TC3.Text = "TC203: " & row("ZONE2_TC3")
                '    btnLBZ2Avg.Text = "Avg Temp : " & row("AvgZone2")
                '    btnLBZ3TC1.Text = "TC301: " & row("ZONE3_TC1")
                '    btnLBZ3TC2.Text = "TC302: " & row("ZONE3_TC2")
                '    btnLBZ3TC3.Text = "TC303: " & row("ZONE3_TC3")
                '    btnLBZ3Avg.Text = "Avg Temp : " & row("AvgZone3")
                '    btnLBZ4TC1.Text = "TC401: " & row("ZONE4_TC1")
                '    btnLBZ4TC2.Text = "TC402: " & row("ZONE4_TC2")
                '    btnLBZ4TC3.Text = "TC403: " & row("ZONE4_TC3")
                '    btnLBZ4Avg.Text = "Avg Temp : " & row("AvgZone4")
                '    btnLBZ5TC1.Text = "TC501: " & row("ZONE5_TC1")
                '    btnLBZ5TC2.Text = "TC502: " & row("ZONE5_TC2")
                '    btnLBZ5TC3.Text = "TC503: " & row("ZONE5_TC3")
                '    btnLBZ5Avg.Text = "Avg Temp : " & row("AvgZone5")
                '    btnLBZ6TC1.Text = "TC601: " & row("ZONE6_TC1")
                '    btnLBZ6TC2.Text = "TC602: " & row("ZONE6_TC2")
                '    btnLBZ6TC3.Text = "TC603: " & row("ZONE6_TC3")
                '    btnLBZ6Avg.Text = "Avg Temp : " & row("AvgZone6")
                '    btnLBZ7TC1.Text = "TC701: " & row("ZONE7_TC1")
                '    btnLBZ7TC2.Text = "TC702: " & row("ZONE7_TC2")
                '    btnLBZ7TC3.Text = "TC703: " & row("ZONE7_TC3")
                '    btnLBZ7Avg.Text = "Avg Temp : " & row("AvgZone7")
                '    btnLBZ8TC1.Text = "TC801: " & row("ZONE8_TC1")
                '    btnLBZ8TC2.Text = "TC802: " & row("ZONE8_TC2")
                '    btnLBZ8TC3.Text = "TC803: " & row("ZONE8_TC3")
                '    btnLBZ8Avg.Text = "Avg Temp : " & row("AvgZone8")
                'Next row

            Catch ex As Exception
                Throw ex
            End Try
        End If

        If MultiView1.ActiveViewIndex = 0 Then

            '========================================================================
            'Dim dSdate As DataTable = objController.PopulateMaxDatetime()
            Dim dSdate As DataTable = objController.PopulateMaxDatetimeForHSM()

            'Dim dSdate As DataSet = objdatahandler.GetDataSetFromQuery("Select max(datetime) As DATETIME FROM  [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]")

            '  Dim dtdate As DataTable = dSdate.Tables(0)
            Dim dtdate As DataTable = dSdate

            Dim ddtdate As DateTime = CDate(dtdate.Rows(0)(0))
            Dim frmDate As String = ddtdate.ToString("yyyy-MM-dd HH:mm:ss")
            Dim toDate As String = ddtdate.AddHours(-1).ToString("yyyy-MM-dd HH:mm:ss")

            lblMAXDATETIME.Text = frmDate
            '===========================================================================

            '========================GRID_VALUE===================================================
            Try


                Dim dtEndgrid As String = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd")
                Dim dtStartgrid As String = DateTime.Now.ToString("yyyy-MM-dd")

                Dim strfrmDtgrid As String = dtStartgrid
                Dim strToDtgrid As String = dtEndgrid


                Dim Monthgrid As String = DateTime.Now.ToString("MM")

                Dim yeargrid As String = DateTime.Now.ToString("yyyy")

                Dim first_dategrid As String = 1



                Dim stdategrid As String = yeargrid & "-" & Monthgrid & "-" & first_dategrid
                '  Dim stdate As String = DateTime.Now.AddDays(-3).ToString("yyyy-MM-dd")
                Dim enddategrid As String = DateTime.Now.ToString("yyyy-MM-dd")

                GETSPEC_TOTAL(stdategrid, enddategrid)

                Dim sum, count As Double
                For Each s As String In TOTAL_SPEC.Split(",")
                    If Not String.IsNullOrEmpty(s) Then
                        sum += s
                        count += 1
                    End If

                Next
                Dim VAL_SPEC As Decimal = sum / count
                Dim SPECTOTAL As Decimal = FormatNumber(VAL_SPEC, 4)

                'lblSpecific.Text = SPECTOTAL 'sum / count
                Dim sqlQueryCum As String = "select top 1 [CUM_SPEC_FUEL_CON] FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY] where PRODUCTION='HRC' order by [DATETIME] desc"
                Dim dtLB As DataTable = New DataTable()
                dtLB = getdatatable(sqlQueryCum)
                For Each row As DataRow In dtLB.Rows
                    ''lblSpecific.Text = row("CUM_SPEC_FUEL_CON")
                Next row

            Catch ex As Exception
                ' Throw ex
            End Try
            'Catch ex As Exception

            'End Try






            'If VAL_SPEC = 0 Then
            '        SPECTOTAL = 0
            '    Else
            '        SPECTOTAL = FormatNumber(VAL_SPEC, 4)
            '    End If
            'Catch ex As Exception

            'End Try

            '===========================================================
            Dim dtspecificdataset As DataSet = objdatahandler.GetDataSetFromQuery("SELECT cast(AVG(SPC_FUEL_CON_ONLINE) As Decimal(10,3)) As SPC_FUEL_CON_ONLINE FROM [TSCR_FURNACE_OPT_FINAL]  where  DATEPART(m, datetime) = DATEPART(m, DATEADD(m, 0, getdate()))  GROUP BY DATENAME(MONTH,DATETIME) order by DATENAME(MONTH,DATETIME) asc")
            Dim dtspecificdatasetB As DataSet = objdatahandler.GetDataSetFromQuery("SELECT cast(AVG(SPC_FUEL_CON_ONLINE) As Decimal(10,3)) As SPC_FUEL_CON_ONLINE FROM [TSCR_FURNACE_OPT_FINAL]  where  DATEPART(m, datetime) = DATEPART(m, DATEADD(m, 0, getdate())) AND LINE ='B' GROUP BY DATENAME(MONTH,DATETIME) order by DATENAME(MONTH,DATETIME) asc")

            Dim dtspecificdatatable As DataTable = dtspecificdataset.Tables(0)
            Dim dtspecificdatatableB As DataTable = dtspecificdatasetB.Tables(0)
            Dim dtspecific As String = dtspecificdatatable.Rows(0)("SPC_FUEL_CON_ONLINE")
            Dim dtspecificB As String = dtspecificdatatableB.Rows(0)("SPC_FUEL_CON_ONLINE")

            '  Dim AVG_LineA_LineB As String = (dtspecific + dtspecificB) / 2
            ' lblSpecific.Text = dtspecific
            '  lblSpecific.Text = SPECTOTAL 'sum / count
            '========================LINEA======================================
            Try
                Dim dt As DataTable = objController.PopulateDataForHeatDistributionModel()
                ''Code Added Below Tirthankar 12-Jun-23
                Dim dtGcFur1 As DataTable = objController.PopulateDataForHSMFurnace1()
                Dim dtGcFur1TPOH As DataTable = objController.PopulateDataForHSMFurnace1TPOH()
                Dim dtGcFur2 As DataTable = objController.PopulateDataForHSMFurnace2()
                Dim dtGcFur2TPOH As DataTable = objController.PopulateDataForHSMFurnace2TPOH()
                Dim dtGcAirFlRatio As DataTable = objController.PopulateAirFuelRatio()
                'Dim dtRecup85checkFir1 As DataTable = objController.PopuDataForRecup85HigherFur1()
                'Dim dtRecup85checkFir2 As DataTable = objController.PopuDataForRecup85HigherFur2()


                If dtGcAirFlRatio.Rows.Count > 0 Then
                    btnZ1ActRatio.Text = dtGcAirFlRatio.Rows(0)("Z1_AIR_FUEL_RATIO")
                    btnZ1ActExceAir.Text = dtGcAirFlRatio.Rows(0)("Z1_EXCESS_AIR")
                    btnZ1RecRatio.Text = ""

                    btnZ2ActRatio.Text = dtGcAirFlRatio.Rows(0)("Z2_AIR_FUEL_RATIO")
                    btnZ2ActExceAir.Text = dtGcAirFlRatio.Rows(0)("Z2_EXCESS_AIR")
                    btnZ2RecRatio.Text = ""

                    btnZ3ActRatio.Text = dtGcAirFlRatio.Rows(0)("Z3_AIR_FUEL_RATIO")
                    btnZ3ActExceAir.Text = dtGcAirFlRatio.Rows(0)("Z3_EXCESS_AIR")
                    btnZ3RecRatio.Text = ""

                    btnZ4ActRatio.Text = dtGcAirFlRatio.Rows(0)("Z4_AIR_FUEL_RATIO")
                    btnZ4ActExceAir.Text = dtGcAirFlRatio.Rows(0)("Z4_EXCESS_AIR")
                    btnZ4RecRatio.Text = ""

                    btnZ5ActRatio.Text = dtGcAirFlRatio.Rows(0)("Z5_AIR_FUEL_RATIO")
                    btnZ5ActExceAir.Text = dtGcAirFlRatio.Rows(0)("Z5_EXCESS_AIR")
                    btnZ5RecRatio.Text = ""

                    btnZ6ActRatio.Text = dtGcAirFlRatio.Rows(0)("Z6_AIR_FUEL_RATIO")
                    btnZ6ActExceAir.Text = dtGcAirFlRatio.Rows(0)("Z6_EXCESS_AIR")
                    btnZ6RecRatio.Text = ""

                    btnZ7ActRatio.Text = dtGcAirFlRatio.Rows(0)("Z7_AIR_FUEL_RATIO")
                    btnZ7ActExceAir.Text = dtGcAirFlRatio.Rows(0)("Z7_EXCESS_AIR")
                    btnZ7RecRatio.Text = ""

                    btnZ8ActRatio.Text = dtGcAirFlRatio.Rows(0)("Z8_AIR_FUEL_RATIO")
                    btnZ8ActExceAir.Text = dtGcAirFlRatio.Rows(0)("Z8_EXCESS_AIR")
                    btnZ8RecRatio.Text = ""

                    btnZ9ActRatio.Text = dtGcAirFlRatio.Rows(0)("Z9_AIR_FUEL_RATIO")
                    btnZ9ActExceAir.Text = dtGcAirFlRatio.Rows(0)("Z9_EXCESS_AIR")
                    btnZ9RecRatio.Text = ""

                    btnZ10ActRatio.Text = dtGcAirFlRatio.Rows(0)("Z10_AIR_FUEL_RATIO")
                    btnZ10ActExceAir.Text = dtGcAirFlRatio.Rows(0)("Z10_EXCESS_AIR")
                    btnZ10RecRatio.Text = ""

                    btnOvrActRatio.Text = dtGcAirFlRatio.Rows(0)("TOTAL_AIR_FUEL_RATIO")
                    btnOvrActExcAir.Text = dtGcAirFlRatio.Rows(0)("TOTAL_EXCESS_AIR")
                    btnOvrRecRatio.Text = dtGcAirFlRatio.Rows(0)("BASE_SUGG_LOW") & " - " & dtGcAirFlRatio.Rows(0)("BASE_SUGG_HIGH")

                End If



                ''End Code Added  Tirthankar 12-Jun-23
                Dim dtlabel As DataTable = objController.populatelabelValue()
                Dim dtlabelavg As DataTable = objController.populatelabelValueForAvg(frmDate, toDate)
                '===========lineb=====================
                Dim dtlineB As DataTable = objController.PopulateDataForHeatDistributionModelFORLINEB()
                Dim dtlabelLineB As DataTable = objController.populatelabelValueFORLINEB()
                '   Dim dtavglineb As DataTable = objController.PopulateAvgValuefromdtLineb(frmDate, toDate)
                Dim dtavglineb As DataTable = objController.populatelabelValueForAvgLineB(frmDate, toDate)
                If rdbtnLineA.Checked Then
                    ''Code Commented Below Tirthankar 12-Jun-23
                    ''If rbdTimeStamp.Checked Then
                    ''    dtlabel = objController.populatelabelValue()
                    ''ElseIf rbdAVG.Checked Then
                    ''    dtlabelavg = objController.populatelabelValueForAvg(frmDate, toDate)
                    ''End If
                    ''End Code Comment Tirthankar 12-Jun-23
                End If
                If rdbtnLineB.Checked Then
                    ''Code Commented Below Tirthankar 12-Jun-23
                    ''If rbdTimeStamp.Checked Then
                    ''    dtlabelLineB = objController.populatelabelValueFORLINEB()
                    ''ElseIf rbdAVG.Checked Then
                    ''    dtavglineb = objController.populatelabelValueForAvgLineB(frmDate, toDate)
                    ''End If
                    ''End Code Comment Tirthankar 12-Jun-23
                End If

                '=================================================================
                '====================Chart Radio Button Change=========================

                '==========================

                ''If rbdChartLineA.Checked Then
                ''    If rbdChartAvgValue.Checked Then
                ''        DrawChartForLINEA()
                ''    ElseIf rbdChartthisMonthValue.Checked Then
                ''        DrawChartForLINEA()
                ''    End If
                ''    '===========================
                ''ElseIf rbdChartLineB.Checked Then
                ''    ' DrawChartForLINEB()
                ''    If rbdChartAvgValue.Checked Then
                ''        DrawChartForLINEB()
                ''    ElseIf rbdChartthisMonthValue.Checked Then
                ''        DrawChartForLINEB()
                ''    End If

                ''    ' DrawChartForLINEA_LINEB()
                ''    '=====================================
                ''ElseIf rbdChartLineA_LineB.Checked Then
                ''    '  DrawChartForLINEA_LINEB()
                ''    If rbdChartAvgValue.Checked Then
                ''        ' DrawChartForLINEA()
                ''        DrawChartForLINEA_LINEB()
                ''    ElseIf rbdChartthisMonthValue.Checked Then
                ''        DrawChartForLINEA_LINEB()
                ''    End If
                ''    '====================================
                ''End If
                '=========================================






                ''If rdbtnLineA.Checked = True Then
                ''    Session("checkboxval") = "A"

                ''    ' DrawChartTop()

                ''    getdataForGrid_LineA()
                ''    lblforgrid_indicator.Text = "Table Grid Show LineA Values"
                ''    ' lblforgriddatavalue.Text = "Abnormal LineA Roll Colling Water Tempreture"
                ''    If dt.Rows.Count > 0 Then
                ''        'txtHeatRecover1.Text = dt.Rows(0)("HEAT_RECOV1")
                ''        btnHeatRecover1.Text = dt.Rows(0)("HEAT_RECOV1") & "%"
                ''        'btnHeatRecoverySanky1.Text = dt.Rows(0)("HEAT_RECOV1") & "%"
                ''        'txtHeatRecover2.Text = dt.Rows(0)("HEAT_RECOV2")
                ''        btnHeatRecover2.Text = dt.Rows(0)("HEAT_RECOV2") & "%"
                ''        ' btnHeatRecoverySanky2.Text = dt.Rows(0)("HEAT_RECOV2") & "%"
                ''        'txtHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3")
                ''        btnHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3") & "%"
                ''        ' btnHeatRecoverySanky3.Text = dt.Rows(0)("HEAT_RECOV3") & "%"
                ''        'txtRecup1.Text = dt.Rows(0)("RECUP1_PERFORM")
                ''        btnRecup1.Text = dt.Rows(0)("RECUP1_PERFORM") & "%"
                ''        'btnrecupSanky1.Text = dt.Rows(0)("RECUP1_PERFORM") & "%"
                ''        'txtRecup2.Text = dt.Rows(0)("RECUP2_PERFORM")
                ''        btnRecup2.Text = dt.Rows(0)("RECUP2_PERFORM") & "%"
                ''        'btnrecupSanky2.Text = dt.Rows(0)("RECUP2_PERFORM") & "%"
                ''        'txtRecup3.Text = dt.Rows(0)("RECUP3_PERFORM")
                ''        btnRecup3.Text = dt.Rows(0)("RECUP3_PERFORM") & "%"
                ''        'btnrecupSanky3.Text = dt.Rows(0)("RECUP3_PERFORM") & "%"
                ''        'txtHeatInput.Text = dt.Rows(0)("HEAT_INPUT")
                ''        btnHeatInput.Text = dt.Rows(0)("HEAT_INPUT") & ""
                ''        'btnHeatInputSanky.Text = dt.Rows(0)("HEAT_INPUT") & ""
                ''        'txtThroughPut.Text = dt.Rows(0)("THROUGHPUT")


                ''        btnThroughPut.Text = dt.Rows(0)("THROUGHPUT")
                ''        'btnThroughPutSanky.Text = dt.Rows(0)("THROUGHPUT")
                ''        'txtStockEntryTemp.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
                ''        btnStockEntryTemp.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
                ''        'btnStockEbtryTempSanky.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
                ''        'txtStockExitTemp.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
                ''        btnStockExitTemp.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
                ''        'btnStockExitTempSanky.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
                ''        'txtCoolingWaterLoss.Text = dt.Rows(0)("COOL_WT_LOSS")
                ''        btnCoolingWaterLoss.Text = dt.Rows(0)("COOL_WT_LOSS")
                ''        'btnCoolingWaterLossSanky.Text = dt.Rows(0)("COOL_WT_LOSS")
                ''        btnCoolingWaterLossPerc.Text = dt.Rows(0)("COOL_WT_LOSS_PERC") & "%"
                ''        'btnCoolingWaterLossPercSanky.Text = dt.Rows(0)("COOL_WT_LOSS_PERC") & "%"
                ''        'txtFuelLoss.Text = dt.Rows(0)("FLUE_LOSS_PERC")

                ''        btnFuelLossPerc.Text = dt.Rows(0)("FLUE_LOSS_PERC") & "%"
                ''        'btnFuelLossPrecSanky.Text = dt.Rows(0)("FLUE_LOSS_PERC") & "%"
                ''        'txtHeatMaterial.Text = dt.Rows(0)("HEAT_MATERIAL")
                ''        btnHeatMaterial.Text = dt.Rows(0)("HEAT_MATERIAL")
                ''        'btnHeatMaterialSanky.Text = dt.Rows(0)("HEAT_MATERIAL")

                ''        btnHeatMaterialPerc.Text = dt.Rows(0)("HEAT_MAT_PERC") & "%"
                ''        'btnHeatMaterialpercSanky.Text = dt.Rows(0)("HEAT_MAT_PERC") & "%"
                ''        'txtOpenLoss.Text = dt.Rows(0)("OPEN_LOSS")
                ''        btnOpenLoss.Text = dt.Rows(0)("OPEN_LOSS")
                ''        ' btnOpenLossSanky.Text = dt.Rows(0)("OPEN_LOSS")
                ''        btnOpenLossPerc.Text = dt.Rows(0)("OPEN_LOSS_PERC") & "%"
                ''        'btnOpenLossPRECSanky.Text = dt.Rows(0)("OPEN_LOSS_PERC") & "%"
                ''        'txtWallRoofLoss.Text = dt.Rows(0)("SKIN_LOSS_PERC")

                ''        btnWallRoofLossPerc.Text = dt.Rows(0)("SKIN_LOSS_PERC") & "%"
                ''        'btnWallRoofLossPrecSanky.Text = dt.Rows(0)("SKIN_LOSS_PERC") & "%"
                ''        'txtAirFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_CAL")
                ''        '  btnAirFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_ONLINE") '("TOTAL_AIR_FLOW_CAL")
                ''        btnAirFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_ONLINE") '("TOTAL_AIR_FLOW_CAL")

                ''        'btnAirFlowSanky.Text = dt.Rows(0)("TOTAL_GAS_FLOW_ONLINE") '("TOTAL_AIR_FLOW_CAL")
                ''        'txtGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_CAL")
                ''        ' btnGasFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_ONLINE") '("TOTAL_GAS_FLOW_CAL")
                ''        btnGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_ONLINE") '("TOTAL_GAS_FLOW_CAL")

                ''        'btnGasFlowSanky.Text = dt.Rows(0)("TOTAL_AIR_FLOW_ONLINE") '("TOTAL_GAS_FLOW_CAL")
                ''        'txtCV.Text = dt.Rows(0)("CV")
                ''        'btnCV.Text = dt.Rows(0)("CV")
                ''        btnWobee.Text = dt.Rows(0)("CV")
                ''        'btnCvSanky.Text = dt.Rows(0)("CV")


                ''    Else



                ''        'txtHeatRecover1.Text = dt.Rows(0)("HEAT_RECOV1")
                ''        btnHeatRecover1.Text = ""
                ''        'btnHeatRecoverySanky1.Text = ""
                ''        'txtHeatRecover2.Text = dt.Rows(0)("HEAT_RECOV2")
                ''        btnHeatRecover2.Text = ""
                ''        'btnHeatRecoverySanky2.Text = ""
                ''        'txtHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3")
                ''        btnHeatRecover3.Text = ""
                ''        'btnHeatRecoverySanky3.Text = ""
                ''        'txtRecup1.Text = dt.Rows(0)("RECUP1_PERFORM")
                ''        btnRecup1.Text = ""
                ''        'btnrecupSanky1.Text = ""
                ''        'txtRecup2.Text = dt.Rows(0)("RECUP2_PERFORM")
                ''        btnRecup2.Text = ""
                ''        'btnrecupSanky2.Text = ""
                ''        'txtRecup3.Text = dt.Rows(0)("RECUP3_PERFORM")
                ''        btnRecup3.Text = ""
                ''        'btnrecupSanky3.Text = ""
                ''        'txtHeatInput.Text = dt.Rows(0)("HEAT_INPUT")
                ''        btnHeatInput.Text = ""
                ''        'btnHeatInputSanky.Text = ""
                ''        'txtThroughPut.Text = dt.Rows(0)("THROUGHPUT")


                ''        btnThroughPut.Text = ""
                ''        'btnThroughPutSanky.Text = ""
                ''        'txtStockEntryTemp.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
                ''        btnStockEntryTemp.Text = ""
                ''        'btnStockEbtryTempSanky.Text = ""
                ''        'txtStockExitTemp.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
                ''        btnStockExitTemp.Text = ""
                ''        'btnStockExitTempSanky.Text = ""
                ''        'txtCoolingWaterLoss.Text = dt.Rows(0)("COOL_WT_LOSS")
                ''        btnCoolingWaterLoss.Text = ""
                ''        ' btnCoolingWaterLossSanky.Text = ""
                ''        btnCoolingWaterLossPerc.Text = ""
                ''        ' btnCoolingWaterLossPercSanky.Text = ""
                ''        'txtFuelLoss.Text = dt.Rows(0)("FLUE_LOSS_PERC")

                ''        btnFuelLossPerc.Text = ""
                ''        'btnFuelLossPrecSanky.Text = ""
                ''        'txtHeatMaterial.Text = dt.Rows(0)("HEAT_MATERIAL")
                ''        btnHeatMaterial.Text = ""
                ''        'btnHeatMaterialSanky.Text = ""
                ''        btnHeatMaterialPerc.Text = ""
                ''        'btnHeatMaterialpercSanky.Text = ""
                ''        'txtOpenLoss.Text = dt.Rows(0)("OPEN_LOSS")
                ''        btnOpenLoss.Text = ""
                ''        'btnOpenLossSanky.Text = ""
                ''        btnOpenLossPerc.Text = ""
                ''        'btnOpenLossPRECSanky.Text = ""
                ''        'txtWallRoofLoss.Text = dt.Rows(0)("SKIN_LOSS_PERC")

                ''        btnWallRoofLossPerc.Text = ""
                ''        'btnWallRoofLossPrecSanky.Text = ""
                ''        'txtAirFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_CAL")
                ''        btnAirFlow.Text = ""
                ''        'btnAirFlowSanky.Text = ""
                ''        'txtGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_CAL")
                ''        btnGasFlow.Text = ""
                ''        'btnGasFlowSanky.Text = ""
                ''        'txtCV.Text = dt.Rows(0)("CV")
                ''        'btnCV.Text = ""
                ''        btnWobee.Text = ""
                ''        'btnCvSanky.Text = ""
                ''    End If


                ''    'Dim dtlabel As DataTable = objController.populatelabelValue()

                ''    ''If rbdTimeStamp.Checked Then

                ''    ''    If dtlabel.Rows.Count > 0 Then

                ''    ''        BaseValueOnline.Text = dtlabel.Rows(0)("TOTAL_AIR_FUEL_RATIO")
                ''    ''        BaseValueRecommended.Text = dtlabel.Rows(0)("BASE_VALUE_RECOM")
                ''    ''        '=================================================
                ''    ''        '   HeatInputOnline.Text = dtlabel.Rows(0)("HEAT_INPUT")
                ''    ''        HeatInputCalculated.Text = dtlabel.Rows(0)("HEAT_INPUT")
                ''    ''        HeatInputRecommended.Text = dtlabel.Rows(0)("HEAT_INPUT_RECOM")
                ''    ''        '====================================================
                ''    ''        SpecificationOnline.Text = dtlabel.Rows(0)("SPC_FUEL_CON_ONLINE") '& AvgData

                ''    ''        SpecificationCalculated.Text = dtlabel.Rows(0)("SPC_FUEL_CON_CAL")
                ''    ''        SpecificationRecommended.Text = dtlabel.Rows(0)("SPEC_FUEL_CON_RECOM")
                ''    ''        '====================================================
                ''    ''        TotalGasFlowOnline.Text = dtlabel.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
                ''    ''        TotalGasFlowCalculated.Text = dtlabel.Rows(0)("TOTAL_GAS_FLOW_CAL")
                ''    ''        TotalGasFlowRecommended.Text = dtlabel.Rows(0)("TOTAL_GAS_FLOW_RECOM")
                ''    ''        '========================================================
                ''    ''        TotalAirFlowOnline.Text = dtlabel.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
                ''    ''        TotalAirFlowCalculated.Text = dtlabel.Rows(0)("TOTAL_AIR_FLOW_CAL")
                ''    ''        TotalAirFlowRecommended.Text = dtlabel.Rows(0)("TOTAL_AIR_FLOW_RECOM")
                ''    ''    Else
                ''    ''        BaseValueOnline.Text = ""
                ''    ''        BaseValueRecommended.Text = ""
                ''    ''        '=================================================
                ''    ''        '   HeatInputOnline.Text = dtlabel.Rows(0)("HEAT_INPUT")
                ''    ''        HeatInputCalculated.Text = ""
                ''    ''        HeatInputRecommended.Text = ""
                ''    ''        '====================================================
                ''    ''        SpecificationOnline.Text = ""
                ''    ''        SpecificationCalculated.Text = ""
                ''    ''        SpecificationRecommended.Text = ""
                ''    ''        '====================================================
                ''    ''        TotalGasFlowOnline.Text = ""
                ''    ''        TotalGasFlowCalculated.Text = ""
                ''    ''        TotalGasFlowRecommended.Text = ""
                ''    ''        '========================================================
                ''    ''        TotalAirFlowOnline.Text = ""
                ''    ''        TotalAirFlowCalculated.Text = ""
                ''    ''        TotalAirFlowRecommended.Text = ""
                ''    ''    End If
                ''    ''End If


                ''    ''If rbdAVG.Checked Then
                ''    ''    '  dtlabelavg = objController.populatelabelValueForAvg(frmDate, toDate)
                ''    ''    If dtlabelavg.Rows.Count > 0 Then

                ''    ''        BaseValueOnline.Text = dtlabelavg.Rows(0)("TOTAL_AIR_FUEL_RATIO")
                ''    ''        BaseValueRecommended.Text = dtlabelavg.Rows(0)("BASE_VALUE_RECOM")
                ''    ''        '=================================================
                ''    ''        '   HeatInputOnline.Text = dtlabelavg.Rows(0)("HEAT_INPUT")
                ''    ''        HeatInputCalculated.Text = dtlabelavg.Rows(0)("HEAT_INPUT")
                ''    ''        HeatInputRecommended.Text = dtlabelavg.Rows(0)("HEAT_INPUT_RECOM")
                ''    ''        '====================================================
                ''    ''        SpecificationOnline.Text = dtlabelavg.Rows(0)("SPC_FUEL_CON_ONLINE") '& AvgData

                ''    ''        SpecificationCalculated.Text = dtlabelavg.Rows(0)("SPC_FUEL_CON_CAL")
                ''    ''        SpecificationRecommended.Text = dtlabelavg.Rows(0)("SPEC_FUEL_CON_RECOM")
                ''    ''        '====================================================
                ''    ''        TotalGasFlowOnline.Text = dtlabelavg.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
                ''    ''        TotalGasFlowCalculated.Text = dtlabelavg.Rows(0)("TOTAL_GAS_FLOW_CAL")
                ''    ''        TotalGasFlowRecommended.Text = dtlabelavg.Rows(0)("TOTAL_GAS_FLOW_RECOM")
                ''    ''        '========================================================
                ''    ''        TotalAirFlowOnline.Text = dtlabelavg.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
                ''    ''        TotalAirFlowCalculated.Text = dtlabelavg.Rows(0)("TOTAL_AIR_FLOW_CAL")
                ''    ''        TotalAirFlowRecommended.Text = dtlabelavg.Rows(0)("TOTAL_AIR_FLOW_RECOM")
                ''    ''    Else
                ''    ''        BaseValueOnline.Text = ""
                ''    ''        BaseValueRecommended.Text = ""
                ''    ''        '=================================================
                ''    ''        '   HeatInputOnline.Text = dtlabel.Rows(0)("HEAT_INPUT")
                ''    ''        HeatInputCalculated.Text = ""
                ''    ''        HeatInputRecommended.Text = ""
                ''    ''        '====================================================
                ''    ''        SpecificationOnline.Text = ""
                ''    ''        SpecificationCalculated.Text = ""
                ''    ''        SpecificationRecommended.Text = ""
                ''    ''        '====================================================
                ''    ''        TotalGasFlowOnline.Text = ""
                ''    ''        TotalGasFlowCalculated.Text = ""
                ''    ''        TotalGasFlowRecommended.Text = ""
                ''    ''        '========================================================
                ''    ''        TotalAirFlowOnline.Text = ""
                ''    ''        TotalAirFlowCalculated.Text = ""
                ''    ''        TotalAirFlowRecommended.Text = ""
                ''    ''    End If


                ''    ''End If



                ''End If
                ''Code Started Tirthankar 12-Jun-23
                ''=========================================================== New Code Start ==================================================================
                If rdbtnLineA.Checked = True Then
                    'Session("checkboxval") = "A"
                    Session("checkboxval") = "1"
                    ' DrawChartTop()

                    getdataForGrid_LineA()
                    ''lblforgrid_indicator.Text = "Table Grid Show LineA Values"
                    ' lblforgriddatavalue.Text = "Abnormal LineA Roll Colling Water Tempreture"
                    If dtGcFur1.Rows.Count > 0 Then


                        btnHeatRecover1.Text = dtGcFur1.Rows(0)("HEAT_RECOV_PERC") & " %"

                        btnHeatRecovPerFluExit.Text = dtGcFur1.Rows(0)("HEAT_RECOV_PERC_FLUE_EXIT") & " %"
                        'btnHeatRecover2.Text = ""

                        'btnHeatRecover3.Text = ""

                        ''New Code Added

                        If Convert.ToDecimal(dtGcFur1.Rows(0)("RECUP_PERF")) >= 100 Then
                            btnRecup1.Text = "100 %"
                        Else
                            btnRecup1.Text = dtGcFur1.Rows(0)("RECUP_PERF") & " %"
                        End If

                        Dim dtRecup85checkFir1 As DataTable = objController.PopuDataForRecup85HigherFur1()

                        Dim checkBelow85 As Integer = 0
                        Dim chkdtrow As Integer = dtRecup85checkFir1.Rows.Count

                        For i = 0 To dtRecup85checkFir1.Rows.Count - 1
                            If dtRecup85checkFir1.Rows(i)(1) < 85 Then
                                checkBelow85 += 1
                            End If
                        Next
                        If checkBelow85 = chkdtrow Then
                            btnRecup1.CssClass &= " blink"
                        Else
                            btnRecup1.CssClass = "btn btn-outline-secondary"
                        End If


                        'btnRecup2.Text = ""

                        'btnRecup3.Text = ""

                        btnHeatInput.Text = dtGcFur1.Rows(0)("HEAT_INPUT")

                        btnCoolingWaterLoss.Text = dtGcFur1.Rows(0)("COOL_WAT_LOSS")

                        btnCoolingWaterLossPerc.Text = dtGcFur1.Rows(0)("COOL_WAT_LOSS_PERC") & " %"

                        btnFuelLossPerc.Text = dtGcFur1.Rows(0)("FLUE_LOSS_PERC") & " %"

                        btnFlueLoss.Text = dtGcFur1.Rows(0)("FLUE_LOSS")

                        btnHeatMaterialPerc.Text = dtGcFur1.Rows(0)("HEAT_MATE_PERC") & " %"

                        btnOpenLoss.Text = dtGcFur1.Rows(0)("OPEN_LOSS")

                        btnOpenLossPerc.Text = dtGcFur1.Rows(0)("OPEN_LOSS_PERC") & " %"

                        'btnWallRoofLoss.Text = ""

                        btnWallRoofLossPerc.Text = dtGcFur1.Rows(0)("SKIN_LOSS_PERC") & " %"


                        'btnAirFlow.Text = dtGcFur1.Rows(0)("TOTAL_AIR_FLOW") * 1000
                        btnAirFlow.Text = dtGcFur1.Rows(0)("TOTAL_AIR_FLOW_ONLINE")

                        ''FUEL_PHUP,FUEL_PHLO,FUEL_HUP,FUEL_HLO,FUEL_PSUP,FUEL_PSLO,FUEL_SRUP,FUEL_SLUP,FUEL_SRLO,FUEL_SLLO,FUEL_REST,FUEL_PRESSURE
                        ''GAS_OP1,GAS_OP2,GAS_OP3,GAS_OP4,GAS_OP5,GAS_OP6,GAS_OP7,GAS_OP8,GAS_OP9,GAS_OP10
                        'Dim totGas As Decimal = Convert.ToDecimal(dtGcFur1.Rows(0)("FUEL_PHUP")) + Convert.ToDecimal(dtGcFur1.Rows(0)("FUEL_PHLO")) + Convert.ToDecimal(dtGcFur1.Rows(0)("FUEL_HUP")) + Convert.ToDecimal(dtGcFur1.Rows(0)("FUEL_HLO")) + Convert.ToDecimal(dtGcFur1.Rows(0)("FUEL_PSUP")) + Convert.ToDecimal(dtGcFur1.Rows(0)("FUEL_PSLO")) + Convert.ToDecimal(dtGcFur1.Rows(0)("FUEL_SRUP")) + Convert.ToDecimal(dtGcFur1.Rows(0)("FUEL_SLUP")) + Convert.ToDecimal(dtGcFur1.Rows(0)("FUEL_SRLO")) + Convert.ToDecimal(dtGcFur1.Rows(0)("FUEL_SLLO"))

                        'btnGasFlow.Text = Int(totGas)
                        btnGasFlow.Text = dtGcFur1.Rows(0)("TOTAL_GAS_FLOW_ONLINE")

                        btnWobee.Text = dtGcFur1.Rows(0)("WOBBE")

                        'lblSpecificFur1.Text = dtGcFur1.Rows(0)("SPEC_FUEL_CON_ONLINE")

                        'textspcificFur1.Visible = True

                        'lblSpecificFur1.Visible = True

                        'textspcificFur2.Visible = False

                        'lblSpecificFur2.Visible = False

                    Else

                        btnHeatRecover1.Text = ""

                        btnHeatRecovPerFluExit.Text = ""
                        'btnHeatRecover2.Text = ""

                        'btnHeatRecover3.Text = ""

                        btnRecup1.Text = ""

                        'btnRecup2.Text = ""

                        'btnRecup3.Text = ""

                        btnHeatInput.Text = ""

                        'btnThroughPut.Text = ""

                        'btnStockEntryTemp.Text = ""

                        'btnStockExitTemp.Text = ""

                        btnCoolingWaterLoss.Text = ""

                        btnCoolingWaterLossPerc.Text = ""

                        btnFuelLossPerc.Text = ""

                        btnFlueLoss.Text = ""

                        'btnHeatMaterial.Text = ""

                        btnHeatMaterialPerc.Text = ""

                        btnOpenLoss.Text = ""

                        btnOpenLossPerc.Text = ""

                        btnWallRoofLossPerc.Text = ""

                        btnAirFlow.Text = ""

                        btnGasFlow.Text = ""

                        btnWobee.Text = ""

                        'lblSpecificFur1.Text = ""

                        'textspcificFur1.Visible = True

                        'lblSpecificFur1.Visible = True

                        'textspcificFur2.Visible = False

                        'lblSpecificFur2.Visible = False

                    End If



                    If dtGcFur1TPOH.Rows.Count > 0 Then

                        btnStockEntryTemp.Text = dtGcFur1TPOH.Rows(0)("SLAB_CHARG_TEMP")
                        btnStockExitTemp.Text = dtGcFur1TPOH.Rows(0)("SLAB_DISCHARG_TEMP")
                        btnThroughPut.Text = dtGcFur1TPOH.Rows(0)("TPOH")
                        btnHeatMaterial.Text = dtGcFur1TPOH.Rows(0)("HEAT_MATER")
                        btnWallRoofLoss.Text = dtGcFur1TPOH.Rows(0)("SKIN_LOSS")
                    Else
                        btnStockEntryTemp.Text = ""
                        btnStockExitTemp.Text = ""
                        btnThroughPut.Text = ""
                        btnHeatMaterial.Text = ""
                        btnWallRoofLoss.Text = ""
                    End If

                    Dim dtGcSpecFuel As DataTable

                    If rdbtnLineA.Checked Then
                        dtGcSpecFuel = objController.PopulateDataForSpecFuelCon("1")
                        If dtGcSpecFuel.Rows.Count > 0 Then
                            lblSpecificFur1.Text = dtGcSpecFuel.Rows(0)("CUM_SPEC_FUEL_CON") & " Gcal/T"
                            textspcificFur1.Visible = True
                            lblSpecificFur1.Visible = True
                            textspcificFur2.Visible = False
                            lblSpecificFur2.Visible = False
                        Else
                            lblSpecificFur1.Text = ""
                            textspcificFur1.Visible = True
                            lblSpecificFur1.Visible = True
                            textspcificFur2.Visible = False
                            lblSpecificFur2.Visible = False
                        End If
                    ElseIf rdbtnLineB.Checked Then
                        dtGcSpecFuel = objController.PopulateDataForSpecFuelCon("2")
                        If dtGcSpecFuel.Rows.Count > 0 Then
                            lblSpecificFur2.Text = dtGcSpecFuel.Rows(0)("CUM_SPEC_FUEL_CON") & " Gcal/T"
                            textspcificFur1.Visible = False
                            lblSpecificFur1.Visible = False
                            textspcificFur2.Visible = True
                            lblSpecificFur2.Visible = True
                        Else
                            lblSpecificFur2.Text = ""
                            textspcificFur1.Visible = False
                            lblSpecificFur1.Visible = False
                            textspcificFur2.Visible = True
                            lblSpecificFur2.Visible = True
                        End If
                    End If





                    'Dim dtlabel As DataTable = objController.populatelabelValue()

                    ''If rbdTimeStamp.Checked Then

                    ''    If dtlabel.Rows.Count > 0 Then

                    ''        BaseValueOnline.Text = dtlabel.Rows(0)("TOTAL_AIR_FUEL_RATIO")
                    ''        BaseValueRecommended.Text = dtlabel.Rows(0)("BASE_VALUE_RECOM")
                    ''        '=================================================
                    ''        '   HeatInputOnline.Text = dtlabel.Rows(0)("HEAT_INPUT")
                    ''        HeatInputCalculated.Text = dtlabel.Rows(0)("HEAT_INPUT")
                    ''        HeatInputRecommended.Text = dtlabel.Rows(0)("HEAT_INPUT_RECOM")
                    ''        '====================================================
                    ''        SpecificationOnline.Text = dtlabel.Rows(0)("SPC_FUEL_CON_ONLINE") '& AvgData

                    ''        SpecificationCalculated.Text = dtlabel.Rows(0)("SPC_FUEL_CON_CAL")
                    ''        SpecificationRecommended.Text = dtlabel.Rows(0)("SPEC_FUEL_CON_RECOM")
                    ''        '====================================================
                    ''        TotalGasFlowOnline.Text = dtlabel.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
                    ''        TotalGasFlowCalculated.Text = dtlabel.Rows(0)("TOTAL_GAS_FLOW_CAL")
                    ''        TotalGasFlowRecommended.Text = dtlabel.Rows(0)("TOTAL_GAS_FLOW_RECOM")
                    ''        '========================================================
                    ''        TotalAirFlowOnline.Text = dtlabel.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
                    ''        TotalAirFlowCalculated.Text = dtlabel.Rows(0)("TOTAL_AIR_FLOW_CAL")
                    ''        TotalAirFlowRecommended.Text = dtlabel.Rows(0)("TOTAL_AIR_FLOW_RECOM")
                    ''    Else
                    ''        BaseValueOnline.Text = ""
                    ''        BaseValueRecommended.Text = ""
                    ''        '=================================================
                    ''        '   HeatInputOnline.Text = dtlabel.Rows(0)("HEAT_INPUT")
                    ''        HeatInputCalculated.Text = ""
                    ''        HeatInputRecommended.Text = ""
                    ''        '====================================================
                    ''        SpecificationOnline.Text = ""
                    ''        SpecificationCalculated.Text = ""
                    ''        SpecificationRecommended.Text = ""
                    ''        '====================================================
                    ''        TotalGasFlowOnline.Text = ""
                    ''        TotalGasFlowCalculated.Text = ""
                    ''        TotalGasFlowRecommended.Text = ""
                    ''        '========================================================
                    ''        TotalAirFlowOnline.Text = ""
                    ''        TotalAirFlowCalculated.Text = ""
                    ''        TotalAirFlowRecommended.Text = ""
                    ''    End If
                    ''End If


                    ''If rbdAVG.Checked Then
                    ''    '  dtlabelavg = objController.populatelabelValueForAvg(frmDate, toDate)
                    ''    If dtlabelavg.Rows.Count > 0 Then

                    ''        BaseValueOnline.Text = dtlabelavg.Rows(0)("TOTAL_AIR_FUEL_RATIO")
                    ''        BaseValueRecommended.Text = dtlabelavg.Rows(0)("BASE_VALUE_RECOM")
                    ''        '=================================================
                    ''        '   HeatInputOnline.Text = dtlabelavg.Rows(0)("HEAT_INPUT")
                    ''        HeatInputCalculated.Text = dtlabelavg.Rows(0)("HEAT_INPUT")
                    ''        HeatInputRecommended.Text = dtlabelavg.Rows(0)("HEAT_INPUT_RECOM")
                    ''        '====================================================
                    ''        SpecificationOnline.Text = dtlabelavg.Rows(0)("SPC_FUEL_CON_ONLINE") '& AvgData

                    ''        SpecificationCalculated.Text = dtlabelavg.Rows(0)("SPC_FUEL_CON_CAL")
                    ''        SpecificationRecommended.Text = dtlabelavg.Rows(0)("SPEC_FUEL_CON_RECOM")
                    ''        '====================================================
                    ''        TotalGasFlowOnline.Text = dtlabelavg.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
                    ''        TotalGasFlowCalculated.Text = dtlabelavg.Rows(0)("TOTAL_GAS_FLOW_CAL")
                    ''        TotalGasFlowRecommended.Text = dtlabelavg.Rows(0)("TOTAL_GAS_FLOW_RECOM")
                    ''        '========================================================
                    ''        TotalAirFlowOnline.Text = dtlabelavg.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
                    ''        TotalAirFlowCalculated.Text = dtlabelavg.Rows(0)("TOTAL_AIR_FLOW_CAL")
                    ''        TotalAirFlowRecommended.Text = dtlabelavg.Rows(0)("TOTAL_AIR_FLOW_RECOM")
                    ''    Else
                    ''        BaseValueOnline.Text = ""
                    ''        BaseValueRecommended.Text = ""
                    ''        '=================================================
                    ''        '   HeatInputOnline.Text = dtlabel.Rows(0)("HEAT_INPUT")
                    ''        HeatInputCalculated.Text = ""
                    ''        HeatInputRecommended.Text = ""
                    ''        '====================================================
                    ''        SpecificationOnline.Text = ""
                    ''        SpecificationCalculated.Text = ""
                    ''        SpecificationRecommended.Text = ""
                    ''        '====================================================
                    ''        TotalGasFlowOnline.Text = ""
                    ''        TotalGasFlowCalculated.Text = ""
                    ''        TotalGasFlowRecommended.Text = ""
                    ''        '========================================================
                    ''        TotalAirFlowOnline.Text = ""
                    ''        TotalAirFlowCalculated.Text = ""
                    ''        TotalAirFlowRecommended.Text = ""
                    ''    End If


                    ''End If



                End If

                If rdbtnLineB.Checked = True Then


                    'Session("checkboxval") = "B"
                    Session("checkboxval") = "2"

                    getdataForGrid_LineB()
                    '   DrawChartTop()
                    'lblforgrid_indicator.Text = "Table Grid Show LineB Values"
                    ' lblforgriddatavalue.Text = "Abnormal LineB Roll Colling Water Tempreture"
                    If dtGcFur2.Rows.Count > 0 Then

                        btnHeatRecover1.Text = dtGcFur2.Rows(0)("HEAT_RECOV_PERC") & " %"

                        btnHeatRecovPerFluExit.Text = dtGcFur2.Rows(0)("HEAT_RECOV_PERC_FLUE_EXIT") & " %"
                        'btnHeatRecover2.Text = ""

                        'btnHeatRecover3.Text = ""

                        ''New Code Added

                        If Convert.ToDecimal(dtGcFur2.Rows(0)("RECUP_PERF")) >= 100 Then
                            btnRecup1.Text = "100 %"
                        Else
                            btnRecup1.Text = dtGcFur2.Rows(0)("RECUP_PERF") & " %"
                        End If

                        Dim dtRecup85checkFir2 As DataTable = objController.PopuDataForRecup85HigherFur2()


                        Dim checkBelow85 As Integer = 0
                        Dim chkdtrow As Integer = dtRecup85checkFir2.Rows.Count

                        For i = 0 To dtRecup85checkFir2.Rows.Count - 1
                            If dtRecup85checkFir2.Rows(i)(1) < 85 Then
                                checkBelow85 += 1
                            End If
                        Next
                        If checkBelow85 = chkdtrow Then
                            btnRecup1.CssClass &= " blink"
                        Else
                            btnRecup1.CssClass = "btn btn-outline-secondary"
                        End If

                        'btnRecup1.Text = dtGcFur2.Rows(0)("RECUP_PERF") & " %"

                        'btnRecup2.Text = ""

                        'btnRecup3.Text = ""

                        btnHeatInput.Text = dtGcFur2.Rows(0)("HEAT_INPUT")

                        btnThroughPut.Text = ""

                        btnStockEntryTemp.Text = ""

                        btnStockExitTemp.Text = ""

                        btnCoolingWaterLoss.Text = dtGcFur2.Rows(0)("COOL_WAT_LOSS")

                        btnCoolingWaterLossPerc.Text = dtGcFur2.Rows(0)("COOL_WAT_LOSS_PERC") & " %"

                        btnFuelLossPerc.Text = dtGcFur2.Rows(0)("FLUE_LOSS_PERC") & " %"

                        btnFlueLoss.Text = dtGcFur2.Rows(0)("FLUE_LOSS")

                        btnHeatMaterialPerc.Text = dtGcFur2.Rows(0)("HEAT_MATE_PERC") & " %"

                        btnOpenLoss.Text = dtGcFur2.Rows(0)("OPEN_LOSS")

                        btnOpenLossPerc.Text = dtGcFur2.Rows(0)("OPEN_LOSS_PERC") & " %"

                        'btnWallRoofLoss.Text = ""

                        btnWallRoofLossPerc.Text = dtGcFur2.Rows(0)("SKIN_LOSS_PERC") & " %"

                        btnAirFlow.Text = dtGcFur2.Rows(0)("TOTAL_AIR_FLOW_ONLINE")

                        btnGasFlow.Text = dtGcFur2.Rows(0)("TOTAL_GAS_FLOW_ONLINE")

                        btnWobee.Text = dtGcFur2.Rows(0)("WOBBE")

                        'lblSpecificFur2.Text = dtGcFur2.Rows(0)("SPEC_FUEL_CON_ONLINE")

                        'textspcificFur2.Visible = True

                        'lblSpecificFur2.Visible = True

                        'textspcificFur1.Visible = False

                        'lblSpecificFur1.Visible = False

                    Else

                        btnHeatRecover1.Text = ""

                        btnHeatRecovPerFluExit.Text = ""
                        'btnHeatRecover2.Text = ""

                        'btnHeatRecover3.Text = ""

                        btnRecup1.Text = ""

                        'btnRecup2.Text = ""

                        'btnRecup3.Text = ""

                        btnHeatInput.Text = ""

                        btnThroughPut.Text = ""

                        btnStockEntryTemp.Text = ""

                        btnStockExitTemp.Text = ""

                        btnCoolingWaterLoss.Text = ""

                        btnCoolingWaterLossPerc.Text = ""

                        btnFuelLossPerc.Text = ""

                        btnFlueLoss.Text = ""

                        'btnHeatMaterial.Text = ""

                        btnHeatMaterialPerc.Text = ""

                        btnOpenLoss.Text = ""

                        btnOpenLossPerc.Text = ""

                        'btnWallRoofLoss.Text = ""

                        btnWallRoofLossPerc.Text = ""

                        btnAirFlow.Text = ""

                        btnGasFlow.Text = ""

                        btnWobee.Text = ""

                        'lblSpecificFur2.Text = ""

                        'textspcificFur2.Visible = True

                        'lblSpecificFur2.Visible = True

                        'textspcificFur1.Visible = False

                        'lblSpecificFur1.Visible = False

                    End If


                    If dtGcFur2TPOH.Rows.Count > 0 Then

                        btnStockEntryTemp.Text = dtGcFur2TPOH.Rows(0)("SLAB_CHARG_TEMP")
                        btnStockExitTemp.Text = dtGcFur2TPOH.Rows(0)("SLAB_DISCHARG_TEMP")
                        btnThroughPut.Text = dtGcFur2TPOH.Rows(0)("TPOH")
                        btnHeatMaterial.Text = dtGcFur2TPOH.Rows(0)("HEAT_MATER")
                        btnWallRoofLoss.Text = dtGcFur2TPOH.Rows(0)("SKIN_LOSS")
                    Else
                        btnStockEntryTemp.Text = ""
                        btnStockExitTemp.Text = ""
                        btnThroughPut.Text = ""
                        btnHeatMaterial.Text = ""
                        btnWallRoofLoss.Text = ""
                    End If

                    Dim dtGcSpecFuelLineB As DataTable

                    If rdbtnLineA.Checked Then
                        dtGcSpecFuelLineB = objController.PopulateDataForSpecFuelCon("1")
                        If dtGcSpecFuelLineB.Rows.Count > 0 Then
                            lblSpecificFur1.Text = dtGcSpecFuelLineB.Rows(0)("CUM_SPEC_FUEL_CON") & " Gcal/T"
                            textspcificFur1.Visible = True
                            lblSpecificFur1.Visible = True
                            textspcificFur2.Visible = False
                            lblSpecificFur2.Visible = False
                        Else
                            lblSpecificFur1.Text = ""
                            textspcificFur1.Visible = True
                            lblSpecificFur1.Visible = True
                            textspcificFur2.Visible = False
                            lblSpecificFur2.Visible = False
                        End If
                    ElseIf rdbtnLineB.Checked Then
                        dtGcSpecFuelLineB = objController.PopulateDataForSpecFuelCon("2")
                        If dtGcSpecFuelLineB.Rows.Count > 0 Then
                            lblSpecificFur2.Text = dtGcSpecFuelLineB.Rows(0)("CUM_SPEC_FUEL_CON") & " Gcal/T"
                            textspcificFur1.Visible = False
                            lblSpecificFur1.Visible = False
                            textspcificFur2.Visible = True
                            lblSpecificFur2.Visible = True
                        Else
                            lblSpecificFur2.Text = ""
                            textspcificFur1.Visible = False
                            lblSpecificFur1.Visible = False
                            textspcificFur2.Visible = True
                            lblSpecificFur2.Visible = True
                        End If
                    End If
                    'Dim dtlabel As DataTable = objController.populatelabelValue()

                    ''If rbdTimeStamp.Checked Then
                    ''    If dtlabelLineB.Rows.Count > 0 Then


                    ''        BaseValueOnline.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FUEL_RATIO")
                    ''        BaseValueRecommended.Text = dtlabelLineB.Rows(0)("BASE_VALUE_RECOM")
                    ''        '=================================================
                    ''        '   HeatInputOnline.Text = dtlabelLineB.Rows(0)("HEAT_INPUT")
                    ''        HeatInputCalculated.Text = dtlabelLineB.Rows(0)("HEAT_INPUT")
                    ''        HeatInputRecommended.Text = dtlabelLineB.Rows(0)("HEAT_INPUT_RECOM")
                    ''        '====================================================
                    ''        SpecificationOnline.Text = dtlabelLineB.Rows(0)("SPC_FUEL_CON_ONLINE")
                    ''        SpecificationCalculated.Text = dtlabelLineB.Rows(0)("SPC_FUEL_CON_CAL")
                    ''        SpecificationRecommended.Text = dtlabelLineB.Rows(0)("SPEC_FUEL_CON_RECOM")
                    ''        '====================================================
                    ''        TotalGasFlowOnline.Text = dtlabelLineB.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
                    ''        TotalGasFlowCalculated.Text = dtlabelLineB.Rows(0)("TOTAL_GAS_FLOW_CAL")
                    ''        TotalGasFlowRecommended.Text = dtlabelLineB.Rows(0)("TOTAL_GAS_FLOW_RECOM")
                    ''        '========================================================
                    ''        TotalAirFlowOnline.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
                    ''        TotalAirFlowCalculated.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FLOW_CAL")
                    ''        TotalAirFlowRecommended.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FLOW_RECOM")

                    ''    Else
                    ''        BaseValueOnline.Text = ""
                    ''        BaseValueRecommended.Text = ""
                    ''        '=================================================
                    ''        '   HeatInputOnline.Text = dtlabelLineB.Rows(0)("HEAT_INPUT")
                    ''        HeatInputCalculated.Text = ""
                    ''        HeatInputRecommended.Text = ""
                    ''        '====================================================
                    ''        SpecificationOnline.Text = ""
                    ''        SpecificationCalculated.Text = ""
                    ''        SpecificationRecommended.Text = ""
                    ''        '====================================================
                    ''        TotalGasFlowOnline.Text = ""
                    ''        TotalGasFlowCalculated.Text = ""
                    ''        TotalGasFlowRecommended.Text = ""
                    ''        '========================================================
                    ''        TotalAirFlowOnline.Text = ""
                    ''        TotalAirFlowCalculated.Text = ""
                    ''        TotalAirFlowRecommended.Text = ""

                    ''    End If




                    ''End If
                    ''If rbdAVG.Checked Then
                    ''    If dtavglineb.Rows.Count > 0 Then

                    ''        BaseValueOnline.Text = dtavglineb.Rows(0)("TOTAL_AIR_FUEL_RATIO")
                    ''        BaseValueRecommended.Text = dtavglineb.Rows(0)("BASE_VALUE_RECOM")
                    ''        '=================================================
                    ''        '   HeatInputOnline.Text = dtavglineb.Rows(0)("HEAT_INPUT")
                    ''        HeatInputCalculated.Text = dtavglineb.Rows(0)("HEAT_INPUT")
                    ''        HeatInputRecommended.Text = dtavglineb.Rows(0)("HEAT_INPUT_RECOM")
                    ''        '====================================================
                    ''        SpecificationOnline.Text = dtavglineb.Rows(0)("SPC_FUEL_CON_ONLINE") '& AvgData

                    ''        SpecificationCalculated.Text = dtavglineb.Rows(0)("SPC_FUEL_CON_CAL")
                    ''        SpecificationRecommended.Text = dtavglineb.Rows(0)("SPEC_FUEL_CON_RECOM")
                    ''        '====================================================
                    ''        TotalGasFlowOnline.Text = dtavglineb.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
                    ''        TotalGasFlowCalculated.Text = dtavglineb.Rows(0)("TOTAL_GAS_FLOW_CAL")
                    ''        TotalGasFlowRecommended.Text = dtavglineb.Rows(0)("TOTAL_GAS_FLOW_RECOM")
                    ''        '========================================================
                    ''        TotalAirFlowOnline.Text = dtavglineb.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
                    ''        TotalAirFlowCalculated.Text = dtavglineb.Rows(0)("TOTAL_AIR_FLOW_CAL")
                    ''        TotalAirFlowRecommended.Text = dtavglineb.Rows(0)("TOTAL_AIR_FLOW_RECOM")
                    ''    Else
                    ''        BaseValueOnline.Text = ""
                    ''        BaseValueRecommended.Text = ""
                    ''        '=================================================
                    ''        '   HeatInputOnline.Text = dtlabel.Rows(0)("HEAT_INPUT")
                    ''        HeatInputCalculated.Text = ""
                    ''        HeatInputRecommended.Text = ""
                    ''        '====================================================
                    ''        SpecificationOnline.Text = ""
                    ''        SpecificationCalculated.Text = ""
                    ''        SpecificationRecommended.Text = ""
                    ''        '====================================================
                    ''        TotalGasFlowOnline.Text = ""
                    ''        TotalGasFlowCalculated.Text = ""
                    ''        TotalGasFlowRecommended.Text = ""
                    ''        '========================================================
                    ''        TotalAirFlowOnline.Text = ""
                    ''        TotalAirFlowCalculated.Text = ""
                    ''        TotalAirFlowRecommended.Text = ""
                    ''    End If

                    ''End If
                End If

                ''=========================================================== New Code End ====================================================================
                ''If rdbtnLineB.Checked = True Then


                ''    Session("checkboxval") = "B"
                ''    getdataForGrid_LineB()
                ''    '   DrawChartTop()
                ''    lblforgrid_indicator.Text = "Table Grid Show LineB Values"
                ''    ' lblforgriddatavalue.Text = "Abnormal LineB Roll Colling Water Tempreture"
                ''    If dtlineB.Rows.Count > 0 Then
                ''        'txtHeatRecover1.Text = dtlineB.Rows(0)("HEAT_RECOV1")
                ''        btnHeatRecover1.Text = dtlineB.Rows(0)("HEAT_RECOV1") & "%"
                ''        'btnHeatRecoverySanky1.Text = dtlineB.Rows(0)("HEAT_RECOV1") & "%"
                ''        'txtHeatRecover2.Text = dtlineB.Rows(0)("HEAT_RECOV2")
                ''        btnHeatRecover2.Text = dtlineB.Rows(0)("HEAT_RECOV2") & "%"
                ''        'btnHeatRecoverySanky2.Text = dtlineB.Rows(0)("HEAT_RECOV2") & "%"
                ''        'txtHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3")
                ''        btnHeatRecover3.Text = dtlineB.Rows(0)("HEAT_RECOV3") & "%"
                ''        'btnHeatRecoverySanky3.Text = dtlineB.Rows(0)("HEAT_RECOV3") & "%"
                ''        'txtRecup1.Text = dtlineB.Rows(0)("RECUP1_PERFORM")
                ''        btnRecup1.Text = dtlineB.Rows(0)("RECUP1_PERFORM") & "%"
                ''        'btnrecupSanky1.Text = dtlineB.Rows(0)("RECUP1_PERFORM") & "%"
                ''        'txtRecup2.Text = dtlineB.Rows(0)("RECUP2_PERFORM")
                ''        btnRecup2.Text = dtlineB.Rows(0)("RECUP2_PERFORM") & "%"
                ''        'btnrecupSanky2.Text = dtlineB.Rows(0)("RECUP2_PERFORM") & "%"
                ''        'txtRecup3.Text = dtlineB.Rows(0)("RECUP3_PERFORM")
                ''        btnRecup3.Text = dtlineB.Rows(0)("RECUP3_PERFORM") & "%"
                ''        'btnrecupSanky3.Text = dtlineB.Rows(0)("RECUP3_PERFORM") & "%"
                ''        'txtHeatInput.Text = dtlineB.Rows(0)("HEAT_INPUT")
                ''        btnHeatInput.Text = dtlineB.Rows(0)("HEAT_INPUT") & ""
                ''        'btnHeatInputSanky.Text = dtlineB.Rows(0)("HEAT_INPUT") & ""
                ''        'txtThroughPut.Text = dtlineB.Rows(0)("THROUGHPUT")


                ''        btnThroughPut.Text = dtlineB.Rows(0)("THROUGHPUT")
                ''        'btnThroughPutSanky.Text = dtlineB.Rows(0)("THROUGHPUT")
                ''        'txtStockEntryTemp.Text = dtlineB.Rows(0)("STOCK_ENTRY_TEMP")
                ''        btnStockEntryTemp.Text = dtlineB.Rows(0)("STOCK_ENTRY_TEMP")
                ''        ' btnStockEbtryTempSanky.Text = dtlineB.Rows(0)("STOCK_ENTRY_TEMP")
                ''        'txtStockExitTemp.Text = dtlineB.Rows(0)("STOCK_EXIT_TEMP")
                ''        btnStockExitTemp.Text = dtlineB.Rows(0)("STOCK_EXIT_TEMP")
                ''        'btnStockExitTempSanky.Text = dtlineB.Rows(0)("STOCK_EXIT_TEMP")
                ''        'txtCoolingWaterLoss.Text = dtlineB.Rows(0)("COOL_WT_LOSS")
                ''        btnCoolingWaterLoss.Text = dtlineB.Rows(0)("COOL_WT_LOSS")
                ''        'btnCoolingWaterLossSanky.Text = dtlineB.Rows(0)("COOL_WT_LOSS")
                ''        btnCoolingWaterLossPerc.Text = dtlineB.Rows(0)("COOL_WT_LOSS_PERC") & "%"
                ''        'btnCoolingWaterLossPercSanky.Text = dtlineB.Rows(0)("COOL_WT_LOSS_PERC") & "%"
                ''        'txtFuelLoss.Text = dtlineB.Rows(0)("FLUE_LOSS_PERC")

                ''        btnFuelLossPerc.Text = dtlineB.Rows(0)("FLUE_LOSS_PERC") & "%"
                ''        'btnFuelLossPrecSanky.Text = dtlineB.Rows(0)("FLUE_LOSS_PERC") & "%"
                ''        'txtHeatMaterial.Text = dtlineB.Rows(0)("HEAT_MATERIAL")
                ''        btnHeatMaterial.Text = dtlineB.Rows(0)("HEAT_MATERIAL")
                ''        'btnHeatMaterialSanky.Text = dtlineB.Rows(0)("HEAT_MATERIAL")
                ''        btnHeatMaterialPerc.Text = dtlineB.Rows(0)("HEAT_MAT_PERC") & "%"
                ''        'btnHeatMaterialpercSanky.Text = dtlineB.Rows(0)("HEAT_MAT_PERC") & "%"
                ''        'txtOpenLoss.Text = dtlineB.Rows(0)("OPEN_LOSS")
                ''        btnOpenLoss.Text = dtlineB.Rows(0)("OPEN_LOSS")
                ''        'btnOpenLossSanky.Text = dtlineB.Rows(0)("OPEN_LOSS")
                ''        btnOpenLossPerc.Text = dtlineB.Rows(0)("OPEN_LOSS_PERC") & "%"
                ''        'btnOpenLossPRECSanky.Text = dtlineB.Rows(0)("OPEN_LOSS_PERC") & "%"
                ''        'txtWallRoofLoss.Text = dtlineB.Rows(0)("SKIN_LOSS_PERC")

                ''        btnWallRoofLossPerc.Text = dtlineB.Rows(0)("SKIN_LOSS_PERC") & "%"
                ''        'btnWallRoofLossPrecSanky.Text = dtlineB.Rows(0)("SKIN_LOSS_PERC") & "%"
                ''        'txtAirFlow.Text = dtlineB.Rows(0)("TOTAL_AIR_FLOW_CAL")
                ''        '  btnAirFlow.Text = dtlineB.Rows(0)("TOTAL_GAS_FLOW_ONLINE") '("TOTAL_AIR_FLOW_CAL")
                ''        btnAirFlow.Text = dtlineB.Rows(0)("TOTAL_AIR_FLOW_ONLINE") '("TOTAL_AIR_FLOW_CAL")

                ''        'btnAirFlowSanky.Text = dtlineB.Rows(0)("TOTAL_GAS_FLOW_ONLINE") '("TOTAL_AIR_FLOW_CAL")
                ''        'txtGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_CAL")
                ''        btnGasFlow.Text = dtlineB.Rows(0)("TOTAL_GAS_FLOW_ONLINE") '("TOTAL_GAS_FLOW_CAL")
                ''        ' btnGasFlow.Text = dtlineB.Rows(0)("TOTAL_AIR_FLOW_ONLINE") '("TOTAL_GAS_FLOW_CAL")

                ''        'btnGasFlowSanky.Text = dtlineB.Rows(0)("TOTAL_AIR_FLOW_ONLINE") '("TOTAL_GAS_FLOW_CAL")
                ''        'txtCV.Text = dtlineB.Rows(0)("CV")
                ''        'btnCV.Text = dtlineB.Rows(0)("CV")
                ''        btnWobee.Text = dtlineB.Rows(0)("CV")
                ''        'btnCvSanky.Text = dtlineB.Rows(0)("CV")
                ''    Else


                ''        'txtHeatRecover1.Text = dt.Rows(0)("HEAT_RECOV1")
                ''        btnHeatRecover1.Text = ""
                ''        'btnHeatRecoverySanky1.Text = ""
                ''        'txtHeatRecover2.Text = dt.Rows(0)("HEAT_RECOV2")
                ''        btnHeatRecover2.Text = ""
                ''        'btnHeatRecoverySanky2.Text = ""
                ''        'txtHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3")
                ''        btnHeatRecover3.Text = ""
                ''        'btnHeatRecoverySanky3.Text = ""
                ''        'txtRecup1.Text = dt.Rows(0)("RECUP1_PERFORM")
                ''        btnRecup1.Text = ""
                ''        'btnrecupSanky1.Text = ""
                ''        'txtRecup2.Text = dt.Rows(0)("RECUP2_PERFORM")
                ''        btnRecup2.Text = ""
                ''        'btnrecupSanky2.Text = ""
                ''        'txtRecup3.Text = dt.Rows(0)("RECUP3_PERFORM")
                ''        btnRecup3.Text = ""
                ''        'btnrecupSanky3.Text = ""
                ''        'txtHeatInput.Text = dt.Rows(0)("HEAT_INPUT")
                ''        btnHeatInput.Text = ""
                ''        'btnHeatInputSanky.Text = ""
                ''        'txtThroughPut.Text = dt.Rows(0)("THROUGHPUT")


                ''        btnThroughPut.Text = ""
                ''        'btnThroughPutSanky.Text = ""
                ''        'txtStockEntryTemp.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
                ''        btnStockEntryTemp.Text = ""
                ''        'btnStockEbtryTempSanky.Text = ""
                ''        'txtStockExitTemp.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
                ''        btnStockExitTemp.Text = ""
                ''        'btnStockExitTempSanky.Text = ""
                ''        'txtCoolingWaterLoss.Text = dt.Rows(0)("COOL_WT_LOSS")
                ''        btnCoolingWaterLoss.Text = ""
                ''        'btnCoolingWaterLossSanky.Text = ""
                ''        btnCoolingWaterLossPerc.Text = ""
                ''        'btnCoolingWaterLossPercSanky.Text = ""
                ''        'txtFuelLoss.Text = dt.Rows(0)("FLUE_LOSS_PERC")

                ''        btnFuelLossPerc.Text = ""
                ''        ' btnFuelLossPrecSanky.Text = ""
                ''        'txtHeatMaterial.Text = dt.Rows(0)("HEAT_MATERIAL")
                ''        btnHeatMaterial.Text = ""
                ''        'btnHeatMaterialSanky.Text = ""
                ''        btnHeatMaterialPerc.Text = ""
                ''        'btnHeatMaterialpercSanky.Text = ""
                ''        'txtOpenLoss.Text = dt.Rows(0)("OPEN_LOSS")
                ''        btnOpenLoss.Text = ""
                ''        'btnOpenLossSanky.Text = ""
                ''        btnOpenLossPerc.Text = ""
                ''        'btnOpenLossPRECSanky.Text = ""
                ''        'txtWallRoofLoss.Text = dt.Rows(0)("SKIN_LOSS_PERC")

                ''        btnWallRoofLossPerc.Text = ""
                ''        'btnWallRoofLossPrecSanky.Text = ""
                ''        'txtAirFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_CAL")
                ''        btnAirFlow.Text = ""
                ''        'btnAirFlowSanky.Text = ""
                ''        'txtGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_CAL")
                ''        btnGasFlow.Text = ""
                ''        'btnGasFlowSanky.Text = ""
                ''        'txtCV.Text = dt.Rows(0)("CV")
                ''        'btnCV.Text = ""
                ''        btnWobee.Text = ""
                ''        'btnCvSanky.Text = ""
                ''    End If
                ''    'Dim dtlabel As DataTable = objController.populatelabelValue()

                ''    ''If rbdTimeStamp.Checked Then
                ''    ''    If dtlabelLineB.Rows.Count > 0 Then


                ''    ''        BaseValueOnline.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FUEL_RATIO")
                ''    ''        BaseValueRecommended.Text = dtlabelLineB.Rows(0)("BASE_VALUE_RECOM")
                ''    ''        '=================================================
                ''    ''        '   HeatInputOnline.Text = dtlabelLineB.Rows(0)("HEAT_INPUT")
                ''    ''        HeatInputCalculated.Text = dtlabelLineB.Rows(0)("HEAT_INPUT")
                ''    ''        HeatInputRecommended.Text = dtlabelLineB.Rows(0)("HEAT_INPUT_RECOM")
                ''    ''        '====================================================
                ''    ''        SpecificationOnline.Text = dtlabelLineB.Rows(0)("SPC_FUEL_CON_ONLINE")
                ''    ''        SpecificationCalculated.Text = dtlabelLineB.Rows(0)("SPC_FUEL_CON_CAL")
                ''    ''        SpecificationRecommended.Text = dtlabelLineB.Rows(0)("SPEC_FUEL_CON_RECOM")
                ''    ''        '====================================================
                ''    ''        TotalGasFlowOnline.Text = dtlabelLineB.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
                ''    ''        TotalGasFlowCalculated.Text = dtlabelLineB.Rows(0)("TOTAL_GAS_FLOW_CAL")
                ''    ''        TotalGasFlowRecommended.Text = dtlabelLineB.Rows(0)("TOTAL_GAS_FLOW_RECOM")
                ''    ''        '========================================================
                ''    ''        TotalAirFlowOnline.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
                ''    ''        TotalAirFlowCalculated.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FLOW_CAL")
                ''    ''        TotalAirFlowRecommended.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FLOW_RECOM")

                ''    ''    Else
                ''    ''        BaseValueOnline.Text = ""
                ''    ''        BaseValueRecommended.Text = ""
                ''    ''        '=================================================
                ''    ''        '   HeatInputOnline.Text = dtlabelLineB.Rows(0)("HEAT_INPUT")
                ''    ''        HeatInputCalculated.Text = ""
                ''    ''        HeatInputRecommended.Text = ""
                ''    ''        '====================================================
                ''    ''        SpecificationOnline.Text = ""
                ''    ''        SpecificationCalculated.Text = ""
                ''    ''        SpecificationRecommended.Text = ""
                ''    ''        '====================================================
                ''    ''        TotalGasFlowOnline.Text = ""
                ''    ''        TotalGasFlowCalculated.Text = ""
                ''    ''        TotalGasFlowRecommended.Text = ""
                ''    ''        '========================================================
                ''    ''        TotalAirFlowOnline.Text = ""
                ''    ''        TotalAirFlowCalculated.Text = ""
                ''    ''        TotalAirFlowRecommended.Text = ""

                ''    ''    End If




                ''    ''End If
                ''    ''If rbdAVG.Checked Then
                ''    ''    If dtavglineb.Rows.Count > 0 Then

                ''    ''        BaseValueOnline.Text = dtavglineb.Rows(0)("TOTAL_AIR_FUEL_RATIO")
                ''    ''        BaseValueRecommended.Text = dtavglineb.Rows(0)("BASE_VALUE_RECOM")
                ''    ''        '=================================================
                ''    ''        '   HeatInputOnline.Text = dtavglineb.Rows(0)("HEAT_INPUT")
                ''    ''        HeatInputCalculated.Text = dtavglineb.Rows(0)("HEAT_INPUT")
                ''    ''        HeatInputRecommended.Text = dtavglineb.Rows(0)("HEAT_INPUT_RECOM")
                ''    ''        '====================================================
                ''    ''        SpecificationOnline.Text = dtavglineb.Rows(0)("SPC_FUEL_CON_ONLINE") '& AvgData

                ''    ''        SpecificationCalculated.Text = dtavglineb.Rows(0)("SPC_FUEL_CON_CAL")
                ''    ''        SpecificationRecommended.Text = dtavglineb.Rows(0)("SPEC_FUEL_CON_RECOM")
                ''    ''        '====================================================
                ''    ''        TotalGasFlowOnline.Text = dtavglineb.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
                ''    ''        TotalGasFlowCalculated.Text = dtavglineb.Rows(0)("TOTAL_GAS_FLOW_CAL")
                ''    ''        TotalGasFlowRecommended.Text = dtavglineb.Rows(0)("TOTAL_GAS_FLOW_RECOM")
                ''    ''        '========================================================
                ''    ''        TotalAirFlowOnline.Text = dtavglineb.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
                ''    ''        TotalAirFlowCalculated.Text = dtavglineb.Rows(0)("TOTAL_AIR_FLOW_CAL")
                ''    ''        TotalAirFlowRecommended.Text = dtavglineb.Rows(0)("TOTAL_AIR_FLOW_RECOM")
                ''    ''    Else
                ''    ''        BaseValueOnline.Text = ""
                ''    ''        BaseValueRecommended.Text = ""
                ''    ''        '=================================================
                ''    ''        '   HeatInputOnline.Text = dtlabel.Rows(0)("HEAT_INPUT")
                ''    ''        HeatInputCalculated.Text = ""
                ''    ''        HeatInputRecommended.Text = ""
                ''    ''        '====================================================
                ''    ''        SpecificationOnline.Text = ""
                ''    ''        SpecificationCalculated.Text = ""
                ''    ''        SpecificationRecommended.Text = ""
                ''    ''        '====================================================
                ''    ''        TotalGasFlowOnline.Text = ""
                ''    ''        TotalGasFlowCalculated.Text = ""
                ''    ''        TotalGasFlowRecommended.Text = ""
                ''    ''        '========================================================
                ''    ''        TotalAirFlowOnline.Text = ""
                ''    ''        TotalAirFlowCalculated.Text = ""
                ''    ''        TotalAirFlowRecommended.Text = ""
                ''    ''    End If

                ''    ''End If
                ''End If
                ''End Code Started Tirthankar 12-Jun-23
            Catch ex As Exception
                MsgBox(ex.ToString())
            End Try
        End If

        If Session("ActiveIndex") = 1 Then
            MultiView1.ActiveViewIndex = 1
        End If


    End Sub

    Public Sub rdbtnLineA_CheckedChanged(sender As Object, e As EventArgs) Handles rdbtnLineA.CheckedChanged
        Try
            'Dim dSdate As DataSet = objdatahandler.GetDataSetFromQuery("select max(datetime) as DATETIME FROM  [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]")
            'Dim dtdate As DataTable = dSdate.Tables(0)
            Dim dSdate As DataTable = objController.PopulateMaxDatetime()


            Dim dtdate As DataTable = dSdate

            Dim ddtdate As DateTime = dtdate.Rows(0)("DATETIME")
            Dim frmDate As String = ddtdate.ToString("yyyy-MM-dd HH:mm:ss")
            Dim toDate As String = ddtdate.AddHours(-1).ToString("yyyy-MM-dd HH:mm:ss")
            '======================LINEA--------------------------------------
            ''Code Commented/Added Below Tirthankar 12-Jun-23
            ''Dim dt As DataTable = objController.PopulateDataForHeatDistributionModel()
            Dim dtGcFur1 As DataTable = objController.PopulateDataForHSMFurnace1()
            Dim dtGcFur1TPOH As DataTable = objController.PopulateDataForHSMFurnace1TPOH()
            ''End Code Comment/Add Tirthankar 12-Jun-23
            Dim dtlabel As DataTable = objController.populatelabelValue()
            Dim dtlabelavg As DataTable = objController.populatelabelValueForAvg(frmDate, toDate)
            '=======
            ' Dim dtavg As DataTable = objController.PopulateAvgValuefromdt(frmDate, toDate)

            'Session("checkboxval") = "A"
            Session("checkboxval") = "1"
            '  DrawChartTop()
            'lblforgrid_indicator.Text = "Table Grid Show LineA Values"
            ' lblforgriddatavalue.Text = "Abnormal LineA Roll Colling Water Tempreture"
            getdataForGrid_LineA()
            ''Code Started Tirthankar 12-Jun-23
            If dtGcFur1.Rows.Count > 0 Then

                btnHeatRecover1.Text = dtGcFur1.Rows(0)("HEAT_RECOV_PERC") & " %"

                btnHeatRecovPerFluExit.Text = dtGcFur1.Rows(0)("HEAT_RECOV_PERC_FLUE_EXIT") & " %"
                'btnHeatRecover2.Text = ""

                'btnHeatRecover3.Text = ""

                ''New Code Added

                If Convert.ToDecimal(dtGcFur1.Rows(0)("RECUP_PERF")) >= 100 Then
                    btnRecup1.Text = "100 %"
                Else
                    btnRecup1.Text = dtGcFur1.Rows(0)("RECUP_PERF") & " %"
                End If

                Dim dtRecup85checkFir1 As DataTable = objController.PopuDataForRecup85HigherFur1()

                Dim checkBelow85 As Integer = 0
                Dim chkdtrow As Integer = dtRecup85checkFir1.Rows.Count

                For i = 0 To dtRecup85checkFir1.Rows.Count - 1
                    If dtRecup85checkFir1.Rows(i)(1) < 85 Then
                        checkBelow85 += 1
                    End If
                Next
                If checkBelow85 = chkdtrow Then
                    btnRecup1.CssClass &= " blink"
                Else
                    btnRecup1.CssClass = "btn btn-outline-secondary"
                End If

                'btnRecup1.Text = dtGcFur1.Rows(0)("RECUP_PERF") & " %"

                'btnRecup2.Text = ""

                'btnRecup3.Text = ""

                btnHeatInput.Text = dtGcFur1.Rows(0)("HEAT_INPUT")


                'btnThroughPut.Text = ""

                'btnStockEntryTemp.Text = ""

                'btnStockExitTemp.Text = ""

                btnCoolingWaterLoss.Text = dtGcFur1.Rows(0)("COOL_WAT_LOSS")

                btnCoolingWaterLossPerc.Text = dtGcFur1.Rows(0)("COOL_WAT_LOSS_PERC") & " %"

                btnFuelLossPerc.Text = dtGcFur1.Rows(0)("FLUE_LOSS_PERC") & " %"

                btnFlueLoss.Text = dtGcFur1.Rows(0)("FLUE_LOSS")

                'btnHeatMaterial.Text = ""

                btnHeatMaterialPerc.Text = dtGcFur1.Rows(0)("HEAT_MATE_PERC") & " %"

                btnOpenLoss.Text = dtGcFur1.Rows(0)("OPEN_LOSS")

                btnOpenLossPerc.Text = dtGcFur1.Rows(0)("OPEN_LOSS_PERC") & " %"

                'btnWallRoofLoss.Text = ""

                btnWallRoofLossPerc.Text = dtGcFur1.Rows(0)("SKIN_LOSS_PERC") & " %"

                'btnAirFlow.Text = dtGcFur1.Rows(0)("TOTAL_AIR_FLOW") * 1000
                btnAirFlow.Text = dtGcFur1.Rows(0)("TOTAL_AIR_FLOW_ONLINE")

                ''FUEL_PHUP,FUEL_PHLO,FUEL_HUP,FUEL_HLO,FUEL_PSUP,FUEL_PSLO,FUEL_SRUP,FUEL_SLUP,FUEL_SRLO,FUEL_SLLO,FUEL_REST,FUEL_PRESSURE
                ''GAS_OP1,GAS_OP2,GAS_OP3,GAS_OP4,GAS_OP5,GAS_OP6,GAS_OP7,GAS_OP8,GAS_OP9,GAS_OP10
                'Dim totGas As Decimal = Convert.ToDecimal(dtGcFur1.Rows(0)("FUEL_PHUP")) + Convert.ToDecimal(dtGcFur1.Rows(0)("FUEL_PHLO")) + Convert.ToDecimal(dtGcFur1.Rows(0)("FUEL_HUP")) + Convert.ToDecimal(dtGcFur1.Rows(0)("FUEL_HLO")) + Convert.ToDecimal(dtGcFur1.Rows(0)("FUEL_PSUP")) + Convert.ToDecimal(dtGcFur1.Rows(0)("FUEL_PSLO")) + Convert.ToDecimal(dtGcFur1.Rows(0)("FUEL_SRUP")) + Convert.ToDecimal(dtGcFur1.Rows(0)("FUEL_SLUP")) + Convert.ToDecimal(dtGcFur1.Rows(0)("FUEL_SRLO")) + Convert.ToDecimal(dtGcFur1.Rows(0)("FUEL_SLLO"))

                'btnGasFlow.Text = Int(totGas)
                btnGasFlow.Text = dtGcFur1.Rows(0)("TOTAL_GAS_FLOW_ONLINE")

                btnWobee.Text = dtGcFur1.Rows(0)("WOBBE")

                'lblSpecificFur1.Text = dtGcFur1.Rows(0)("SPEC_FUEL_CON_ONLINE")

                'textspcificFur1.Visible = True

                'lblSpecificFur1.Visible = True

                'textspcificFur2.Visible = False

                'lblSpecificFur2.Visible = False

            Else

                btnHeatRecover1.Text = ""

                btnHeatRecovPerFluExit.Text = ""
                'btnHeatRecover2.Text = ""

                'btnHeatRecover3.Text = ""

                btnRecup1.Text = ""

                'btnRecup2.Text = ""

                'btnRecup3.Text = ""

                btnHeatInput.Text = ""

                'btnThroughPut.Text = ""

                'btnStockEntryTemp.Text = ""

                'btnStockExitTemp.Text = ""

                btnCoolingWaterLoss.Text = ""

                btnCoolingWaterLossPerc.Text = ""

                btnFuelLossPerc.Text = ""

                btnFlueLoss.Text = ""

                'btnHeatMaterial.Text = ""

                btnHeatMaterialPerc.Text = ""

                btnOpenLoss.Text = ""

                btnOpenLossPerc.Text = ""

                'btnWallRoofLoss.Text = ""

                btnWallRoofLossPerc.Text = ""

                btnAirFlow.Text = ""

                btnGasFlow.Text = ""

                btnWobee.Text = ""

                'lblSpecificFur1.Text = ""

                'textspcificFur1.Visible = True

                'lblSpecificFur1.Visible = True

                'textspcificFur2.Visible = False

                'lblSpecificFur2.Visible = False

            End If

            If dtGcFur1TPOH.Rows.Count > 0 Then

                btnStockEntryTemp.Text = dtGcFur1TPOH.Rows(0)("SLAB_CHARG_TEMP")
                btnStockExitTemp.Text = dtGcFur1TPOH.Rows(0)("SLAB_DISCHARG_TEMP")
                btnThroughPut.Text = dtGcFur1TPOH.Rows(0)("TPOH")
                btnHeatMaterial.Text = dtGcFur1TPOH.Rows(0)("HEAT_MATER")
                btnWallRoofLoss.Text = dtGcFur1TPOH.Rows(0)("SKIN_LOSS")
            Else
                btnStockEntryTemp.Text = ""
                btnStockExitTemp.Text = ""
                btnThroughPut.Text = ""
                btnHeatMaterial.Text = ""
                btnWallRoofLoss.Text = ""
            End If

            Dim dtGcSpecFuel As DataTable

            dtGcSpecFuel = objController.PopulateDataForSpecFuelCon("1")

            If dtGcSpecFuel.Rows.Count > 0 Then
                lblSpecificFur1.Text = dtGcSpecFuel.Rows(0)("CUM_SPEC_FUEL_CON") & " Gcal/T"
                'lblGasUnavlbl.Visible = True
                textspcificFur1.Visible = True
                lblSpecificFur1.Visible = True
                textspcificFur2.Visible = False
                lblSpecificFur2.Visible = False
            Else
                lblSpecificFur1.Text = ""
                textspcificFur1.Visible = True
                lblSpecificFur1.Visible = True
                textspcificFur2.Visible = False
                lblSpecificFur2.Visible = False
            End If

            populateAirFuelRatio("1")
            DrawSpecFuelChart()

            'Dim dtlabel As DataTable = objController.populatelabelValue()

            '=============================================================
            ''If rbdTimeStamp.Checked Then

            ''    If dtlabel.Rows.Count > 0 Then

            ''        BaseValueOnline.Text = dtlabel.Rows(0)("TOTAL_AIR_FUEL_RATIO")
            ''        BaseValueRecommended.Text = dtlabel.Rows(0)("BASE_VALUE_RECOM")
            ''        '=================================================
            ''        '   HeatInputOnline.Text = dtlabel.Rows(0)("HEAT_INPUT")
            ''        HeatInputCalculated.Text = dtlabel.Rows(0)("HEAT_INPUT")
            ''        HeatInputRecommended.Text = dtlabel.Rows(0)("HEAT_INPUT_RECOM")
            ''        '====================================================
            ''        SpecificationOnline.Text = dtlabel.Rows(0)("SPC_FUEL_CON_ONLINE") '& AvgData

            ''        SpecificationCalculated.Text = dtlabel.Rows(0)("SPC_FUEL_CON_CAL")
            ''        SpecificationRecommended.Text = dtlabel.Rows(0)("SPEC_FUEL_CON_RECOM")
            ''        '====================================================
            ''        TotalGasFlowOnline.Text = dtlabel.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
            ''        TotalGasFlowCalculated.Text = dtlabel.Rows(0)("TOTAL_GAS_FLOW_CAL")
            ''        TotalGasFlowRecommended.Text = dtlabel.Rows(0)("TOTAL_GAS_FLOW_RECOM")
            ''        '========================================================
            ''        TotalAirFlowOnline.Text = dtlabel.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
            ''        TotalAirFlowCalculated.Text = dtlabel.Rows(0)("TOTAL_AIR_FLOW_CAL")
            ''        TotalAirFlowRecommended.Text = dtlabel.Rows(0)("TOTAL_AIR_FLOW_RECOM")
            ''    Else
            ''        BaseValueOnline.Text = ""
            ''        BaseValueRecommended.Text = ""
            ''        '=================================================
            ''        '   HeatInputOnline.Text = dtlabel.Rows(0)("HEAT_INPUT")
            ''        HeatInputCalculated.Text = ""
            ''        HeatInputRecommended.Text = ""
            ''        '====================================================
            ''        SpecificationOnline.Text = ""
            ''        SpecificationCalculated.Text = ""
            ''        SpecificationRecommended.Text = ""
            ''        '====================================================
            ''        TotalGasFlowOnline.Text = ""
            ''        TotalGasFlowCalculated.Text = ""
            ''        TotalGasFlowRecommended.Text = ""
            ''        '========================================================
            ''        TotalAirFlowOnline.Text = ""
            ''        TotalAirFlowCalculated.Text = ""
            ''        TotalAirFlowRecommended.Text = ""
            ''    End If



            ''    If rbdAVG.Checked Then
            ''        '  dtlabelavg = objController.populatelabelValueForAvg(frmDate, toDate)
            ''        If dtlabelavg.Rows.Count > 0 Then

            ''            BaseValueOnline.Text = dtlabelavg.Rows(0)("TOTAL_AIR_FUEL_RATIO")
            ''            BaseValueRecommended.Text = dtlabelavg.Rows(0)("BASE_VALUE_RECOM")
            ''            '=================================================
            ''            '   HeatInputOnline.Text = dtlabelavg.Rows(0)("HEAT_INPUT")
            ''            HeatInputCalculated.Text = dtlabelavg.Rows(0)("HEAT_INPUT")
            ''            HeatInputRecommended.Text = dtlabelavg.Rows(0)("HEAT_INPUT_RECOM")
            ''            '====================================================
            ''            SpecificationOnline.Text = dtlabelavg.Rows(0)("SPC_FUEL_CON_ONLINE") '& AvgData

            ''            SpecificationCalculated.Text = dtlabelavg.Rows(0)("SPC_FUEL_CON_CAL")
            ''            SpecificationRecommended.Text = dtlabelavg.Rows(0)("SPEC_FUEL_CON_RECOM")
            ''            '====================================================
            ''            TotalGasFlowOnline.Text = dtlabelavg.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
            ''            TotalGasFlowCalculated.Text = dtlabelavg.Rows(0)("TOTAL_GAS_FLOW_CAL")
            ''            TotalGasFlowRecommended.Text = dtlabelavg.Rows(0)("TOTAL_GAS_FLOW_RECOM")
            ''            '========================================================
            ''            TotalAirFlowOnline.Text = dtlabelavg.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
            ''            TotalAirFlowCalculated.Text = dtlabelavg.Rows(0)("TOTAL_AIR_FLOW_CAL")
            ''            TotalAirFlowRecommended.Text = dtlabelavg.Rows(0)("TOTAL_AIR_FLOW_RECOM")
            ''        Else
            ''            BaseValueOnline.Text = ""
            ''            BaseValueRecommended.Text = ""
            ''            '=================================================
            ''            '   HeatInputOnline.Text = dtlabel.Rows(0)("HEAT_INPUT")
            ''            HeatInputCalculated.Text = ""
            ''            HeatInputRecommended.Text = ""
            ''            '====================================================
            ''            SpecificationOnline.Text = ""
            ''            SpecificationCalculated.Text = ""
            ''            SpecificationRecommended.Text = ""
            ''            '====================================================
            ''            TotalGasFlowOnline.Text = ""
            ''            TotalGasFlowCalculated.Text = ""
            ''            TotalGasFlowRecommended.Text = ""
            ''            '========================================================
            ''            TotalAirFlowOnline.Text = ""
            ''            TotalAirFlowCalculated.Text = ""
            ''            TotalAirFlowRecommended.Text = ""
            ''        End If


            ''    End If
            ''End If

            ''End Code Started Tirthankar 12-Jun-23


        Catch ex As Exception

        End Try
    End Sub

    Protected Sub populateAirFuelRatio(fce_ID As String)

        Dim dtGcAirFlRatio As DataTable

        If fce_ID = 1 Then
            dtGcAirFlRatio = objController.PopulateAirFuelRatio()
        ElseIf fce_ID = 2 Then
            dtGcAirFlRatio = objController.PopulateAirFuelRatioFurnc2()
        End If



        If dtGcAirFlRatio.Rows.Count > 0 Then
            btnZ1ActRatio.Text = dtGcAirFlRatio.Rows(0)("Z1_AIR_FUEL_RATIO")
            btnZ1ActExceAir.Text = dtGcAirFlRatio.Rows(0)("Z1_EXCESS_AIR")
            btnZ1RecRatio.Text = ""

            btnZ2ActRatio.Text = dtGcAirFlRatio.Rows(0)("Z2_AIR_FUEL_RATIO")
            btnZ2ActExceAir.Text = dtGcAirFlRatio.Rows(0)("Z2_EXCESS_AIR")
            btnZ2RecRatio.Text = ""

            btnZ3ActRatio.Text = dtGcAirFlRatio.Rows(0)("Z3_AIR_FUEL_RATIO")
            btnZ3ActExceAir.Text = dtGcAirFlRatio.Rows(0)("Z3_EXCESS_AIR")
            btnZ3RecRatio.Text = ""

            btnZ4ActRatio.Text = dtGcAirFlRatio.Rows(0)("Z4_AIR_FUEL_RATIO")
            btnZ4ActExceAir.Text = dtGcAirFlRatio.Rows(0)("Z4_EXCESS_AIR")
            btnZ4RecRatio.Text = ""

            btnZ5ActRatio.Text = dtGcAirFlRatio.Rows(0)("Z5_AIR_FUEL_RATIO")
            btnZ5ActExceAir.Text = dtGcAirFlRatio.Rows(0)("Z5_EXCESS_AIR")
            btnZ5RecRatio.Text = ""

            btnZ6ActRatio.Text = dtGcAirFlRatio.Rows(0)("Z6_AIR_FUEL_RATIO")
            btnZ6ActExceAir.Text = dtGcAirFlRatio.Rows(0)("Z6_EXCESS_AIR")
            btnZ6RecRatio.Text = ""

            btnZ7ActRatio.Text = dtGcAirFlRatio.Rows(0)("Z7_AIR_FUEL_RATIO")
            btnZ7ActExceAir.Text = dtGcAirFlRatio.Rows(0)("Z7_EXCESS_AIR")
            btnZ7RecRatio.Text = ""

            btnZ8ActRatio.Text = dtGcAirFlRatio.Rows(0)("Z8_AIR_FUEL_RATIO")
            btnZ8ActExceAir.Text = dtGcAirFlRatio.Rows(0)("Z8_EXCESS_AIR")
            btnZ8RecRatio.Text = ""

            btnZ9ActRatio.Text = dtGcAirFlRatio.Rows(0)("Z9_AIR_FUEL_RATIO")
            btnZ9ActExceAir.Text = dtGcAirFlRatio.Rows(0)("Z9_EXCESS_AIR")
            btnZ9RecRatio.Text = ""

            btnZ10ActRatio.Text = dtGcAirFlRatio.Rows(0)("Z10_AIR_FUEL_RATIO")
            btnZ10ActExceAir.Text = dtGcAirFlRatio.Rows(0)("Z10_EXCESS_AIR")
            btnZ10RecRatio.Text = ""

            btnOvrActRatio.Text = dtGcAirFlRatio.Rows(0)("TOTAL_AIR_FUEL_RATIO")
            btnOvrActExcAir.Text = dtGcAirFlRatio.Rows(0)("TOTAL_EXCESS_AIR")
            btnOvrRecRatio.Text = dtGcAirFlRatio.Rows(0)("BASE_SUGG_LOW") & " - " & dtGcAirFlRatio.Rows(0)("BASE_SUGG_HIGH")

        End If
    End Sub

    Protected Sub rdbtnLineB_CheckedChanged(sender As Object, e As EventArgs) Handles rdbtnLineB.CheckedChanged
        Try
            'Dim dSdate As DataSet = objdatahandler.GetDataSetFromQuery("select max(datetime) as DATETIME FROM  [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]")
            'Dim dtdate As DataTable = dSdate.Tables(0)
            Dim dSdate As DataTable = objController.PopulateMaxDatetime()

            'Dim dSdate As DataSet = objdatahandler.GetDataSetFromQuery("select max(datetime) as DATETIME FROM  [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]")

            '  Dim dtdate As DataTable = dSdate.Tables(0)
            Dim dtdate As DataTable = dSdate

            Dim ddtdate As DateTime = dtdate.Rows(0)("DATETIME")
            Dim frmDate As String = ddtdate.ToString("yyyy-MM-dd HH:mm:ss")
            Dim toDate As String = ddtdate.AddHours(-1).ToString("yyyy-MM-dd HH:mm:ss")


            '===========lineb=====================
            'Dim dtlineB As DataTable = objController.PopulateDataForHeatDistributionModelFORLINEB()
            Dim dtGcFur2 As DataTable = objController.PopulateDataForHSMFurnace2()
            Dim dtGcFur2TPOH As DataTable = objController.PopulateDataForHSMFurnace2TPOH()
            Dim dtlabelLineB As DataTable = objController.populatelabelValueFORLINEB()
            ' Dim dtavg As DataTable = objController.PopulateAvgValuefromdt(frmDate, toDate)
            ' Dim dtavglineb As DataTable = objController.PopulateAvgValuefromdtLineb(frmDate, toDate)
            Dim dtavglineb As DataTable = objController.populatelabelValueForAvgLineB(frmDate, toDate)


            If rdbtnLineB.Checked = True Then
                'Session("checkboxval") = "B"
                Session("checkboxval") = "2"
                ' DrawChartTop()
                getdataForGrid_LineB()
                'lblforgrid_indicator.Text = "Table Grid Show LineB Values"
                ' lblforgriddatavalue.Text = "Abnormal LineB Roll Colling Water Tempreture"
                ''Code started Tirthankar 12-Jun-23
                If dtGcFur2.Rows.Count > 0 Then

                    btnHeatRecover1.Text = dtGcFur2.Rows(0)("HEAT_RECOV_PERC") & " %"

                    btnHeatRecovPerFluExit.Text = dtGcFur2.Rows(0)("HEAT_RECOV_PERC_FLUE_EXIT") & " %"
                    'btnHeatRecover2.Text = ""

                    'btnHeatRecover3.Text = ""

                    ''New Code Added

                    If Convert.ToDecimal(dtGcFur2.Rows(0)("RECUP_PERF")) >= 100 Then
                        btnRecup1.Text = "100 %"
                    Else
                        btnRecup1.Text = dtGcFur2.Rows(0)("RECUP_PERF") & " %"
                    End If

                    Dim dtRecup85checkFir2 As DataTable = objController.PopuDataForRecup85HigherFur2()


                    Dim checkBelow85 As Integer = 0
                    Dim chkdtrow As Integer = dtRecup85checkFir2.Rows.Count

                    For i = 0 To dtRecup85checkFir2.Rows.Count - 1
                        If dtRecup85checkFir2.Rows(i)(1) < 85 Then
                            checkBelow85 += 1
                        End If
                    Next
                    If checkBelow85 = chkdtrow Then
                        btnRecup1.CssClass &= " blink"
                    Else
                        btnRecup1.CssClass = "btn btn-outline-secondary"
                    End If

                    'btnRecup1.Text = dtGcFur2.Rows(0)("RECUP_PERF") & " %"

                    'btnRecup2.Text = ""

                    'btnRecup3.Text = ""

                    btnHeatInput.Text = dtGcFur2.Rows(0)("HEAT_INPUT")


                    'btnThroughPut.Text = ""

                    'btnStockEntryTemp.Text = ""

                    'btnStockExitTemp.Text = ""

                    btnCoolingWaterLoss.Text = dtGcFur2.Rows(0)("COOL_WAT_LOSS")

                    btnCoolingWaterLossPerc.Text = dtGcFur2.Rows(0)("COOL_WAT_LOSS_PERC") & " %"

                    btnFuelLossPerc.Text = dtGcFur2.Rows(0)("FLUE_LOSS_PERC") & " %"

                    btnFlueLoss.Text = dtGcFur2.Rows(0)("FLUE_LOSS")

                    'btnHeatMaterial.Text = ""

                    btnHeatMaterialPerc.Text = dtGcFur2.Rows(0)("HEAT_MATE_PERC") & " %"

                    btnOpenLoss.Text = dtGcFur2.Rows(0)("OPEN_LOSS")

                    btnOpenLossPerc.Text = dtGcFur2.Rows(0)("OPEN_LOSS_PERC") & " %"

                    'btnWallRoofLoss.Text = ""

                    btnWallRoofLossPerc.Text = dtGcFur2.Rows(0)("SKIN_LOSS_PERC") & " %"

                    btnAirFlow.Text = dtGcFur2.Rows(0)("TOTAL_AIR_FLOW_ONLINE")

                    btnGasFlow.Text = dtGcFur2.Rows(0)("TOTAL_GAS_FLOW_ONLINE")

                    btnWobee.Text = dtGcFur2.Rows(0)("WOBBE")

                    lblSpecificFur2.Text = dtGcFur2.Rows(0)("SPEC_FUEL_CON_ONLINE")

                    textspcificFur2.Visible = True

                    lblSpecificFur2.Visible = True

                    textspcificFur1.Visible = False

                    lblSpecificFur1.Visible = False

                Else

                    btnHeatRecover1.Text = ""

                    btnHeatRecovPerFluExit.Text = ""
                    'btnHeatRecover2.Text = ""

                    'btnHeatRecover3.Text = ""

                    btnRecup1.Text = ""

                    'btnRecup2.Text = ""

                    'btnRecup3.Text = ""

                    btnHeatInput.Text = ""

                    'btnThroughPut.Text = ""

                    'btnStockEntryTemp.Text = ""

                    'btnStockExitTemp.Text = ""

                    btnCoolingWaterLoss.Text = ""

                    btnCoolingWaterLossPerc.Text = ""

                    btnFuelLossPerc.Text = ""

                    btnFlueLoss.Text = ""

                    'btnHeatMaterial.Text = ""

                    btnHeatMaterialPerc.Text = ""

                    btnOpenLoss.Text = ""

                    btnOpenLossPerc.Text = ""

                    'btnWallRoofLoss.Text = ""

                    btnWallRoofLossPerc.Text = ""

                    btnAirFlow.Text = ""

                    btnGasFlow.Text = ""

                    btnWobee.Text = ""

                    lblSpecificFur2.Text = ""

                    textspcificFur2.Visible = True

                    lblSpecificFur2.Visible = True

                    textspcificFur1.Visible = False

                    lblSpecificFur1.Visible = False

                End If


                If dtGcFur2TPOH.Rows.Count > 0 Then

                    btnStockEntryTemp.Text = dtGcFur2TPOH.Rows(0)("SLAB_CHARG_TEMP")
                    btnStockExitTemp.Text = dtGcFur2TPOH.Rows(0)("SLAB_DISCHARG_TEMP")
                    btnThroughPut.Text = dtGcFur2TPOH.Rows(0)("TPOH")
                    btnHeatMaterial.Text = dtGcFur2TPOH.Rows(0)("HEAT_MATER")
                    btnWallRoofLoss.Text = dtGcFur2TPOH.Rows(0)("SKIN_LOSS")
                Else
                    btnStockEntryTemp.Text = ""
                    btnStockExitTemp.Text = ""
                    btnThroughPut.Text = ""
                    btnHeatMaterial.Text = ""
                    btnWallRoofLoss.Text = ""
                End If

                Dim dtGcSpecFuel As DataTable

                dtGcSpecFuel = objController.PopulateDataForSpecFuelCon("2")

                If dtGcSpecFuel.Rows.Count > 0 Then
                    lblSpecificFur2.Text = dtGcSpecFuel.Rows(0)("CUM_SPEC_FUEL_CON") & " Gcal/T"
                    'lblGasUnavlbl.Visible = False
                    textspcificFur2.Visible = True
                    lblSpecificFur2.Visible = True
                    textspcificFur1.Visible = False
                    lblSpecificFur1.Visible = False
                Else
                    lblSpecificFur2.Text = ""
                    'lblGasUnavlbl.Visible = False
                    textspcificFur2.Visible = True
                    lblSpecificFur2.Visible = True
                    textspcificFur1.Visible = False
                    lblSpecificFur1.Visible = False
                End If

                populateAirFuelRatio(2)

                DrawSpecFuelChart()

                'Dim dtlabel As DataTable = objController.populatelabelValue()

                ''If rbdTimeStamp.Checked Then
                ''    If dtlabelLineB.Rows.Count > 0 Then


                ''        BaseValueOnline.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FUEL_RATIO")
                ''        BaseValueRecommended.Text = dtlabelLineB.Rows(0)("BASE_VALUE_RECOM")
                ''        '=================================================
                ''        '   HeatInputOnline.Text = dtlabelLineB.Rows(0)("HEAT_INPUT")
                ''        HeatInputCalculated.Text = dtlabelLineB.Rows(0)("HEAT_INPUT")
                ''        HeatInputRecommended.Text = dtlabelLineB.Rows(0)("HEAT_INPUT_RECOM")
                ''        '====================================================
                ''        SpecificationOnline.Text = dtlabelLineB.Rows(0)("SPC_FUEL_CON_ONLINE")
                ''        SpecificationCalculated.Text = dtlabelLineB.Rows(0)("SPC_FUEL_CON_CAL")
                ''        SpecificationRecommended.Text = dtlabelLineB.Rows(0)("SPEC_FUEL_CON_RECOM")
                ''        '====================================================
                ''        TotalGasFlowOnline.Text = dtlabelLineB.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
                ''        TotalGasFlowCalculated.Text = dtlabelLineB.Rows(0)("TOTAL_GAS_FLOW_CAL")
                ''        TotalGasFlowRecommended.Text = dtlabelLineB.Rows(0)("TOTAL_GAS_FLOW_RECOM")
                ''        '========================================================
                ''        TotalAirFlowOnline.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
                ''        TotalAirFlowCalculated.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FLOW_CAL")
                ''        TotalAirFlowRecommended.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FLOW_RECOM")

                ''    Else
                ''        BaseValueOnline.Text = ""
                ''        BaseValueRecommended.Text = ""
                ''        '=================================================
                ''        '   HeatInputOnline.Text = dtlabelLineB.Rows(0)("HEAT_INPUT")
                ''        HeatInputCalculated.Text = ""
                ''        HeatInputRecommended.Text = ""
                ''        '====================================================
                ''        SpecificationOnline.Text = ""
                ''        SpecificationCalculated.Text = ""
                ''        SpecificationRecommended.Text = ""
                ''        '====================================================
                ''        TotalGasFlowOnline.Text = ""
                ''        TotalGasFlowCalculated.Text = ""
                ''        TotalGasFlowRecommended.Text = ""
                ''        '========================================================
                ''        TotalAirFlowOnline.Text = ""
                ''        TotalAirFlowCalculated.Text = ""
                ''        TotalAirFlowRecommended.Text = ""

                ''    End If




                ''End If
                ''If rbdAVG.Checked Then
                ''    If dtavglineb.Rows.Count > 0 Then

                ''        BaseValueOnline.Text = dtavglineb.Rows(0)("TOTAL_AIR_FUEL_RATIO")
                ''        BaseValueRecommended.Text = dtavglineb.Rows(0)("BASE_VALUE_RECOM")
                ''        '=================================================
                ''        '   HeatInputOnline.Text = dtavglineb.Rows(0)("HEAT_INPUT")
                ''        HeatInputCalculated.Text = dtavglineb.Rows(0)("HEAT_INPUT")
                ''        HeatInputRecommended.Text = dtavglineb.Rows(0)("HEAT_INPUT_RECOM")
                ''        '====================================================
                ''        SpecificationOnline.Text = dtavglineb.Rows(0)("SPC_FUEL_CON_ONLINE") '& AvgData

                ''        SpecificationCalculated.Text = dtavglineb.Rows(0)("SPC_FUEL_CON_CAL")
                ''        SpecificationRecommended.Text = dtavglineb.Rows(0)("SPEC_FUEL_CON_RECOM")
                ''        '====================================================
                ''        TotalGasFlowOnline.Text = dtavglineb.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
                ''        TotalGasFlowCalculated.Text = dtavglineb.Rows(0)("TOTAL_GAS_FLOW_CAL")
                ''        TotalGasFlowRecommended.Text = dtavglineb.Rows(0)("TOTAL_GAS_FLOW_RECOM")
                ''        '========================================================
                ''        TotalAirFlowOnline.Text = dtavglineb.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
                ''        TotalAirFlowCalculated.Text = dtavglineb.Rows(0)("TOTAL_AIR_FLOW_CAL")
                ''        TotalAirFlowRecommended.Text = dtavglineb.Rows(0)("TOTAL_AIR_FLOW_RECOM")
                ''    Else
                ''        BaseValueOnline.Text = ""
                ''        BaseValueRecommended.Text = ""
                ''        '=================================================
                ''        '   HeatInputOnline.Text = dtlabel.Rows(0)("HEAT_INPUT")
                ''        HeatInputCalculated.Text = ""
                ''        HeatInputRecommended.Text = ""
                ''        '====================================================
                ''        SpecificationOnline.Text = ""
                ''        SpecificationCalculated.Text = ""
                ''        SpecificationRecommended.Text = ""
                ''        '====================================================
                ''        TotalGasFlowOnline.Text = ""
                ''        TotalGasFlowCalculated.Text = ""
                ''        TotalGasFlowRecommended.Text = ""
                ''        '========================================================
                ''        TotalAirFlowOnline.Text = ""
                ''        TotalAirFlowCalculated.Text = ""
                ''        TotalAirFlowRecommended.Text = ""
                ''    End If

                ''End If
                ''End Code Tirthankar started 12-Jun-23
            End If




        Catch ex As Exception

        End Try
    End Sub





    'Public Shared Function SetAllValues(rbdTimeStamp As Boolean, rbdAVG As Boolean) As String

    <WebMethod>
    Public Shared Function SetAllValues(rdbtnLineA As Boolean, rdbtnLineB As Boolean) As String
        Dim dh As New DataHandler
        Dim oc As New Controller
        Dim dSdate As DataSet = dh.GetDataSetFromQuery("select max(datetime) as DATETIME FROM  [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]")
        Dim dtdate As DataTable = dSdate.Tables(0)

        Dim ddtdate As DateTime = CDate(dtdate.Rows(0)(0))
        Dim frmDate As String = ddtdate.ToString("yyyy-MM-dd HH:mm:ss")
        Dim toDate As String = ddtdate.AddHours(-1).ToString("yyyy-MM-dd HH:mm:ss")
        'LINEA
        Dim dt As DataTable = oc.PopulateDataForHeatDistributionModel()
        Dim dtlabel As DataTable = oc.populatelabelValue()
        Dim dtlabelavg As DataTable = oc.populatelabelValueForAvg(frmDate, toDate)
        'LINEB
        Dim dtlineB As DataTable = oc.PopulateDataForHeatDistributionModelFORLINEB()
        Dim dtlabelLineB As DataTable = oc.populatelabelValueFORLINEB()

        '  Dim dtavglineb As DataTable = oc.PopulateAvgValuefromdtLineb(frmDate, toDate)
        Dim dtavglineb As DataTable = oc.populatelabelValueForAvgLineB(frmDate, toDate)
        Dim flag85 As Boolean


        'If rbdTimeStamp Then
        '    dtlabel = oc.populatelabelValue()
        'ElseIf rbdAVG Then
        '    dtlabel = oc.populatelabelValueForAvg(frmDate, toDate)
        'End If
        Dim dtTPOH As DataTable

        If rdbtnLineA Then
            'dt = oc.PopulateDataForHeatDistributionModel()
            dt = oc.PopulateDataForHSMFurnace1()
            dtTPOH = oc.PopulateDataForHSMFurnace1TPOH()

            Dim dtRecup85checkFir1 As DataTable = oc.PopuDataForRecup85HigherFur1()


            Dim checkBelow85 As Integer = 0
            Dim chkdtrow As Integer = dtRecup85checkFir1.Rows.Count

            For i = 0 To dtRecup85checkFir1.Rows.Count - 1
                If dtRecup85checkFir1.Rows(i)(1) < 85 Then
                    checkBelow85 += 1
                End If
            Next
            If checkBelow85 = chkdtrow Then
                flag85 = True
            Else
                flag85 = False
            End If
        ElseIf rdbtnLineB Then
            'dt = oc.PopulateDataForHeatDistributionModelFORLINEB()
            dt = oc.PopulateDataForHSMFurnace2()
            dtTPOH = oc.PopulateDataForHSMFurnace2TPOH()

            Dim dtRecup85checkFir2 As DataTable = oc.PopuDataForRecup85HigherFur2()


            Dim checkBelow85 As Integer = 0
            Dim chkdtrow As Integer = dtRecup85checkFir2.Rows.Count

            For i = 0 To dtRecup85checkFir2.Rows.Count - 1
                If dtRecup85checkFir2.Rows(i)(1) < 85 Then
                    checkBelow85 += 1
                End If
            Next
            If checkBelow85 = chkdtrow Then
                flag85 = True
            Else
                flag85 = False
            End If
        End If


        '  Dim dtavg As DataTable = oc.PopulateAvgValuefromdt(frmDate, toDate)


        If dt.Rows.Count > 0 Then
            Dim ret As New StringBuilder
            'btnHeatRecover1.Text =
            ' lblMAXDATETIME.Text = frmDate
            ret.Append(dt.Rows(0)("HEAT_RECOV_PERC") & " %,")
            'btnHeatRecoverySanky1.Text = 
            ret.Append(dt.Rows(0)("HEAT_INPUT") & ",")
            'btnHeatRecover2.Text = 
            ret.Append(dt.Rows(0)("TOTAL_AIR_FLOW_ONLINE") & ",")
            'btnHeatRecoverySanky2.Text = 
            'ret.Append(dt.Rows(0)("HEAT_RECOV2") & "%,")
            ''btnHeatRecover3.Text = 
            'ret.Append(dt.Rows(0)("HEAT_RECOV3") & "%,")

            '============================================
            'ret.Append(dt.Rows(0)("HEAT_RECOV3") & "%,")
            ret.Append(dt.Rows(0)("TOTAL_GAS_FLOW_ONLINE") & ",")
            ret.Append(dt.Rows(0)("WOBBE") & ",")
            ret.Append(dt.Rows(0)("COOL_WAT_LOSS") & ",")
            ret.Append(dt.Rows(0)("COOL_WAT_LOSS_PERC") & " %,")
            ret.Append(dt.Rows(0)("FLUE_LOSS_PERC") & " %,")
            ret.Append(dt.Rows(0)("FLUE_LOSS") & ",")
            ret.Append(dt.Rows(0)("HEAT_MATE_PERC") & " %,")
            ret.Append(dt.Rows(0)("OPEN_LOSS") & ",")
            ret.Append(dt.Rows(0)("OPEN_LOSS_PERC") & " %,")
            ret.Append(dt.Rows(0)("SKIN_LOSS_PERC") & " %,")

            ret.Append(dtTPOH.Rows(0)("TPOH") & ",")
            ret.Append(dtTPOH.Rows(0)("HEAT_MATER") & ",")
            ret.Append(dtTPOH.Rows(0)("SLAB_CHARG_TEMP") & ",")
            ret.Append(dtTPOH.Rows(0)("SLAB_DISCHARG_TEMP") & ",")
            ret.Append(dtTPOH.Rows(0)("SKIN_LOSS") & ",")
            If Convert.ToDecimal(dt.Rows(0)("RECUP_PERF")) >= 100 Then
                ret.Append("100 %,")
            Else
                ret.Append(dt.Rows(0)("RECUP_PERF") & " %,")
            End If
            ret.Append(dt.Rows(0)("HEAT_RECOV_PERC_FLUE_EXIT") & " %,")
            ret.Append(flag85)

            Return (ret.ToString)
        Else
            Return "novalues"
        End If
        'If dtlabel.Rows.Count > 0 Then
        '    Dim retLabel As New StringBuilder
        '    retLabel.Append(dtlabel.Rows(0)("TOTAL_AIR_FUEL_RATIO"))
        '    retLabel.Append(dtlabel.Rows(0)("BASE_VALUE_RECOM"))
        '    retLabel.Append(dtlabel.Rows(0)("HEAT_INPUT"))
        '    retLabel.Append(dtlabel.Rows(0)("HEAT_INPUT_RECOM"))
        '    retLabel.Append(dtlabel.Rows(0)("SPC_FUEL_CON_ONLINE"))
        '    retLabel.Append(dtlabel.Rows(0)("SPC_FUEL_CON_CAL"))
        '    retLabel.Append(dtlabel.Rows(0)("SPEC_FUEL_CON_RECOM"))
        '    retLabel.Append(dtlabel.Rows(0)("TOTAL_GAS_FLOW_ONLINE"))
        '    retLabel.Append(dtlabel.Rows(0)("TOTAL_GAS_FLOW_CAL"))
        '    retLabel.Append(dtlabel.Rows(0)("TOTAL_GAS_FLOW_RECOM"))
        '    retLabel.Append(dtlabel.Rows(0)("TOTAL_AIR_FLOW_ONLINE"))
        '    retLabel.Append(dtlabel.Rows(0)("TOTAL_AIR_FLOW_CAL"))
        '    retLabel.Append(dtlabel.Rows(0)("TOTAL_AIR_FLOW_RECOM"))


        'Else
        '    Return "novalues"
        'End If


    End Function

    <WebMethod>
    Public Shared Function setAllgridValues_1hour(rdbtnLineA As Boolean, rdbtnLineB As Boolean) As String
        Dim dh As New DataHandler
        Dim oc As New Controller
        'Dim gvData As GridView
        Dim dttablegrid As DataTable
        Dim DSDATE_FORGRID As DataTable = oc.PopulateMaxDatetime()


        Dim dtdateforgrid As DataTable = DSDATE_FORGRID

        Dim ddtdateforgrid As DateTime = CDate(dtdateforgrid.Rows(0)(0))
        Dim frmDateforgrid As String = ddtdateforgrid.ToString("yyyy-MM-dd HH:mm:ss")
        Dim toDateforgrid As String = ddtdateforgrid.AddHours(-1).ToString("yyyy-MM-dd HH:mm:ss")

        If rdbtnLineA Then
            dttablegrid = oc.GetDataForLogDetailsLINEA(toDateforgrid, frmDateforgrid)

        ElseIf rdbtnLineB Then
            dttablegrid = oc.GetDataForLogDetailsLineB(toDateforgrid, frmDateforgrid)

        End If

        Dim dv_forgrid As DataView = dttablegrid.DefaultView
        Try


            For i As Integer = 0 To dttablegrid.Rows.Count - 1
                Dim row As DataRow = dttablegrid.Rows(i)
                If row.Item(1) = 0 And row.Item(2) = 0 And row.Item(3) = 0 And row.Item(3) = 0 And row.Item(4) = 0 And row.Item(5) = 0 And row.Item(6) = 0 Then
                    dttablegrid.Rows(i).Delete()
                    'ElseIf row.Item(0).ToString.Trim = "" Then
                    '    dttablegrid.Rows.Remove(row)
                End If
            Next
        Catch ex As Exception
            ' Throw ex
        End Try
        dttablegrid.AcceptChanges()
        Dim retLabel As New StringBuilder
        If dttablegrid.Rows.Count > 0 Then

            ' Button1.BackColor = Color.Red
            For k As Integer = 0 To dttablegrid.Rows.Count - 1
                '  ret.Append(dt.Rows(0)("CV") & "%,")
                retLabel.Append(dttablegrid.Rows(k)("ROLLER") & ",")
                retLabel.Append(dttablegrid.Rows(k)("ABN_INLET_TEMP_MIN") & ",")
                retLabel.Append(dttablegrid.Rows(k)("ABN_INLET_TEMP_MAX") & ",")
                retLabel.Append(dttablegrid.Rows(k)("ABN_DELTA_T_MIN") & ",")
                retLabel.Append(dttablegrid.Rows(k)("ABN_DELTA_T_MAX") & ",")
                retLabel.Append(dttablegrid.Rows(k)("ABN_OUTLET_TEMP_MIN") & ",")
                retLabel.Append(dttablegrid.Rows(k)("ABN_OUTLET_TEMP_MAX") & "")
                retLabel.Append("#")
            Next


            'btnCoolingWaterLossPerc.BackColor = Color.Red
            Return (retLabel.ToString)
        Else
            Return "novalues"
            'btnCoolingWaterLossPerc.BackColor = Color.Yellow
        End If
        '    btnCoolingWaterLossPerc.BackColor = Color.Red
        'Else
        '    btnCoolingWaterLossPerc.BackColor = Color.Yellow

        'End If





    End Function

    <WebMethod>
    Public Shared Function SetAllValuesGridTables(rbdTimeStamp As Boolean, rbdAVG As Boolean, rdbtnLineA As Boolean, rdbtnLineB As Boolean) As String
        Dim dh As New DataHandler
        Dim oc As New Controller
        Dim dSdate As DataSet = dh.GetDataSetFromQuery("select max(datetime) as DATETIME FROM  [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]")
        Dim dtdate As DataTable = dSdate.Tables(0)

        Dim ddtdate As DateTime = CDate(dtdate.Rows(0)(0))
        Dim frmDate As String = ddtdate.ToString("yyyy-MM-dd HH:mm:ss")
        Dim toDate As String = ddtdate.AddHours(-1).ToString("yyyy-MM-dd HH:mm:ss")
        '================lineA
        Dim dt As DataTable = oc.PopulateDataForHeatDistributionModel()
        Dim dtlabel As DataTable = oc.populatelabelValue()
        Dim dtlabelavg As DataTable = oc.populatelabelValueForAvg(frmDate, toDate)
        '==========LINEB
        Dim dtlineB As DataTable = oc.PopulateDataForHeatDistributionModelFORLINEB()
        Dim dtlabelLineB As DataTable = oc.populatelabelValueFORLINEB()
        '  Dim dtavglineb As DataTable = oc.PopulateAvgValuefromdtLineb(frmDate, toDate)
        Dim dtavglineb As DataTable = oc.populatelabelValueForAvgLineB(frmDate, toDate)

        '================


        If rdbtnLineA Then
            If rbdTimeStamp Then
                dtlabel = oc.populatelabelValue()
            ElseIf rbdAVG Then
                dtlabel = oc.populatelabelValueForAvg(frmDate, toDate)
            End If
        End If
        If rdbtnLineB Then
            If rbdTimeStamp Then
                dtlabel = oc.populatelabelValueFORLINEB()
            ElseIf rbdAVG Then
                'dtlabel = oc.PopulateAvgValuefromdtLineb(frmDate, toDate)
                dtlabel = oc.populatelabelValueForAvgLineB(frmDate, toDate)

            End If
        End If


        If dtlabel.Rows.Count > 0 Then
            Dim retLabel As New StringBuilder
            '  ret.Append(dt.Rows(0)("CV") & "%,")
            retLabel.Append(dtlabel.Rows(0)("TOTAL_AIR_FUEL_RATIO") & ",")
            retLabel.Append(dtlabel.Rows(0)("BASE_VALUE_RECOM") & ",")
            retLabel.Append(dtlabel.Rows(0)("HEAT_INPUT") & ",")
            retLabel.Append(dtlabel.Rows(0)("HEAT_INPUT_RECOM") & ",")
            retLabel.Append(dtlabel.Rows(0)("SPC_FUEL_CON_ONLINE") & ",")
            retLabel.Append(dtlabel.Rows(0)("SPC_FUEL_CON_CAL") & ",")
            retLabel.Append(dtlabel.Rows(0)("SPEC_FUEL_CON_RECOM") & ",")
            retLabel.Append(dtlabel.Rows(0)("TOTAL_GAS_FLOW_ONLINE") & ",")
            retLabel.Append(dtlabel.Rows(0)("TOTAL_GAS_FLOW_CAL") & ",")
            retLabel.Append(dtlabel.Rows(0)("TOTAL_GAS_FLOW_RECOM") & ",")
            retLabel.Append(dtlabel.Rows(0)("TOTAL_AIR_FLOW_ONLINE") & ",")
            retLabel.Append(dtlabel.Rows(0)("TOTAL_AIR_FLOW_CAL") & ",")
            retLabel.Append(dtlabel.Rows(0)("TOTAL_AIR_FLOW_RECOM") & ",")

            Return (retLabel.ToString)
        Else
            Return "novalues"
        End If


    End Function
    <WebMethod>
    Public Shared Function setValuesForAirFuelRatio(rdbLineA As Boolean, rdbLineB As Boolean) As String

        Dim dh As New DataHandler
        Dim oc As New Controller
        Dim dtGcAirFlRatio As DataTable

        If rdbLineA Then
            dtGcAirFlRatio = oc.PopulateAirFuelRatio()
        ElseIf rdbLineB Then
            dtGcAirFlRatio = oc.PopulateAirFuelRatioFurnc2()
        End If

        If dtGcAirFlRatio.Rows.Count > 0 Then
            Dim retLabel As New StringBuilder
            '  ret.Append(dt.Rows(0)("CV") & "%,")
            retLabel.Append(dtGcAirFlRatio.Rows(0)("Z1_AIR_FUEL_RATIO") & ",")
            retLabel.Append(dtGcAirFlRatio.Rows(0)("Z1_EXCESS_AIR") & ",")
            retLabel.Append(" ,")

            retLabel.Append(dtGcAirFlRatio.Rows(0)("Z2_AIR_FUEL_RATIO") & ",")
            retLabel.Append(dtGcAirFlRatio.Rows(0)("Z2_EXCESS_AIR") & ",")
            retLabel.Append(" ,")

            retLabel.Append(dtGcAirFlRatio.Rows(0)("Z3_AIR_FUEL_RATIO") & ",")
            retLabel.Append(dtGcAirFlRatio.Rows(0)("Z3_EXCESS_AIR") & ",")
            retLabel.Append(" ,")

            retLabel.Append(dtGcAirFlRatio.Rows(0)("Z4_AIR_FUEL_RATIO") & ",")
            retLabel.Append(dtGcAirFlRatio.Rows(0)("Z4_EXCESS_AIR") & ",")
            retLabel.Append(" ,")

            retLabel.Append(dtGcAirFlRatio.Rows(0)("Z5_AIR_FUEL_RATIO") & ",")
            retLabel.Append(dtGcAirFlRatio.Rows(0)("Z5_EXCESS_AIR") & ",")
            retLabel.Append(" ,")

            retLabel.Append(dtGcAirFlRatio.Rows(0)("Z6_AIR_FUEL_RATIO") & ",")
            retLabel.Append(dtGcAirFlRatio.Rows(0)("Z6_EXCESS_AIR") & ",")
            retLabel.Append(" ,")

            retLabel.Append(dtGcAirFlRatio.Rows(0)("Z7_AIR_FUEL_RATIO") & ",")
            retLabel.Append(dtGcAirFlRatio.Rows(0)("Z7_EXCESS_AIR") & ",")
            retLabel.Append(" ,")

            retLabel.Append(dtGcAirFlRatio.Rows(0)("Z8_AIR_FUEL_RATIO") & ",")
            retLabel.Append(dtGcAirFlRatio.Rows(0)("Z8_EXCESS_AIR") & ",")
            retLabel.Append(" ,")

            retLabel.Append(dtGcAirFlRatio.Rows(0)("Z9_AIR_FUEL_RATIO") & ",")
            retLabel.Append(dtGcAirFlRatio.Rows(0)("Z9_EXCESS_AIR") & ",")
            retLabel.Append(" ,")

            retLabel.Append(dtGcAirFlRatio.Rows(0)("Z10_AIR_FUEL_RATIO") & ",")
            retLabel.Append(dtGcAirFlRatio.Rows(0)("Z10_EXCESS_AIR") & ",")
            retLabel.Append(" ,")

            retLabel.Append(dtGcAirFlRatio.Rows(0)("TOTAL_AIR_FUEL_RATIO") & ",")
            retLabel.Append(dtGcAirFlRatio.Rows(0)("TOTAL_EXCESS_AIR") & ",")
            retLabel.Append(dtGcAirFlRatio.Rows(0)("BASE_SUGG_LOW") & " - " & dtGcAirFlRatio.Rows(0)("BASE_SUGG_HIGH") & ",")

            Return (retLabel.ToString)
        Else
            Return "novalues"
        End If

    End Function



    <WebMethod>
    Public Shared Function setlabeltime(rdbtnLineA As Boolean, rdbtnLineB As Boolean) As String
        Dim dh As New DataHandler
        Dim oc As New Controller
        'Dim dtdate As DataTable = oc.PopulateMaxDatetime()
        Dim dtdate As DataTable = oc.PopulateMaxDatetimeForHSM()


        If rdbtnLineA Then
            'dtdate = oc.PopulateMaxDatetime()
            dtdate = oc.PopulateMaxDatetimeForHSM()
        ElseIf rdbtnLineB Then
            'dtdate = oc.PopulateMaxDatetime()
            dtdate = oc.PopulateMaxDatetimeForHSM()
        End If

        If dtdate.Rows.Count > 0 Then
            Dim retdate As New StringBuilder


            retdate.Append(CDate(dtdate.Rows(0)("DATE_TIME")).ToString("yyyy-MM-dd HH:mm:ss") & ",")


            Return (retdate.ToString)
        Else
            Return "novalues"
        End If


    End Function

    '<WebMethod>
    'Public Shared Function setSpecificMonthAVG(rdbtnLineA As Boolean, rdbtnLineB As Boolean) As String
    '    Dim dh As New DataHandler
    '    Dim oc As New Controller
    '    Dim dtspecificdataset As DataSet = dh.GetDataSetFromQuery("SELECT cast(AVG(SPC_FUEL_CON_ONLINE) As Decimal(10,3)) As SPC_FUEL_CON_ONLINE FROM [TSCR_FURNACE_OPT_FINAL]  where  DATEPART(m, datetime) = DATEPART(m, DATEADD(m, 0, getdate())) GROUP BY DATENAME(MONTH,DATETIME) order by DATENAME(MONTH,DATETIME) asc")
    '    Dim dtspecificdatatable As DataTable = dtspecificdataset.Tables(0)
    '    Dim dtspecific As String = dtspecificdatatable.Rows(0)("SPC_FUEL_CON_ONLINE")
    '    ' lblSpecific.Text = dtspecific
    '    If rdbtnLineA Then
    '        dtspecificdatatable = dtspecificdataset.Tables(0)
    '    ElseIf rdbtnLineB Then
    '        dtspecificdatatable = dtspecificdataset.Tables(0)
    '    End If

    '    If dtspecificdatatable.Rows.Count > 0 Then
    '        Dim ret As New StringBuilder


    '        ret.Append(dtspecificdatatable.Rows(0)("SPC_FUEL_CON_ONLINE") & ",")


    '        Return (ret.ToString)
    '    Else
    '        Return "novalues"
    '    End If


    'End Function

    <WebMethod>
    Public Shared Function setSpecificMonthAVG(rdbtnLineA As Boolean, rdbtnLineB As Boolean) As String
        Dim dh As New DataHandler
        Dim oc As New Controller
        Dim TOTAL_SPEC1 As String = ""

        Dim Monthgrid As String = DateTime.Now.ToString("MM")

        Dim yeargrid As String = DateTime.Now.ToString("yyyy")

        Dim first_dategrid As String = 1



        Dim stdategrid As String = yeargrid & "-" & Monthgrid & "-" & first_dategrid
        '  Dim stdate As String = DateTime.Now.AddDays(-3).ToString("yyyy-MM-dd")
        Dim enddategrid As String = DateTime.Now.ToString("yyyy-MM-dd")
        Dim query As String = "Select CONVERT(VARCHAR(10),datetime,120) as datetime, [PRODUCTION], [ON_DATE], [TO_DATE],TOTAL_GAS_CON FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY]  " &
                                   "where DATETIME between '" & stdategrid & "' and '" & enddategrid & "' and PRODUCTION = 'HRC'    order by DATETIME asc"

        Dim count As Short = 0
        Dim getdt As DataTable = dh.GetDataSetFromQuery(query).Tables(0)








        Dim lfcdec_query As String = "SELECT CONVERT(VARCHAR(10),datetime,120) as datetime,   CAST(ROUND(avg(CV), 2) AS DECIMAL(10,2)) as cv FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]  Where  DATETIME between '" & stdategrid & "' and '" & enddategrid & "' and cv is not null group by CONVERT(VARCHAR(10),datetime,120) 	order by CONVERT(VARCHAR(10),datetime,120) asc"

        Dim decisiondt As DataTable = dh.GetDataSetFromQuery(lfcdec_query).Tables(0)

        Dim min As String = ""
        Dim max As String = ""
        Try
            If getdt.Rows.Count > 0 Then

                If decisiondt.Rows.Count > 0 Then
                    Dim query1 As String = "Select CONVERT(VARCHAR(10),datetime,120) as datetime, [PRODUCTION], [ON_DATE], [TO_DATE],TOTAL_GAS_CON FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY]  " &
                                   "where DATETIME between '" & stdategrid & "' and '" & enddategrid & "'   and PRODUCTION ='HRC' order by DATETIME asc"
                    Dim HRC As DataTable = dh.GetDataSetFromQuery(query1).Tables(0)

                    For j As Integer = 0 To getdt.Rows.Count - 1
                        Try
                            Dim row As DataRow = decisiondt.Select("datetime='" & getdt.Rows(j)(0) & "'")(0)


                            Dim HRCDT As DataRow = HRC.Select("datetime='" & getdt.Rows(j)(0) & "'")(0)

                            If IsDBNull(getdt.Rows.Item(j)(4)) Or IsDBNull(getdt.Rows.Item(j)(2)) Then 'or replace from and  and getdt.rows.item(j)(2) from getdt.rows.item(j)(4)


                                '  TOTAL_SPEC1 &= "'" & getdt.Rows(j)(0).ToString & "',"
                                TOTAL_SPEC1 &= 0 & ","

                            Else

                                ' TOTAL_SPEC1 &= "'" & getdt.Rows(j)(0).ToString & "',"
                                Dim valhrc As Decimal = ((getdt.Rows.Item(j)(4) * row.Item(1)) / ((HRCDT.Item(2)) * 1000000))
                                Dim spe_totalhrc As Decimal = FormatNumber(valhrc, 4)




                                TOTAL_SPEC1 &= spe_totalhrc & ","
                            End If
                            ' End If
                            count += 1
                        Catch ex As Exception

                            TOTAL_SPEC1 &= "," '((getdt.Rows.Item(j)(4) * row.Item(1)) / ((HRCDT.Item(2)) * 1000000)) & ","

                            Continue For ' Throw ex
                        End Try
                    Next

                End If

            End If


        Catch ex As Exception
            Return "novalues"
        End Try


        Dim sum, count1 As Double

        'For Each s As String In TOTAL_SPEC1.Split(",")
        '    If Not String.IsNullOrEmpty(s) Then
        '        sum += s
        '        count1 += 1
        '    End If

        'Next
        'Dim VAL_SPEC As Decimal = sum / count1
        'Dim SPECTOTAL As Decimal = FormatNumber(VAL_SPEC, 4)
        Dim VAL_SPEC As Decimal
        Dim SPECTOTAL As Decimal
        If TOTAL_SPEC1 = "" Then
            VAL_SPEC = 0
            Return VAL_SPEC
        Else
            For Each s As String In TOTAL_SPEC1.Split(",")
                If Not String.IsNullOrEmpty(s) Then
                    sum += s
                    count1 += 1
                End If

            Next
            VAL_SPEC = sum / count1
            SPECTOTAL = FormatNumber(VAL_SPEC, 4)
            Return SPECTOTAL
        End If
        'Return SPECTOTAL

        '    Return (retdate.ToString)
        'Else
        '    Return "novalues"
        'End If


    End Function

    <WebMethod>
    Public Shared Function CurrMonthCumulativeSpecificFuel(rdbtnLineA As Boolean, rdbtnLineB As Boolean) As String

        ''Below Commented Code is For HDM(TSCR) Commented on 17-July23 Tirthankar
        ''Dim CummFuelData As String
        ''CummFuelData = ""
        ''Dim dh As New DataHandler

        ''Dim sqlQueryCum As String = "select top 1 [CUM_SPEC_FUEL_CON] FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY] where PRODUCTION='HRC' order by [DATETIME] desc"
        ''Dim dtLB As DataTable = New DataTable()
        '''dtLB = getdatatable(sqlQueryCum)
        ''dtLB = dh.GetDataSetFromQuery(sqlQueryCum).Tables(0)
        ''For Each row As DataRow In dtLB.Rows
        ''    CummFuelData &= row("CUM_SPEC_FUEL_CON") & ","
        ''Next row
        ''Return CummFuelData
        ''Commented till here 17-July-23 Tirthankar
        Try
            Dim objDataHandlerGcp As New DataHandlerGCP
            Dim dt As DataTable
            Dim query As String
            Dim CummFuelData As String
            Dim FurncId As String
            'Dim hrf As HSMReheatingFurnace = New HSMReheatingFurnace()


            If rdbtnLineA Then
                FurncId = 1
            ElseIf rdbtnLineB Then
                FurncId = 2
            End If

            'query = "SELECT  SPEC_FUEL_CON_ONLINE FROM `tsl-datalake.PTG_PSA.HSM_REHT_FURNC` WHERE FCE_ID = " & FurncId & " ORDER BY DATE_TIME DESC LIMIT 1"
            query = "SELECT  CUM_SPEC_FUEL_CON FROM `tsl-datalake.PTG_PSA.HSM_SPECIFIC_FUEL` WHERE FCE_ID = " & FurncId & " ORDER BY DATE_TIME DESC LIMIT 1"

            'CUM_SPEC_FUEL_CON
            dt = objDataHandlerGcp.DataReading(query)

            For Each row As DataRow In dt.Rows
                'CummFuelData &= row("SPEC_FUEL_CON_ONLINE") & ","
                CummFuelData &= row("CUM_SPEC_FUEL_CON") & " Gcal/T,"
            Next row

            'hrf.DrawSpecFuelChart()

            Return CummFuelData
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try


    End Function

    'Public Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
    '    ' MultiView1.ActiveViewIndex = 1
    '    MultiView1.ActiveViewIndex = 0



    '    Dim dSdate As DataSet = objdatahandler.GetDataSetFromQuery("select max(datetime) as DATETIME FROM  [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]")
    '    Dim dtdate As DataTable = dSdate.Tables(0)

    '    Dim ddtdate As DateTime = dtdate.Rows(0)("DATETIME")
    '    Dim frmDate As String = ddtdate.ToString("yyyy-MM-dd HH:mm:ss")
    '    Dim toDate As String = ddtdate.AddHours(-1).ToString("yyyy-MM-dd HH:mm:ss")
    '    lblMAXDATETIME.Text = frmDate


    '    Dim dt As DataTable = objController.PopulateDataForHeatDistributionModel()
    '    Dim dtlabel As DataTable = objController.populatelabelValue()
    '    If rbdTimeStamp.Checked Then
    '        dtlabel = objController.populatelabelValue()
    '    ElseIf rbdAVG.Checked Then
    '        dtlabel = objController.populatelabelValueForAvg(frmDate, toDate)
    '    End If
    '    Dim dtavg As DataTable = objController.PopulateAvgValuefromdt(frmDate, toDate)

    '    Dim dtlineB As DataTable = objController.PopulateDataForHeatDistributionModelFORLINEB()
    '    Dim dtlabelLineB As DataTable = objController.populatelabelValueFORLINEB()

    '    Dim dtavglineb As DataTable = objController.PopulateAvgValuefromdtLineb(frmDate, toDate)

    '    If rdbtnLineA.Checked = True Then
    '        Session("checkboxval") = "A"

    '        '  DrawChartTop()
    '        If dt.Rows.Count > 0 Then
    '            '            'txtHeatRecover1.Text = dt.Rows(0)("HEAT_RECOV1")
    '            btnHeatRecover1.Text = dt.Rows(0)("HEAT_RECOV1") & "%"
    '            btnHeatRecoverySanky1.Text = dt.Rows(0)("HEAT_RECOV1") & "%"
    '            'txtHeatRecover2.Text = dt.Rows(0)("HEAT_RECOV2")
    '            btnHeatRecover2.Text = dt.Rows(0)("HEAT_RECOV2") & "%"
    '            btnHeatRecoverySanky2.Text = dt.Rows(0)("HEAT_RECOV2") & "%"
    '            'txtHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3")
    '            btnHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3") & "%"
    '            btnHeatRecoverySanky3.Text = dt.Rows(0)("HEAT_RECOV3") & "%"
    '            'txtRecup1.Text = dt.Rows(0)("RECUP1_PERFORM")
    '            btnRecup1.Text = dt.Rows(0)("RECUP1_PERFORM") & "%"
    '            btnrecupSanky1.Text = dt.Rows(0)("RECUP1_PERFORM") & "%"
    '            'txtRecup2.Text = dt.Rows(0)("RECUP2_PERFORM")
    '            btnRecup2.Text = dt.Rows(0)("RECUP2_PERFORM") & "%"
    '            btnrecupSanky2.Text = dt.Rows(0)("RECUP2_PERFORM") & "%"
    '            'txtRecup3.Text = dt.Rows(0)("RECUP3_PERFORM")
    '            btnRecup3.Text = dt.Rows(0)("RECUP3_PERFORM") & "%"
    '            btnrecupSanky3.Text = dt.Rows(0)("RECUP3_PERFORM") & "%"
    '            'txtHeatInput.Text = dt.Rows(0)("HEAT_INPUT")
    '            btnHeatInput.Text = dt.Rows(0)("HEAT_INPUT") & "%"
    '            btnHeatInputSanky.Text = dt.Rows(0)("HEAT_INPUT") & "%"
    '            'txtThroughPut.Text = dt.Rows(0)("THROUGHPUT")


    '            btnThroughPut.Text = dt.Rows(0)("THROUGHPUT")
    '            btnThroughPutSanky.Text = dt.Rows(0)("THROUGHPUT")
    '            'txtStockEntryTemp.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
    '            btnStockEntryTemp.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
    '            btnStockEbtryTempSanky.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
    '            'txtStockExitTemp.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
    '            btnStockExitTemp.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
    '            btnStockExitTempSanky.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
    '            'txtCoolingWaterLoss.Text = dt.Rows(0)("COOL_WT_LOSS")
    '            btnCoolingWaterLoss.Text = dt.Rows(0)("COOL_WT_LOSS")
    '            btnCoolingWaterLossSanky.Text = dt.Rows(0)("COOL_WT_LOSS")
    '            btnCoolingWaterLossPerc.Text = dt.Rows(0)("COOL_WT_LOSS_PERC") & "%"
    '            btnCoolingWaterLossPercSanky.Text = dt.Rows(0)("COOL_WT_LOSS_PERC") & "%"
    '            'txtFuelLoss.Text = dt.Rows(0)("FLUE_LOSS_PERC")

    '            btnFuelLossPerc.Text = dt.Rows(0)("FLUE_LOSS_PERC") & "%"
    '            btnFuelLossPrecSanky.Text = dt.Rows(0)("FLUE_LOSS_PERC") & "%"
    '            'txtHeatMaterial.Text = dt.Rows(0)("HEAT_MATERIAL")
    '            btnHeatMaterial.Text = dt.Rows(0)("HEAT_MATERIAL")
    '            btnHeatMaterialSanky.Text = dt.Rows(0)("HEAT_MATERIAL")

    '            btnHeatMaterialPerc.Text = dt.Rows(0)("HEAT_MAT_PERC") & "%"
    '            btnHeatMaterialpercSanky.Text = dt.Rows(0)("HEAT_MAT_PERC") & "%"
    '            'txtOpenLoss.Text = dt.Rows(0)("OPEN_LOSS")
    '            btnOpenLoss.Text = dt.Rows(0)("OPEN_LOSS")
    '            btnOpenLossSanky.Text = dt.Rows(0)("OPEN_LOSS")
    '            btnOpenLossPerc.Text = dt.Rows(0)("OPEN_LOSS_PERC") & "%"
    '            btnOpenLossPRECSanky.Text = dt.Rows(0)("OPEN_LOSS_PERC") & "%"
    '            'txtWallRoofLoss.Text = dt.Rows(0)("SKIN_LOSS_PERC")

    '            btnWallRoofLossPerc.Text = dt.Rows(0)("SKIN_LOSS_PERC") & "%"
    '            btnWallRoofLossPrecSanky.Text = dt.Rows(0)("SKIN_LOSS_PERC") & "%"
    '            'txtAirFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_CAL")
    '            btnAirFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_ONLINE") '("TOTAL_AIR_FLOW_CAL")
    '            btnAirFlowSanky.Text = dt.Rows(0)("TOTAL_GAS_FLOW_ONLINE") '("TOTAL_AIR_FLOW_CAL")
    '            'txtGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_CAL")
    '            btnGasFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_ONLINE") '("TOTAL_GAS_FLOW_CAL")
    '            btnGasFlowSanky.Text = dt.Rows(0)("TOTAL_AIR_FLOW_ONLINE") '("TOTAL_GAS_FLOW_CAL")
    '            'txtCV.Text = dt.Rows(0)("CV")
    '            btnCV.Text = dt.Rows(0)("CV")
    '            btnCvSanky.Text = dt.Rows(0)("CV")


    '        Else



    '            'txtHeatRecover1.Text = dt.Rows(0)("HEAT_RECOV1")
    '            btnHeatRecover1.Text = ""
    '            btnHeatRecoverySanky1.Text = ""
    '            'txtHeatRecover2.Text = dt.Rows(0)("HEAT_RECOV2")
    '            btnHeatRecover2.Text = ""
    '            btnHeatRecoverySanky2.Text = ""
    '            'txtHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3")
    '            btnHeatRecover3.Text = ""
    '            btnHeatRecoverySanky3.Text = ""
    '            'txtRecup1.Text = dt.Rows(0)("RECUP1_PERFORM")
    '            btnRecup1.Text = ""
    '            btnrecupSanky1.Text = ""
    '            'txtRecup2.Text = dt.Rows(0)("RECUP2_PERFORM")
    '            btnRecup2.Text = ""
    '            btnrecupSanky2.Text = ""
    '            'txtRecup3.Text = dt.Rows(0)("RECUP3_PERFORM")
    '            btnRecup3.Text = ""
    '            btnrecupSanky3.Text = ""
    '            'txtHeatInput.Text = dt.Rows(0)("HEAT_INPUT")
    '            btnHeatInput.Text = ""
    '            btnHeatInputSanky.Text = ""
    '            'txtThroughPut.Text = dt.Rows(0)("THROUGHPUT")


    '            btnThroughPut.Text = ""
    '            btnThroughPutSanky.Text = ""
    '            'txtStockEntryTemp.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
    '            btnStockEntryTemp.Text = ""
    '            btnStockEbtryTempSanky.Text = ""
    '            'txtStockExitTemp.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
    '            btnStockExitTemp.Text = ""
    '            btnStockExitTempSanky.Text = ""
    '            'txtCoolingWaterLoss.Text = dt.Rows(0)("COOL_WT_LOSS")
    '            btnCoolingWaterLoss.Text = ""
    '            btnCoolingWaterLossSanky.Text = ""
    '            btnCoolingWaterLossPerc.Text = ""
    '            btnCoolingWaterLossPercSanky.Text = ""
    '            'txtFuelLoss.Text = dt.Rows(0)("FLUE_LOSS_PERC")

    '            btnFuelLossPerc.Text = ""
    '            btnFuelLossPrecSanky.Text = ""
    '            'txtHeatMaterial.Text = dt.Rows(0)("HEAT_MATERIAL")
    '            btnHeatMaterial.Text = ""
    '            btnHeatMaterialSanky.Text = ""
    '            btnHeatMaterialPerc.Text = ""
    '            btnHeatMaterialpercSanky.Text = ""
    '            'txtOpenLoss.Text = dt.Rows(0)("OPEN_LOSS")
    '            btnOpenLoss.Text = ""
    '            btnOpenLossSanky.Text = ""
    '            btnOpenLossPerc.Text = ""
    '            btnOpenLossPRECSanky.Text = ""
    '            'txtWallRoofLoss.Text = dt.Rows(0)("SKIN_LOSS_PERC")

    '            btnWallRoofLossPerc.Text = ""
    '            btnWallRoofLossPrecSanky.Text = ""
    '            'txtAirFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_CAL")
    '            btnAirFlow.Text = ""
    '            btnAirFlowSanky.Text = ""
    '            'txtGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_CAL")
    '            btnGasFlow.Text = ""
    '            btnGasFlowSanky.Text = ""
    '            'txtCV.Text = dt.Rows(0)("CV")
    '            btnCV.Text = ""
    '            btnCvSanky.Text = ""

    '        End If
    '        '  Dim dtlabel As DataTable = objController.populatelabelValue()
    '        If dtlabel.Rows.Count > 0 Then

    '            'If dtavg.Rows.Count > 0 Then
    '            '    Dim AvgData = ""
    '            '    'Dim arrYValues(dtavg.Rows.Count) As Decimal
    '            '    '  arrYValues = (From row In dtlabel Select col = Decimal.Parse(row(Trim("SPC_FUEL_CON_ONLINE"))) Where "DATETIME" >= DateAdd(DateInterval.Hour, -1, DateTime.Now)) '.ToArray

    '            '    'arrYValues = dtavg.AsEnumerable.Where(Function(r) r.Field(Of DateTime)("Datetime") > DateTime.Now.AddHours(-1)).Select(Function(x) x.Field(Of Decimal)("SPC_FUEL_CON_ONLINE")).ToArray
    '            '    'arrYValues = (From row In dtlabel Select col = Decimal.Parse(row(Trim("SPC_FUEL_CON_ONLINE")).ToString()) Where DateTime > DateAdd(Hour, -1, GETDATE())).ToArray
    '            '    Dim arrYValues As Decimal = dtavg.AsEnumerable.Select(Function(x) x.Field(Of Decimal)("SPC_FUEL_CON_ONLINE")).Average()

    '            '    'Array.Sort(arrYValues)
    '            '    AvgData = arrYValues

    '            '    Dim d As Double
    '            '    'd = Math.Round(AvgData, 2)

    '            '    d = AvgData
    '            '    avgButtonOnline.Text = Math.Round(d, 3)
    '            'Else
    '            '    avgButtonOnline.Text = ""
    '            'End If

    '            BaseValueOnline.Text = dtlabel.Rows(0)("TOTAL_AIR_FUEL_RATIO")
    '            BaseValueRecommended.Text = dtlabel.Rows(0)("BASE_VALUE_RECOM")
    '            '=================================================
    '            '   HeatInputOnline.Text = dtlabel.Rows(0)("HEAT_INPUT")
    '            HeatInputCalculated.Text = dtlabel.Rows(0)("HEAT_INPUT")
    '            HeatInputRecommended.Text = dtlabel.Rows(0)("HEAT_INPUT_RECOM")
    '            '====================================================
    '            SpecificationOnline.Text = dtlabel.Rows(0)("SPC_FUEL_CON_ONLINE")
    '            SpecificationCalculated.Text = dtlabel.Rows(0)("SPC_FUEL_CON_CAL")
    '            SpecificationRecommended.Text = dtlabel.Rows(0)("SPEC_FUEL_CON_RECOM")
    '            '====================================================
    '            TotalGasFlowOnline.Text = dtlabel.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
    '            TotalGasFlowCalculated.Text = dtlabel.Rows(0)("TOTAL_GAS_FLOW_CAL")
    '            TotalGasFlowRecommended.Text = dtlabel.Rows(0)("TOTAL_GAS_FLOW_RECOM")
    '            '========================================================
    '            TotalAirFlowOnline.Text = dtlabel.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
    '            TotalAirFlowCalculated.Text = dtlabel.Rows(0)("TOTAL_AIR_FLOW_CAL")
    '            TotalAirFlowRecommended.Text = dtlabel.Rows(0)("TOTAL_AIR_FLOW_RECOM")
    '        Else
    '            BaseValueOnline.Text = ""
    '            BaseValueRecommended.Text = ""
    '            '=================================================
    '            '   HeatInputOnline.Text = dtlabel.Rows(0)("HEAT_INPUT")
    '            HeatInputCalculated.Text = ""
    '            HeatInputRecommended.Text = ""
    '            '====================================================
    '            SpecificationOnline.Text = ""
    '            SpecificationCalculated.Text = ""
    '            SpecificationRecommended.Text = ""
    '            '====================================================
    '            TotalGasFlowOnline.Text = ""
    '            TotalGasFlowCalculated.Text = ""
    '            TotalGasFlowRecommended.Text = ""
    '            '========================================================
    '            TotalAirFlowOnline.Text = ""
    '            TotalAirFlowCalculated.Text = ""
    '            TotalAirFlowRecommended.Text = ""
    '        End If
    '    End If


    '    If rdbtnLineB.Checked = True Then
    '        Session("checkboxval") = "B"
    '        ' DrawChartTop()
    '        If dtlineB.Rows.Count > 0 Then
    '            'txtHeatRecover1.Text = dtlineB.Rows(0)("HEAT_RECOV1")
    '            btnHeatRecover1.Text = dtlineB.Rows(0)("HEAT_RECOV1") & "%"
    '            btnHeatRecoverySanky1.Text = dtlineB.Rows(0)("HEAT_RECOV1") & "%"
    '            'txtHeatRecover2.Text = dtlineB.Rows(0)("HEAT_RECOV2")
    '            btnHeatRecover2.Text = dtlineB.Rows(0)("HEAT_RECOV2") & "%"
    '            btnHeatRecoverySanky2.Text = dtlineB.Rows(0)("HEAT_RECOV2") & "%"
    '            'txtHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3")
    '            btnHeatRecover3.Text = dtlineB.Rows(0)("HEAT_RECOV3") & "%"
    '            btnHeatRecoverySanky3.Text = dtlineB.Rows(0)("HEAT_RECOV3") & "%"
    '            'txtRecup1.Text = dtlineB.Rows(0)("RECUP1_PERFORM")
    '            btnRecup1.Text = dtlineB.Rows(0)("RECUP1_PERFORM") & "%"
    '            btnrecupSanky1.Text = dtlineB.Rows(0)("RECUP1_PERFORM") & "%"
    '            'txtRecup2.Text = dtlineB.Rows(0)("RECUP2_PERFORM")
    '            btnRecup2.Text = dtlineB.Rows(0)("RECUP2_PERFORM") & "%"
    '            btnrecupSanky2.Text = dtlineB.Rows(0)("RECUP2_PERFORM") & "%"
    '            'txtRecup3.Text = dtlineB.Rows(0)("RECUP3_PERFORM")
    '            btnRecup3.Text = dtlineB.Rows(0)("RECUP3_PERFORM") & "%"
    '            btnrecupSanky3.Text = dtlineB.Rows(0)("RECUP3_PERFORM") & "%"
    '            'txtHeatInput.Text = dtlineB.Rows(0)("HEAT_INPUT")
    '            btnHeatInput.Text = dtlineB.Rows(0)("HEAT_INPUT") & "%"
    '            btnHeatInputSanky.Text = dtlineB.Rows(0)("HEAT_INPUT") & "%"
    '            'txtThroughPut.Text = dtlineB.Rows(0)("THROUGHPUT")


    '            btnThroughPut.Text = dtlineB.Rows(0)("THROUGHPUT")
    '            btnThroughPutSanky.Text = dtlineB.Rows(0)("THROUGHPUT")
    '            'txtStockEntryTemp.Text = dtlineB.Rows(0)("STOCK_ENTRY_TEMP")
    '            btnStockEntryTemp.Text = dtlineB.Rows(0)("STOCK_ENTRY_TEMP")
    '            btnStockEbtryTempSanky.Text = dtlineB.Rows(0)("STOCK_ENTRY_TEMP")
    '            'txtStockExitTemp.Text = dtlineB.Rows(0)("STOCK_EXIT_TEMP")
    '            btnStockExitTemp.Text = dtlineB.Rows(0)("STOCK_EXIT_TEMP")
    '            btnStockExitTempSanky.Text = dtlineB.Rows(0)("STOCK_EXIT_TEMP")
    '            'txtCoolingWaterLoss.Text = dtlineB.Rows(0)("COOL_WT_LOSS")
    '            btnCoolingWaterLoss.Text = dtlineB.Rows(0)("COOL_WT_LOSS")
    '            btnCoolingWaterLossSanky.Text = dtlineB.Rows(0)("COOL_WT_LOSS")
    '            btnCoolingWaterLossPerc.Text = dtlineB.Rows(0)("COOL_WT_LOSS_PERC") & "%"
    '            btnCoolingWaterLossPercSanky.Text = dtlineB.Rows(0)("COOL_WT_LOSS_PERC") & "%"
    '            'txtFuelLoss.Text = dtlineB.Rows(0)("FLUE_LOSS_PERC")

    '            btnFuelLossPerc.Text = dtlineB.Rows(0)("FLUE_LOSS_PERC") & "%"
    '            btnFuelLossPrecSanky.Text = dtlineB.Rows(0)("FLUE_LOSS_PERC") & "%"
    '            'txtHeatMaterial.Text = dtlineB.Rows(0)("HEAT_MATERIAL")
    '            btnHeatMaterial.Text = dtlineB.Rows(0)("HEAT_MATERIAL")
    '            btnHeatMaterialSanky.Text = dtlineB.Rows(0)("HEAT_MATERIAL")
    '            btnHeatMaterialPerc.Text = dtlineB.Rows(0)("HEAT_MAT_PERC") & "%"
    '            btnHeatMaterialpercSanky.Text = dtlineB.Rows(0)("HEAT_MAT_PERC") & "%"
    '            'txtOpenLoss.Text = dtlineB.Rows(0)("OPEN_LOSS")
    '            btnOpenLoss.Text = dtlineB.Rows(0)("OPEN_LOSS")
    '            btnOpenLossSanky.Text = dtlineB.Rows(0)("OPEN_LOSS")
    '            btnOpenLossPerc.Text = dtlineB.Rows(0)("OPEN_LOSS_PERC") & "%"
    '            btnOpenLossPRECSanky.Text = dtlineB.Rows(0)("OPEN_LOSS_PERC") & "%"
    '            'txtWallRoofLoss.Text = dtlineB.Rows(0)("SKIN_LOSS_PERC")

    '            btnWallRoofLossPerc.Text = dtlineB.Rows(0)("SKIN_LOSS_PERC") & "%"
    '            btnWallRoofLossPrecSanky.Text = dtlineB.Rows(0)("SKIN_LOSS_PERC") & "%"
    '            'txtAirFlow.Text = dtlineB.Rows(0)("TOTAL_AIR_FLOW_CAL")
    '            btnAirFlow.Text = dtlineB.Rows(0)("TOTAL_GAS_FLOW_ONLINE") '("TOTAL_AIR_FLOW_CAL")
    '            btnAirFlowSanky.Text = dtlineB.Rows(0)("TOTAL_GAS_FLOW_ONLINE") '("TOTAL_AIR_FLOW_CAL")
    '            'txtGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_CAL")
    '            btnGasFlow.Text = dtlineB.Rows(0)("TOTAL_AIR_FLOW_ONLINE") '("TOTAL_GAS_FLOW_CAL")
    '            btnGasFlowSanky.Text = dtlineB.Rows(0)("TOTAL_AIR_FLOW_ONLINE") '("TOTAL_GAS_FLOW_CAL")
    '            'txtCV.Text = dtlineB.Rows(0)("CV")
    '            btnCV.Text = dtlineB.Rows(0)("CV")
    '            btnCvSanky.Text = dtlineB.Rows(0)("CV")
    '        Else

    '            'txtHeatRecover1.Text = dt.Rows(0)("HEAT_RECOV1")
    '            btnHeatRecover1.Text = ""
    '            btnHeatRecoverySanky1.Text = ""
    '            'txtHeatRecover2.Text = dt.Rows(0)("HEAT_RECOV2")
    '            btnHeatRecover2.Text = ""
    '            btnHeatRecoverySanky2.Text = ""
    '            'txtHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3")
    '            btnHeatRecover3.Text = ""
    '            btnHeatRecoverySanky3.Text = ""
    '            'txtRecup1.Text = dt.Rows(0)("RECUP1_PERFORM")
    '            btnRecup1.Text = ""
    '            btnrecupSanky1.Text = ""
    '            'txtRecup2.Text = dt.Rows(0)("RECUP2_PERFORM")
    '            btnRecup2.Text = ""
    '            btnrecupSanky2.Text = ""
    '            'txtRecup3.Text = dt.Rows(0)("RECUP3_PERFORM")
    '            btnRecup3.Text = ""
    '            btnrecupSanky3.Text = ""
    '            'txtHeatInput.Text = dt.Rows(0)("HEAT_INPUT")
    '            btnHeatInput.Text = ""
    '            btnHeatInputSanky.Text = ""
    '            'txtThroughPut.Text = dt.Rows(0)("THROUGHPUT")


    '            btnThroughPut.Text = ""
    '            btnThroughPutSanky.Text = ""
    '            'txtStockEntryTemp.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
    '            btnStockEntryTemp.Text = ""
    '            btnStockEbtryTempSanky.Text = ""
    '            'txtStockExitTemp.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
    '            btnStockExitTemp.Text = ""
    '            btnStockExitTempSanky.Text = ""
    '            'txtCoolingWaterLoss.Text = dt.Rows(0)("COOL_WT_LOSS")
    '            btnCoolingWaterLoss.Text = ""
    '            btnCoolingWaterLossSanky.Text = ""
    '            btnCoolingWaterLossPerc.Text = ""
    '            btnCoolingWaterLossPercSanky.Text = ""
    '            'txtFuelLoss.Text = dt.Rows(0)("FLUE_LOSS_PERC")

    '            btnFuelLossPerc.Text = ""
    '            btnFuelLossPrecSanky.Text = ""
    '            'txtHeatMaterial.Text = dt.Rows(0)("HEAT_MATERIAL")
    '            btnHeatMaterial.Text = ""
    '            btnHeatMaterialSanky.Text = ""
    '            btnHeatMaterialPerc.Text = ""
    '            btnHeatMaterialpercSanky.Text = ""
    '            'txtOpenLoss.Text = dt.Rows(0)("OPEN_LOSS")
    '            btnOpenLoss.Text = ""
    '            btnOpenLossSanky.Text = ""
    '            btnOpenLossPerc.Text = ""
    '            btnOpenLossPRECSanky.Text = ""
    '            'txtWallRoofLoss.Text = dt.Rows(0)("SKIN_LOSS_PERC")

    '            btnWallRoofLossPerc.Text = ""
    '            btnWallRoofLossPrecSanky.Text = ""
    '            'txtAirFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_CAL")
    '            btnAirFlow.Text = ""
    '            btnAirFlowSanky.Text = ""
    '            'txtGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_CAL")
    '            btnGasFlow.Text = ""
    '            btnGasFlowSanky.Text = ""
    '            'txtCV.Text = dt.Rows(0)("CV")
    '            btnCV.Text = ""
    '            btnCvSanky.Text = ""

    '        End If


    '        'Dim dtlabel As DataTable = objController.populatelabelValue()
    '        If dtlabelLineB.Rows.Count > 0 Then


    '            'If dtavglineb.Rows.Count > 0 Then
    '            '    Dim AvgData = ""
    '            '    'Dim arrYValues(dtavglineb.Rows.Count) As Decimal
    '            '    '  arrYValues = (From row In dtlabel Select col = Decimal.Parse(row(Trim("SPC_FUEL_CON_ONLINE"))) Where "DATETIME" >= DateAdd(DateInterval.Hour, -1, DateTime.Now)) '.ToArray

    '            '    'arrYValues = dtavglineb.AsEnumerable.Where(Function(r) r.Field(Of DateTime)("Datetime") > DateTime.Now.AddHours(-1)).Select(Function(x) x.Field(Of Decimal)("SPC_FUEL_CON_ONLINE")).ToArray
    '            '    'arrYValues = (From row In dtlabel Select col = Decimal.Parse(row(Trim("SPC_FUEL_CON_ONLINE")).ToString()) Where DateTime > DateAdd(Hour, -1, GETDATE())).ToArray
    '            '    Dim arrYValues As Decimal = dtavglineb.AsEnumerable.Select(Function(x) x.Field(Of Decimal)("SPC_FUEL_CON_ONLINE")).Average()

    '            '    'Array.Sort(arrYValues)
    '            '    AvgData = arrYValues

    '            '    Dim d As Double
    '            '    'd = Math.Round(AvgData, 2)

    '            '    d = AvgData
    '            '    avgButtonOnline.Text = Math.Round(d, 3)
    '            'Else
    '            '    avgButtonOnline.Text = ""
    '            'End If


    '            BaseValueOnline.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FUEL_RATIO")
    '            BaseValueRecommended.Text = dtlabelLineB.Rows(0)("BASE_VALUE_RECOM")
    '            '=================================================
    '            '   HeatInputOnline.Text = dtlabelLineB.Rows(0)("HEAT_INPUT")
    '            HeatInputCalculated.Text = dtlabelLineB.Rows(0)("HEAT_INPUT")
    '            HeatInputRecommended.Text = dtlabelLineB.Rows(0)("HEAT_INPUT_RECOM")
    '            '====================================================
    '            SpecificationOnline.Text = dtlabelLineB.Rows(0)("SPC_FUEL_CON_ONLINE")
    '            SpecificationCalculated.Text = dtlabelLineB.Rows(0)("SPC_FUEL_CON_CAL")
    '            SpecificationRecommended.Text = dtlabelLineB.Rows(0)("SPEC_FUEL_CON_RECOM")
    '            '====================================================
    '            TotalGasFlowOnline.Text = dtlabelLineB.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
    '            TotalGasFlowCalculated.Text = dtlabelLineB.Rows(0)("TOTAL_GAS_FLOW_CAL")
    '            TotalGasFlowRecommended.Text = dtlabelLineB.Rows(0)("TOTAL_GAS_FLOW_RECOM")
    '            '========================================================
    '            TotalAirFlowOnline.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
    '            TotalAirFlowCalculated.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FLOW_CAL")
    '            TotalAirFlowRecommended.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FLOW_RECOM")
    '        Else
    '            BaseValueOnline.Text = ""
    '            BaseValueRecommended.Text = ""
    '            '=================================================
    '            '   HeatInputOnline.Text = dtlabelLineB.Rows(0)("HEAT_INPUT")
    '            HeatInputCalculated.Text = ""
    '            HeatInputRecommended.Text = ""
    '            '====================================================
    '            SpecificationOnline.Text = ""
    '            SpecificationCalculated.Text = ""
    '            SpecificationRecommended.Text = ""
    '            '====================================================
    '            TotalGasFlowOnline.Text = ""
    '            TotalGasFlowCalculated.Text = ""
    '            TotalGasFlowRecommended.Text = ""
    '            '========================================================
    '            TotalAirFlowOnline.Text = ""
    '            TotalAirFlowCalculated.Text = ""
    '            TotalAirFlowRecommended.Text = ""

    '        End If
    '    End If


    '    If Session("ActiveIndex") = 1 Then
    '        MultiView1.ActiveViewIndex = 1
    '    End If

    'End Sub

    Protected Sub btn2DView_Click(sender As Object, e As EventArgs) Handles btn2DView.Click
        MultiView1.ActiveViewIndex = 0
        Session("ActiveIndex") = 0
        Try

            'Dim dSdate As DataSet = objdatahandler.GetDataSetFromQuery("select max(datetime) as DATETIME FROM  [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]")
            'Dim dtdate As DataTable = dSdate.Tables(0)

            Dim dSdate As DataTable = objController.PopulateMaxDatetime()

            'Dim dSdate As DataSet = objdatahandler.GetDataSetFromQuery("select max(datetime) as DATETIME FROM  [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]")

            '  Dim dtdate As DataTable = dSdate.Tables(0)
            Dim dtdate As DataTable = dSdate


            Dim ddtdate As DateTime = dtdate.Rows(0)("DATETIME")
            Dim frmDate As String = ddtdate.ToString("yyyy-MM-dd HH:mm:ss")
            Dim toDate As String = ddtdate.AddHours(-1).ToString("yyyy-MM-dd HH:mm:ss")
            Dim dt As DataTable = objController.PopulateDataForHeatDistributionModel()
            Dim dtlabel As DataTable = objController.populatelabelValue()
            '  Dim dtavg As DataTable = objController.PopulateAvgValuefromdt(frmDate, toDate)

            If rdbtnLineA.Checked = True Then
                Session("checkboxval") = "A"
                '  DrawChartTop()
                ''Code Commented Below Tirthankar 12-Jun-23
                ''lblforgrid_indicator.Text = "Table Grid Show LineA Values"
                ''End Code Comment Tirthankar 12-Jun-23
                If dt.Rows.Count > 0 Then
                    'txtHeatRecover1.Text = dt.Rows(0)("HEAT_RECOV1")
                    btnHeatRecover1.Text = dt.Rows(0)("HEAT_RECOV1") & "%"
                    'txtHeatRecover2.Text = dt.Rows(0)("HEAT_RECOV2")
                    'btnHeatRecover2.Text = dt.Rows(0)("HEAT_RECOV2") & "%"
                    'txtHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3")
                    'btnHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3") & "%"
                    'txtRecup1.Text = dt.Rows(0)("RECUP1_PERFORM")
                    btnRecup1.Text = dt.Rows(0)("RECUP1_PERFORM") & "%"
                    'txtRecup2.Text = dt.Rows(0)("RECUP2_PERFORM")
                    'btnRecup2.Text = dt.Rows(0)("RECUP2_PERFORM") & "%"
                    'txtRecup3.Text = dt.Rows(0)("RECUP3_PERFORM")
                    'btnRecup3.Text = dt.Rows(0)("RECUP3_PERFORM") & "%"
                    'txtHeatInput.Text = dt.Rows(0)("HEAT_INPUT")
                    btnHeatInput.Text = dt.Rows(0)("HEAT_INPUT") & ""
                    'txtThroughPut.Text = dt.Rows(0)("THROUGHPUT")


                    btnThroughPut.Text = dt.Rows(0)("THROUGHPUT")
                    'txtStockEntryTemp.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
                    btnStockEntryTemp.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
                    'txtStockExitTemp.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
                    btnStockExitTemp.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
                    'txtCoolingWaterLoss.Text = dt.Rows(0)("COOL_WT_LOSS")
                    btnCoolingWaterLoss.Text = dt.Rows(0)("COOL_WT_LOSS")
                    btnCoolingWaterLossPerc.Text = dt.Rows(0)("COOL_WT_LOSS_PERC") & "%"
                    'txtFuelLoss.Text = dt.Rows(0)("FLUE_LOSS_PERC")

                    btnFuelLossPerc.Text = dt.Rows(0)("FLUE_LOSS_PERC") & "%"
                    'txtHeatMaterial.Text = dt.Rows(0)("HEAT_MATERIAL")
                    btnHeatMaterial.Text = dt.Rows(0)("HEAT_MATERIAL")
                    btnHeatMaterialPerc.Text = dt.Rows(0)("HEAT_MAT_PERC") & "%"
                    'txtOpenLoss.Text = dt.Rows(0)("OPEN_LOSS")
                    btnOpenLoss.Text = dt.Rows(0)("OPEN_LOSS")
                    btnOpenLossPerc.Text = dt.Rows(0)("OPEN_LOSS_PERC") & "%"
                    'txtWallRoofLoss.Text = dt.Rows(0)("SKIN_LOSS_PERC")

                    btnWallRoofLossPerc.Text = dt.Rows(0)("SKIN_LOSS_PERC") & "%"
                    'txtAirFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_CAL")
                    btnAirFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
                    'txtGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_CAL")
                    btnGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
                    'txtCV.Text = dt.Rows(0)("CV")
                    'btnCV.Text = dt.Rows(0)("CV")
                    btnWobee.Text = dt.Rows(0)("CV")
                Else



                    'txtHeatRecover1.Text = dt.Rows(0)("HEAT_RECOV1")
                    btnHeatRecover1.Text = ""
                    'txtHeatRecover2.Text = dt.Rows(0)("HEAT_RECOV2")
                    'btnHeatRecover2.Text = ""
                    'txtHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3")
                    'btnHeatRecover3.Text = ""
                    'txtRecup1.Text = dt.Rows(0)("RECUP1_PERFORM")
                    btnRecup1.Text = ""
                    'txtRecup2.Text = dt.Rows(0)("RECUP2_PERFORM")
                    'btnRecup2.Text = ""
                    'txtRecup3.Text = dt.Rows(0)("RECUP3_PERFORM")
                    'btnRecup3.Text = ""
                    'txtHeatInput.Text = dt.Rows(0)("HEAT_INPUT")
                    btnHeatInput.Text = ""
                    'txtThroughPut.Text = dt.Rows(0)("THROUGHPUT")


                    btnThroughPut.Text = ""
                    'txtStockEntryTemp.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
                    btnStockEntryTemp.Text = ""
                    'txtStockExitTemp.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
                    btnStockExitTemp.Text = ""
                    'txtCoolingWaterLoss.Text = dt.Rows(0)("COOL_WT_LOSS")
                    btnCoolingWaterLoss.Text = ""
                    btnCoolingWaterLossPerc.Text = ""
                    'txtFuelLoss.Text = dt.Rows(0)("FLUE_LOSS_PERC")

                    btnFuelLossPerc.Text = ""
                    'txtHeatMaterial.Text = dt.Rows(0)("HEAT_MATERIAL")
                    btnHeatMaterial.Text = ""
                    btnHeatMaterialPerc.Text = ""
                    'txtOpenLoss.Text = dt.Rows(0)("OPEN_LOSS")
                    btnOpenLoss.Text = ""
                    btnOpenLossPerc.Text = ""
                    'txtWallRoofLoss.Text = dt.Rows(0)("SKIN_LOSS_PERC")

                    btnWallRoofLossPerc.Text = ""
                    'txtAirFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_CAL")
                    btnAirFlow.Text = ""
                    'txtGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_CAL")
                    btnGasFlow.Text = ""
                    'txtCV.Text = dt.Rows(0)("CV")
                    'btnCV.Text = ""
                    btnWobee.Text = ""

                End If

                'Dim dtlabel As DataTable = objController.populatelabelValue()
                If dtlabel.Rows.Count > 0 Then

                    'If dtavg.Rows.Count > 0 Then
                    '    Dim AvgData = ""
                    '    Dim arrYValues(dtavg.Rows.Count) As Decimal
                    '    '  arrYValues = (From row In dtlabel Select col = Decimal.Parse(row(Trim("SPC_FUEL_CON_ONLINE"))) Where "DATETIME" >= DateAdd(DateInterval.Hour, -1, DateTime.Now)) '.ToArray

                    '    arrYValues = dtavg.AsEnumerable.Where(Function(r) r.Field(Of DateTime)("Datetime") > DateTime.Now.AddHours(-1)).Select(Function(x) x.Field(Of Decimal)("SPC_FUEL_CON_ONLINE")).ToArray
                    '    'arrYValues = (From row In dtlabel Select col = Decimal.Parse(row(Trim("SPC_FUEL_CON_ONLINE")).ToString()) Where DateTime > DateAdd(Hour, -1, GETDATE())).ToArray


                    '    Array.Sort(arrYValues)
                    '    AvgData = arrYValues.Average

                    '    Dim d As Double
                    '    'd = Math.Round(AvgData, 2)

                    '    d = AvgData
                    '    avgButtonOnline.Text = Math.Round(d, 3)
                    'Else
                    '    avgButtonOnline.Text = ""
                    'End If

                    ''Code Commented Tirthankar 12-Jun-23
                    ''BaseValueOnline.Text = dtlabel.Rows(0)("TOTAL_AIR_FUEL_RATIO")
                    ''BaseValueRecommended.Text = dtlabel.Rows(0)("BASE_VALUE_RECOM")
                    '''=================================================
                    '''   HeatInputOnline.Text = dtlabel.Rows(0)("HEAT_INPUT")
                    ''HeatInputCalculated.Text = dtlabel.Rows(0)("HEAT_INPUT")
                    ''HeatInputRecommended.Text = dtlabel.Rows(0)("HEAT_INPUT_RECOM")
                    '''====================================================
                    ''SpecificationOnline.Text = dtlabel.Rows(0)("SPC_FUEL_CON_ONLINE")
                    ''SpecificationCalculated.Text = dtlabel.Rows(0)("SPC_FUEL_CON_CAL")
                    ''SpecificationRecommended.Text = dtlabel.Rows(0)("SPEC_FUEL_CON_RECOM")
                    '''====================================================
                    ''TotalGasFlowOnline.Text = dtlabel.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
                    ''TotalGasFlowCalculated.Text = dtlabel.Rows(0)("TOTAL_GAS_FLOW_CAL")
                    ''TotalGasFlowRecommended.Text = dtlabel.Rows(0)("TOTAL_GAS_FLOW_RECOM")
                    '''========================================================
                    ''TotalAirFlowOnline.Text = dtlabel.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
                    ''TotalAirFlowCalculated.Text = dtlabel.Rows(0)("TOTAL_AIR_FLOW_CAL")
                    ''TotalAirFlowRecommended.Text = dtlabel.Rows(0)("TOTAL_AIR_FLOW_RECOM")
                    ''End Code Comment Tirthankar 12-Jun-23
                Else
                    ''Code Commented Below Tirthankar 12-Jun-23
                    ''BaseValueOnline.Text = ""
                    ''BaseValueRecommended.Text = ""
                    '''=================================================
                    '''   HeatInputOnline.Text = dtlabel.Rows(0)("HEAT_INPUT")
                    ''HeatInputCalculated.Text = ""
                    ''HeatInputRecommended.Text = ""
                    '''====================================================
                    ''SpecificationOnline.Text = ""
                    ''SpecificationCalculated.Text = ""
                    ''SpecificationRecommended.Text = ""
                    '''====================================================
                    ''TotalGasFlowOnline.Text = ""
                    ''TotalGasFlowCalculated.Text = ""
                    ''TotalGasFlowRecommended.Text = ""
                    '''========================================================
                    ''TotalAirFlowOnline.Text = ""
                    ''TotalAirFlowCalculated.Text = ""
                    ''TotalAirFlowRecommended.Text = ""
                    ''End  Code comment on 12-Jun-23
                    ''End Code Comment Tirthankar 12-Jun-23
                End If

            End If
        Catch ex As Exception

        End Try




        If rdbtnLineB.Checked = True Then
            'MultiView1.ActiveViewIndex = 1
            Try

                'Dim dSdate As DataSet = objdatahandler.GetDataSetFromQuery("select max(datetime) as DATETIME FROM  [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]")
                'Dim dtdate As DataTable = dSdate.Tables(0)

                Dim dSdate As DataTable = objController.PopulateMaxDatetime()

                'Dim dSdate As DataSet = objdatahandler.GetDataSetFromQuery("select max(datetime) as DATETIME FROM  [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]")

                '  Dim dtdate As DataTable = dSdate.Tables(0)
                Dim dtdate As DataTable = dSdate


                Dim ddtdate As DateTime = dtdate.Rows(0)("DATETIME")
                Dim frmDate As String = ddtdate.ToString("yyyy-MM-dd HH:mm:ss")
                Dim toDate As String = ddtdate.AddHours(-1).ToString("yyyy-MM-dd HH:mm:ss")
                '===========lineb=====================
                Dim dtlineB As DataTable = objController.PopulateDataForHeatDistributionModelFORLINEB()
                Dim dtlabelLineB As DataTable = objController.populatelabelValueFORLINEB()
                ' Dim dtavg As DataTable = objController.PopulateAvgValuefromdt(frmDate, toDate)
                '  Dim dtavglineb As DataTable = objController.PopulateAvgValuefromdtLineb(frmDate, toDate)
                Dim dtavglineb As DataTable = objController.populatelabelValueForAvgLineB(frmDate, toDate)


                Session("checkboxval") = "B"
                '  DrawChartTop()
                ''Code Commented Below Tirthankar 12-Jun-23
                ''lblforgrid_indicator.Text = "Table Grid Show LineB Values"
                ''End Code Comment Tirthankar 12-Jun-23
                If dtlineB.Rows.Count > 0 Then
                    'txtHeatRecover1.Text = dtlineB.Rows(0)("HEAT_RECOV1")
                    btnHeatRecover1.Text = dtlineB.Rows(0)("HEAT_RECOV1") & "%"
                    'txtHeatRecover2.Text = dtlineB.Rows(0)("HEAT_RECOV2")
                    'btnHeatRecover2.Text = dtlineB.Rows(0)("HEAT_RECOV2") & "%"
                    'txtHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3")
                    'btnHeatRecover3.Text = dtlineB.Rows(0)("HEAT_RECOV3") & "%"
                    'txtRecup1.Text = dtlineB.Rows(0)("RECUP1_PERFORM")
                    btnRecup1.Text = dtlineB.Rows(0)("RECUP1_PERFORM") & "%"
                    'txtRecup2.Text = dtlineB.Rows(0)("RECUP2_PERFORM")
                    'btnRecup2.Text = dtlineB.Rows(0)("RECUP2_PERFORM") & "%"
                    'txtRecup3.Text = dtlineB.Rows(0)("RECUP3_PERFORM")
                    'btnRecup3.Text = dtlineB.Rows(0)("RECUP3_PERFORM") & "%"
                    'txtHeatInput.Text = dtlineB.Rows(0)("HEAT_INPUT")
                    btnHeatInput.Text = dtlineB.Rows(0)("HEAT_INPUT") & ""
                    'txtThroughPut.Text = dtlineB.Rows(0)("THROUGHPUT")


                    btnThroughPut.Text = dtlineB.Rows(0)("THROUGHPUT")
                    'txtStockEntryTemp.Text = dtlineB.Rows(0)("STOCK_ENTRY_TEMP")
                    btnStockEntryTemp.Text = dtlineB.Rows(0)("STOCK_ENTRY_TEMP")
                    'txtStockExitTemp.Text = dtlineB.Rows(0)("STOCK_EXIT_TEMP")
                    btnStockExitTemp.Text = dtlineB.Rows(0)("STOCK_EXIT_TEMP")
                    'txtCoolingWaterLoss.Text = dtlineB.Rows(0)("COOL_WT_LOSS")
                    btnCoolingWaterLoss.Text = dtlineB.Rows(0)("COOL_WT_LOSS")
                    btnCoolingWaterLossPerc.Text = dtlineB.Rows(0)("COOL_WT_LOSS_PERC") & "%"
                    'txtFuelLoss.Text = dtlineB.Rows(0)("FLUE_LOSS_PERC")

                    btnFuelLossPerc.Text = dtlineB.Rows(0)("FLUE_LOSS_PERC") & "%"
                    'txtHeatMaterial.Text = dtlineB.Rows(0)("HEAT_MATERIAL")
                    btnHeatMaterial.Text = dtlineB.Rows(0)("HEAT_MATERIAL")
                    btnHeatMaterialPerc.Text = dtlineB.Rows(0)("HEAT_MAT_PERC") & "%"
                    'txtOpenLoss.Text = dtlineB.Rows(0)("OPEN_LOSS")
                    btnOpenLoss.Text = dtlineB.Rows(0)("OPEN_LOSS")
                    btnOpenLossPerc.Text = dtlineB.Rows(0)("OPEN_LOSS_PERC") & "%"
                    'txtWallRoofLoss.Text = dtlineB.Rows(0)("SKIN_LOSS_PERC")

                    btnWallRoofLossPerc.Text = dtlineB.Rows(0)("SKIN_LOSS_PERC") & "%"
                    'txtAirFlow.Text = dtlineB.Rows(0)("TOTAL_AIR_FLOW_CAL")
                    btnAirFlow.Text = dtlineB.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
                    'txtGasFlow.Text = dtlineB.Rows(0)("TOTAL_GAS_FLOW_CAL")
                    btnGasFlow.Text = dtlineB.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
                    'txtCV.Text = dtlineB.Rows(0)("CV")
                    'btnCV.Text = dtlineB.Rows(0)("CV")
                    btnWobee.Text = dtlineB.Rows(0)("CV")
                Else

                    btnHeatRecover1.Text = " "
                    'txtHeatRecover2.Text = dtlineB.Rows(0)("HEAT_RECOV2")
                    'btnHeatRecover2.Text = " "
                    'txtHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3")
                    'btnHeatRecover3.Text = " "
                    'txtRecup1.Text = dtlineB.Rows(0)("RECUP1_PERFORM")
                    btnRecup1.Text = " "
                    'txtRecup2.Text = dtlineB.Rows(0)("RECUP2_PERFORM")
                    'btnRecup2.Text = " "
                    'txtRecup3.Text = dtlineB.Rows(0)("RECUP3_PERFORM")
                    'btnRecup3.Text = " "
                    'txtHeatInput.Text = dtlineB.Rows(0)("HEAT_INPUT")
                    btnHeatInput.Text = ""
                    'txtThroughPut.Text = dtlineB.Rows(0)("THROUGHPUT")


                    btnThroughPut.Text = ""
                    'txtStockEntryTemp.Text = dtlineB.Rows(0)("STOCK_ENTRY_TEMP")
                    btnStockEntryTemp.Text = ""
                    'txtStockExitTemp.Text = dtlineB.Rows(0)("STOCK_EXIT_TEMP")
                    btnStockExitTemp.Text = ""
                    'txtCoolingWaterLoss.Text = dtlineB.Rows(0)("COOL_WT_LOSS")
                    btnCoolingWaterLoss.Text = ""
                    btnCoolingWaterLossPerc.Text = "" 'COOL_WAT_LOSS
                    'txtFuelLoss.Text = dtlineB.Rows(0)("FLUE_LOSS_PERC")

                    btnFuelLossPerc.Text = ""
                    'txtHeatMaterial.Text = dtlineB.Rows(0)("HEAT_MATERIAL")
                    btnHeatMaterial.Text = ""
                    btnHeatMaterialPerc.Text = ""
                    'txtOpenLoss.Text = dtlineB.Rows(0)("OPEN_LOSS")
                    btnOpenLoss.Text = ""
                    btnOpenLossPerc.Text = ""
                    'txtWallRoofLoss.Text = dtlineB.Rows(0)("SKIN_LOSS_PERC")

                    btnWallRoofLossPerc.Text = ""
                    'txtAirFlow.Text = dtlineB.Rows(0)("TOTAL_AIR_FLOW_CAL")
                    btnAirFlow.Text = ""
                    'txtGasFlow.Text = dtlineB.Rows(0)("TOTAL_GAS_FLOW_CAL")
                    btnGasFlow.Text = ""
                    'txtCV.Text = dtlineB.Rows(0)("CV")
                    'btnCV.Text = ""
                    btnWobee.Text = ""
                End If





                'Dim dtlabel As DataTable = objController.populatelabelValue()
                If dtlabelLineB.Rows.Count > 0 Then

                    'If dtavglineb.Rows.Count > 0 Then
                    '    Dim AvgData = ""
                    '    Dim arrYValues(dtavglineb.Rows.Count) As Decimal
                    '    '  arrYValues = (From row In dtlabel Select col = Decimal.Parse(row(Trim("SPC_FUEL_CON_ONLINE"))) Where "DATETIME" >= DateAdd(DateInterval.Hour, -1, DateTime.Now)) '.ToArray

                    '    arrYValues = dtavglineb.AsEnumerable.Where(Function(r) r.Field(Of DateTime)("Datetime") > DateTime.Now.AddHours(-1)).Select(Function(x) x.Field(Of Decimal)("SPC_FUEL_CON_ONLINE")).ToArray
                    '    'arrYValues = (From row In dtlabel Select col = Decimal.Parse(row(Trim("SPC_FUEL_CON_ONLINE")).ToString()) Where DateTime > DateAdd(Hour, -1, GETDATE())).ToArray


                    '    Array.Sort(arrYValues)
                    '    AvgData = arrYValues.Average

                    '    Dim d As Double
                    '    'd = Math.Round(AvgData, 2)

                    '    d = AvgData
                    '    avgButtonOnline.Text = Math.Round(d, 3)
                    'Else
                    '    avgButtonOnline.Text = ""
                    'End If

                    ''Code commented below Tirthankar 12-Jun-23
                    ''BaseValueOnline.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FUEL_RATIO")
                    ''BaseValueRecommended.Text = dtlabelLineB.Rows(0)("BASE_VALUE_RECOM")
                    '''=================================================
                    '''   HeatInputOnline.Text = dtlabelLineB.Rows(0)("HEAT_INPUT")
                    ''HeatInputCalculated.Text = dtlabelLineB.Rows(0)("HEAT_INPUT")
                    ''HeatInputRecommended.Text = dtlabelLineB.Rows(0)("HEAT_INPUT_RECOM")
                    '''====================================================
                    ''SpecificationOnline.Text = dtlabelLineB.Rows(0)("SPC_FUEL_CON_ONLINE")
                    ''SpecificationCalculated.Text = dtlabelLineB.Rows(0)("SPC_FUEL_CON_CAL")
                    ''SpecificationRecommended.Text = dtlabelLineB.Rows(0)("SPEC_FUEL_CON_RECOM")
                    '''====================================================
                    ''TotalGasFlowOnline.Text = dtlabelLineB.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
                    ''TotalGasFlowCalculated.Text = dtlabelLineB.Rows(0)("TOTAL_GAS_FLOW_CAL")
                    ''TotalGasFlowRecommended.Text = dtlabelLineB.Rows(0)("TOTAL_GAS_FLOW_RECOM")
                    '''========================================================
                    ''TotalAirFlowOnline.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
                    ''TotalAirFlowCalculated.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FLOW_CAL")
                    ''TotalAirFlowRecommended.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FLOW_RECOM")


                Else
                    ''BaseValueOnline.Text = ""
                    ''BaseValueRecommended.Text = ""
                    '''=================================================
                    '''   HeatInputOnline.Text = dtlabelLineB.Rows(0)("HEAT_INPUT")
                    ''HeatInputCalculated.Text = ""
                    ''HeatInputRecommended.Text = ""
                    '''====================================================
                    ''SpecificationOnline.Text = ""
                    ''SpecificationCalculated.Text = ""
                    ''SpecificationRecommended.Text = ""
                    '''====================================================
                    ''TotalGasFlowOnline.Text = ""
                    ''TotalGasFlowCalculated.Text = ""
                    ''TotalGasFlowRecommended.Text = ""
                    '''========================================================
                    ''TotalAirFlowOnline.Text = ""
                    ''TotalAirFlowCalculated.Text = ""
                    ''TotalAirFlowRecommended.Text = ""
                    ''End Code commented below Tirthankar 12-Jun-23
                End If








            Catch ex As Exception

            End Try
        End If
        'rdbtnLineB_CheckedChanged()

    End Sub

    'Protected Sub btnSanky_Click(sender As Object, e As EventArgs) Handles btnSanky.Click
    '    MultiView1.ActiveViewIndex = 1
    '    Session("ActiveIndex") = 1
    'End Sub

    Protected Sub btnTCZoneTemp_Click(sender As Object, e As EventArgs) Handles btnTCZoneTemp.Click
        MultiView1.ActiveViewIndex = 1
        Session("ActiveIndex") = 1
    End Sub
    Protected Sub btnChartAndAnalysis_Click(sender As Object, e As EventArgs) Handles btnChartAndAnalysis.Click
        'MultiView1.ActiveViewIndex = 1
        'Session("ActiveIndex") = 1
        'Response.Redirect("Furnace_Equipment_Tracker.aspx")
        Dim url As String = "HSMFurnace_Equipment_Tracker.aspx"
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Page.ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "window.open('" & url & "','_newtab');", True)

    End Sub

    '===================Picture label ========================================================
    Private Sub btnHeatRecover1_click(sender As System.Object, e As System.EventArgs) Handles btnHeatRecover1.Click
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
        Session("checkLineChartParameters") = "HEAT_RECOV_PERC"
        Session("DateField") = "DATE_TIME"
        Dim url As String = "LineChartHSM.aspx"
        'btnHeatRecover1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub

    Protected Sub btnHeatRecovPerFluExit_Click(sender As Object, e As EventArgs) Handles btnHeatRecovPerFluExit.Click
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
        Session("checkLineChartParameters") = "HEAT_RECOV_PERC_FLUE_EXIT"
        Session("DateField") = "DATE_TIME"
        Dim url As String = "LineChartHSM.aspx"
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub


    'Private Sub btnHeatRecover2_click(sender As System.Object, e As System.EventArgs) Handles btnHeatRecover2.Click
    '    Session("checkLineChartParameters") = "HEAT_RECOV2"
    '    Dim url As String = "LineChart.aspx"
    '    'btnHeatRecover2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
    '    ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    'End Sub
    'Private Sub btnHeatRecover3_click(sender As System.Object, e As System.EventArgs) Handles btnHeatRecover3.Click
    '    Session("checkLineChartParameters") = "HEAT_RECOV3"
    '    Dim url As String = "LineChart.aspx"
    '    'btnHeatRecover3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
    '    ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    'End Sub

    Private Sub btnRecup1_click(sender As System.Object, e As System.EventArgs) Handles btnRecup1.Click
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
        Session("checkLineChartParameters") = "RECUP_PERF"
        Session("DateField") = "DATE_TIME"
        Dim url As String = "LineChartHSM.aspx"
        'btnRecup1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    'Private Sub btnRecup2_click(sender As System.Object, e As System.EventArgs) Handles btnRecup2.Click
    '    Session("checkLineChartParameters") = "RECUP2_PERFORM"
    '    Dim url As String = "LineChart.aspx"
    '    'btnRecup2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
    '    ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    'End Sub

    'Private Sub btnRecup3_click(sender As System.Object, e As System.EventArgs) Handles btnRecup3.Click
    '    Session("checkLineChartParameters") = "RECUP3_PERFORM"
    '    Dim url As String = "LineChart.aspx"
    '    'btnRecup3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
    '    ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    'End Sub

    Private Sub btnHeatInput_click(sender As System.Object, e As System.EventArgs) Handles btnHeatInput.Click
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
        Session("checkLineChartParameters") = "HEAT_INPUT"
        Session("DateField") = "DATE_TIME"
        Dim url As String = "LineChartHSM.aspx"
        'btnHeatInput.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Private Sub btnThroughPut_click(sender As System.Object, e As System.EventArgs) Handles btnThroughPut.Click
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_TPOH"
        Session("checkLineChartParameters") = "TPOH"
        Session("DateField") = "MSG_INSERT_DATE_TIME"
        Dim url As String = "LineChartHSM.aspx"
        'btnThroughPut.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub

    Private Sub btnStockEntryTemp_click(sender As System.Object, e As System.EventArgs) Handles btnStockEntryTemp.Click
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_TPOH"
        Session("checkLineChartParameters") = "SLAB_CHARG_TEMP"
        Session("DateField") = "MSG_INSERT_DATE_TIME"
        Dim url As String = "LineChartHSM.aspx"
        'btnStockEntryTemp.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Private Sub btnStockExitTemp_click(sender As System.Object, e As System.EventArgs) Handles btnStockExitTemp.Click
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_TPOH"
        Session("checkLineChartParameters") = "SLAB_DISCHARG_TEMP"
        Session("DateField") = "MSG_INSERT_DATE_TIME"
        Dim url As String = "LineChartHSM.aspx"
        'btnStockExitTemp.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Private Sub btnCoolingWaterLoss_click(sender As System.Object, e As System.EventArgs) Handles btnCoolingWaterLoss.Click
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
        Session("checkLineChartParameters") = "COOL_WAT_LOSS"
        Session("DateField") = "DATE_TIME"
        Dim url As String = "LineChartHSM.aspx"
        'btnCoolingWaterLoss.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Private Sub btnCoolingWaterLossPerc_click(sender As System.Object, e As System.EventArgs) Handles btnCoolingWaterLossPerc.Click
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
        Session("checkLineChartParameters") = "COOL_WAT_LOSS_PERC"
        Session("DateField") = "DATE_TIME"
        Dim url As String = "LineChartHSM.aspx"
        'btnCoolingWaterLossPerc.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnFlueLoss_Click(sender As Object, e As EventArgs) Handles btnFlueLoss.Click
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
        Session("checkLineChartParameters") = "FLUE_LOSS"
        Session("DateField") = "DATE_TIME"
        Dim url As String = "LineChartHSM.aspx"
        'btnFuelLossPerc.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub

    Private Sub btnFuelLossPerc_click(sender As System.Object, e As System.EventArgs) Handles btnFuelLossPerc.Click
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
        Session("checkLineChartParameters") = "FLUE_LOSS_PERC"
        Session("DateField") = "DATE_TIME"
        Dim url As String = "LineChartHSM.aspx"
        'btnFuelLossPerc.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Private Sub btnHeatMaterial_click(sender As System.Object, e As System.EventArgs) Handles btnHeatMaterial.Click
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_TPOH"
        Session("checkLineChartParameters") = "HEAT_MATER"
        Session("DateField") = "MSG_INSERT_DATE_TIME"
        Dim url As String = "LineChartHSM.aspx"
        'btnHeatMaterial.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Private Sub btnHeatMaterialPerc_click(sender As System.Object, e As System.EventArgs) Handles btnHeatMaterialPerc.Click
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
        Session("checkLineChartParameters") = "HEAT_MATE_PERC"
        Session("DateField") = "DATE_TIME"
        Dim url As String = "LineChartHSM.aspx"
        'btnHeatMaterialPerc.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Private Sub btnOpenLoss_click(sender As System.Object, e As System.EventArgs) Handles btnOpenLoss.Click
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
        Session("checkLineChartParameters") = "OPEN_LOSS"
        Session("DateField") = "DATE_TIME"
        Dim url As String = "LineChartHSM.aspx"
        'btnOpenLoss.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Private Sub btnOpenLossPerc_click(sender As System.Object, e As System.EventArgs) Handles btnOpenLossPerc.Click
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
        Session("checkLineChartParameters") = "OPEN_LOSS_PERC"
        Session("DateField") = "DATE_TIME"
        Dim url As String = "LineChartHSM.aspx"
        'btnOpenLossPerc.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Private Sub btnWallRoofLossPerc_click(sender As System.Object, e As System.EventArgs) Handles btnWallRoofLossPerc.Click
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
        Session("checkLineChartParameters") = "SKIN_LOSS_PERC"
        Session("DateField") = "DATE_TIME"
        Dim url As String = "LineChartHSM.aspx"
        'btnWallRoofLossPerc.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnWallRoofLoss_Click(sender As Object, e As EventArgs) Handles btnWallRoofLoss.Click
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_TPOH"
        Session("checkLineChartParameters") = "SKIN_LOSS"
        Session("DateField") = "MSG_INSERT_DATE_TIME"
        Dim url As String = "LineChartHSM.aspx"
        'btnWallRoofLossPerc.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Private Sub btnAirFlow_click(sender As System.Object, e As System.EventArgs) Handles btnAirFlow.Click
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
        Session("checkLineChartParameters") = "TOTAL_AIR_FLOW_ONLINE" '"TOTAL_AIR_FLOW_CAL"
        Session("DateField") = "DATE_TIME"
        Dim url As String = "LineChartHSM.aspx"
        'btnAirFlow.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Private Sub btnGasFlow_click(sender As System.Object, e As System.EventArgs) Handles btnGasFlow.Click
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
        Session("checkLineChartParameters") = "TOTAL_GAS_FLOW_ONLINE" '"TOTAL_GAS_FLOW_CAL"
        Session("DateField") = "DATE_TIME"
        Dim url As String = "LineChartHSM.aspx"
        'btnGasFlow.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    ''Function Commented below Tirthankar 12-Jun-23
    'Private Sub btnCV_click(sender As System.Object, e As System.EventArgs) Handles btnCV.Click
    '    Session("checkLineChartParameters") = "CV"
    '    Dim url As String = "LineChart.aspx"
    '    'btnCV.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
    '    ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    'End Sub
    ''End Function Comment Tirthankar 12-Jun-23

    ''Function Added below Tirthankar 12-Jun-23
    Private Sub btnWobee_Click(sender As Object, e As EventArgs) Handles btnWobee.Click
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
        Session("checkLineChartParameters") = "WOBBE"
        Session("DateField") = "DATE_TIME"
        Dim url As String = "LineChartHSM.aspx"
        'btnCV.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    ''End Function Tirthankar 12-Jun-23

    '=============================================================================================================



    'Private Sub BaseValueCalculated_Click(sender As System.Object, e As System.EventArgs) Handles BaseValueCalculated.Click

    '    Dim url As String = "BaseValueCal.aspx"
    '    BaseValueCalculated.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
    'End Sub
    ''Code Commented Below Tirthankar 12-Jun-23
    ''Private Sub BaseValueOnline_Click(sender As System.Object, e As System.EventArgs) Handles BaseValueOnline.Click

    ''    Dim url As String = "BaseValueCal.aspx"
    ''    'BaseValueOnline.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
    ''    ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    ''End Sub

    ''Protected Sub BaseValueRecommended_Click(sender As Object, e As EventArgs) Handles BaseValueRecommended.Click
    ''    Dim url As String = "BasicRecom_Value.aspx"
    ''    'BaseValueRecommended.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
    ''    ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    ''End Sub
    ''Protected Sub BaseValue_Click(sender As Object, e As EventArgs) Handles BaseValue.Click
    ''    Dim url As String = "Basic_Value_Ratio.aspx"
    ''    'BaseValue.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
    ''    ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    ''End Sub
    ''Protected Sub Heat_Input_Click(sender As Object, e As EventArgs) Handles Heat_Input.Click
    ''    Dim url As String = "Heat_Input.aspx"
    ''    'Heat_Input.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
    ''    ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    ''End Sub

    ''Protected Sub HeatInputCalculated_Click(sender As Object, e As EventArgs) Handles HeatInputCalculated.Click
    ''    Dim url As String = "HeatValueCal.aspx"
    ''    'HeatInputCalculated.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
    ''    ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    ''End Sub
    ''Protected Sub HeatInputRecommended_Click(sender As Object, e As EventArgs) Handles HeatInputRecommended.Click
    ''    Dim url As String = "Heat_Value_Recomm.aspx"
    ''    'HeatInputRecommended.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
    ''    ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    ''End Sub
    ''Protected Sub Specification_fuel_Click(sender As Object, e As EventArgs) Handles Specification_fuel.Click
    ''    Dim url As String = "Specification_Fuel_Con.aspx"
    ''    'Specification_fuel.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
    ''    ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    ''End Sub

    ''Protected Sub SpecificationOnline_Click(sender As Object, e As EventArgs) Handles SpecificationOnline.Click
    ''    Dim url As String = "Specification_Online.aspx"
    ''    'SpecificationOnline.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
    ''    ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    ''End Sub
    ''Protected Sub SpecificationCalculated_Click(sender As Object, e As EventArgs) Handles SpecificationCalculated.Click
    ''    Dim url As String = "Specification_Cal.aspx"
    ''    SpecificationCalculated.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
    ''    ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    ''End Sub

    ''Protected Sub SpecificationRecommended_Click(sender As Object, e As EventArgs) Handles SpecificationRecommended.Click
    ''    Dim url As String = "Specification_Recomm.aspx"
    ''    'SpecificationRecommended.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
    ''    ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    ''End Sub
    ''Protected Sub Total_Gas_Flow_Click(sender As Object, e As EventArgs) Handles Total_Gas_Flow.Click
    ''    Dim url As String = "Total_Gas_Flow_Value.aspx"
    ''    'Total_Gas_Flow.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
    ''    ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    ''End Sub
    ''Protected Sub TotalGasFlowOnline_Click(sender As Object, e As EventArgs) Handles TotalGasFlowOnline.Click
    ''    Dim url As String = "Total_Gas_Flow_Online.aspx"
    ''    'TotalGasFlowOnline.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
    ''    ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    ''End Sub
    ''Protected Sub TotalGasFlowCalculated_Click(sender As Object, e As EventArgs) Handles TotalGasFlowCalculated.Click
    ''    Dim url As String = "Total_Gas_Flow_Cal.aspx"
    ''    'TotalGasFlowCalculated.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
    ''    ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    ''End Sub
    ''Protected Sub TotalGasFlowRecommended_Click(sender As Object, e As EventArgs) Handles TotalGasFlowRecommended.Click
    ''    Dim url As String = "Total_Gas_Flow_Recomm.aspx"
    ''    'TotalGasFlowRecommended.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
    ''    ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    ''End Sub
    ''Protected Sub Total_Air_Flow_Click(sender As Object, e As EventArgs) Handles Total_Air_Flow.Click
    ''    Dim url As String = "Total_Air_Flow_Val.aspx"
    ''    'Total_Air_Flow.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
    ''    ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    ''End Sub
    ''Protected Sub TotalAirFlowOnline_Click(sender As Object, e As EventArgs) Handles TotalAirFlowOnline.Click
    ''    Dim url As String = "Total_Air_Flow_Online.aspx"
    ''    'TotalAirFlowOnline.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
    ''    ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    ''End Sub
    ''Protected Sub TotalAirFlowCalculated_Click(sender As Object, e As EventArgs) Handles TotalAirFlowCalculated.Click
    ''    Dim url As String = "Total_Air_Flow_Cal.aspx"
    ''    'TotalAirFlowCalculated.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
    ''    ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    ''End Sub
    ''Protected Sub TotalAirFlowRecommended_Click(sender As Object, e As EventArgs) Handles TotalAirFlowRecommended.Click
    ''    Dim url As String = "Total_Air_Flow_Recomm.aspx"
    ''    'TotalAirFlowRecommended.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
    ''    ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    ''End Sub
    ''''''''''''''''''''''''''''''''''''''BAR GRAPH Specific and Troughput''''''''''''''''''''''''''''''''''''''''''''''''''
    ''End Code Comment Tirthankar 12-Jun-23


    Sub DrawChartTop()
        Try

            Dim SELECT_LINE As String = Session("checkboxval")

            Dim dstemp As DataSet = objController.GetDataForSpecific_throughput(SELECT_LINE)
            ' objController.PopulateDataForHeatDistributionModel()

            ' Dim dstemp As DataSet = objController.GetDataForthisDateMonth(SELECT_LINE)
            PlotBarGraphSpecific_troughput(dstemp.Tables(0), Litral1, "container1", "plot1")



        Catch ex As Exception
            Throw ex
        End Try
    End Sub


    Sub DrawChartThisMonth()
        Try

            '  Dim frmDate As String = DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 6, 0, 0)
            Dim frmDate As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            Dim toDate As String = DateTime.Now.AddMonths(0).ToString("yyyy-MM-dd HH:mm:ss")

            Dim strfrmDt As String = frmDate
            Dim strToDt As String = toDate
            Dim SELECT_LINE As String = Session("checkboxval")

            Dim dstemp As DataSet = objController.GetDataForthisDateMonth(SELECT_LINE) 'frmDate, toDate(02/11/2021)
            ' objController.PopulateDataForHeatDistributionModel()
            dstemp.Tables(0).DefaultView.Sort = "Datetime ASC"
            ' Dim dt As DataTable = dstemp.Tables(0)

            PlotBarGraphSpecific_troughput(dstemp.Tables(0), Litral1, "container1", "plot1")



        Catch ex As Exception
            Throw ex
        End Try
    End Sub




    Sub DrawChartForLINEA()
        Try

            '  Dim frmDate As String = DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 6, 0, 0)
            Dim frmDate As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            Dim toDate As String = DateTime.Now.AddMonths(0).ToString("yyyy-MM-dd HH:mm:ss")

            Dim strfrmDt As String = frmDate
            Dim strToDt As String = toDate
            Dim SELECT_LINE As String = Session("checkboxval")
            ' If rbdChartLineA.Checked Then
            ''Code Commented Below Tirthankar 12-Jun-23
            ''If rbdChartAvgValue.Checked Then
            ''    Dim dstemp As DataSet = objController.GetDataForCHART_LINEA() 'frmDate, toDate(02/11/2021)
            ''    PlotBarGraphSpecific_troughput(dstemp.Tables(0), Litral1, "container1", "plot1")
            ''End If
            ''If rbdChartthisMonthValue.Checked Then
            ''    Dim dstemp As DataSet = objController.GetDataForCHART_LINEA_DAYWISE() 'frmDate, toDate(02/11/2021)
            ''    PlotBarGraphSpecific_troughput(dstemp.Tables(0), Litral1, "container1", "plot1")
            ''End If
            ''End Code Comment Tirthankar 12-Jun-23

        Catch ex As Exception
            Throw ex
        End Try


    End Sub
    Sub DrawChartForLINEB()
        Try

            '  Dim frmDate As String = DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 6, 0, 0)
            Dim frmDate As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            Dim toDate As String = DateTime.Now.AddMonths(0).ToString("yyyy-MM-dd HH:mm:ss")

            Dim strfrmDt As String = frmDate
            Dim strToDt As String = toDate
            Dim SELECT_LINE As String = Session("checkboxval")

            '  Dim dstemp As DataSet = objController.GetDataForCHART_LINEB() 'frmDate, toDate(02/11/2021)

            '    PlotBarGraphSpecific_troughput(dstemp.Tables(0), Litral1, "container1", "plot1")
            ''Code Commented Below Tirthankar 12-Jun-23
            ''If rbdChartAvgValue.Checked Then
            ''    Dim dstemp As DataSet = objController.GetDataForCHART_LINEB() 'frmDate, toDate(02/11/2021)
            ''    PlotBarGraphSpecific_troughput(dstemp.Tables(0), Litral1, "container1", "plot1")
            ''End If
            ''If rbdChartthisMonthValue.Checked Then
            ''    Dim dstemp As DataSet = objController.GetDataForCHART_LINEB_DAYWISE() 'frmDate, toDate(02/11/2021)
            ''    PlotBarGraphSpecific_troughput(dstemp.Tables(0), Litral1, "container1", "plot1")
            ''End If
            ''End Code Comment Tirthankar 12-Jun-23


        Catch ex As Exception
            Throw ex
        End Try


    End Sub


    'Sub DrawChartForLINEA_LINEB()
    '    Try

    '        '  Dim frmDate As String = DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 6, 0, 0)
    '        Dim frmDate As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
    '        Dim toDate As String = DateTime.Now.AddMonths(0).ToString("yyyy-MM-dd HH:mm:ss")

    '        Dim strfrmDt As String = frmDate
    '        Dim strToDt As String = toDate
    '        Dim SELECT_LINE As String = Session("checkboxval")

    '        'Dim dstemp As DataSet = objController.GetDataForCHART_LINEA_LINEB() 'frmDate, toDate(02/11/2021)

    '        'PlotBarGraphSpecific_troughput(dstemp.Tables(0), Litral1, "container1", "plot1")

    '        If rbdChartAvgValue.Checked Then
    '            Dim dstemp As DataSet = objController.GetDataForCHART_LINEA_LINEB() 'frmDate, toDate(02/11/2021)
    '            PlotBarGraphSpecific_troughput(dstemp.Tables(0), Litral1, "container1", "plot1")
    '        End If
    '        If rbdChartthisMonthValue.Checked Then
    '            Dim dstemp As DataSet = objController.GetDataForCHART_LINEA_LINEB_DAYWISE() 'frmDate, toDate(02/11/2021)
    '            PlotBarGraphSpecific_troughput(dstemp.Tables(0), Litral1, "container1", "plot1")
    '        End If



    '    Catch ex As Exception
    '        Throw ex
    '    End Try


    'End Sub
    Sub DrawChartForLINEA_LINEB()
        Try

            '  Dim frmDate As String = DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 6, 0, 0)
            Dim frmDate As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            'Dim toDate As String = DateTime.Now.AddMonths(0).ToString("yyyy-MM-dd HH:mm:ss")
            Dim Month As String = DateTime.Now.ToString("MM")
            Dim Year As String = DateTime.Now.ToString("yyyy")
            Dim firstdate As String = 1
            Dim toDate As String = Year & "-" & Month & "-" & firstdate

            Dim strfrmDt As String = frmDate
            Dim strToDt As String = toDate
            Dim SELECT_LINE As String = Session("checkboxval")

            'Dim dstemp As DataSet = objController.GetDataForCHART_LINEA_LINEB() 'frmDate, toDate(02/11/2021)

            'PlotBarGraphSpecific_troughput(dstemp.Tables(0), Litral1, "container1", "plot1")
            ''Code Commented Below Tirthankar 12-Jun-23
            ''If rbdChartAvgValue.Checked Then
            ''    Dim dstemp As DataSet = objController.GetDataForCHART_LINEA_LINEB()
            ''    Dim dsspec As DataSet = objController.GetDataForCHART_LINEA_LINEBspec()

            ''    'frmDate, toDate(02/11/2021)
            ''    DATAWISE_Chart_spec_and_throughput(dstemp.Tables(0), dsspec.Tables(0), Litral1, "container1", "plot1")
            ''End If
            ''If rbdChartthisMonthValue.Checked Then
            ''    Dim dstemp As DataSet = objController.GetDataForCHART_LINEA_LINEB_DAYWISE_Spec() 'frmDate, toDate(02/11/2021)
            ''    Dim dtthroughput As DataSet = objController.GetDataForCHART_LINEA_LINEB_DAYWISE_throughput()
            ''    DATAWISE_Chart_spec_and_throughput(dtthroughput.Tables(0), dstemp.Tables(0), Litral1, "container1", "plot1")
            ''    ' PlotBarGraphSpecific_troughput(dstemp.Tables(0), Litral1, "container1", "plot1")
            ''End If
            ''End Code Comment Tirthankar 12-Jun-23


        Catch ex As Exception
            Throw ex
        End Try


    End Sub
    Public Sub DATAWISE_Chart_spec_and_throughput(ByVal dt As DataTable, ByVal dt1 As DataTable, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String)
        Try
            LiteralName.Text = ""
            Dim ticks As String

            ' dt.DefaultView.Sort = "DAY asc"
            Dim line1, line2, line3 As String
            For i As Integer = 0 To dt1.Rows.Count - 1
                If i > 0 Then
                    ticks &= ","
                    line1 &= ","
                    'line2 &= ","
                    'line3 &= ","
                End If
                ticks &= "'" & dt1.Rows(i)(0) & "'"
                If IsDBNull(dt1.Rows(i)(1)) Then
                    line1 &= 0
                Else
                    line1 &= dt1.Rows(i)(1)
                End If
            Next

            For i As Integer = 0 To dt.Rows.Count - 1
                If i > 0 Then
                    '  ticks &= ","
                    'line1 &= ","
                    line2 &= ","
                    'line3 &= ","
                End If
                'ticks &= "'" & dt.Rows(i)(0) & "'"
                ' ticks &= "'" & dt.Rows(i)(0) & "'"
                If IsDBNull(dt.Rows(i)(1)) Then
                    line2 &= 0
                Else
                    line2 &= dt.Rows(i)(1)
                End If

            Next

            Dim s As New StringBuilder("<script>")

            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            s.Append("var myChart = echarts.init(document.getElementById('" & ContainerName & "'));")
            s.Append("option = {    tooltip: {   trigger: 'axis',  axisPointer: {   type: 'cross', crossStyle: {   color: '#999'  }  } },")
            s.Append("toolbox: {  feature: {  dataView: {show: true, readOnly: false},  magicType: {show: true, type: ['line', 'bar']},  restore: {show: true},  saveAsImage: {show: true}  }  },")
            s.Append("legend: {   data: ['Specific','Throughput'], left:'5%'  },")
            s.Append("xAxis: [ {  type: 'category',  data: [" & ticks & "],    axisPointer: { type: 'shadow'   }       }   ],   ")
            s.Append("yAxis: [  {   type: 'value', name: 'Specific',   min: 0,    max: 0.5,  axisLabel: {  formatter: '{value}'    }    },      {    type: 'value',         name: 'Throughput',      min: 0,        max: 500,    axisLabel: {            formatter: '{value}'        }        }   ],")
            s.Append("series: [  {   name: 'Specific',  type: 'bar',  data: [" & line1 & "]  },   {           name: 'Throughput',           type: 'bar',    yAxisIndex: 1, data: [" & line2 & "]")
            s.Append("}   ]};")

            s.Append(" myChart.setOption(option);")
            s.Append("</script>")
            LiteralName.Text = s.ToString()
        Catch ex As Exception
            Dim i As String = ""

        End Try

    End Sub




    'Public Sub PlotBarGraphSpecific_troughput(ByVal dt As DataTable, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String)
    '    Try
    '        LiteralName.Text = ""

    '        Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
    '             "$.jqplot.config.enablePlugins = true;" & vbCrLf
    '        Dim ticks As String = "["
    '        Dim line1, line2, line3 As String
    '        line1 &= "["
    '        line2 &= "["
    '        line3 &= "["
    '        Dim labels As String = "['SPC_FUEL_CON_ONLINE','THROUGHPUT']"
    '        For i As Integer = 0 To dt.Rows.Count - 1
    '            If i > 0 Then
    '                ticks &= ","
    '                line1 &= ","
    '                line2 &= ","
    '                'line3 &= ","
    '            End If
    '            ticks &= "'" & dt.Rows(i)(0) & "'"
    '            If IsDBNull(dt.Rows(i)(1)) Then
    '                line1 &= 0
    '            Else
    '                line1 &= dt.Rows(i)(1)
    '            End If
    '            If IsDBNull(dt.Rows(i)(2)) Then
    '                line2 &= 0
    '            Else
    '                line2 &= dt.Rows(i)(2)
    '            End If

    '            'line3 &= dt.Rows(i)("plt3")

    '        Next
    '        ticks &= "]"
    '        line1 &= "]"
    '        line2 &= "]"
    '        line3 &= "]"

    '        js &= "var ticks=" & ticks & ";"
    '        js &= "var pl1=" & line1 & ";"
    '        js &= "var pl2=" & line2 & ";"
    '        'js &= "var pl3=" & line3 & ";"

    '        js &= "var " & PlotName & " = $.jqplot('" & ContainerName & "', [pl1,pl2], {"
    '        js &= " captureRightClick: true,highlighter: {show: true,tooltipContentEditor: function (str, seriesIndex, pointIndex, plot) {var html = '<div>Month: ' + plot.options.axes.xaxis.ticks[pointIndex] + '<br/>Data: ' + Math.round(plot.data[seriesIndex][pointIndex]); return html;}},"
    '        js &= "seriesDefaults:{renderer:$.jqplot.BarRenderer, rendererOptions: {barMargin: 10,highlightMouseDown: true},pointLabels: {show: false}},"
    '        js &= "  axesDefaults: { tickRenderer: $.jqplot.CanvasAxisTickRenderer, tickOptions: {  angle: 30,fontSize:   '10pt' } },"
    '        js &= "seriesColors:['#0B62A4','#B62455','#4DA74D'],"
    '        js &= "axes: {"
    '        js &= "xaxis: { renderer: $.jqplot.CategoryAxisRenderer,ticks: " & ticks & "  },"
    '        js &= "yaxis: { min: -1.999, label:'',labelRenderer: $.jqplot.CanvasAxisLabelRenderer },"
    '        js &= "},legend: {show: true, location: 's',labels:" & labels & ",renderer: $.jqplot.EnhancedLegendRenderer,placement:  'outside',placement: 'outsideGrid',rendererOptions:{numberColumns:3}}});"
    '        js &= "</script>"
    '        LiteralName.Text = js

    '    Catch ex As Exception
    '        Dim i As String = ""

    '    End Try

    'End Sub
    Public Sub PlotBarGraphSpecific_troughput(ByVal dt As DataTable, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String)
        Try
            LiteralName.Text = ""
            Dim ticks As String

            ' dt.DefaultView.Sort = "DAY asc"
            Dim line1, line2, line3 As String
            For i As Integer = 0 To dt.Rows.Count - 1
                If i > 0 Then
                    ticks &= ","
                    line1 &= ","
                    line2 &= ","
                    'line3 &= ","
                End If
                ticks &= "'" & dt.Rows(i)(0) & "'"
                If IsDBNull(dt.Rows(i)(1)) Then
                    line1 &= 0
                Else
                    line1 &= dt.Rows(i)(1)
                End If
                If IsDBNull(dt.Rows(i)(2)) Then
                    line2 &= 0
                Else
                    line2 &= dt.Rows(i)(2)
                End If

            Next

            Dim s As New StringBuilder("<script>")

            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            s.Append("var myChart = echarts.init(document.getElementById('" & ContainerName & "'));")
            s.Append("option = {    tooltip: {   trigger: 'axis',  axisPointer: {   type: 'cross', crossStyle: {   color: '#999'  }  } },")
            s.Append("toolbox: {  feature: {  dataView: {show: true, readOnly: false},  magicType: {show: true, type: ['line', 'bar']},  restore: {show: true},  saveAsImage: {show: true}  }  },")
            s.Append("legend: {   data: ['Specific','Throughput'], left:'5%'  },")
            s.Append("xAxis: [ {  type: 'category',  data: [" & ticks & "],    axisPointer: { type: 'shadow'   }       }   ],   ")
            s.Append("yAxis: [  {   type: 'value', name: 'Specific',   min: 0,    max: 0.5,  axisLabel: {  formatter: '{value}'    }    },      {    type: 'value',         name: 'Throughput',      min: 0,        max: 500,    axisLabel: {            formatter: '{value}'        }        }   ],")
            s.Append("series: [  {   name: 'Specific',  type: 'bar',  data: [" & line1 & "]  },   {           name: 'Throughput',           type: 'bar',    yAxisIndex: 1, data: [" & line2 & "]")
            s.Append("}   ]};")

            s.Append(" myChart.setOption(option);")
            s.Append("</script>")
            LiteralName.Text = s.ToString()
        Catch ex As Exception
            Dim i As String = ""

        End Try

    End Sub

    Sub GETSPEC_TOTAL(ByVal FromDt As String, ByVal ToDt As String)
        Dim enDate As String = ToDt
        Dim stDate As String = FromDt

        Dim query As String = "Select CONVERT(VARCHAR(10),datetime,120) as datetime, [PRODUCTION], [ON_DATE], [TO_DATE],TOTAL_GAS_CON FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY]  " &
                                   "where DATETIME between '" & stDate & "' and '" & enDate & "' and PRODUCTION = 'HRC'    order by DATETIME asc"

        Dim count As Short = 0
        Dim getdt As DataTable = getdatatable(query)








        Dim lfcdec_query As String = "SELECT CONVERT(VARCHAR(10),datetime,120) as datetime,   CAST(ROUND(avg(CV), 2) AS DECIMAL(10,2)) as cv FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]  Where  DATETIME between '" & stDate & "' and '" & enDate & "' and cv is not null group by CONVERT(VARCHAR(10),datetime,120) 	order by CONVERT(VARCHAR(10),datetime,120) asc"

        Dim decisiondt As DataTable = getdatatable(lfcdec_query)

        Dim min As String = ""
        Dim max As String = ""
        Try
            If getdt.Rows.Count > 0 Then

                If decisiondt.Rows.Count > 0 Then
                    Dim query1 As String = "Select CONVERT(VARCHAR(10),datetime,120) as datetime, [PRODUCTION], [ON_DATE], [TO_DATE],TOTAL_GAS_CON FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY]  " &
                                   "where DATETIME between '" & stDate & "' and '" & enDate & "'   and PRODUCTION ='HRC' order by DATETIME asc"
                    Dim HRC As DataTable = getdatatable(query1)

                    For j As Integer = 0 To getdt.Rows.Count - 1
                        Try
                            Dim row As DataRow = decisiondt.Select("datetime='" & getdt.Rows(j)(0) & "'")(0)


                            Dim HRCDT As DataRow = HRC.Select("datetime='" & getdt.Rows(j)(0) & "'")(0)

                            If IsDBNull(getdt.Rows.Item(j)(4)) Or IsDBNull(getdt.Rows.Item(j)(2)) Then 'or replace from and  and getdt.rows.item(j)(2) from getdt.rows.item(j)(4)


                                '  TOTAL_SPEC &= "'" & getdt.Rows(j)(0).ToString & "',"
                                TOTAL_SPEC &= 0 & ","

                            Else

                                ' TOTAL_SPEC &= "'" & getdt.Rows(j)(0).ToString & "',"
                                Dim valhrc As Decimal = ((getdt.Rows.Item(j)(4) * row.Item(1)) / ((HRCDT.Item(2)) * 1000000))
                                Dim spe_totalhrc As Decimal = FormatNumber(valhrc, 4)




                                TOTAL_SPEC &= spe_totalhrc & ","
                            End If
                            ' End If
                            count += 1
                        Catch ex As Exception

                            TOTAL_SPEC &= "," '((getdt.Rows.Item(j)(4) * row.Item(1)) / ((HRCDT.Item(2)) * 1000000)) & ","

                            Continue For ' Throw ex
                        End Try
                    Next

                End If

            End If


        Catch ex As Exception
            Throw ex
        End Try



    End Sub





    Sub getdataForGrid_LineA()
        '===============================GridValue=================================================================================


        'lblforgriddatavalue.Text = "Abnormal LineA Roll Colling Water Tempreture"
        Dim DSDATE_FORGRID As DataTable = objController.PopulateMaxDatetime()

        Dim dtdateforgrid As DataTable = DSDATE_FORGRID

        Dim ddtdateforgrid As DateTime = CDate(dtdateforgrid.Rows(0)(0))
        Dim frmDateforgrid As String = ddtdateforgrid.ToString("yyyy-MM-dd HH:mm:ss")
        Dim toDateforgrid As String = ddtdateforgrid.AddHours(-1).ToString("yyyy-MM-dd HH:mm:ss")

        Dim dttablegrid As DataTable = objController.GetDataForLogDetailsLINEA(toDateforgrid, frmDateforgrid)

        Dim dv_forgrid As DataView = dttablegrid.DefaultView
        Try


            For i As Integer = 0 To dttablegrid.Rows.Count - 1
                Dim row As DataRow = dttablegrid.Rows(i)
                If row.Item(1) = 0 And row.Item(2) = 0 And row.Item(3) = 0 And row.Item(3) = 0 And row.Item(4) = 0 And row.Item(5) = 0 And row.Item(6) = 0 Then
                    dttablegrid.Rows(i).Delete()
                    'ElseIf row.Item(0).ToString.Trim = "" Then
                    '    dttablegrid.Rows.Remove(row)
                End If
            Next
        Catch ex As Exception
            ' Throw ex
        End Try
        dttablegrid.AcceptChanges()

        If dttablegrid.Rows.Count > 0 Then
            ''Code Commented Below Tirthankar 12-Jun-23
            ''lblforgriddatavalue.Text = "Abnormal LineA Roll Colling Water Tempreture"
            ''gvData.DataSource = dttablegrid
            ''gvData.DataBind()
            ''gvData.UseAccessibleHeader = True
            ''gvData.HeaderRow.TableSection = TableRowSection.TableHeader
            ''End Code Comment Tirthankar 12-Jun-23
            btnCoolingWaterLossPerc.BackColor = Color.Red
            btnCoolingWaterLoss.BackColor = Color.Red
        Else
            ''Code Commented Below Tirthankar 12-Jun-23
            ''gvData.DataSource = Nothing
            ''gvData.DataBind()
            ''End Code Comment Tirthankar 12-Jun-23
            btnCoolingWaterLossPerc.BackColor = Color.Yellow
            btnCoolingWaterLoss.BackColor = System.Drawing.ColorTranslator.FromHtml("#8CF02E")
        End If

    End Sub
    Sub getdataForGrid_LineB()
        '===============================GridValue=================================================================================


        Dim DSDATE_FORGRID As DataTable = objController.PopulateMaxDatetime()

        Dim dtdateforgrid As DataTable = DSDATE_FORGRID

        Dim ddtdateforgrid As DateTime = CDate(dtdateforgrid.Rows(0)(0))
        Dim frmDateforgrid As String = ddtdateforgrid.ToString("yyyy-MM-dd HH:mm:ss")
        Dim toDateforgrid As String = ddtdateforgrid.AddHours(-1).ToString("yyyy-MM-dd HH:mm:ss")

        Dim dttablegrid As DataTable = objController.GetDataForLogDetailsLineB(toDateforgrid, frmDateforgrid)

        Dim dv_forgrid As DataView = dttablegrid.DefaultView
        Try


            For i As Integer = 0 To dttablegrid.Rows.Count - 1
                Dim row As DataRow = dttablegrid.Rows(i)
                If row.Item(1) = 0 And row.Item(2) = 0 And row.Item(3) = 0 And row.Item(3) = 0 And row.Item(4) = 0 And row.Item(5) = 0 And row.Item(6) = 0 Then
                    dttablegrid.Rows(i).Delete()
                    'ElseIf row.Item(0).ToString.Trim = "" Then
                    '    dttablegrid.Rows.Remove(row)
                End If
            Next
        Catch ex As Exception
            ' Throw ex
        End Try
        dttablegrid.AcceptChanges()

        If dttablegrid.Rows.Count > 0 Then
            ''Code Commented Below Tirthankar 12-Jun-23
            ''lblforgriddatavalue.Text = "Abnormal LineB Roll Colling Water Tempreture"
            ''gvData.DataSource = dttablegrid
            ''gvData.DataBind()
            ''gvData.UseAccessibleHeader = True
            ''gvData.HeaderRow.TableSection = TableRowSection.TableHeader
            ''End Code Comment Tirthankar 12-Jun-23
            btnCoolingWaterLossPerc.BackColor = Color.Red
            btnCoolingWaterLoss.BackColor = Color.Red
        Else
            ''Code Commented Below Tirthankar 12-Jun-23
            ''gvData.DataSource = Nothing
            ''gvData.DataBind()
            ''End Code Comment Tirthankar 12-Jun-23
            btnCoolingWaterLossPerc.BackColor = Color.Yellow
            btnCoolingWaterLoss.BackColor = System.Drawing.ColorTranslator.FromHtml("#8CF02E")

        End If

    End Sub

    ''Code Commented Below Tirthankar 12-Jun-23

    ''Private Sub gvData_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles gvData.RowDataBound
    ''    If e.Row.RowType = DataControlRowType.DataRow Then
    ''        If DataBinder.Eval(e.Row.DataItem, "ABN_INLET_TEMP_MIN") = 0 Then
    ''            CType(e.Row.FindControl("lblABN_INLET_TEMP_MIN"), Label).Text = ""
    ''        End If

    ''        If DataBinder.Eval(e.Row.DataItem, "ABN_INLET_TEMP_MAX") = 0 Then
    ''            CType(e.Row.FindControl("lblABN_INLET_TEMP_MAX"), Label).Text = ""
    ''        End If

    ''        If DataBinder.Eval(e.Row.DataItem, "ABN_DELTA_T_MIN") = 0 Then
    ''            CType(e.Row.FindControl("lblABN_DELTA_T_MIN"), Label).Text = ""
    ''        End If

    ''        If DataBinder.Eval(e.Row.DataItem, "ABN_DELTA_T_MAX") = 0 Then
    ''            CType(e.Row.FindControl("lblABN_DELTA_T_MAX"), Label).Text = ""
    ''        End If

    ''        If DataBinder.Eval(e.Row.DataItem, "ABN_OUTLET_TEMP_MIN") = 0 Then
    ''            CType(e.Row.FindControl("lblABN_OUTLET_TEMP_MIN"), Label).Text = ""
    ''        End If

    ''        If DataBinder.Eval(e.Row.DataItem, "ABN_OUTLET_TEMP_MAX") = 0 Then
    ''            CType(e.Row.FindControl("lblABN_OUTLET_TEMP_MAX"), Label).Text = ""
    ''        End If
    ''    End If
    ''End Sub

    ''End Code Comment Tirthankar 12-Jun-23
    Public Function GetTempZoneWise(ByVal Line As String, ByVal ColName As String, ByVal StartTime As String, ByVal EndTime As String)
        Dim sqlQuery As String = "Select TIMESTAMP,LINE," & ColName & " From TSCR_FURNACE_ZONE_TEMP Where LINE = '" & Line & "'"
        sqlQuery &= " AND TIMESTAMP BETWEEN '" & StartTime & "' AND '" & EndTime & "'"
        Dim dt As DataTable = getdatatable(sqlQuery)
    End Function
    Protected Sub btnZ1TC1_Click(sender As Object, e As EventArgs) Handles btnZ1TC1.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE1_TC1"
        Dim Zone As String = "ZONE - 1"
        Dim TC As String = "TC- 1"
        'Dim dtStart As String = DateTime.Now.AddHours(-1).ToString("yyyy-MM-dd HH:mm")
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ1TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        'Dim s As String = "window.open('TSK_Chart_UTS_YS.aspx?CoilId=" & coilid & "&Value=" & Value & "&UTSMin=" & UTS_Min & "&UTSMax=" & UTS_Max & "&YSMin=" & YS_Min & "&YSMax=" & YS_Max & "','_blank');"
        'Page.ClientScript.RegisterStartupScript(Me.GetType(), "alertscript", s, True)

    End Sub
    Protected Sub btnZ1TC2_Click(sender As Object, e As EventArgs) Handles btnZ1TC2.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE1_TC2"
        Dim Zone As String = "ZONE - 1"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ1TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ1TC3_Click(sender As Object, e As EventArgs) Handles btnZ1TC3.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE1_TC3"
        Dim Zone As String = "ZONE - 1"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ1TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ2TC1_Click(sender As Object, e As EventArgs) Handles btnZ2TC1.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE2_TC1"
        Dim Zone As String = "ZONE - 2"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ2TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ2TC2_Click(sender As Object, e As EventArgs) Handles btnZ2TC2.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE2_TC2"
        Dim Zone As String = "ZONE - 2"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ2TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ2TC3_Click(sender As Object, e As EventArgs) Handles btnZ2TC3.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE2_TC3"
        Dim Zone As String = "ZONE - 2"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ2TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ3TC1_Click(sender As Object, e As EventArgs) Handles btnZ3TC1.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE3_TC1"
        Dim Zone As String = "ZONE - 3"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ3TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ3TC2_Click(sender As Object, e As EventArgs) Handles btnZ3TC2.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE3_TC2"
        Dim Zone As String = "ZONE - 3"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ3TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ3TC3_Click(sender As Object, e As EventArgs) Handles btnZ3TC3.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE3_TC3"
        Dim Zone As String = "ZONE - 3"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ3TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ4TC1_Click(sender As Object, e As EventArgs) Handles btnZ4TC1.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE4_TC1"
        Dim Zone As String = "ZONE - 4"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ4TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ4TC2_Click(sender As Object, e As EventArgs) Handles btnZ4TC2.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE4_TC2"
        Dim Zone As String = "ZONE - 4"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ4TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ4TC3_Click(sender As Object, e As EventArgs) Handles btnZ4TC3.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE4_TC3"
        Dim Zone As String = "ZONE - 4"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ4TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ5TC1_Click(sender As Object, e As EventArgs) Handles btnZ5TC1.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE5_TC1"
        Dim Zone As String = "ZONE - 5"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ5TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ5TC2_Click(sender As Object, e As EventArgs) Handles btnZ5TC2.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE5_TC2"
        Dim Zone As String = "ZONE - 5"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ5TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ5TC3_Click(sender As Object, e As EventArgs) Handles btnZ5TC3.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE5_TC3"
        Dim Zone As String = "ZONE - 5"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ5TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ6TC1_Click(sender As Object, e As EventArgs) Handles btnZ6TC1.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE6_TC1"
        Dim Zone As String = "ZONE - 6"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ6TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ6TC2_Click(sender As Object, e As EventArgs) Handles btnZ6TC2.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE6_TC2"
        Dim Zone As String = "ZONE - 6"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ6TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ6TC3_Click(sender As Object, e As EventArgs) Handles btnZ6TC3.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE6_TC3"
        Dim Zone As String = "ZONE - 6"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ6TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ7TC1_Click(sender As Object, e As EventArgs) Handles btnZ7TC1.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE7_TC1"
        Dim Zone As String = "ZONE - 7"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ7TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ7TC2_Click(sender As Object, e As EventArgs) Handles btnZ7TC2.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE7_TC2"
        Dim Zone As String = "ZONE - 7"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ7TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ7TC3_Click(sender As Object, e As EventArgs) Handles btnZ7TC3.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE7_TC3"
        Dim Zone As String = "ZONE - 7"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ7TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ8TC1_Click(sender As Object, e As EventArgs) Handles btnZ8TC1.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE8_TC1"
        Dim Zone As String = "ZONE - 8"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ8TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ8TC2_Click(sender As Object, e As EventArgs) Handles btnZ8TC2.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE8_TC2"
        Dim Zone As String = "ZONE - 8"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ8TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ8TC3_Click(sender As Object, e As EventArgs) Handles btnZ8TC3.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE8_TC3"
        Dim Zone As String = "ZONE - 8"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ8TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ9TC1_Click(sender As Object, e As EventArgs) Handles btnZ9TC1.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE9_TC1"
        Dim Zone As String = "ZONE - 9"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ9TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ9TC2_Click(sender As Object, e As EventArgs) Handles btnZ9TC2.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE9_TC2"
        Dim Zone As String = "ZONE - 9"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ9TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ9TC3_Click(sender As Object, e As EventArgs) Handles btnZ9TC3.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE9_TC3"
        Dim Zone As String = "ZONE - 9"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ9TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ1Avg_Click(sender As Object, e As EventArgs) Handles btnZ1Avg.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "(ZONE1_TC1+ZONE1_TC2+ZONE1_TC3)/3"
        Dim Zone As String = "ZONE - 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"
        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ1Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ2Avg_Click(sender As Object, e As EventArgs) Handles btnZ2Avg.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "(ZONE2_TC1+ZONE2_TC2+ZONE2_TC3)/3"
        Dim Zone As String = "ZONE - 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ2Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ3Avg_Click(sender As Object, e As EventArgs) Handles btnZ3Avg.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "(ZONE3_TC1+ZONE3_TC2+ZONE3_TC3)/3"
        Dim Zone As String = "ZONE - 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ3Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ4Avg_Click(sender As Object, e As EventArgs) Handles btnZ4Avg.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "(ZONE4_TC1+ZONE4_TC2+ZONE4_TC3)/3"
        Dim Zone As String = "ZONE - 4"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ4Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ5Avg_Click(sender As Object, e As EventArgs) Handles btnZ5Avg.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "(ZONE5_TC1+ZONE5_TC2+ZONE5_TC3)/3"
        Dim Zone As String = "ZONE - 5"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ5Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ6Avg_Click(sender As Object, e As EventArgs) Handles btnZ6Avg.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "(ZONE6_TC1+ZONE6_TC2+ZONE6_TC3)/3"
        Dim Zone As String = "ZONE - 6"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ6Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ7Avg_Click(sender As Object, e As EventArgs) Handles btnZ7Avg.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "(ZONE7_TC1+ZONE7_TC2+ZONE7_TC3)/3"
        Dim Zone As String = "ZONE - 7"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ7Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ8Avg_Click(sender As Object, e As EventArgs) Handles btnZ8Avg.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "(ZONE8_TC1+ZONE8_TC2+ZONE8_TC3)/3"
        Dim Zone As String = "ZONE - 8"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ8Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ9Avg_Click(sender As Object, e As EventArgs) Handles btnZ9Avg.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "(ZONE9_TC1+ZONE9_TC2+ZONE9_TC3)/3"
        Dim Zone As String = "ZONE - 9"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ9Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub

    Protected Sub btnLBZ1TC1_Click(sender As Object, e As EventArgs) Handles btnLBZ1TC1.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE1_TC1"
        Dim Zone As String = "ZONE - 1"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ1TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ1TC2_Click(sender As Object, e As EventArgs) Handles btnLBZ1TC2.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE1_TC2"
        Dim Zone As String = "ZONE - 1"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ1TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ1TC3_Click(sender As Object, e As EventArgs) Handles btnLBZ1TC3.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE1_TC3"
        Dim Zone As String = "ZONE - 1"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ1TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ2TC1_Click(sender As Object, e As EventArgs) Handles btnLBZ2TC1.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE2_TC1"
        Dim Zone As String = "ZONE - 2"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ2TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ2TC2_Click(sender As Object, e As EventArgs) Handles btnLBZ2TC2.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE2_TC2"
        Dim Zone As String = "ZONE - 2"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ2TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ2TC3_Click(sender As Object, e As EventArgs) Handles btnLBZ2TC3.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE2_TC3"
        Dim Zone As String = "ZONE - 2"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ2TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ3TC1_Click(sender As Object, e As EventArgs) Handles btnLBZ3TC1.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE3_TC1"
        Dim Zone As String = "ZONE - 3"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ3TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ3TC2_Click(sender As Object, e As EventArgs) Handles btnLBZ3TC2.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE3_TC2"
        Dim Zone As String = "ZONE - 3"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ3TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub

    Protected Sub btnLBZ3TC3_Click(sender As Object, e As EventArgs) Handles btnLBZ3TC3.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE3_TC3"
        Dim Zone As String = "ZONE - 3"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ3TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ4TC1_Click(sender As Object, e As EventArgs) Handles btnLBZ4TC1.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE4_TC1"
        Dim Zone As String = "ZONE - 4"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ4TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ4TC2_Click(sender As Object, e As EventArgs) Handles btnLBZ4TC2.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE4_TC2"
        Dim Zone As String = "ZONE - 4"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ4TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ4TC3_Click(sender As Object, e As EventArgs) Handles btnLBZ4TC3.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE4_TC3"
        Dim Zone As String = "ZONE - 4"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ4TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ5TC1_Click(sender As Object, e As EventArgs) Handles btnLBZ5TC1.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE5_TC1"
        Dim Zone As String = "ZONE - 5"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ5TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ5TC2_Click(sender As Object, e As EventArgs) Handles btnLBZ5TC2.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE5_TC2"
        Dim Zone As String = "ZONE - 5"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ5TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub

    Protected Sub btnLBZ5TC3_Click(sender As Object, e As EventArgs) Handles btnLBZ5TC3.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE5_TC3"
        Dim Zone As String = "ZONE - 5"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ5TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ6TC1_Click(sender As Object, e As EventArgs) Handles btnLBZ6TC1.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE6_TC1"
        Dim Zone As String = "ZONE - 6"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ6TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ6TC2_Click(sender As Object, e As EventArgs) Handles btnLBZ6TC2.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE6_TC2"
        Dim Zone As String = "ZONE - 6"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ6TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ6TC3_Click(sender As Object, e As EventArgs) Handles btnLBZ6TC3.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE6_TC3"
        Dim Zone As String = "ZONE - 6"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ6TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub

    Protected Sub btnLBZ7TC1_Click(sender As Object, e As EventArgs) Handles btnLBZ7TC1.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE7_TC1"
        Dim Zone As String = "ZONE - 7"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ7TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ7TC2_Click(sender As Object, e As EventArgs) Handles btnLBZ7TC2.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE7_TC2"
        Dim Zone As String = "ZONE - 7"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ7TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ7TC3_Click(sender As Object, e As EventArgs) Handles btnLBZ7TC3.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE7_TC3"
        Dim Zone As String = "ZONE - 7"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ7TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ8TC1_Click(sender As Object, e As EventArgs) Handles btnLBZ8TC1.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE8_TC1"
        Dim Zone As String = "ZONE - 8"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ8TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ8TC2_Click(sender As Object, e As EventArgs) Handles btnLBZ8TC2.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE8_TC2"
        Dim Zone As String = "ZONE - 8"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ8TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ8TC3_Click(sender As Object, e As EventArgs) Handles btnLBZ8TC3.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE8_TC3"
        Dim Zone As String = "ZONE - 8"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ8TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub

    Protected Sub btnLBZ1Avg_Click(sender As Object, e As EventArgs) Handles btnLBZ1Avg.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "(ZONE1_TC1+ZONE1_TC2+ZONE1_TC3)/3"
        Dim Zone As String = "ZONE - 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ1Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ2Avg_Click(sender As Object, e As EventArgs) Handles btnLBZ2Avg.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "(ZONE2_TC1+ZONE2_TC2+ZONE2_TC3)/3"
        Dim Zone As String = "ZONE - 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ2Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ3Avg_Click(sender As Object, e As EventArgs) Handles btnLBZ3Avg.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "(ZONE3_TC1+ZONE3_TC2+ZONE3_TC3)/3"
        Dim Zone As String = "ZONE - 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ3Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ4Avg_Click(sender As Object, e As EventArgs) Handles btnLBZ4Avg.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "(ZONE4_TC1+ZONE4_TC2+ZONE4_TC3)/3"
        Dim Zone As String = "ZONE - 4"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ4Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ5Avg_Click(sender As Object, e As EventArgs) Handles btnLBZ5Avg.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "(ZONE5_TC1+ZONE5_TC2+ZONE5_TC3)/3"
        Dim Zone As String = "ZONE - 5"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ5Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ6Avg_Click(sender As Object, e As EventArgs) Handles btnLBZ6Avg.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "(ZONE6_TC1+ZONE6_TC2+ZONE6_TC3)/3"
        Dim Zone As String = "ZONE - 6"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ6Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ7Avg_Click(sender As Object, e As EventArgs) Handles btnLBZ7Avg.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "(ZONE7_TC1+ZONE7_TC2+ZONE7_TC3)/3"
        Dim Zone As String = "ZONE - 7"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ7Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ8Avg_Click(sender As Object, e As EventArgs) Handles btnLBZ8Avg.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "(ZONE8_TC1+ZONE8_TC2+ZONE8_TC3)/3"
        Dim Zone As String = "ZONE - 8"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ8Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub

    Protected Sub btnDSHistLA_Click(sender As Object, e As EventArgs) Handles btnDSHistLA.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE1_TC1,ZONE1_TC3,ZONE2_TC2,ZONE3_TC1,ZONE3_TC3,ZONE4_TC2,ZONE5_TC2,ZONE6_TC2,ZONE7_TC2,ZONE8_TC2,ZONE9_TC1,ZONE9_TC3"
        Dim Zone As String = "HistDataLineADrive"
        'Dim TC As String = "HistDataLineADrive"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        Dim url As String = "ZoneTempLineChart.aspx"
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone '& "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnOSHistLA_Click(sender As Object, e As EventArgs) Handles btnOSHistLA.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE1_TC2,ZONE2_TC1,ZONE2_TC3,ZONE3_TC2,ZONE4_TC1,ZONE4_TC3,ZONE5_TC1,ZONE5_TC3,ZONE6_TC1,ZONE6_TC3,ZONE7_TC1,ZONE7_TC3,ZONE8_TC1,ZONE8_TC3,ZONE9_TC2"
        Dim Zone As String = "HistDataLineAOS"
        'Dim TC As String = "HistDataLineADrive"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        Dim url As String = "ZoneTempLineChart.aspx"
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone '& "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnBothHistLA_Click(sender As Object, e As EventArgs) Handles btnBothHistLA.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE1_TC1,ZONE1_TC3,ZONE2_TC2,ZONE3_TC1,ZONE3_TC3,ZONE4_TC2,ZONE5_TC2,ZONE6_TC2,ZONE7_TC2,ZONE8_TC2,ZONE9_TC1,ZONE9_TC3,ZONE1_TC2,ZONE2_TC1,ZONE2_TC3,ZONE3_TC2,ZONE4_TC1,ZONE4_TC3,ZONE5_TC1,ZONE5_TC3,ZONE6_TC1,ZONE6_TC3,ZONE7_TC1,ZONE7_TC3,ZONE8_TC1,ZONE8_TC3,ZONE9_TC2"
        Dim Zone As String = "HistDataLineABoth"
        'Dim TC As String = "HistDataLineADrive"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        Dim url As String = "ZoneTempLineChart.aspx"
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone '& "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnDSHistLB_Click(sender As Object, e As EventArgs) Handles btnDSHistLB.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE1_TC1,ZONE1_TC3,ZONE2_TC2,ZONE3_TC1,ZONE3_TC3,ZONE4_TC2,ZONE5_TC1,ZONE5_TC3,ZONE6_TC2,ZONE7_TC2,ZONE8_TC2"
        Dim Zone As String = "HistDataLineBDrive"
        'Dim TC As String = "HistDataLineADrive"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        Dim url As String = "ZoneTempLineChart.aspx"
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone '& "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnOSHistLB_Click(sender As Object, e As EventArgs) Handles btnOSHistLB.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE1_TC2,ZONE2_TC1,ZONE2_TC3,ZONE3_TC2,ZONE4_TC1,ZONE4_TC3,ZONE5_TC2,ZONE6_TC1,ZONE6_TC3,ZONE7_TC1,ZONE7_TC3,ZONE8_TC1,ZONE8_TC3"
        Dim Zone As String = "HistDataLineBOS"
        'Dim TC As String = "HistDataLineADrive"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        Dim url As String = "ZoneTempLineChart.aspx"
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone '& "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnBothHistLB_Click(sender As Object, e As EventArgs) Handles btnBothHistLB.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE1_TC1,ZONE1_TC3,ZONE2_TC2,ZONE3_TC1,ZONE3_TC3,ZONE4_TC2,ZONE5_TC1,ZONE5_TC3,ZONE6_TC2,ZONE7_TC2,ZONE8_TC2,ZONE1_TC2,ZONE2_TC1,ZONE2_TC3,ZONE3_TC2,ZONE4_TC1,ZONE4_TC3,ZONE5_TC2,ZONE6_TC1,ZONE6_TC3,ZONE7_TC1,ZONE7_TC3,ZONE8_TC1,ZONE8_TC3"
        Dim Zone As String = "HistDataLineBBoth"
        'Dim TC As String = "HistDataLineADrive"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        Dim url As String = "ZoneTempLineChart.aspx"
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone '& "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub

    Sub DrawChartFor_on_toDate()
        Try

            '  Dim frmDate As String = DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 6, 0, 0)
            Dim frmDate As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            Dim toDate As String = DateTime.Now.AddMonths(0).ToString("yyyy-MM-dd HH:mm:ss")

            Dim strfrmDt As String = frmDate
            Dim strToDt As String = toDate
            Dim dstemp As DataSet = objController.GetDataForCHART_ON_TODate() 'frmDate, toDate(02/11/2021)
            PlotBarGraphON_TODate(dstemp.Tables(0), Lit2, "container2", "plot2")


        Catch ex As Exception
            Throw ex
        End Try


    End Sub

    Public Sub PlotBarGraphON_TODate(ByVal dt As DataTable, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String)
        Try
            LiteralName.Text = ""
            Dim ticks As String

            ' dt.DefaultView.Sort = "DAY asc"
            Dim line1, line2, line3 As String
            For i As Integer = 0 To dt.Rows.Count - 1
                If i > 0 Then
                    ticks &= ","
                    line1 &= ","
                    line2 &= ","
                    'line3 &= ","
                End If
                ticks &= "'" & dt.Rows(i)(0) & "'"
                If IsDBNull(dt.Rows(i)(1)) Then
                    line1 &= 0
                Else
                    line1 &= dt.Rows(i)(1)
                End If
                If IsDBNull(dt.Rows(i)(2)) Then
                    line2 &= 0
                Else
                    line2 &= dt.Rows(i)(2)
                End If

            Next

            Dim s As New StringBuilder("<script>")

            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            s.Append("var myChart = echarts.init(document.getElementById('" & ContainerName & "'));")
            s.Append("option = {    tooltip: {   trigger: 'axis',  axisPointer: {   type: 'cross', crossStyle: {   color: '#999'  }  } },")
            s.Append("toolbox: {  feature: {  dataView: {show: true, readOnly: false},  magicType: {show: true, type: ['line', 'bar']},  restore: {show: true},  saveAsImage: {show: true}  }  },")
            s.Append("legend: {   data: ['To Date SP. Fuel Consumption','To Date Production'], left:'5%'  },")
            s.Append("xAxis: [ {  type: 'category',  data: [" & ticks & "],    axisPointer: { type: 'shadow'   }       }   ],   ")
            s.Append("yAxis: [  {   type: 'value', name: 'To Date SP. Fuel Consumption',   min: 0,    max: 1.0,  axisLabel: {  formatter: '{value}'    }    },      {    type: 'value',         name: 'To Date Production',      min: 0,        max: 500000,    axisLabel: {            formatter: '{value}'        }        }   ],")
            s.Append("series: [  {   name: 'To Date SP. Fuel Consumption',  type: 'bar',  data: [" & line1 & "]  },   {           name: 'To Date Production',           type: 'bar',    yAxisIndex: 1, data: [" & line2 & "]")
            s.Append("}   ]};")

            s.Append(" myChart.setOption(option);")
            s.Append("</script>")
            LiteralName.Text = s.ToString()
        Catch ex As Exception
            Dim i As String = ""

        End Try

    End Sub

    Protected Sub textspcificFur1_Click(sender As Object, e As EventArgs) Handles textspcificFur1.Click
        Dim url As String = "HSMCumulativeSpecFuelConsum.aspx"
        Dim Line As String

        If rdbtnLineA.Checked Then
            Line = "1"
        ElseIf rdbtnLineB.Checked Then
            Line = "2"
        End If
        Dim s As String = url & "?Furnace=" & Line '& "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone '& "&TC=" & TC
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Page.ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "window.open('" & s & "','_newtab');", True)
    End Sub
    Protected Sub textspcificFur2_Click(sender As Object, e As EventArgs) Handles textspcificFur2.Click
        Dim url As String = "HSMCumulativeSpecFuelConsum.aspx"
        Dim Line As String

        If rdbtnLineA.Checked Then
            Line = "1"
        ElseIf rdbtnLineB.Checked Then
            Line = "2"
        End If
        Dim s As String = url & "?Furnace=" & Line '& "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone '& "&TC=" & TC
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Page.ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "window.open('" & s & "','_newtab');", True)
    End Sub

    Public Sub DrawSpecFuelChart()
        Try

            'Dim frmDate As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            'Dim toDate As String = DateTime.Now.AddMonths(0).ToString("yyyy-MM-dd HH:mm:ss")

            'Dim strfrmDt As String = frmDate
            'Dim strToDt As String = toDate
            'Dim dstemp As DataSet
            Dim furnId As String
            If rdbtnLineA.Checked Then
                furnId = 1
            ElseIf rdbtnLineB.Checked Then
                furnId = 2
            End If

            Dim dt As DataTable = objController.GetSpecFuelDataForCHART(furnId)
            'PlotBarGraphON_TODate(dstemp.Tables(0), Lit2, "container2", "plot2")
            PlotBarGraphSecFuelConsum(dt, Lit2, "container2", "plot2")

        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Public Sub PlotBarGraphSecFuelConsum(ByVal dt As DataTable, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String)
        Try
            Dim ticks As String
            Dim line1 As String
            Dim uslPoint As String
            Dim lslPoint As String

            'Dim line1, line2, line3, LINE4 As String
            LiteralName.Text = ""
            'Dim labels As String
            Dim flagFY As Integer = 0

            If dt.Rows.Count > 0 Then
                'Dim dtDist As DataTable = dt.DefaultView.ToTable(True, "TIMESTAMP")
                Dim dtDist As DataTable = dt
                '  dtDist = dt.ToString("dd-MMM-yyyy HH:mm")
                Dim rs As DataView = dt.DefaultView


                For i As Integer = 0 To dtDist.Rows.Count - 1

                    ' rs.RowFilter = "TIMESTAMP=#" & CDate(dtDist.Rows(i)(0)).ToString("MM/dd/yyyy hh:mm A") & " "
                    'ticks &= " '" & CDate(dtDist.Rows(i)(0)).ToString("yyyy-MM-dd") & "',"
                    'ticks &= " '" & CDate(dtDist.Rows(i)("Month")).ToString("yyyy-MM-dd") & "',"
                    ticks &= " '" & dtDist.Rows(i)("Month") & "',"

                    If flagFY = 0 Then
                        Session("FinYear") = dtDist.Rows(i)("FinancialYear")
                        flagFY = 1
                    End If


                    If rs.Count > 0 Then
                        'line1 &= " '" & dt.Rows(i)("GAS_WASTE") & "',"
                        line1 &= " '" & dt.Rows(i)("CUM_SPEC_FUEL_CON") & "',"

                    Else
                        line1 &= ","
                    End If

                Next

                ' ChartTitle = ""

                Dim js = "<script language='javascript' type='text/javascript'>"

                'js &= "var chartDom = document.getElementById('main');"
                'js &= "var myChart = echarts.init(chartDom);"
                'js &= "var option;"
                js &= "var option1;"
                'js &= "const colors1 = ['#5470C6', '#F4200E', '#F4200E'];"
                'js &= "colors1 = ['#5470C6', '#F4200E', '#F4200E'];" '#999
                js &= "colors1 = ['#2847B2', '#F4200E', '#F4200E'];"
                'js &= "option = {"
                js &= "option1 = {"
                js &= "color: colors1,"
                js &= "tooltip: {"
                js &= "trigger: 'axis',"
                js &= "axisPointer: {"
                js &= "type: 'cross'"
                js &= "}"
                js &= "},"
                js &= "grid: {"
                js &= "right: '5%'"
                js &= "},"
                js &= "toolbox: {"
                js &= "feature: {"
                js &= "dataView: { show: true, readOnly: false },"
                js &= "magicType: { show: true, type: ['line', 'bar'] },"
                js &= "restore: { show: true },"
                js &= "saveAsImage: { show: true }"
                js &= "}"
                js &= "},"
                js &= "legend: {"
                'js &= "data: ['GasFlow']"
                'js &= "data: ['GasFlowVariation']"
                js &= "data: ['CumulativeFuelConsumption']"
                js &= "},"
                js &= "xAxis: ["
                js &= "{"
                js &= "type: 'category',"
                js &= "axisTick: {"
                js &= "alignWithLabel: true"
                js &= "},"
                'js &= "// prettier-ignore "
                'js &= "data: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']"
                js &= "data: [" & ticks & "]"
                js &= "}"
                js &= "],"
                js &= "yAxis:["
                js &= "{"
                js &= "type: 'value',"
                'js &= "name:'Deviation% (Totalizer-Sum of Zone)',"
                js &= "name:'GCal / T',"
                js &= "nameRotate:'90',"
                js &= "nameLocation:'center',"
                js &= "nameTextStyle: {"
                'js &= "fontSize:9,"
                js &= "fontSize:12,"
                js &= "fontStyle:'italic',"
                js &= "fontWeight:'bold',"
                js &= "},"
                js &= "nameGap:'35',"
                js &= "position: 'left',"
                js &= "alignTicks: true,"
                js &= "axisLine: {"
                js &= "show: true,"
                js &= "lineStyle: {"
                js &= "color: colors1[0]"
                js &= "}"
                js &= "},"
                js &= "axisLabel: {"
                js &= "formatter: '{value}'"
                js &= "}"
                js &= "},"
                js &= "{"
                js &= "type: 'value',"
                js &= "name: 'Precipitation',"
                js &= "position: 'right',"
                js &= "alignTicks: true,"
                js &= "show: false,"
                js &= "offset: 80,"
                js &= "axisLine: {"
                js &= "show: true,"
                js &= "lineStyle: {"
                js &= "color: colors1[1]"
                js &= "}"
                js &= "},"
                js &= "axisLabel: {"
                js &= "formatter: '{value} ml'"
                js &= "}"
                js &= "},"
                js &= "{"
                js &= "type: 'value',"
                js &= "name: '温度',"
                js &= "position: 'left',"
                js &= "alignTicks: true,"
                js &= "show: false,"
                js &= "axisLine: {"
                js &= "show: true,"
                js &= "lineStyle: {"
                js &= "color: colors1[2]"
                js &= "}"
                js &= "}"
                'js &= "//axisLabel: {"
                'js &= "//  formatter: '{value} °C'"
                'js &= "//  }"
                js &= "}"
                js &= "],"
                js &= "series: ["
                js &= "{"
                'js &= "name: 'GasFlow',"
                'js &= "name: 'GasFlowVariation',"
                js &= "name: 'CumulativeFuelConsumption',"
                js &= "type: 'bar',"
                js &= "data: ["
                js &= "" & line1 & ""
                js &= "]"
                js &= "},"
                'js &= "{"
                'js &= "name: 'USL',"
                'js &= "type: 'line',"
                'js &= "symbol: 'none',"
                ''js &= "yAxisIndex: 1,"
                'js &= "yAxisIndex: 0,"
                'js &= "data: [" & uslPoint & "]"
                'js &= "},"
                'js &= "{"
                'js &= "name: 'LSL',"
                'js &= "type: 'line',"
                'js &= "symbol: 'none',"
                ''js &= "yAxisIndex: 2,"
                'js &= "yAxisIndex: 0,"
                'js &= "data: [" & lslPoint & "]"
                'js &= "}"
                js &= "]"
                js &= "};"
                'js &= "option && myChart.setOption(option);"

                'js &= "var " & PlotName & " = echarts.init(document.getElementById('" & containerName & "'));" & PlotName & ".setOption(option);"
                js &= "var " & PlotName & " = echarts.init(document.getElementById('" & ContainerName & "'));" & PlotName & ".setOption(option1);"
                js &= "</script>"

                LiteralName.Text = js
            Else
                'Lit.Text = "<script>$('#container22').html('<p>No Data</p>')</script>"
                LiteralName.Text = "<script>$('#" & ContainerName & "').html('<p>No Data</p>')</script>"
            End If
        Catch ex As Exception
            Dim i As String = ""

        End Try

    End Sub

    Protected Sub btnZ1_Click(sender As Object, e As EventArgs) Handles btnZ1.Click
        If rdbtnLineA.Checked Then
            Session("checkboxval") = "1"
        ElseIf rdbtnLineB.Checked Then
            Session("checkboxval") = "2"
        End If

        Session("checkLineChartField1") = "Z1_AIR_FUEL_RATIO"
        Session("checkLineChartField2") = "Z1_EXCESS_AIR"
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
        Session("DateField") = "DATE_TIME"

        Dim url As String = "AirFuelRatioChart.aspx"
        Page.ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "window.open('" & url & "','_newtab');", True)
    End Sub
    Protected Sub btnZ2_Click(sender As Object, e As EventArgs) Handles btnZ2.Click
        If rdbtnLineA.Checked Then
            Session("checkboxval") = "1"
        ElseIf rdbtnLineB.Checked Then
            Session("checkboxval") = "2"
        End If

        Session("checkLineChartField1") = "Z2_AIR_FUEL_RATIO"
        Session("checkLineChartField2") = "Z2_EXCESS_AIR"
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
        Session("DateField") = "DATE_TIME"

        Dim url As String = "AirFuelRatioChart.aspx"
        Page.ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "window.open('" & url & "','_newtab');", True)
    End Sub

    Protected Sub btnZ3_Click(sender As Object, e As EventArgs) Handles btnZ3.Click
        If rdbtnLineA.Checked Then
            Session("checkboxval") = "1"
        ElseIf rdbtnLineB.Checked Then
            Session("checkboxval") = "2"
        End If

        Session("checkLineChartField1") = "Z3_AIR_FUEL_RATIO"
        Session("checkLineChartField2") = "Z3_EXCESS_AIR"
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
        Session("DateField") = "DATE_TIME"

        Dim url As String = "AirFuelRatioChart.aspx"
        Page.ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "window.open('" & url & "','_newtab');", True)
    End Sub

    Protected Sub btnZ4_Click(sender As Object, e As EventArgs) Handles btnZ4.Click
        If rdbtnLineA.Checked Then
            Session("checkboxval") = "1"
        ElseIf rdbtnLineB.Checked Then
            Session("checkboxval") = "2"
        End If

        Session("checkLineChartField1") = "Z4_AIR_FUEL_RATIO"
        Session("checkLineChartField2") = "Z4_EXCESS_AIR"
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
        Session("DateField") = "DATE_TIME"

        Dim url As String = "AirFuelRatioChart.aspx"
        Page.ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "window.open('" & url & "','_newtab');", True)
    End Sub
    Protected Sub btnZ5_Click(sender As Object, e As EventArgs) Handles btnZ5.Click
        If rdbtnLineA.Checked Then
            Session("checkboxval") = "1"
        ElseIf rdbtnLineB.Checked Then
            Session("checkboxval") = "2"
        End If

        Session("checkLineChartField1") = "Z5_AIR_FUEL_RATIO"
        Session("checkLineChartField2") = "Z5_EXCESS_AIR"
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
        Session("DateField") = "DATE_TIME"

        Dim url As String = "AirFuelRatioChart.aspx"
        Page.ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "window.open('" & url & "','_newtab');", True)
    End Sub

    Protected Sub btnZ6_Click(sender As Object, e As EventArgs) Handles btnZ6.Click
        If rdbtnLineA.Checked Then
            Session("checkboxval") = "1"
        ElseIf rdbtnLineB.Checked Then
            Session("checkboxval") = "2"
        End If

        Session("checkLineChartField1") = "Z6_AIR_FUEL_RATIO"
        Session("checkLineChartField2") = "Z6_EXCESS_AIR"
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
        Session("DateField") = "DATE_TIME"

        Dim url As String = "AirFuelRatioChart.aspx"
        Page.ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "window.open('" & url & "','_newtab');", True)
    End Sub

    Protected Sub btnZ7_Click(sender As Object, e As EventArgs) Handles btnZ7.Click
        If rdbtnLineA.Checked Then
            Session("checkboxval") = "1"
        ElseIf rdbtnLineB.Checked Then
            Session("checkboxval") = "2"
        End If

        Session("checkLineChartField1") = "Z7_AIR_FUEL_RATIO"
        Session("checkLineChartField2") = "Z7_EXCESS_AIR"
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
        Session("DateField") = "DATE_TIME"

        Dim url As String = "AirFuelRatioChart.aspx"
        Page.ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "window.open('" & url & "','_newtab');", True)
    End Sub
    Protected Sub btnZ8_Click(sender As Object, e As EventArgs) Handles btnZ8.Click
        If rdbtnLineA.Checked Then
            Session("checkboxval") = "1"
        ElseIf rdbtnLineB.Checked Then
            Session("checkboxval") = "2"
        End If

        Session("checkLineChartField1") = "Z8_AIR_FUEL_RATIO"
        Session("checkLineChartField2") = "Z8_EXCESS_AIR"
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
        Session("DateField") = "DATE_TIME"

        Dim url As String = "AirFuelRatioChart.aspx"
        Page.ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "window.open('" & url & "','_newtab');", True)
    End Sub

    Protected Sub btnZ9_Click(sender As Object, e As EventArgs) Handles btnZ9.Click
        If rdbtnLineA.Checked Then
            Session("checkboxval") = "1"
        ElseIf rdbtnLineB.Checked Then
            Session("checkboxval") = "2"
        End If

        Session("checkLineChartField1") = "Z9_AIR_FUEL_RATIO"
        Session("checkLineChartField2") = "Z9_EXCESS_AIR"
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
        Session("DateField") = "DATE_TIME"

        Dim url As String = "AirFuelRatioChart.aspx"
        Page.ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "window.open('" & url & "','_newtab');", True)
    End Sub

    Protected Sub btnZ10_Click(sender As Object, e As EventArgs) Handles btnZ10.Click
        If rdbtnLineA.Checked Then
            Session("checkboxval") = "1"
        ElseIf rdbtnLineB.Checked Then
            Session("checkboxval") = "2"
        End If

        Session("checkLineChartField1") = "Z10_AIR_FUEL_RATIO"
        Session("checkLineChartField2") = "Z10_EXCESS_AIR"
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
        Session("DateField") = "DATE_TIME"

        Dim url As String = "AirFuelRatioChart.aspx"
        Page.ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "window.open('" & url & "','_newtab');", True)
    End Sub
    Protected Sub btnOverall_Click(sender As Object, e As EventArgs) Handles btnOverall.Click
        If rdbtnLineA.Checked Then
            Session("checkboxval") = "1"
        ElseIf rdbtnLineB.Checked Then
            Session("checkboxval") = "2"
        End If

        Session("checkLineChartField1") = "TOTAL_AIR_FUEL_RATIO"
        Session("checkLineChartField2") = "TOTAL_EXCESS_AIR"
        Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
        Session("DateField") = "DATE_TIME"

        Dim url As String = "AirFuelRatioChart.aspx"
        Page.ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "window.open('" & url & "','_newtab');", True)
    End Sub
End Class
