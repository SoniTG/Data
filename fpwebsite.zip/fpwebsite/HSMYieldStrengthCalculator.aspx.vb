﻿Imports System.IO
Partial Class HSMYieldStrengthCalculator
    Inherits System.Web.UI.Page

    Const Sigma_I_Avg As Double = 60.0
    Const Sigma_I_Min As Double = 47.0
    Const Sigma_I_Max As Double = 70.0
    Dim flag As Boolean = False

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            If CDbl(txtC_Actual.Text) < CDbl(txtC_Min.Text) Then
                flag = True
                litMsg.Text = "  <span class='label label-success pull-right'>Contribution from carbite ppt is not considered</span>"
            End If
        Catch ex As Exception

        End Try

        'Actual
        Dim YS_SS_Actual As Double = Solid_Solution(txtMn_Actual.Text, txtSi_Actual.Text, txtP_Actual.Text, txtSn_Actual.Text, txtCu_Actual.Text, txtMo_Actual.Text, txtNi_Actual.Text, txtCr_Actual.Text)
        Dim YS_GS_Actual As Double = Grain_Size(txtASTM_Actual.Text)
        Dim YS_PH_Actual As Double = Precipitate(txtV_Actual.Text, txtNb_Actual.Text, txtTi_Actual.Text, txtDia_Actual.Text)
        Dim YS_Actual As Double = Sigma_I_Avg + YS_SS_Actual + YS_GS_Actual + YS_PH_Actual
        Dim UTS_Actual As Double = YS_Actual / 0.92

        'Min
        Dim YS_SS_Min As Double = Solid_Solution(txtMn_Min.Text, txtSi_Min.Text, txtP_Min.Text, txtSn_Min.Text, txtCu_Min.Text, txtMo_Min.Text, txtNi_Min.Text, txtCr_Min.Text)
        Dim YS_GS_Min As Double = Grain_Size(txtASTM_Min.Text)
        Dim YS_PH_Min As Double = Precipitate(txtV_Min.Text, txtNb_Min.Text, txtTi_Min.Text, txtDia_Min.Text)
        Dim YS_Min As Double = Sigma_I_Min + YS_SS_Min + YS_GS_Min + YS_PH_Min
        Dim UTS_Min As Double = YS_Min / 0.92

        'Max
        Dim YS_SS_Max As Double = Solid_Solution(txtMn_Max.Text, txtSi_Max.Text, txtP_Max.Text, txtSn_Max.Text, txtCu_Max.Text, txtMo_Max.Text, txtNi_Max.Text, txtCr_Max.Text)
        Dim YS_GS_Max As Double = Grain_Size(txtASTM_Max.Text)
        Dim YS_PH_Max As Double = Precipitate(txtV_Max.Text, txtNb_Max.Text, txtTi_Max.Text, txtDia_Max.Text)
        Dim YS_Max As Double = Sigma_I_Max + YS_SS_Max + YS_GS_Max + YS_PH_Max
        Dim UTS_Max As Double = YS_Max / 0.92

        lblYS_Act.Text = Math.Round(YS_Actual, 0)
        lblYS_min.Text = Math.Round(YS_Min, 0)
        lblYS_Max.Text = Math.Round(YS_Max, 0)
        lblUTS_Act.Text = Math.Round(UTS_Actual, 0)
        lblUTS_Min.Text = Math.Round(UTS_Min, 0)
        lblUTS_Max.Text = Math.Round(UTS_Max, 0)
        lblSS_Avg.Text = Math.Round(YS_SS_Actual, 0)
        lblSS_Min.Text = Math.Round(YS_SS_Min, 0)
        lblSS_Max.Text = Math.Round(YS_SS_Max, 0)
        lblGS_Avg.Text = Math.Round(YS_GS_Actual, 0)
        lblGS_Min.Text = Math.Round(YS_GS_Min, 0)
        lblGS_Max.Text = Math.Round(YS_GS_Max, 0)
        lblPH_Avg.Text = Math.Round(YS_PH_Actual, 0)
        lblPH_Min.Text = Math.Round(YS_PH_Min, 0)
        lblPH_Max.Text = Math.Round(YS_PH_Max, 0)
        lblSigma_Avg.Text = Sigma_I_Avg
        lblSigma_Min.Text = Sigma_I_Min
        lblSigma_Max.Text = Sigma_I_Max

        PlotChart(Sigma_I_Avg, Math.Round(YS_SS_Actual, 0), Math.Round(YS_GS_Actual, 0), Math.Round(YS_PH_Actual, 0))

    End Sub

    Sub PlotChart(ByVal sigma As Double, ByVal ss As Double, ByVal gs As Double, ByVal ph As Double)
        Dim js As String = "<script>var line1 = [" & sigma & ", " & ss & ", " & gs & ", " & ph & "];"
        js &= "var ticks = ['Inherent Strength','Solid Soln Strengthening','Grain Refinement','Precipitation Hardening'];"
        js &= "var plot1 = $.jqplot('container1', [line1], {seriesDefaults:{renderer:$.jqplot.BarRenderer, "
        js &= "rendererOptions:{waterfall:true},pointLabels: {hideZeros: true}},axes:{yaxis:{tickOptions:{fontSize:'10pt'}},xaxis:{renderer:$.jqplot.CategoryAxisRenderer,ticks:ticks,"
        js &= "tickRenderer: $.jqplot.CanvasAxisTickRenderer,tickOptions: {angle: -30,showMark: false,showGridline: false}}}});</script>"
        Literal1.Text = js
    End Sub

    Function Solid_Solution(ByVal Mn As Double, ByVal Si As Double, ByVal P As Double, ByVal Sn As Double, ByVal Cu As Double, ByVal Mo As Double, ByVal Ni As Double, ByVal Cr As Double) As Double
        Dim retVal As Double = 0.0
        Try
            retVal = 32 * Mn + 83 * Si + 678 * P + 123 * Sn + 39 * Cu + 11 * Mo + 0 * Ni + (-32) * Cr
        Catch ex As Exception

        End Try
        Return retVal
    End Function

    Function Grain_Size(ByVal ASTMGrainSize As Double) As Double
        Dim retVal As Double = 0.0
        Dim val1 As Double = Math.Exp((2.9542 + ASTMGrainSize) / 1.4427)
        Dim val2 As Double = Math.Sqrt(1 / val1)
        Try
            retVal = 19.7 / Math.Sqrt(val2)
        Catch ex As Exception

        End Try
        Return retVal
    End Function

    Function Precipitate(ByVal V As Double, ByVal Nb As Double, ByVal Ti As Double, ByVal Dia As Double) As Double
        Dim retVal As Double = 0.0
        Dim C_V, C_Nb, C_Ti As Double
        If flag = True Then
            C_V = V * 1.63 / 100
            C_Nb = Nb * 1.08 / 100
            C_Ti = Ti * 1.99 / 100
        Else
            C_V = V * 1.64 / 100  '1.63
            C_Nb = Nb * 1.1 / 100  '1.08
            C_Ti = Ti * 1.99 / 100 '1.99
        End If
        
        Try
            retVal = ((10.8 / Dia) * Math.Log(Dia * 10000 / 6.125)) * (Math.Sqrt(C_V) + Math.Sqrt(C_Nb) + Math.Sqrt(C_Ti))
        Catch ex As Exception

        End Try
        Return retVal
    End Function

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Session("pagehit") = New Controller().SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
        End If


    End Sub
End Class
