﻿Imports System.Data
Imports System.IO
Partial Class HSM_Heat_Map
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim objDataHandler As New DataHandler
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        'If Page.IsPostBack Then
        '    Try

        '        Dim p As String = Request("__EVENTARGUMENT")
        '        If p = "date" Then
        '            txtDate_TextChanged()
        '        End If

        '    Catch ex As Exception

        '    End Try
        'End If
        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
                'Dim dtStart As DateTime = DateTime.Now.AddMonths(-4).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                objController.PopulateParameterForHSM(ddl_para, dtStart, dtEnd)

                DrawHeatMap(dtStart, dtEnd, "container1", Lit1, ddl_para.SelectedItem.Text, 1)
                DrawHeatMap(dtStart, dtEnd, "container2", Lit2, ddl_para.SelectedItem.Text, 2)
                DrawHeatMap(dtStart, dtEnd, "container3", Lit3, ddl_para.SelectedItem.Text, 3)
            Catch ex As Exception

            End Try
        End If
    End Sub
    Sub DrawHeatMap(ByVal FromDate As String, ByVal ToDate As String, ByVal ContainerName As String, ByVal LitName As Literal, ByVal Parameter As String, ByVal fur_no As Int16)
        Try

            Dim strfrmDt As String = FromDate
            Dim strToDt As String = ToDate
            Dim mintemp, maxtemp As Double
            mintemp = -1.0
            maxtemp = 0.0
            Dim dtmfrmDt As DateTime = strfrmDt
            Dim dtmToDt As DateTime = strToDt

            'Dim dt As DataTable = objDataHandler.GetDataSetFromQueryLP("select top 20 * from NBM_AlongLength_parameters  where [Blt_temperature_time] between '" & dtmfrmDt.ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & dtmToDt.ToString("yyyy-MM-dd HH:mm:ss") & "' and parameter= '" & Parameter & "' order by [Blt_temperature_time] desc").Tables(0)
            'Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select top 20 * from HSM_AlongLength_parameters  where [Temperature_time] between '" & dtmfrmDt.ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & dtmToDt.ToString("yyyy-MM-dd HH:mm:ss") & "' and Parameter= '" & Parameter & "' order by [Temperature_time] desc").Tables(0)
            Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("Select  TOP(20) [Temperature_time],[Parameter],[0-5]    ,[5-10]  ,[10-15] ,[15-20] ,[20-25] ,[25-30] ,[30-35],[35-40] ,[40-45] " &
                                    " ,[45-50]  ,[50-55] ,[55-60] ,[60-65],[65-70] ,[70-75],[75-80] ,[80-85] ,[85-90] ,[90-95],[95-100] " &
                                    " ,T1.[FUR_No]  ,T1.[HR_COIL_ID] ,T2.[FCE_ID]  " &
                                    " From [FP_PROCESS_DATA].[dbo].[HSM_AlongLength_parameters] T1, [FP_PROCESS_DATA].[dbo].[T_HR_PARAMS] T2 " &
                                    " Where T1.[HR_COIL_ID] = T2.[HR_COIL_ID] And [Temperature_time] between  '" & dtmfrmDt.ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & dtmToDt.ToString("yyyy-MM-dd HH:mm:ss") & "' " &
                                    " And Parameter = '" & Parameter & "' and [FCE_ID] =  " & fur_no & " order by [Temperature_time] desc").Tables(0)
            If dt.Rows.Count > 0 Then

                'For j = 3 To dt.Columns.Count - 1
                '    Dim temp As Double = dt.Compute("Min([" & dt.Columns(j).ColumnName & "])", "")
                '    Dim temp1 As Double = dt.Compute("Max([" & dt.Columns(j).ColumnName & "])", "")
                '    If mintemp = -1.0 Then
                '        mintemp = temp
                '    End If
                '    If temp < mintemp Then
                '        mintemp = temp
                '    End If
                '    If temp1 > maxtemp Then
                '        maxtemp = temp1
                '    End If
                'Next

                'CB_EXT_TEMP
                'CB_PRU_BOTcurr
                'CB_PRU_ForceAvg
                'CB_PRU_TOPcurr
                'Pr_Entry_Pres
                'Pr_Ext_Pres
                'RMET
                'Sc_desc_Entry_Pres
                'Sc_desc_Ext_Pres

                If Parameter = "CB_BendUt_Top_cur" Or Parameter = "CB_BendUt_Bot_cur" Then
                    mintemp = 100
                    maxtemp = 1000

                ElseIf Parameter = "CB_EXT_TEMP" Then
                    mintemp = 900
                    maxtemp = 1050
                ElseIf Parameter = "CB_BendUt_Bot_Spd" Or Parameter = "CB_BendUt_Top_Spd" Then
                    mintemp = 1
                    maxtemp = 5
                ElseIf Parameter = "RMET" Then
                    mintemp = 1000
                    maxtemp = 1120
                ElseIf Parameter = "CB_PRU_TOPcurr" Or Parameter = "CB_PRU_BOTcurr" Then
                    mintemp = 100
                    maxtemp = 300
                ElseIf Parameter = "CB_PRU_ForceAvg" Then
                    mintemp = 50
                    maxtemp = 250
                ElseIf Parameter = "Sc_desc_Entry_Pres" Or Parameter = "Sc_desc_Ext_Pres" Then
                    mintemp = 150
                    maxtemp = 200
                End If

                Dim StartTime As DateTime = Convert.ToDateTime((dt.Compute("min(Temperature_time)", String.Empty)))
                Dim EndTime As DateTime = Convert.ToDateTime((dt.Compute("max(Temperature_time)", String.Empty)))
                'lblDate.Text = StartTime.ToString("dd-MM-yyyy HH:mm tt") & " - " & EndTime.ToString("dd-MM-yyyy HH:mm tt")
                Dim s As New StringBuilder("<script>")
                s.Append("var hours = ['Head', '10', '15', '20', '25', '30', '35','40','45','50', '55', '60', '65', '70', '75', '80','85','90','95','Tail'];")

                s.Append("var days = [")
                For i As Integer = 0 To dt.Rows.Count - 1
                    If i > 0 Then
                        s.Append(",")
                    End If
                    s.Append("'" & CDate(dt.Rows(i)("Temperature_time")).ToString("dd-MM-yyyy HH:mm") & "'")
                Next
                s.Append("];")
                s.Append("var data = [")
                For i As Integer = 0 To dt.Rows.Count - 1
                    If i > 0 Then
                        s.Append(",")
                    End If
                    For j As Integer = 2 To dt.Columns.Count - 3
                        If j > 2 Then
                            s.Append(",")
                        End If
                        s.Append("[" & (i) & "," & (j - 2) & "," & dt.Rows(i)(j) & "]")
                    Next
                Next
                s.Append("];")
                s.Append("data = data.map(function (item) {return [item[1], item[0], item[2] || '-'];});")
                ''  s.Append("option = {tooltip: { position: 'top',formatter:function(params){var c = Math.round(params.value[2]);var d = days[params.value[1]];return params.name + ': ' + d +  ', ' + c}}, animation: true, grid: { height: '80%', y: '1%' }, xAxis: { type: 'category', data: hours, splitArea: { show: true } }, yAxis: { type: 'category', data: days, splitArea: { show: true } }, visualMap: { min: " & Math.Floor(mintemp) & ", max: " & Math.Floor(maxtemp) & ", calculable: true, orient: 'horizontal', left: 'center', bottom: '0%' }, series: [{ name: 'Billet Temp', type: 'heatmap', data: data, label: { normal: { show: false } }, itemStyle: { emphasis: { shadowBlur: 10, shadowColor: 'rgba(0, 0, 0, 0.5)' } } }] };")
                s.Append("var myChart = echarts.init(document.getElementById('" & ContainerName & "'));")

                s.Append("option = {tooltip: { position: 'bottom',formatter:function(params){var c = Math.round(params.value[2]);var d = days[params.value[1]];return params.name + ': ' + d +  ', ' + c}}, animation: true, grid: { height: '80%', y: '1%' }, xAxis: { type: 'category', data: hours, splitArea: { show: true } }, yAxis: { type: 'category', data: days, splitArea: { show: true } }, visualMap: { min: " & Math.Floor(mintemp) & ", max: " & Math.Floor(maxtemp) & ",")
                s.Append("inRange: { color: ['#fee090', '#fdae61', '#f46d43', '#d73027', '#a50026']},calculable: true, orient: 'horizontal', left: 'center', bottom: '0%' }, series: [{ name: 'Billet Temp', type: 'heatmap', data: data, label: { normal: { show: false } }, itemStyle: { emphasis: { shadowBlur: 10, shadowColor: 'rgba(0, 0, 0, 0.5)' } } }] };")
                s.Append("myChart.setOption(option);")
                s.Append("window.onresize = function() { myChart.resize();};")
                s.Append("</script>")
                LitName.Text = s.ToString()
                'lblmsg.Text = "Show temperature data of last 80 billets"
            Else
                'lblerror.Text = "No Data Found"
                LitName.Text = ""
            End If

        Catch ex As Exception
            'lblerror.Text = ex.ToString
            Lit1.Text = " "
        End Try
    End Sub

    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try


            Dim strfrmDt As String = hfFrom.Value
            Dim strToDt As String = hfTo.Value
            'Dim dtmfrmDt As DateTime = strfrmDt
            'Dim dtmToDt As DateTime = strToDt
            objController.PopulateParameterForHSM(ddl_para, strfrmDt, strToDt)

            DrawHeatMap(strfrmDt, strToDt, "container1", Lit1, ddl_para.SelectedItem.Text, 1)
            DrawHeatMap(strfrmDt, strToDt, "container2", Lit2, ddl_para.SelectedItem.Text, 2)
            DrawHeatMap(strfrmDt, strToDt, "container3", Lit3, ddl_para.SelectedItem.Text, 3)


        Catch ex As Exception

        End Try
    End Sub
    Protected Sub ddl_para_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddl_para.SelectedIndexChanged
        Dim strfrmDt As String = hfFrom.Value
        Dim strToDt As String = hfTo.Value
        'Dim dtmfrmDt As DateTime = strfrmDt
        'Dim dtmToDt As DateTime = strToDt


        DrawHeatMap(strfrmDt, strToDt, "container1", Lit1, ddl_para.SelectedItem.Text, 1)
        DrawHeatMap(strfrmDt, strToDt, "container2", Lit2, ddl_para.SelectedItem.Text, 2)
        DrawHeatMap(strfrmDt, strToDt, "container3", Lit3, ddl_para.SelectedItem.Text, 3)


    End Sub
End Class
