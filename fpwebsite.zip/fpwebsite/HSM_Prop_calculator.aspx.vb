﻿Imports System.Data
Imports System.IO

Partial Class calculator
    Inherits System.Web.UI.Page

    Dim dtUTS, dtYS As DataTable
    Dim objController As New Controller


    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim uts As Double = 0.0
        Dim ys As Double = 0.0
        Dim uts_min As Double = 0
        Dim uts_max As Double = 0
        Dim ys_min As Double = 0
        Dim ys_max As Double = 0

        Dim const_UTS As Double = 0
        Dim const_YS As Double = 0
        Dim coeff_UTS_YS As Double = 0
        Dim std_error_uts As Double = 0
        Dim std_error_ys As Double = 0

        If ddlGrade.SelectedValue = "Low Carbon" Then
            const_UTS = 375.5179
            const_YS = -43.08697
            coeff_UTS_YS = 1.3815709
            std_error_uts = 8.3581768
            std_error_ys = 12.651545
        End If
        If ddlGrade.SelectedValue = "Low Carbon Micro-Alloy" Then
            const_UTS = 187.7473
            const_YS = 13.1241
            coeff_UTS_YS = 1.02252553
            std_error_uts = 16.46201
            std_error_ys = 13.80887
        End If
        If ddlGrade.SelectedValue = "Peritectic" Then
            const_UTS = 463.25783
            const_YS = 40.939947
            coeff_UTS_YS = 0.8403099
            std_error_uts = 11.39754
            std_error_ys = 17.3055
        End If
        If ddlGrade.SelectedValue = "Peritectic Micro-Alloy" Then
            const_UTS = 538.42337
            const_YS = -73.0963
            coeff_UTS_YS = 1.06817228
            std_error_uts = 14.7845
            std_error_ys = 11.646229
        End If
        If ddlGrade.SelectedValue = "Meidum and High Carbon" Then
            const_UTS = 360.3864148
            const_YS = -209.197257
            coeff_UTS_YS = 1.0489327
            std_error_uts = 14.75327
            std_error_ys = 12.6341
        End If
        For Each item As RepeaterItem In Repeater1.Items
            If item.ItemType = ListItemType.Item OrElse item.ItemType = ListItemType.AlternatingItem Then
                Dim actval As Double = CType(item.FindControl("txtC_Actual"), TextBox).Text
                Dim coeff_uts As Double = CType(item.FindControl("lblC_coeff_uts"), Label).Text
                Dim coeff_ys As Double = CType(item.FindControl("lblC_coeff_ys"), Label).Text
                If ddlGrade.SelectedValue = "Peritectic Micro-Alloy" Then
                    Dim param As String = CType(item.FindControl("lblparam"), Label).Text
                    If param.Trim.ToUpper = "V" Then
                        uts += Math.Log(actval) * 20.7725975914128 '+ actval * coeff_uts
                        ys += Math.Log(actval) * -2.51739950373217 '+ actval * coeff_ys
                    End If
                    If param.Trim.ToUpper = "MN" Then
                        uts += Math.Pow(actval, 2.0) * -31.3769263305797 '+ actval * coeff_uts
                        ys += Math.Pow(actval, 2.0) * -5.37587177784739 '+ actval * coeff_ys
                    End If
                ElseIf ddlGrade.SelectedValue = "Meidum and High Carbon" Then
                    Dim param As String = CType(item.FindControl("lblparam"), Label).Text
                    If param.Trim.ToUpper = "SI" Then
                        uts += Math.Pow(actval, 2) * -410.808230206832 '+ actval * coeff_uts
                        ys += Math.Pow(actval, 2) * -781.504432027153 '+ actval * coeff_ys
                    End If
                Else

                End If

                uts += actval * coeff_uts
                ys += actval * coeff_ys
            End If
        Next
        lblUTS_Act.Text = Math.Round(uts + const_UTS, 0)
        lblYS_Act.Text = Math.Round(ys + const_YS + coeff_UTS_YS * (uts + const_UTS), 0)
        uts_max = Math.Round(uts + const_UTS + 1.8 * std_error_uts, 0)
        uts_min = Math.Round(uts + const_UTS - 1.8 * std_error_uts, 0)
        ys_max = Math.Round(CDbl(lblYS_Act.Text) + 1.8 * std_error_ys, 0)
        ys_min = Math.Round(CDbl(lblYS_Act.Text) - 1.8 * std_error_ys, 0)

        lblUTS_Max.Text = uts_max
        lblUTS_Min.Text = uts_min
        lblYS_Max.Text = ys_max
        lblYS_min.Text = ys_min
    End Sub

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        lblmsg.Text = hf.Value
        If Not Page.IsPostBack Then
            Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
        End If
    End Sub

    Sub getLCData()
        Dim dt As New DataTable
        dt.Columns.Add("parameter", GetType(String))
        dt.Columns.Add("unit", GetType(String))
        dt.Columns.Add("min", GetType(Double))
        dt.Columns.Add("max", GetType(Double))
        dt.Columns.Add("actual", GetType(Double))
        dt.Columns.Add("coeff_uts", GetType(Double))
        dt.Columns.Add("coeff_ys", GetType(Double))

        dt.Rows.Add("HR_THICKNESS", "mm", 1.6, 10, 5.8, -2.23013580383165, -3.87813154830669)
        dt.Rows.Add("C", "%", 0.025, 0.07, 0.0475, 464.172411950544, -586.210822479408)
        dt.Rows.Add("MN", "%", 0.117, 0.51, 0.3135, 52.5469562245773, -28.6268782583443)
        dt.Rows.Add("S", "%", 0.0016, 0.0223, 0.01195, -490.957387123064, -317.320179874214)
        dt.Rows.Add("P", "%", 0.007, 0.039, 0.023, 697.166799580746, -348.915979618461)
        dt.Rows.Add("SI", "%", 0.003, 0.25, 0.1265, 143.849006020706, -55.9152275938173)
        dt.Rows.Add("Al_Tot", "%", 0.002, 0.087, 0.0445, 62.6890293015254, -60.3956353976391)
        dt.Rows.Add("N", "%", 0.0019, 0.0082, 0.00505, 3704.55066854843, -4155.80295610732)
        dt.Rows.Add("CR", "%", 0.012, 0.04, 0.026, 98.9897357758184, 20.6946116468073)
        dt.Rows.Add("B", "%", 0, 0.0024, 0.0012, -10526.686157375, -2764.8302010592)
        dt.Rows.Add("Cu", "%", 0.004, 0.016, 0.01, -431.256775356419, -386.928498044551)
        dt.Rows.Add("NI", "%", 0.019, 0.035, 0.027, 513.364584757525, -365.340219089166)
        dt.Rows.Add("FM_Exit_Temp", "DegC", 827, 957, 892, -0.0117551850367199, -0.117365243035318)
        dt.Rows.Add("Coiling_Temp", "DegC", 543, 703, 623, -0.0857121657785886, 0.0259395165535105)
        dt.Rows.Add("MO", "%", 0, 0.105, 0.0525, 0, 112.753041209592)
        dt.Rows.Add("Dischar_Temp_Tail", "DegC", 1169, 1275, 1222, 0, -0.0184006871919823)

        dtUTS = dt



    End Sub

    Sub getLCMAData()
        Dim dt As New DataTable
        dt.Columns.Add("parameter", GetType(String))
        dt.Columns.Add("unit", GetType(String))
        dt.Columns.Add("min", GetType(Double))
        dt.Columns.Add("max", GetType(Double))
        dt.Columns.Add("actual", GetType(Double))
        dt.Columns.Add("coeff_uts", GetType(Double))
        dt.Columns.Add("coeff_ys", GetType(Double))

        dt.Rows.Add("HR_THICKNESS", "mm", 1.6, 25, 13.3, -2.92361726033667, -2.48167691575385)
        dt.Rows.Add("C", "%", 0.0298, 0.07, 0.0499, 1056.92948512832, -236.072211351918)
        dt.Rows.Add("MN", "%", 0.1411, 2, 1.07055, 99.8340331094815, 5.04556313662525)
        dt.Rows.Add("S", "%", 0.0006, 0.022, 0.0113, -431.920641797219, 0)
        dt.Rows.Add("P", "%", 0.008, 0.14, 0.074, 756.84882797789, -126.019010665829)
        dt.Rows.Add("SI", "%", 0.006, 0.438, 0.222, 83.1660095268876, 37.2134659734323)
        dt.Rows.Add("Al_Tot", "%", 0.02, 0.1, 0.06, 112.325151224549, -29.3166067747085)
        dt.Rows.Add("N", "%", 0.001, 0.0107, 0.00585, -4856.54494261182, 0)
        dt.Rows.Add("CR", "%", 0.003, 0.424, 0.2135, 50.8915126168735, -143.349466023765)
        dt.Rows.Add("TI", "%", 0, 0.109, 0.0545, 2283.57935376891, -109.074658405412)
        dt.Rows.Add("Nb", "%", 0, 0.08, 0.04, 1670.11123511607, 285.458745706332)
        dt.Rows.Add("V", "%", 0, 0.068, 0.034, 1969.34959187361, -142.637134183045)
        dt.Rows.Add("B", "%", 0, 0.0024, 0.0012, -10722.7850223634, -17886.7754269688)
        dt.Rows.Add("Ca", "ppm", 0, 49, 24.5, (-0.520300229511235), (-0.174146851928242))
        dt.Rows.Add("Cu", "%", 0.002, 0.382, 0.192, 144.226273022358, -99.1482458096447)
        dt.Rows.Add("NI", "%", 0.0026, 0.398, 0.2003, -182.989885710518, 150.924859798929)
        dt.Rows.Add("MO", "%", 0, 0.255, 0.1275, 416.233248153591, -163.401929941588)
        dt.Rows.Add("FM_Exit_Temp", "DegC", 811, 941, 876, 0.0422459315200857, -0.0702143894829774)
        dt.Rows.Add("Coiling_Temp", "DegC", 378, 663, 521, 0.0533533892479283, 0.0492719315166233)
        dt.Rows.Add("R2_Bar_Thick", "microns", 31000, 60000, 45500, 0.000286800521311136, 0)
        dt.Rows.Add("Entry_Temp_Tail", "DegC", 890, 1059, 974, 0.050794819659448, -0.039113090705313)
        dt.Rows.Add("F7_Reduction", "%", 0.07, 0.178, 0.124, -198.981875672953, -73.1891957997921)


        dtUTS = dt
    End Sub

    Sub getPeriMAData()
        Dim dt As New DataTable
        dt.Columns.Add("parameter", GetType(String))
        dt.Columns.Add("unit", GetType(String))
        dt.Columns.Add("min", GetType(Double))
        dt.Columns.Add("max", GetType(Double))
        dt.Columns.Add("actual", GetType(Double))
        dt.Columns.Add("coeff_uts", GetType(Double))
        dt.Columns.Add("coeff_ys", GetType(Double))

        dt.Rows.Add("HR_THICKNESS", "mm", 2, 25, 13.5, -1.9173031581091, -1.79960240962279)
        dt.Rows.Add("C", "%", 0.071, 0.16, 0.1155, 479.47401559642, -364.317036149556)
        dt.Rows.Add("MN", "%", 0.342, 1.952, 1.147, 125.122967798879, -5.37587177784739)
        dt.Rows.Add("S", "%", 0.001, 0.0147, 0.00785, -361.668426936073, 0)
        dt.Rows.Add("P", "%", 0.009, 0.14, 0.0745, 448.577326905635, -119.075358449232)
        dt.Rows.Add("SI", "%", 0.006, 0.46, 0.233, 116.193421221791, -36.2538922686371)
        dt.Rows.Add("Al_Tot", "%", 0.022, 0.096, 0.059, 78.2026780722852, 0)
        dt.Rows.Add("N", "%", 0.0025, 0.0112, 0.00685, -2161.33259042759, 0)
        dt.Rows.Add("CR", "%", 0.013, 0.46, 0.2365, -109.53146725748, -54.979393955026)
        dt.Rows.Add("TI", "%", 0, 0.115, 0.0575, 2287.54496172131, -90.3141319241836)
        dt.Rows.Add("Nb", "%", 0, 0.065, 0.0325, 1921.61757934576, 482.286401368742)
        dt.Rows.Add("B", "%", 0, 0.0017, 0.00085, 12165.2497455268, -3371.53401894781)
        dt.Rows.Add("Ca", "ppm", 0, 40, 20, (0.0540264532757814), (0.0757880935161441))
        dt.Rows.Add("Cu", "%", 0.004, 0.392, 0.198, -5.05785163599313, -55.3096250047834)
        dt.Rows.Add("NI", "%", 0.012, 0.409, 0.2105, 233.839190574066, 68.1037074469522)
        dt.Rows.Add("MO", "%", 0, 0.255, 0.1275, 561.063783138622, -213.367409879088)
        dt.Rows.Add("V", "%", 0.001, 0.195, 0.098, 0, 0)
        dt.Rows.Add("FM_Exit_Temp", "DegC", 787, 950, 869, 0.112948318787703, -0.0604189905366684)
        dt.Rows.Add("Coiling_Temp", "DegC", 518, 677, 598, -0.330209019442838, 0.0408254479165393)
        dt.Rows.Add("RT_Inter_Temp", "DegC", 440, 853, 647, 0.0487743361370596, 0)
        dt.Rows.Add("F7_Reduction", "%", 0.079, 0.169, 0.124, -183.326576116384, 0)



        dtUTS = dt
    End Sub

    Sub getMCHCData()
        Dim dt As New DataTable
        dt.Columns.Add("parameter", GetType(String))
        dt.Columns.Add("unit", GetType(String))
        dt.Columns.Add("min", GetType(Double))
        dt.Columns.Add("max", GetType(Double))
        dt.Columns.Add("actual", GetType(Double))
        dt.Columns.Add("coeff_uts", GetType(Double))
        dt.Columns.Add("coeff_ys", GetType(Double))

        dt.Rows.Add("HR_THICKNESS", "mm", 1.6, 25, 13.3, -3.65952854244706, -1.90191857687755)
        dt.Rows.Add("C", "%", 0.161, 0.592, 0.3765, 856.797539731052, -361.674091602718)
        dt.Rows.Add("MN", "%", 0.404, 1.59, 0.997, 89.4814368535694, 13.1852707148526)
        dt.Rows.Add("S", "%", 0.001, 0.0136, 0.0073, -129.698647905877, 96.013666171028)
        dt.Rows.Add("P", "%", 0.009, 0.036, 0.0225, 497.635558247263, -121.379458596006)
        dt.Rows.Add("SI", "%", 0.005, 0.31, 0.1575, 179.091187356094, 118.770605945684)
        dt.Rows.Add("N", "%", 0.0025, 0.0094, 0.00595, 3599.77726308519, 1385.83333563375)
        dt.Rows.Add("CR", "%", 0.013, 0.3, 0.1565, 330.208889296073, -39.8323942428403)
        dt.Rows.Add("TI", "%", 0.001, 0.037, 0.019, 796.294065015803, 537.787833242153)
        dt.Rows.Add("Nb", "%", 0.001, 0.06, 0.0305, 1524.75046446388, 206.68484423616)
        dt.Rows.Add("V", "%", 0.001, 0.11, 0.0555, 1221.13395667654, 122.289094771962)
        dt.Rows.Add("Cu", "%", 0.004, 0.253, 0.1285, 77.2095272680015, 0)
        dt.Rows.Add("MO", "%", 0, 0.057, 0.0285, -575.467114972753, 0)
        dt.Rows.Add("FM_Exit_Temp", "DegC", 798, 946, 872, 0.172112366913695, -0.0119745571318144)
        dt.Rows.Add("Coiling_Temp", "DegC", 505, 659, 582, -0.366808252051207, 0.173875098134311)
        dt.Rows.Add("RT_Inter_Temp", "DegC", 440, 774, 607, -0.0449969407582031, -0.0158667620948339)
        dt.Rows.Add("Al_Tot", "%", 0.006, 0.1, 0.053, 0, 100.258091629023)


        dtUTS = dt
    End Sub

    Sub getPeriData()
        Dim dt As New DataTable
        dt.Columns.Add("parameter", GetType(String))
        dt.Columns.Add("unit", GetType(String))
        dt.Columns.Add("min", GetType(Double))
        dt.Columns.Add("max", GetType(Double))
        dt.Columns.Add("actual", GetType(Double))
        dt.Columns.Add("coeff_uts", GetType(Double))
        dt.Columns.Add("coeff_ys", GetType(Double))

        dt.Rows.Add("C", "%", 0.072, 0.16, 0.116, 603.711111309643, -370.477268944248)
        dt.Rows.Add("MN", "%", 0.133, 1.29, 0.7115, 70.7650058961446, 17.1742568034169)
        dt.Rows.Add("S", "%", 0.0009, 0.0168, 0.00885, -480.788123709445, -232.472524500124)
        dt.Rows.Add("P", "%", 0.008, 0.14, 0.074, 540.467470254579, -151.539899240381)
        dt.Rows.Add("SI", "%", 0.004, 0.447, 0.2255, 128.3405821043, -16.0399276346677)
        dt.Rows.Add("Al_Tot", "%", 0.002, 0.098, 0.05, 91.6662845973392, 67.0365709745267)
        dt.Rows.Add("CR", "%", 0.005, 0.438, 0.2215, 15.9509934849847, 90.2275654786683)
        dt.Rows.Add("N", "%", 0.0021, 0.0105, 0.0063, 3730.99477397345, 45.9890065022679)
        dt.Rows.Add("Cu", "%", 0.003, 0.367, 0.185, 23.4459113001458, -27.2709115444651)
        dt.Rows.Add("R2_Bar_Thick", "microns", 31000, 55000, 43000, -0.000645303973232742, -0.00105046210132109)
        dt.Rows.Add("Entry_Temp_Tail", "DegC", 815, 1064, 940, -0.102912196798994, -0.157251165385026)
        dt.Rows.Add("FM_Exit_Temp", "DegC", 797, 942, 870, 0.168229728757193, 0.100722785563728)
        dt.Rows.Add("Coiling_Temp", "DegC", 510, 673, 592, -0.275667871079414, 0.0591159260334304)
        dt.Rows.Add("HR_THICKNESS", "mm", 1.6, 25, 13.3, -2.2489859083083, -1.43607010955707)
        dt.Rows.Add("F7_Reduction", "%", 0.074, 0.189, 0.1315, -32.3597454016336, 88.4087176182095)


        dtUTS = dt
    End Sub

    Protected Sub ddlGrade_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlGrade.SelectedIndexChanged
        lblUTS_Act.Text = ""
        lblYS_Act.Text = ""
        lblUTS_Max.Text = ""
        lblUTS_Min.Text = ""
        lblYS_Max.Text = ""
        lblYS_min.Text = ""
        If ddlGrade.SelectedIndex > 0 Then
            If ddlGrade.SelectedItem.Value = "Low Carbon" Then
                getLCData()
            ElseIf ddlGrade.SelectedItem.Value = "Low Carbon Micro-Alloy" Then
                getLCMAData()
            ElseIf ddlGrade.SelectedItem.Value = "Peritectic Micro-Alloy" Then
                getPeriMAData()
            ElseIf ddlGrade.SelectedItem.Value = "Meidum and High Carbon" Then
                getMCHCData()
            ElseIf ddlGrade.SelectedItem.Value = "Peritectic" Then
                getPeriData()
            End If
            Repeater1.DataSource = dtUTS
            Repeater1.DataBind()
        Else
            Repeater1.DataSource = Nothing
            Repeater1.DataBind()
        End If
    End Sub
End Class
