﻿Imports System.Data
Imports System.IO
Imports System.Web.Services
Imports System.Data.SqlClient
Imports System.Data.OleDb
Imports Oracle.ManagedDataAccess.Client
Partial Class HSMdefectgoodbad
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim objDataHandler As New DataHandler
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Dim OraAdap As New OracleDataAdapter
    Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("TGOraServer_New").ConnectionString


    Dim Oleconnection_ora As New OracleConnection(strConnectionString)
    Dim OleAdap As New OracleDataAdapter
    Dim OleCom As New OracleCommand
    Dim ds, ds_wd As New DataSet
    Dim dt, dt_wd As New DataTable

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try

                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    'txtDate_TextChanged()
                End If



            Catch ex As Exception

            End Try
        End If
        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-1).ToString("dd-MMM-yy")
                'Dim dtStart As DateTime = DateTime.Now.AddMonths(-6).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("dd-MMM-yy")







            Catch ex As Exception

            End Try
        End If
    End Sub

    Sub CloseConnection()
        Try
            If Oleconnection_ora.State <> ConnectionState.Closed Then
                Oleconnection_ora.Close()
            End If
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

    End Sub
    Public Function Ora_selectquery(ByVal strselect As String) As OracleDataAdapter 'OleDbDataAdapter
        Try

            OleCom.Connection = Oleconnection_ora
            OleCom.CommandText = strselect
            OleAdap.SelectCommand = OleCom

            Return OleAdap

        Catch ex As Exception

        End Try
    End Function





    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try

            Dim dtStart As String = CDate(hfFrom.Value).ToString("dd-MMM-yy")
            Dim dtEnd As String = CDate(hfTo.Value).ToString("dd-MMM-yy")

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub rdbtnCoilwise_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles rdbtnCoilwise.CheckedChanged
        Try

            txtCoilwise.Enabled = True
            Panel1.Enabled = False

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub rdbtnDatewise_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles rdbtnDatewise.CheckedChanged
        Try

            txtCoilwise.Text = ""
            txtCoilwise.Enabled = False
            Panel1.Enabled = True


        Catch ex As Exception

        End Try
    End Sub






    Private Sub btnOk_Click(sender As Object, e As EventArgs) Handles btnOk.Click
        Try
            If txtCoilwise1.Text <> "" Then
                Dim dt As DataTable = objController.GetParameterForHSM()
                'Dim fromDt As String = hfFrom.Value
                'Dim toDt As String = hfTo.Value
                Dim str1 As String = ""
                'Dim count As Integer = 0
                Dim appendString = ""
                For i As Integer = 0 To dt.Rows.Count - 1

                    'count += 1
                    'str1 &= ",'" & clbcoilid.Items(i).Value & "'"
                    appendString &= "<div class='col-md-12'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>" & dt.Rows(i)(0) & "</h3> <span></span></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='" & dt.Rows(i)(0) & "' style='height: 200px;'></div></div></div></div>"
                Next
                divHolder5.InnerHtml = appendString
                'If str1 = "" Then

                'Else
                'str1 = str1.Substring(1)
                Dim str() As String
                If txtCoilwise1.Text.Contains(",") Then
                    str = txtCoilwise1.Text.Split(",")
                    For i As Integer = 0 To str.Length - 1
                        str1 &= ",'" & Trim(str(i)) & "'"
                    Next
                    str1 = str1.Substring(1)
                Else
                    str1 = "'" & txtCoilwise1.Text.Trim() & "'"
                End If

                DrawChartTop(str1)
                Dim a = dt.AsEnumerable().Select(Function(r) r("Parameter").ToString()).ToArray()

                Dim l As Literal
                For i As Integer = 0 To UBound(a)
                    Dim literals = Page.Master.FindControl("content_body").Controls.OfType(Of Literal)()
                    For Each lit In literals
                        If (lit.ID = "Lit" & i + 5) Then
                            l = lit
                            Exit For
                        End If
                    Next

                    DrawHeatMap(a(i), l, a(i), str1)

                Next

                'End If
            End If
            If txtCoilwise.Text <> "" Then
                Dim str1 As String = ""
                Dim str() As String
                If txtCoilwise.Text.Contains(",") Then
                    str = txtCoilwise.Text.Split(",")
                    For i As Integer = 0 To str.Length - 1
                        str1 &= ",'" & Trim(str(i)) & "'"
                    Next
                    str1 = str1.Substring(1)
                Else
                    str1 = "'" & txtCoilwise.Text.Trim() & "'"
                End If
                DrawChartTop1(str1)
            End If

        Catch ex As Exception

        End Try
    End Sub
    Sub DrawChartTop(ByVal ColumnName As String)
        Try

            'Dim strfrmDt As String = FromDt
            'Dim strToDt As String = ToDt
            CloseConnection()
            Oleconnection_ora.Open()
            ds_wd.Clear()
            dt_wd.Clear()
            ds.Clear()
            dt.Clear()
            Dim OraQuery_maxwidth As String = "Select    max(t2.theo_width) FROM T_HSM_REAL_TIME_DEFECT t1, t_hsm_coil_infos t2  where t2.COIL_ID_SYSTEM In (" & ColumnName & ") "
            Ora_selectquery(OraQuery_maxwidth)
            OleAdap.Fill(ds_wd)
            dt_wd = ds_wd.Tables(0)

            Dim max_width As Double = 1500
            max_width = dt_wd.Rows(0)(0)

            'Dim OraQuery As String = "Select COIL_ID_SYSTEM,TIME_STAMP,SIDE_ID,Y_START_MOTHER_COIL,Y_START_DAUGHTER_COIL As yaxis,X_START_FACTORY As xaxis,LENGTH,WIDTH,LENGTH * WIDTH As bubblesize from TG.T_HSM_REAL_TIME_DEFECT WHERE TIME_STAMP  between '" & CDate(FromDt).ToString("dd-MMM-yy") & "' and '" & CDate(ToDt).ToString("dd-MMM-yy") & "' and COIL_ID_SYSTEM in (" & ColumnName & ")"
            Dim OraQuery As String = "SELECT  t1.coil_id_system,  t1.time_stamp,    t1.side_id, t1.y_start_mother_coil,    t1.y_start_daughter_coil as yaxis, t1.x_start_factory as xaxis1,   t1.length,  t1.width, t1.length*width as bubblesize, " &
                            "  t1.MEASURED_INTENSITY, t1.DENSITY,t1.MEAN_GREY_LEVEL,t1.OBJECT_COUNT,  t2.coil_id_system,   t2.theo_width,    t2.measured_length,   t2.measured_width, " &
                            " ((" & max_width & " - t2.theo_width)/2000 + X_START_FACTORY) as xaxis " &
                             " FROM T_HSM_REAL_TIME_DEFECT t1, t_hsm_coil_infos t2 " &
                            " where t1.MEASURED_FAMILY Like 'RCB' and t1.coil_id_system = t2.coil_id_system and t1.COIL_ID_SYSTEM in (" & ColumnName & ")  order by t1.TIME_STAMP, t1.Y_START_DAUGHTER_COIL"
            ' --and t1.side_id like '0' order by t1.TIME_STAMP, t1.Y_START_DAUGHTER_COIL ;"
            Ora_selectquery(OraQuery)
            OleAdap.Fill(ds)
            dt = ds.Tables(0)

            Dim coilid1, coil As String
            Dim temp_length, total_length_coil As Double

            temp_length = 0
            total_length_coil = 0
            For i As Integer = 1 To dt.Rows.Count - 1
                temp_length = dt.Rows(i - 1)("measured_length")
                If dt.Rows(i)("coil_id_system") = dt.Rows(i - 1)("coil_id_system") Then
                    dt.Rows(i)("yaxis") = total_length_coil + dt.Rows(i)("yaxis")
                Else
                    total_length_coil = total_length_coil + temp_length
                    dt.Rows(i)("yaxis") = total_length_coil + dt.Rows(i)("yaxis")
                End If
                'If dt.Rows(i)("bubblesize") <= 100 Then
                '    dt.Rows(i)("bubblesize") = 5
                'ElseIf dt.Rows(i)("bubblesize") <= 250 Then
                '    dt.Rows(i)("bubblesize") = 11
                'ElseIf dt.Rows(i)("bubblesize") <= 500 Then
                '    dt.Rows(i)("bubblesize") = 17
                'ElseIf dt.Rows(i)("bubblesize") <= 750 Then
                '    dt.Rows(i)("bubblesize") = 25
                'ElseIf dt.Rows(i)("bubblesize") <= 1000 Then
                '    dt.Rows(i)("bubblesize") = 30
                'ElseIf dt.Rows(i)("bubblesize") > 1000 Then
                '    dt.Rows(i)("bubblesize") = 35
                'End If
            Next
            'Dim width_dt As DataTable
            'width_dt.Columns.Add("yaxis")
            'Dim row As DataRow
            'For i As Integer = 0 To total_length_coil
            '    width_dt.Rows.Add()
            '    width_dt.Rows(i)("yaxis") = ""
            '    width_dt.Rows(i)("xaxis") = ""
            '    width_dt.Rows(i)("bubblesize") = 21
            '    width_dt.Rows(i)("coil_id_system") = ""
            '    width_dt.Rows(i)("")

            'Next

            'For Each row In width_dt.Rows
            '    dt.LoadDataRow(row.ItemArray, False)
            'Next
            'Dim dt As DataTable = objController.GetDataForAnalysis("T_CGL_FUR_PARAM", strfrmDt, strToDt, "PRM_TS_END", ColumnName, Filter)

            'Dim a() As String = ColumnName.Split(",")
            'Dim l As Literal
            'For i As Integer = 0 To UBound(a)
            '    Dim literals = Page.Master.FindControl("content_body").Controls.OfType(Of Literal)()
            '    For Each lit In literals
            '        If (lit.ID = "Lit" & i + 1) Then
            '            l = lit
            '            Exit For
            '        End If
            '    Next
            'Next
            '0 is top and 1 is bottom
            'objController.PlotLineChartForAnalysis(dt, "PRM_TS_END", a(i), l, a(i), "plot" & i + 1, "", "", i, chartType)

            PlotBubbleEChart(dt, Lit1, "container", "plot1", "xaxis", "yaxis", "Coil Width, m", "Total Length rolled, m", max_width, 0)
            PlotBubbleEChart(dt, Lit2, "container2", "plot2", "xaxis", "yaxis", "Coil Width, m", "Total Length rolled, m", max_width, 1)


        Catch ex As Exception

        End Try
    End Sub

    Sub DrawHeatMap(ByVal ContainerName As String, ByVal LitName As Literal, ByVal Parameter As String, ByVal CoilId As String)
        Try

            'Dim strfrmDt As String = FromDate
            'Dim strToDt As String = ToDate
            Dim mintemp, maxtemp As Double
            mintemp = -1.0
            maxtemp = 0.0
            'Dim dtmfrmDt As DateTime = strfrmDt
            'Dim dtmToDt As DateTime = strToDt

            'Dim dt As DataTable = objDataHandler.GetDataSetFromQueryLP("select top 20 * from NBM_AlongLength_parameters  where [Blt_temperature_time] between '" & dtmfrmDt.ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & dtmToDt.ToString("yyyy-MM-dd HH:mm:ss") & "' and parameter= '" & Parameter & "' order by [Blt_temperature_time] desc").Tables(0)
            'Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select top 20 * from HSM_AlongLength_parameters  where [Temperature_time] between '" & dtmfrmDt.ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & dtmToDt.ToString("yyyy-MM-dd HH:mm:ss") & "' and Parameter= '" & Parameter & "' order by [Temperature_time] desc").Tables(0)
            Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("Select  TOP(20) [Temperature_time],[Parameter],[0-5]    ,[5-10]  ,[10-15] ,[15-20] ,[20-25] ,[25-30] ,[30-35],[35-40] ,[40-45] " &
                                    " ,[45-50]  ,[50-55] ,[55-60] ,[60-65],[65-70] ,[70-75],[75-80] ,[80-85] ,[85-90] ,[90-95],[95-100] " &
                                    " ,T1.[FUR_No]  ,T1.[HR_COIL_ID]   " &
                                    " From [FP_PROCESS_DATA].[dbo].[HSM_AlongLength_parameters] T1 " &
                                    " Where T1.[HR_COIL_ID] in (" & CoilId & ") and  Parameter = '" & Parameter & "' order by [Temperature_time] desc").Tables(0)
            If dt.Rows.Count > 0 Then

                'For j = 3 To dt.Columns.Count - 1
                '    Dim temp As Double = dt.Compute("Min([" & dt.Columns(j).ColumnName & "])", "")
                '    Dim temp1 As Double = dt.Compute("Max([" & dt.Columns(j).ColumnName & "])", "")
                '    If mintemp = -1.0 Then
                '        mintemp = temp
                '    End If
                '    If temp < mintemp Then
                '        mintemp = temp
                '    End If
                '    If temp1 > maxtemp Then
                '        maxtemp = temp1
                '    End If
                'Next

                
                If Parameter = "CB_BendUt_Top_cur" Or Parameter = "CB_BendUt_Bot_cur" Then
                    mintemp = 100
                    maxtemp = 1000

                ElseIf Parameter = "CB_EXT_TEMP" Then
                    mintemp = 900
                    maxtemp = 1050
                ElseIf Parameter = "CB_BendUt_Bot_Spd" Or Parameter = "CB_BendUt_Top_Spd" Then
                    mintemp = 1
                    maxtemp = 5
                ElseIf Parameter = "RMET" Then
                    mintemp = 1000
                    maxtemp = 1120
                ElseIf Parameter = "CB_PRU_TOPcurr" Or Parameter = "CB_PRU_BOTcurr" Then
                    mintemp = 100
                    maxtemp = 300
                ElseIf Parameter = "CB_PRU_ForceAvg" Then
                    mintemp = 50
                    maxtemp = 250
                ElseIf Parameter = "Sc_desc_Entry_Pres" Or Parameter = "Sc_desc_Ext_Pres" Then
                    mintemp = 150
                    maxtemp = 200
                End If


                Dim StartTime As DateTime = Convert.ToDateTime((dt.Compute("min(Temperature_time)", String.Empty)))
                Dim EndTime As DateTime = Convert.ToDateTime((dt.Compute("max(Temperature_time)", String.Empty)))
                'lblDate.Text = StartTime.ToString("dd-MM-yyyy HH:mm tt") & " - " & EndTime.ToString("dd-MM-yyyy HH:mm tt")
                Dim s As New StringBuilder("<script>")
                s.Append("var hours = ['Head', '10', '15', '20', '25', '30', '35','40','45','50', '55', '60', '65', '70', '75', '80','85','90','95','Tail'];")

                s.Append("var days = [")
                For i As Integer = 0 To dt.Rows.Count - 1
                    If i > 0 Then
                        s.Append(",")
                    End If
                    's.Append("'" & CDate(dt.Rows(i)("Temperature_time")).ToString("dd-MM-yyyy HH:mm") & "'")
                    s.Append("'" & dt.Rows(i)("HR_COIL_ID").ToString().Trim & "'")
                Next
                s.Append("];")
                s.Append("var data = [")
                For i As Integer = 0 To dt.Rows.Count - 1
                    If i > 0 Then
                        s.Append(",")
                    End If
                    For j As Integer = 2 To dt.Columns.Count - 3
                        If j > 2 Then
                            s.Append(",")
                        End If
                        s.Append("[" & (i) & "," & (j - 2) & "," & dt.Rows(i)(j) & "]")
                    Next
                Next
                s.Append("];")
                s.Append("data = data.map(function (item) {return [item[1], item[0], item[2] || '-'];});")
                ''  s.Append("option = {tooltip: { position: 'top',formatter:function(params){var c = Math.round(params.value[2]);var d = days[params.value[1]];return params.name + ': ' + d +  ', ' + c}}, animation: true, grid: { height: '80%', y: '1%' }, xAxis: { type: 'category', data: hours, splitArea: { show: true } }, yAxis: { type: 'category', data: days, splitArea: { show: true } }, visualMap: { min: " & Math.Floor(mintemp) & ", max: " & Math.Floor(maxtemp) & ", calculable: true, orient: 'horizontal', left: 'center', bottom: '0%' }, series: [{ name: 'Billet Temp', type: 'heatmap', data: data, label: { normal: { show: false } }, itemStyle: { emphasis: { shadowBlur: 10, shadowColor: 'rgba(0, 0, 0, 0.5)' } } }] };")
                s.Append("var myChart = echarts.init(document.getElementById('" & ContainerName & "'));")

                s.Append("option = {tooltip: { position: 'bottom',formatter:function(params){var c = Math.round(params.value[2]);var d = days[params.value[1]];return params.name + ': ' + d +  ', ' + c}}, animation: true, grid: { height: '80%', y: '1%' }, xAxis: { type: 'category', data: hours, splitArea: { show: true } }, yAxis: { type: 'category', data: days, splitArea: { show: true } }, visualMap: { min: " & Math.Floor(mintemp) & ", max: " & Math.Floor(maxtemp) & ",")
                s.Append("inRange: { color: ['#fee090', '#fdae61', '#f46d43', '#d73027', '#a50026']},calculable: true, orient: 'horizontal', left: 'center', bottom: '0%' }, series: [{ name: 'Billet Temp', type: 'heatmap', data: data, label: { normal: { show: false } }, itemStyle: { emphasis: { shadowBlur: 10, shadowColor: 'rgba(0, 0, 0, 0.5)' } } }] };")
                s.Append("myChart.setOption(option);")
                s.Append("window.onresize = function() { myChart.resize();};")
                s.Append("</script>")
                LitName.Text = s.ToString()
                'lblmsg.Text = "Show temperature data of last 80 billets"
            Else
                'lblerror.Text = "No Data Found"
                LitName.Text = ""
            End If

        Catch ex As Exception
            'lblerror.Text = ex.ToString
            Lit1.Text = " "
        End Try
    End Sub

    Sub DrawChartTop1(ByVal ColumnName As String)
        Try

            'Dim strfrmDt As String = FromDt
            'Dim strToDt As String = ToDt
            CloseConnection()
            Oleconnection_ora.Open()
            ds_wd.Clear()
            dt_wd.Clear()
            ds.Clear()
            dt.Clear()
            Dim OraQuery_maxwidth As String = "Select    max(t2.theo_width) FROM T_HSM_REAL_TIME_DEFECT t1, t_hsm_coil_infos t2  where t2.COIL_ID_SYSTEM In (" & ColumnName & ") "
            Ora_selectquery(OraQuery_maxwidth)
            OleAdap.Fill(ds_wd)
            dt_wd = ds_wd.Tables(0)

            Dim max_width As Double = 1500
            max_width = dt_wd.Rows(0)(0)

            'Dim OraQuery As String = "Select COIL_ID_SYSTEM,TIME_STAMP,SIDE_ID,Y_START_MOTHER_COIL,Y_START_DAUGHTER_COIL As yaxis,X_START_FACTORY As xaxis,LENGTH,WIDTH,LENGTH * WIDTH As bubblesize from TG.T_HSM_REAL_TIME_DEFECT WHERE TIME_STAMP  between '" & CDate(FromDt).ToString("dd-MMM-yy") & "' and '" & CDate(ToDt).ToString("dd-MMM-yy") & "' and COIL_ID_SYSTEM in (" & ColumnName & ")"
            Dim OraQuery As String = "SELECT  t1.coil_id_system,  t1.time_stamp,    t1.side_id, t1.y_start_mother_coil,    t1.y_start_daughter_coil as yaxis, t1.x_start_factory as xaxis1,   t1.length,  t1.width, t1.length*width as bubblesize, " &
                            "  t1.MEASURED_INTENSITY, t1.DENSITY,t1.MEAN_GREY_LEVEL,t1.OBJECT_COUNT,  t2.coil_id_system,   t2.theo_width,    t2.measured_length,   t2.measured_width, " &
                            " ((" & max_width & " - t2.theo_width)/2000 + X_START_FACTORY) as xaxis " &
                             " FROM T_HSM_REAL_TIME_DEFECT t1, t_hsm_coil_infos t2 " &
                            " where t1.MEASURED_FAMILY Like 'RCB' and t1.coil_id_system = t2.coil_id_system and t1.COIL_ID_SYSTEM in (" & ColumnName & ")  order by t1.TIME_STAMP, t1.Y_START_DAUGHTER_COIL"
            ' --and t1.side_id like '0' order by t1.TIME_STAMP, t1.Y_START_DAUGHTER_COIL ;"
            Ora_selectquery(OraQuery)
            OleAdap.Fill(ds)
            dt = ds.Tables(0)

            Dim coilid1, coil As String
            Dim temp_length, total_length_coil As Double

            temp_length = 0
            total_length_coil = 0
            For i As Integer = 1 To dt.Rows.Count - 1
                temp_length = dt.Rows(i - 1)("measured_length")
                If dt.Rows(i)("coil_id_system") = dt.Rows(i - 1)("coil_id_system") Then
                    dt.Rows(i)("yaxis") = total_length_coil + dt.Rows(i)("yaxis")
                Else
                    total_length_coil = total_length_coil + temp_length
                    dt.Rows(i)("yaxis") = total_length_coil + dt.Rows(i)("yaxis")
                End If
                'If dt.Rows(i)("bubblesize") <= 100 Then
                '    dt.Rows(i)("bubblesize") = 5
                'ElseIf dt.Rows(i)("bubblesize") <= 250 Then
                '    dt.Rows(i)("bubblesize") = 11
                'ElseIf dt.Rows(i)("bubblesize") <= 500 Then
                '    dt.Rows(i)("bubblesize") = 17
                'ElseIf dt.Rows(i)("bubblesize") <= 750 Then
                '    dt.Rows(i)("bubblesize") = 25
                'ElseIf dt.Rows(i)("bubblesize") <= 1000 Then
                '    dt.Rows(i)("bubblesize") = 30
                'ElseIf dt.Rows(i)("bubblesize") > 1000 Then
                '    dt.Rows(i)("bubblesize") = 35
                'End If
            Next
            'Dim width_dt As DataTable
            'width_dt.Columns.Add("yaxis")
            'Dim row As DataRow
            'For i As Integer = 0 To total_length_coil
            '    width_dt.Rows.Add()
            '    width_dt.Rows(i)("yaxis") = ""
            '    width_dt.Rows(i)("xaxis") = ""
            '    width_dt.Rows(i)("bubblesize") = 21
            '    width_dt.Rows(i)("coil_id_system") = ""
            '    width_dt.Rows(i)("")

            'Next

            'For Each row In width_dt.Rows
            '    dt.LoadDataRow(row.ItemArray, False)
            'Next
            'Dim dt As DataTable = objController.GetDataForAnalysis("T_CGL_FUR_PARAM", strfrmDt, strToDt, "PRM_TS_END", ColumnName, Filter)

            'Dim a() As String = ColumnName.Split(",")
            'Dim l As Literal
            'For i As Integer = 0 To UBound(a)
            '    Dim literals = Page.Master.FindControl("content_body").Controls.OfType(Of Literal)()
            '    For Each lit In literals
            '        If (lit.ID = "Lit" & i + 1) Then
            '            l = lit
            '            Exit For
            '        End If
            '    Next
            'Next
            '0 is top and 1 is bottom
            'objController.PlotLineChartForAnalysis(dt, "PRM_TS_END", a(i), l, a(i), "plot" & i + 1, "", "", i, chartType)
            PlotBubbleEChart(dt, Lit3, "container3", "plot3", "xaxis", "yaxis", "Coil Width, m", "Total Length rolled, m", max_width, 0)
            PlotBubbleEChart(dt, Lit4, "container4", "plot4", "xaxis", "yaxis", "Coil Width, m", "Total Length rolled, m", max_width, 1)

            Dim dt1 As DataTable = objController.GetParameterForHSM()
            'Dim fromDt As String = hfFrom.Value
            'Dim toDt As String = hfTo.Value
            Dim str1 As String = ""
            'Dim count As Integer = 0
            Dim appendString = ""
            For i As Integer = 0 To dt1.Rows.Count - 1
                'count += 1
                'str1 &= ",'" & clbcoilid.Items(i).Value & "'"
                appendString &= "<div class='col-md-12'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>" & dt1.Rows(i)(0) & "</h3> <span></span></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='" & dt1.Rows(i)(0) & "" & i & "' style='height: 200px;'></div></div></div></div>"

            Next

            divHolder6.InnerHtml = appendString
            'If str1 = "" Then

            'Else
            'str1 = str1.Substring(1)
            Dim str() As String
            If txtCoilwise.Text.Contains(",") Then
                str = txtCoilwise.Text.Split(",")
                For i As Integer = 0 To str.Length - 1
                    str1 &= ",'" & Trim(str(i)) & "'"
                Next
                str1 = str1.Substring(1)
            Else
                str1 = "'" & txtCoilwise.Text & "'"
            End If




            'DrawChartTop(str1)


            Dim a = dt1.AsEnumerable().Select(Function(r) r("Parameter").ToString()).ToArray()

            Dim l As Literal
            For i As Integer = 0 To UBound(a)
                Dim literals = Page.Master.FindControl("content_body").Controls.OfType(Of Literal)()
                For Each lit In literals
                    If (lit.ID = "Lit" & i + 18) Then
                        l = lit
                        Exit For
                    End If
                Next

                DrawHeatMap(a(i) & i, l, a(i), str1)

            Next


        Catch ex As Exception

        End Try
    End Sub

    Public Sub PlotBubbleEChart(ByVal dt As DataTable, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal xcol As String, ByVal ycol As String, ByVal XAxisLabelName As String, ByVal YAxisLabelName As String, ByVal max_width As Double, ByVal surface As Integer)
        ' Try

        LiteralName.Text = ""

        Dim data As String = ""
        Dim coilid As String = ""
        dt.DefaultView.RowFilter = String.Empty
        Dim dtcoil As DataTable = dt.DefaultView.ToTable(True, "COIL_ID_SYSTEM")
        Dim dataView As DataView = dt.DefaultView
        Dim y_axis_max As Double = Math.Floor(dt.Rows(dt.Rows.Count - 1)(ycol))




        data &= "["
        For i As Integer = 0 To dtcoil.Rows.Count - 1
            dataView.RowFilter = " COIL_ID_SYSTEM  ='" & dtcoil.Rows(i)(0) & "' AND  SIDE_ID  ='" & surface & "' "
            coilid &= ",'" & dtcoil.Rows(i)(0) & "'"
            data &= "["
            For j As Integer = 0 To dataView.Count - 1
                If j > 0 Then
                    data &= ","
                End If
                data &= "" & "[" & dataView.Item(j)(xcol) & "," & dataView.Item(j)(ycol) & "," & dataView.Item(j)("bubblesize") & "," & dataView.Item(j)("COIL_ID_SYSTEM") & "," & dataView.Item(j)("COIL_ID_SYSTEM") & "]"
                'data &= "," & "[" & i + 1 & "," & dt.Rows(i)(ycol) & "]"
                'coilid &= ",'" & dt.Rows(i)("COIL_ID_SYSTEM") & "'"
            Next
            data &= "],"
        Next
        For i As Integer = 0 To 0
            coilid &= ",'OperSide'"
            data &= "["
            For j As Integer = 0 To dt.Rows.Count - 1
                If j > 0 Then
                    data &= ","
                End If
                data &= "" & "[" & (max_width - dt.Rows(j)("Theo_width")) / 2000 + dt.Rows(j)("Theo_width") / 1000 & "," & dt.Rows(j)(ycol) & ", 10 ,'OperSide','OperSide']"
                'data &= "," & "[" & i + 1 & "," & dt.Rows(i)(ycol) & "]"
                'coilid &= ",'" & dt.Rows(i)("COIL_ID_SYSTEM") & "'"
            Next
            data &= "],"
        Next
        For i As Integer = 0 To 0
            coilid &= ",'DrvSide'"
            data &= "["
            For j As Integer = 0 To dt.Rows.Count - 1
                If j > 0 Then
                    data &= ","
                End If
                data &= "" & "[" & (max_width - dt.Rows(j)("Theo_width")) / 2000 & "," & dt.Rows(j)(ycol) & ", 10 ,'DrvSide','DrvSide']"
                'data &= "," & "[" & i + 1 & "," & dt.Rows(i)(ycol) & "]"
                'coilid &= ",'" & dt.Rows(i)("COIL_ID_SYSTEM") & "'"
            Next
            data &= "],"
        Next

        'data &= "]"
        data = data.Remove(data.LastIndexOf(","))
        data &= "];"
        coilid = coilid.Substring(1)
        'data = data.Substring(1)

        '' dv.Item(0)("lenseverity")
        Dim s As New StringBuilder("<script>")

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        s.Append(" var myChart = echarts.init(document.getElementById('" & ContainerName & "'));")
        's.Append("{")
        s.Append("data = " & data & "")
        s.Append("option = {")
        's.Append("backgroundColor: new echarts.graphic.RadialGradient(0.3, 0.3, 0.8, [{")
        's.Append("offset: 0,")
        's.Append("color: '#f7f8fa'")
        's.Append("}, {")
        's.Append("offset: 1,")
        's.Append("color: '#cdd0d5'")
        's.Append("}]),")
        s.Append("title: {")
        s.Append("text: ''")
        'violet,pink, red,, blue green,yellow,brown,blueish,reddish,pinkish
        s.Append("},color:['#a042eb','#f7b2ad','#de3c2a','#615cdb','#40c244','#d9d645','#de873c','#2ed1ce','#d12e2e','#e342c3'],")
        's.Append("},")
        s.Append("grid: {left: '12%',right: '15%', bottom: '10%'},")
        s.Append("legend: {")
        s.Append("right: 'right',")
        s.Append("data: [" & coilid & "]")
        s.Append("},")
        s.Append("tooltip: {")
        s.Append("trigger: 'axis'")
        s.Append("},")

        s.Append("xAxis: {  name: '" & XAxisLabelName & "',")
        s.Append("nameLocation:'middle',")
        s.Append("nameTextStyle:{color:'black',fontWeight:'bold',fontFamily: 'serif',fontSize: 18}, ")
        s.Append("nameGap:35,")
        s.Append(" splitLine: { show: false},")
        s.Append("axisLine: {lineStyle: { color: '#000000',width: 2,}},")
        s.Append("},")

        s.Append("yAxis: {  name: '" & YAxisLabelName & "',")
        s.Append("nameLocation:'middle',")
        s.Append("min:0, max:" & y_axis_max & ", ")
        s.Append("nameTextStyle:{color:'black',fontWeight:'bold',fontFamily: 'serif',fontSize: 18}, ")
        s.Append("nameGap:40,")
        s.Append(" splitLine: { show: false},")
        s.Append("axisLine: {lineStyle: { color: '#000000',width: 0,}},")
        s.Append("},")

        s.Append("toolbox: {")
        s.Append(" left: 'left',")
        s.Append("feature: {")
        s.Append("dataZoom: {")
        s.Append("yAxisIndex: 'none'")
        s.Append("},")
        s.Append("restore: {},")
        s.Append("saveAsImage: {}")
        s.Append("}")
        s.Append("},")

        s.Append("series: [")
        s.Append("")
        Dim strseries As String = ""
        For i As Integer = 0 To dtcoil.Rows.Count - 1
            'strseries &= "{name:"" '" & dtcoil.Rows(i)(0) & "',data: data[" & i & "], type: 'scatter',symbolSize:function (data) { return data[2];},emphasis: { label: { show: true, formatter: Function (param) { Return  param.data[3];},position: 'top'}}, itemStyle: { shadowBlur: 10, shadowColor: 'rgba(120, 36, 50, 0.5)',shadowOffsetY: 5, color: New echarts.graphic.RadialGradient(0.4, 0.3, 1, [{ offset: 0, color: 'rgb(251, 118, 123)' }, { offset: 1, color: 'rgb(204, 46, 72)' }]) }},"
            strseries &= "{name: '" & dtcoil.Rows(i)(0) & "',data: data[" & i & "], type: 'scatter',symbolSize:function (data) { return Math.sqrt(data[2])/10;},emphasis: { label: { show: true, formatter: function (param) { return  param.data[3];},position: 'top'}}, itemStyle: { shadowBlur: 10, shadowColor: 'rgba(120, 36, 50, 0.5)',shadowOffsetY: 5}},"
        Next
        strseries &= "{name: 'OperSide',data: data[" & dtcoil.Rows.Count & "], type: 'scatter',symbolSize:function (data) { return Math.sqrt(data[2]);},emphasis: { label: { show: true, formatter: function (param) { return  param.data[3];},position: 'top'}}, itemStyle: {color:'black'}},"
        strseries &= "{name: 'DrvSide',data: data[" & dtcoil.Rows.Count + 1 & "], type: 'scatter',symbolSize:function (data) { return Math.sqrt(data[2]);},emphasis: { label: { show: true, formatter: function (param) { return  param.data[3];},position: 'top'}}, itemStyle: { color:'#0a0a0a'}},"

        s.Append(strseries)
        ' s.Append("},")

        s.Append("]")
        s.Append("};")

        s.Append(" myChart.setOption(option);")
        s.Append("</script>")
        LiteralName.Text = s.ToString()


        'Catch ex As Exception

        'End Try
    End Sub



End Class
