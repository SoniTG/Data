﻿
Imports System.Data
Imports System.IO

Imports System.Web
Imports System.Web.Services

Imports System.Net
Imports System.Data.SqlClient
Imports System.Web.Script.Serialization
Imports System.Drawing
Imports System.Web.UI

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
<System.Web.Script.Services.ScriptService()>
<WebService(Namespace:="http://tempuri.org/")>
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)>
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class HeatDistributionModel
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim objdatahandler As New DataHandler

    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Dim TOTAL_SPEC As String = ""
    Dim SPECTOTAL As Decimal
    Function getdatatable(ByVal query As String) As DataTable
        Dim fndatatable As New DataTable
        Dim connection As String = "Password=Welcome@135;Persist Security Info=True;User ID=153521;Initial Catalog=FP_PROCESS_DATA;Data Source=176.0.0.60\lptgsqldev"
        Using con As New SqlConnection(connection)
            Using cmd As New SqlCommand(query, con)
                cmd.CommandType = CommandType.Text
                cmd.CommandTimeout = 1000000000
                Using sda As New SqlDataAdapter(cmd)
                    'Using dt As New DataTable()
                    sda.Fill(fndatatable)
                    'End Using
                End Using
            End Using
        End Using
        Return fndatatable
    End Function


    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                MultiView1.ActiveViewIndex = 0
                DrawChartFor_on_toDate()
                If rbdChartLineA.Checked Then
                    If rbdChartAvgValue.Checked Then
                        DrawChartForLINEA()
                    ElseIf rbdChartthisMonthValue.Checked Then
                        DrawChartForLINEA()
                    End If
                    '===========================
                ElseIf rbdChartLineB.Checked Then
                    ' DrawChartForLINEB()
                    If rbdChartAvgValue.Checked Then
                        DrawChartForLINEB()
                    ElseIf rbdChartthisMonthValue.Checked Then
                        DrawChartForLINEB()
                    End If

                    ' DrawChartForLINEA_LINEB()
                    '=====================================
                ElseIf rbdChartLineA_LineB.Checked Then
                    '  DrawChartForLINEA_LINEB()
                    If rbdChartAvgValue.Checked Then
                        ' DrawChartForLINEA()
                        DrawChartForLINEA_LINEB()
                    ElseIf rbdChartthisMonthValue.Checked Then
                        DrawChartForLINEA_LINEB()
                    End If
                    '====================================
                End If
                '=========================================
                ' GETSPEC_TOTAL(stdategrid, enddategrid)

                'TC and Zone Temperature Code Start

                Dim sqlQuery As String = "Select Top 1 TIMESTAMP,LINE,"
                sqlQuery &= " ZONE1_TC1, ZONE1_TC2, ZONE1_TC3, Cast((ZONE1_TC1 + ZONE1_TC2 + ZONE1_TC3) / 3 As Integer) As AvgZone1,"
                sqlQuery &= " ZONE2_TC1, ZONE2_TC2, ZONE2_TC3, Cast((ZONE2_TC1 + ZONE2_TC2 + ZONE2_TC3) / 3 As Integer) As AvgZone2,"
                sqlQuery &= " ZONE3_TC1, ZONE3_TC2, ZONE3_TC3, Cast((ZONE3_TC1 + ZONE3_TC2 + ZONE3_TC3) / 3 As Integer) As AvgZone3,"
                sqlQuery &= " ZONE4_TC1, ZONE4_TC2, ZONE4_TC3, Cast((ZONE4_TC1 + ZONE4_TC2 + ZONE4_TC3) / 3 As Integer) As AvgZone4,"
                sqlQuery &= " ZONE5_TC1, ZONE5_TC2, ZONE5_TC3, Cast((ZONE5_TC1 + ZONE5_TC2 + ZONE5_TC3) / 3 As Integer) As AvgZone5,"
                sqlQuery &= " ZONE6_TC1, ZONE6_TC2, ZONE6_TC3, Cast((ZONE6_TC1 + ZONE6_TC2 + ZONE6_TC3) / 3 As Integer) As AvgZone6,"
                sqlQuery &= " ZONE7_TC1, ZONE7_TC2, ZONE7_TC3, Cast((ZONE7_TC1 + ZONE7_TC2 + ZONE7_TC3) / 3 As Integer) As AvgZone7,"
                sqlQuery &= " ZONE8_TC1, ZONE8_TC2, ZONE8_TC3, Cast((ZONE8_TC1 + ZONE8_TC2 + ZONE8_TC3) / 3 As Integer) As AvgZone8,"
                sqlQuery &= " ZONE9_TC1, ZONE9_TC2, ZONE9_TC3, Cast((ZONE9_TC1 + ZONE9_TC2 + ZONE9_TC3) / 3 As Integer) as AvgZone9"
                sqlQuery &= " From TSCR_FURNACE_ZONE_TEMP  Where Line = 'A' Order By TIMESTAMP desc"

                Dim dt As DataTable = New DataTable()
                dt = getdatatable(sqlQuery)
                For Each row As DataRow In dt.Rows
                    btnZ1TC1.Text = "TC101: " & row("ZONE1_TC1")
                    btnZ1TC2.Text = "TC102: " & row("ZONE1_TC2")
                    btnZ1TC3.Text = "TC103: " & row("ZONE1_TC3")
                    btnZ1Avg.Text = "Avg Temp : " & row("AvgZone1")
                    btnZ2TC1.Text = "TC201: " & row("ZONE2_TC1")
                    btnZ2TC2.Text = "TC202: " & row("ZONE2_TC2")
                    btnZ2TC3.Text = "TC203: " & row("ZONE2_TC3")
                    btnZ2Avg.Text = "Avg Temp : " & row("AvgZone2")
                    btnZ3TC1.Text = "TC301: " & row("ZONE3_TC1")
                    btnZ3TC2.Text = "TC302: " & row("ZONE3_TC2")
                    btnZ3TC3.Text = "TC303: " & row("ZONE3_TC3")
                    btnZ3Avg.Text = "Avg Temp : " & row("AvgZone3")
                    btnZ4TC1.Text = "TC401: " & row("ZONE4_TC1")
                    btnZ4TC2.Text = "TC402: " & row("ZONE4_TC2")
                    btnZ4TC3.Text = "TC403: " & row("ZONE4_TC3")
                    btnZ4Avg.Text = "Avg Temp : " & row("AvgZone4")
                    btnZ5TC1.Text = "TC501: " & row("ZONE5_TC1")
                    btnZ5TC2.Text = "TC502: " & row("ZONE5_TC2")
                    btnZ5TC3.Text = "TC503: " & row("ZONE5_TC3")
                    btnZ5Avg.Text = "Avg Temp : " & row("AvgZone5")
                    btnZ6TC1.Text = "TC601: " & row("ZONE6_TC1")
                    btnZ6TC2.Text = "TC602: " & row("ZONE6_TC2")
                    btnZ6TC3.Text = "TC603: " & row("ZONE6_TC3")
                    btnZ6Avg.Text = "Avg Temp : " & row("AvgZone6")
                    btnZ7TC1.Text = "TC701: " & row("ZONE7_TC1")
                    btnZ7TC2.Text = "TC702: " & row("ZONE7_TC2")
                    btnZ7TC3.Text = "TC703: " & row("ZONE7_TC3")
                    btnZ7Avg.Text = "Avg Temp : " & row("AvgZone7")
                    btnZ8TC1.Text = "TC801: " & row("ZONE8_TC1")
                    btnZ8TC2.Text = "TC802: " & row("ZONE8_TC2")
                    btnZ8TC3.Text = "TC803: " & row("ZONE8_TC3")
                    btnZ8Avg.Text = "Avg Temp : " & row("AvgZone8")
                    btnZ9TC1.Text = "TC901: " & row("ZONE9_TC1")
                    btnZ9TC2.Text = "TC902: " & row("ZONE9_TC2")
                    btnZ9TC3.Text = "TC903: " & row("ZONE9_TC3")
                    btnZ9Avg.Text = "Avg Temp : " & row("AvgZone9")
                Next row
                'TC and Zone Temperature Code End

                Dim sqlQueryLB As String = "Select Top 1 TIMESTAMP,LINE,"
                sqlQueryLB &= " ZONE1_TC1, ZONE1_TC2, ZONE1_TC3, Cast((ZONE1_TC1 + ZONE1_TC2 + ZONE1_TC3) / 3 As Integer) As AvgZone1,"
                sqlQueryLB &= " ZONE2_TC1, ZONE2_TC2, ZONE2_TC3, Cast((ZONE2_TC1 + ZONE2_TC2 + ZONE2_TC3) / 3 As Integer) As AvgZone2,"
                sqlQueryLB &= " ZONE3_TC1, ZONE3_TC2, ZONE3_TC3, Cast((ZONE3_TC1 + ZONE3_TC2 + ZONE3_TC3) / 3 As Integer) As AvgZone3,"
                sqlQueryLB &= " ZONE4_TC1, ZONE4_TC2, ZONE4_TC3, Cast((ZONE4_TC1 + ZONE4_TC2 + ZONE4_TC3) / 3 As Integer) As AvgZone4,"
                sqlQueryLB &= " ZONE5_TC1, ZONE5_TC2, ZONE5_TC3, Cast((ZONE5_TC1 + ZONE5_TC2 + ZONE5_TC3) / 3 As Integer) As AvgZone5,"
                sqlQueryLB &= " ZONE6_TC1, ZONE6_TC2, ZONE6_TC3, Cast((ZONE6_TC1 + ZONE6_TC2 + ZONE6_TC3) / 3 As Integer) As AvgZone6,"
                sqlQueryLB &= " ZONE7_TC1, ZONE7_TC2, ZONE7_TC3, Cast((ZONE7_TC1 + ZONE7_TC2 + ZONE7_TC3) / 3 As Integer) As AvgZone7,"
                sqlQueryLB &= " ZONE8_TC1, ZONE8_TC2, ZONE8_TC3, Cast((ZONE8_TC1 + ZONE8_TC2 + ZONE8_TC3) / 3 As Integer) As AvgZone8"
                'sqlQueryLB &= " ZONE9_TC1, ZONE9_TC2, ZONE9_TC3, Cast((ZONE9_TC1 + ZONE9_TC2 + ZONE9_TC3) / 3 As Integer) as AvgZone9"
                sqlQueryLB &= " From TSCR_FURNACE_ZONE_TEMP  Where Line = 'B' Order By TIMESTAMP desc"

                Dim dtLB As DataTable = New DataTable()
                dtLB = getdatatable(sqlQueryLB)
                For Each row As DataRow In dtLB.Rows
                    btnLBZ1TC1.Text = "TC101: " & row("ZONE1_TC1")
                    btnLBZ1TC2.Text = "TC102: " & row("ZONE1_TC2")
                    btnLBZ1TC3.Text = "TC103: " & row("ZONE1_TC3")
                    btnLBZ1Avg.Text = "Avg Temp : " & row("AvgZone1")
                    btnLBZ2TC1.Text = "TC201: " & row("ZONE2_TC1")
                    btnLBZ2TC2.Text = "TC202: " & row("ZONE2_TC2")
                    btnLBZ2TC3.Text = "TC203: " & row("ZONE2_TC3")
                    btnLBZ2Avg.Text = "Avg Temp : " & row("AvgZone2")
                    btnLBZ3TC1.Text = "TC301: " & row("ZONE3_TC1")
                    btnLBZ3TC2.Text = "TC302: " & row("ZONE3_TC2")
                    btnLBZ3TC3.Text = "TC303: " & row("ZONE3_TC3")
                    btnLBZ3Avg.Text = "Avg Temp : " & row("AvgZone3")
                    btnLBZ4TC1.Text = "TC401: " & row("ZONE4_TC1")
                    btnLBZ4TC2.Text = "TC402: " & row("ZONE4_TC2")
                    btnLBZ4TC3.Text = "TC403: " & row("ZONE4_TC3")
                    btnLBZ4Avg.Text = "Avg Temp : " & row("AvgZone4")
                    btnLBZ5TC1.Text = "TC501: " & row("ZONE5_TC1")
                    btnLBZ5TC2.Text = "TC502: " & row("ZONE5_TC2")
                    btnLBZ5TC3.Text = "TC503: " & row("ZONE5_TC3")
                    btnLBZ5Avg.Text = "Avg Temp : " & row("AvgZone5")
                    btnLBZ6TC1.Text = "TC601: " & row("ZONE6_TC1")
                    btnLBZ6TC2.Text = "TC602: " & row("ZONE6_TC2")
                    btnLBZ6TC3.Text = "TC603: " & row("ZONE6_TC3")
                    btnLBZ6Avg.Text = "Avg Temp : " & row("AvgZone6")
                    btnLBZ7TC1.Text = "TC701: " & row("ZONE7_TC1")
                    btnLBZ7TC2.Text = "TC702: " & row("ZONE7_TC2")
                    btnLBZ7TC3.Text = "TC703: " & row("ZONE7_TC3")
                    btnLBZ7Avg.Text = "Avg Temp : " & row("AvgZone7")
                    btnLBZ8TC1.Text = "TC801: " & row("ZONE8_TC1")
                    btnLBZ8TC2.Text = "TC802: " & row("ZONE8_TC2")
                    btnLBZ8TC3.Text = "TC803: " & row("ZONE8_TC3")
                    btnLBZ8Avg.Text = "Avg Temp : " & row("AvgZone8")
                Next row

                '''''''''''''''''''''COLOUR CODING WITH DEFAULT COLOUR GREEN FOR LINE-A TC''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                btnZ1TC1.BackColor = Color.GreenYellow
                btnZ1TC2.BackColor = Color.GreenYellow
                btnZ1TC3.BackColor = Color.GreenYellow
                btnZ1Avg.BackColor = Color.GreenYellow

                btnZ2TC1.BackColor = Color.GreenYellow
                btnZ2TC2.BackColor = Color.GreenYellow
                btnZ2TC3.BackColor = Color.GreenYellow
                btnZ2Avg.BackColor = Color.GreenYellow

                btnZ3TC1.BackColor = Color.GreenYellow
                btnZ3TC2.BackColor = Color.GreenYellow
                btnZ3TC3.BackColor = Color.GreenYellow
                btnZ3Avg.BackColor = Color.GreenYellow

                btnZ4TC1.BackColor = Color.GreenYellow
                btnZ4TC2.BackColor = Color.GreenYellow
                btnZ4TC3.BackColor = Color.GreenYellow
                btnZ4Avg.BackColor = Color.GreenYellow

                btnZ5TC1.BackColor = Color.GreenYellow
                btnZ5TC2.BackColor = Color.GreenYellow
                btnZ5TC3.BackColor = Color.GreenYellow
                btnZ5Avg.BackColor = Color.GreenYellow

                btnZ6TC1.BackColor = Color.GreenYellow
                btnZ6TC2.BackColor = Color.GreenYellow
                btnZ6TC3.BackColor = Color.GreenYellow
                btnZ6Avg.BackColor = Color.GreenYellow

                btnZ7TC1.BackColor = Color.GreenYellow
                btnZ7TC2.BackColor = Color.GreenYellow
                btnZ7TC3.BackColor = Color.GreenYellow
                btnZ7Avg.BackColor = Color.GreenYellow

                btnZ8TC1.BackColor = Color.GreenYellow
                btnZ8TC2.BackColor = Color.GreenYellow
                btnZ8TC3.BackColor = Color.GreenYellow
                btnZ8Avg.BackColor = Color.GreenYellow

                btnZ9TC1.BackColor = Color.GreenYellow
                btnZ9TC2.BackColor = Color.GreenYellow
                btnZ9TC3.BackColor = Color.GreenYellow
                btnZ9Avg.BackColor = Color.GreenYellow


                '''''''''''''''''''''COLOUR CODING WITH DEFAULT COLOUR GREEN FOR LINE-A TC''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                btnLBZ1TC1.BackColor = Color.GreenYellow
                btnLBZ1TC2.BackColor = Color.GreenYellow
                btnLBZ1TC3.BackColor = Color.GreenYellow
                btnLBZ1Avg.BackColor = Color.GreenYellow

                btnLBZ2TC1.BackColor = Color.GreenYellow
                btnLBZ2TC2.BackColor = Color.GreenYellow
                btnLBZ2TC3.BackColor = Color.GreenYellow
                btnLBZ2Avg.BackColor = Color.GreenYellow

                btnLBZ3TC1.BackColor = Color.GreenYellow
                btnLBZ3TC2.BackColor = Color.GreenYellow
                btnLBZ3TC3.BackColor = Color.GreenYellow
                btnLBZ3Avg.BackColor = Color.GreenYellow

                btnLBZ4TC1.BackColor = Color.GreenYellow
                btnLBZ4TC2.BackColor = Color.GreenYellow
                btnLBZ4TC3.BackColor = Color.GreenYellow
                btnLBZ4Avg.BackColor = Color.GreenYellow

                btnLBZ5TC1.BackColor = Color.GreenYellow
                btnLBZ5TC2.BackColor = Color.GreenYellow
                btnLBZ5TC3.BackColor = Color.GreenYellow
                btnLBZ5Avg.BackColor = Color.GreenYellow

                btnLBZ6TC1.BackColor = Color.GreenYellow
                btnLBZ6TC2.BackColor = Color.GreenYellow
                btnLBZ6TC3.BackColor = Color.GreenYellow
                btnLBZ6Avg.BackColor = Color.GreenYellow

                btnLBZ7TC1.BackColor = Color.GreenYellow
                btnLBZ7TC2.BackColor = Color.GreenYellow
                btnLBZ7TC3.BackColor = Color.GreenYellow
                btnLBZ7Avg.BackColor = Color.GreenYellow

                btnLBZ8TC1.BackColor = Color.GreenYellow
                btnLBZ8TC2.BackColor = Color.GreenYellow
                btnLBZ8TC3.BackColor = Color.GreenYellow
                btnLBZ8Avg.BackColor = Color.GreenYellow


                ActualPredictionLineAZ1TC1()
                ActualPredictionLineAZ1TC2()
                ActualPredictionLineAZ1TC3()
                ActualPredictionLineAZ2TC1()
                ActualPredictionLineAZ2TC2()
                ActualPredictionLineAZ2TC3()
                ActualPredictionLineAZ3TC1()
                ActualPredictionLineAZ3TC2()
                ActualPredictionLineAZ3TC3()
                ActualPredictionLineAZ4TC1()
                ActualPredictionLineAZ4TC2()
                ActualPredictionLineAZ4TC3()
                ActualPredictionLineAZ5TC1()
                ActualPredictionLineAZ5TC2()
                ActualPredictionLineAZ5TC3()
                ActualPredictionLineAZ6TC1()
                ActualPredictionLineAZ6TC2()
                ActualPredictionLineAZ6TC3()
                ActualPredictionLineAZ7TC1()
                ActualPredictionLineAZ7TC2()
                ActualPredictionLineAZ7TC3()
                ActualPredictionLineAZ8TC1()
                ActualPredictionLineAZ8TC2()
                ActualPredictionLineAZ8TC3()
                ActualPredictionLineAZ9TC1()
                ActualPredictionLineAZ9TC2()
                ActualPredictionLineAZ9TC3()

                ActualPredictionLineBZ1TC1()
                ActualPredictionLineBZ1TC2()
                ActualPredictionLineBZ1TC3()
                ActualPredictionLineBZ2TC1()
                ActualPredictionLineBZ2TC2()
                ActualPredictionLineBZ2TC3()
                ActualPredictionLineBZ3TC1()
                ActualPredictionLineBZ3TC2()
                ActualPredictionLineBZ3TC3()
                ActualPredictionLineBZ4TC1()
                ActualPredictionLineBZ4TC2()
                ActualPredictionLineBZ4TC3()
                ActualPredictionLineBZ5TC1()
                ActualPredictionLineBZ5TC2()
                ActualPredictionLineBZ5TC3()
                ActualPredictionLineBZ6TC1()
                ActualPredictionLineBZ6TC2()
                ActualPredictionLineBZ6TC3()
                ActualPredictionLineBZ7TC1()
                ActualPredictionLineBZ7TC2()
                ActualPredictionLineBZ7TC3()
                ActualPredictionLineBZ8TC1()
                ActualPredictionLineBZ8TC2()
                ActualPredictionLineBZ8TC3()

                Session("TimeSelected") = ""


            Catch ex As Exception
                Throw ex
            End Try
        End If
        ShowTCDeviationLineA()
        ShowTCDeviationLineB()


        'Dim timer As Timer = New Timer()
        'timer.Interval = 500
        'timer.Enabled = False
        'timer.Start()
        'timer.Tick += New EventHandler(timer_Tick)



        If MultiView1.ActiveViewIndex = 0 Then

            '========================================================================
            Dim dSdate As DataTable = objController.PopulateMaxDatetime()

            'Dim dSdate As DataSet = objdatahandler.GetDataSetFromQuery("Select max(datetime) As DATETIME FROM  [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]")

            '  Dim dtdate As DataTable = dSdate.Tables(0)
            Dim dtdate As DataTable = dSdate

            Dim ddtdate As DateTime = CDate(dtdate.Rows(0)(0))
            Dim frmDate As String = ddtdate.ToString("yyyy-MM-dd HH:mm:ss")
            Dim toDate As String = ddtdate.AddHours(-1).ToString("yyyy-MM-dd HH:mm:ss")

            lblMAXDATETIME.Text = frmDate
            '===========================================================================

            '========================GRID_VALUE===================================================
            Try


                Dim dtEndgrid As String = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd")
                Dim dtStartgrid As String = DateTime.Now.ToString("yyyy-MM-dd")

                Dim strfrmDtgrid As String = dtStartgrid
                Dim strToDtgrid As String = dtEndgrid


                Dim Monthgrid As String = DateTime.Now.ToString("MM")

                Dim yeargrid As String = DateTime.Now.ToString("yyyy")

                Dim first_dategrid As String = 1



                Dim stdategrid As String = yeargrid & "-" & Monthgrid & "-" & first_dategrid
                '  Dim stdate As String = DateTime.Now.AddDays(-3).ToString("yyyy-MM-dd")
                Dim enddategrid As String = DateTime.Now.ToString("yyyy-MM-dd")

                GETSPEC_TOTAL(stdategrid, enddategrid)

                Dim sum, count As Double
                For Each s As String In TOTAL_SPEC.Split(",")
                    If Not String.IsNullOrEmpty(s) Then
                        sum += s
                        count += 1
                    End If

                Next
                Dim VAL_SPEC As Decimal = sum / count
                Dim SPECTOTAL As Decimal = FormatNumber(VAL_SPEC, 4)

                'lblSpecific.Text = SPECTOTAL 'sum / count
                Dim sqlQueryCum As String = "select top 1 [CUM_SPEC_FUEL_CON] FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY] where PRODUCTION='HRC' order by [DATETIME] desc"
                Dim dtLB As DataTable = New DataTable()
                dtLB = getdatatable(sqlQueryCum)
                For Each row As DataRow In dtLB.Rows
                    lblSpecific.Text = row("CUM_SPEC_FUEL_CON")
                Next row

            Catch ex As Exception
                ' Throw ex
            End Try
            'Catch ex As Exception

            'End Try






            'If VAL_SPEC = 0 Then
            '        SPECTOTAL = 0
            '    Else
            '        SPECTOTAL = FormatNumber(VAL_SPEC, 4)
            '    End If
            'Catch ex As Exception

            'End Try

            '===========================================================
            Dim dtspecificdataset As DataSet = objdatahandler.GetDataSetFromQuery("SELECT cast(AVG(SPC_FUEL_CON_ONLINE) As Decimal(10,3)) As SPC_FUEL_CON_ONLINE FROM [TSCR_FURNACE_OPT_FINAL]  where  DATEPART(m, datetime) = DATEPART(m, DATEADD(m, 0, getdate()))  GROUP BY DATENAME(MONTH,DATETIME) order by DATENAME(MONTH,DATETIME) asc")
            Dim dtspecificdatasetB As DataSet = objdatahandler.GetDataSetFromQuery("SELECT cast(AVG(SPC_FUEL_CON_ONLINE) As Decimal(10,3)) As SPC_FUEL_CON_ONLINE FROM [TSCR_FURNACE_OPT_FINAL]  where  DATEPART(m, datetime) = DATEPART(m, DATEADD(m, 0, getdate())) AND LINE ='B' GROUP BY DATENAME(MONTH,DATETIME) order by DATENAME(MONTH,DATETIME) asc")

            Dim dtspecificdatatable As DataTable = dtspecificdataset.Tables(0)
            Dim dtspecificdatatableB As DataTable = dtspecificdatasetB.Tables(0)
            Dim dtspecific As String = dtspecificdatatable.Rows(0)("SPC_FUEL_CON_ONLINE")
            Dim dtspecificB As String = dtspecificdatatableB.Rows(0)("SPC_FUEL_CON_ONLINE")

            '  Dim AVG_LineA_LineB As String = (dtspecific + dtspecificB) / 2
            ' lblSpecific.Text = dtspecific
            '  lblSpecific.Text = SPECTOTAL 'sum / count
            '========================LINEA======================================
            Try
                Dim dt As DataTable = objController.PopulateDataForHeatDistributionModel()
                Dim dtlabel As DataTable = objController.populatelabelValue()
                Dim dtlabelavg As DataTable = objController.populatelabelValueForAvg(frmDate, toDate)
                '===========lineb=====================
                Dim dtlineB As DataTable = objController.PopulateDataForHeatDistributionModelFORLINEB()
                Dim dtlabelLineB As DataTable = objController.populatelabelValueFORLINEB()
                '   Dim dtavglineb As DataTable = objController.PopulateAvgValuefromdtLineb(frmDate, toDate)
                Dim dtavglineb As DataTable = objController.populatelabelValueForAvgLineB(frmDate, toDate)
                If rdbtnLineA.Checked Then
                    If rbdTimeStamp.Checked Then
                        dtlabel = objController.populatelabelValue()
                    ElseIf rbdAVG.Checked Then
                        dtlabelavg = objController.populatelabelValueForAvg(frmDate, toDate)
                    End If
                End If
                If rdbtnLineB.Checked Then
                    If rbdTimeStamp.Checked Then
                        dtlabelLineB = objController.populatelabelValueFORLINEB()
                    ElseIf rbdAVG.Checked Then
                        dtavglineb = objController.populatelabelValueForAvgLineB(frmDate, toDate)
                    End If
                End If

                '=================================================================
                '====================Chart Radio Button Change=========================

                '==========================

                If rbdChartLineA.Checked Then
                    If rbdChartAvgValue.Checked Then
                        DrawChartForLINEA()
                    ElseIf rbdChartthisMonthValue.Checked Then
                        DrawChartForLINEA()
                    End If
                    '===========================
                ElseIf rbdChartLineB.Checked Then
                    ' DrawChartForLINEB()
                    If rbdChartAvgValue.Checked Then
                        DrawChartForLINEB()
                    ElseIf rbdChartthisMonthValue.Checked Then
                        DrawChartForLINEB()
                    End If

                    ' DrawChartForLINEA_LINEB()
                    '=====================================
                ElseIf rbdChartLineA_LineB.Checked Then
                    '  DrawChartForLINEA_LINEB()
                    If rbdChartAvgValue.Checked Then
                        ' DrawChartForLINEA()
                        DrawChartForLINEA_LINEB()
                    ElseIf rbdChartthisMonthValue.Checked Then
                        DrawChartForLINEA_LINEB()
                    End If
                    '====================================
                End If
                '=========================================






                If rdbtnLineA.Checked = True Then
                    Session("checkboxval") = "A"

                    ' DrawChartTop()

                    getdataForGrid_LineA()
                    lblforgrid_indicator.Text = "Table Grid Show LineA Values"
                    ' lblforgriddatavalue.Text = "Abnormal LineA Roll Colling Water Tempreture"
                    If dt.Rows.Count > 0 Then
                        'txtHeatRecover1.Text = dt.Rows(0)("HEAT_RECOV1")
                        btnHeatRecover1.Text = dt.Rows(0)("HEAT_RECOV1") & "%"
                        'btnHeatRecoverySanky1.Text = dt.Rows(0)("HEAT_RECOV1") & "%"
                        'txtHeatRecover2.Text = dt.Rows(0)("HEAT_RECOV2")
                        btnHeatRecover2.Text = dt.Rows(0)("HEAT_RECOV2") & "%"
                        ' btnHeatRecoverySanky2.Text = dt.Rows(0)("HEAT_RECOV2") & "%"
                        'txtHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3")
                        btnHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3") & "%"
                        ' btnHeatRecoverySanky3.Text = dt.Rows(0)("HEAT_RECOV3") & "%"
                        'txtRecup1.Text = dt.Rows(0)("RECUP1_PERFORM")
                        btnRecup1.Text = dt.Rows(0)("RECUP1_PERFORM") & "%"
                        'btnrecupSanky1.Text = dt.Rows(0)("RECUP1_PERFORM") & "%"
                        'txtRecup2.Text = dt.Rows(0)("RECUP2_PERFORM")
                        btnRecup2.Text = dt.Rows(0)("RECUP2_PERFORM") & "%"
                        'btnrecupSanky2.Text = dt.Rows(0)("RECUP2_PERFORM") & "%"
                        'txtRecup3.Text = dt.Rows(0)("RECUP3_PERFORM")
                        btnRecup3.Text = dt.Rows(0)("RECUP3_PERFORM") & "%"
                        'btnrecupSanky3.Text = dt.Rows(0)("RECUP3_PERFORM") & "%"
                        'txtHeatInput.Text = dt.Rows(0)("HEAT_INPUT")
                        btnHeatInput.Text = dt.Rows(0)("HEAT_INPUT") & ""
                        'btnHeatInputSanky.Text = dt.Rows(0)("HEAT_INPUT") & ""
                        'txtThroughPut.Text = dt.Rows(0)("THROUGHPUT")


                        btnThroughPut.Text = dt.Rows(0)("THROUGHPUT")
                        'btnThroughPutSanky.Text = dt.Rows(0)("THROUGHPUT")
                        'txtStockEntryTemp.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
                        btnStockEntryTemp.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
                        'btnStockEbtryTempSanky.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
                        'txtStockExitTemp.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
                        btnStockExitTemp.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
                        'btnStockExitTempSanky.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
                        'txtCoolingWaterLoss.Text = dt.Rows(0)("COOL_WT_LOSS")
                        btnCoolingWaterLoss.Text = dt.Rows(0)("COOL_WT_LOSS")
                        'btnCoolingWaterLossSanky.Text = dt.Rows(0)("COOL_WT_LOSS")
                        btnCoolingWaterLossPerc.Text = dt.Rows(0)("COOL_WT_LOSS_PERC") & "%"
                        'btnCoolingWaterLossPercSanky.Text = dt.Rows(0)("COOL_WT_LOSS_PERC") & "%"
                        'txtFuelLoss.Text = dt.Rows(0)("FLUE_LOSS_PERC")

                        btnFuelLossPerc.Text = dt.Rows(0)("FLUE_LOSS_PERC") & "%"
                        'btnFuelLossPrecSanky.Text = dt.Rows(0)("FLUE_LOSS_PERC") & "%"
                        'txtHeatMaterial.Text = dt.Rows(0)("HEAT_MATERIAL")
                        btnHeatMaterial.Text = dt.Rows(0)("HEAT_MATERIAL")
                        'btnHeatMaterialSanky.Text = dt.Rows(0)("HEAT_MATERIAL")

                        btnHeatMaterialPerc.Text = dt.Rows(0)("HEAT_MAT_PERC") & "%"
                        'btnHeatMaterialpercSanky.Text = dt.Rows(0)("HEAT_MAT_PERC") & "%"
                        'txtOpenLoss.Text = dt.Rows(0)("OPEN_LOSS")
                        btnOpenLoss.Text = dt.Rows(0)("OPEN_LOSS")
                        ' btnOpenLossSanky.Text = dt.Rows(0)("OPEN_LOSS")
                        btnOpenLossPerc.Text = dt.Rows(0)("OPEN_LOSS_PERC") & "%"
                        'btnOpenLossPRECSanky.Text = dt.Rows(0)("OPEN_LOSS_PERC") & "%"
                        'txtWallRoofLoss.Text = dt.Rows(0)("SKIN_LOSS_PERC")

                        btnWallRoofLossPerc.Text = dt.Rows(0)("SKIN_LOSS_PERC") & "%"
                        'btnWallRoofLossPrecSanky.Text = dt.Rows(0)("SKIN_LOSS_PERC") & "%"
                        'txtAirFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_CAL")
                        '  btnAirFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_ONLINE") '("TOTAL_AIR_FLOW_CAL")
                        btnAirFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_ONLINE") '("TOTAL_AIR_FLOW_CAL")

                        'btnAirFlowSanky.Text = dt.Rows(0)("TOTAL_GAS_FLOW_ONLINE") '("TOTAL_AIR_FLOW_CAL")
                        'txtGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_CAL")
                        ' btnGasFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_ONLINE") '("TOTAL_GAS_FLOW_CAL")
                        btnGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_ONLINE") '("TOTAL_GAS_FLOW_CAL")

                        'btnGasFlowSanky.Text = dt.Rows(0)("TOTAL_AIR_FLOW_ONLINE") '("TOTAL_GAS_FLOW_CAL")
                        'txtCV.Text = dt.Rows(0)("CV")
                        btnCV.Text = dt.Rows(0)("CV")
                        'btnCvSanky.Text = dt.Rows(0)("CV")


                    Else



                        'txtHeatRecover1.Text = dt.Rows(0)("HEAT_RECOV1")
                        btnHeatRecover1.Text = ""
                        'btnHeatRecoverySanky1.Text = ""
                        'txtHeatRecover2.Text = dt.Rows(0)("HEAT_RECOV2")
                        btnHeatRecover2.Text = ""
                        'btnHeatRecoverySanky2.Text = ""
                        'txtHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3")
                        btnHeatRecover3.Text = ""
                        'btnHeatRecoverySanky3.Text = ""
                        'txtRecup1.Text = dt.Rows(0)("RECUP1_PERFORM")
                        btnRecup1.Text = ""
                        'btnrecupSanky1.Text = ""
                        'txtRecup2.Text = dt.Rows(0)("RECUP2_PERFORM")
                        btnRecup2.Text = ""
                        'btnrecupSanky2.Text = ""
                        'txtRecup3.Text = dt.Rows(0)("RECUP3_PERFORM")
                        btnRecup3.Text = ""
                        'btnrecupSanky3.Text = ""
                        'txtHeatInput.Text = dt.Rows(0)("HEAT_INPUT")
                        btnHeatInput.Text = ""
                        'btnHeatInputSanky.Text = ""
                        'txtThroughPut.Text = dt.Rows(0)("THROUGHPUT")


                        btnThroughPut.Text = ""
                        'btnThroughPutSanky.Text = ""
                        'txtStockEntryTemp.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
                        btnStockEntryTemp.Text = ""
                        'btnStockEbtryTempSanky.Text = ""
                        'txtStockExitTemp.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
                        btnStockExitTemp.Text = ""
                        'btnStockExitTempSanky.Text = ""
                        'txtCoolingWaterLoss.Text = dt.Rows(0)("COOL_WT_LOSS")
                        btnCoolingWaterLoss.Text = ""
                        ' btnCoolingWaterLossSanky.Text = ""
                        btnCoolingWaterLossPerc.Text = ""
                        ' btnCoolingWaterLossPercSanky.Text = ""
                        'txtFuelLoss.Text = dt.Rows(0)("FLUE_LOSS_PERC")

                        btnFuelLossPerc.Text = ""
                        'btnFuelLossPrecSanky.Text = ""
                        'txtHeatMaterial.Text = dt.Rows(0)("HEAT_MATERIAL")
                        btnHeatMaterial.Text = ""
                        'btnHeatMaterialSanky.Text = ""
                        btnHeatMaterialPerc.Text = ""
                        'btnHeatMaterialpercSanky.Text = ""
                        'txtOpenLoss.Text = dt.Rows(0)("OPEN_LOSS")
                        btnOpenLoss.Text = ""
                        'btnOpenLossSanky.Text = ""
                        btnOpenLossPerc.Text = ""
                        'btnOpenLossPRECSanky.Text = ""
                        'txtWallRoofLoss.Text = dt.Rows(0)("SKIN_LOSS_PERC")

                        btnWallRoofLossPerc.Text = ""
                        'btnWallRoofLossPrecSanky.Text = ""
                        'txtAirFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_CAL")
                        btnAirFlow.Text = ""
                        'btnAirFlowSanky.Text = ""
                        'txtGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_CAL")
                        btnGasFlow.Text = ""
                        'btnGasFlowSanky.Text = ""
                        'txtCV.Text = dt.Rows(0)("CV")
                        btnCV.Text = ""
                        'btnCvSanky.Text = ""
                    End If


                    'Dim dtlabel As DataTable = objController.populatelabelValue()

                    If rbdTimeStamp.Checked Then

                        If dtlabel.Rows.Count > 0 Then

                            BaseValueOnline.Text = dtlabel.Rows(0)("TOTAL_AIR_FUEL_RATIO")
                            BaseValueRecommended.Text = dtlabel.Rows(0)("BASE_VALUE_RECOM")
                            '=================================================
                            '   HeatInputOnline.Text = dtlabel.Rows(0)("HEAT_INPUT")
                            HeatInputCalculated.Text = dtlabel.Rows(0)("HEAT_INPUT")
                            HeatInputRecommended.Text = dtlabel.Rows(0)("HEAT_INPUT_RECOM")
                            '====================================================
                            SpecificationOnline.Text = dtlabel.Rows(0)("SPC_FUEL_CON_ONLINE") '& AvgData

                            SpecificationCalculated.Text = dtlabel.Rows(0)("SPC_FUEL_CON_CAL")
                            SpecificationRecommended.Text = dtlabel.Rows(0)("SPEC_FUEL_CON_RECOM")
                            '====================================================
                            TotalGasFlowOnline.Text = dtlabel.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
                            TotalGasFlowCalculated.Text = dtlabel.Rows(0)("TOTAL_GAS_FLOW_CAL")
                            TotalGasFlowRecommended.Text = dtlabel.Rows(0)("TOTAL_GAS_FLOW_RECOM")
                            '========================================================
                            TotalAirFlowOnline.Text = dtlabel.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
                            TotalAirFlowCalculated.Text = dtlabel.Rows(0)("TOTAL_AIR_FLOW_CAL")
                            TotalAirFlowRecommended.Text = dtlabel.Rows(0)("TOTAL_AIR_FLOW_RECOM")
                        Else
                            BaseValueOnline.Text = ""
                            BaseValueRecommended.Text = ""
                            '=================================================
                            '   HeatInputOnline.Text = dtlabel.Rows(0)("HEAT_INPUT")
                            HeatInputCalculated.Text = ""
                            HeatInputRecommended.Text = ""
                            '====================================================
                            SpecificationOnline.Text = ""
                            SpecificationCalculated.Text = ""
                            SpecificationRecommended.Text = ""
                            '====================================================
                            TotalGasFlowOnline.Text = ""
                            TotalGasFlowCalculated.Text = ""
                            TotalGasFlowRecommended.Text = ""
                            '========================================================
                            TotalAirFlowOnline.Text = ""
                            TotalAirFlowCalculated.Text = ""
                            TotalAirFlowRecommended.Text = ""
                        End If
                    End If


                    If rbdAVG.Checked Then
                        '  dtlabelavg = objController.populatelabelValueForAvg(frmDate, toDate)
                        If dtlabelavg.Rows.Count > 0 Then

                            BaseValueOnline.Text = dtlabelavg.Rows(0)("TOTAL_AIR_FUEL_RATIO")
                            BaseValueRecommended.Text = dtlabelavg.Rows(0)("BASE_VALUE_RECOM")
                            '=================================================
                            '   HeatInputOnline.Text = dtlabelavg.Rows(0)("HEAT_INPUT")
                            HeatInputCalculated.Text = dtlabelavg.Rows(0)("HEAT_INPUT")
                            HeatInputRecommended.Text = dtlabelavg.Rows(0)("HEAT_INPUT_RECOM")
                            '====================================================
                            SpecificationOnline.Text = dtlabelavg.Rows(0)("SPC_FUEL_CON_ONLINE") '& AvgData

                            SpecificationCalculated.Text = dtlabelavg.Rows(0)("SPC_FUEL_CON_CAL")
                            SpecificationRecommended.Text = dtlabelavg.Rows(0)("SPEC_FUEL_CON_RECOM")
                            '====================================================
                            TotalGasFlowOnline.Text = dtlabelavg.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
                            TotalGasFlowCalculated.Text = dtlabelavg.Rows(0)("TOTAL_GAS_FLOW_CAL")
                            TotalGasFlowRecommended.Text = dtlabelavg.Rows(0)("TOTAL_GAS_FLOW_RECOM")
                            '========================================================
                            TotalAirFlowOnline.Text = dtlabelavg.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
                            TotalAirFlowCalculated.Text = dtlabelavg.Rows(0)("TOTAL_AIR_FLOW_CAL")
                            TotalAirFlowRecommended.Text = dtlabelavg.Rows(0)("TOTAL_AIR_FLOW_RECOM")
                        Else
                            BaseValueOnline.Text = ""
                            BaseValueRecommended.Text = ""
                            '=================================================
                            '   HeatInputOnline.Text = dtlabel.Rows(0)("HEAT_INPUT")
                            HeatInputCalculated.Text = ""
                            HeatInputRecommended.Text = ""
                            '====================================================
                            SpecificationOnline.Text = ""
                            SpecificationCalculated.Text = ""
                            SpecificationRecommended.Text = ""
                            '====================================================
                            TotalGasFlowOnline.Text = ""
                            TotalGasFlowCalculated.Text = ""
                            TotalGasFlowRecommended.Text = ""
                            '========================================================
                            TotalAirFlowOnline.Text = ""
                            TotalAirFlowCalculated.Text = ""
                            TotalAirFlowRecommended.Text = ""
                        End If


                    End If



                End If
                If rdbtnLineB.Checked = True Then


                    Session("checkboxval") = "B"
                    getdataForGrid_LineB()
                    '   DrawChartTop()
                    lblforgrid_indicator.Text = "Table Grid Show LineB Values"
                    ' lblforgriddatavalue.Text = "Abnormal LineB Roll Colling Water Tempreture"
                    If dtlineB.Rows.Count > 0 Then
                        'txtHeatRecover1.Text = dtlineB.Rows(0)("HEAT_RECOV1")
                        btnHeatRecover1.Text = dtlineB.Rows(0)("HEAT_RECOV1") & "%"
                        'btnHeatRecoverySanky1.Text = dtlineB.Rows(0)("HEAT_RECOV1") & "%"
                        'txtHeatRecover2.Text = dtlineB.Rows(0)("HEAT_RECOV2")
                        btnHeatRecover2.Text = dtlineB.Rows(0)("HEAT_RECOV2") & "%"
                        'btnHeatRecoverySanky2.Text = dtlineB.Rows(0)("HEAT_RECOV2") & "%"
                        'txtHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3")
                        btnHeatRecover3.Text = dtlineB.Rows(0)("HEAT_RECOV3") & "%"
                        'btnHeatRecoverySanky3.Text = dtlineB.Rows(0)("HEAT_RECOV3") & "%"
                        'txtRecup1.Text = dtlineB.Rows(0)("RECUP1_PERFORM")
                        btnRecup1.Text = dtlineB.Rows(0)("RECUP1_PERFORM") & "%"
                        'btnrecupSanky1.Text = dtlineB.Rows(0)("RECUP1_PERFORM") & "%"
                        'txtRecup2.Text = dtlineB.Rows(0)("RECUP2_PERFORM")
                        btnRecup2.Text = dtlineB.Rows(0)("RECUP2_PERFORM") & "%"
                        'btnrecupSanky2.Text = dtlineB.Rows(0)("RECUP2_PERFORM") & "%"
                        'txtRecup3.Text = dtlineB.Rows(0)("RECUP3_PERFORM")
                        btnRecup3.Text = dtlineB.Rows(0)("RECUP3_PERFORM") & "%"
                        'btnrecupSanky3.Text = dtlineB.Rows(0)("RECUP3_PERFORM") & "%"
                        'txtHeatInput.Text = dtlineB.Rows(0)("HEAT_INPUT")
                        btnHeatInput.Text = dtlineB.Rows(0)("HEAT_INPUT") & ""
                        'btnHeatInputSanky.Text = dtlineB.Rows(0)("HEAT_INPUT") & ""
                        'txtThroughPut.Text = dtlineB.Rows(0)("THROUGHPUT")


                        btnThroughPut.Text = dtlineB.Rows(0)("THROUGHPUT")
                        'btnThroughPutSanky.Text = dtlineB.Rows(0)("THROUGHPUT")
                        'txtStockEntryTemp.Text = dtlineB.Rows(0)("STOCK_ENTRY_TEMP")
                        btnStockEntryTemp.Text = dtlineB.Rows(0)("STOCK_ENTRY_TEMP")
                        ' btnStockEbtryTempSanky.Text = dtlineB.Rows(0)("STOCK_ENTRY_TEMP")
                        'txtStockExitTemp.Text = dtlineB.Rows(0)("STOCK_EXIT_TEMP")
                        btnStockExitTemp.Text = dtlineB.Rows(0)("STOCK_EXIT_TEMP")
                        'btnStockExitTempSanky.Text = dtlineB.Rows(0)("STOCK_EXIT_TEMP")
                        'txtCoolingWaterLoss.Text = dtlineB.Rows(0)("COOL_WT_LOSS")
                        btnCoolingWaterLoss.Text = dtlineB.Rows(0)("COOL_WT_LOSS")
                        'btnCoolingWaterLossSanky.Text = dtlineB.Rows(0)("COOL_WT_LOSS")
                        btnCoolingWaterLossPerc.Text = dtlineB.Rows(0)("COOL_WT_LOSS_PERC") & "%"
                        'btnCoolingWaterLossPercSanky.Text = dtlineB.Rows(0)("COOL_WT_LOSS_PERC") & "%"
                        'txtFuelLoss.Text = dtlineB.Rows(0)("FLUE_LOSS_PERC")

                        btnFuelLossPerc.Text = dtlineB.Rows(0)("FLUE_LOSS_PERC") & "%"
                        'btnFuelLossPrecSanky.Text = dtlineB.Rows(0)("FLUE_LOSS_PERC") & "%"
                        'txtHeatMaterial.Text = dtlineB.Rows(0)("HEAT_MATERIAL")
                        btnHeatMaterial.Text = dtlineB.Rows(0)("HEAT_MATERIAL")
                        'btnHeatMaterialSanky.Text = dtlineB.Rows(0)("HEAT_MATERIAL")
                        btnHeatMaterialPerc.Text = dtlineB.Rows(0)("HEAT_MAT_PERC") & "%"
                        'btnHeatMaterialpercSanky.Text = dtlineB.Rows(0)("HEAT_MAT_PERC") & "%"
                        'txtOpenLoss.Text = dtlineB.Rows(0)("OPEN_LOSS")
                        btnOpenLoss.Text = dtlineB.Rows(0)("OPEN_LOSS")
                        'btnOpenLossSanky.Text = dtlineB.Rows(0)("OPEN_LOSS")
                        btnOpenLossPerc.Text = dtlineB.Rows(0)("OPEN_LOSS_PERC") & "%"
                        'btnOpenLossPRECSanky.Text = dtlineB.Rows(0)("OPEN_LOSS_PERC") & "%"
                        'txtWallRoofLoss.Text = dtlineB.Rows(0)("SKIN_LOSS_PERC")

                        btnWallRoofLossPerc.Text = dtlineB.Rows(0)("SKIN_LOSS_PERC") & "%"
                        'btnWallRoofLossPrecSanky.Text = dtlineB.Rows(0)("SKIN_LOSS_PERC") & "%"
                        'txtAirFlow.Text = dtlineB.Rows(0)("TOTAL_AIR_FLOW_CAL")
                        '  btnAirFlow.Text = dtlineB.Rows(0)("TOTAL_GAS_FLOW_ONLINE") '("TOTAL_AIR_FLOW_CAL")
                        btnAirFlow.Text = dtlineB.Rows(0)("TOTAL_AIR_FLOW_ONLINE") '("TOTAL_AIR_FLOW_CAL")

                        'btnAirFlowSanky.Text = dtlineB.Rows(0)("TOTAL_GAS_FLOW_ONLINE") '("TOTAL_AIR_FLOW_CAL")
                        'txtGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_CAL")
                        btnGasFlow.Text = dtlineB.Rows(0)("TOTAL_GAS_FLOW_ONLINE") '("TOTAL_GAS_FLOW_CAL")
                        ' btnGasFlow.Text = dtlineB.Rows(0)("TOTAL_AIR_FLOW_ONLINE") '("TOTAL_GAS_FLOW_CAL")

                        'btnGasFlowSanky.Text = dtlineB.Rows(0)("TOTAL_AIR_FLOW_ONLINE") '("TOTAL_GAS_FLOW_CAL")
                        'txtCV.Text = dtlineB.Rows(0)("CV")
                        btnCV.Text = dtlineB.Rows(0)("CV")
                        'btnCvSanky.Text = dtlineB.Rows(0)("CV")
                    Else


                        'txtHeatRecover1.Text = dt.Rows(0)("HEAT_RECOV1")
                        btnHeatRecover1.Text = ""
                        'btnHeatRecoverySanky1.Text = ""
                        'txtHeatRecover2.Text = dt.Rows(0)("HEAT_RECOV2")
                        btnHeatRecover2.Text = ""
                        'btnHeatRecoverySanky2.Text = ""
                        'txtHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3")
                        btnHeatRecover3.Text = ""
                        'btnHeatRecoverySanky3.Text = ""
                        'txtRecup1.Text = dt.Rows(0)("RECUP1_PERFORM")
                        btnRecup1.Text = ""
                        'btnrecupSanky1.Text = ""
                        'txtRecup2.Text = dt.Rows(0)("RECUP2_PERFORM")
                        btnRecup2.Text = ""
                        'btnrecupSanky2.Text = ""
                        'txtRecup3.Text = dt.Rows(0)("RECUP3_PERFORM")
                        btnRecup3.Text = ""
                        'btnrecupSanky3.Text = ""
                        'txtHeatInput.Text = dt.Rows(0)("HEAT_INPUT")
                        btnHeatInput.Text = ""
                        'btnHeatInputSanky.Text = ""
                        'txtThroughPut.Text = dt.Rows(0)("THROUGHPUT")


                        btnThroughPut.Text = ""
                        'btnThroughPutSanky.Text = ""
                        'txtStockEntryTemp.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
                        btnStockEntryTemp.Text = ""
                        'btnStockEbtryTempSanky.Text = ""
                        'txtStockExitTemp.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
                        btnStockExitTemp.Text = ""
                        'btnStockExitTempSanky.Text = ""
                        'txtCoolingWaterLoss.Text = dt.Rows(0)("COOL_WT_LOSS")
                        btnCoolingWaterLoss.Text = ""
                        'btnCoolingWaterLossSanky.Text = ""
                        btnCoolingWaterLossPerc.Text = ""
                        'btnCoolingWaterLossPercSanky.Text = ""
                        'txtFuelLoss.Text = dt.Rows(0)("FLUE_LOSS_PERC")

                        btnFuelLossPerc.Text = ""
                        ' btnFuelLossPrecSanky.Text = ""
                        'txtHeatMaterial.Text = dt.Rows(0)("HEAT_MATERIAL")
                        btnHeatMaterial.Text = ""
                        'btnHeatMaterialSanky.Text = ""
                        btnHeatMaterialPerc.Text = ""
                        'btnHeatMaterialpercSanky.Text = ""
                        'txtOpenLoss.Text = dt.Rows(0)("OPEN_LOSS")
                        btnOpenLoss.Text = ""
                        'btnOpenLossSanky.Text = ""
                        btnOpenLossPerc.Text = ""
                        'btnOpenLossPRECSanky.Text = ""
                        'txtWallRoofLoss.Text = dt.Rows(0)("SKIN_LOSS_PERC")

                        btnWallRoofLossPerc.Text = ""
                        'btnWallRoofLossPrecSanky.Text = ""
                        'txtAirFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_CAL")
                        btnAirFlow.Text = ""
                        'btnAirFlowSanky.Text = ""
                        'txtGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_CAL")
                        btnGasFlow.Text = ""
                        'btnGasFlowSanky.Text = ""
                        'txtCV.Text = dt.Rows(0)("CV")
                        btnCV.Text = ""
                        'btnCvSanky.Text = ""
                    End If
                    'Dim dtlabel As DataTable = objController.populatelabelValue()

                    If rbdTimeStamp.Checked Then
                        If dtlabelLineB.Rows.Count > 0 Then


                            BaseValueOnline.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FUEL_RATIO")
                            BaseValueRecommended.Text = dtlabelLineB.Rows(0)("BASE_VALUE_RECOM")
                            '=================================================
                            '   HeatInputOnline.Text = dtlabelLineB.Rows(0)("HEAT_INPUT")
                            HeatInputCalculated.Text = dtlabelLineB.Rows(0)("HEAT_INPUT")
                            HeatInputRecommended.Text = dtlabelLineB.Rows(0)("HEAT_INPUT_RECOM")
                            '====================================================
                            SpecificationOnline.Text = dtlabelLineB.Rows(0)("SPC_FUEL_CON_ONLINE")
                            SpecificationCalculated.Text = dtlabelLineB.Rows(0)("SPC_FUEL_CON_CAL")
                            SpecificationRecommended.Text = dtlabelLineB.Rows(0)("SPEC_FUEL_CON_RECOM")
                            '====================================================
                            TotalGasFlowOnline.Text = dtlabelLineB.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
                            TotalGasFlowCalculated.Text = dtlabelLineB.Rows(0)("TOTAL_GAS_FLOW_CAL")
                            TotalGasFlowRecommended.Text = dtlabelLineB.Rows(0)("TOTAL_GAS_FLOW_RECOM")
                            '========================================================
                            TotalAirFlowOnline.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
                            TotalAirFlowCalculated.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FLOW_CAL")
                            TotalAirFlowRecommended.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FLOW_RECOM")

                        Else
                            BaseValueOnline.Text = ""
                            BaseValueRecommended.Text = ""
                            '=================================================
                            '   HeatInputOnline.Text = dtlabelLineB.Rows(0)("HEAT_INPUT")
                            HeatInputCalculated.Text = ""
                            HeatInputRecommended.Text = ""
                            '====================================================
                            SpecificationOnline.Text = ""
                            SpecificationCalculated.Text = ""
                            SpecificationRecommended.Text = ""
                            '====================================================
                            TotalGasFlowOnline.Text = ""
                            TotalGasFlowCalculated.Text = ""
                            TotalGasFlowRecommended.Text = ""
                            '========================================================
                            TotalAirFlowOnline.Text = ""
                            TotalAirFlowCalculated.Text = ""
                            TotalAirFlowRecommended.Text = ""

                        End If




                    End If
                    If rbdAVG.Checked Then
                        If dtavglineb.Rows.Count > 0 Then

                            BaseValueOnline.Text = dtavglineb.Rows(0)("TOTAL_AIR_FUEL_RATIO")
                            BaseValueRecommended.Text = dtavglineb.Rows(0)("BASE_VALUE_RECOM")
                            '=================================================
                            '   HeatInputOnline.Text = dtavglineb.Rows(0)("HEAT_INPUT")
                            HeatInputCalculated.Text = dtavglineb.Rows(0)("HEAT_INPUT")
                            HeatInputRecommended.Text = dtavglineb.Rows(0)("HEAT_INPUT_RECOM")
                            '====================================================
                            SpecificationOnline.Text = dtavglineb.Rows(0)("SPC_FUEL_CON_ONLINE") '& AvgData

                            SpecificationCalculated.Text = dtavglineb.Rows(0)("SPC_FUEL_CON_CAL")
                            SpecificationRecommended.Text = dtavglineb.Rows(0)("SPEC_FUEL_CON_RECOM")
                            '====================================================
                            TotalGasFlowOnline.Text = dtavglineb.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
                            TotalGasFlowCalculated.Text = dtavglineb.Rows(0)("TOTAL_GAS_FLOW_CAL")
                            TotalGasFlowRecommended.Text = dtavglineb.Rows(0)("TOTAL_GAS_FLOW_RECOM")
                            '========================================================
                            TotalAirFlowOnline.Text = dtavglineb.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
                            TotalAirFlowCalculated.Text = dtavglineb.Rows(0)("TOTAL_AIR_FLOW_CAL")
                            TotalAirFlowRecommended.Text = dtavglineb.Rows(0)("TOTAL_AIR_FLOW_RECOM")
                        Else
                            BaseValueOnline.Text = ""
                            BaseValueRecommended.Text = ""
                            '=================================================
                            '   HeatInputOnline.Text = dtlabel.Rows(0)("HEAT_INPUT")
                            HeatInputCalculated.Text = ""
                            HeatInputRecommended.Text = ""
                            '====================================================
                            SpecificationOnline.Text = ""
                            SpecificationCalculated.Text = ""
                            SpecificationRecommended.Text = ""
                            '====================================================
                            TotalGasFlowOnline.Text = ""
                            TotalGasFlowCalculated.Text = ""
                            TotalGasFlowRecommended.Text = ""
                            '========================================================
                            TotalAirFlowOnline.Text = ""
                            TotalAirFlowCalculated.Text = ""
                            TotalAirFlowRecommended.Text = ""
                        End If

                    End If
                End If

            Catch ex As Exception

            End Try
        End If

        If Session("ActiveIndex") = 1 Then
            MultiView1.ActiveViewIndex = 1
        End If

    End Sub

    Public Sub rdbtnLineA_CheckedChanged(sender As Object, e As EventArgs) Handles rdbtnLineA.CheckedChanged
        Try
            'Dim dSdate As DataSet = objdatahandler.GetDataSetFromQuery("select max(datetime) as DATETIME FROM  [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]")
            'Dim dtdate As DataTable = dSdate.Tables(0)
            Dim dSdate As DataTable = objController.PopulateMaxDatetime()


            Dim dtdate As DataTable = dSdate

            Dim ddtdate As DateTime = dtdate.Rows(0)("DATETIME")
            Dim frmDate As String = ddtdate.ToString("yyyy-MM-dd HH:mm:ss")
            Dim toDate As String = ddtdate.AddHours(-1).ToString("yyyy-MM-dd HH:mm:ss")
            '======================LINEA--------------------------------------
            Dim dt As DataTable = objController.PopulateDataForHeatDistributionModel()
            Dim dtlabel As DataTable = objController.populatelabelValue()
            Dim dtlabelavg As DataTable = objController.populatelabelValueForAvg(frmDate, toDate)
            '=======
            ' Dim dtavg As DataTable = objController.PopulateAvgValuefromdt(frmDate, toDate)

            Session("checkboxval") = "A"
            '  DrawChartTop()
            lblforgrid_indicator.Text = "Table Grid Show LineA Values"
            ' lblforgriddatavalue.Text = "Abnormal LineA Roll Colling Water Tempreture"
            getdataForGrid_LineA()
            If dt.Rows.Count > 0 Then
                'txtHeatRecover1.Text = dt.Rows(0)("HEAT_RECOV1")
                btnHeatRecover1.Text = dt.Rows(0)("HEAT_RECOV1") & "%"
                ' btnHeatRecoverySanky1.Text = dt.Rows(0)("HEAT_RECOV1") & "%"
                'txtHeatRecover2.Text = dt.Rows(0)("HEAT_RECOV2")
                btnHeatRecover2.Text = dt.Rows(0)("HEAT_RECOV2") & "%"
                'btnHeatRecoverySanky2.Text = dt.Rows(0)("HEAT_RECOV2") & "%"
                'txtHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3")
                btnHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3") & "%"
                'btnHeatRecoverySanky3.Text = dt.Rows(0)("HEAT_RECOV3") & "%"
                'txtRecup1.Text = dt.Rows(0)("RECUP1_PERFORM")
                btnRecup1.Text = dt.Rows(0)("RECUP1_PERFORM") & "%"
                'btnrecupSanky1.Text = dt.Rows(0)("RECUP1_PERFORM") & "%"
                'txtRecup2.Text = dt.Rows(0)("RECUP2_PERFORM")
                btnRecup2.Text = dt.Rows(0)("RECUP2_PERFORM") & "%"
                'btnrecupSanky2.Text = dt.Rows(0)("RECUP2_PERFORM") & "%"
                'txtRecup3.Text = dt.Rows(0)("RECUP3_PERFORM")
                btnRecup3.Text = dt.Rows(0)("RECUP3_PERFORM") & "%"
                ' btnrecupSanky3.Text = dt.Rows(0)("RECUP3_PERFORM") & "%"
                'txtHeatInput.Text = dt.Rows(0)("HEAT_INPUT")
                btnHeatInput.Text = dt.Rows(0)("HEAT_INPUT") & ""
                'btnHeatInputSanky.Text = dt.Rows(0)("HEAT_INPUT") & ""
                'txtThroughPut.Text = dt.Rows(0)("THROUGHPUT")


                btnThroughPut.Text = dt.Rows(0)("THROUGHPUT")
                'btnThroughPutSanky.Text = dt.Rows(0)("THROUGHPUT")
                'txtStockEntryTemp.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
                btnStockEntryTemp.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
                'btnStockEbtryTempSanky.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
                'txtStockExitTemp.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
                btnStockExitTemp.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
                'btnStockExitTempSanky.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
                'txtCoolingWaterLoss.Text = dt.Rows(0)("COOL_WT_LOSS")
                btnCoolingWaterLoss.Text = dt.Rows(0)("COOL_WT_LOSS")
                ' btnCoolingWaterLossSanky.Text = dt.Rows(0)("COOL_WT_LOSS")
                btnCoolingWaterLossPerc.Text = dt.Rows(0)("COOL_WT_LOSS_PERC") & "%"
                'btnCoolingWaterLossPercSanky.Text = dt.Rows(0)("COOL_WT_LOSS_PERC") & "%"
                'txtFuelLoss.Text = dt.Rows(0)("FLUE_LOSS_PERC")

                btnFuelLossPerc.Text = dt.Rows(0)("FLUE_LOSS_PERC") & "%"
                ' btnFuelLossPrecSanky.Text = dt.Rows(0)("FLUE_LOSS_PERC") & "%"
                'txtHeatMaterial.Text = dt.Rows(0)("HEAT_MATERIAL")
                btnHeatMaterial.Text = dt.Rows(0)("HEAT_MATERIAL")
                'btnHeatMaterialSanky.Text = dt.Rows(0)("HEAT_MATERIAL")

                btnHeatMaterialPerc.Text = dt.Rows(0)("HEAT_MAT_PERC") & "%"
                'btnHeatMaterialpercSanky.Text = dt.Rows(0)("HEAT_MAT_PERC") & "%"
                'txtOpenLoss.Text = dt.Rows(0)("OPEN_LOSS")
                btnOpenLoss.Text = dt.Rows(0)("OPEN_LOSS")
                'btnOpenLossSanky.Text = dt.Rows(0)("OPEN_LOSS")
                btnOpenLossPerc.Text = dt.Rows(0)("OPEN_LOSS_PERC") & "%"
                ' btnOpenLossPRECSanky.Text = dt.Rows(0)("OPEN_LOSS_PERC") & "%"
                'txtWallRoofLoss.Text = dt.Rows(0)("SKIN_LOSS_PERC")

                btnWallRoofLossPerc.Text = dt.Rows(0)("SKIN_LOSS_PERC") & "%"
                'btnWallRoofLossPrecSanky.Text = dt.Rows(0)("SKIN_LOSS_PERC") & "%"
                'txtAirFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_CAL")
                ' btnAirFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_ONLINE") '("TOTAL_AIR_FLOW_CAL")
                btnAirFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_ONLINE") '("TOTAL_AIR_FLOW_CAL")

                'btnAirFlowSanky.Text = dt.Rows(0)("TOTAL_GAS_FLOW_ONLINE") '("TOTAL_AIR_FLOW_CAL")
                'txtGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_CAL")
                ' btnGasFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_ONLINE") '("TOTAL_GAS_FLOW_CAL")
                btnGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_ONLINE") '("TOTAL_GAS_FLOW_CAL")

                'btnGasFlowSanky.Text = dt.Rows(0)("TOTAL_AIR_FLOW_ONLINE") '("TOTAL_GAS_FLOW_CAL")
                'txtCV.Text = dt.Rows(0)("CV")
                btnCV.Text = dt.Rows(0)("CV")
                ' btnCvSanky.Text = dt.Rows(0)("CV")


            Else



                'txtHeatRecover1.Text = dt.Rows(0)("HEAT_RECOV1")
                btnHeatRecover1.Text = ""
                'btnHeatRecoverySanky1.Text = ""
                'txtHeatRecover2.Text = dt.Rows(0)("HEAT_RECOV2")
                btnHeatRecover2.Text = ""
                'btnHeatRecoverySanky2.Text = ""
                'txtHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3")
                btnHeatRecover3.Text = ""
                'btnHeatRecoverySanky3.Text = ""
                'txtRecup1.Text = dt.Rows(0)("RECUP1_PERFORM")
                btnRecup1.Text = ""
                'btnrecupSanky1.Text = ""
                'txtRecup2.Text = dt.Rows(0)("RECUP2_PERFORM")
                btnRecup2.Text = ""
                ' btnrecupSanky2.Text = ""
                'txtRecup3.Text = dt.Rows(0)("RECUP3_PERFORM")
                btnRecup3.Text = ""
                'btnrecupSanky3.Text = ""
                'txtHeatInput.Text = dt.Rows(0)("HEAT_INPUT")
                btnHeatInput.Text = ""
                'btnHeatInputSanky.Text = ""
                'txtThroughPut.Text = dt.Rows(0)("THROUGHPUT")


                btnThroughPut.Text = ""
                'btnThroughPutSanky.Text = ""
                'txtStockEntryTemp.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
                btnStockEntryTemp.Text = ""
                'btnStockEbtryTempSanky.Text = ""
                'txtStockExitTemp.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
                btnStockExitTemp.Text = ""
                'btnStockExitTempSanky.Text = ""
                'txtCoolingWaterLoss.Text = dt.Rows(0)("COOL_WT_LOSS")
                btnCoolingWaterLoss.Text = ""
                ' btnCoolingWaterLossSanky.Text = ""
                btnCoolingWaterLossPerc.Text = ""
                ' btnCoolingWaterLossPercSanky.Text = ""
                'txtFuelLoss.Text = dt.Rows(0)("FLUE_LOSS_PERC")

                btnFuelLossPerc.Text = ""
                'btnFuelLossPrecSanky.Text = ""
                'txtHeatMaterial.Text = dt.Rows(0)("HEAT_MATERIAL")
                btnHeatMaterial.Text = ""
                'btnHeatMaterialSanky.Text = ""
                btnHeatMaterialPerc.Text = ""
                'btnHeatMaterialpercSanky.Text = ""
                'txtOpenLoss.Text = dt.Rows(0)("OPEN_LOSS")
                btnOpenLoss.Text = ""
                'btnOpenLossSanky.Text = ""
                btnOpenLossPerc.Text = ""
                'btnOpenLossPRECSanky.Text = ""
                'txtWallRoofLoss.Text = dt.Rows(0)("SKIN_LOSS_PERC")

                btnWallRoofLossPerc.Text = ""
                'btnWallRoofLossPrecSanky.Text = ""
                'txtAirFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_CAL")
                btnAirFlow.Text = ""
                'btnAirFlowSanky.Text = ""
                'txtGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_CAL")
                btnGasFlow.Text = ""
                'btnGasFlowSanky.Text = ""
                'txtCV.Text = dt.Rows(0)("CV")
                btnCV.Text = ""
                'btnCvSanky.Text = ""

            End If

            'Dim dtlabel As DataTable = objController.populatelabelValue()

            '=============================================================
            If rbdTimeStamp.Checked Then

                If dtlabel.Rows.Count > 0 Then

                    BaseValueOnline.Text = dtlabel.Rows(0)("TOTAL_AIR_FUEL_RATIO")
                    BaseValueRecommended.Text = dtlabel.Rows(0)("BASE_VALUE_RECOM")
                    '=================================================
                    '   HeatInputOnline.Text = dtlabel.Rows(0)("HEAT_INPUT")
                    HeatInputCalculated.Text = dtlabel.Rows(0)("HEAT_INPUT")
                    HeatInputRecommended.Text = dtlabel.Rows(0)("HEAT_INPUT_RECOM")
                    '====================================================
                    SpecificationOnline.Text = dtlabel.Rows(0)("SPC_FUEL_CON_ONLINE") '& AvgData

                    SpecificationCalculated.Text = dtlabel.Rows(0)("SPC_FUEL_CON_CAL")
                    SpecificationRecommended.Text = dtlabel.Rows(0)("SPEC_FUEL_CON_RECOM")
                    '====================================================
                    TotalGasFlowOnline.Text = dtlabel.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
                    TotalGasFlowCalculated.Text = dtlabel.Rows(0)("TOTAL_GAS_FLOW_CAL")
                    TotalGasFlowRecommended.Text = dtlabel.Rows(0)("TOTAL_GAS_FLOW_RECOM")
                    '========================================================
                    TotalAirFlowOnline.Text = dtlabel.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
                    TotalAirFlowCalculated.Text = dtlabel.Rows(0)("TOTAL_AIR_FLOW_CAL")
                    TotalAirFlowRecommended.Text = dtlabel.Rows(0)("TOTAL_AIR_FLOW_RECOM")
                Else
                    BaseValueOnline.Text = ""
                    BaseValueRecommended.Text = ""
                    '=================================================
                    '   HeatInputOnline.Text = dtlabel.Rows(0)("HEAT_INPUT")
                    HeatInputCalculated.Text = ""
                    HeatInputRecommended.Text = ""
                    '====================================================
                    SpecificationOnline.Text = ""
                    SpecificationCalculated.Text = ""
                    SpecificationRecommended.Text = ""
                    '====================================================
                    TotalGasFlowOnline.Text = ""
                    TotalGasFlowCalculated.Text = ""
                    TotalGasFlowRecommended.Text = ""
                    '========================================================
                    TotalAirFlowOnline.Text = ""
                    TotalAirFlowCalculated.Text = ""
                    TotalAirFlowRecommended.Text = ""
                End If



                If rbdAVG.Checked Then
                    '  dtlabelavg = objController.populatelabelValueForAvg(frmDate, toDate)
                    If dtlabelavg.Rows.Count > 0 Then

                        BaseValueOnline.Text = dtlabelavg.Rows(0)("TOTAL_AIR_FUEL_RATIO")
                        BaseValueRecommended.Text = dtlabelavg.Rows(0)("BASE_VALUE_RECOM")
                        '=================================================
                        '   HeatInputOnline.Text = dtlabelavg.Rows(0)("HEAT_INPUT")
                        HeatInputCalculated.Text = dtlabelavg.Rows(0)("HEAT_INPUT")
                        HeatInputRecommended.Text = dtlabelavg.Rows(0)("HEAT_INPUT_RECOM")
                        '====================================================
                        SpecificationOnline.Text = dtlabelavg.Rows(0)("SPC_FUEL_CON_ONLINE") '& AvgData

                        SpecificationCalculated.Text = dtlabelavg.Rows(0)("SPC_FUEL_CON_CAL")
                        SpecificationRecommended.Text = dtlabelavg.Rows(0)("SPEC_FUEL_CON_RECOM")
                        '====================================================
                        TotalGasFlowOnline.Text = dtlabelavg.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
                        TotalGasFlowCalculated.Text = dtlabelavg.Rows(0)("TOTAL_GAS_FLOW_CAL")
                        TotalGasFlowRecommended.Text = dtlabelavg.Rows(0)("TOTAL_GAS_FLOW_RECOM")
                        '========================================================
                        TotalAirFlowOnline.Text = dtlabelavg.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
                        TotalAirFlowCalculated.Text = dtlabelavg.Rows(0)("TOTAL_AIR_FLOW_CAL")
                        TotalAirFlowRecommended.Text = dtlabelavg.Rows(0)("TOTAL_AIR_FLOW_RECOM")
                    Else
                        BaseValueOnline.Text = ""
                        BaseValueRecommended.Text = ""
                        '=================================================
                        '   HeatInputOnline.Text = dtlabel.Rows(0)("HEAT_INPUT")
                        HeatInputCalculated.Text = ""
                        HeatInputRecommended.Text = ""
                        '====================================================
                        SpecificationOnline.Text = ""
                        SpecificationCalculated.Text = ""
                        SpecificationRecommended.Text = ""
                        '====================================================
                        TotalGasFlowOnline.Text = ""
                        TotalGasFlowCalculated.Text = ""
                        TotalGasFlowRecommended.Text = ""
                        '========================================================
                        TotalAirFlowOnline.Text = ""
                        TotalAirFlowCalculated.Text = ""
                        TotalAirFlowRecommended.Text = ""
                    End If


                End If
            End If




        Catch ex As Exception

        End Try
    End Sub

    Protected Sub rdbtnLineB_CheckedChanged(sender As Object, e As EventArgs) Handles rdbtnLineB.CheckedChanged
        Try
            'Dim dSdate As DataSet = objdatahandler.GetDataSetFromQuery("select max(datetime) as DATETIME FROM  [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]")
            'Dim dtdate As DataTable = dSdate.Tables(0)
            Dim dSdate As DataTable = objController.PopulateMaxDatetime()

            'Dim dSdate As DataSet = objdatahandler.GetDataSetFromQuery("select max(datetime) as DATETIME FROM  [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]")

            '  Dim dtdate As DataTable = dSdate.Tables(0)
            Dim dtdate As DataTable = dSdate

            Dim ddtdate As DateTime = dtdate.Rows(0)("DATETIME")
            Dim frmDate As String = ddtdate.ToString("yyyy-MM-dd HH:mm:ss")
            Dim toDate As String = ddtdate.AddHours(-1).ToString("yyyy-MM-dd HH:mm:ss")


            '===========lineb=====================
            Dim dtlineB As DataTable = objController.PopulateDataForHeatDistributionModelFORLINEB()
            Dim dtlabelLineB As DataTable = objController.populatelabelValueFORLINEB()
            ' Dim dtavg As DataTable = objController.PopulateAvgValuefromdt(frmDate, toDate)
            ' Dim dtavglineb As DataTable = objController.PopulateAvgValuefromdtLineb(frmDate, toDate)
            Dim dtavglineb As DataTable = objController.populatelabelValueForAvgLineB(frmDate, toDate)


            If rdbtnLineB.Checked = True Then
                Session("checkboxval") = "B"
                ' DrawChartTop()
                getdataForGrid_LineB()
                lblforgrid_indicator.Text = "Table Grid Show LineB Values"
                ' lblforgriddatavalue.Text = "Abnormal LineB Roll Colling Water Tempreture"
                If dtlineB.Rows.Count > 0 Then
                    'txtHeatRecover1.Text = dtlineB.Rows(0)("HEAT_RECOV1")
                    btnHeatRecover1.Text = dtlineB.Rows(0)("HEAT_RECOV1") & "%"
                    'btnHeatRecoverySanky1.Text = dtlineB.Rows(0)("HEAT_RECOV1") & "%"
                    'txtHeatRecover2.Text = dtlineB.Rows(0)("HEAT_RECOV2")
                    btnHeatRecover2.Text = dtlineB.Rows(0)("HEAT_RECOV2") & "%"
                    'btnHeatRecoverySanky2.Text = dtlineB.Rows(0)("HEAT_RECOV2") & "%"
                    'txtHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3")
                    btnHeatRecover3.Text = dtlineB.Rows(0)("HEAT_RECOV3") & "%"
                    'btnHeatRecoverySanky3.Text = dtlineB.Rows(0)("HEAT_RECOV3") & "%"
                    'txtRecup1.Text = dtlineB.Rows(0)("RECUP1_PERFORM")
                    btnRecup1.Text = dtlineB.Rows(0)("RECUP1_PERFORM") & "%"
                    'btnrecupSanky1.Text = dtlineB.Rows(0)("RECUP1_PERFORM") & "%"
                    'txtRecup2.Text = dtlineB.Rows(0)("RECUP2_PERFORM")
                    btnRecup2.Text = dtlineB.Rows(0)("RECUP2_PERFORM") & "%"
                    'btnrecupSanky2.Text = dtlineB.Rows(0)("RECUP2_PERFORM") & "%"
                    'txtRecup3.Text = dtlineB.Rows(0)("RECUP3_PERFORM")
                    btnRecup3.Text = dtlineB.Rows(0)("RECUP3_PERFORM") & "%"
                    'btnrecupSanky3.Text = dtlineB.Rows(0)("RECUP3_PERFORM") & "%"
                    'txtHeatInput.Text = dtlineB.Rows(0)("HEAT_INPUT")
                    btnHeatInput.Text = dtlineB.Rows(0)("HEAT_INPUT") & ""
                    'btnHeatInputSanky.Text = dtlineB.Rows(0)("HEAT_INPUT") & ""
                    'txtThroughPut.Text = dtlineB.Rows(0)("THROUGHPUT")


                    btnThroughPut.Text = dtlineB.Rows(0)("THROUGHPUT")
                    'btnThroughPutSanky.Text = dtlineB.Rows(0)("THROUGHPUT")
                    'txtStockEntryTemp.Text = dtlineB.Rows(0)("STOCK_ENTRY_TEMP")
                    btnStockEntryTemp.Text = dtlineB.Rows(0)("STOCK_ENTRY_TEMP")
                    'btnStockEbtryTempSanky.Text = dtlineB.Rows(0)("STOCK_ENTRY_TEMP")
                    'txtStockExitTemp.Text = dtlineB.Rows(0)("STOCK_EXIT_TEMP")
                    btnStockExitTemp.Text = dtlineB.Rows(0)("STOCK_EXIT_TEMP")
                    'btnStockExitTempSanky.Text = dtlineB.Rows(0)("STOCK_EXIT_TEMP")
                    'txtCoolingWaterLoss.Text = dtlineB.Rows(0)("COOL_WT_LOSS")
                    btnCoolingWaterLoss.Text = dtlineB.Rows(0)("COOL_WT_LOSS")
                    'btnCoolingWaterLossSanky.Text = dtlineB.Rows(0)("COOL_WT_LOSS")
                    btnCoolingWaterLossPerc.Text = dtlineB.Rows(0)("COOL_WT_LOSS_PERC") & "%"
                    'btnCoolingWaterLossPercSanky.Text = dtlineB.Rows(0)("COOL_WT_LOSS_PERC") & "%"
                    'txtFuelLoss.Text = dtlineB.Rows(0)("FLUE_LOSS_PERC")

                    btnFuelLossPerc.Text = dtlineB.Rows(0)("FLUE_LOSS_PERC") & "%"
                    'btnFuelLossPrecSanky.Text = dtlineB.Rows(0)("FLUE_LOSS_PERC") & "%"
                    'txtHeatMaterial.Text = dtlineB.Rows(0)("HEAT_MATERIAL")
                    btnHeatMaterial.Text = dtlineB.Rows(0)("HEAT_MATERIAL")
                    'btnHeatMaterialSanky.Text = dtlineB.Rows(0)("HEAT_MATERIAL")
                    btnHeatMaterialPerc.Text = dtlineB.Rows(0)("HEAT_MAT_PERC") & "%"
                    'btnHeatMaterialpercSanky.Text = dtlineB.Rows(0)("HEAT_MAT_PERC") & "%"
                    'txtOpenLoss.Text = dtlineB.Rows(0)("OPEN_LOSS")
                    btnOpenLoss.Text = dtlineB.Rows(0)("OPEN_LOSS")
                    'btnOpenLossSanky.Text = dtlineB.Rows(0)("OPEN_LOSS")
                    btnOpenLossPerc.Text = dtlineB.Rows(0)("OPEN_LOSS_PERC") & "%"
                    'btnOpenLossPRECSanky.Text = dtlineB.Rows(0)("OPEN_LOSS_PERC") & "%"
                    'txtWallRoofLoss.Text = dtlineB.Rows(0)("SKIN_LOSS_PERC")

                    btnWallRoofLossPerc.Text = dtlineB.Rows(0)("SKIN_LOSS_PERC") & "%"
                    'btnWallRoofLossPrecSanky.Text = dtlineB.Rows(0)("SKIN_LOSS_PERC") & "%"
                    'txtAirFlow.Text = dtlineB.Rows(0)("TOTAL_AIR_FLOW_CAL")
                    btnAirFlow.Text = dtlineB.Rows(0)("TOTAL_AIR_FLOW_ONLINE") '("TOTAL_AIR_FLOW_CAL") TOTAL_GAS_FLOW_ONLINE
                    'btnAirFlowSanky.Text = dtlineB.Rows(0)("TOTAL_GAS_FLOW_ONLINE") '("TOTAL_AIR_FLOW_CAL")
                    'txtGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_CAL")
                    btnGasFlow.Text = dtlineB.Rows(0)("TOTAL_GAS_FLOW_ONLINE") '("TOTAL_GAS_FLOW_CAL") TOTAL_AIR_FLOW_ONLINE
                    'btnGasFlowSanky.Text = dtlineB.Rows(0)("TOTAL_AIR_FLOW_ONLINE") '("TOTAL_GAS_FLOW_CAL")
                    'txtCV.Text = dtlineB.Rows(0)("CV")
                    btnCV.Text = dtlineB.Rows(0)("CV")
                    'btnCvSanky.Text = dtlineB.Rows(0)("CV")
                Else

                    'txtHeatRecover1.Text = dt.Rows(0)("HEAT_RECOV1")
                    btnHeatRecover1.Text = ""
                    'btnHeatRecoverySanky1.Text = ""
                    'txtHeatRecover2.Text = dt.Rows(0)("HEAT_RECOV2")
                    btnHeatRecover2.Text = ""
                    'btnHeatRecoverySanky2.Text = ""
                    'txtHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3")
                    btnHeatRecover3.Text = ""
                    'btnHeatRecoverySanky3.Text = ""
                    'txtRecup1.Text = dt.Rows(0)("RECUP1_PERFORM")
                    btnRecup1.Text = ""
                    'btnrecupSanky1.Text = ""
                    'txtRecup2.Text = dt.Rows(0)("RECUP2_PERFORM")
                    btnRecup2.Text = ""
                    'btnrecupSanky2.Text = ""
                    'txtRecup3.Text = dt.Rows(0)("RECUP3_PERFORM")
                    btnRecup3.Text = ""
                    'btnrecupSanky3.Text = ""
                    'txtHeatInput.Text = dt.Rows(0)("HEAT_INPUT")
                    btnHeatInput.Text = ""
                    'btnHeatInputSanky.Text = ""
                    'txtThroughPut.Text = dt.Rows(0)("THROUGHPUT")


                    btnThroughPut.Text = ""
                    'btnThroughPutSanky.Text = ""
                    'txtStockEntryTemp.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
                    btnStockEntryTemp.Text = ""
                    'btnStockEbtryTempSanky.Text = ""
                    'txtStockExitTemp.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
                    btnStockExitTemp.Text = ""
                    'btnStockExitTempSanky.Text = ""
                    'txtCoolingWaterLoss.Text = dt.Rows(0)("COOL_WT_LOSS")
                    btnCoolingWaterLoss.Text = ""
                    'btnCoolingWaterLossSanky.Text = ""
                    btnCoolingWaterLossPerc.Text = ""
                    'btnCoolingWaterLossPercSanky.Text = ""
                    'txtFuelLoss.Text = dt.Rows(0)("FLUE_LOSS_PERC")

                    btnFuelLossPerc.Text = ""
                    'btnFuelLossPrecSanky.Text = ""
                    'txtHeatMaterial.Text = dt.Rows(0)("HEAT_MATERIAL")
                    btnHeatMaterial.Text = ""
                    'btnHeatMaterialSanky.Text = ""
                    btnHeatMaterialPerc.Text = ""
                    'btnHeatMaterialpercSanky.Text = ""
                    'txtOpenLoss.Text = dt.Rows(0)("OPEN_LOSS")
                    btnOpenLoss.Text = ""
                    'btnOpenLossSanky.Text = ""
                    btnOpenLossPerc.Text = ""
                    'btnOpenLossPRECSanky.Text = ""
                    'txtWallRoofLoss.Text = dt.Rows(0)("SKIN_LOSS_PERC")

                    btnWallRoofLossPerc.Text = ""
                    'btnWallRoofLossPrecSanky.Text = ""
                    'txtAirFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_CAL")
                    btnAirFlow.Text = ""
                    'btnAirFlowSanky.Text = ""
                    'txtGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_CAL")
                    btnGasFlow.Text = ""
                    'btnGasFlowSanky.Text = ""
                    'txtCV.Text = dt.Rows(0)("CV")
                    btnCV.Text = ""
                    'btnCvSanky.Text = ""

                End If



                'Dim dtlabel As DataTable = objController.populatelabelValue()

                If rbdTimeStamp.Checked Then
                    If dtlabelLineB.Rows.Count > 0 Then


                        BaseValueOnline.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FUEL_RATIO")
                        BaseValueRecommended.Text = dtlabelLineB.Rows(0)("BASE_VALUE_RECOM")
                        '=================================================
                        '   HeatInputOnline.Text = dtlabelLineB.Rows(0)("HEAT_INPUT")
                        HeatInputCalculated.Text = dtlabelLineB.Rows(0)("HEAT_INPUT")
                        HeatInputRecommended.Text = dtlabelLineB.Rows(0)("HEAT_INPUT_RECOM")
                        '====================================================
                        SpecificationOnline.Text = dtlabelLineB.Rows(0)("SPC_FUEL_CON_ONLINE")
                        SpecificationCalculated.Text = dtlabelLineB.Rows(0)("SPC_FUEL_CON_CAL")
                        SpecificationRecommended.Text = dtlabelLineB.Rows(0)("SPEC_FUEL_CON_RECOM")
                        '====================================================
                        TotalGasFlowOnline.Text = dtlabelLineB.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
                        TotalGasFlowCalculated.Text = dtlabelLineB.Rows(0)("TOTAL_GAS_FLOW_CAL")
                        TotalGasFlowRecommended.Text = dtlabelLineB.Rows(0)("TOTAL_GAS_FLOW_RECOM")
                        '========================================================
                        TotalAirFlowOnline.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
                        TotalAirFlowCalculated.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FLOW_CAL")
                        TotalAirFlowRecommended.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FLOW_RECOM")

                    Else
                        BaseValueOnline.Text = ""
                        BaseValueRecommended.Text = ""
                        '=================================================
                        '   HeatInputOnline.Text = dtlabelLineB.Rows(0)("HEAT_INPUT")
                        HeatInputCalculated.Text = ""
                        HeatInputRecommended.Text = ""
                        '====================================================
                        SpecificationOnline.Text = ""
                        SpecificationCalculated.Text = ""
                        SpecificationRecommended.Text = ""
                        '====================================================
                        TotalGasFlowOnline.Text = ""
                        TotalGasFlowCalculated.Text = ""
                        TotalGasFlowRecommended.Text = ""
                        '========================================================
                        TotalAirFlowOnline.Text = ""
                        TotalAirFlowCalculated.Text = ""
                        TotalAirFlowRecommended.Text = ""

                    End If




                End If
                If rbdAVG.Checked Then
                    If dtavglineb.Rows.Count > 0 Then

                        BaseValueOnline.Text = dtavglineb.Rows(0)("TOTAL_AIR_FUEL_RATIO")
                        BaseValueRecommended.Text = dtavglineb.Rows(0)("BASE_VALUE_RECOM")
                        '=================================================
                        '   HeatInputOnline.Text = dtavglineb.Rows(0)("HEAT_INPUT")
                        HeatInputCalculated.Text = dtavglineb.Rows(0)("HEAT_INPUT")
                        HeatInputRecommended.Text = dtavglineb.Rows(0)("HEAT_INPUT_RECOM")
                        '====================================================
                        SpecificationOnline.Text = dtavglineb.Rows(0)("SPC_FUEL_CON_ONLINE") '& AvgData

                        SpecificationCalculated.Text = dtavglineb.Rows(0)("SPC_FUEL_CON_CAL")
                        SpecificationRecommended.Text = dtavglineb.Rows(0)("SPEC_FUEL_CON_RECOM")
                        '====================================================
                        TotalGasFlowOnline.Text = dtavglineb.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
                        TotalGasFlowCalculated.Text = dtavglineb.Rows(0)("TOTAL_GAS_FLOW_CAL")
                        TotalGasFlowRecommended.Text = dtavglineb.Rows(0)("TOTAL_GAS_FLOW_RECOM")
                        '========================================================
                        TotalAirFlowOnline.Text = dtavglineb.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
                        TotalAirFlowCalculated.Text = dtavglineb.Rows(0)("TOTAL_AIR_FLOW_CAL")
                        TotalAirFlowRecommended.Text = dtavglineb.Rows(0)("TOTAL_AIR_FLOW_RECOM")
                    Else
                        BaseValueOnline.Text = ""
                        BaseValueRecommended.Text = ""
                        '=================================================
                        '   HeatInputOnline.Text = dtlabel.Rows(0)("HEAT_INPUT")
                        HeatInputCalculated.Text = ""
                        HeatInputRecommended.Text = ""
                        '====================================================
                        SpecificationOnline.Text = ""
                        SpecificationCalculated.Text = ""
                        SpecificationRecommended.Text = ""
                        '====================================================
                        TotalGasFlowOnline.Text = ""
                        TotalGasFlowCalculated.Text = ""
                        TotalGasFlowRecommended.Text = ""
                        '========================================================
                        TotalAirFlowOnline.Text = ""
                        TotalAirFlowCalculated.Text = ""
                        TotalAirFlowRecommended.Text = ""
                    End If

                End If

            End If




        Catch ex As Exception

        End Try
    End Sub





    'Public Shared Function SetAllValues(rbdTimeStamp As Boolean, rbdAVG As Boolean) As String

    <WebMethod>
    Public Shared Function SetAllValues(rdbtnLineA As Boolean, rdbtnLineB As Boolean) As String
        Dim dh As New DataHandler
        Dim oc As New Controller
        Dim dSdate As DataSet = dh.GetDataSetFromQuery("select max(datetime) as DATETIME FROM  [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]")
        Dim dtdate As DataTable = dSdate.Tables(0)

        Dim ddtdate As DateTime = CDate(dtdate.Rows(0)(0))
        Dim frmDate As String = ddtdate.ToString("yyyy-MM-dd HH:mm:ss")
        Dim toDate As String = ddtdate.AddHours(-1).ToString("yyyy-MM-dd HH:mm:ss")
        'LINEA
        Dim dt As DataTable = oc.PopulateDataForHeatDistributionModel()
        Dim dtlabel As DataTable = oc.populatelabelValue()
        Dim dtlabelavg As DataTable = oc.populatelabelValueForAvg(frmDate, toDate)
        'LINEB
        Dim dtlineB As DataTable = oc.PopulateDataForHeatDistributionModelFORLINEB()
        Dim dtlabelLineB As DataTable = oc.populatelabelValueFORLINEB()

        '  Dim dtavglineb As DataTable = oc.PopulateAvgValuefromdtLineb(frmDate, toDate)
        Dim dtavglineb As DataTable = oc.populatelabelValueForAvgLineB(frmDate, toDate)

        'If rbdTimeStamp Then
        '    dtlabel = oc.populatelabelValue()
        'ElseIf rbdAVG Then
        '    dtlabel = oc.populatelabelValueForAvg(frmDate, toDate)
        'End If

        If rdbtnLineA Then
            dt = oc.PopulateDataForHeatDistributionModel()
        ElseIf rdbtnLineB Then
            dt = oc.PopulateDataForHeatDistributionModelFORLINEB()
        End If


        '  Dim dtavg As DataTable = oc.PopulateAvgValuefromdt(frmDate, toDate)


        If dt.Rows.Count > 0 Then
            Dim ret As New StringBuilder
            'btnHeatRecover1.Text =
            ' lblMAXDATETIME.Text = frmDate
            ret.Append(dt.Rows(0)("HEAT_RECOV1") & "%,")
            'btnHeatRecoverySanky1.Text = 
            ret.Append(dt.Rows(0)("HEAT_RECOV2") & "%,")
            'btnHeatRecover2.Text = 
            ret.Append(dt.Rows(0)("HEAT_RECOV3") & "%,")
            'btnHeatRecoverySanky2.Text = 
            'ret.Append(dt.Rows(0)("HEAT_RECOV2") & "%,")
            ''btnHeatRecover3.Text = 
            'ret.Append(dt.Rows(0)("HEAT_RECOV3") & "%,")

            '============================================
            'ret.Append(dt.Rows(0)("HEAT_RECOV3") & "%,")
            ret.Append(dt.Rows(0)("RECUP1_PERFORM") & "%,")
            ret.Append(dt.Rows(0)("RECUP2_PERFORM") & "%,")
            ret.Append(dt.Rows(0)("RECUP3_PERFORM") & "%,")
            ret.Append(dt.Rows(0)("HEAT_INPUT") & ",")
            ret.Append(dt.Rows(0)("THROUGHPUT") & ",")
            ret.Append(dt.Rows(0)("STOCK_ENTRY_TEMP") & ",")
            ret.Append(dt.Rows(0)("STOCK_EXIT_TEMP") & ",")

            ret.Append(dt.Rows(0)("COOL_WT_LOSS") & ",")
            ret.Append(dt.Rows(0)("COOL_WT_LOSS_PERC") & "%,")
            ret.Append(dt.Rows(0)("FLUE_LOSS_PERC") & "%,")
            ret.Append(dt.Rows(0)("HEAT_MATERIAL") & ",")
            ret.Append(dt.Rows(0)("HEAT_MAT_PERC") & "%,")
            ret.Append(dt.Rows(0)("OPEN_LOSS") & ",")
            ret.Append(dt.Rows(0)("OPEN_LOSS_PERC") & "%,")
            ret.Append(dt.Rows(0)("SKIN_LOSS_PERC") & "%,")
            ret.Append(dt.Rows(0)("TOTAL_GAS_FLOW_ONLINE") & ",")
            ret.Append(dt.Rows(0)("TOTAL_AIR_FLOW_ONLINE") & ",")
            ret.Append(dt.Rows(0)("CV") & ",")



            Return (ret.ToString)
        Else
            Return "novalues"
        End If
        'If dtlabel.Rows.Count > 0 Then
        '    Dim retLabel As New StringBuilder
        '    retLabel.Append(dtlabel.Rows(0)("TOTAL_AIR_FUEL_RATIO"))
        '    retLabel.Append(dtlabel.Rows(0)("BASE_VALUE_RECOM"))
        '    retLabel.Append(dtlabel.Rows(0)("HEAT_INPUT"))
        '    retLabel.Append(dtlabel.Rows(0)("HEAT_INPUT_RECOM"))
        '    retLabel.Append(dtlabel.Rows(0)("SPC_FUEL_CON_ONLINE"))
        '    retLabel.Append(dtlabel.Rows(0)("SPC_FUEL_CON_CAL"))
        '    retLabel.Append(dtlabel.Rows(0)("SPEC_FUEL_CON_RECOM"))
        '    retLabel.Append(dtlabel.Rows(0)("TOTAL_GAS_FLOW_ONLINE"))
        '    retLabel.Append(dtlabel.Rows(0)("TOTAL_GAS_FLOW_CAL"))
        '    retLabel.Append(dtlabel.Rows(0)("TOTAL_GAS_FLOW_RECOM"))
        '    retLabel.Append(dtlabel.Rows(0)("TOTAL_AIR_FLOW_ONLINE"))
        '    retLabel.Append(dtlabel.Rows(0)("TOTAL_AIR_FLOW_CAL"))
        '    retLabel.Append(dtlabel.Rows(0)("TOTAL_AIR_FLOW_RECOM"))


        'Else
        '    Return "novalues"
        'End If


    End Function

    <WebMethod>
    Public Shared Function setAllgridValues_1hour(rdbtnLineA As Boolean, rdbtnLineB As Boolean) As String
        Dim dh As New DataHandler
        Dim oc As New Controller
        'Dim gvData As GridView
        Dim dttablegrid As DataTable
        Dim DSDATE_FORGRID As DataTable = oc.PopulateMaxDatetime()


        Dim dtdateforgrid As DataTable = DSDATE_FORGRID

        Dim ddtdateforgrid As DateTime = CDate(dtdateforgrid.Rows(0)(0))
        Dim frmDateforgrid As String = ddtdateforgrid.ToString("yyyy-MM-dd HH:mm:ss")
        Dim toDateforgrid As String = ddtdateforgrid.AddHours(-1).ToString("yyyy-MM-dd HH:mm:ss")

        If rdbtnLineA Then
            dttablegrid = oc.GetDataForLogDetailsLINEA(toDateforgrid, frmDateforgrid)

        ElseIf rdbtnLineB Then
            dttablegrid = oc.GetDataForLogDetailsLineB(toDateforgrid, frmDateforgrid)

        End If

        Dim dv_forgrid As DataView = dttablegrid.DefaultView
        Try


            For i As Integer = 0 To dttablegrid.Rows.Count - 1
                Dim row As DataRow = dttablegrid.Rows(i)
                If row.Item(1) = 0 And row.Item(2) = 0 And row.Item(3) = 0 And row.Item(3) = 0 And row.Item(4) = 0 And row.Item(5) = 0 And row.Item(6) = 0 Then
                    dttablegrid.Rows(i).Delete()
                    'ElseIf row.Item(0).ToString.Trim = "" Then
                    '    dttablegrid.Rows.Remove(row)
                End If
            Next
        Catch ex As Exception
            ' Throw ex
        End Try
        dttablegrid.AcceptChanges()
        Dim retLabel As New StringBuilder
        If dttablegrid.Rows.Count > 0 Then

            ' Button1.BackColor = Color.Red
            For k As Integer = 0 To dttablegrid.Rows.Count - 1
                '  ret.Append(dt.Rows(0)("CV") & "%,")
                retLabel.Append(dttablegrid.Rows(k)("ROLLER") & ",")
                retLabel.Append(dttablegrid.Rows(k)("ABN_INLET_TEMP_MIN") & ",")
                retLabel.Append(dttablegrid.Rows(k)("ABN_INLET_TEMP_MAX") & ",")
                retLabel.Append(dttablegrid.Rows(k)("ABN_DELTA_T_MIN") & ",")
                retLabel.Append(dttablegrid.Rows(k)("ABN_DELTA_T_MAX") & ",")
                retLabel.Append(dttablegrid.Rows(k)("ABN_OUTLET_TEMP_MIN") & ",")
                retLabel.Append(dttablegrid.Rows(k)("ABN_OUTLET_TEMP_MAX") & "")
                retLabel.Append("#")
            Next


            'btnCoolingWaterLossPerc.BackColor = Color.Red
            Return (retLabel.ToString)
        Else
            Return "novalues"
            'btnCoolingWaterLossPerc.BackColor = Color.Yellow
        End If
        '    btnCoolingWaterLossPerc.BackColor = Color.Red
        'Else
        '    btnCoolingWaterLossPerc.BackColor = Color.Yellow

        'End If





    End Function

    <WebMethod>
    Public Shared Function SetAllValuesGridTables(rbdTimeStamp As Boolean, rbdAVG As Boolean, rdbtnLineA As Boolean, rdbtnLineB As Boolean) As String
        Dim dh As New DataHandler
        Dim oc As New Controller
        Dim dSdate As DataSet = dh.GetDataSetFromQuery("select max(datetime) as DATETIME FROM  [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]")
        Dim dtdate As DataTable = dSdate.Tables(0)

        Dim ddtdate As DateTime = CDate(dtdate.Rows(0)(0))
        Dim frmDate As String = ddtdate.ToString("yyyy-MM-dd HH:mm:ss")
        Dim toDate As String = ddtdate.AddHours(-1).ToString("yyyy-MM-dd HH:mm:ss")
        '================lineA
        Dim dt As DataTable = oc.PopulateDataForHeatDistributionModel()
        Dim dtlabel As DataTable = oc.populatelabelValue()
        Dim dtlabelavg As DataTable = oc.populatelabelValueForAvg(frmDate, toDate)
        '==========LINEB
        Dim dtlineB As DataTable = oc.PopulateDataForHeatDistributionModelFORLINEB()
        Dim dtlabelLineB As DataTable = oc.populatelabelValueFORLINEB()
        '  Dim dtavglineb As DataTable = oc.PopulateAvgValuefromdtLineb(frmDate, toDate)
        Dim dtavglineb As DataTable = oc.populatelabelValueForAvgLineB(frmDate, toDate)

        '================


        If rdbtnLineA Then
            If rbdTimeStamp Then
                dtlabel = oc.populatelabelValue()
            ElseIf rbdAVG Then
                dtlabel = oc.populatelabelValueForAvg(frmDate, toDate)
            End If
        End If
        If rdbtnLineB Then
            If rbdTimeStamp Then
                dtlabel = oc.populatelabelValueFORLINEB()
            ElseIf rbdAVG Then
                'dtlabel = oc.PopulateAvgValuefromdtLineb(frmDate, toDate)
                dtlabel = oc.populatelabelValueForAvgLineB(frmDate, toDate)

            End If
        End If


        If dtlabel.Rows.Count > 0 Then
            Dim retLabel As New StringBuilder
            '  ret.Append(dt.Rows(0)("CV") & "%,")
            retLabel.Append(dtlabel.Rows(0)("TOTAL_AIR_FUEL_RATIO") & ",")
            retLabel.Append(dtlabel.Rows(0)("BASE_VALUE_RECOM") & ",")
            retLabel.Append(dtlabel.Rows(0)("HEAT_INPUT") & ",")
            retLabel.Append(dtlabel.Rows(0)("HEAT_INPUT_RECOM") & ",")
            retLabel.Append(dtlabel.Rows(0)("SPC_FUEL_CON_ONLINE") & ",")
            retLabel.Append(dtlabel.Rows(0)("SPC_FUEL_CON_CAL") & ",")
            retLabel.Append(dtlabel.Rows(0)("SPEC_FUEL_CON_RECOM") & ",")
            retLabel.Append(dtlabel.Rows(0)("TOTAL_GAS_FLOW_ONLINE") & ",")
            retLabel.Append(dtlabel.Rows(0)("TOTAL_GAS_FLOW_CAL") & ",")
            retLabel.Append(dtlabel.Rows(0)("TOTAL_GAS_FLOW_RECOM") & ",")
            retLabel.Append(dtlabel.Rows(0)("TOTAL_AIR_FLOW_ONLINE") & ",")
            retLabel.Append(dtlabel.Rows(0)("TOTAL_AIR_FLOW_CAL") & ",")
            retLabel.Append(dtlabel.Rows(0)("TOTAL_AIR_FLOW_RECOM") & ",")

            Return (retLabel.ToString)
        Else
            Return "novalues"
        End If


    End Function


    <WebMethod>
    Public Shared Function setlabeltime(rdbtnLineA As Boolean, rdbtnLineB As Boolean) As String
        Dim dh As New DataHandler
        Dim oc As New Controller
        Dim dtdate As DataTable = oc.PopulateMaxDatetime()

        If rdbtnLineA Then
            dtdate = oc.PopulateMaxDatetime()
        ElseIf rdbtnLineB Then
            dtdate = oc.PopulateMaxDatetime()
        End If

        If dtdate.Rows.Count > 0 Then
            Dim retdate As New StringBuilder


            retdate.Append(CDate(dtdate.Rows(0)("DATETIME")).ToString("yyyy-MM-dd HH:mm:ss") & ",")


            Return (retdate.ToString)
        Else
            Return "novalues"
        End If


    End Function

    '<WebMethod>
    'Public Shared Function setSpecificMonthAVG(rdbtnLineA As Boolean, rdbtnLineB As Boolean) As String
    '    Dim dh As New DataHandler
    '    Dim oc As New Controller
    '    Dim dtspecificdataset As DataSet = dh.GetDataSetFromQuery("SELECT cast(AVG(SPC_FUEL_CON_ONLINE) As Decimal(10,3)) As SPC_FUEL_CON_ONLINE FROM [TSCR_FURNACE_OPT_FINAL]  where  DATEPART(m, datetime) = DATEPART(m, DATEADD(m, 0, getdate())) GROUP BY DATENAME(MONTH,DATETIME) order by DATENAME(MONTH,DATETIME) asc")
    '    Dim dtspecificdatatable As DataTable = dtspecificdataset.Tables(0)
    '    Dim dtspecific As String = dtspecificdatatable.Rows(0)("SPC_FUEL_CON_ONLINE")
    '    ' lblSpecific.Text = dtspecific
    '    If rdbtnLineA Then
    '        dtspecificdatatable = dtspecificdataset.Tables(0)
    '    ElseIf rdbtnLineB Then
    '        dtspecificdatatable = dtspecificdataset.Tables(0)
    '    End If

    '    If dtspecificdatatable.Rows.Count > 0 Then
    '        Dim ret As New StringBuilder


    '        ret.Append(dtspecificdatatable.Rows(0)("SPC_FUEL_CON_ONLINE") & ",")


    '        Return (ret.ToString)
    '    Else
    '        Return "novalues"
    '    End If


    'End Function

    <WebMethod>
    Public Shared Function setSpecificMonthAVG(rdbtnLineA As Boolean, rdbtnLineB As Boolean) As String
        Dim dh As New DataHandler
        Dim oc As New Controller
        Dim TOTAL_SPEC1 As String = ""

        Dim Monthgrid As String = DateTime.Now.ToString("MM")

        Dim yeargrid As String = DateTime.Now.ToString("yyyy")

        Dim first_dategrid As String = 1



        Dim stdategrid As String = yeargrid & "-" & Monthgrid & "-" & first_dategrid
        '  Dim stdate As String = DateTime.Now.AddDays(-3).ToString("yyyy-MM-dd")
        Dim enddategrid As String = DateTime.Now.ToString("yyyy-MM-dd")
        Dim query As String = "Select CONVERT(VARCHAR(10),datetime,120) as datetime, [PRODUCTION], [ON_DATE], [TO_DATE],TOTAL_GAS_CON FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY]  " &
                                   "where DATETIME between '" & stdategrid & "' and '" & enddategrid & "' and PRODUCTION = 'HRC'    order by DATETIME asc"

        Dim count As Short = 0
        Dim getdt As DataTable = dh.GetDataSetFromQuery(query).Tables(0)








        Dim lfcdec_query As String = "SELECT CONVERT(VARCHAR(10),datetime,120) as datetime,   CAST(ROUND(avg(CV), 2) AS DECIMAL(10,2)) as cv FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]  Where  DATETIME between '" & stdategrid & "' and '" & enddategrid & "' and cv is not null group by CONVERT(VARCHAR(10),datetime,120) 	order by CONVERT(VARCHAR(10),datetime,120) asc"

        Dim decisiondt As DataTable = dh.GetDataSetFromQuery(lfcdec_query).Tables(0)

        Dim min As String = ""
        Dim max As String = ""
        Try
            If getdt.Rows.Count > 0 Then

                If decisiondt.Rows.Count > 0 Then
                    Dim query1 As String = "Select CONVERT(VARCHAR(10),datetime,120) as datetime, [PRODUCTION], [ON_DATE], [TO_DATE],TOTAL_GAS_CON FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY]  " &
                                   "where DATETIME between '" & stdategrid & "' and '" & enddategrid & "'   and PRODUCTION ='HRC' order by DATETIME asc"
                    Dim HRC As DataTable = dh.GetDataSetFromQuery(query1).Tables(0)

                    For j As Integer = 0 To getdt.Rows.Count - 1
                        Try
                            Dim row As DataRow = decisiondt.Select("datetime='" & getdt.Rows(j)(0) & "'")(0)


                            Dim HRCDT As DataRow = HRC.Select("datetime='" & getdt.Rows(j)(0) & "'")(0)

                            If IsDBNull(getdt.Rows.Item(j)(4)) Or IsDBNull(getdt.Rows.Item(j)(2)) Then 'or replace from and  and getdt.rows.item(j)(2) from getdt.rows.item(j)(4)


                                '  TOTAL_SPEC1 &= "'" & getdt.Rows(j)(0).ToString & "',"
                                TOTAL_SPEC1 &= 0 & ","

                            Else

                                ' TOTAL_SPEC1 &= "'" & getdt.Rows(j)(0).ToString & "',"
                                Dim valhrc As Decimal = ((getdt.Rows.Item(j)(4) * row.Item(1)) / ((HRCDT.Item(2)) * 1000000))
                                Dim spe_totalhrc As Decimal = FormatNumber(valhrc, 4)




                                TOTAL_SPEC1 &= spe_totalhrc & ","
                            End If
                            ' End If
                            count += 1
                        Catch ex As Exception

                            TOTAL_SPEC1 &= "," '((getdt.Rows.Item(j)(4) * row.Item(1)) / ((HRCDT.Item(2)) * 1000000)) & ","

                            Continue For ' Throw ex
                        End Try
                    Next

                End If

            End If


        Catch ex As Exception
            Return "novalues"
        End Try


        Dim sum, count1 As Double

        'For Each s As String In TOTAL_SPEC1.Split(",")
        '    If Not String.IsNullOrEmpty(s) Then
        '        sum += s
        '        count1 += 1
        '    End If

        'Next
        'Dim VAL_SPEC As Decimal = sum / count1
        'Dim SPECTOTAL As Decimal = FormatNumber(VAL_SPEC, 4)
        Dim VAL_SPEC As Decimal
        Dim SPECTOTAL As Decimal
        If TOTAL_SPEC1 = "" Then
            VAL_SPEC = 0
            Return VAL_SPEC
        Else
            For Each s As String In TOTAL_SPEC1.Split(",")
                If Not String.IsNullOrEmpty(s) Then
                    sum += s
                    count1 += 1
                End If

            Next
            VAL_SPEC = sum / count1
            SPECTOTAL = FormatNumber(VAL_SPEC, 4)
            Return SPECTOTAL
        End If
        'Return SPECTOTAL

        '    Return (retdate.ToString)
        'Else
        '    Return "novalues"
        'End If


    End Function

    <WebMethod>
    Public Shared Function CurrMonthCumulativeSpecificFuel() As String
        Dim CummFuelData As String
        CummFuelData = ""
        Dim dh As New DataHandler

        Dim sqlQueryCum As String = "select top 1 [CUM_SPEC_FUEL_CON] FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY] where PRODUCTION='HRC' order by [DATETIME] desc"
        Dim dtLB As DataTable = New DataTable()
        'dtLB = getdatatable(sqlQueryCum)
        dtLB = dh.GetDataSetFromQuery(sqlQueryCum).Tables(0)
        For Each row As DataRow In dtLB.Rows
            CummFuelData &= row("CUM_SPEC_FUEL_CON") & ","
        Next row
        Return CummFuelData
    End Function

    'Public Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
    '    ' MultiView1.ActiveViewIndex = 1
    '    MultiView1.ActiveViewIndex = 0



    '    Dim dSdate As DataSet = objdatahandler.GetDataSetFromQuery("select max(datetime) as DATETIME FROM  [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]")
    '    Dim dtdate As DataTable = dSdate.Tables(0)

    '    Dim ddtdate As DateTime = dtdate.Rows(0)("DATETIME")
    '    Dim frmDate As String = ddtdate.ToString("yyyy-MM-dd HH:mm:ss")
    '    Dim toDate As String = ddtdate.AddHours(-1).ToString("yyyy-MM-dd HH:mm:ss")
    '    lblMAXDATETIME.Text = frmDate


    '    Dim dt As DataTable = objController.PopulateDataForHeatDistributionModel()
    '    Dim dtlabel As DataTable = objController.populatelabelValue()
    '    If rbdTimeStamp.Checked Then
    '        dtlabel = objController.populatelabelValue()
    '    ElseIf rbdAVG.Checked Then
    '        dtlabel = objController.populatelabelValueForAvg(frmDate, toDate)
    '    End If
    '    Dim dtavg As DataTable = objController.PopulateAvgValuefromdt(frmDate, toDate)

    '    Dim dtlineB As DataTable = objController.PopulateDataForHeatDistributionModelFORLINEB()
    '    Dim dtlabelLineB As DataTable = objController.populatelabelValueFORLINEB()

    '    Dim dtavglineb As DataTable = objController.PopulateAvgValuefromdtLineb(frmDate, toDate)

    '    If rdbtnLineA.Checked = True Then
    '        Session("checkboxval") = "A"

    '        '  DrawChartTop()
    '        If dt.Rows.Count > 0 Then
    '            '            'txtHeatRecover1.Text = dt.Rows(0)("HEAT_RECOV1")
    '            btnHeatRecover1.Text = dt.Rows(0)("HEAT_RECOV1") & "%"
    '            btnHeatRecoverySanky1.Text = dt.Rows(0)("HEAT_RECOV1") & "%"
    '            'txtHeatRecover2.Text = dt.Rows(0)("HEAT_RECOV2")
    '            btnHeatRecover2.Text = dt.Rows(0)("HEAT_RECOV2") & "%"
    '            btnHeatRecoverySanky2.Text = dt.Rows(0)("HEAT_RECOV2") & "%"
    '            'txtHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3")
    '            btnHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3") & "%"
    '            btnHeatRecoverySanky3.Text = dt.Rows(0)("HEAT_RECOV3") & "%"
    '            'txtRecup1.Text = dt.Rows(0)("RECUP1_PERFORM")
    '            btnRecup1.Text = dt.Rows(0)("RECUP1_PERFORM") & "%"
    '            btnrecupSanky1.Text = dt.Rows(0)("RECUP1_PERFORM") & "%"
    '            'txtRecup2.Text = dt.Rows(0)("RECUP2_PERFORM")
    '            btnRecup2.Text = dt.Rows(0)("RECUP2_PERFORM") & "%"
    '            btnrecupSanky2.Text = dt.Rows(0)("RECUP2_PERFORM") & "%"
    '            'txtRecup3.Text = dt.Rows(0)("RECUP3_PERFORM")
    '            btnRecup3.Text = dt.Rows(0)("RECUP3_PERFORM") & "%"
    '            btnrecupSanky3.Text = dt.Rows(0)("RECUP3_PERFORM") & "%"
    '            'txtHeatInput.Text = dt.Rows(0)("HEAT_INPUT")
    '            btnHeatInput.Text = dt.Rows(0)("HEAT_INPUT") & "%"
    '            btnHeatInputSanky.Text = dt.Rows(0)("HEAT_INPUT") & "%"
    '            'txtThroughPut.Text = dt.Rows(0)("THROUGHPUT")


    '            btnThroughPut.Text = dt.Rows(0)("THROUGHPUT")
    '            btnThroughPutSanky.Text = dt.Rows(0)("THROUGHPUT")
    '            'txtStockEntryTemp.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
    '            btnStockEntryTemp.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
    '            btnStockEbtryTempSanky.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
    '            'txtStockExitTemp.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
    '            btnStockExitTemp.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
    '            btnStockExitTempSanky.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
    '            'txtCoolingWaterLoss.Text = dt.Rows(0)("COOL_WT_LOSS")
    '            btnCoolingWaterLoss.Text = dt.Rows(0)("COOL_WT_LOSS")
    '            btnCoolingWaterLossSanky.Text = dt.Rows(0)("COOL_WT_LOSS")
    '            btnCoolingWaterLossPerc.Text = dt.Rows(0)("COOL_WT_LOSS_PERC") & "%"
    '            btnCoolingWaterLossPercSanky.Text = dt.Rows(0)("COOL_WT_LOSS_PERC") & "%"
    '            'txtFuelLoss.Text = dt.Rows(0)("FLUE_LOSS_PERC")

    '            btnFuelLossPerc.Text = dt.Rows(0)("FLUE_LOSS_PERC") & "%"
    '            btnFuelLossPrecSanky.Text = dt.Rows(0)("FLUE_LOSS_PERC") & "%"
    '            'txtHeatMaterial.Text = dt.Rows(0)("HEAT_MATERIAL")
    '            btnHeatMaterial.Text = dt.Rows(0)("HEAT_MATERIAL")
    '            btnHeatMaterialSanky.Text = dt.Rows(0)("HEAT_MATERIAL")

    '            btnHeatMaterialPerc.Text = dt.Rows(0)("HEAT_MAT_PERC") & "%"
    '            btnHeatMaterialpercSanky.Text = dt.Rows(0)("HEAT_MAT_PERC") & "%"
    '            'txtOpenLoss.Text = dt.Rows(0)("OPEN_LOSS")
    '            btnOpenLoss.Text = dt.Rows(0)("OPEN_LOSS")
    '            btnOpenLossSanky.Text = dt.Rows(0)("OPEN_LOSS")
    '            btnOpenLossPerc.Text = dt.Rows(0)("OPEN_LOSS_PERC") & "%"
    '            btnOpenLossPRECSanky.Text = dt.Rows(0)("OPEN_LOSS_PERC") & "%"
    '            'txtWallRoofLoss.Text = dt.Rows(0)("SKIN_LOSS_PERC")

    '            btnWallRoofLossPerc.Text = dt.Rows(0)("SKIN_LOSS_PERC") & "%"
    '            btnWallRoofLossPrecSanky.Text = dt.Rows(0)("SKIN_LOSS_PERC") & "%"
    '            'txtAirFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_CAL")
    '            btnAirFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_ONLINE") '("TOTAL_AIR_FLOW_CAL")
    '            btnAirFlowSanky.Text = dt.Rows(0)("TOTAL_GAS_FLOW_ONLINE") '("TOTAL_AIR_FLOW_CAL")
    '            'txtGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_CAL")
    '            btnGasFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_ONLINE") '("TOTAL_GAS_FLOW_CAL")
    '            btnGasFlowSanky.Text = dt.Rows(0)("TOTAL_AIR_FLOW_ONLINE") '("TOTAL_GAS_FLOW_CAL")
    '            'txtCV.Text = dt.Rows(0)("CV")
    '            btnCV.Text = dt.Rows(0)("CV")
    '            btnCvSanky.Text = dt.Rows(0)("CV")


    '        Else



    '            'txtHeatRecover1.Text = dt.Rows(0)("HEAT_RECOV1")
    '            btnHeatRecover1.Text = ""
    '            btnHeatRecoverySanky1.Text = ""
    '            'txtHeatRecover2.Text = dt.Rows(0)("HEAT_RECOV2")
    '            btnHeatRecover2.Text = ""
    '            btnHeatRecoverySanky2.Text = ""
    '            'txtHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3")
    '            btnHeatRecover3.Text = ""
    '            btnHeatRecoverySanky3.Text = ""
    '            'txtRecup1.Text = dt.Rows(0)("RECUP1_PERFORM")
    '            btnRecup1.Text = ""
    '            btnrecupSanky1.Text = ""
    '            'txtRecup2.Text = dt.Rows(0)("RECUP2_PERFORM")
    '            btnRecup2.Text = ""
    '            btnrecupSanky2.Text = ""
    '            'txtRecup3.Text = dt.Rows(0)("RECUP3_PERFORM")
    '            btnRecup3.Text = ""
    '            btnrecupSanky3.Text = ""
    '            'txtHeatInput.Text = dt.Rows(0)("HEAT_INPUT")
    '            btnHeatInput.Text = ""
    '            btnHeatInputSanky.Text = ""
    '            'txtThroughPut.Text = dt.Rows(0)("THROUGHPUT")


    '            btnThroughPut.Text = ""
    '            btnThroughPutSanky.Text = ""
    '            'txtStockEntryTemp.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
    '            btnStockEntryTemp.Text = ""
    '            btnStockEbtryTempSanky.Text = ""
    '            'txtStockExitTemp.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
    '            btnStockExitTemp.Text = ""
    '            btnStockExitTempSanky.Text = ""
    '            'txtCoolingWaterLoss.Text = dt.Rows(0)("COOL_WT_LOSS")
    '            btnCoolingWaterLoss.Text = ""
    '            btnCoolingWaterLossSanky.Text = ""
    '            btnCoolingWaterLossPerc.Text = ""
    '            btnCoolingWaterLossPercSanky.Text = ""
    '            'txtFuelLoss.Text = dt.Rows(0)("FLUE_LOSS_PERC")

    '            btnFuelLossPerc.Text = ""
    '            btnFuelLossPrecSanky.Text = ""
    '            'txtHeatMaterial.Text = dt.Rows(0)("HEAT_MATERIAL")
    '            btnHeatMaterial.Text = ""
    '            btnHeatMaterialSanky.Text = ""
    '            btnHeatMaterialPerc.Text = ""
    '            btnHeatMaterialpercSanky.Text = ""
    '            'txtOpenLoss.Text = dt.Rows(0)("OPEN_LOSS")
    '            btnOpenLoss.Text = ""
    '            btnOpenLossSanky.Text = ""
    '            btnOpenLossPerc.Text = ""
    '            btnOpenLossPRECSanky.Text = ""
    '            'txtWallRoofLoss.Text = dt.Rows(0)("SKIN_LOSS_PERC")

    '            btnWallRoofLossPerc.Text = ""
    '            btnWallRoofLossPrecSanky.Text = ""
    '            'txtAirFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_CAL")
    '            btnAirFlow.Text = ""
    '            btnAirFlowSanky.Text = ""
    '            'txtGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_CAL")
    '            btnGasFlow.Text = ""
    '            btnGasFlowSanky.Text = ""
    '            'txtCV.Text = dt.Rows(0)("CV")
    '            btnCV.Text = ""
    '            btnCvSanky.Text = ""

    '        End If
    '        '  Dim dtlabel As DataTable = objController.populatelabelValue()
    '        If dtlabel.Rows.Count > 0 Then

    '            'If dtavg.Rows.Count > 0 Then
    '            '    Dim AvgData = ""
    '            '    'Dim arrYValues(dtavg.Rows.Count) As Decimal
    '            '    '  arrYValues = (From row In dtlabel Select col = Decimal.Parse(row(Trim("SPC_FUEL_CON_ONLINE"))) Where "DATETIME" >= DateAdd(DateInterval.Hour, -1, DateTime.Now)) '.ToArray

    '            '    'arrYValues = dtavg.AsEnumerable.Where(Function(r) r.Field(Of DateTime)("Datetime") > DateTime.Now.AddHours(-1)).Select(Function(x) x.Field(Of Decimal)("SPC_FUEL_CON_ONLINE")).ToArray
    '            '    'arrYValues = (From row In dtlabel Select col = Decimal.Parse(row(Trim("SPC_FUEL_CON_ONLINE")).ToString()) Where DateTime > DateAdd(Hour, -1, GETDATE())).ToArray
    '            '    Dim arrYValues As Decimal = dtavg.AsEnumerable.Select(Function(x) x.Field(Of Decimal)("SPC_FUEL_CON_ONLINE")).Average()

    '            '    'Array.Sort(arrYValues)
    '            '    AvgData = arrYValues

    '            '    Dim d As Double
    '            '    'd = Math.Round(AvgData, 2)

    '            '    d = AvgData
    '            '    avgButtonOnline.Text = Math.Round(d, 3)
    '            'Else
    '            '    avgButtonOnline.Text = ""
    '            'End If

    '            BaseValueOnline.Text = dtlabel.Rows(0)("TOTAL_AIR_FUEL_RATIO")
    '            BaseValueRecommended.Text = dtlabel.Rows(0)("BASE_VALUE_RECOM")
    '            '=================================================
    '            '   HeatInputOnline.Text = dtlabel.Rows(0)("HEAT_INPUT")
    '            HeatInputCalculated.Text = dtlabel.Rows(0)("HEAT_INPUT")
    '            HeatInputRecommended.Text = dtlabel.Rows(0)("HEAT_INPUT_RECOM")
    '            '====================================================
    '            SpecificationOnline.Text = dtlabel.Rows(0)("SPC_FUEL_CON_ONLINE")
    '            SpecificationCalculated.Text = dtlabel.Rows(0)("SPC_FUEL_CON_CAL")
    '            SpecificationRecommended.Text = dtlabel.Rows(0)("SPEC_FUEL_CON_RECOM")
    '            '====================================================
    '            TotalGasFlowOnline.Text = dtlabel.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
    '            TotalGasFlowCalculated.Text = dtlabel.Rows(0)("TOTAL_GAS_FLOW_CAL")
    '            TotalGasFlowRecommended.Text = dtlabel.Rows(0)("TOTAL_GAS_FLOW_RECOM")
    '            '========================================================
    '            TotalAirFlowOnline.Text = dtlabel.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
    '            TotalAirFlowCalculated.Text = dtlabel.Rows(0)("TOTAL_AIR_FLOW_CAL")
    '            TotalAirFlowRecommended.Text = dtlabel.Rows(0)("TOTAL_AIR_FLOW_RECOM")
    '        Else
    '            BaseValueOnline.Text = ""
    '            BaseValueRecommended.Text = ""
    '            '=================================================
    '            '   HeatInputOnline.Text = dtlabel.Rows(0)("HEAT_INPUT")
    '            HeatInputCalculated.Text = ""
    '            HeatInputRecommended.Text = ""
    '            '====================================================
    '            SpecificationOnline.Text = ""
    '            SpecificationCalculated.Text = ""
    '            SpecificationRecommended.Text = ""
    '            '====================================================
    '            TotalGasFlowOnline.Text = ""
    '            TotalGasFlowCalculated.Text = ""
    '            TotalGasFlowRecommended.Text = ""
    '            '========================================================
    '            TotalAirFlowOnline.Text = ""
    '            TotalAirFlowCalculated.Text = ""
    '            TotalAirFlowRecommended.Text = ""
    '        End If
    '    End If


    '    If rdbtnLineB.Checked = True Then
    '        Session("checkboxval") = "B"
    '        ' DrawChartTop()
    '        If dtlineB.Rows.Count > 0 Then
    '            'txtHeatRecover1.Text = dtlineB.Rows(0)("HEAT_RECOV1")
    '            btnHeatRecover1.Text = dtlineB.Rows(0)("HEAT_RECOV1") & "%"
    '            btnHeatRecoverySanky1.Text = dtlineB.Rows(0)("HEAT_RECOV1") & "%"
    '            'txtHeatRecover2.Text = dtlineB.Rows(0)("HEAT_RECOV2")
    '            btnHeatRecover2.Text = dtlineB.Rows(0)("HEAT_RECOV2") & "%"
    '            btnHeatRecoverySanky2.Text = dtlineB.Rows(0)("HEAT_RECOV2") & "%"
    '            'txtHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3")
    '            btnHeatRecover3.Text = dtlineB.Rows(0)("HEAT_RECOV3") & "%"
    '            btnHeatRecoverySanky3.Text = dtlineB.Rows(0)("HEAT_RECOV3") & "%"
    '            'txtRecup1.Text = dtlineB.Rows(0)("RECUP1_PERFORM")
    '            btnRecup1.Text = dtlineB.Rows(0)("RECUP1_PERFORM") & "%"
    '            btnrecupSanky1.Text = dtlineB.Rows(0)("RECUP1_PERFORM") & "%"
    '            'txtRecup2.Text = dtlineB.Rows(0)("RECUP2_PERFORM")
    '            btnRecup2.Text = dtlineB.Rows(0)("RECUP2_PERFORM") & "%"
    '            btnrecupSanky2.Text = dtlineB.Rows(0)("RECUP2_PERFORM") & "%"
    '            'txtRecup3.Text = dtlineB.Rows(0)("RECUP3_PERFORM")
    '            btnRecup3.Text = dtlineB.Rows(0)("RECUP3_PERFORM") & "%"
    '            btnrecupSanky3.Text = dtlineB.Rows(0)("RECUP3_PERFORM") & "%"
    '            'txtHeatInput.Text = dtlineB.Rows(0)("HEAT_INPUT")
    '            btnHeatInput.Text = dtlineB.Rows(0)("HEAT_INPUT") & "%"
    '            btnHeatInputSanky.Text = dtlineB.Rows(0)("HEAT_INPUT") & "%"
    '            'txtThroughPut.Text = dtlineB.Rows(0)("THROUGHPUT")


    '            btnThroughPut.Text = dtlineB.Rows(0)("THROUGHPUT")
    '            btnThroughPutSanky.Text = dtlineB.Rows(0)("THROUGHPUT")
    '            'txtStockEntryTemp.Text = dtlineB.Rows(0)("STOCK_ENTRY_TEMP")
    '            btnStockEntryTemp.Text = dtlineB.Rows(0)("STOCK_ENTRY_TEMP")
    '            btnStockEbtryTempSanky.Text = dtlineB.Rows(0)("STOCK_ENTRY_TEMP")
    '            'txtStockExitTemp.Text = dtlineB.Rows(0)("STOCK_EXIT_TEMP")
    '            btnStockExitTemp.Text = dtlineB.Rows(0)("STOCK_EXIT_TEMP")
    '            btnStockExitTempSanky.Text = dtlineB.Rows(0)("STOCK_EXIT_TEMP")
    '            'txtCoolingWaterLoss.Text = dtlineB.Rows(0)("COOL_WT_LOSS")
    '            btnCoolingWaterLoss.Text = dtlineB.Rows(0)("COOL_WT_LOSS")
    '            btnCoolingWaterLossSanky.Text = dtlineB.Rows(0)("COOL_WT_LOSS")
    '            btnCoolingWaterLossPerc.Text = dtlineB.Rows(0)("COOL_WT_LOSS_PERC") & "%"
    '            btnCoolingWaterLossPercSanky.Text = dtlineB.Rows(0)("COOL_WT_LOSS_PERC") & "%"
    '            'txtFuelLoss.Text = dtlineB.Rows(0)("FLUE_LOSS_PERC")

    '            btnFuelLossPerc.Text = dtlineB.Rows(0)("FLUE_LOSS_PERC") & "%"
    '            btnFuelLossPrecSanky.Text = dtlineB.Rows(0)("FLUE_LOSS_PERC") & "%"
    '            'txtHeatMaterial.Text = dtlineB.Rows(0)("HEAT_MATERIAL")
    '            btnHeatMaterial.Text = dtlineB.Rows(0)("HEAT_MATERIAL")
    '            btnHeatMaterialSanky.Text = dtlineB.Rows(0)("HEAT_MATERIAL")
    '            btnHeatMaterialPerc.Text = dtlineB.Rows(0)("HEAT_MAT_PERC") & "%"
    '            btnHeatMaterialpercSanky.Text = dtlineB.Rows(0)("HEAT_MAT_PERC") & "%"
    '            'txtOpenLoss.Text = dtlineB.Rows(0)("OPEN_LOSS")
    '            btnOpenLoss.Text = dtlineB.Rows(0)("OPEN_LOSS")
    '            btnOpenLossSanky.Text = dtlineB.Rows(0)("OPEN_LOSS")
    '            btnOpenLossPerc.Text = dtlineB.Rows(0)("OPEN_LOSS_PERC") & "%"
    '            btnOpenLossPRECSanky.Text = dtlineB.Rows(0)("OPEN_LOSS_PERC") & "%"
    '            'txtWallRoofLoss.Text = dtlineB.Rows(0)("SKIN_LOSS_PERC")

    '            btnWallRoofLossPerc.Text = dtlineB.Rows(0)("SKIN_LOSS_PERC") & "%"
    '            btnWallRoofLossPrecSanky.Text = dtlineB.Rows(0)("SKIN_LOSS_PERC") & "%"
    '            'txtAirFlow.Text = dtlineB.Rows(0)("TOTAL_AIR_FLOW_CAL")
    '            btnAirFlow.Text = dtlineB.Rows(0)("TOTAL_GAS_FLOW_ONLINE") '("TOTAL_AIR_FLOW_CAL")
    '            btnAirFlowSanky.Text = dtlineB.Rows(0)("TOTAL_GAS_FLOW_ONLINE") '("TOTAL_AIR_FLOW_CAL")
    '            'txtGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_CAL")
    '            btnGasFlow.Text = dtlineB.Rows(0)("TOTAL_AIR_FLOW_ONLINE") '("TOTAL_GAS_FLOW_CAL")
    '            btnGasFlowSanky.Text = dtlineB.Rows(0)("TOTAL_AIR_FLOW_ONLINE") '("TOTAL_GAS_FLOW_CAL")
    '            'txtCV.Text = dtlineB.Rows(0)("CV")
    '            btnCV.Text = dtlineB.Rows(0)("CV")
    '            btnCvSanky.Text = dtlineB.Rows(0)("CV")
    '        Else

    '            'txtHeatRecover1.Text = dt.Rows(0)("HEAT_RECOV1")
    '            btnHeatRecover1.Text = ""
    '            btnHeatRecoverySanky1.Text = ""
    '            'txtHeatRecover2.Text = dt.Rows(0)("HEAT_RECOV2")
    '            btnHeatRecover2.Text = ""
    '            btnHeatRecoverySanky2.Text = ""
    '            'txtHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3")
    '            btnHeatRecover3.Text = ""
    '            btnHeatRecoverySanky3.Text = ""
    '            'txtRecup1.Text = dt.Rows(0)("RECUP1_PERFORM")
    '            btnRecup1.Text = ""
    '            btnrecupSanky1.Text = ""
    '            'txtRecup2.Text = dt.Rows(0)("RECUP2_PERFORM")
    '            btnRecup2.Text = ""
    '            btnrecupSanky2.Text = ""
    '            'txtRecup3.Text = dt.Rows(0)("RECUP3_PERFORM")
    '            btnRecup3.Text = ""
    '            btnrecupSanky3.Text = ""
    '            'txtHeatInput.Text = dt.Rows(0)("HEAT_INPUT")
    '            btnHeatInput.Text = ""
    '            btnHeatInputSanky.Text = ""
    '            'txtThroughPut.Text = dt.Rows(0)("THROUGHPUT")


    '            btnThroughPut.Text = ""
    '            btnThroughPutSanky.Text = ""
    '            'txtStockEntryTemp.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
    '            btnStockEntryTemp.Text = ""
    '            btnStockEbtryTempSanky.Text = ""
    '            'txtStockExitTemp.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
    '            btnStockExitTemp.Text = ""
    '            btnStockExitTempSanky.Text = ""
    '            'txtCoolingWaterLoss.Text = dt.Rows(0)("COOL_WT_LOSS")
    '            btnCoolingWaterLoss.Text = ""
    '            btnCoolingWaterLossSanky.Text = ""
    '            btnCoolingWaterLossPerc.Text = ""
    '            btnCoolingWaterLossPercSanky.Text = ""
    '            'txtFuelLoss.Text = dt.Rows(0)("FLUE_LOSS_PERC")

    '            btnFuelLossPerc.Text = ""
    '            btnFuelLossPrecSanky.Text = ""
    '            'txtHeatMaterial.Text = dt.Rows(0)("HEAT_MATERIAL")
    '            btnHeatMaterial.Text = ""
    '            btnHeatMaterialSanky.Text = ""
    '            btnHeatMaterialPerc.Text = ""
    '            btnHeatMaterialpercSanky.Text = ""
    '            'txtOpenLoss.Text = dt.Rows(0)("OPEN_LOSS")
    '            btnOpenLoss.Text = ""
    '            btnOpenLossSanky.Text = ""
    '            btnOpenLossPerc.Text = ""
    '            btnOpenLossPRECSanky.Text = ""
    '            'txtWallRoofLoss.Text = dt.Rows(0)("SKIN_LOSS_PERC")

    '            btnWallRoofLossPerc.Text = ""
    '            btnWallRoofLossPrecSanky.Text = ""
    '            'txtAirFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_CAL")
    '            btnAirFlow.Text = ""
    '            btnAirFlowSanky.Text = ""
    '            'txtGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_CAL")
    '            btnGasFlow.Text = ""
    '            btnGasFlowSanky.Text = ""
    '            'txtCV.Text = dt.Rows(0)("CV")
    '            btnCV.Text = ""
    '            btnCvSanky.Text = ""

    '        End If


    '        'Dim dtlabel As DataTable = objController.populatelabelValue()
    '        If dtlabelLineB.Rows.Count > 0 Then


    '            'If dtavglineb.Rows.Count > 0 Then
    '            '    Dim AvgData = ""
    '            '    'Dim arrYValues(dtavglineb.Rows.Count) As Decimal
    '            '    '  arrYValues = (From row In dtlabel Select col = Decimal.Parse(row(Trim("SPC_FUEL_CON_ONLINE"))) Where "DATETIME" >= DateAdd(DateInterval.Hour, -1, DateTime.Now)) '.ToArray

    '            '    'arrYValues = dtavglineb.AsEnumerable.Where(Function(r) r.Field(Of DateTime)("Datetime") > DateTime.Now.AddHours(-1)).Select(Function(x) x.Field(Of Decimal)("SPC_FUEL_CON_ONLINE")).ToArray
    '            '    'arrYValues = (From row In dtlabel Select col = Decimal.Parse(row(Trim("SPC_FUEL_CON_ONLINE")).ToString()) Where DateTime > DateAdd(Hour, -1, GETDATE())).ToArray
    '            '    Dim arrYValues As Decimal = dtavglineb.AsEnumerable.Select(Function(x) x.Field(Of Decimal)("SPC_FUEL_CON_ONLINE")).Average()

    '            '    'Array.Sort(arrYValues)
    '            '    AvgData = arrYValues

    '            '    Dim d As Double
    '            '    'd = Math.Round(AvgData, 2)

    '            '    d = AvgData
    '            '    avgButtonOnline.Text = Math.Round(d, 3)
    '            'Else
    '            '    avgButtonOnline.Text = ""
    '            'End If


    '            BaseValueOnline.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FUEL_RATIO")
    '            BaseValueRecommended.Text = dtlabelLineB.Rows(0)("BASE_VALUE_RECOM")
    '            '=================================================
    '            '   HeatInputOnline.Text = dtlabelLineB.Rows(0)("HEAT_INPUT")
    '            HeatInputCalculated.Text = dtlabelLineB.Rows(0)("HEAT_INPUT")
    '            HeatInputRecommended.Text = dtlabelLineB.Rows(0)("HEAT_INPUT_RECOM")
    '            '====================================================
    '            SpecificationOnline.Text = dtlabelLineB.Rows(0)("SPC_FUEL_CON_ONLINE")
    '            SpecificationCalculated.Text = dtlabelLineB.Rows(0)("SPC_FUEL_CON_CAL")
    '            SpecificationRecommended.Text = dtlabelLineB.Rows(0)("SPEC_FUEL_CON_RECOM")
    '            '====================================================
    '            TotalGasFlowOnline.Text = dtlabelLineB.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
    '            TotalGasFlowCalculated.Text = dtlabelLineB.Rows(0)("TOTAL_GAS_FLOW_CAL")
    '            TotalGasFlowRecommended.Text = dtlabelLineB.Rows(0)("TOTAL_GAS_FLOW_RECOM")
    '            '========================================================
    '            TotalAirFlowOnline.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
    '            TotalAirFlowCalculated.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FLOW_CAL")
    '            TotalAirFlowRecommended.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FLOW_RECOM")
    '        Else
    '            BaseValueOnline.Text = ""
    '            BaseValueRecommended.Text = ""
    '            '=================================================
    '            '   HeatInputOnline.Text = dtlabelLineB.Rows(0)("HEAT_INPUT")
    '            HeatInputCalculated.Text = ""
    '            HeatInputRecommended.Text = ""
    '            '====================================================
    '            SpecificationOnline.Text = ""
    '            SpecificationCalculated.Text = ""
    '            SpecificationRecommended.Text = ""
    '            '====================================================
    '            TotalGasFlowOnline.Text = ""
    '            TotalGasFlowCalculated.Text = ""
    '            TotalGasFlowRecommended.Text = ""
    '            '========================================================
    '            TotalAirFlowOnline.Text = ""
    '            TotalAirFlowCalculated.Text = ""
    '            TotalAirFlowRecommended.Text = ""

    '        End If
    '    End If


    '    If Session("ActiveIndex") = 1 Then
    '        MultiView1.ActiveViewIndex = 1
    '    End If

    'End Sub

    Protected Sub btn2DView_Click(sender As Object, e As EventArgs) Handles btn2DView.Click
        MultiView1.ActiveViewIndex = 0
        Session("ActiveIndex") = 0
        Try

            'Dim dSdate As DataSet = objdatahandler.GetDataSetFromQuery("select max(datetime) as DATETIME FROM  [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]")
            'Dim dtdate As DataTable = dSdate.Tables(0)

            Dim dSdate As DataTable = objController.PopulateMaxDatetime()

            'Dim dSdate As DataSet = objdatahandler.GetDataSetFromQuery("select max(datetime) as DATETIME FROM  [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]")

            '  Dim dtdate As DataTable = dSdate.Tables(0)
            Dim dtdate As DataTable = dSdate


            Dim ddtdate As DateTime = dtdate.Rows(0)("DATETIME")
            Dim frmDate As String = ddtdate.ToString("yyyy-MM-dd HH:mm:ss")
            Dim toDate As String = ddtdate.AddHours(-1).ToString("yyyy-MM-dd HH:mm:ss")
            Dim dt As DataTable = objController.PopulateDataForHeatDistributionModel()
            Dim dtlabel As DataTable = objController.populatelabelValue()
            '  Dim dtavg As DataTable = objController.PopulateAvgValuefromdt(frmDate, toDate)

            If rdbtnLineA.Checked = True Then
                Session("checkboxval") = "A"
                '  DrawChartTop()
                lblforgrid_indicator.Text = "Table Grid Show LineA Values"
                If dt.Rows.Count > 0 Then
                    'txtHeatRecover1.Text = dt.Rows(0)("HEAT_RECOV1")
                    btnHeatRecover1.Text = dt.Rows(0)("HEAT_RECOV1") & "%"
                    'txtHeatRecover2.Text = dt.Rows(0)("HEAT_RECOV2")
                    btnHeatRecover2.Text = dt.Rows(0)("HEAT_RECOV2") & "%"
                    'txtHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3")
                    btnHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3") & "%"
                    'txtRecup1.Text = dt.Rows(0)("RECUP1_PERFORM")
                    btnRecup1.Text = dt.Rows(0)("RECUP1_PERFORM") & "%"
                    'txtRecup2.Text = dt.Rows(0)("RECUP2_PERFORM")
                    btnRecup2.Text = dt.Rows(0)("RECUP2_PERFORM") & "%"
                    'txtRecup3.Text = dt.Rows(0)("RECUP3_PERFORM")
                    btnRecup3.Text = dt.Rows(0)("RECUP3_PERFORM") & "%"
                    'txtHeatInput.Text = dt.Rows(0)("HEAT_INPUT")
                    btnHeatInput.Text = dt.Rows(0)("HEAT_INPUT") & ""
                    'txtThroughPut.Text = dt.Rows(0)("THROUGHPUT")


                    btnThroughPut.Text = dt.Rows(0)("THROUGHPUT")
                    'txtStockEntryTemp.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
                    btnStockEntryTemp.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
                    'txtStockExitTemp.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
                    btnStockExitTemp.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
                    'txtCoolingWaterLoss.Text = dt.Rows(0)("COOL_WT_LOSS")
                    btnCoolingWaterLoss.Text = dt.Rows(0)("COOL_WT_LOSS")
                    btnCoolingWaterLossPerc.Text = dt.Rows(0)("COOL_WT_LOSS_PERC") & "%"
                    'txtFuelLoss.Text = dt.Rows(0)("FLUE_LOSS_PERC")

                    btnFuelLossPerc.Text = dt.Rows(0)("FLUE_LOSS_PERC") & "%"
                    'txtHeatMaterial.Text = dt.Rows(0)("HEAT_MATERIAL")
                    btnHeatMaterial.Text = dt.Rows(0)("HEAT_MATERIAL")
                    btnHeatMaterialPerc.Text = dt.Rows(0)("HEAT_MAT_PERC") & "%"
                    'txtOpenLoss.Text = dt.Rows(0)("OPEN_LOSS")
                    btnOpenLoss.Text = dt.Rows(0)("OPEN_LOSS")
                    btnOpenLossPerc.Text = dt.Rows(0)("OPEN_LOSS_PERC") & "%"
                    'txtWallRoofLoss.Text = dt.Rows(0)("SKIN_LOSS_PERC")

                    btnWallRoofLossPerc.Text = dt.Rows(0)("SKIN_LOSS_PERC") & "%"
                    'txtAirFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_CAL")
                    btnAirFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
                    'txtGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_CAL")
                    btnGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
                    'txtCV.Text = dt.Rows(0)("CV")
                    btnCV.Text = dt.Rows(0)("CV")
                Else



                    'txtHeatRecover1.Text = dt.Rows(0)("HEAT_RECOV1")
                    btnHeatRecover1.Text = ""
                    'txtHeatRecover2.Text = dt.Rows(0)("HEAT_RECOV2")
                    btnHeatRecover2.Text = ""
                    'txtHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3")
                    btnHeatRecover3.Text = ""
                    'txtRecup1.Text = dt.Rows(0)("RECUP1_PERFORM")
                    btnRecup1.Text = ""
                    'txtRecup2.Text = dt.Rows(0)("RECUP2_PERFORM")
                    btnRecup2.Text = ""
                    'txtRecup3.Text = dt.Rows(0)("RECUP3_PERFORM")
                    btnRecup3.Text = ""
                    'txtHeatInput.Text = dt.Rows(0)("HEAT_INPUT")
                    btnHeatInput.Text = ""
                    'txtThroughPut.Text = dt.Rows(0)("THROUGHPUT")


                    btnThroughPut.Text = ""
                    'txtStockEntryTemp.Text = dt.Rows(0)("STOCK_ENTRY_TEMP")
                    btnStockEntryTemp.Text = ""
                    'txtStockExitTemp.Text = dt.Rows(0)("STOCK_EXIT_TEMP")
                    btnStockExitTemp.Text = ""
                    'txtCoolingWaterLoss.Text = dt.Rows(0)("COOL_WT_LOSS")
                    btnCoolingWaterLoss.Text = ""
                    btnCoolingWaterLossPerc.Text = ""
                    'txtFuelLoss.Text = dt.Rows(0)("FLUE_LOSS_PERC")

                    btnFuelLossPerc.Text = ""
                    'txtHeatMaterial.Text = dt.Rows(0)("HEAT_MATERIAL")
                    btnHeatMaterial.Text = ""
                    btnHeatMaterialPerc.Text = ""
                    'txtOpenLoss.Text = dt.Rows(0)("OPEN_LOSS")
                    btnOpenLoss.Text = ""
                    btnOpenLossPerc.Text = ""
                    'txtWallRoofLoss.Text = dt.Rows(0)("SKIN_LOSS_PERC")

                    btnWallRoofLossPerc.Text = ""
                    'txtAirFlow.Text = dt.Rows(0)("TOTAL_AIR_FLOW_CAL")
                    btnAirFlow.Text = ""
                    'txtGasFlow.Text = dt.Rows(0)("TOTAL_GAS_FLOW_CAL")
                    btnGasFlow.Text = ""
                    'txtCV.Text = dt.Rows(0)("CV")
                    btnCV.Text = ""
                End If

                'Dim dtlabel As DataTable = objController.populatelabelValue()
                If dtlabel.Rows.Count > 0 Then

                    'If dtavg.Rows.Count > 0 Then
                    '    Dim AvgData = ""
                    '    Dim arrYValues(dtavg.Rows.Count) As Decimal
                    '    '  arrYValues = (From row In dtlabel Select col = Decimal.Parse(row(Trim("SPC_FUEL_CON_ONLINE"))) Where "DATETIME" >= DateAdd(DateInterval.Hour, -1, DateTime.Now)) '.ToArray

                    '    arrYValues = dtavg.AsEnumerable.Where(Function(r) r.Field(Of DateTime)("Datetime") > DateTime.Now.AddHours(-1)).Select(Function(x) x.Field(Of Decimal)("SPC_FUEL_CON_ONLINE")).ToArray
                    '    'arrYValues = (From row In dtlabel Select col = Decimal.Parse(row(Trim("SPC_FUEL_CON_ONLINE")).ToString()) Where DateTime > DateAdd(Hour, -1, GETDATE())).ToArray


                    '    Array.Sort(arrYValues)
                    '    AvgData = arrYValues.Average

                    '    Dim d As Double
                    '    'd = Math.Round(AvgData, 2)

                    '    d = AvgData
                    '    avgButtonOnline.Text = Math.Round(d, 3)
                    'Else
                    '    avgButtonOnline.Text = ""
                    'End If


                    BaseValueOnline.Text = dtlabel.Rows(0)("TOTAL_AIR_FUEL_RATIO")
                    BaseValueRecommended.Text = dtlabel.Rows(0)("BASE_VALUE_RECOM")
                    '=================================================
                    '   HeatInputOnline.Text = dtlabel.Rows(0)("HEAT_INPUT")
                    HeatInputCalculated.Text = dtlabel.Rows(0)("HEAT_INPUT")
                    HeatInputRecommended.Text = dtlabel.Rows(0)("HEAT_INPUT_RECOM")
                    '====================================================
                    SpecificationOnline.Text = dtlabel.Rows(0)("SPC_FUEL_CON_ONLINE")
                    SpecificationCalculated.Text = dtlabel.Rows(0)("SPC_FUEL_CON_CAL")
                    SpecificationRecommended.Text = dtlabel.Rows(0)("SPEC_FUEL_CON_RECOM")
                    '====================================================
                    TotalGasFlowOnline.Text = dtlabel.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
                    TotalGasFlowCalculated.Text = dtlabel.Rows(0)("TOTAL_GAS_FLOW_CAL")
                    TotalGasFlowRecommended.Text = dtlabel.Rows(0)("TOTAL_GAS_FLOW_RECOM")
                    '========================================================
                    TotalAirFlowOnline.Text = dtlabel.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
                    TotalAirFlowCalculated.Text = dtlabel.Rows(0)("TOTAL_AIR_FLOW_CAL")
                    TotalAirFlowRecommended.Text = dtlabel.Rows(0)("TOTAL_AIR_FLOW_RECOM")
                Else
                    BaseValueOnline.Text = ""
                    BaseValueRecommended.Text = ""
                    '=================================================
                    '   HeatInputOnline.Text = dtlabel.Rows(0)("HEAT_INPUT")
                    HeatInputCalculated.Text = ""
                    HeatInputRecommended.Text = ""
                    '====================================================
                    SpecificationOnline.Text = ""
                    SpecificationCalculated.Text = ""
                    SpecificationRecommended.Text = ""
                    '====================================================
                    TotalGasFlowOnline.Text = ""
                    TotalGasFlowCalculated.Text = ""
                    TotalGasFlowRecommended.Text = ""
                    '========================================================
                    TotalAirFlowOnline.Text = ""
                    TotalAirFlowCalculated.Text = ""
                    TotalAirFlowRecommended.Text = ""
                End If

            End If
        Catch ex As Exception

        End Try




        If rdbtnLineB.Checked = True Then
            'MultiView1.ActiveViewIndex = 1
            Try

                'Dim dSdate As DataSet = objdatahandler.GetDataSetFromQuery("select max(datetime) as DATETIME FROM  [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]")
                'Dim dtdate As DataTable = dSdate.Tables(0)

                Dim dSdate As DataTable = objController.PopulateMaxDatetime()

                'Dim dSdate As DataSet = objdatahandler.GetDataSetFromQuery("select max(datetime) as DATETIME FROM  [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]")

                '  Dim dtdate As DataTable = dSdate.Tables(0)
                Dim dtdate As DataTable = dSdate


                Dim ddtdate As DateTime = dtdate.Rows(0)("DATETIME")
                Dim frmDate As String = ddtdate.ToString("yyyy-MM-dd HH:mm:ss")
                Dim toDate As String = ddtdate.AddHours(-1).ToString("yyyy-MM-dd HH:mm:ss")
                '===========lineb=====================
                Dim dtlineB As DataTable = objController.PopulateDataForHeatDistributionModelFORLINEB()
                Dim dtlabelLineB As DataTable = objController.populatelabelValueFORLINEB()
                ' Dim dtavg As DataTable = objController.PopulateAvgValuefromdt(frmDate, toDate)
                '  Dim dtavglineb As DataTable = objController.PopulateAvgValuefromdtLineb(frmDate, toDate)
                Dim dtavglineb As DataTable = objController.populatelabelValueForAvgLineB(frmDate, toDate)


                Session("checkboxval") = "B"
                '  DrawChartTop()
                lblforgrid_indicator.Text = "Table Grid Show LineB Values"
                If dtlineB.Rows.Count > 0 Then
                    'txtHeatRecover1.Text = dtlineB.Rows(0)("HEAT_RECOV1")
                    btnHeatRecover1.Text = dtlineB.Rows(0)("HEAT_RECOV1") & "%"
                    'txtHeatRecover2.Text = dtlineB.Rows(0)("HEAT_RECOV2")
                    btnHeatRecover2.Text = dtlineB.Rows(0)("HEAT_RECOV2") & "%"
                    'txtHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3")
                    btnHeatRecover3.Text = dtlineB.Rows(0)("HEAT_RECOV3") & "%"
                    'txtRecup1.Text = dtlineB.Rows(0)("RECUP1_PERFORM")
                    btnRecup1.Text = dtlineB.Rows(0)("RECUP1_PERFORM") & "%"
                    'txtRecup2.Text = dtlineB.Rows(0)("RECUP2_PERFORM")
                    btnRecup2.Text = dtlineB.Rows(0)("RECUP2_PERFORM") & "%"
                    'txtRecup3.Text = dtlineB.Rows(0)("RECUP3_PERFORM")
                    btnRecup3.Text = dtlineB.Rows(0)("RECUP3_PERFORM") & "%"
                    'txtHeatInput.Text = dtlineB.Rows(0)("HEAT_INPUT")
                    btnHeatInput.Text = dtlineB.Rows(0)("HEAT_INPUT") & ""
                    'txtThroughPut.Text = dtlineB.Rows(0)("THROUGHPUT")


                    btnThroughPut.Text = dtlineB.Rows(0)("THROUGHPUT")
                    'txtStockEntryTemp.Text = dtlineB.Rows(0)("STOCK_ENTRY_TEMP")
                    btnStockEntryTemp.Text = dtlineB.Rows(0)("STOCK_ENTRY_TEMP")
                    'txtStockExitTemp.Text = dtlineB.Rows(0)("STOCK_EXIT_TEMP")
                    btnStockExitTemp.Text = dtlineB.Rows(0)("STOCK_EXIT_TEMP")
                    'txtCoolingWaterLoss.Text = dtlineB.Rows(0)("COOL_WT_LOSS")
                    btnCoolingWaterLoss.Text = dtlineB.Rows(0)("COOL_WT_LOSS")
                    btnCoolingWaterLossPerc.Text = dtlineB.Rows(0)("COOL_WT_LOSS_PERC") & "%"
                    'txtFuelLoss.Text = dtlineB.Rows(0)("FLUE_LOSS_PERC")

                    btnFuelLossPerc.Text = dtlineB.Rows(0)("FLUE_LOSS_PERC") & "%"
                    'txtHeatMaterial.Text = dtlineB.Rows(0)("HEAT_MATERIAL")
                    btnHeatMaterial.Text = dtlineB.Rows(0)("HEAT_MATERIAL")
                    btnHeatMaterialPerc.Text = dtlineB.Rows(0)("HEAT_MAT_PERC") & "%"
                    'txtOpenLoss.Text = dtlineB.Rows(0)("OPEN_LOSS")
                    btnOpenLoss.Text = dtlineB.Rows(0)("OPEN_LOSS")
                    btnOpenLossPerc.Text = dtlineB.Rows(0)("OPEN_LOSS_PERC") & "%"
                    'txtWallRoofLoss.Text = dtlineB.Rows(0)("SKIN_LOSS_PERC")

                    btnWallRoofLossPerc.Text = dtlineB.Rows(0)("SKIN_LOSS_PERC") & "%"
                    'txtAirFlow.Text = dtlineB.Rows(0)("TOTAL_AIR_FLOW_CAL")
                    btnAirFlow.Text = dtlineB.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
                    'txtGasFlow.Text = dtlineB.Rows(0)("TOTAL_GAS_FLOW_CAL")
                    btnGasFlow.Text = dtlineB.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
                    'txtCV.Text = dtlineB.Rows(0)("CV")
                    btnCV.Text = dtlineB.Rows(0)("CV")
                Else

                    btnHeatRecover1.Text = " "
                    'txtHeatRecover2.Text = dtlineB.Rows(0)("HEAT_RECOV2")
                    btnHeatRecover2.Text = " "
                    'txtHeatRecover3.Text = dt.Rows(0)("HEAT_RECOV3")
                    btnHeatRecover3.Text = " "
                    'txtRecup1.Text = dtlineB.Rows(0)("RECUP1_PERFORM")
                    btnRecup1.Text = " "
                    'txtRecup2.Text = dtlineB.Rows(0)("RECUP2_PERFORM")
                    btnRecup2.Text = " "
                    'txtRecup3.Text = dtlineB.Rows(0)("RECUP3_PERFORM")
                    btnRecup3.Text = " "
                    'txtHeatInput.Text = dtlineB.Rows(0)("HEAT_INPUT")
                    btnHeatInput.Text = ""
                    'txtThroughPut.Text = dtlineB.Rows(0)("THROUGHPUT")


                    btnThroughPut.Text = ""
                    'txtStockEntryTemp.Text = dtlineB.Rows(0)("STOCK_ENTRY_TEMP")
                    btnStockEntryTemp.Text = ""
                    'txtStockExitTemp.Text = dtlineB.Rows(0)("STOCK_EXIT_TEMP")
                    btnStockExitTemp.Text = ""
                    'txtCoolingWaterLoss.Text = dtlineB.Rows(0)("COOL_WT_LOSS")
                    btnCoolingWaterLoss.Text = ""
                    btnCoolingWaterLossPerc.Text = ""
                    'txtFuelLoss.Text = dtlineB.Rows(0)("FLUE_LOSS_PERC")

                    btnFuelLossPerc.Text = ""
                    'txtHeatMaterial.Text = dtlineB.Rows(0)("HEAT_MATERIAL")
                    btnHeatMaterial.Text = ""
                    btnHeatMaterialPerc.Text = ""
                    'txtOpenLoss.Text = dtlineB.Rows(0)("OPEN_LOSS")
                    btnOpenLoss.Text = ""
                    btnOpenLossPerc.Text = ""
                    'txtWallRoofLoss.Text = dtlineB.Rows(0)("SKIN_LOSS_PERC")

                    btnWallRoofLossPerc.Text = ""
                    'txtAirFlow.Text = dtlineB.Rows(0)("TOTAL_AIR_FLOW_CAL")
                    btnAirFlow.Text = ""
                    'txtGasFlow.Text = dtlineB.Rows(0)("TOTAL_GAS_FLOW_CAL")
                    btnGasFlow.Text = ""
                    'txtCV.Text = dtlineB.Rows(0)("CV")
                    btnCV.Text = ""
                End If





                'Dim dtlabel As DataTable = objController.populatelabelValue()
                If dtlabelLineB.Rows.Count > 0 Then

                    'If dtavglineb.Rows.Count > 0 Then
                    '    Dim AvgData = ""
                    '    Dim arrYValues(dtavglineb.Rows.Count) As Decimal
                    '    '  arrYValues = (From row In dtlabel Select col = Decimal.Parse(row(Trim("SPC_FUEL_CON_ONLINE"))) Where "DATETIME" >= DateAdd(DateInterval.Hour, -1, DateTime.Now)) '.ToArray

                    '    arrYValues = dtavglineb.AsEnumerable.Where(Function(r) r.Field(Of DateTime)("Datetime") > DateTime.Now.AddHours(-1)).Select(Function(x) x.Field(Of Decimal)("SPC_FUEL_CON_ONLINE")).ToArray
                    '    'arrYValues = (From row In dtlabel Select col = Decimal.Parse(row(Trim("SPC_FUEL_CON_ONLINE")).ToString()) Where DateTime > DateAdd(Hour, -1, GETDATE())).ToArray


                    '    Array.Sort(arrYValues)
                    '    AvgData = arrYValues.Average

                    '    Dim d As Double
                    '    'd = Math.Round(AvgData, 2)

                    '    d = AvgData
                    '    avgButtonOnline.Text = Math.Round(d, 3)
                    'Else
                    '    avgButtonOnline.Text = ""
                    'End If


                    BaseValueOnline.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FUEL_RATIO")
                    BaseValueRecommended.Text = dtlabelLineB.Rows(0)("BASE_VALUE_RECOM")
                    '=================================================
                    '   HeatInputOnline.Text = dtlabelLineB.Rows(0)("HEAT_INPUT")
                    HeatInputCalculated.Text = dtlabelLineB.Rows(0)("HEAT_INPUT")
                    HeatInputRecommended.Text = dtlabelLineB.Rows(0)("HEAT_INPUT_RECOM")
                    '====================================================
                    SpecificationOnline.Text = dtlabelLineB.Rows(0)("SPC_FUEL_CON_ONLINE")
                    SpecificationCalculated.Text = dtlabelLineB.Rows(0)("SPC_FUEL_CON_CAL")
                    SpecificationRecommended.Text = dtlabelLineB.Rows(0)("SPEC_FUEL_CON_RECOM")
                    '====================================================
                    TotalGasFlowOnline.Text = dtlabelLineB.Rows(0)("TOTAL_GAS_FLOW_ONLINE")
                    TotalGasFlowCalculated.Text = dtlabelLineB.Rows(0)("TOTAL_GAS_FLOW_CAL")
                    TotalGasFlowRecommended.Text = dtlabelLineB.Rows(0)("TOTAL_GAS_FLOW_RECOM")
                    '========================================================
                    TotalAirFlowOnline.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FLOW_ONLINE")
                    TotalAirFlowCalculated.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FLOW_CAL")
                    TotalAirFlowRecommended.Text = dtlabelLineB.Rows(0)("TOTAL_AIR_FLOW_RECOM")


                Else
                    BaseValueOnline.Text = ""
                    BaseValueRecommended.Text = ""
                    '=================================================
                    '   HeatInputOnline.Text = dtlabelLineB.Rows(0)("HEAT_INPUT")
                    HeatInputCalculated.Text = ""
                    HeatInputRecommended.Text = ""
                    '====================================================
                    SpecificationOnline.Text = ""
                    SpecificationCalculated.Text = ""
                    SpecificationRecommended.Text = ""
                    '====================================================
                    TotalGasFlowOnline.Text = ""
                    TotalGasFlowCalculated.Text = ""
                    TotalGasFlowRecommended.Text = ""
                    '========================================================
                    TotalAirFlowOnline.Text = ""
                    TotalAirFlowCalculated.Text = ""
                    TotalAirFlowRecommended.Text = ""

                End If








            Catch ex As Exception

            End Try
        End If
        'rdbtnLineB_CheckedChanged()

    End Sub

    'Protected Sub btnSanky_Click(sender As Object, e As EventArgs) Handles btnSanky.Click
    '    MultiView1.ActiveViewIndex = 1
    '    Session("ActiveIndex") = 1
    'End Sub

    Protected Sub btnTCZoneTemp_Click(sender As Object, e As EventArgs) Handles btnTCZoneTemp.Click
        MultiView1.ActiveViewIndex = 1
        Session("ActiveIndex") = 1
    End Sub
    Protected Sub btnChartAndAnalysis_Click(sender As Object, e As EventArgs) Handles btnChartAndAnalysis.Click
        'MultiView1.ActiveViewIndex = 1
        'Session("ActiveIndex") = 1
        Response.Redirect("Furnace_Equipment_Tracker.aspx")
    End Sub

    '===================Picture label ========================================================
    Private Sub btnHeatRecover1_click(sender As System.Object, e As System.EventArgs) Handles btnHeatRecover1.Click
        Session("checkLineChartParameters") = "HEAT_RECOV1"
        Dim url As String = "LineChart.aspx"
        'btnHeatRecover1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Private Sub btnHeatRecover2_click(sender As System.Object, e As System.EventArgs) Handles btnHeatRecover2.Click
        Session("checkLineChartParameters") = "HEAT_RECOV2"
        Dim url As String = "LineChart.aspx"
        'btnHeatRecover2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Private Sub btnHeatRecover3_click(sender As System.Object, e As System.EventArgs) Handles btnHeatRecover3.Click
        Session("checkLineChartParameters") = "HEAT_RECOV3"
        Dim url As String = "LineChart.aspx"
        'btnHeatRecover3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub

    Private Sub btnRecup1_click(sender As System.Object, e As System.EventArgs) Handles btnRecup1.Click
        Session("checkLineChartParameters") = "RECUP1_PERFORM"
        Dim url As String = "LineChart.aspx"
        'btnRecup1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Private Sub btnRecup2_click(sender As System.Object, e As System.EventArgs) Handles btnRecup2.Click
        Session("checkLineChartParameters") = "RECUP2_PERFORM"
        Dim url As String = "LineChart.aspx"
        'btnRecup2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub

    Private Sub btnRecup3_click(sender As System.Object, e As System.EventArgs) Handles btnRecup3.Click
        Session("checkLineChartParameters") = "RECUP3_PERFORM"
        Dim url As String = "LineChart.aspx"
        'btnRecup3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub

    Private Sub btnHeatInput_click(sender As System.Object, e As System.EventArgs) Handles btnHeatInput.Click
        Session("checkLineChartParameters") = "HEAT_INPUT"
        Dim url As String = "LineChart.aspx"
        'btnHeatInput.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Private Sub btnThroughPut_click(sender As System.Object, e As System.EventArgs) Handles btnThroughPut.Click
        Session("checkLineChartParameters") = "THROUGHPUT"
        Dim url As String = "LineChart.aspx"
        'btnThroughPut.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub

    Private Sub btnStockEntryTemp_click(sender As System.Object, e As System.EventArgs) Handles btnStockEntryTemp.Click
        Session("checkLineChartParameters") = "STOCK_ENTRY_TEMP"
        Dim url As String = "LineChart.aspx"
        'btnStockEntryTemp.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Private Sub btnStockExitTemp_click(sender As System.Object, e As System.EventArgs) Handles btnStockExitTemp.Click
        Session("checkLineChartParameters") = "STOCK_EXIT_TEMP"
        Dim url As String = "LineChart.aspx"
        'btnStockExitTemp.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Private Sub btnCoolingWaterLoss_click(sender As System.Object, e As System.EventArgs) Handles btnCoolingWaterLoss.Click
        Session("checkLineChartParameters") = "COOL_WT_LOSS"
        Dim url As String = "LineChart.aspx"
        'btnCoolingWaterLoss.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Private Sub btnCoolingWaterLossPerc_click(sender As System.Object, e As System.EventArgs) Handles btnCoolingWaterLossPerc.Click
        Session("checkLineChartParameters") = "COOL_WT_LOSS_PERC"
        Dim url As String = "LineChart.aspx"
        'btnCoolingWaterLossPerc.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Private Sub btnFuelLossPerc_click(sender As System.Object, e As System.EventArgs) Handles btnFuelLossPerc.Click
        Session("checkLineChartParameters") = "FLUE_LOSS_PERC"
        Dim url As String = "LineChart.aspx"
        'btnFuelLossPerc.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Private Sub btnHeatMaterial_click(sender As System.Object, e As System.EventArgs) Handles btnHeatMaterial.Click
        Session("checkLineChartParameters") = "HEAT_MATERIAL"
        Dim url As String = "LineChart.aspx"
        'btnHeatMaterial.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Private Sub btnHeatMaterialPerc_click(sender As System.Object, e As System.EventArgs) Handles btnHeatMaterialPerc.Click
        Session("checkLineChartParameters") = "HEAT_MAT_PERC"
        Dim url As String = "LineChart.aspx"
        'btnHeatMaterialPerc.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Private Sub btnOpenLoss_click(sender As System.Object, e As System.EventArgs) Handles btnOpenLoss.Click
        Session("checkLineChartParameters") = "OPEN_LOSS"
        Dim url As String = "LineChart.aspx"
        'btnOpenLoss.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Private Sub btnOpenLossPerc_click(sender As System.Object, e As System.EventArgs) Handles btnOpenLossPerc.Click
        Session("checkLineChartParameters") = "OPEN_LOSS_PERC"
        Dim url As String = "LineChart.aspx"
        'btnOpenLossPerc.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Private Sub btnWallRoofLossPerc_click(sender As System.Object, e As System.EventArgs) Handles btnWallRoofLossPerc.Click
        Session("checkLineChartParameters") = "SKIN_LOSS_PERC"
        Dim url As String = "LineChart.aspx"
        'btnWallRoofLossPerc.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Private Sub btnAirFlow_click(sender As System.Object, e As System.EventArgs) Handles btnAirFlow.Click
        Session("checkLineChartParameters") = "TOTAL_AIR_FLOW_ONLINE" '"TOTAL_AIR_FLOW_CAL"
        Dim url As String = "LineChart.aspx"
        'btnAirFlow.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Private Sub btnGasFlow_click(sender As System.Object, e As System.EventArgs) Handles btnGasFlow.Click
        Session("checkLineChartParameters") = "TOTAL_GAS_FLOW_ONLINE" '"TOTAL_GAS_FLOW_CAL"
        Dim url As String = "LineChart.aspx"
        'btnGasFlow.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Private Sub btnCV_click(sender As System.Object, e As System.EventArgs) Handles btnCV.Click
        Session("checkLineChartParameters") = "CV"
        Dim url As String = "LineChart.aspx"
        'btnCV.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub

    '=============================================================================================================



    'Private Sub BaseValueCalculated_Click(sender As System.Object, e As System.EventArgs) Handles BaseValueCalculated.Click

    '    Dim url As String = "BaseValueCal.aspx"
    '    BaseValueCalculated.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
    'End Sub

    Private Sub BaseValueOnline_Click(sender As System.Object, e As System.EventArgs) Handles BaseValueOnline.Click

        Dim url As String = "BaseValueCal.aspx"
        'BaseValueOnline.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub

    Protected Sub BaseValueRecommended_Click(sender As Object, e As EventArgs) Handles BaseValueRecommended.Click
        Dim url As String = "BasicRecom_Value.aspx"
        'BaseValueRecommended.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub BaseValue_Click(sender As Object, e As EventArgs) Handles BaseValue.Click
        Dim url As String = "Basic_Value_Ratio.aspx"
        'BaseValue.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub Heat_Input_Click(sender As Object, e As EventArgs) Handles Heat_Input.Click
        Dim url As String = "Heat_Input.aspx"
        'Heat_Input.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub

    Protected Sub HeatInputCalculated_Click(sender As Object, e As EventArgs) Handles HeatInputCalculated.Click
        Dim url As String = "HeatValueCal.aspx"
        'HeatInputCalculated.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub HeatInputRecommended_Click(sender As Object, e As EventArgs) Handles HeatInputRecommended.Click
        Dim url As String = "Heat_Value_Recomm.aspx"
        'HeatInputRecommended.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub Specification_fuel_Click(sender As Object, e As EventArgs) Handles Specification_fuel.Click
        Dim url As String = "Specification_Fuel_Con.aspx"
        'Specification_fuel.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub

    Protected Sub SpecificationOnline_Click(sender As Object, e As EventArgs) Handles SpecificationOnline.Click
        Dim url As String = "Specification_Online.aspx"
        'SpecificationOnline.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub SpecificationCalculated_Click(sender As Object, e As EventArgs) Handles SpecificationCalculated.Click
        Dim url As String = "Specification_Cal.aspx"
        SpecificationCalculated.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub

    Protected Sub SpecificationRecommended_Click(sender As Object, e As EventArgs) Handles SpecificationRecommended.Click
        Dim url As String = "Specification_Recomm.aspx"
        'SpecificationRecommended.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub Total_Gas_Flow_Click(sender As Object, e As EventArgs) Handles Total_Gas_Flow.Click
        Dim url As String = "Total_Gas_Flow_Value.aspx"
        'Total_Gas_Flow.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub TotalGasFlowOnline_Click(sender As Object, e As EventArgs) Handles TotalGasFlowOnline.Click
        Dim url As String = "Total_Gas_Flow_Online.aspx"
        'TotalGasFlowOnline.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub TotalGasFlowCalculated_Click(sender As Object, e As EventArgs) Handles TotalGasFlowCalculated.Click
        Dim url As String = "Total_Gas_Flow_Cal.aspx"
        'TotalGasFlowCalculated.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub TotalGasFlowRecommended_Click(sender As Object, e As EventArgs) Handles TotalGasFlowRecommended.Click
        Dim url As String = "Total_Gas_Flow_Recomm.aspx"
        'TotalGasFlowRecommended.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub Total_Air_Flow_Click(sender As Object, e As EventArgs) Handles Total_Air_Flow.Click
        Dim url As String = "Total_Air_Flow_Val.aspx"
        'Total_Air_Flow.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub TotalAirFlowOnline_Click(sender As Object, e As EventArgs) Handles TotalAirFlowOnline.Click
        Dim url As String = "Total_Air_Flow_Online.aspx"
        'TotalAirFlowOnline.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub TotalAirFlowCalculated_Click(sender As Object, e As EventArgs) Handles TotalAirFlowCalculated.Click
        Dim url As String = "Total_Air_Flow_Cal.aspx"
        'TotalAirFlowCalculated.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub TotalAirFlowRecommended_Click(sender As Object, e As EventArgs) Handles TotalAirFlowRecommended.Click
        Dim url As String = "Total_Air_Flow_Recomm.aspx"
        'TotalAirFlowRecommended.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    ''''''''''''''''''''''''''''''''''''''BAR GRAPH Specific and Troughput''''''''''''''''''''''''''''''''''''''''''''''''''



    Sub DrawChartTop()
        Try

            Dim SELECT_LINE As String = Session("checkboxval")

            Dim dstemp As DataSet = objController.GetDataForSpecific_throughput(SELECT_LINE)
            ' objController.PopulateDataForHeatDistributionModel()

            ' Dim dstemp As DataSet = objController.GetDataForthisDateMonth(SELECT_LINE)
            PlotBarGraphSpecific_troughput(dstemp.Tables(0), Litral1, "container1", "plot1")



        Catch ex As Exception
            Throw ex
        End Try
    End Sub


    Sub DrawChartThisMonth()
        Try

            '  Dim frmDate As String = DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 6, 0, 0)
            Dim frmDate As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            Dim toDate As String = DateTime.Now.AddMonths(0).ToString("yyyy-MM-dd HH:mm:ss")

            Dim strfrmDt As String = frmDate
            Dim strToDt As String = toDate
            Dim SELECT_LINE As String = Session("checkboxval")

            Dim dstemp As DataSet = objController.GetDataForthisDateMonth(SELECT_LINE) 'frmDate, toDate(02/11/2021)
            ' objController.PopulateDataForHeatDistributionModel()
            dstemp.Tables(0).DefaultView.Sort = "Datetime ASC"
            ' Dim dt As DataTable = dstemp.Tables(0)

            PlotBarGraphSpecific_troughput(dstemp.Tables(0), Litral1, "container1", "plot1")



        Catch ex As Exception
            Throw ex
        End Try
    End Sub




    Sub DrawChartForLINEA()
        Try

            '  Dim frmDate As String = DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 6, 0, 0)
            Dim frmDate As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            Dim toDate As String = DateTime.Now.AddMonths(0).ToString("yyyy-MM-dd HH:mm:ss")

            Dim strfrmDt As String = frmDate
            Dim strToDt As String = toDate
            Dim SELECT_LINE As String = Session("checkboxval")
            ' If rbdChartLineA.Checked Then
            If rbdChartAvgValue.Checked Then
                Dim dstemp As DataSet = objController.GetDataForCHART_LINEA() 'frmDate, toDate(02/11/2021)
                PlotBarGraphSpecific_troughput(dstemp.Tables(0), Litral1, "container1", "plot1")
            End If
            If rbdChartthisMonthValue.Checked Then
                Dim dstemp As DataSet = objController.GetDataForCHART_LINEA_DAYWISE() 'frmDate, toDate(02/11/2021)
                PlotBarGraphSpecific_troughput(dstemp.Tables(0), Litral1, "container1", "plot1")
            End If


        Catch ex As Exception
            Throw ex
        End Try


    End Sub
    Sub DrawChartForLINEB()
        Try

            '  Dim frmDate As String = DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 6, 0, 0)
            Dim frmDate As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            Dim toDate As String = DateTime.Now.AddMonths(0).ToString("yyyy-MM-dd HH:mm:ss")

            Dim strfrmDt As String = frmDate
            Dim strToDt As String = toDate
            Dim SELECT_LINE As String = Session("checkboxval")

            '  Dim dstemp As DataSet = objController.GetDataForCHART_LINEB() 'frmDate, toDate(02/11/2021)

            '    PlotBarGraphSpecific_troughput(dstemp.Tables(0), Litral1, "container1", "plot1")
            If rbdChartAvgValue.Checked Then
                Dim dstemp As DataSet = objController.GetDataForCHART_LINEB() 'frmDate, toDate(02/11/2021)
                PlotBarGraphSpecific_troughput(dstemp.Tables(0), Litral1, "container1", "plot1")
            End If
            If rbdChartthisMonthValue.Checked Then
                Dim dstemp As DataSet = objController.GetDataForCHART_LINEB_DAYWISE() 'frmDate, toDate(02/11/2021)
                PlotBarGraphSpecific_troughput(dstemp.Tables(0), Litral1, "container1", "plot1")
            End If



        Catch ex As Exception
            Throw ex
        End Try


    End Sub


    'Sub DrawChartForLINEA_LINEB()
    '    Try

    '        '  Dim frmDate As String = DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 6, 0, 0)
    '        Dim frmDate As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
    '        Dim toDate As String = DateTime.Now.AddMonths(0).ToString("yyyy-MM-dd HH:mm:ss")

    '        Dim strfrmDt As String = frmDate
    '        Dim strToDt As String = toDate
    '        Dim SELECT_LINE As String = Session("checkboxval")

    '        'Dim dstemp As DataSet = objController.GetDataForCHART_LINEA_LINEB() 'frmDate, toDate(02/11/2021)

    '        'PlotBarGraphSpecific_troughput(dstemp.Tables(0), Litral1, "container1", "plot1")

    '        If rbdChartAvgValue.Checked Then
    '            Dim dstemp As DataSet = objController.GetDataForCHART_LINEA_LINEB() 'frmDate, toDate(02/11/2021)
    '            PlotBarGraphSpecific_troughput(dstemp.Tables(0), Litral1, "container1", "plot1")
    '        End If
    '        If rbdChartthisMonthValue.Checked Then
    '            Dim dstemp As DataSet = objController.GetDataForCHART_LINEA_LINEB_DAYWISE() 'frmDate, toDate(02/11/2021)
    '            PlotBarGraphSpecific_troughput(dstemp.Tables(0), Litral1, "container1", "plot1")
    '        End If



    '    Catch ex As Exception
    '        Throw ex
    '    End Try


    'End Sub
    Sub DrawChartForLINEA_LINEB()
        Try

            '  Dim frmDate As String = DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 6, 0, 0)
            Dim frmDate As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            'Dim toDate As String = DateTime.Now.AddMonths(0).ToString("yyyy-MM-dd HH:mm:ss")
            Dim Month As String = DateTime.Now.ToString("MM")
            Dim Year As String = DateTime.Now.ToString("yyyy")
            Dim firstdate As String = 1
            Dim toDate As String = Year & "-" & Month & "-" & firstdate

            Dim strfrmDt As String = frmDate
            Dim strToDt As String = toDate
            Dim SELECT_LINE As String = Session("checkboxval")

            'Dim dstemp As DataSet = objController.GetDataForCHART_LINEA_LINEB() 'frmDate, toDate(02/11/2021)

            'PlotBarGraphSpecific_troughput(dstemp.Tables(0), Litral1, "container1", "plot1")

            If rbdChartAvgValue.Checked Then
                Dim dstemp As DataSet = objController.GetDataForCHART_LINEA_LINEB()
                Dim dsspec As DataSet = objController.GetDataForCHART_LINEA_LINEBspec()

                'frmDate, toDate(02/11/2021)
                DATAWISE_Chart_spec_and_throughput(dstemp.Tables(0), dsspec.Tables(0), Litral1, "container1", "plot1")
            End If
            If rbdChartthisMonthValue.Checked Then
                Dim dstemp As DataSet = objController.GetDataForCHART_LINEA_LINEB_DAYWISE_Spec() 'frmDate, toDate(02/11/2021)
                Dim dtthroughput As DataSet = objController.GetDataForCHART_LINEA_LINEB_DAYWISE_throughput()
                DATAWISE_Chart_spec_and_throughput(dtthroughput.Tables(0), dstemp.Tables(0), Litral1, "container1", "plot1")
                ' PlotBarGraphSpecific_troughput(dstemp.Tables(0), Litral1, "container1", "plot1")
            End If



        Catch ex As Exception
            Throw ex
        End Try


    End Sub
    Public Sub DATAWISE_Chart_spec_and_throughput(ByVal dt As DataTable, ByVal dt1 As DataTable, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String)
        Try
            LiteralName.Text = ""
            Dim ticks As String

            ' dt.DefaultView.Sort = "DAY asc"
            Dim line1, line2, line3 As String
            For i As Integer = 0 To dt1.Rows.Count - 1
                If i > 0 Then
                    ticks &= ","
                    line1 &= ","
                    'line2 &= ","
                    'line3 &= ","
                End If
                ticks &= "'" & dt1.Rows(i)(0) & "'"
                If IsDBNull(dt1.Rows(i)(1)) Then
                    line1 &= 0
                Else
                    line1 &= dt1.Rows(i)(1)
                End If
            Next

            For i As Integer = 0 To dt.Rows.Count - 1
                If i > 0 Then
                    '  ticks &= ","
                    'line1 &= ","
                    line2 &= ","
                    'line3 &= ","
                End If
                'ticks &= "'" & dt.Rows(i)(0) & "'"
                ' ticks &= "'" & dt.Rows(i)(0) & "'"
                If IsDBNull(dt.Rows(i)(1)) Then
                    line2 &= 0
                Else
                    line2 &= dt.Rows(i)(1)
                End If

            Next


            ''''''''''''''''5% Less min and max shown below'''''''''''''''''''''''''''''''''''''''''
            'Dim yVal, yVal1 As Decimal()
            'Dim y_mint, y_maxt, y_mint1, y_maxt1 As String

            'yVal = (From row In dt Select col = CDec(row(1))).ToArray()
            'yVal1 = (From row In dt1 Select col = CDec(row(1))).ToArray()

            'y_mint = Math.Round(yVal.Min() - (5 / 100 * yVal.Min), 2).ToString()
            'y_maxt = Math.Round(yVal.Max() + (5 / 100 * yVal.Max), 2).ToString()

            'y_mint1 = (yVal1.Min() - (5 / 100 * yVal1.Min)).ToString()
            'y_maxt1 = (yVal1.Max() + (5 / 100 * yVal1.Max)).ToString()


            'Dim y_min As String
            'Dim y_max As String

            'If y_mint < y_mint1 Then
            '    y_min = y_mint
            'Else
            '    y_min = y_mint1
            'End If

            'If y_maxt > y_maxt1 Then
            '    y_max = y_maxt
            'Else
            '    y_max = y_maxt1
            'End If

            Dim s As New StringBuilder("<script>")

            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            s.Append("var myChart = echarts.init(document.getElementById('" & ContainerName & "'));")
            s.Append("option = {    tooltip: {   trigger: 'axis',  axisPointer: {   type: 'cross', crossStyle: {   color: '#999'  }  } },")
            s.Append("toolbox: {  feature: {  dataView: {show: true, readOnly: false},  magicType: {show: true, type: ['line', 'bar']},  restore: {show: true},  saveAsImage: {show: true}  }  },")
            s.Append("legend: {   data: ['Specific','Throughput'], left:'5%'  },")
            s.Append("xAxis: [ {  type: 'category',  data: [" & ticks & "],    axisPointer: { type: 'shadow'   }       }   ],   ")
            s.Append("yAxis: [  {   type: 'value', name: 'Specific',   min: 0,    max: 0.5,  axisLabel: {  formatter: '{value}'    }    },      {    type: 'value',         name: 'Throughput',      min: 0,        max: 500,    axisLabel: {            formatter: '{value}'        }        }   ],")
            's.Append("yAxis: [  {   type: 'value', name: 'Specific',   min: " & y_mint1 & ",    max: " & y_maxt1 & ",  axisLabel: {  formatter: '{value}'    }    },      {    type: 'value',         name: 'Throughput',      min: " & y_mint & ",        max: " & y_maxt & ",    axisLabel: {            formatter: '{value}'        }        }   ],")
            s.Append("series: [  {   name: 'Specific',  type: 'bar',  data: [" & line1 & "]  },   {           name: 'Throughput',           type: 'bar',    yAxisIndex: 1, data: [" & line2 & "]")
            s.Append("}   ]};")

            s.Append(" myChart.setOption(option);")
            s.Append("</script>")
            LiteralName.Text = s.ToString()
        Catch ex As Exception
            Dim i As String = ""

        End Try

    End Sub




    'Public Sub PlotBarGraphSpecific_troughput(ByVal dt As DataTable, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String)
    '    Try
    '        LiteralName.Text = ""

    '        Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
    '             "$.jqplot.config.enablePlugins = true;" & vbCrLf
    '        Dim ticks As String = "["
    '        Dim line1, line2, line3 As String
    '        line1 &= "["
    '        line2 &= "["
    '        line3 &= "["
    '        Dim labels As String = "['SPC_FUEL_CON_ONLINE','THROUGHPUT']"
    '        For i As Integer = 0 To dt.Rows.Count - 1
    '            If i > 0 Then
    '                ticks &= ","
    '                line1 &= ","
    '                line2 &= ","
    '                'line3 &= ","
    '            End If
    '            ticks &= "'" & dt.Rows(i)(0) & "'"
    '            If IsDBNull(dt.Rows(i)(1)) Then
    '                line1 &= 0
    '            Else
    '                line1 &= dt.Rows(i)(1)
    '            End If
    '            If IsDBNull(dt.Rows(i)(2)) Then
    '                line2 &= 0
    '            Else
    '                line2 &= dt.Rows(i)(2)
    '            End If

    '            'line3 &= dt.Rows(i)("plt3")

    '        Next
    '        ticks &= "]"
    '        line1 &= "]"
    '        line2 &= "]"
    '        line3 &= "]"

    '        js &= "var ticks=" & ticks & ";"
    '        js &= "var pl1=" & line1 & ";"
    '        js &= "var pl2=" & line2 & ";"
    '        'js &= "var pl3=" & line3 & ";"

    '        js &= "var " & PlotName & " = $.jqplot('" & ContainerName & "', [pl1,pl2], {"
    '        js &= " captureRightClick: true,highlighter: {show: true,tooltipContentEditor: function (str, seriesIndex, pointIndex, plot) {var html = '<div>Month: ' + plot.options.axes.xaxis.ticks[pointIndex] + '<br/>Data: ' + Math.round(plot.data[seriesIndex][pointIndex]); return html;}},"
    '        js &= "seriesDefaults:{renderer:$.jqplot.BarRenderer, rendererOptions: {barMargin: 10,highlightMouseDown: true},pointLabels: {show: false}},"
    '        js &= "  axesDefaults: { tickRenderer: $.jqplot.CanvasAxisTickRenderer, tickOptions: {  angle: 30,fontSize:   '10pt' } },"
    '        js &= "seriesColors:['#0B62A4','#B62455','#4DA74D'],"
    '        js &= "axes: {"
    '        js &= "xaxis: { renderer: $.jqplot.CategoryAxisRenderer,ticks: " & ticks & "  },"
    '        js &= "yaxis: { min: -1.999, label:'',labelRenderer: $.jqplot.CanvasAxisLabelRenderer },"
    '        js &= "},legend: {show: true, location: 's',labels:" & labels & ",renderer: $.jqplot.EnhancedLegendRenderer,placement:  'outside',placement: 'outsideGrid',rendererOptions:{numberColumns:3}}});"
    '        js &= "</script>"
    '        LiteralName.Text = js

    '    Catch ex As Exception
    '        Dim i As String = ""

    '    End Try

    'End Sub
    Public Sub PlotBarGraphSpecific_troughput(ByVal dt As DataTable, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String)
        Try
            LiteralName.Text = ""
            Dim ticks As String

            ' dt.DefaultView.Sort = "DAY asc"
            Dim line1, line2, line3 As String
            For i As Integer = 0 To dt.Rows.Count - 1
                If i > 0 Then
                    ticks &= ","
                    line1 &= ","
                    line2 &= ","
                    'line3 &= ","
                End If
                ticks &= "'" & dt.Rows(i)(0) & "'"
                If IsDBNull(dt.Rows(i)(1)) Then
                    line1 &= 0
                Else
                    line1 &= dt.Rows(i)(1)
                End If
                If IsDBNull(dt.Rows(i)(2)) Then
                    line2 &= 0
                Else
                    line2 &= dt.Rows(i)(2)
                End If

            Next

            Dim s As New StringBuilder("<script>")

            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            s.Append("var myChart = echarts.init(document.getElementById('" & ContainerName & "'));")
            s.Append("option = {    tooltip: {   trigger: 'axis',  axisPointer: {   type: 'cross', crossStyle: {   color: '#999'  }  } },")
            s.Append("toolbox: {  feature: {  dataView: {show: true, readOnly: false},  magicType: {show: true, type: ['line', 'bar']},  restore: {show: true},  saveAsImage: {show: true}  }  },")
            s.Append("legend: {   data: ['Specific','Throughput'], left:'5%'  },")
            s.Append("xAxis: [ {  type: 'category',  data: [" & ticks & "],    axisPointer: { type: 'shadow'   }       }   ],   ")
            s.Append("yAxis: [  {   type: 'value', name: 'Specific',   min: 0,    max: 0.5,  axisLabel: {  formatter: '{value}'    }    },      {    type: 'value',         name: 'Throughput',      min: 0,        max: 500,    axisLabel: {            formatter: '{value}'        }        }   ],")
            s.Append("series: [  {   name: 'Specific',  type: 'bar',  data: [" & line1 & "]  },   {           name: 'Throughput',           type: 'bar',    yAxisIndex: 1, data: [" & line2 & "]")
            s.Append("}   ]};")

            s.Append(" myChart.setOption(option);")
            s.Append("</script>")
            LiteralName.Text = s.ToString()
        Catch ex As Exception
            Dim i As String = ""

        End Try

    End Sub

    Sub GETSPEC_TOTAL(ByVal FromDt As String, ByVal ToDt As String)
        Dim enDate As String = ToDt
        Dim stDate As String = FromDt

        Dim query As String = "Select CONVERT(VARCHAR(10),datetime,120) as datetime, [PRODUCTION], [ON_DATE], [TO_DATE],TOTAL_GAS_CON FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY]  " &
                                   "where DATETIME between '" & stDate & "' and '" & enDate & "' and PRODUCTION = 'HRC'    order by DATETIME asc"

        Dim count As Short = 0
        Dim getdt As DataTable = getdatatable(query)








        Dim lfcdec_query As String = "SELECT CONVERT(VARCHAR(10),datetime,120) as datetime,   CAST(ROUND(avg(CV), 2) AS DECIMAL(10,2)) as cv FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]  Where  DATETIME between '" & stDate & "' and '" & enDate & "' and cv is not null group by CONVERT(VARCHAR(10),datetime,120) 	order by CONVERT(VARCHAR(10),datetime,120) asc"

        Dim decisiondt As DataTable = getdatatable(lfcdec_query)

        Dim min As String = ""
        Dim max As String = ""
        Try
            If getdt.Rows.Count > 0 Then

                If decisiondt.Rows.Count > 0 Then
                    Dim query1 As String = "Select CONVERT(VARCHAR(10),datetime,120) as datetime, [PRODUCTION], [ON_DATE], [TO_DATE],TOTAL_GAS_CON FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY]  " &
                                   "where DATETIME between '" & stDate & "' and '" & enDate & "'   and PRODUCTION ='HRC' order by DATETIME asc"
                    Dim HRC As DataTable = getdatatable(query1)

                    For j As Integer = 0 To getdt.Rows.Count - 1
                        Try
                            Dim row As DataRow = decisiondt.Select("datetime='" & getdt.Rows(j)(0) & "'")(0)


                            Dim HRCDT As DataRow = HRC.Select("datetime='" & getdt.Rows(j)(0) & "'")(0)

                            If IsDBNull(getdt.Rows.Item(j)(4)) Or IsDBNull(getdt.Rows.Item(j)(2)) Then 'or replace from and  and getdt.rows.item(j)(2) from getdt.rows.item(j)(4)


                                '  TOTAL_SPEC &= "'" & getdt.Rows(j)(0).ToString & "',"
                                TOTAL_SPEC &= 0 & ","

                            Else

                                ' TOTAL_SPEC &= "'" & getdt.Rows(j)(0).ToString & "',"
                                Dim valhrc As Decimal = ((getdt.Rows.Item(j)(4) * row.Item(1)) / ((HRCDT.Item(2)) * 1000000))
                                Dim spe_totalhrc As Decimal = FormatNumber(valhrc, 4)




                                TOTAL_SPEC &= spe_totalhrc & ","
                            End If
                            ' End If
                            count += 1
                        Catch ex As Exception

                            TOTAL_SPEC &= "," '((getdt.Rows.Item(j)(4) * row.Item(1)) / ((HRCDT.Item(2)) * 1000000)) & ","

                            Continue For ' Throw ex
                        End Try
                    Next

                End If

            End If


        Catch ex As Exception
            Throw ex
        End Try



    End Sub





    Sub getdataForGrid_LineA()
        '===============================GridValue=================================================================================


        'lblforgriddatavalue.Text = "Abnormal LineA Roll Colling Water Tempreture"
        Dim DSDATE_FORGRID As DataTable = objController.PopulateMaxDatetime()

        Dim dtdateforgrid As DataTable = DSDATE_FORGRID

        Dim ddtdateforgrid As DateTime = CDate(dtdateforgrid.Rows(0)(0))
        Dim frmDateforgrid As String = ddtdateforgrid.ToString("yyyy-MM-dd HH:mm:ss")
        Dim toDateforgrid As String = ddtdateforgrid.AddHours(-1).ToString("yyyy-MM-dd HH:mm:ss")

        Dim dttablegrid As DataTable = objController.GetDataForLogDetailsLINEA(toDateforgrid, frmDateforgrid)

        Dim dv_forgrid As DataView = dttablegrid.DefaultView
        Try


            For i As Integer = 0 To dttablegrid.Rows.Count - 1
                Dim row As DataRow = dttablegrid.Rows(i)
                If row.Item(1) = 0 And row.Item(2) = 0 And row.Item(3) = 0 And row.Item(3) = 0 And row.Item(4) = 0 And row.Item(5) = 0 And row.Item(6) = 0 Then
                    dttablegrid.Rows(i).Delete()
                    'ElseIf row.Item(0).ToString.Trim = "" Then
                    '    dttablegrid.Rows.Remove(row)
                End If
            Next
        Catch ex As Exception
            ' Throw ex
        End Try
        dttablegrid.AcceptChanges()

        If dttablegrid.Rows.Count > 0 Then
            lblforgriddatavalue.Text = "Abnormal LineA Roll Colling Water Tempreture"


            gvData.DataSource = dttablegrid
            gvData.DataBind()
            gvData.UseAccessibleHeader = True
            gvData.HeaderRow.TableSection = TableRowSection.TableHeader
            btnCoolingWaterLossPerc.BackColor = Color.Red
            btnCoolingWaterLoss.BackColor = Color.Red
        Else
            gvData.DataSource = Nothing
            gvData.DataBind()
            btnCoolingWaterLossPerc.BackColor = Color.Yellow
            btnCoolingWaterLoss.BackColor = System.Drawing.ColorTranslator.FromHtml("#8CF02E")
        End If

    End Sub
    Sub getdataForGrid_LineB()
        '===============================GridValue=================================================================================


        Dim DSDATE_FORGRID As DataTable = objController.PopulateMaxDatetime()

        Dim dtdateforgrid As DataTable = DSDATE_FORGRID

        Dim ddtdateforgrid As DateTime = CDate(dtdateforgrid.Rows(0)(0))
        Dim frmDateforgrid As String = ddtdateforgrid.ToString("yyyy-MM-dd HH:mm:ss")
        Dim toDateforgrid As String = ddtdateforgrid.AddHours(-1).ToString("yyyy-MM-dd HH:mm:ss")

        Dim dttablegrid As DataTable = objController.GetDataForLogDetailsLineB(toDateforgrid, frmDateforgrid)

        Dim dv_forgrid As DataView = dttablegrid.DefaultView
        Try


            For i As Integer = 0 To dttablegrid.Rows.Count - 1
                Dim row As DataRow = dttablegrid.Rows(i)
                If row.Item(1) = 0 And row.Item(2) = 0 And row.Item(3) = 0 And row.Item(3) = 0 And row.Item(4) = 0 And row.Item(5) = 0 And row.Item(6) = 0 Then
                    dttablegrid.Rows(i).Delete()
                    'ElseIf row.Item(0).ToString.Trim = "" Then
                    '    dttablegrid.Rows.Remove(row)
                End If
            Next
        Catch ex As Exception
            ' Throw ex
        End Try
        dttablegrid.AcceptChanges()

        If dttablegrid.Rows.Count > 0 Then

            lblforgriddatavalue.Text = "Abnormal LineB Roll Colling Water Tempreture"

            gvData.DataSource = dttablegrid
            gvData.DataBind()
            gvData.UseAccessibleHeader = True
            gvData.HeaderRow.TableSection = TableRowSection.TableHeader
            btnCoolingWaterLossPerc.BackColor = Color.Red
            btnCoolingWaterLoss.BackColor = Color.Red
        Else
            gvData.DataSource = Nothing
            gvData.DataBind()
            btnCoolingWaterLossPerc.BackColor = Color.Yellow
            btnCoolingWaterLoss.BackColor = System.Drawing.ColorTranslator.FromHtml("#8CF02E")

        End If

    End Sub

    Private Sub gvData_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles gvData.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then

            If DataBinder.Eval(e.Row.DataItem, "ABN_INLET_TEMP_MIN") = 0 Then
                CType(e.Row.FindControl("lblABN_INLET_TEMP_MIN"), Label).Text = ""
            End If

            If DataBinder.Eval(e.Row.DataItem, "ABN_INLET_TEMP_MAX") = 0 Then
                CType(e.Row.FindControl("lblABN_INLET_TEMP_MAX"), Label).Text = ""
            End If

            If DataBinder.Eval(e.Row.DataItem, "ABN_DELTA_T_MIN") = 0 Then
                CType(e.Row.FindControl("lblABN_DELTA_T_MIN"), Label).Text = ""
            End If

            If DataBinder.Eval(e.Row.DataItem, "ABN_DELTA_T_MAX") = 0 Then
                CType(e.Row.FindControl("lblABN_DELTA_T_MAX"), Label).Text = ""
            End If

            If DataBinder.Eval(e.Row.DataItem, "ABN_OUTLET_TEMP_MIN") = 0 Then
                CType(e.Row.FindControl("lblABN_OUTLET_TEMP_MIN"), Label).Text = ""
            End If

            If DataBinder.Eval(e.Row.DataItem, "ABN_OUTLET_TEMP_MAX") = 0 Then
                CType(e.Row.FindControl("lblABN_OUTLET_TEMP_MAX"), Label).Text = ""
            End If




        End If
    End Sub
    Public Function GetTempZoneWise(ByVal Line As String, ByVal ColName As String, ByVal StartTime As String, ByVal EndTime As String)
        Dim sqlQuery As String = "Select TIMESTAMP,LINE," & ColName & " From TSCR_FURNACE_ZONE_TEMP Where LINE = '" & Line & "'"
        sqlQuery &= " AND TIMESTAMP BETWEEN '" & StartTime & "' AND '" & EndTime & "'"
        Dim dt As DataTable = getdatatable(sqlQuery)
    End Function
    Protected Sub btnZ1TC1_Click(sender As Object, e As EventArgs) Handles btnZ1TC1.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE1_TC1"
        Dim Zone As String = "ZONE - 1"
        Dim TC As String = "TC- 1"
        'Dim dtStart As String = DateTime.Now.AddHours(-1).ToString("yyyy-MM-dd HH:mm")
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ1TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        'Dim s As String = "window.open('TSK_Chart_UTS_YS.aspx?CoilId=" & coilid & "&Value=" & Value & "&UTSMin=" & UTS_Min & "&UTSMax=" & UTS_Max & "&YSMin=" & YS_Min & "&YSMax=" & YS_Max & "','_blank');"
        'Page.ClientScript.RegisterStartupScript(Me.GetType(), "alertscript", s, True)

    End Sub
    Protected Sub btnZ1TC2_Click(sender As Object, e As EventArgs) Handles btnZ1TC2.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE1_TC2"
        Dim Zone As String = "ZONE - 1"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ1TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ1TC3_Click(sender As Object, e As EventArgs) Handles btnZ1TC3.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE1_TC3"
        Dim Zone As String = "ZONE - 1"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ1TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ2TC1_Click(sender As Object, e As EventArgs) Handles btnZ2TC1.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE2_TC1"
        Dim Zone As String = "ZONE - 2"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ2TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ2TC2_Click(sender As Object, e As EventArgs) Handles btnZ2TC2.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE2_TC2"
        Dim Zone As String = "ZONE - 2"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ2TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ2TC3_Click(sender As Object, e As EventArgs) Handles btnZ2TC3.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE2_TC3"
        Dim Zone As String = "ZONE - 2"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ2TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ3TC1_Click(sender As Object, e As EventArgs) Handles btnZ3TC1.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE3_TC1"
        Dim Zone As String = "ZONE - 3"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ3TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ3TC2_Click(sender As Object, e As EventArgs) Handles btnZ3TC2.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE3_TC2"
        Dim Zone As String = "ZONE - 3"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ3TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ3TC3_Click(sender As Object, e As EventArgs) Handles btnZ3TC3.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE3_TC3"
        Dim Zone As String = "ZONE - 3"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ3TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ4TC1_Click(sender As Object, e As EventArgs) Handles btnZ4TC1.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE4_TC1"
        Dim Zone As String = "ZONE - 4"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ4TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ4TC2_Click(sender As Object, e As EventArgs) Handles btnZ4TC2.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE4_TC2"
        Dim Zone As String = "ZONE - 4"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ4TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ4TC3_Click(sender As Object, e As EventArgs) Handles btnZ4TC3.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE4_TC3"
        Dim Zone As String = "ZONE - 4"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ4TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ5TC1_Click(sender As Object, e As EventArgs) Handles btnZ5TC1.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE5_TC1"
        Dim Zone As String = "ZONE - 5"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ5TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ5TC2_Click(sender As Object, e As EventArgs) Handles btnZ5TC2.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE5_TC2"
        Dim Zone As String = "ZONE - 5"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ5TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ5TC3_Click(sender As Object, e As EventArgs) Handles btnZ5TC3.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE5_TC3"
        Dim Zone As String = "ZONE - 5"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ5TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ6TC1_Click(sender As Object, e As EventArgs) Handles btnZ6TC1.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE6_TC1"
        Dim Zone As String = "ZONE - 6"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ6TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ6TC2_Click(sender As Object, e As EventArgs) Handles btnZ6TC2.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE6_TC2"
        Dim Zone As String = "ZONE - 6"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ6TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ6TC3_Click(sender As Object, e As EventArgs) Handles btnZ6TC3.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE6_TC3"
        Dim Zone As String = "ZONE - 6"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ6TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ7TC1_Click(sender As Object, e As EventArgs) Handles btnZ7TC1.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE7_TC1"
        Dim Zone As String = "ZONE - 7"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ7TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ7TC2_Click(sender As Object, e As EventArgs) Handles btnZ7TC2.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE7_TC2"
        Dim Zone As String = "ZONE - 7"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ7TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ7TC3_Click(sender As Object, e As EventArgs) Handles btnZ7TC3.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE7_TC3"
        Dim Zone As String = "ZONE - 7"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ7TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ8TC1_Click(sender As Object, e As EventArgs) Handles btnZ8TC1.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE8_TC1"
        Dim Zone As String = "ZONE - 8"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ8TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ8TC2_Click(sender As Object, e As EventArgs) Handles btnZ8TC2.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE8_TC2"
        Dim Zone As String = "ZONE - 8"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ8TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ8TC3_Click(sender As Object, e As EventArgs) Handles btnZ8TC3.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE8_TC3"
        Dim Zone As String = "ZONE - 8"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ8TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ9TC1_Click(sender As Object, e As EventArgs) Handles btnZ9TC1.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE9_TC1"
        Dim Zone As String = "ZONE - 9"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ9TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ9TC2_Click(sender As Object, e As EventArgs) Handles btnZ9TC2.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE9_TC2"
        Dim Zone As String = "ZONE - 9"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ9TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ9TC3_Click(sender As Object, e As EventArgs) Handles btnZ9TC3.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE9_TC3"
        Dim Zone As String = "ZONE - 9"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ9TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ1Avg_Click(sender As Object, e As EventArgs) Handles btnZ1Avg.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "(ZONE1_TC1+ZONE1_TC2+ZONE1_TC3)/3"
        Dim Zone As String = "ZONE - 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"
        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ1Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ2Avg_Click(sender As Object, e As EventArgs) Handles btnZ2Avg.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "(ZONE2_TC1+ZONE2_TC2+ZONE2_TC3)/3"
        Dim Zone As String = "ZONE - 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ2Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ3Avg_Click(sender As Object, e As EventArgs) Handles btnZ3Avg.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "(ZONE3_TC1+ZONE3_TC2+ZONE3_TC3)/3"
        Dim Zone As String = "ZONE - 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ3Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ4Avg_Click(sender As Object, e As EventArgs) Handles btnZ4Avg.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "(ZONE4_TC1+ZONE4_TC2+ZONE4_TC3)/3"
        Dim Zone As String = "ZONE - 4"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ4Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ5Avg_Click(sender As Object, e As EventArgs) Handles btnZ5Avg.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "(ZONE5_TC1+ZONE5_TC2+ZONE5_TC3)/3"
        Dim Zone As String = "ZONE - 5"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ5Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ6Avg_Click(sender As Object, e As EventArgs) Handles btnZ6Avg.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "(ZONE6_TC1+ZONE6_TC2+ZONE6_TC3)/3"
        Dim Zone As String = "ZONE - 6"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ6Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ7Avg_Click(sender As Object, e As EventArgs) Handles btnZ7Avg.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "(ZONE7_TC1+ZONE7_TC2+ZONE7_TC3)/3"
        Dim Zone As String = "ZONE - 7"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ7Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ8Avg_Click(sender As Object, e As EventArgs) Handles btnZ8Avg.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "(ZONE8_TC1+ZONE8_TC2+ZONE8_TC3)/3"
        Dim Zone As String = "ZONE - 8"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ8Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnZ9Avg_Click(sender As Object, e As EventArgs) Handles btnZ9Avg.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "(ZONE9_TC1+ZONE9_TC2+ZONE9_TC3)/3"
        Dim Zone As String = "ZONE - 9"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnZ9Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub

    Protected Sub btnLBZ1TC1_Click(sender As Object, e As EventArgs) Handles btnLBZ1TC1.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE1_TC1"
        Dim Zone As String = "ZONE - 1"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ1TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ1TC2_Click(sender As Object, e As EventArgs) Handles btnLBZ1TC2.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE1_TC2"
        Dim Zone As String = "ZONE - 1"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ1TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ1TC3_Click(sender As Object, e As EventArgs) Handles btnLBZ1TC3.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE1_TC3"
        Dim Zone As String = "ZONE - 1"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ1TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ2TC1_Click(sender As Object, e As EventArgs) Handles btnLBZ2TC1.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE2_TC1"
        Dim Zone As String = "ZONE - 2"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ2TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ2TC2_Click(sender As Object, e As EventArgs) Handles btnLBZ2TC2.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE2_TC2"
        Dim Zone As String = "ZONE - 2"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ2TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ2TC3_Click(sender As Object, e As EventArgs) Handles btnLBZ2TC3.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE2_TC3"
        Dim Zone As String = "ZONE - 2"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ2TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ3TC1_Click(sender As Object, e As EventArgs) Handles btnLBZ3TC1.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE3_TC1"
        Dim Zone As String = "ZONE - 3"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ3TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ3TC2_Click(sender As Object, e As EventArgs) Handles btnLBZ3TC2.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE3_TC2"
        Dim Zone As String = "ZONE - 3"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ3TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub

    Protected Sub btnLBZ3TC3_Click(sender As Object, e As EventArgs) Handles btnLBZ3TC3.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE3_TC3"
        Dim Zone As String = "ZONE - 3"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ3TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ4TC1_Click(sender As Object, e As EventArgs) Handles btnLBZ4TC1.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE4_TC1"
        Dim Zone As String = "ZONE - 4"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ4TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ4TC2_Click(sender As Object, e As EventArgs) Handles btnLBZ4TC2.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE4_TC2"
        Dim Zone As String = "ZONE - 4"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ4TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ4TC3_Click(sender As Object, e As EventArgs) Handles btnLBZ4TC3.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE4_TC3"
        Dim Zone As String = "ZONE - 4"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ4TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ5TC1_Click(sender As Object, e As EventArgs) Handles btnLBZ5TC1.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE5_TC1"
        Dim Zone As String = "ZONE - 5"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ5TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ5TC2_Click(sender As Object, e As EventArgs) Handles btnLBZ5TC2.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE5_TC2"
        Dim Zone As String = "ZONE - 5"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ5TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub

    Protected Sub btnLBZ5TC3_Click(sender As Object, e As EventArgs) Handles btnLBZ5TC3.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE5_TC3"
        Dim Zone As String = "ZONE - 5"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ5TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ6TC1_Click(sender As Object, e As EventArgs) Handles btnLBZ6TC1.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE6_TC1"
        Dim Zone As String = "ZONE - 6"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ6TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ6TC2_Click(sender As Object, e As EventArgs) Handles btnLBZ6TC2.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE6_TC2"
        Dim Zone As String = "ZONE - 6"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ6TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ6TC3_Click(sender As Object, e As EventArgs) Handles btnLBZ6TC3.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE6_TC3"
        Dim Zone As String = "ZONE - 6"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ6TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub

    Protected Sub btnLBZ7TC1_Click(sender As Object, e As EventArgs) Handles btnLBZ7TC1.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE7_TC1"
        Dim Zone As String = "ZONE - 7"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ7TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ7TC2_Click(sender As Object, e As EventArgs) Handles btnLBZ7TC2.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE7_TC2"
        Dim Zone As String = "ZONE - 7"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ7TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ7TC3_Click(sender As Object, e As EventArgs) Handles btnLBZ7TC3.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE7_TC3"
        Dim Zone As String = "ZONE - 7"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ7TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ8TC1_Click(sender As Object, e As EventArgs) Handles btnLBZ8TC1.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE8_TC1"
        Dim Zone As String = "ZONE - 8"
        Dim TC As String = "TC- 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ8TC1.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ8TC2_Click(sender As Object, e As EventArgs) Handles btnLBZ8TC2.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE8_TC2"
        Dim Zone As String = "ZONE - 8"
        Dim TC As String = "TC- 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ8TC2.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ8TC3_Click(sender As Object, e As EventArgs) Handles btnLBZ8TC3.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE8_TC3"
        Dim Zone As String = "ZONE - 8"
        Dim TC As String = "TC- 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("TC") = TC

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ8TC3.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub

    Protected Sub btnLBZ1Avg_Click(sender As Object, e As EventArgs) Handles btnLBZ1Avg.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "(ZONE1_TC1+ZONE1_TC2+ZONE1_TC3)/3"
        Dim Zone As String = "ZONE - 1"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ1Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ2Avg_Click(sender As Object, e As EventArgs) Handles btnLBZ2Avg.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "(ZONE2_TC1+ZONE2_TC2+ZONE2_TC3)/3"
        Dim Zone As String = "ZONE - 2"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ2Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ3Avg_Click(sender As Object, e As EventArgs) Handles btnLBZ3Avg.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "(ZONE3_TC1+ZONE3_TC2+ZONE3_TC3)/3"
        Dim Zone As String = "ZONE - 3"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ3Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ4Avg_Click(sender As Object, e As EventArgs) Handles btnLBZ4Avg.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "(ZONE4_TC1+ZONE4_TC2+ZONE4_TC3)/3"
        Dim Zone As String = "ZONE - 4"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ4Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ5Avg_Click(sender As Object, e As EventArgs) Handles btnLBZ5Avg.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "(ZONE5_TC1+ZONE5_TC2+ZONE5_TC3)/3"
        Dim Zone As String = "ZONE - 5"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ5Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ6Avg_Click(sender As Object, e As EventArgs) Handles btnLBZ6Avg.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "(ZONE6_TC1+ZONE6_TC2+ZONE6_TC3)/3"
        Dim Zone As String = "ZONE - 6"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ6Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ7Avg_Click(sender As Object, e As EventArgs) Handles btnLBZ7Avg.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "(ZONE7_TC1+ZONE7_TC2+ZONE7_TC3)/3"
        Dim Zone As String = "ZONE - 7"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ7Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnLBZ8Avg_Click(sender As Object, e As EventArgs) Handles btnLBZ8Avg.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "(ZONE8_TC1+ZONE8_TC2+ZONE8_TC3)/3"
        Dim Zone As String = "ZONE - 8"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        Dim TC As String = "Avg"

        'Session("Furnace") = Line
        'Session("ZoneTemp") = ZoneTC
        'Session("StartDt") = dtStart
        'Session("EndDt") = dtEnd
        'Session("Zone") = Zone
        'Session("Avg") = "Avg"

        Dim url As String = "ZoneTempLineChart.aspx"
        'btnLBZ8Avg.Attributes.Add("onclick", "window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no' );return false;")
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "', '_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & Server.UrlEncode(Server.HtmlEncode(ZoneTC)) & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone & "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub

    Protected Sub btnDSHistLA_Click(sender As Object, e As EventArgs) Handles btnDSHistLA.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE1_TC1,ZONE1_TC3,ZONE2_TC2,ZONE3_TC1,ZONE3_TC3,ZONE4_TC2,ZONE5_TC2,ZONE6_TC2,ZONE7_TC2,ZONE8_TC2,ZONE9_TC1,ZONE9_TC3"
        Dim Zone As String = "HistDataLineADrive"
        'Dim TC As String = "HistDataLineADrive"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        Dim url As String = "ZoneTempLineChart.aspx"
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone '& "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnOSHistLA_Click(sender As Object, e As EventArgs) Handles btnOSHistLA.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE1_TC2,ZONE2_TC1,ZONE2_TC3,ZONE3_TC2,ZONE4_TC1,ZONE4_TC3,ZONE5_TC1,ZONE5_TC3,ZONE6_TC1,ZONE6_TC3,ZONE7_TC1,ZONE7_TC3,ZONE8_TC1,ZONE8_TC3,ZONE9_TC2"
        Dim Zone As String = "HistDataLineAOS"
        'Dim TC As String = "HistDataLineADrive"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        Dim url As String = "ZoneTempLineChart.aspx"
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone '& "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnBothHistLA_Click(sender As Object, e As EventArgs) Handles btnBothHistLA.Click
        Dim Line As String = "A"
        Dim ZoneTC As String = "ZONE1_TC1,ZONE1_TC3,ZONE2_TC2,ZONE3_TC1,ZONE3_TC3,ZONE4_TC2,ZONE5_TC2,ZONE6_TC2,ZONE7_TC2,ZONE8_TC2,ZONE9_TC1,ZONE9_TC3,ZONE1_TC2,ZONE2_TC1,ZONE2_TC3,ZONE3_TC2,ZONE4_TC1,ZONE4_TC3,ZONE5_TC1,ZONE5_TC3,ZONE6_TC1,ZONE6_TC3,ZONE7_TC1,ZONE7_TC3,ZONE8_TC1,ZONE8_TC3,ZONE9_TC2"
        Dim Zone As String = "HistDataLineABoth"
        'Dim TC As String = "HistDataLineADrive"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        Dim url As String = "ZoneTempLineChart.aspx"
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone '& "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnDSHistLB_Click(sender As Object, e As EventArgs) Handles btnDSHistLB.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE1_TC1,ZONE1_TC3,ZONE2_TC2,ZONE3_TC1,ZONE3_TC3,ZONE4_TC2,ZONE5_TC1,ZONE5_TC3,ZONE6_TC2,ZONE7_TC2,ZONE8_TC2"
        Dim Zone As String = "HistDataLineBDrive"
        'Dim TC As String = "HistDataLineADrive"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        Dim url As String = "ZoneTempLineChart.aspx"
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone '& "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnOSHistLB_Click(sender As Object, e As EventArgs) Handles btnOSHistLB.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE1_TC2,ZONE2_TC1,ZONE2_TC3,ZONE3_TC2,ZONE4_TC1,ZONE4_TC3,ZONE5_TC2,ZONE6_TC1,ZONE6_TC3,ZONE7_TC1,ZONE7_TC3,ZONE8_TC1,ZONE8_TC3"
        Dim Zone As String = "HistDataLineBOS"
        'Dim TC As String = "HistDataLineADrive"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        Dim url As String = "ZoneTempLineChart.aspx"
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone '& "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub
    Protected Sub btnBothHistLB_Click(sender As Object, e As EventArgs) Handles btnBothHistLB.Click
        Dim Line As String = "B"
        Dim ZoneTC As String = "ZONE1_TC1,ZONE1_TC3,ZONE2_TC2,ZONE3_TC1,ZONE3_TC3,ZONE4_TC2,ZONE5_TC1,ZONE5_TC3,ZONE6_TC2,ZONE7_TC2,ZONE8_TC2,ZONE1_TC2,ZONE2_TC1,ZONE2_TC3,ZONE3_TC2,ZONE4_TC1,ZONE4_TC3,ZONE5_TC2,ZONE6_TC1,ZONE6_TC3,ZONE7_TC1,ZONE7_TC3,ZONE8_TC1,ZONE8_TC3"
        Dim Zone As String = "HistDataLineBBoth"
        'Dim TC As String = "HistDataLineADrive"
        Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        Dim url As String = "ZoneTempLineChart.aspx"
        Dim s As String = url & "?Furnace=" & Line & "&ZoneTemp=" & ZoneTC & "&StartDt=" & dtStart & "&EndDt=" & dtEnd & "&Zone=" & Zone '& "&TC=" & TC
        ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & s & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)
    End Sub





    Sub DrawChartFor_on_toDate()
        Try

            '  Dim frmDate As String = DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 6, 0, 0)
            Dim frmDate As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            Dim toDate As String = DateTime.Now.AddMonths(0).ToString("yyyy-MM-dd HH:mm:ss")

            Dim strfrmDt As String = frmDate
            Dim strToDt As String = toDate
            Dim dstemp As DataSet = objController.GetDataForCHART_ON_TODate() 'frmDate, toDate(02/11/2021)
            PlotBarGraphON_TODate(dstemp.Tables(0), Lit2, "container2", "plot2")


        Catch ex As Exception
            Throw ex
        End Try


    End Sub


    Public Sub PlotBarGraphON_TODate(ByVal dt As DataTable, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String)
        Try
            LiteralName.Text = ""
            Dim ticks As String
            Dim flg As Int32 = 0

            ' dt.DefaultView.Sort = "DAY asc"
            Dim line1, line2, line3 As String
            For i As Integer = 0 To dt.Rows.Count - 1
                If i > 0 Then
                    ticks &= ","
                    line1 &= ","
                    line2 &= ","
                    'line3 &= ","
                    If flg = 0 Then
                        Session("FnYear") = dt.Rows(i)(4)
                        flg = 1
                    End If
                End If
                ticks &= "'" & dt.Rows(i)(0) & "'"
                If IsDBNull(dt.Rows(i)(1)) Then
                    line1 &= 0
                Else
                    line1 &= Math.Round(dt.Rows(i)(1), 3)
                End If
                'If IsDBNull(dt.Rows(i)(2)) Then
                '    line2 &= 0
                'Else
                '    line2 &= dt.Rows(i)(2)
                'End If

            Next
            Dim yVal As Decimal()

            yVal = (From row In dt Select col = CDec(row("CUM_SPEC_FUEL_CON"))).ToArray()

            ''''''''''''''''5% Less min and max shown below'''''''''''''''''''''''''''''''''''''''''
            Dim y_min As String = Math.Round(yVal.Min() - (5 / 100 * yVal.Min), 2).ToString()
            Dim y_max As String = Math.Round(yVal.Max() + (5 / 100 * yVal.Max), 2).ToString()

            Dim s As New StringBuilder("<script>")

            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            s.Append("var myChart = echarts.init(document.getElementById('" & ContainerName & "'));")
            s.Append("option = {    tooltip: {   trigger: 'axis',  axisPointer: {   type: 'cross', crossStyle: {   color: '#999'  }  } },")
            s.Append("toolbox: {  feature: {  dataView: {show: true, readOnly: false},  magicType: {show: true, type: ['line', 'bar']},  restore: {show: true},  saveAsImage: {show: true}  }  },")
            's.Append("legend: {   data: ['To Date SP. Fuel Consumption','To Date Production'], left:'5%'  },")
            s.Append("legend: {   data: ['SP. Fuel Consumption'], left:'15%'  },")
            s.Append("xAxis: [ {  type: 'category',  data: [" & ticks & "],    axisPointer: { type: 'shadow'   }       }   ],   ")
            's.Append("yAxis: [  {   type: 'value', name: 'To Date SP. Fuel Consumption',   min: 0,    max: 1.0,  axisLabel: {  formatter: '{value}'    }    },      {  type: 'value', name: 'To Date Production', min: 0,  max: 500000,  axisLabel: { formatter: '{value}' } }],")
            's.Append("yAxis: [  {   type: 'value', name: 'SP. Fuel Consumption',   min: 0,    max: 0.25,  axisLabel: {  formatter: '{value}'    },left:'15%'    } ],")
            s.Append("yAxis: [  {   type: 'value', name: 'SP. Fuel Consumption',   min: " & y_min & ",    max: " & y_max & ",  axisLabel: {  formatter: '{value}'    },left:'15%'    } ],")
            's.Append("series: [  {   name: 'To Date SP. Fuel Consumption',  type: 'bar',  data: [" & line1 & "]  },   { name: 'To Date Production', type:'bar', yAxisIndex: 1, data: [" & line2 & "] } ]")
            s.Append("series: [  {   name: 'SP. Fuel Consumption',  type: 'bar',  data: [" & line1 & "]  } ]")
            s.Append("};")

            s.Append(" myChart.setOption(option);")
            s.Append("</script>")
            LiteralName.Text = s.ToString()
        Catch ex As Exception
            Dim i As String = ""

        End Try

    End Sub

    Public Sub ShowTCDeviationLineA()

        Dim sqlQuery As String = "SELECT TOP (100) [TIMESTAMP],[LINE],[ZONE1_DEV_TC1],[ZONE1_TC1_TEMP],[ZONE1_DEV_TC2],[ZONE1_TC2_TEMP]"
        sqlQuery &= " ,[ZONE1_DEV_TC3],[ZONE1_TC3_TEMP],[ZONE2_DEV_TC1],[ZONE2_TC1_TEMP],[ZONE2_DEV_TC2],[ZONE2_TC2_TEMP],[ZONE2_DEV_TC3]"
        sqlQuery &= " ,[ZONE2_TC3_TEMP],[ZONE3_DEV_TC1],[ZONE3_TC1_TEMP],[ZONE3_DEV_TC2],[ZONE3_TC2_TEMP],[ZONE3_DEV_TC3],[ZONE3_TC3_TEMP]"
        sqlQuery &= " ,[ZONE4_DEV_TC1],[ZONE4_TC1_TEMP],[ZONE4_DEV_TC2],[ZONE4_TC2_TEMP],[ZONE4_DEV_TC3],[ZONE4_TC3_TEMP],[ZONE5_DEV_TC1]"
        sqlQuery &= " ,[ZONE5_TC1_TEMP],[ZONE5_DEV_TC2],[ZONE5_TC2_TEMP],[ZONE5_DEV_TC3],[ZONE5_TC3_TEMP],[ZONE6_DEV_TC1],[ZONE6_TC1_TEMP]"
        sqlQuery &= " ,[ZONE6_DEV_TC2],[ZONE6_TC2_TEMP],[ZONE6_DEV_TC3],[ZONE6_TC3_TEMP],[ZONE7_DEV_TC1],[ZONE7_TC1_TEMP],[ZONE7_DEV_TC2]"
        sqlQuery &= " ,[ZONE7_TC2_TEMP],[ZONE7_DEV_TC3],[ZONE7_TC3_TEMP],[ZONE8_DEV_TC1],[ZONE8_TC1_TEMP],[ZONE8_DEV_TC2],[ZONE8_TC2_TEMP]"
        sqlQuery &= " ,[ZONE8_DEV_TC3],[ZONE8_TC3_TEMP],[ZONE9_DEV_TC1],[ZONE9_TC1_TEMP],[ZONE9_DEV_TC2],[ZONE9_TC2_TEMP],[ZONE9_DEV_TC3],[ZONE9_TC3_TEMP]"
        sqlQuery &= " FROM TSCR_FURNACE_ZONE_TEMP"
        sqlQuery &= " WHERE LINE in ('A')"
        sqlQuery &= " AND TIMESTAMP > DATEADD(MINUTE, -30, (SELECT MAX(TimeStamp) FROM TSCR_FURNACE_ZONE_TEMP))"
        sqlQuery &= " ORDER BY TIMESTAMP DESC"

        Dim dt As DataTable = New DataTable()
        dt = getdatatable(sqlQuery)

        If dt.Rows.Count > 0 Then
            Dim Z1TC1, Z1TC2, Z1TC3, Z2TC1, Z2TC2, Z2TC3, Z3TC1, Z3TC2, Z3TC3, Z4TC1, Z4TC2, Z4TC3, Z5TC1, Z5TC2, Z5TC3, Z6TC1,
                Z6TC2, Z6TC3, Z7TC1, Z7TC2, Z7TC3, Z8TC1, Z8TC2, Z8TC3, Z9TC1, Z9TC2, Z9TC3 As String

            Dim Z1DevTC1Count, Z1DevTC2Count, Z1DevTC3Count, Z2DevTC1Count, Z2DevTC2Count, Z2DevTC3Count, Z3DevTC1Count, Z3DevTC2Count, Z3DevTC3Count, Z4DevTC1Count,
            Z4DevTC2Count, Z4DevTC3Count, Z5DevTC1Count, Z5DevTC2Count, Z5DevTC3Count, Z6DevTC1Count, Z6DevTC2Count, Z6DevTC3Count, Z7DevTC1Count, Z7DevTC2Count,
            Z7DevTC3Count, Z8DevTC1Count, Z8DevTC2Count, Z8DevTC3Count, Z9DevTC1Count, Z9DevTC2Count, Z9DevTC3Count As Integer

            'For i As Integer = 0 To i < dt.Rows.Count
            '    If dt.Columns Then
            'Next

            For Each row As DataRow In dt.Rows
                If row("ZONE1_DEV_TC1") = "NO DEV" Then

                Else
                    Z1TC1 = row("ZONE1_DEV_TC1").ToString()
                    Z1DevTC1Count += 1
                End If
                If row("ZONE1_DEV_TC2") = "NO DEV" Then

                Else
                    Z1TC2 = row("ZONE1_DEV_TC2").ToString()
                    Z1DevTC2Count += 1
                End If
                If row("ZONE1_DEV_TC3") = "NO DEV" Then

                Else
                    Z1TC3 = row("ZONE1_DEV_TC3").ToString()
                    Z1DevTC3Count += 1
                End If
                If row("ZONE2_DEV_TC1") = "NO DEV" Then

                Else
                    Z2TC1 = row("ZONE2_DEV_TC1").ToString()
                    Z2DevTC1Count += 1
                End If
                If row("ZONE2_DEV_TC2") = "NO DEV" Then

                Else
                    Z2TC2 = row("ZONE2_DEV_TC2").ToString()
                    Z2DevTC2Count += 1
                End If
                If row("ZONE2_DEV_TC3") = "NO DEV" Then

                Else
                    Z2TC3 = row("ZONE2_DEV_TC3").ToString()
                    Z2DevTC3Count += 1
                End If
                If row("ZONE3_DEV_TC1") = "NO DEV" Then

                Else
                    Z3TC1 = row("ZONE3_DEV_TC1").ToString()
                    Z3DevTC1Count += 1
                End If
                If row("ZONE3_DEV_TC2") = "NO DEV" Then

                Else
                    Z3TC2 = row("ZONE3_DEV_TC2").ToString()
                    Z3DevTC2Count += 1
                End If
                If row("ZONE3_DEV_TC3") = "NO DEV" Then

                Else
                    Z3TC3 = row("ZONE3_DEV_TC3").ToString()
                    Z3DevTC3Count += 1
                End If
                If row("ZONE4_DEV_TC1") = "NO DEV" Then

                Else
                    Z4TC1 = row("ZONE4_DEV_TC1").ToString()
                    Z4DevTC1Count += 1
                End If
                If row("ZONE4_DEV_TC2") = "NO DEV" Then

                Else
                    Z4TC2 = row("ZONE4_DEV_TC2").ToString()
                    Z4DevTC2Count += 1
                End If
                If row("ZONE4_DEV_TC3") = "NO DEV" Then

                Else
                    Z4TC3 = row("ZONE4_DEV_TC3").ToString()
                    Z4DevTC3Count += 1
                End If
                If row("ZONE5_DEV_TC1") = "NO DEV" Then

                Else
                    Z5TC1 = row("ZONE5_DEV_TC1").ToString()
                    Z5DevTC1Count += 1
                End If
                If row("ZONE5_DEV_TC2") = "NO DEV" Then

                Else
                    Z5TC2 = row("ZONE5_DEV_TC2").ToString()
                    Z5DevTC2Count += 1
                End If
                If row("ZONE5_DEV_TC3") = "NO DEV" Then

                Else
                    Z5TC3 = row("ZONE5_DEV_TC3").ToString()
                    Z5DevTC3Count += 1
                End If
                If row("ZONE6_DEV_TC1") = "NO DEV" Then

                Else
                    Z6TC1 = row("ZONE6_DEV_TC1").ToString()
                    Z6DevTC1Count += 1
                End If
                If row("ZONE6_DEV_TC2") = "NO DEV" Then

                Else
                    Z6TC2 = row("ZONE6_DEV_TC2").ToString()
                    Z6DevTC2Count += 1
                End If
                If row("ZONE6_DEV_TC3") = "NO DEV" Then

                Else
                    Z6TC3 = row("ZONE6_DEV_TC3").ToString()
                    Z6DevTC3Count += 1
                End If
                If row("ZONE7_DEV_TC1") = "NO DEV" Then

                Else
                    Z7TC1 = row("ZONE7_DEV_TC1").ToString()
                    Z7DevTC1Count += 1
                End If
                If row("ZONE7_DEV_TC2") = "NO DEV" Then

                Else
                    Z7TC2 = row("ZONE7_DEV_TC2").ToString()
                    Z7DevTC2Count += 1
                End If
                If row("ZONE7_DEV_TC3") = "NO DEV" Then

                Else
                    Z7TC3 = row("ZONE7_DEV_TC3").ToString()
                    Z7DevTC3Count += 1
                End If
                If row("ZONE8_DEV_TC1") = "NO DEV" Then

                Else
                    Z8TC1 = row("ZONE8_DEV_TC1").ToString()
                    Z8DevTC1Count += 1
                End If
                If row("ZONE8_DEV_TC2") = "NO DEV" Then

                Else
                    Z8TC2 = row("ZONE8_DEV_TC2").ToString()
                    Z8DevTC2Count += 1
                End If
                If row("ZONE8_DEV_TC3") = "NO DEV" Then

                Else
                    Z8TC3 = row("ZONE8_DEV_TC3").ToString()
                    Z8DevTC3Count += 1
                End If
                If row("ZONE9_DEV_TC1") = "NO DEV" Then

                Else
                    Z9TC1 = row("ZONE9_DEV_TC1").ToString()
                    Z9DevTC1Count += 1
                End If
                If row("ZONE9_DEV_TC2") = "NO DEV" Then

                Else
                    Z9TC2 = row("ZONE9_DEV_TC2").ToString()
                    Z9DevTC2Count += 1
                End If
                If row("ZONE9_DEV_TC3") = "NO DEV" Then

                Else
                    Z9TC3 = row("ZONE9_DEV_TC3").ToString()
                    Z9DevTC3Count += 1
                End If
            Next row
            ''''''''''''''''''''''''''''''''''''Color Coding Acccording to Deviation Data Obtained'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            If Z1DevTC1Count > (dt.Rows.Count) / 2 Then
                If Z1TC1 = "TC1" Then
                    btnZ1TC1.BackColor = Color.Red
                    btnZ1TC1.CssClass &= " blink"
                ElseIf Z1TC1 = "TC2" Then
                    btnZ1TC2.BackColor = Color.Red
                    btnZ1TC2.CssClass &= " blink"
                ElseIf Z1TC1 = "TC3" Then
                    btnZ1TC3.BackColor = Color.Red
                    btnZ1TC3.CssClass &= " blink"
                End If
            ElseIf Z1DevTC1Count < (dt.Rows.Count) / 2 And Z1DevTC1Count > 10 Then
                If Z1TC1 = "TC1" Then
                    btnZ1TC1.BackColor = Color.Orange
                    btnZ1TC1.CssClass = btnZ1TC1.CssClass.Replace("blink", "")
                ElseIf Z1TC1 = "TC2" Then
                    btnZ1TC2.BackColor = Color.Orange
                    btnZ1TC2.CssClass = btnZ1TC2.CssClass.Replace("blink", "")
                ElseIf Z1TC1 = "TC3" Then
                    btnZ1TC3.BackColor = Color.Orange
                    btnZ1TC3.CssClass = btnZ1TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z1DevTC2Count > (dt.Rows.Count) / 2 Then
                If Z1TC2 = "TC1" Then
                    btnZ1TC1.BackColor = Color.Red
                    'btnZ1TC1.Attributes.Add("CssClass", "blink")
                    btnZ1TC1.CssClass &= " blink"
                    ''btnZ1TC1.Attributes.Add("style", "text-decoration:blink")
                ElseIf Z1TC2 = "TC2" Then
                    btnZ1TC2.BackColor = Color.Red
                    'btnZ1TC2.Attributes.Add("CssClass", "blink")
                    btnZ1TC2.CssClass &= " blink"
                    ''btnZ1TC2.Attributes.Add("style", "text-decoration:blink")
                ElseIf Z1TC2 = "TC3" Then
                    btnZ1TC3.BackColor = Color.Red
                    btnZ1TC3.CssClass &= " blink"
                    'btnZ1TC3.Attributes.Add("CssClass", "blink")
                    ''btnZ1TC3.Attributes.Add("style", "text-decoration:blink")
                End If
            ElseIf Z1DevTC2Count < (dt.Rows.Count) / 2 And Z1DevTC2Count > 10 Then
                If Z1TC2 = "TC1" Then
                    btnZ1TC1.BackColor = Color.Orange
                    btnZ1TC1.CssClass = btnZ1TC1.CssClass.Replace("blink", "")
                ElseIf Z1TC2 = "TC2" Then
                    btnZ1TC2.BackColor = Color.Orange
                    btnZ1TC2.CssClass = btnZ1TC2.CssClass.Replace("blink", "")
                ElseIf Z1TC2 = "TC3" Then
                    btnZ1TC3.BackColor = Color.Orange
                    btnZ1TC3.CssClass = btnZ1TC3.CssClass.Replace("blink", "")
                End If
            End If
            If Z1DevTC3Count > (dt.Rows.Count) / 2 Then
                If Z1TC3 = "TC1" Then
                    btnZ1TC1.BackColor = Color.Red
                    btnZ1TC1.CssClass &= " blink"
                ElseIf Z1TC3 = "TC2" Then
                    btnZ1TC2.BackColor = Color.Red
                    btnZ1TC2.CssClass &= " blink"
                ElseIf Z1TC3 = "TC3" Then
                    btnZ1TC3.BackColor = Color.Red
                    btnZ1TC3.CssClass &= " blink"
                End If
            ElseIf Z1DevTC3Count < (dt.Rows.Count) / 2 And Z1DevTC3Count > 10 Then
                If Z1TC3 = "TC1" Then
                    btnZ1TC1.BackColor = Color.Orange
                    btnZ1TC1.CssClass = btnZ1TC1.CssClass.Replace("blink", "")
                ElseIf Z1TC3 = "TC2" Then
                    btnZ1TC2.BackColor = Color.Orange
                    btnZ1TC2.CssClass = btnZ1TC2.CssClass.Replace("blink", "")
                ElseIf Z1TC3 = "TC3" Then
                    btnZ1TC3.BackColor = Color.Orange
                    btnZ1TC3.CssClass = btnZ1TC3.CssClass.Replace("blink", "")
                End If
            End If


            If Z2DevTC1Count > (dt.Rows.Count) / 2 Then
                If Z2TC1 = "TC1" Then
                    btnZ2TC1.BackColor = Color.Red
                    btnZ2TC1.CssClass &= " blink"
                ElseIf Z2TC1 = "TC2" Then
                    btnZ2TC2.BackColor = Color.Red
                    btnZ2TC2.CssClass &= " blink"
                ElseIf Z2TC1 = "TC3" Then
                    btnZ2TC3.BackColor = Color.Red
                    btnZ2TC3.CssClass &= " blink"
                End If
            ElseIf Z2DevTC1Count < (dt.Rows.Count) / 2 And Z2DevTC1Count > 10 Then
                If Z2TC1 = "TC1" Then
                    btnZ2TC1.BackColor = Color.Orange
                    btnZ2TC1.CssClass = btnZ2TC1.CssClass.Replace("blink", "")
                ElseIf Z2TC1 = "TC2" Then
                    btnZ2TC2.BackColor = Color.Orange
                    btnZ2TC2.CssClass = btnZ2TC2.CssClass.Replace("blink", "")
                ElseIf Z2TC1 = "TC3" Then
                    btnZ2TC3.BackColor = Color.Orange
                    btnZ2TC3.CssClass = btnZ2TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z2DevTC2Count > (dt.Rows.Count) / 2 Then
                If Z2TC2 = "TC1" Then
                    btnZ2TC1.BackColor = Color.Red
                    btnZ2TC1.CssClass &= " blink"
                ElseIf Z2TC2 = "TC2" Then
                    btnZ2TC2.BackColor = Color.Red
                    btnZ2TC2.CssClass &= " blink"
                ElseIf Z2TC2 = "TC3" Then
                    btnZ2TC3.BackColor = Color.Red
                    btnZ2TC3.CssClass &= " blink"
                End If
            ElseIf Z2DevTC2Count < (dt.Rows.Count) / 2 And Z2DevTC2Count > 10 Then
                If Z2TC2 = "TC1" Then
                    btnZ2TC1.BackColor = Color.Orange
                    btnZ2TC1.CssClass = btnZ2TC1.CssClass.Replace("blink", "")
                ElseIf Z2TC2 = "TC2" Then
                    btnZ2TC2.BackColor = Color.Orange
                    btnZ2TC2.CssClass = btnZ2TC2.CssClass.Replace("blink", "")
                ElseIf Z2TC2 = "TC3" Then
                    btnZ2TC3.BackColor = Color.Orange
                    btnZ2TC3.CssClass = btnZ2TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z2DevTC3Count > (dt.Rows.Count) / 2 Then
                If Z2TC3 = "TC1" Then
                    btnZ2TC1.BackColor = Color.Red
                    btnZ2TC1.CssClass &= " blink"
                ElseIf Z2TC3 = "TC2" Then
                    btnZ2TC2.BackColor = Color.Red
                    btnZ2TC2.CssClass &= " blink"
                ElseIf Z2TC3 = "TC3" Then
                    btnZ2TC3.BackColor = Color.Red
                    btnZ2TC3.CssClass &= " blink"
                End If
            ElseIf Z2DevTC3Count < (dt.Rows.Count) / 2 And Z2DevTC3Count > 10 Then
                If Z2TC3 = "TC1" Then
                    btnZ2TC1.BackColor = Color.Orange
                    btnZ2TC1.CssClass = btnZ2TC1.CssClass.Replace("blink", "")
                ElseIf Z2TC3 = "TC2" Then
                    btnZ2TC2.BackColor = Color.Orange
                    btnZ2TC2.CssClass = btnZ2TC2.CssClass.Replace("blink", "")
                ElseIf Z2TC3 = "TC3" Then
                    btnZ2TC3.BackColor = Color.Orange
                    btnZ2TC3.CssClass = btnZ2TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z3DevTC1Count > (dt.Rows.Count) / 2 Then
                If Z3TC1 = "TC1" Then
                    btnZ3TC1.BackColor = Color.Red
                    btnZ3TC1.CssClass &= " blink"
                ElseIf Z3TC1 = "TC2" Then
                    btnZ3TC2.BackColor = Color.Red
                    btnZ3TC2.CssClass &= " blink"
                ElseIf Z3TC1 = "TC3" Then
                    btnZ3TC3.BackColor = Color.Red
                    btnZ3TC3.CssClass &= " blink"
                End If
            ElseIf Z3DevTC1Count < (dt.Rows.Count) / 2 And Z3DevTC1Count > 10 Then
                If Z3TC1 = "TC1" Then
                    btnZ3TC1.BackColor = Color.Orange
                    btnZ3TC1.CssClass = btnZ3TC1.CssClass.Replace("blink", "")
                ElseIf Z3TC1 = "TC2" Then
                    btnZ3TC2.BackColor = Color.Orange
                    btnZ3TC2.CssClass = btnZ3TC2.CssClass.Replace("blink", "")
                ElseIf Z3TC1 = "TC3" Then
                    btnZ3TC3.BackColor = Color.Orange
                    btnZ3TC3.CssClass = btnZ3TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z3DevTC2Count > (dt.Rows.Count) / 2 Then
                If Z3TC2 = "TC1" Then
                    btnZ3TC1.BackColor = Color.Red
                    btnZ3TC1.CssClass &= " blink"
                ElseIf Z3TC2 = "TC2" Then
                    btnZ3TC2.BackColor = Color.Red
                    btnZ3TC2.CssClass &= " blink"
                ElseIf Z3TC2 = "TC3" Then
                    btnZ3TC3.BackColor = Color.Red
                    btnZ3TC3.CssClass &= " blink"
                End If
            ElseIf Z3DevTC2Count < (dt.Rows.Count) / 2 And Z3DevTC2Count > 10 Then
                If Z3TC2 = "TC1" Then
                    btnZ3TC1.BackColor = Color.Orange
                    btnZ3TC1.CssClass = btnZ3TC1.CssClass.Replace("blink", "")
                ElseIf Z3TC2 = "TC2" Then
                    btnZ3TC2.BackColor = Color.Orange
                    btnZ3TC2.CssClass = btnZ3TC2.CssClass.Replace("blink", "")
                ElseIf Z3TC2 = "TC3" Then
                    btnZ3TC3.BackColor = Color.Orange
                    btnZ3TC3.CssClass = btnZ3TC3.CssClass.Replace("blink", "")
                End If
            End If
            If Z3DevTC3Count > (dt.Rows.Count) / 2 Then
                If Z3TC3 = "TC1" Then
                    btnZ3TC1.BackColor = Color.Red
                    btnZ3TC1.CssClass &= " blink"
                ElseIf Z3TC3 = "TC2" Then
                    btnZ3TC2.BackColor = Color.Red
                    btnZ3TC2.CssClass &= " blink"
                ElseIf Z3TC3 = "TC3" Then
                    btnZ3TC3.BackColor = Color.Red
                    btnZ3TC3.CssClass &= " blink"
                End If
            ElseIf Z3DevTC3Count < (dt.Rows.Count) / 2 And Z3DevTC3Count > 10 Then
                If Z3TC3 = "TC1" Then
                    btnZ3TC1.BackColor = Color.Orange
                    btnZ3TC1.CssClass = btnZ3TC1.CssClass.Replace("blink", "")
                ElseIf Z3TC3 = "TC2" Then
                    btnZ3TC2.BackColor = Color.Orange
                    btnZ3TC2.CssClass = btnZ3TC2.CssClass.Replace("blink", "")
                ElseIf Z3TC3 = "TC3" Then
                    btnZ3TC3.BackColor = Color.Orange
                    btnZ3TC3.CssClass = btnZ3TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z4DevTC1Count > (dt.Rows.Count) / 2 Then
                If Z4TC1 = "TC1" Then
                    btnZ4TC1.BackColor = Color.Red
                    btnZ4TC1.CssClass &= " blink"
                ElseIf Z4TC1 = "TC2" Then
                    btnZ4TC2.BackColor = Color.Red
                    btnZ4TC2.CssClass &= " blink"
                ElseIf Z4TC1 = "TC3" Then
                    btnZ4TC3.BackColor = Color.Red
                    btnZ4TC3.CssClass &= " blink"
                End If
            ElseIf Z4DevTC1Count < (dt.Rows.Count) / 2 And Z4DevTC1Count > 10 Then
                If Z4TC1 = "TC1" Then
                    btnZ4TC1.BackColor = Color.Orange
                    btnZ4TC1.CssClass = btnZ4TC1.CssClass.Replace("blink", "")
                ElseIf Z4TC1 = "TC2" Then
                    btnZ4TC2.BackColor = Color.Orange
                    btnZ4TC2.CssClass = btnZ4TC2.CssClass.Replace("blink", "")
                ElseIf Z4TC1 = "TC3" Then
                    btnZ4TC3.BackColor = Color.Orange
                    btnZ4TC3.CssClass = btnZ4TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z4DevTC2Count > (dt.Rows.Count) / 2 Then
                If Z4TC2 = "TC1" Then
                    btnZ4TC1.BackColor = Color.Red
                    btnZ4TC1.CssClass &= " blink"
                ElseIf Z4TC2 = "TC2" Then
                    btnZ4TC2.BackColor = Color.Red
                    btnZ4TC2.CssClass &= " blink"
                ElseIf Z4TC2 = "TC3" Then
                    btnZ4TC3.BackColor = Color.Red
                    btnZ4TC3.CssClass &= " blink"
                End If
            ElseIf Z4DevTC2Count < (dt.Rows.Count) / 2 And Z4DevTC2Count > 10 Then
                If Z4TC2 = "TC1" Then
                    btnZ4TC1.BackColor = Color.Orange
                    btnZ4TC1.CssClass = btnZ4TC1.CssClass.Replace("blink", "")
                ElseIf Z4TC2 = "TC2" Then
                    btnZ4TC2.BackColor = Color.Orange
                    btnZ4TC2.CssClass = btnZ4TC2.CssClass.Replace("blink", "")
                ElseIf Z4TC2 = "TC3" Then
                    btnZ4TC3.BackColor = Color.Orange
                    btnZ4TC3.CssClass = btnZ4TC3.CssClass.Replace("blink", "")
                End If
            End If
            If Z4DevTC3Count > (dt.Rows.Count) / 2 Then
                If Z4TC3 = "TC1" Then
                    btnZ4TC1.BackColor = Color.Red
                    btnZ4TC1.CssClass &= " blink"
                ElseIf Z4TC3 = "TC2" Then
                    btnZ4TC2.BackColor = Color.Red
                    btnZ4TC2.CssClass &= " blink"
                ElseIf Z4TC3 = "TC3" Then
                    btnZ4TC3.BackColor = Color.Red
                    btnZ4TC3.CssClass &= " blink"
                End If
            ElseIf Z4DevTC3Count < (dt.Rows.Count) / 2 And Z4DevTC3Count > 10 Then
                If Z4TC3 = "TC1" Then
                    btnZ4TC1.BackColor = Color.Orange
                    btnZ4TC1.CssClass = btnZ4TC1.CssClass.Replace("blink", "")
                ElseIf Z4TC3 = "TC2" Then
                    btnZ4TC2.BackColor = Color.Orange
                    btnZ4TC2.CssClass = btnZ4TC2.CssClass.Replace("blink", "")
                ElseIf Z4TC3 = "TC3" Then
                    btnZ4TC3.BackColor = Color.Orange
                    btnZ4TC3.CssClass = btnZ4TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z5DevTC1Count > (dt.Rows.Count) / 2 Then
                If Z5TC1 = "TC1" Then
                    btnZ5TC1.BackColor = Color.Red
                    btnZ5TC1.CssClass &= " blink"
                ElseIf Z5TC1 = "TC2" Then
                    btnZ5TC2.BackColor = Color.Red
                    btnZ5TC2.CssClass &= " blink"
                ElseIf Z5TC1 = "TC3" Then
                    btnZ5TC3.BackColor = Color.Red
                    btnZ5TC3.CssClass &= " blink"
                End If
            ElseIf Z5DevTC1Count < (dt.Rows.Count) / 2 And Z5DevTC1Count > 10 Then
                If Z5TC1 = "TC1" Then
                    btnZ5TC1.BackColor = Color.Orange
                    btnZ5TC1.CssClass = btnZ5TC1.CssClass.Replace("blink", "")
                ElseIf Z5TC1 = "TC2" Then
                    btnZ5TC2.BackColor = Color.Orange
                    btnZ5TC2.CssClass = btnZ5TC2.CssClass.Replace("blink", "")
                ElseIf Z5TC1 = "TC3" Then
                    btnZ5TC3.BackColor = Color.Orange
                    btnZ5TC3.CssClass = btnZ5TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z5DevTC2Count > (dt.Rows.Count) / 2 Then
                If Z5TC2 = "TC1" Then
                    btnZ5TC1.BackColor = Color.Red
                    btnZ5TC1.CssClass &= " blink"
                ElseIf Z5TC2 = "TC2" Then
                    btnZ5TC2.BackColor = Color.Red
                    btnZ5TC2.CssClass &= " blink"
                ElseIf Z5TC2 = "TC3" Then
                    btnZ5TC3.BackColor = Color.Red
                    btnZ5TC3.CssClass &= " blink"
                End If
            ElseIf Z5DevTC2Count < (dt.Rows.Count) / 2 And Z5DevTC2Count > 10 Then
                If Z5TC2 = "TC1" Then
                    btnZ5TC1.BackColor = Color.Orange
                    btnZ5TC1.CssClass = btnZ5TC1.CssClass.Replace("blink", "")
                ElseIf Z5TC2 = "TC2" Then
                    btnZ5TC2.BackColor = Color.Orange
                    btnZ5TC2.CssClass = btnZ5TC2.CssClass.Replace("blink", "")
                ElseIf Z5TC2 = "TC3" Then
                    btnZ5TC3.BackColor = Color.Orange
                    btnZ5TC3.CssClass = btnZ5TC3.CssClass.Replace("blink", "")
                End If
            End If
            If Z5DevTC3Count > (dt.Rows.Count) / 2 Then
                If Z5TC3 = "TC1" Then
                    btnZ5TC1.BackColor = Color.Red
                    btnZ5TC1.CssClass &= " blink"
                ElseIf Z5TC3 = "TC2" Then
                    btnZ5TC2.BackColor = Color.Red
                    btnZ5TC2.CssClass &= " blink"
                ElseIf Z5TC3 = "TC3" Then
                    btnZ5TC3.BackColor = Color.Red
                    btnZ5TC3.CssClass &= " blink"
                End If
            ElseIf Z5DevTC3Count < (dt.Rows.Count) / 2 And Z5DevTC3Count > 10 Then
                If Z5TC3 = "TC1" Then
                    btnZ5TC1.BackColor = Color.Orange
                    btnZ5TC1.CssClass = btnZ5TC1.CssClass.Replace("blink", "")
                ElseIf Z5TC3 = "TC2" Then
                    btnZ5TC2.BackColor = Color.Orange
                    btnZ5TC2.CssClass = btnZ5TC2.CssClass.Replace("blink", "")
                ElseIf Z5TC3 = "TC3" Then
                    btnZ5TC3.BackColor = Color.Orange
                    btnZ5TC3.CssClass = btnZ5TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z6DevTC1Count > (dt.Rows.Count) / 2 Then
                If Z6TC1 = "TC1" Then
                    btnZ6TC1.BackColor = Color.Red
                    btnZ6TC1.CssClass &= " blink"
                ElseIf Z6TC1 = "TC2" Then
                    btnZ6TC2.BackColor = Color.Red
                    btnZ6TC2.CssClass &= " blink"
                ElseIf Z6TC1 = "TC3" Then
                    btnZ6TC3.BackColor = Color.Red
                    btnZ6TC3.CssClass &= " blink"
                End If
            ElseIf Z6DevTC1Count < (dt.Rows.Count) / 2 And Z6DevTC1Count > 10 Then
                If Z6TC1 = "TC1" Then
                    btnZ6TC1.BackColor = Color.Orange
                    btnZ6TC1.CssClass = btnZ6TC1.CssClass.Replace("blink", "")
                ElseIf Z6TC1 = "TC2" Then
                    btnZ6TC2.BackColor = Color.Orange
                    btnZ6TC2.CssClass = btnZ6TC2.CssClass.Replace("blink", "")
                ElseIf Z6TC1 = "TC3" Then
                    btnZ6TC3.BackColor = Color.Orange
                    btnZ6TC3.CssClass = btnZ6TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z6DevTC2Count > (dt.Rows.Count) / 2 Then
                If Z6TC2 = "TC1" Then
                    btnZ6TC1.BackColor = Color.Red
                    btnZ6TC1.CssClass &= " blink"
                ElseIf Z6TC2 = "TC2" Then
                    btnZ6TC2.BackColor = Color.Red
                    btnZ6TC2.CssClass &= " blink"
                ElseIf Z6TC2 = "TC3" Then
                    btnZ6TC3.BackColor = Color.Red
                    btnZ6TC3.CssClass &= " blink"
                End If
            ElseIf Z6DevTC2Count < (dt.Rows.Count) / 2 And Z6DevTC2Count > 10 Then
                If Z6TC2 = "TC1" Then
                    btnZ6TC1.BackColor = Color.Orange
                    btnZ6TC1.CssClass = btnZ6TC1.CssClass.Replace("blink", "")
                ElseIf Z6TC2 = "TC2" Then
                    btnZ6TC2.BackColor = Color.Orange
                    btnZ6TC2.CssClass = btnZ6TC2.CssClass.Replace("blink", "")
                ElseIf Z6TC2 = "TC3" Then
                    btnZ6TC3.BackColor = Color.Orange
                    btnZ6TC3.CssClass = btnZ6TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z6DevTC3Count > (dt.Rows.Count) / 2 Then
                If Z6TC3 = "TC1" Then
                    btnZ6TC1.BackColor = Color.Red
                    btnZ6TC1.CssClass &= " blink"
                ElseIf Z6TC3 = "TC2" Then
                    btnZ6TC2.BackColor = Color.Red
                    btnZ6TC2.CssClass &= " blink"
                ElseIf Z6TC3 = "TC3" Then
                    btnZ6TC3.BackColor = Color.Red
                    btnZ6TC3.CssClass &= " blink"
                End If
            ElseIf Z6DevTC3Count < (dt.Rows.Count) / 2 And Z6DevTC3Count > 10 Then
                If Z6TC3 = "TC1" Then
                    btnZ6TC1.BackColor = Color.Orange
                    btnZ6TC1.CssClass = btnZ6TC1.CssClass.Replace("blink", "")
                ElseIf Z6TC3 = "TC2" Then
                    btnZ6TC2.BackColor = Color.Orange
                    btnZ6TC2.CssClass = btnZ6TC2.CssClass.Replace("blink", "")
                ElseIf Z6TC3 = "TC3" Then
                    btnZ6TC3.BackColor = Color.Orange
                    btnZ6TC3.CssClass = btnZ6TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z7DevTC1Count > (dt.Rows.Count) / 2 Then
                If Z7TC1 = "TC1" Then
                    btnZ7TC1.BackColor = Color.Red
                    btnZ7TC1.CssClass &= " blink"
                ElseIf Z7TC1 = "TC2" Then
                    btnZ7TC2.BackColor = Color.Red
                    btnZ7TC2.CssClass &= " blink"
                ElseIf Z7TC1 = "TC3" Then
                    btnZ7TC3.BackColor = Color.Red
                    btnZ7TC3.CssClass &= " blink"
                End If
            ElseIf Z7DevTC1Count < (dt.Rows.Count) / 2 And Z7DevTC1Count > 10 Then
                If Z7TC1 = "TC1" Then
                    btnZ7TC1.BackColor = Color.Orange
                    btnZ7TC1.CssClass = btnZ7TC1.CssClass.Replace("blink", "")
                ElseIf Z7TC1 = "TC2" Then
                    btnZ7TC2.BackColor = Color.Orange
                    btnZ7TC2.CssClass = btnZ7TC2.CssClass.Replace("blink", "")
                ElseIf Z7TC1 = "TC3" Then
                    btnZ7TC3.BackColor = Color.Orange
                    btnZ7TC3.CssClass = btnZ7TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z7DevTC2Count > (dt.Rows.Count) / 2 Then
                If Z7TC2 = "TC1" Then
                    btnZ7TC1.BackColor = Color.Red
                    btnZ7TC1.CssClass &= " blink"
                ElseIf Z7TC2 = "TC2" Then
                    btnZ7TC2.BackColor = Color.Red
                    btnZ7TC2.CssClass &= " blink"
                ElseIf Z7TC2 = "TC3" Then
                    btnZ7TC3.BackColor = Color.Red
                    btnZ7TC3.CssClass &= " blink"
                End If
            ElseIf Z7DevTC2Count < (dt.Rows.Count) / 2 And Z7DevTC2Count > 10 Then
                If Z7TC2 = "TC1" Then
                    btnZ7TC1.BackColor = Color.Orange
                    btnZ7TC1.CssClass = btnZ7TC1.CssClass.Replace("blink", "")
                ElseIf Z7TC2 = "TC2" Then
                    btnZ7TC2.BackColor = Color.Orange
                    btnZ7TC2.CssClass = btnZ7TC2.CssClass.Replace("blink", "")
                ElseIf Z7TC2 = "TC3" Then
                    btnZ7TC3.BackColor = Color.Orange
                    btnZ7TC3.CssClass = btnZ7TC3.CssClass.Replace("blink", "")
                End If
            End If
            If Z7DevTC3Count > (dt.Rows.Count) / 2 Then
                If Z7TC3 = "TC1" Then
                    btnZ7TC1.BackColor = Color.Red
                    btnZ7TC1.CssClass &= " blink"
                ElseIf Z7TC3 = "TC2" Then
                    btnZ7TC2.BackColor = Color.Red
                    btnZ7TC2.CssClass &= " blink"
                ElseIf Z7TC3 = "TC3" Then
                    btnZ7TC3.BackColor = Color.Red
                    btnZ7TC3.CssClass &= " blink"
                End If
            ElseIf Z7DevTC3Count < (dt.Rows.Count) / 2 And Z7DevTC3Count > 10 Then
                If Z7TC3 = "TC1" Then
                    btnZ7TC1.BackColor = Color.Orange
                    btnZ7TC1.CssClass = btnZ7TC1.CssClass.Replace("blink", "")
                ElseIf Z7TC3 = "TC2" Then
                    btnZ7TC2.BackColor = Color.Orange
                    btnZ7TC2.CssClass = btnZ7TC2.CssClass.Replace("blink", "")
                ElseIf Z7TC3 = "TC3" Then
                    btnZ7TC3.BackColor = Color.Orange
                    btnZ7TC3.CssClass = btnZ7TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z8DevTC1Count > (dt.Rows.Count) / 2 Then
                If Z8TC1 = "TC1" Then
                    btnZ8TC1.BackColor = Color.Red
                    btnZ8TC1.CssClass &= " blink"
                ElseIf Z8TC1 = "TC2" Then
                    btnZ8TC2.BackColor = Color.Red
                    btnZ8TC2.CssClass &= " blink"
                ElseIf Z8TC1 = "TC3" Then
                    btnZ8TC3.BackColor = Color.Red
                    btnZ8TC3.CssClass &= " blink"
                End If
            ElseIf Z8DevTC1Count < (dt.Rows.Count) / 2 And Z8DevTC1Count > 10 Then
                If Z8TC1 = "TC1" Then
                    btnZ8TC1.BackColor = Color.Orange
                    btnZ8TC1.CssClass = btnZ8TC1.CssClass.Replace("blink", "")
                ElseIf Z8TC1 = "TC2" Then
                    btnZ8TC2.BackColor = Color.Orange
                    btnZ8TC2.CssClass = btnZ8TC2.CssClass.Replace("blink", "")
                ElseIf Z8TC1 = "TC3" Then
                    btnZ8TC3.BackColor = Color.Orange
                    btnZ8TC3.CssClass = btnZ8TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z8DevTC2Count > (dt.Rows.Count) / 2 Then
                If Z8TC2 = "TC1" Then
                    btnZ8TC1.BackColor = Color.Red
                    btnZ8TC1.CssClass &= " blink"
                ElseIf Z8TC2 = "TC2" Then
                    btnZ8TC2.BackColor = Color.Red
                    btnZ8TC2.CssClass &= " blink"
                ElseIf Z8TC2 = "TC3" Then
                    btnZ8TC3.BackColor = Color.Red
                    btnZ8TC3.CssClass &= " blink"
                End If
            ElseIf Z8DevTC2Count < (dt.Rows.Count) / 2 And Z8DevTC2Count > 10 Then
                If Z8TC2 = "TC1" Then
                    btnZ8TC1.BackColor = Color.Orange
                    btnZ8TC1.CssClass = btnZ8TC1.CssClass.Replace("blink", "")
                ElseIf Z8TC2 = "TC2" Then
                    btnZ8TC2.BackColor = Color.Orange
                    btnZ8TC2.CssClass = btnZ8TC2.CssClass.Replace("blink", "")
                ElseIf Z8TC2 = "TC3" Then
                    btnZ8TC3.BackColor = Color.Orange
                    btnZ8TC3.CssClass = btnZ8TC3.CssClass.Replace("blink", "")
                End If
            End If
            If Z8DevTC3Count > (dt.Rows.Count) / 2 Then
                If Z8TC3 = "TC1" Then
                    btnZ8TC1.BackColor = Color.Red
                    btnZ8TC1.CssClass &= " blink"
                ElseIf Z8TC3 = "TC2" Then
                    btnZ8TC2.BackColor = Color.Red
                    btnZ8TC2.CssClass &= " blink"
                ElseIf Z8TC3 = "TC3" Then
                    btnZ8TC3.BackColor = Color.Red
                    btnZ8TC3.CssClass &= " blink"
                End If
            ElseIf Z8DevTC3Count < (dt.Rows.Count) / 2 And Z8DevTC3Count > 10 Then
                If Z8TC3 = "TC1" Then
                    btnZ8TC1.BackColor = Color.Orange
                    btnZ8TC1.CssClass = btnZ8TC1.CssClass.Replace("blink", "")
                ElseIf Z8TC3 = "TC2" Then
                    btnZ8TC2.BackColor = Color.Orange
                    btnZ8TC2.CssClass = btnZ8TC2.CssClass.Replace("blink", "")
                ElseIf Z8TC3 = "TC3" Then
                    btnZ8TC3.BackColor = Color.Orange
                    btnZ8TC3.CssClass = btnZ8TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z9DevTC1Count > (dt.Rows.Count) / 2 Then
                If Z9TC1 = "TC1" Then
                    btnZ9TC1.BackColor = Color.Red
                    btnZ9TC1.CssClass &= " blink"
                ElseIf Z9TC1 = "TC2" Then
                    btnZ9TC2.BackColor = Color.Red
                    btnZ9TC2.CssClass &= " blink"
                ElseIf Z9TC1 = "TC3" Then
                    btnZ9TC3.BackColor = Color.Red
                    btnZ9TC3.CssClass &= " blink"
                End If
            ElseIf Z9DevTC1Count < (dt.Rows.Count) / 2 And Z9DevTC1Count > 10 Then
                If Z9TC1 = "TC1" Then
                    btnZ9TC1.BackColor = Color.Orange
                    btnZ9TC1.CssClass = btnZ9TC1.CssClass.Replace("blink", "")
                ElseIf Z9TC1 = "TC2" Then
                    btnZ9TC2.BackColor = Color.Orange
                    btnZ9TC2.CssClass = btnZ9TC2.CssClass.Replace("blink", "")
                ElseIf Z9TC1 = "TC3" Then
                    btnZ9TC3.BackColor = Color.Orange
                    btnZ9TC3.CssClass = btnZ9TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z9DevTC2Count > (dt.Rows.Count) / 2 Then
                If Z9TC2 = "TC1" Then
                    btnZ9TC1.BackColor = Color.Red
                    btnZ9TC1.CssClass &= " blink"
                ElseIf Z9TC2 = "TC2" Then
                    btnZ9TC2.BackColor = Color.Red
                    btnZ9TC2.CssClass &= " blink"
                ElseIf Z9TC2 = "TC3" Then
                    btnZ9TC3.BackColor = Color.Red
                    btnZ9TC3.CssClass &= " blink"
                End If
            ElseIf Z9DevTC2Count < (dt.Rows.Count) / 2 And Z9DevTC2Count > 10 Then
                If Z9TC2 = "TC1" Then
                    btnZ9TC1.BackColor = Color.Orange
                    btnZ9TC1.CssClass = btnZ9TC1.CssClass.Replace("blink", "")
                ElseIf Z9TC2 = "TC2" Then
                    btnZ9TC2.BackColor = Color.Orange
                    btnZ9TC2.CssClass = btnZ9TC2.CssClass.Replace("blink", "")
                ElseIf Z9TC2 = "TC3" Then
                    btnZ9TC3.BackColor = Color.Orange
                    btnZ9TC3.CssClass = btnZ9TC3.CssClass.Replace("blink", "")
                End If
            End If
            If Z9DevTC3Count > (dt.Rows.Count) / 2 Then
                If Z9TC3 = "TC1" Then
                    btnZ9TC1.BackColor = Color.Red
                    btnZ9TC1.CssClass &= " blink"
                ElseIf Z9TC3 = "TC2" Then
                    btnZ9TC2.BackColor = Color.Red
                    btnZ9TC2.CssClass &= " blink"
                ElseIf Z9TC3 = "TC3" Then
                    btnZ9TC3.BackColor = Color.Red
                    btnZ9TC3.CssClass &= " blink"
                End If
            ElseIf Z9DevTC3Count < (dt.Rows.Count) / 2 And Z9DevTC3Count > 10 Then
                If Z9TC3 = "TC1" Then
                    btnZ9TC1.BackColor = Color.Orange
                    btnZ9TC1.CssClass = btnZ9TC1.CssClass.Replace("blink", "")
                ElseIf Z9TC3 = "TC2" Then
                    btnZ9TC2.BackColor = Color.Orange
                    btnZ9TC2.CssClass = btnZ9TC2.CssClass.Replace("blink", "")
                ElseIf Z9TC3 = "TC3" Then
                    btnZ9TC3.BackColor = Color.Orange
                    btnZ9TC3.CssClass = btnZ9TC3.CssClass.Replace("blink", "")
                End If
            End If



        End If
    End Sub

    Public Sub ShowTCDeviationLineB()

        Dim sqlQuery As String = "SELECT TOP (100) [TIMESTAMP],[LINE],[ZONE1_DEV_TC1],[ZONE1_TC1_TEMP],[ZONE1_DEV_TC2],[ZONE1_TC2_TEMP]"
        sqlQuery &= " ,[ZONE1_DEV_TC3],[ZONE1_TC3_TEMP],[ZONE2_DEV_TC1],[ZONE2_TC1_TEMP],[ZONE2_DEV_TC2],[ZONE2_TC2_TEMP],[ZONE2_DEV_TC3]"
        sqlQuery &= " ,[ZONE2_TC3_TEMP],[ZONE3_DEV_TC1],[ZONE3_TC1_TEMP],[ZONE3_DEV_TC2],[ZONE3_TC2_TEMP],[ZONE3_DEV_TC3],[ZONE3_TC3_TEMP]"
        sqlQuery &= " ,[ZONE4_DEV_TC1],[ZONE4_TC1_TEMP],[ZONE4_DEV_TC2],[ZONE4_TC2_TEMP],[ZONE4_DEV_TC3],[ZONE4_TC3_TEMP],[ZONE5_DEV_TC1]"
        sqlQuery &= " ,[ZONE5_TC1_TEMP],[ZONE5_DEV_TC2],[ZONE5_TC2_TEMP],[ZONE5_DEV_TC3],[ZONE5_TC3_TEMP],[ZONE6_DEV_TC1],[ZONE6_TC1_TEMP]"
        sqlQuery &= " ,[ZONE6_DEV_TC2],[ZONE6_TC2_TEMP],[ZONE6_DEV_TC3],[ZONE6_TC3_TEMP],[ZONE7_DEV_TC1],[ZONE7_TC1_TEMP],[ZONE7_DEV_TC2]"
        sqlQuery &= " ,[ZONE7_TC2_TEMP],[ZONE7_DEV_TC3],[ZONE7_TC3_TEMP],[ZONE8_DEV_TC1],[ZONE8_TC1_TEMP],[ZONE8_DEV_TC2],[ZONE8_TC2_TEMP]"
        sqlQuery &= " ,[ZONE8_DEV_TC3],[ZONE8_TC3_TEMP]"
        ''',[ZONE9_DEV_TC1],[ZONE9_TC1_TEMP],[ZONE9_DEV_TC2],[ZONE9_TC2_TEMP],[ZONE9_DEV_TC3],[ZONE9_TC3_TEMP]
        sqlQuery &= " FROM TSCR_FURNACE_ZONE_TEMP"
        sqlQuery &= " WHERE LINE in ('B')"
        sqlQuery &= " AND TIMESTAMP > DATEADD(MINUTE, -30, (SELECT MAX(TimeStamp) FROM TSCR_FURNACE_ZONE_TEMP))"
        sqlQuery &= " ORDER BY TIMESTAMP DESC"

        Dim dt As DataTable = New DataTable()
        dt = getdatatable(sqlQuery)

        If dt.Rows.Count > 0 Then
            Dim Z1TC1, Z1TC2, Z1TC3, Z2TC1, Z2TC2, Z2TC3, Z3TC1, Z3TC2, Z3TC3, Z4TC1, Z4TC2, Z4TC3, Z5TC1, Z5TC2, Z5TC3, Z6TC1,
                Z6TC2, Z6TC3, Z7TC1, Z7TC2, Z7TC3, Z8TC1, Z8TC2, Z8TC3 As String    '', Z9TC1, Z9TC2, Z9TC3

            Dim Z1DevTC1Count, Z1DevTC2Count, Z1DevTC3Count, Z2DevTC1Count, Z2DevTC2Count, Z2DevTC3Count, Z3DevTC1Count, Z3DevTC2Count, Z3DevTC3Count, Z4DevTC1Count,
            Z4DevTC2Count, Z4DevTC3Count, Z5DevTC1Count, Z5DevTC2Count, Z5DevTC3Count, Z6DevTC1Count, Z6DevTC2Count, Z6DevTC3Count, Z7DevTC1Count, Z7DevTC2Count,
            Z7DevTC3Count, Z8DevTC1Count, Z8DevTC2Count, Z8DevTC3Count As Integer   '', Z9DevTC1Count, Z9DevTC2Count, Z9DevTC3Count



            For Each row As DataRow In dt.Rows
                If row("ZONE1_DEV_TC1") = "NO DEV" Then

                Else
                    Z1TC1 = row("ZONE1_DEV_TC1").ToString()
                    Z1DevTC1Count += 1
                End If
                If row("ZONE1_DEV_TC2") = "NO DEV" Then

                Else
                    Z1TC2 = row("ZONE1_DEV_TC2").ToString()
                    Z1DevTC2Count += 1
                End If
                If row("ZONE1_DEV_TC3") = "NO DEV" Then

                Else
                    Z1TC3 = row("ZONE1_DEV_TC3").ToString()
                    Z1DevTC3Count += 1
                End If
                If row("ZONE2_DEV_TC1") = "NO DEV" Then

                Else
                    Z2TC1 = row("ZONE2_DEV_TC1").ToString()
                    Z2DevTC1Count += 1
                End If
                If row("ZONE2_DEV_TC2") = "NO DEV" Then

                Else
                    Z2TC2 = row("ZONE2_DEV_TC2").ToString()
                    Z2DevTC2Count += 1
                End If
                If row("ZONE2_DEV_TC3") = "NO DEV" Then

                Else
                    Z2TC3 = row("ZONE2_DEV_TC3").ToString()
                    Z2DevTC3Count += 1
                End If
                If row("ZONE3_DEV_TC1") = "NO DEV" Then

                Else
                    Z3TC1 = row("ZONE3_DEV_TC1").ToString()
                    Z3DevTC1Count += 1
                End If
                If row("ZONE3_DEV_TC2") = "NO DEV" Then

                Else
                    Z3TC2 = row("ZONE3_DEV_TC2").ToString()
                    Z3DevTC2Count += 1
                End If
                If row("ZONE3_DEV_TC3") = "NO DEV" Then

                Else
                    Z3TC3 = row("ZONE3_DEV_TC3").ToString()
                    Z3DevTC3Count += 1
                End If
                If row("ZONE4_DEV_TC1") = "NO DEV" Then

                Else
                    Z4TC1 = row("ZONE4_DEV_TC1").ToString()
                    Z4DevTC1Count += 1
                End If
                If row("ZONE4_DEV_TC2") = "NO DEV" Then

                Else
                    Z4TC2 = row("ZONE4_DEV_TC2").ToString()
                    Z4DevTC2Count += 1
                End If
                If row("ZONE4_DEV_TC3") = "NO DEV" Then

                Else
                    Z4TC3 = row("ZONE4_DEV_TC3").ToString()
                    Z4DevTC3Count += 1
                End If
                If row("ZONE5_DEV_TC1") = "NO DEV" Then

                Else
                    Z5TC1 = row("ZONE5_DEV_TC1").ToString()
                    Z5DevTC1Count += 1
                End If
                If row("ZONE5_DEV_TC2") = "NO DEV" Then

                Else
                    Z5TC2 = row("ZONE5_DEV_TC2").ToString()
                    Z5DevTC2Count += 1
                End If
                If row("ZONE5_DEV_TC3") = "NO DEV" Then

                Else
                    Z5TC3 = row("ZONE5_DEV_TC3").ToString()
                    Z5DevTC3Count += 1
                End If
                If row("ZONE6_DEV_TC1") = "NO DEV" Then

                Else
                    Z6TC1 = row("ZONE6_DEV_TC1").ToString()
                    Z6DevTC1Count += 1
                End If
                If row("ZONE6_DEV_TC2") = "NO DEV" Then

                Else
                    Z6TC2 = row("ZONE6_DEV_TC2").ToString()
                    Z6DevTC2Count += 1
                End If
                If row("ZONE6_DEV_TC3") = "NO DEV" Then

                Else
                    Z6TC3 = row("ZONE6_DEV_TC3").ToString()
                    Z6DevTC3Count += 1
                End If
                If row("ZONE7_DEV_TC1") = "NO DEV" Then

                Else
                    Z7TC1 = row("ZONE7_DEV_TC1").ToString()
                    Z7DevTC1Count += 1
                End If
                If row("ZONE7_DEV_TC2") = "NO DEV" Then

                Else
                    Z7TC2 = row("ZONE7_DEV_TC2").ToString()
                    Z7DevTC2Count += 1
                End If
                If row("ZONE7_DEV_TC3") = "NO DEV" Then

                Else
                    Z7TC3 = row("ZONE7_DEV_TC3").ToString()
                    Z7DevTC3Count += 1
                End If
                If row("ZONE8_DEV_TC1") = "NO DEV" Then

                Else
                    Z8TC1 = row("ZONE8_DEV_TC1").ToString()
                    Z8DevTC1Count += 1
                End If
                If row("ZONE8_DEV_TC2") = "NO DEV" Then

                Else
                    Z8TC2 = row("ZONE8_DEV_TC2").ToString()
                    Z8DevTC2Count += 1
                End If
                If row("ZONE8_DEV_TC3") = "NO DEV" Then

                Else
                    Z8TC3 = row("ZONE8_DEV_TC3").ToString()
                    Z8DevTC3Count += 1
                End If
                ''If row("ZONE9_DEV_TC1") = "NO DEV" Then

                ''Else
                ''    Z9TC1 = row("ZONE9_DEV_TC1").ToString()
                ''    Z9DevTC1Count += 1
                ''End If
                ''If row("ZONE9_DEV_TC2") = "NO DEV" Then

                ''Else
                ''    Z9TC2 = row("ZONE9_DEV_TC2").ToString()
                ''    Z9DevTC2Count += 1
                ''End If
                ''If row("ZONE9_DEV_TC3") = "NO DEV" Then

                ''Else
                ''    Z9TC3 = row("ZONE9_DEV_TC3").ToString()
                ''    Z9DevTC3Count += 1
                ''End If
            Next row
            ''''''''''''''''''''''''''''''''''''Color Coding Acccording to Deviation Data Obtained'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            If Z1DevTC1Count > (dt.Rows.Count) / 2 Then
                If Z1TC1 = "TC1" Then
                    btnLBZ1TC1.BackColor = Color.Red
                    btnLBZ1TC1.CssClass &= " blink"
                ElseIf Z1TC1 = "TC2" Then
                    btnLBZ1TC2.BackColor = Color.Red
                    btnLBZ1TC2.CssClass &= " blink"
                ElseIf Z1TC1 = "TC3" Then
                    btnLBZ1TC3.BackColor = Color.Red
                    btnLBZ1TC3.CssClass &= " blink"
                End If
            ElseIf Z1DevTC1Count < (dt.Rows.Count) / 2 And Z1DevTC1Count > 10 Then
                If Z1TC1 = "TC1" Then
                    btnLBZ1TC1.BackColor = Color.Orange
                    btnLBZ1TC1.CssClass = btnLBZ1TC1.CssClass.Replace("blink", "")
                ElseIf Z1TC1 = "TC2" Then
                    btnLBZ1TC2.BackColor = Color.Orange
                    btnLBZ1TC2.CssClass = btnLBZ1TC2.CssClass.Replace("blink", "")
                ElseIf Z1TC1 = "TC3" Then
                    btnLBZ1TC3.BackColor = Color.Orange
                    btnLBZ1TC3.CssClass = btnLBZ1TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z1DevTC2Count > (dt.Rows.Count) / 2 Then
                If Z1TC2 = "TC1" Then
                    btnLBZ1TC1.BackColor = Color.Red
                    btnLBZ1TC1.CssClass &= " blink"
                ElseIf Z1TC2 = "TC2" Then
                    btnLBZ1TC2.BackColor = Color.Red
                    btnLBZ1TC2.CssClass &= " blink"
                ElseIf Z1TC2 = "TC3" Then
                    btnLBZ1TC3.BackColor = Color.Red
                    btnLBZ1TC3.CssClass &= " blink"
                End If
            ElseIf Z1DevTC2Count < (dt.Rows.Count) / 2 And Z1DevTC2Count > 10 Then
                If Z1TC2 = "TC1" Then
                    btnLBZ1TC1.BackColor = Color.Orange
                    btnLBZ1TC1.CssClass = btnLBZ1TC1.CssClass.Replace("blink", "")
                ElseIf Z1TC2 = "TC2" Then
                    btnLBZ1TC2.BackColor = Color.Orange
                    btnLBZ1TC2.CssClass = btnLBZ1TC2.CssClass.Replace("blink", "")
                ElseIf Z1TC2 = "TC3" Then
                    btnLBZ1TC3.BackColor = Color.Orange
                    btnLBZ1TC3.CssClass = btnLBZ1TC3.CssClass.Replace("blink", "")
                End If
            End If
            If Z1DevTC3Count > (dt.Rows.Count) / 2 Then
                If Z1TC3 = "TC1" Then
                    btnLBZ1TC1.BackColor = Color.Red
                    btnLBZ1TC1.CssClass &= " blink"
                ElseIf Z1TC3 = "TC2" Then
                    btnLBZ1TC2.BackColor = Color.Red
                    btnLBZ1TC2.CssClass &= " blink"
                ElseIf Z1TC3 = "TC3" Then
                    btnLBZ1TC3.BackColor = Color.Red
                    btnLBZ1TC3.CssClass &= " blink"
                End If
            ElseIf Z1DevTC3Count < (dt.Rows.Count) / 2 And Z1DevTC3Count > 10 Then
                If Z1TC3 = "TC1" Then
                    btnLBZ1TC1.BackColor = Color.Orange
                    btnLBZ1TC1.CssClass = btnLBZ1TC1.CssClass.Replace("blink", "")
                ElseIf Z1TC3 = "TC2" Then
                    btnLBZ1TC2.BackColor = Color.Orange
                    btnLBZ1TC2.CssClass = btnLBZ1TC2.CssClass.Replace("blink", "")
                ElseIf Z1TC3 = "TC3" Then
                    btnLBZ1TC3.BackColor = Color.Orange
                    btnLBZ1TC3.CssClass = btnLBZ1TC3.CssClass.Replace("blink", "")
                End If
            End If


            If Z2DevTC1Count > (dt.Rows.Count) / 2 Then
                If Z2TC1 = "TC1" Then
                    btnLBZ2TC1.BackColor = Color.Red
                    btnLBZ2TC1.CssClass &= " blink"
                ElseIf Z2TC1 = "TC2" Then
                    btnLBZ2TC2.BackColor = Color.Red
                    btnLBZ2TC2.CssClass &= " blink"
                ElseIf Z2TC1 = "TC3" Then
                    btnLBZ2TC3.BackColor = Color.Red
                    btnLBZ2TC3.CssClass &= " blink"
                End If
            ElseIf Z2DevTC1Count < (dt.Rows.Count) / 2 And Z2DevTC1Count > 10 Then
                If Z2TC1 = "TC1" Then
                    btnLBZ2TC1.BackColor = Color.Orange
                    btnLBZ2TC1.CssClass = btnLBZ2TC1.CssClass.Replace("blink", "")
                ElseIf Z2TC1 = "TC2" Then
                    btnLBZ2TC2.BackColor = Color.Orange
                    btnLBZ2TC2.CssClass = btnLBZ2TC2.CssClass.Replace("blink", "")
                ElseIf Z2TC1 = "TC3" Then
                    btnLBZ2TC3.BackColor = Color.Orange
                    btnLBZ2TC3.CssClass = btnLBZ2TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z2DevTC2Count > (dt.Rows.Count) / 2 Then
                If Z2TC2 = "TC1" Then
                    btnLBZ2TC1.BackColor = Color.Red
                    btnLBZ2TC1.CssClass &= " blink"
                ElseIf Z2TC2 = "TC2" Then
                    btnLBZ2TC2.BackColor = Color.Red
                    btnLBZ2TC2.CssClass &= " blink"
                ElseIf Z2TC2 = "TC3" Then
                    btnLBZ2TC3.BackColor = Color.Red
                    btnLBZ2TC3.CssClass &= " blink"
                End If
            ElseIf Z2DevTC2Count < (dt.Rows.Count) / 2 And Z2DevTC2Count > 10 Then
                If Z2TC2 = "TC1" Then
                    btnLBZ2TC1.BackColor = Color.Orange
                    btnLBZ2TC1.CssClass = btnLBZ2TC1.CssClass.Replace("blink", "")
                ElseIf Z2TC2 = "TC2" Then
                    btnLBZ2TC2.BackColor = Color.Orange
                    btnLBZ2TC2.CssClass = btnLBZ2TC2.CssClass.Replace("blink", "")
                ElseIf Z2TC2 = "TC3" Then
                    btnLBZ2TC3.BackColor = Color.Orange
                    btnLBZ2TC3.CssClass = btnLBZ2TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z2DevTC3Count > (dt.Rows.Count) / 2 Then
                If Z2TC3 = "TC1" Then
                    btnLBZ2TC1.BackColor = Color.Red
                    btnLBZ2TC1.CssClass &= " blink"
                ElseIf Z2TC3 = "TC2" Then
                    btnLBZ2TC2.BackColor = Color.Red
                    btnLBZ2TC2.CssClass &= " blink"
                ElseIf Z2TC3 = "TC3" Then
                    btnLBZ2TC3.BackColor = Color.Red
                    btnLBZ2TC3.CssClass &= " blink"
                End If
            ElseIf Z2DevTC3Count < (dt.Rows.Count) / 2 And Z2DevTC3Count > 10 Then
                If Z2TC3 = "TC1" Then
                    btnLBZ2TC1.BackColor = Color.Orange
                    btnLBZ2TC1.CssClass = btnLBZ2TC1.CssClass.Replace("blink", "")
                ElseIf Z2TC3 = "TC2" Then
                    btnLBZ2TC2.BackColor = Color.Orange
                    btnLBZ2TC2.CssClass = btnLBZ2TC2.CssClass.Replace("blink", "")
                ElseIf Z2TC3 = "TC3" Then
                    btnLBZ2TC3.BackColor = Color.Orange
                    btnLBZ2TC3.CssClass = btnLBZ2TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z3DevTC1Count > (dt.Rows.Count) / 2 Then
                If Z3TC1 = "TC1" Then
                    btnLBZ3TC1.BackColor = Color.Red
                    btnLBZ3TC1.CssClass &= " blink"
                ElseIf Z3TC1 = "TC2" Then
                    btnLBZ3TC2.BackColor = Color.Red
                    btnLBZ3TC2.CssClass &= " blink"
                ElseIf Z3TC1 = "TC3" Then
                    btnLBZ3TC3.BackColor = Color.Red
                    btnLBZ3TC3.CssClass &= " blink"
                End If
            ElseIf Z3DevTC1Count < (dt.Rows.Count) / 2 And Z3DevTC1Count > 10 Then
                If Z3TC1 = "TC1" Then
                    btnLBZ3TC1.BackColor = Color.Orange
                    btnLBZ3TC1.CssClass = btnLBZ3TC1.CssClass.Replace("blink", "")
                ElseIf Z3TC1 = "TC2" Then
                    btnLBZ3TC2.BackColor = Color.Orange
                    btnLBZ3TC2.CssClass = btnLBZ3TC2.CssClass.Replace("blink", "")
                ElseIf Z3TC1 = "TC3" Then
                    btnLBZ3TC3.BackColor = Color.Orange
                    btnLBZ3TC3.CssClass = btnLBZ3TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z3DevTC2Count > (dt.Rows.Count) / 2 Then
                If Z3TC2 = "TC1" Then
                    btnLBZ3TC1.BackColor = Color.Red
                    btnLBZ3TC1.CssClass &= " blink"
                ElseIf Z3TC2 = "TC2" Then
                    btnLBZ3TC2.BackColor = Color.Red
                    btnLBZ3TC2.CssClass &= " blink"
                ElseIf Z3TC2 = "TC3" Then
                    btnLBZ3TC3.BackColor = Color.Red
                    btnLBZ3TC3.CssClass &= " blink"
                End If
            ElseIf Z3DevTC2Count < (dt.Rows.Count) / 2 And Z3DevTC2Count > 10 Then
                If Z3TC2 = "TC1" Then
                    btnLBZ3TC1.BackColor = Color.Orange
                    btnLBZ3TC1.CssClass = btnLBZ3TC1.CssClass.Replace("blink", "")
                ElseIf Z3TC2 = "TC2" Then
                    btnLBZ3TC2.BackColor = Color.Orange
                    btnLBZ3TC2.CssClass = btnLBZ3TC2.CssClass.Replace("blink", "")
                ElseIf Z3TC2 = "TC3" Then
                    btnLBZ3TC3.BackColor = Color.Orange
                    btnLBZ3TC3.CssClass = btnLBZ3TC3.CssClass.Replace("blink", "")
                End If
            End If
            If Z3DevTC3Count > (dt.Rows.Count) / 2 Then
                If Z3TC3 = "TC1" Then
                    btnLBZ3TC1.BackColor = Color.Red
                    btnLBZ3TC1.CssClass &= " blink"
                ElseIf Z3TC3 = "TC2" Then
                    btnLBZ3TC2.BackColor = Color.Red
                    btnLBZ3TC2.CssClass &= " blink"
                ElseIf Z3TC3 = "TC3" Then
                    btnLBZ3TC3.BackColor = Color.Red
                    btnLBZ3TC3.CssClass &= " blink"
                End If
            ElseIf Z3DevTC3Count < (dt.Rows.Count) / 2 And Z3DevTC3Count > 10 Then
                If Z3TC3 = "TC1" Then
                    btnLBZ3TC1.BackColor = Color.Orange
                    btnLBZ3TC1.CssClass = btnLBZ3TC1.CssClass.Replace("blink", "")
                ElseIf Z3TC3 = "TC2" Then
                    btnLBZ3TC2.BackColor = Color.Orange
                    btnLBZ3TC2.CssClass = btnLBZ3TC2.CssClass.Replace("blink", "")
                ElseIf Z3TC3 = "TC3" Then
                    btnLBZ3TC3.BackColor = Color.Orange
                    btnLBZ3TC3.CssClass = btnLBZ3TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z4DevTC1Count > (dt.Rows.Count) / 2 Then
                If Z4TC1 = "TC1" Then
                    btnLBZ4TC1.BackColor = Color.Red
                    btnLBZ4TC1.CssClass &= " blink"
                ElseIf Z4TC1 = "TC2" Then
                    btnLBZ4TC2.BackColor = Color.Red
                    btnLBZ4TC2.CssClass &= " blink"
                ElseIf Z4TC1 = "TC3" Then
                    btnLBZ4TC3.BackColor = Color.Red
                    btnLBZ4TC3.CssClass &= " blink"
                End If
            ElseIf Z4DevTC1Count < (dt.Rows.Count) / 2 And Z4DevTC1Count > 10 Then
                If Z4TC1 = "TC1" Then
                    btnLBZ4TC1.BackColor = Color.Orange
                    btnLBZ4TC1.CssClass = btnLBZ4TC1.CssClass.Replace("blink", "")
                ElseIf Z4TC1 = "TC2" Then
                    btnLBZ4TC2.BackColor = Color.Orange
                    btnLBZ4TC2.CssClass = btnLBZ4TC2.CssClass.Replace("blink", "")
                ElseIf Z4TC1 = "TC3" Then
                    btnLBZ4TC3.BackColor = Color.Orange
                    btnLBZ4TC3.CssClass = btnLBZ4TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z4DevTC2Count > (dt.Rows.Count) / 2 Then
                If Z4TC2 = "TC1" Then
                    btnLBZ4TC1.BackColor = Color.Red
                    btnLBZ4TC1.CssClass &= " blink"
                ElseIf Z4TC2 = "TC2" Then
                    btnLBZ4TC2.BackColor = Color.Red
                    btnLBZ4TC2.CssClass &= " blink"
                ElseIf Z4TC2 = "TC3" Then
                    btnLBZ4TC3.BackColor = Color.Red
                    btnLBZ4TC3.CssClass &= " blink"
                End If
            ElseIf Z4DevTC2Count < (dt.Rows.Count) / 2 And Z4DevTC2Count > 10 Then
                If Z4TC2 = "TC1" Then
                    btnLBZ4TC1.BackColor = Color.Orange
                    btnLBZ4TC1.CssClass = btnLBZ4TC1.CssClass.Replace("blink", "")
                ElseIf Z4TC2 = "TC2" Then
                    btnLBZ4TC2.BackColor = Color.Orange
                    btnLBZ4TC2.CssClass = btnLBZ4TC2.CssClass.Replace("blink", "")
                ElseIf Z4TC2 = "TC3" Then
                    btnLBZ4TC3.BackColor = Color.Orange
                    btnLBZ4TC3.CssClass = btnLBZ4TC3.CssClass.Replace("blink", "")
                End If
            End If
            If Z4DevTC3Count > (dt.Rows.Count) / 2 Then
                If Z4TC3 = "TC1" Then
                    btnLBZ4TC1.BackColor = Color.Red
                    btnLBZ4TC1.CssClass &= " blink"
                ElseIf Z4TC3 = "TC2" Then
                    btnLBZ4TC2.BackColor = Color.Red
                    btnLBZ4TC2.CssClass &= " blink"
                ElseIf Z4TC3 = "TC3" Then
                    btnLBZ4TC3.BackColor = Color.Red
                    btnLBZ4TC3.CssClass &= " blink"
                End If
            ElseIf Z4DevTC3Count < (dt.Rows.Count) / 2 And Z4DevTC3Count > 10 Then
                If Z4TC3 = "TC1" Then
                    btnLBZ4TC1.BackColor = Color.Orange
                    btnLBZ4TC1.CssClass = btnLBZ4TC1.CssClass.Replace("blink", "")
                ElseIf Z4TC3 = "TC2" Then
                    btnLBZ4TC2.BackColor = Color.Orange
                    btnLBZ4TC2.CssClass = btnLBZ4TC2.CssClass.Replace("blink", "")
                ElseIf Z4TC3 = "TC3" Then
                    btnLBZ4TC3.BackColor = Color.Orange
                    btnLBZ4TC3.CssClass = btnLBZ4TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z5DevTC1Count > (dt.Rows.Count) / 2 Then
                If Z5TC1 = "TC1" Then
                    btnLBZ5TC1.BackColor = Color.Red
                    btnLBZ5TC1.CssClass &= " blink"
                ElseIf Z5TC1 = "TC2" Then
                    btnLBZ5TC2.BackColor = Color.Red
                    btnLBZ5TC2.CssClass &= " blink"
                ElseIf Z5TC1 = "TC3" Then
                    btnLBZ5TC3.BackColor = Color.Red
                    btnLBZ5TC3.CssClass &= " blink"
                End If
            ElseIf Z5DevTC1Count < (dt.Rows.Count) / 2 And Z5DevTC1Count > 10 Then
                If Z5TC1 = "TC1" Then
                    btnLBZ5TC1.BackColor = Color.Orange
                    btnLBZ5TC1.CssClass = btnLBZ5TC1.CssClass.Replace("blink", "")
                ElseIf Z5TC1 = "TC2" Then
                    btnLBZ5TC2.BackColor = Color.Orange
                    btnLBZ5TC2.CssClass = btnLBZ5TC2.CssClass.Replace("blink", "")
                ElseIf Z5TC1 = "TC3" Then
                    btnLBZ5TC3.BackColor = Color.Orange
                    btnLBZ5TC3.CssClass = btnLBZ5TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z5DevTC2Count > (dt.Rows.Count) / 2 Then
                If Z5TC2 = "TC1" Then
                    btnLBZ5TC1.BackColor = Color.Red
                    btnLBZ5TC1.CssClass &= " blink"
                ElseIf Z5TC2 = "TC2" Then
                    btnLBZ5TC2.BackColor = Color.Red
                    btnLBZ5TC2.CssClass &= " blink"
                ElseIf Z5TC2 = "TC3" Then
                    btnLBZ5TC3.BackColor = Color.Red
                    btnLBZ5TC3.CssClass &= " blink"
                End If
            ElseIf Z5DevTC2Count < (dt.Rows.Count) / 2 And Z5DevTC2Count > 10 Then
                If Z5TC2 = "TC1" Then
                    btnLBZ5TC1.BackColor = Color.Orange
                    btnLBZ5TC1.CssClass = btnLBZ5TC1.CssClass.Replace("blink", "")
                ElseIf Z5TC2 = "TC2" Then
                    btnLBZ5TC2.BackColor = Color.Orange
                    btnLBZ5TC2.CssClass = btnLBZ5TC2.CssClass.Replace("blink", "")
                ElseIf Z5TC2 = "TC3" Then
                    btnLBZ5TC3.BackColor = Color.Orange
                    btnLBZ5TC3.CssClass = btnLBZ5TC3.CssClass.Replace("blink", "")
                End If
            End If
            If Z5DevTC3Count > (dt.Rows.Count) / 2 Then
                If Z5TC3 = "TC1" Then
                    btnLBZ5TC1.BackColor = Color.Red
                    btnLBZ5TC1.CssClass &= " blink"
                ElseIf Z5TC3 = "TC2" Then
                    btnLBZ5TC2.BackColor = Color.Red
                    btnLBZ5TC2.CssClass &= " blink"
                ElseIf Z5TC3 = "TC3" Then
                    btnLBZ5TC3.BackColor = Color.Red
                    btnLBZ5TC3.CssClass &= " blink"
                End If
            ElseIf Z5DevTC3Count < (dt.Rows.Count) / 2 And Z5DevTC3Count > 10 Then
                If Z5TC3 = "TC1" Then
                    btnLBZ5TC1.BackColor = Color.Orange
                    btnLBZ5TC1.CssClass = btnLBZ5TC1.CssClass.Replace("blink", "")
                ElseIf Z5TC3 = "TC2" Then
                    btnLBZ5TC2.BackColor = Color.Orange
                    btnLBZ5TC2.CssClass = btnLBZ5TC2.CssClass.Replace("blink", "")
                ElseIf Z5TC3 = "TC3" Then
                    btnLBZ5TC3.BackColor = Color.Orange
                    btnLBZ5TC3.CssClass = btnLBZ5TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z6DevTC1Count > (dt.Rows.Count) / 2 Then
                If Z6TC1 = "TC1" Then
                    btnLBZ6TC1.BackColor = Color.Red
                    btnLBZ6TC1.CssClass &= " blink"
                ElseIf Z6TC1 = "TC2" Then
                    btnLBZ6TC2.BackColor = Color.Red
                    btnLBZ6TC2.CssClass &= " blink"
                ElseIf Z6TC1 = "TC3" Then
                    btnLBZ6TC3.BackColor = Color.Red
                    btnLBZ6TC3.CssClass &= " blink"
                End If
            ElseIf Z6DevTC1Count < (dt.Rows.Count) / 2 And Z6DevTC1Count > 10 Then
                If Z6TC1 = "TC1" Then
                    btnLBZ6TC1.BackColor = Color.Orange
                    btnLBZ6TC1.CssClass = btnLBZ6TC1.CssClass.Replace("blink", "")
                ElseIf Z6TC1 = "TC2" Then
                    btnLBZ6TC2.BackColor = Color.Orange
                    btnLBZ6TC2.CssClass = btnLBZ6TC2.CssClass.Replace("blink", "")
                ElseIf Z6TC1 = "TC3" Then
                    btnLBZ6TC3.BackColor = Color.Orange
                    btnLBZ6TC3.CssClass = btnLBZ6TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z6DevTC2Count > (dt.Rows.Count) / 2 Then
                If Z6TC2 = "TC1" Then
                    btnLBZ6TC1.BackColor = Color.Red
                    btnLBZ6TC1.CssClass &= " blink"
                ElseIf Z6TC2 = "TC2" Then
                    btnLBZ6TC2.BackColor = Color.Red
                    btnLBZ6TC2.CssClass &= " blink"
                ElseIf Z6TC2 = "TC3" Then
                    btnLBZ6TC3.BackColor = Color.Red
                    btnLBZ6TC3.CssClass &= " blink"
                End If
            ElseIf Z6DevTC2Count < (dt.Rows.Count) / 2 And Z6DevTC2Count > 10 Then
                If Z6TC2 = "TC1" Then
                    btnLBZ6TC1.BackColor = Color.Orange
                    btnLBZ6TC1.CssClass = btnLBZ6TC1.CssClass.Replace("blink", "")
                ElseIf Z6TC2 = "TC2" Then
                    btnLBZ6TC2.BackColor = Color.Orange
                    btnLBZ6TC2.CssClass = btnLBZ6TC2.CssClass.Replace("blink", "")
                ElseIf Z6TC2 = "TC3" Then
                    btnLBZ6TC3.BackColor = Color.Orange
                    btnLBZ6TC3.CssClass = btnLBZ6TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z6DevTC3Count > (dt.Rows.Count) / 2 Then
                If Z6TC3 = "TC1" Then
                    btnLBZ6TC1.BackColor = Color.Red
                    btnLBZ6TC1.CssClass &= " blink"
                ElseIf Z6TC3 = "TC2" Then
                    btnLBZ6TC2.BackColor = Color.Red
                    btnLBZ6TC2.CssClass &= " blink"
                ElseIf Z6TC3 = "TC3" Then
                    btnLBZ6TC3.BackColor = Color.Red
                    btnLBZ6TC3.CssClass &= " blink"
                End If
            ElseIf Z6DevTC3Count < (dt.Rows.Count) / 2 And Z6DevTC3Count > 10 Then
                If Z6TC3 = "TC1" Then
                    btnLBZ6TC1.BackColor = Color.Orange
                    btnLBZ6TC1.CssClass = btnLBZ6TC1.CssClass.Replace("blink", "")
                ElseIf Z6TC3 = "TC2" Then
                    btnLBZ6TC2.BackColor = Color.Orange
                    btnLBZ6TC2.CssClass = btnLBZ6TC2.CssClass.Replace("blink", "")
                ElseIf Z6TC3 = "TC3" Then
                    btnLBZ6TC3.BackColor = Color.Orange
                    btnLBZ6TC3.CssClass = btnLBZ6TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z7DevTC1Count > (dt.Rows.Count) / 2 Then
                If Z7TC1 = "TC1" Then
                    btnLBZ7TC1.BackColor = Color.Red
                    btnLBZ7TC1.CssClass &= " blink"
                ElseIf Z7TC1 = "TC2" Then
                    btnLBZ7TC2.BackColor = Color.Red
                    btnLBZ7TC2.CssClass &= " blink"
                ElseIf Z7TC1 = "TC3" Then
                    btnLBZ7TC3.BackColor = Color.Red
                    btnLBZ7TC3.CssClass &= " blink"
                End If
            ElseIf Z7DevTC1Count < (dt.Rows.Count) / 2 And Z7DevTC1Count > 10 Then
                If Z7TC1 = "TC1" Then
                    btnLBZ7TC1.BackColor = Color.Orange
                    btnLBZ7TC1.CssClass = btnLBZ7TC1.CssClass.Replace("blink", "")
                ElseIf Z7TC1 = "TC2" Then
                    btnLBZ7TC2.BackColor = Color.Orange
                    btnLBZ7TC2.CssClass = btnLBZ7TC2.CssClass.Replace("blink", "")
                ElseIf Z7TC1 = "TC3" Then
                    btnLBZ7TC3.BackColor = Color.Orange
                    btnLBZ7TC3.CssClass = btnLBZ7TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z7DevTC2Count > (dt.Rows.Count) / 2 Then
                If Z7TC2 = "TC1" Then
                    btnLBZ7TC1.BackColor = Color.Red
                    btnLBZ7TC1.CssClass &= " blink"
                ElseIf Z7TC2 = "TC2" Then
                    btnLBZ7TC2.BackColor = Color.Red
                    btnLBZ7TC2.CssClass &= " blink"
                ElseIf Z7TC2 = "TC3" Then
                    btnLBZ7TC3.BackColor = Color.Red
                    btnLBZ7TC3.CssClass &= " blink"
                End If
            ElseIf Z7DevTC2Count < (dt.Rows.Count) / 2 And Z7DevTC2Count > 10 Then
                If Z7TC2 = "TC1" Then
                    btnLBZ7TC1.BackColor = Color.Orange
                    btnLBZ7TC1.CssClass = btnLBZ7TC1.CssClass.Replace("blink", "")
                ElseIf Z7TC2 = "TC2" Then
                    btnLBZ7TC2.BackColor = Color.Orange
                    btnLBZ7TC2.CssClass = btnLBZ7TC2.CssClass.Replace("blink", "")
                ElseIf Z7TC2 = "TC3" Then
                    btnLBZ7TC3.BackColor = Color.Orange
                    btnLBZ7TC3.CssClass = btnLBZ7TC3.CssClass.Replace("blink", "")
                End If
            End If
            If Z7DevTC3Count > (dt.Rows.Count) / 2 Then
                If Z7TC3 = "TC1" Then
                    btnLBZ7TC1.BackColor = Color.Red
                    btnLBZ7TC1.CssClass &= " blink"
                ElseIf Z7TC3 = "TC2" Then
                    btnLBZ7TC2.BackColor = Color.Red
                    btnLBZ7TC2.CssClass &= " blink"
                ElseIf Z7TC3 = "TC3" Then
                    btnLBZ7TC3.BackColor = Color.Red
                    btnLBZ7TC3.CssClass &= " blink"
                End If
            ElseIf Z7DevTC3Count < (dt.Rows.Count) / 2 And Z7DevTC3Count > 10 Then
                If Z7TC3 = "TC1" Then
                    btnLBZ7TC1.BackColor = Color.Orange
                    btnLBZ7TC1.CssClass = btnLBZ7TC1.CssClass.Replace("blink", "")
                ElseIf Z7TC3 = "TC2" Then
                    btnLBZ7TC2.BackColor = Color.Orange
                    btnLBZ7TC2.CssClass = btnLBZ7TC2.CssClass.Replace("blink", "")
                ElseIf Z7TC3 = "TC3" Then
                    btnLBZ7TC3.BackColor = Color.Orange
                    btnLBZ7TC3.CssClass = btnLBZ7TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z8DevTC1Count > (dt.Rows.Count) / 2 Then
                If Z8TC1 = "TC1" Then
                    btnLBZ8TC1.BackColor = Color.Red
                    btnLBZ8TC1.CssClass &= " blink"
                ElseIf Z8TC1 = "TC2" Then
                    btnLBZ8TC2.BackColor = Color.Red
                    btnLBZ8TC2.CssClass &= " blink"
                ElseIf Z8TC1 = "TC3" Then
                    btnLBZ8TC3.BackColor = Color.Red
                    btnLBZ8TC3.CssClass &= " blink"
                End If
            ElseIf Z8DevTC1Count < (dt.Rows.Count) / 2 And Z8DevTC1Count > 10 Then
                If Z8TC1 = "TC1" Then
                    btnLBZ8TC1.BackColor = Color.Orange
                    btnLBZ8TC1.CssClass = btnLBZ8TC1.CssClass.Replace("blink", "")
                ElseIf Z8TC1 = "TC2" Then
                    btnLBZ8TC2.BackColor = Color.Orange
                    btnLBZ8TC2.CssClass = btnLBZ8TC2.CssClass.Replace("blink", "")
                ElseIf Z8TC1 = "TC3" Then
                    btnLBZ8TC3.BackColor = Color.Orange
                    btnLBZ8TC3.CssClass = btnLBZ8TC3.CssClass.Replace("blink", "")
                End If
            End If

            If Z8DevTC2Count > (dt.Rows.Count) / 2 Then
                If Z8TC2 = "TC1" Then
                    btnLBZ8TC1.BackColor = Color.Red
                    btnLBZ8TC1.CssClass &= " blink"
                ElseIf Z8TC2 = "TC2" Then
                    btnLBZ8TC2.BackColor = Color.Red
                    btnLBZ8TC2.CssClass &= " blink"
                ElseIf Z8TC2 = "TC3" Then
                    btnLBZ8TC3.BackColor = Color.Red
                    btnLBZ8TC3.CssClass &= " blink"
                End If
            ElseIf Z8DevTC2Count < (dt.Rows.Count) / 2 And Z8DevTC2Count > 10 Then
                If Z8TC2 = "TC1" Then
                    btnLBZ8TC1.BackColor = Color.Orange
                    btnLBZ8TC1.CssClass = btnLBZ8TC1.CssClass.Replace("blink", "")
                ElseIf Z8TC2 = "TC2" Then
                    btnLBZ8TC2.BackColor = Color.Orange
                    btnLBZ8TC2.CssClass = btnLBZ8TC2.CssClass.Replace("blink", "")
                ElseIf Z8TC2 = "TC3" Then
                    btnLBZ8TC3.BackColor = Color.Orange
                    btnLBZ8TC3.CssClass = btnLBZ8TC3.CssClass.Replace("blink", "")
                End If
            End If
            If Z8DevTC3Count > (dt.Rows.Count) / 2 Then
                If Z8TC3 = "TC1" Then
                    btnLBZ8TC1.BackColor = Color.Red
                    btnLBZ8TC1.CssClass &= " blink"
                ElseIf Z8TC3 = "TC2" Then
                    btnLBZ8TC2.BackColor = Color.Red
                    btnLBZ8TC2.CssClass &= " blink"
                ElseIf Z8TC3 = "TC3" Then
                    btnLBZ8TC3.BackColor = Color.Red
                    btnLBZ8TC3.CssClass &= " blink"
                End If
            ElseIf Z8DevTC3Count < (dt.Rows.Count) / 2 And Z8DevTC3Count > 10 Then
                If Z8TC3 = "TC1" Then
                    btnLBZ8TC1.BackColor = Color.Orange
                    btnLBZ8TC1.CssClass = btnLBZ8TC1.CssClass.Replace("blink", "")
                ElseIf Z8TC3 = "TC2" Then
                    btnLBZ8TC2.BackColor = Color.Orange
                    btnLBZ8TC2.CssClass = btnLBZ8TC2.CssClass.Replace("blink", "")
                ElseIf Z8TC3 = "TC3" Then
                    btnLBZ8TC3.BackColor = Color.Orange
                    btnLBZ8TC3.CssClass = btnLBZ8TC3.CssClass.Replace("blink", "")
                End If
            End If

        End If
    End Sub

    Public Sub ActualPredictionLineAZ1TC1()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE1_TC1,ZONE1_TC1_PRED"
        Dim LineName As String = "A"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LAZ1TC1, "ZONE1_TC1", "ZONE1_TC1_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitZ1TC1Zone, "contLAZ1TC1", "plot6", "chart1", "Z1TC1Actual", "Z1TC1Prediction", "Threshold", "ZONE1_TC1", "ZONE1_TC1_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineAZ1TC2()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE1_TC2,ZONE1_TC2_PRED"
        Dim LineName As String = "A"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LAZ1TC2, "ZONE1_TC2", "ZONE1_TC2_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitZ1TC2Zone, "contLAZ1TC2", "plot7", "chart1", "Z1TC2Actual", "Z1TC2Prediction", "Threshold", "ZONE1_TC2", "ZONE1_TC2_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineAZ1TC3()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE1_TC3,ZONE1_TC3_PRED"
        Dim LineName As String = "A"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LAZ1TC3, "ZONE1_TC3", "ZONE1_TC3_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitZ1TC3Zone, "contLAZ1TC3", "plot8", "chart1", "Z1TC3Actual", "Z1TC3Prediction", "Threshold", "ZONE1_TC3", "ZONE1_TC3_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineAZ2TC1()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE2_TC1,ZONE2_TC1_PRED"
        Dim LineName As String = "A"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LAZ2TC1, "ZONE2_TC1", "ZONE2_TC1_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitZ2TC1Zone, "contLAZ2TC1", "plot9", "chart1", "Z2TC1Actual", "Z2TC1Prediction", "Threshold", "ZONE2_TC1", "ZONE2_TC1_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineAZ2TC2()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE2_TC2,ZONE2_TC2_PRED"
        Dim LineName As String = "A"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LAZ2TC2, "ZONE2_TC2", "ZONE2_TC2_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitZ2TC2Zone, "contLAZ2TC2", "plot10", "chart1", "Z2TC2Actual", "Z2TC2Prediction", "Threshold", "ZONE2_TC2", "ZONE2_TC2_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineAZ2TC3()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE2_TC3,ZONE2_TC3_PRED"
        Dim LineName As String = "A"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LAZ2TC3, "ZONE2_TC3", "ZONE2_TC3_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitZ2TC3Zone, "contLAZ2TC3", "plot11", "chart1", "Z2TC3Actual", "Z2TC3Prediction", "Threshold", "ZONE2_TC3", "ZONE2_TC3_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineAZ3TC1()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE3_TC1,ZONE3_TC1_PRED"
        Dim LineName As String = "A"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LAZ3TC1, "ZONE3_TC1", "ZONE3_TC1_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitZ3TC1Zone, "contLAZ3TC1", "plot12", "chart1", "Z3TC1Actual", "Z3TC1Prediction", "Threshold", "ZONE3_TC1", "ZONE3_TC1_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineAZ3TC2()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE3_TC2,ZONE3_TC2_PRED"
        Dim LineName As String = "A"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LAZ3TC2, "ZONE3_TC2", "ZONE3_TC2_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitZ3TC2Zone, "contLAZ3TC2", "plot13", "chart1", "Z3TC2Actual", "Z3TC2Prediction", "Threshold", "ZONE3_TC2", "ZONE3_TC2_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineAZ3TC3()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE3_TC3,ZONE3_TC3_PRED"
        Dim LineName As String = "A"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LAZ3TC3, "ZONE3_TC3", "ZONE3_TC3_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitZ3TC3Zone, "contLAZ3TC3", "plot14", "chart1", "Z3TC3Actual", "Z3TC3Prediction", "Threshold", "ZONE3_TC3", "ZONE3_TC3_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineAZ4TC1()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE4_TC1,ZONE4_TC1_PRED"
        Dim LineName As String = "A"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LAZ4TC1, "ZONE4_TC1", "ZONE4_TC1_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitZ4TC1Zone, "contLAZ4TC1", "plot15", "chart1", "Z4TC1Actual", "Z4TC1Prediction", "Threshold", "ZONE4_TC1", "ZONE4_TC1_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineAZ4TC2()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE4_TC2,ZONE4_TC2_PRED"
        Dim LineName As String = "A"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LAZ4TC2, "ZONE4_TC2", "ZONE4_TC2_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitZ4TC2Zone, "contLAZ4TC2", "plot16", "chart1", "Z4TC2Actual", "Z4TC2Prediction", "Threshold", "ZONE4_TC2", "ZONE4_TC2_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineAZ4TC3()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE4_TC3,ZONE4_TC3_PRED"
        Dim LineName As String = "A"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LAZ4TC3, "ZONE4_TC3", "ZONE4_TC3_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitZ4TC3Zone, "contLAZ4TC3", "plot17", "chart1", "Z4TC3Actual", "Z4TC3Prediction", "Threshold", "ZONE4_TC3", "ZONE4_TC3_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineAZ5TC1()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE5_TC1,ZONE5_TC1_PRED"
        Dim LineName As String = "A"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LAZ5TC1, "ZONE5_TC1", "ZONE5_TC1_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitZ5TC1Zone, "contLAZ5TC1", "plot18", "chart1", "Z5TC1Actual", "Z5TC1Prediction", "Threshold", "ZONE5_TC1", "ZONE5_TC1_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineAZ5TC2()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE5_TC2,ZONE5_TC2_PRED"
        Dim LineName As String = "A"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LAZ5TC2, "ZONE5_TC2", "ZONE5_TC2_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitZ5TC2Zone, "contLAZ5TC2", "plot19", "chart1", "Z5TC2Actual", "Z5TC2Prediction", "Threshold", "ZONE5_TC2", "ZONE5_TC2_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineAZ5TC3()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE5_TC3,ZONE5_TC3_PRED"
        Dim LineName As String = "A"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LAZ5TC3, "ZONE5_TC3", "ZONE5_TC3_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitZ5TC3Zone, "contLAZ5TC3", "plot20", "chart1", "Z5TC3Actual", "Z5TC3Prediction", "Threshold", "ZONE5_TC3", "ZONE5_TC3_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineAZ6TC1()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE6_TC1,ZONE6_TC1_PRED"
        Dim LineName As String = "A"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LAZ6TC1, "ZONE6_TC1", "ZONE6_TC1_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitZ6TC1Zone, "contLAZ6TC1", "plot21", "chart1", "Z6TC1Actual", "Z6TC1Prediction", "Threshold", "ZONE6_TC1", "ZONE6_TC1_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineAZ6TC2()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE6_TC2,ZONE6_TC2_PRED"
        Dim LineName As String = "A"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LAZ6TC2, "ZONE6_TC2", "ZONE6_TC2_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitZ6TC2Zone, "contLAZ6TC2", "plot22", "chart1", "Z6TC2Actual", "Z6TC2Prediction", "Threshold", "ZONE6_TC2", "ZONE6_TC2_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineAZ6TC3()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE6_TC3,ZONE6_TC3_PRED"
        Dim LineName As String = "A"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LAZ6TC3, "ZONE6_TC3", "ZONE6_TC3_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitZ6TC3Zone, "contLAZ6TC3", "plot23", "chart1", "Z6TC3Actual", "Z6TC3Prediction", "Threshold", "ZONE6_TC3", "ZONE6_TC3_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineAZ7TC1()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE7_TC1,ZONE7_TC1_PRED"
        Dim LineName As String = "A"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LAZ7TC1, "ZONE7_TC1", "ZONE7_TC1_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitZ7TC1Zone, "contLAZ7TC1", "plot24", "chart1", "Z7TC1Actual", "Z7TC1Prediction", "Threshold", "ZONE7_TC1", "ZONE7_TC1_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineAZ7TC2()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE7_TC2,ZONE7_TC2_PRED"
        Dim LineName As String = "A"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LAZ7TC2, "ZONE7_TC2", "ZONE7_TC2_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitZ7TC2Zone, "contLAZ7TC2", "plot25", "chart1", "Z7TC2Actual", "Z7TC2Prediction", "Threshold", "ZONE7_TC2", "ZONE7_TC2_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineAZ7TC3()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE7_TC3,ZONE7_TC3_PRED"
        Dim LineName As String = "A"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LAZ7TC3, "ZONE7_TC3", "ZONE7_TC3_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitZ7TC3Zone, "contLAZ7TC3", "plot26", "chart1", "Z7TC3Actual", "Z7TC3Prediction", "Threshold", "ZONE7_TC3", "ZONE7_TC3_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineAZ8TC1()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE8_TC1,ZONE8_TC1_PRED"
        Dim LineName As String = "A"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LAZ8TC1, "ZONE8_TC1", "ZONE8_TC1_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitZ8TC1Zone, "contLAZ8TC1", "plot27", "chart1", "Z8TC1Actual", "Z8TC1Prediction", "Threshold", "ZONE8_TC1", "ZONE8_TC1_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineAZ8TC2()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE8_TC2,ZONE8_TC2_PRED"
        Dim LineName As String = "A"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LAZ8TC2, "ZONE8_TC2", "ZONE8_TC2_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitZ8TC2Zone, "contLAZ8TC2", "plot28", "chart1", "Z8TC2Actual", "Z8TC2Prediction", "Threshold", "ZONE8_TC2", "ZONE8_TC2_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineAZ8TC3()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE8_TC3,ZONE8_TC3_PRED"
        Dim LineName As String = "A"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LAZ8TC3, "ZONE8_TC3", "ZONE8_TC3_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitZ8TC3Zone, "contLAZ8TC3", "plot29", "chart1", "Z8TC3Actual", "Z8TC3Prediction", "Threshold", "ZONE8_TC3", "ZONE8_TC3_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineAZ9TC1()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE9_TC1,ZONE9_TC1_PRED"
        Dim LineName As String = "A"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LAZ9TC1, "ZONE9_TC1", "ZONE9_TC1_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitZ9TC1Zone, "contLAZ9TC1", "plot30", "chart1", "Z9TC1Actual", "Z9TC1Prediction", "Threshold", "ZONE9_TC1", "ZONE9_TC1_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineAZ9TC2()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE9_TC2,ZONE9_TC2_PRED"
        Dim LineName As String = "A"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LAZ9TC2, "ZONE9_TC2", "ZONE9_TC2_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitZ9TC2Zone, "contLAZ9TC2", "plot31", "chart1", "Z9TC2Actual", "Z9TC2Prediction", "Threshold", "ZONE9_TC2", "ZONE9_TC2_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineAZ9TC3()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE9_TC3,ZONE9_TC3_PRED"
        Dim LineName As String = "A"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LAZ9TC3, "ZONE9_TC3", "ZONE9_TC3_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitZ9TC3Zone, "contLAZ9TC3", "plot32", "chart1", "Z9TC3Actual", "Z9TC3Prediction", "Threshold", "ZONE9_TC3", "ZONE9_TC3_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineBZ1TC1()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE1_TC1,ZONE1_TC1_PRED"
        Dim LineName As String = "B"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LBZ1TC1, "ZONE1_TC1", "ZONE1_TC1_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitLBZ1TC1, "contLBZ1TC1", "plot33", "chart1", "Z1TC1Actual", "Z1TC1Prediction", "Threshold", "ZONE1_TC1", "ZONE1_TC1_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineBZ1TC2()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE1_TC2,ZONE1_TC2_PRED"
        Dim LineName As String = "B"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LBZ1TC2, "ZONE1_TC2", "ZONE1_TC2_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitLBZ1TC2, "contLBZ1TC2", "plot34", "chart1", "Z1TC2Actual", "Z1TC2Prediction", "Threshold", "ZONE1_TC2", "ZONE1_TC2_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineBZ1TC3()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE1_TC3,ZONE1_TC3_PRED"
        Dim LineName As String = "B"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LBZ1TC3, "ZONE1_TC3", "ZONE1_TC3_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitLBZ1TC3, "contLBZ1TC3", "plot35", "chart1", "Z1TC3Actual", "Z1TC3Prediction", "Threshold", "ZONE1_TC3", "ZONE1_TC3_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineBZ2TC1()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE2_TC1,ZONE2_TC1_PRED"
        Dim LineName As String = "B"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LBZ2TC1, "ZONE2_TC1", "ZONE2_TC1_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitLBZ2TC1, "contLBZ2TC1", "plot36", "chart1", "Z2TC1Actual", "Z2TC1Prediction", "Threshold", "ZONE2_TC1", "ZONE2_TC1_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineBZ2TC2()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE2_TC2,ZONE2_TC2_PRED"
        Dim LineName As String = "B"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LBZ2TC2, "ZONE2_TC2", "ZONE2_TC2_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitLBZ2TC2, "contLBZ2TC2", "plot37", "chart1", "Z2TC2Actual", "Z2TC2Prediction", "Threshold", "ZONE2_TC2", "ZONE2_TC2_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineBZ2TC3()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE2_TC3,ZONE2_TC3_PRED"
        Dim LineName As String = "B"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LBZ2TC3, "ZONE2_TC3", "ZONE2_TC3_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitLBZ2TC3, "contLBZ2TC3", "plot38", "chart1", "Z2TC3Actual", "Z2TC3Prediction", "Threshold", "ZONE2_TC3", "ZONE2_TC3_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineBZ3TC1()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE3_TC1,ZONE3_TC1_PRED"
        Dim LineName As String = "B"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LBZ3TC1, "ZONE3_TC1", "ZONE3_TC1_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitLBZ3TC1, "contLBZ3TC1", "plot39", "chart1", "Z3TC1Actual", "Z3TC1Prediction", "Threshold", "ZONE3_TC1", "ZONE3_TC1_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineBZ3TC2()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE3_TC2,ZONE3_TC2_PRED"
        Dim LineName As String = "B"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LBZ3TC2, "ZONE3_TC2", "ZONE3_TC2_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitLBZ3TC2, "contLBZ3TC2", "plot40", "chart1", "Z3TC2Actual", "Z3TC2Prediction", "Threshold", "ZONE3_TC2", "ZONE3_TC2_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineBZ3TC3()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE3_TC3,ZONE3_TC3_PRED"
        Dim LineName As String = "B"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LBZ3TC3, "ZONE3_TC3", "ZONE3_TC3_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitLBZ3TC3, "contLBZ3TC3", "plot41", "chart1", "Z3TC3Actual", "Z3TC3Prediction", "Threshold", "ZONE3_TC3", "ZONE3_TC3_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineBZ4TC1()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE4_TC1,ZONE4_TC1_PRED"
        Dim LineName As String = "B"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LBZ4TC1, "ZONE4_TC1", "ZONE4_TC1_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitLBZ4TC1, "contLBZ4TC1", "plot42", "chart1", "Z4TC1Actual", "Z4TC1Prediction", "Threshold", "ZONE4_TC1", "ZONE4_TC1_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineBZ4TC2()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE4_TC2,ZONE4_TC2_PRED"
        Dim LineName As String = "B"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LBZ4TC2, "ZONE4_TC2", "ZONE4_TC2_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitLBZ4TC2, "contLBZ4TC2", "plot43", "chart1", "Z4TC2Actual", "Z4TC2Prediction", "Threshold", "ZONE4_TC2", "ZONE4_TC2_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineBZ4TC3()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE4_TC3,ZONE4_TC3_PRED"
        Dim LineName As String = "B"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LBZ4TC3, "ZONE4_TC3", "ZONE4_TC3_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitLBZ4TC3, "contLBZ4TC3", "plot44", "chart1", "Z4TC3Actual", "Z4TC3Prediction", "Threshold", "ZONE4_TC3", "ZONE4_TC3_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineBZ5TC1()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE5_TC1,ZONE5_TC1_PRED"
        Dim LineName As String = "B"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LBZ5TC1, "ZONE5_TC1", "ZONE5_TC1_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitLBZ5TC1, "contLBZ5TC1", "plot45", "chart1", "Z5TC1Actual", "Z5TC1Prediction", "Threshold", "ZONE5_TC1", "ZONE5_TC1_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineBZ5TC2()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE5_TC2,ZONE5_TC2_PRED"
        Dim LineName As String = "B"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LBZ5TC2, "ZONE5_TC2", "ZONE5_TC2_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitLBZ5TC2, "contLBZ5TC2", "plot46", "chart1", "Z5TC2Actual", "Z5TC2Prediction", "Threshold", "ZONE5_TC2", "ZONE5_TC2_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineBZ5TC3()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE5_TC3,ZONE5_TC3_PRED"
        Dim LineName As String = "B"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LBZ5TC3, "ZONE5_TC3", "ZONE5_TC3_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitLBZ5TC3, "contLBZ5TC3", "plot47", "chart1", "Z5TC3Actual", "Z5TC3Prediction", "Threshold", "ZONE5_TC3", "ZONE5_TC3_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineBZ6TC1()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE6_TC1,ZONE6_TC1_PRED"
        Dim LineName As String = "B"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LBZ6TC1, "ZONE6_TC1", "ZONE6_TC1_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitLBZ6TC1, "contLBZ6TC1", "plot48", "chart1", "Z6TC1Actual", "Z6TC1Prediction", "Threshold", "ZONE6_TC1", "ZONE6_TC1_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineBZ6TC2()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE6_TC2,ZONE6_TC2_PRED"
        Dim LineName As String = "B"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LBZ6TC2, "ZONE6_TC2", "ZONE6_TC2_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitLBZ6TC2, "contLBZ6TC2", "plot49", "chart1", "Z6TC2Actual", "Z6TC2Prediction", "Threshold", "ZONE6_TC2", "ZONE6_TC2_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineBZ6TC3()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE6_TC3,ZONE6_TC3_PRED"
        Dim LineName As String = "B"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LBZ6TC3, "ZONE6_TC3", "ZONE6_TC3_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitLBZ6TC3, "contLBZ6TC3", "plot50", "chart1", "Z6TC3Actual", "Z6TC3Prediction", "Threshold", "ZONE6_TC3", "ZONE6_TC3_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineBZ7TC1()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE7_TC1,ZONE7_TC1_PRED"
        Dim LineName As String = "B"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LBZ7TC1, "ZONE7_TC1", "ZONE7_TC1_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitLBZ7TC1, "contLBZ7TC1", "plot51", "chart1", "Z7TC1Actual", "Z7TC1Prediction", "Threshold", "ZONE7_TC1", "ZONE7_TC1_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineBZ7TC2()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE7_TC2,ZONE7_TC2_PRED"
        Dim LineName As String = "B"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LBZ7TC2, "ZONE7_TC2", "ZONE7_TC2_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitLBZ7TC2, "contLBZ7TC2", "plot52", "chart1", "Z7TC2Actual", "Z7TC2Prediction", "Threshold", "ZONE7_TC2", "ZONE7_TC2_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineBZ7TC3()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE7_TC3,ZONE7_TC3_PRED"
        Dim LineName As String = "B"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LBZ7TC3, "ZONE7_TC3", "ZONE7_TC3_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitLBZ7TC3, "contLBZ7TC3", "plot53", "chart1", "Z7TC3Actual", "Z7TC3Prediction", "Threshold", "ZONE7_TC3", "ZONE7_TC3_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineBZ8TC1()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE8_TC1,ZONE8_TC1_PRED"
        Dim LineName As String = "B"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LBZ8TC1, "ZONE8_TC1", "ZONE8_TC1_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitLBZ8TC1, "contLBZ8TC1", "plot54", "chart1", "Z8TC1Actual", "Z8TC1Prediction", "Threshold", "ZONE8_TC1", "ZONE8_TC1_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineBZ8TC2()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE8_TC2,ZONE8_TC2_PRED"
        Dim LineName As String = "B"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LBZ8TC2, "ZONE8_TC2", "ZONE8_TC2_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitLBZ8TC2, "contLBZ8TC2", "plot55", "chart1", "Z8TC2Actual", "Z8TC2Prediction", "Threshold", "ZONE8_TC2", "ZONE8_TC2_PRED", LineName)
    End Sub

    Public Sub ActualPredictionLineBZ8TC3()
        Dim ColName As String = "TIMESTAMP,LINE,ZONE8_TC3,ZONE8_TC3_PRED"
        Dim LineName As String = "B"
        Dim dt As DataTable

        dt = ActualPredQuery(ColName, LineName)
        PopulateThresholdVal(dt, LBZ8TC3, "ZONE8_TC3", "ZONE8_TC3_PRED", LineName)
        objController.DrawChartTcZoneTEMPActualPred(dt, LitLBZ8TC3, "contLBZ8TC3", "plot56", "chart1", "Z8TC3Actual", "Z8TC3Prediction", "Threshold", "ZONE8_TC3", "ZONE8_TC3_PRED", LineName)
    End Sub


    Public Function ActualPredQuery(ByVal ColumnName As String, ByVal LineName As String) As DataTable
        Try
            Dim query As String
            Dim dt As DataTable
            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value

            Dim TimeSelected As String = Session("TimeSelected")
            Dim SelectedTime As String = "SelectedTime"

            If TimeSelected = SelectedTime Then
                query = "SELECT " & ColumnName & " FROM FP_PROCESS_DATA.dbo.TSCR_FURNACE_ZONE_TEMP WHERE LINE='" & LineName & "' AND TIMESTAMP BETWEEN '" & fromDt & "' AND '" & toDt & "'"
                query &= " order by TIMESTAMP ASC"
            Else
                query = "SELECT " & ColumnName & " FROM FP_PROCESS_DATA.dbo.TSCR_FURNACE_ZONE_TEMP WHERE LINE='" & LineName & "' AND TIMESTAMP BETWEEN DATEADD(HOUR,-5,GETDATE()) AND GETDATE()"
                query &= " order by TIMESTAMP ASC"
            End If

            'query = "SELECT " & ColumnName & " FROM FP_PROCESS_DATA.dbo.TSCR_FURNACE_ZONE_TEMP WHERE LINE='" & LineName & "' AND TIMESTAMP BETWEEN DATEADD(HOUR,-5,GETDATE()) AND GETDATE()"
            'query &= " order by TIMESTAMP ASC"

            dt = objdatahandler.GetDataSetFromQuery(query).Tables(0)
            Return dt
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Function

    Public Sub PopulateThresholdVal(dt As DataTable, ctrlName As Label, ByVal ColName1 As String, ByVal ColName2 As String, ByVal LineName As String)
        Dim ticks As String
        Dim line1 As String
        Dim line2 As String
        Dim line1ColRed As String
        Dim diff As Double
        Dim thresholdPt As String
        Dim dtAccuData As DataTable

        Dim sum As Integer = 0
        Dim avg As Double = 0.0
        Dim standev As Double = 0.0

        Try
            '''''''''''''''''''''''''''''''''''''''''''''''''''''STANDARD DEVIATION START'''''''''''''''''''''''''''''''''''''''''''''''''

            For ab As Integer = 0 To dt.Rows.Count - 1
                sum = sum + (Math.Abs(dt(ab)(ColName1) - dt(ab)(ColName2)))
            Next
            avg = sum / dt.Rows.Count
            For j As Integer = 0 To dt.Rows.Count - 1
                standev += Math.Pow((Math.Abs(dt(j)(ColName1) - dt(j)(ColName2))) - avg, 2)
            Next
            standev = Math.Sqrt(standev / dt.Rows.Count)

            '''''''''''''''''''''''''''''''''''''''''''''''''''''STANDARD DEVIATION END'''''''''''''''''''''''''''''''''''''''''''''''''
            dtAccuData = objController.GetLSTM_MODEL_ACCURACY_Data(LineName)

            For i As Integer = 0 To dt.Rows.Count - 1
                For x As Integer = 0 To dtAccuData.Rows.Count - 1
                    If dtAccuData(x)("TC") = ColName1 Then
                        'If Math.Abs(dt(i)(ColName1) - dt(i)(ColName2)) > Math.Round((dtAccuData(x)("MAE") + (3 * standev)), 0) Then
                        '    line1 &= "{value:" & dt.Rows(i)(ColName1) & ", itemStyle:{color:'#f00'}}" & ","
                        '    line1ColRed &= dt.Rows(i)(ColName1) & ","
                        'Else
                        '    line1 &= dt.Rows(i)(ColName1) & ","
                        '    'line1ColRed = line1ColRed & ","
                        '    line1ColRed &= Nothing & ","
                        'End If
                        ctrlName.Text = Math.Round((dtAccuData(x)("MAE") + (3 * standev)), 0)
                    End If
                Next
            Next


        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub

    Private Sub txtDate_TextChanged(sender As Object, e As EventArgs) Handles txtDate.TextChanged
        Try
            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            Session("TimeSelected") = "SelectedTime"

            PopulateChartsWithTime()

        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub
    Public Function PopulateChartsWithTime()
        Try
            ActualPredictionLineAZ1TC1()
            ActualPredictionLineAZ1TC2()
            ActualPredictionLineAZ1TC3()
            ActualPredictionLineAZ2TC1()
            ActualPredictionLineAZ2TC2()
            ActualPredictionLineAZ2TC3()
            ActualPredictionLineAZ3TC1()
            ActualPredictionLineAZ3TC2()
            ActualPredictionLineAZ3TC3()
            ActualPredictionLineAZ4TC1()
            ActualPredictionLineAZ4TC2()
            ActualPredictionLineAZ4TC3()
            ActualPredictionLineAZ5TC1()
            ActualPredictionLineAZ5TC2()
            ActualPredictionLineAZ5TC3()
            ActualPredictionLineAZ6TC1()
            ActualPredictionLineAZ6TC2()
            ActualPredictionLineAZ6TC3()
            ActualPredictionLineAZ7TC1()
            ActualPredictionLineAZ7TC2()
            ActualPredictionLineAZ7TC3()
            ActualPredictionLineAZ8TC1()
            ActualPredictionLineAZ8TC2()
            ActualPredictionLineAZ8TC3()
            ActualPredictionLineAZ9TC1()
            ActualPredictionLineAZ9TC2()
            ActualPredictionLineAZ9TC3()

            ActualPredictionLineBZ1TC1()
            ActualPredictionLineBZ1TC2()
            ActualPredictionLineBZ1TC3()
            ActualPredictionLineBZ2TC1()
            ActualPredictionLineBZ2TC2()
            ActualPredictionLineBZ2TC3()
            ActualPredictionLineBZ3TC1()
            ActualPredictionLineBZ3TC2()
            ActualPredictionLineBZ3TC3()
            ActualPredictionLineBZ4TC1()
            ActualPredictionLineBZ4TC2()
            ActualPredictionLineBZ4TC3()
            ActualPredictionLineBZ5TC1()
            ActualPredictionLineBZ5TC2()
            ActualPredictionLineBZ5TC3()
            ActualPredictionLineBZ6TC1()
            ActualPredictionLineBZ6TC2()
            ActualPredictionLineBZ6TC3()
            ActualPredictionLineBZ7TC1()
            ActualPredictionLineBZ7TC2()
            ActualPredictionLineBZ7TC3()
            ActualPredictionLineBZ8TC1()
            ActualPredictionLineBZ8TC2()
            ActualPredictionLineBZ8TC3()

        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Function



End Class
