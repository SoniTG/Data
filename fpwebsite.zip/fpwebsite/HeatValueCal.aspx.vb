﻿Imports System.Data
Imports System.IO

Partial Class HeatValueCal
    Inherits System.Web.UI.Page

    Dim objdatahandler As New DataHandler
    Dim objController As New Controller
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
            Dim dSdate As DataSet = objdatahandler.GetDataSetFromQuery("select max(datetime) as DATETIME FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]")
            Dim dtdate As DataTable = dSdate.Tables(0)

            Dim ddtdate As DateTime = dtdate.Rows(0)("DATETIME")
            Dim frmDate As String = ddtdate.ToString("yyyy-MM-dd HH:mm:ss")

            Dim toDate As String = ddtdate.AddHours(-1).ToString("yyyy-MM-dd HH:mm:ss")

            '=============LINEA AND B
            Dim SELECT_LINE As String = Session("checkboxval")

            Dim ds As DataSet = objdatahandler.GetDataSetFromQuery("SELECT [DATETIME], [HEAT_INPUT] FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL] where LINE =  '" & SELECT_LINE & "'  AND  [datetime] between '" & toDate & "' and '" & frmDate & "'  ORDER BY DATETIME ASC")
            Dim dt As DataTable = ds.Tables(0)
            'between '" & frmDate & "' and '" & toDate & "'
            Try
                Literal1.Text = ""

                Dim yVal() As Decimal
                yVal = (From row In dt Select col = CDec(row("HEAT_INPUT"))).ToArray()
                Dim y_min As String = yVal.Min() - 10
                Dim y_max As String = yVal.Max() + 10


                'Dim y_min As String = yVal.Min()
                'Dim y_max As String = yVal.Max()
                'Dim y_min As String = yVal.Min() - (10 / 100 * yVal.Min)
                'Dim y_max As String = yVal.Max() + (10 / 100 * yVal.Max)
                Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                     "$.jqplot.config.enablePlugins = true;" & vbCrLf
                js &= "var line1 = ["
                For i As Integer = 0 To dt.Rows.Count - 1
                    js &= "['" & CDate(dt.Rows(i)("DATETIME")).ToString("yyyy-MM-dd HH:mm:ss") & "'," & dt.Rows(i)("HEAT_INPUT") & "],"

                Next
                js &= "];"
                'js &= "var line2 = ["
                'For i As Integer = 0 To dt.Rows.Count - 1
                '    js &= "['" & dt.Rows(i)("DATETIME") & "'," & dt.Rows(i)("HEAT_INPUT") & "],"

                'Next
                'js &= "];"

                Dim plotname = "plot1"
                Dim ContainerName = "chart1"
                js &= "var " & plotname & " = $.jqplot('" & ContainerName & "',[line1], {"
                js &= "series:[{  showMarker:true,pointLabels: { show:false } ,label:'calculated'  }],"
                js &= "axesDefaults: { tickRenderer: $.jqplot.CanvasAxisTickRenderer ,tickOptions: {  angle: 30 ,fontSize:  '8pt'  }},"
                js &= "seriesColors:['#0B62A4'],"
                js &= "axes: {labelOptions:{fontSize:  '8pt'},"
                js &= "xaxis: {   label : " & """Time""" & ",labelOptions:{fontSize:  '8pt'},renderer:$.jqplot.DateAxisRenderer,tickOptions:{formatString:'%Y/%#m/%#d %H:%M:%S'}},"
                js &= "yaxis: {type: 'value',min:" & y_min & ", max: " & y_max & " , label:'Parameters',labelRenderer: $.jqplot.CanvasAxisLabelRenderer }"
                js &= "}, highlighter: {show: true}, cursor: { show: true, zoom:true,},grid: {backgroundColor:  'rgb(255,255,255)'} ,legend:{show:true,placement: 'OutsideGrid',rendererOptions: {numberRows: 1, marginTop: 10 },  renderer: $.jqplot.EnhancedLegendRenderer } });"
                js &= "</script>"
                Literal1.Text = js

            Catch ex As Exception

            End Try


        End If
    End Sub




End Class
