﻿
Partial Class Home_Screen
    Inherits System.Web.UI.Page

End Class
