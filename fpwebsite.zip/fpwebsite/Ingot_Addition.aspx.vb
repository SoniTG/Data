﻿Imports System.Data
Imports System.IO
Imports OfficeOpenXml
Imports System.Drawing
Partial Class Ingot_Addition

    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim Yesterday_Shift, Today_Shift, id As String

    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxSuccessWithUrl(ByVal Message As String, ByVal Url As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalertandredirect('" + Message + "', '" + Url + "');", True)
    End Sub
    Sub UserConfirmationBox()
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "confirmation();", True)
    End Sub
    Sub OpenModal(ByVal DivId As String)
        Dim sb As New StringBuilder()
        sb.Append("<script type='text/javascript'>")
        sb.Append("$('#" & DivId & "').modal('show');")
        sb.Append("</script>")
        ScriptManager.RegisterClientScriptBlock(Me, Me.GetType(), "ShowModal", sb.ToString(), False)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If gdvZnYield.Rows.Count > 0 Then
            gdvZnYield.UseAccessibleHeader = True
            gdvZnYield.HeaderRow.TableSection = TableRowSection.TableHeader
        End If
        If gdvDetails.Rows.Count > 0 Then
            gdvDetails.UseAccessibleHeader = True
            gdvDetails.HeaderRow.TableSection = TableRowSection.TableHeader
        End If
        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                'Dim dtStart As String = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd HH:mm")
                Dim dtStart As String = DateTime.Now.AddDays(-10).ToString("yyyy-MM-dd 06:00:00")

                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                txtDateTime.Text = Now.ToString("dd-MMM-yyyy HH:mm:ss")
                objController.PopulateIngotDetails(dtStart, dtEnd, gdvDetails)

                gdvDetails.Columns(7).Visible = False
                MonthConsumption()


                InsertIngotAdditionShift(dtStart, dtEnd)
                PopulateGridZnYield(dtStart, dtEnd)
                Drawchart(dtStart, dtEnd)

            Catch ex As Exception

            End Try
        End If
    End Sub
    Sub MonthConsumption()
        Try
            Dim month As String = Date.Now.ToString("MMM")
            ddlmonth.SelectedIndex = ddlmonth.Items.IndexOf(ddlmonth.Items.FindByText(month))
            objController.PopulateMonthlyCon(ddlmonth.SelectedIndex + 1, lblCgg, lblScg, lblAlPer, lbldross)
        Catch ex As Exception

        End Try
       
    End Sub
    Sub PopulateGridZnYield(ByVal startdate As String, ByVal enddate As String)
        Try

            Dim ds As DataSet = objController.ExportExcelIngot(startdate, enddate)
            Dim t1, t2 As Double
            't1 = 110
            't2 = 110
            Dim dt1, dt2, dt3, dt4, dt5 As DataTable
            dt1 = ds.Tables(0)
            dt2 = ds.Tables(1)
            dt3 = ds.Tables(2)
            dt4 = ds.Tables(3)
            dt5 = ds.Tables(4)

            Dim dt_SecondSheet As New DataTable
            dt_SecondSheet.Columns.Add("DATE")
            dt_SecondSheet.Columns.Add("CGG", GetType(Double))
            dt_SecondSheet.Columns.Add("SHG", GetType(Double))
            dt_SecondSheet.Columns.Add("AL5PER", GetType(Double))
            dt_SecondSheet.Columns.Add("DROSS", GetType(Double))

            For j As Integer = 0 To dt2.Rows.Count - 1
                Dim irow As DataRow = dt_SecondSheet.NewRow
                irow("DATE") = dt4.Rows(j)("DATE")
                irow("CGG") = dt2.Rows(j)("CGG")
                irow("SHG") = dt2.Rows(j)("SHG")
                irow("AL5PER") = dt2.Rows(j)("AL5PER")
                irow("DROSS") = dt2.Rows(j)("DROSS")

                dt_SecondSheet.Rows.Add(irow)


            Next

            Dim table As New DataTable

            table.Columns.Add("Date")
            table.Columns.Add("TotalIngotAddition(Ton)", GetType(Double))
            table.Columns.Add("Production", GetType(Double))
            table.Columns.Add("Kg/Ton", GetType(Double))
            table.Columns.Add("Total Input", GetType(Double))
            table.Columns.Add("Coated SA", GetType(Double))

            table.Columns.Add("Zn on strip( at +4 deviation)", GetType(Double))
            table.Columns.Add("Yesterday A shift level", GetType(Double))
            table.Columns.Add("Today A shift level", GetType(Double))
            table.Columns.Add("Add. Zn in bath", GetType(Double))
            table.Columns.Add("Avg. Zn on strip (theoretical) in gsm", GetType(Double))
            table.Columns.Add("Zn yield", GetType(Double))
            table.Columns.Add("Avg. Zn on strip (as per coating gauge) in gsm", GetType(Double))
            table.Columns.Add("Zn on strip( from coating gauge)", GetType(Double))
            table.Columns.Add("Zn yield (coating gauge)", GetType(Double))



            For i As Integer = 0 To dt_SecondSheet.Rows.Count - 1


                Dim row As DataRow = table.NewRow



                row("Date") = dt_SecondSheet.Rows(i)("DATE").ToString().Substring(0, 10)
                row("TotalIngotAddition(Ton)") = Math.Round(dt_SecondSheet.Rows(i)("CGG") + dt_SecondSheet.Rows(i)("SHG") + dt_SecondSheet.Rows(i)("AL5PER"), 2)
                row("Production") = Math.Round(dt3.Rows(i)("production_C"), 2)
                row("Kg/Ton") = Math.Round((dt_SecondSheet.Rows(i)("CGG") + dt_SecondSheet.Rows(i)("SHG") + dt_SecondSheet.Rows(i)("AL5PER")) * 1000 / dt3.Rows(i)("production_C"), 2)
                row("Total Input") = Math.Round((dt_SecondSheet.Rows(i)("CGG") + dt_SecondSheet.Rows(i)("SHG") + dt_SecondSheet.Rows(i)("AL5PER")) - dt_SecondSheet.Rows(i)("DROSS"), 2)
                row("Coated SA") = Math.Round(dt3.Rows(i)("SA_F"), 2)
                row("Zn on strip( at +4 deviation)") = Math.Round(dt3.Rows(i)("zn_on_strip_G"), 2)
                If dt5.Rows.Count > 0 Then

                    If dt_SecondSheet.Rows(i)("DATE") = dt5.Rows(i)("CIAS_TIMESTAMP") Then
                        t1 = dt5.Rows(i)("CIAS_YESTERDAY_SHIFT")
                        t2 = dt5.Rows(i)("CIAS_TODAY_SHIFT")
                        'Else
                        '    t1 = 110
                        '    t2 = 110
                    End If
                Else
                    t1 = 110
                    t2 = 110

                End If
                row("Yesterday A shift level") = t1
                row("Today A shift level") = t2
                row("Add. Zn in bath") = ((t1 - t2) / 10) * 410 * 320 * 7.13 / 1000000
                row("Avg. Zn on strip (theoretical) in gsm") = Math.Round((((dt_SecondSheet.Rows(i)("CGG") + dt_SecondSheet.Rows(i)("SHG") + dt_SecondSheet.Rows(i)("AL5PER")) - dt_SecondSheet.Rows(i)("DROSS")) - (((t1 - t2) / 10) * 410 * 320 * 7.13 / 1000000)) * 1000000 / dt3.Rows(i)("SA_F"), 2)
                row("Zn yield") = Math.Round((((dt_SecondSheet.Rows(i)("CGG") + dt_SecondSheet.Rows(i)("SHG") + dt_SecondSheet.Rows(i)("AL5PER")) - dt_SecondSheet.Rows(i)("DROSS")) - (((t1 - t2) / 10) * 410 * 320 * 7.13 / 1000000)) / dt3.Rows(i)("zn_on_strip_G"), 2)
                row("Avg. Zn on strip (as per coating gauge) in gsm") = Math.Round(dt3.Rows(i)("avg_zn_strip_M"), 2)
                row("Zn on strip( from coating gauge)") = Math.Round(dt3.Rows(i)("zn_strip_N"), 2)
                row("Zn yield (coating gauge)") = Math.Round((dt_SecondSheet.Rows(i)("CGG") + dt_SecondSheet.Rows(i)("SHG") + dt_SecondSheet.Rows(i)("AL5PER") - dt_SecondSheet.Rows(i)("DROSS")) / dt3.Rows(i)("zn_strip_N"), 2)

                table.Rows.Add(row)
            Next

            gdvZnYield.DataSource = table
            gdvZnYield.DataBind()
            If gdvZnYield.Rows.Count > 0 Then
                gdvZnYield.UseAccessibleHeader = True
                gdvZnYield.HeaderRow.TableSection = TableRowSection.TableHeader
            End If

        Catch ex As Exception

        End Try
    End Sub
    Protected Sub txtDate_TextChanged(sender As Object, e As System.EventArgs) Handles txtDate.TextChanged
        Try
            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            objController.PopulateIngotDetails(fromDt, toDt, gdvDetails)
            InsertIngotAdditionShift(fromDt, toDt)
            PopulateGridZnYield(fromDt, toDt)
            MonthConsumption()
            Drawchart(fromDt, toDt)
        Catch ex As Exception

        End Try


    End Sub


    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Dim sum As Integer = 0
        Dim cnt As Integer = 0
        Dim C, S, A As Integer

        Dim strDateTime As DateTime = Format(txtDateTime.Text)
        Dim d1 As DateTime = DateTime.Now


        C = ddlCgg.SelectedItem.Text
        S = ddlScg.SelectedItem.Text
        A = ddlAlPer.SelectedItem.Text
        sum = C + S + A



        Try


            If sum > 0 Then

                If (ddlCgg.SelectedItem.Text <> 0 Or txtCggWeight.Text <> 0) Or (ddlScg.SelectedItem.Text <> 0 Or txtShgWeight.Text <> 0) Or (ddlAlPer.SelectedItem.Text <> 0 Or txtAlPerWeight.Text <> 0) Or (ddldross.SelectedItem.Text <> 0 Or txtDrossWeight.Text <> 0) Then


                    If strDateTime < d1 Then
                        cnt = objController.SaveIngotAddition(strDateTime.ToString("yyyy-MM-dd HH:mm:ss"), ddlCgg.SelectedItem.ToString(), ddlScg.SelectedItem.ToString(), ddlAlPer.SelectedItem.ToString(), ddldross.SelectedItem.ToString(), txtCggWeight.Text, txtShgWeight.Text, txtAlPerWeight.Text, txtDrossWeight.Text)
                        hfTo.Value = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                    Else
                        UserMsgBoxWarning("Datetime should not be greater than current date time.")
                    End If

                Else
                    UserMsgBoxWarning("Values should be nonzero ")
                End If

            Else
                    UserMsgBoxWarning(" Cgg + Shg + 5%Al sum should be greater than 0.")


                End If

            If cnt > 0 Then

            'UserMsgBoxSuccessWithUrl(" Saved successfully.", " Ingot_Addition.aspx")
            UserMsgBoxSuccess("Saved successfully.")
             ddlScg.SelectedIndex = 0
                ddlCgg.SelectedIndex = 0
                ddlAlPer.SelectedIndex = 0
                ddldross.SelectedIndex = 0
                txtCggWeight.Text = 0
                txtShgWeight.Text = 0
                txtAlPerWeight.Text = 0
                txtDrossWeight.Text = 0
                txtDateTime.Text = strDateTime.AddSeconds(1).ToString("dd-MMM-yyyy HH:mm:ss")
        End If
        txtDate_TextChanged(sender, e)

        'Label1.Text = 10000
        'If tmr1.Interval = Label1.Text Then
        '    UserMsgBoxError("left")
            'End If
        Catch ex As Exception
            UserMsgBoxWarning("Datetime should be different.")
        End Try
    End Sub

    Private Sub ddlmonth_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlmonth.SelectedIndexChanged
        Try
            objController.PopulateMonthlyCon(ddlmonth.SelectedIndex + 1, lblCgg, lblScg, lblAlPer, lbldross)
        Catch ex As Exception

        End Try


    End Sub

    Private Sub gdvDetails_RowCancelingEdit(sender As Object, e As GridViewCancelEditEventArgs) Handles gdvDetails.RowCancelingEdit
        Try
            gdvDetails.EditIndex = -1
            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            objController.PopulateIngotDetails(fromDt, toDt, gdvDetails)
            MonthConsumption()
        Catch ex As Exception

        End Try

    End Sub

    Private Sub gdvDetails_RowDeleting(sender As Object, e As GridViewDeleteEventArgs) Handles gdvDetails.RowDeleting
        Try
            'OpenModal(" ConfrmMsgModal")
            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            Dim row As GridViewRow = gdvDetails.Rows(e.RowIndex)

            Dim datetime As DateTime = (TryCast(row.FindControl("lblDatetime"), Label)).Text

            objController.DeleteIngot(datetime.ToString("yyyy-MM-dd HH:mm:ss"))
            UserMsgBoxSuccess("Deleted successfully.")
            objController.PopulateIngotDetails(fromDt, toDt, gdvDetails)
            MonthConsumption()
        Catch ex As Exception

        End Try


    End Sub

    Private Sub gdvDetails_RowEditing(sender As Object, e As GridViewEditEventArgs) Handles gdvDetails.RowEditing
        Try
            gdvDetails.EditIndex = e.NewEditIndex
            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            objController.PopulateIngotDetails(fromDt, toDt, gdvDetails)
            MonthConsumption()
        Catch ex As Exception

        End Try

    End Sub

    Private Sub gdvDetails_RowUpdating(sender As Object, e As GridViewUpdateEventArgs) Handles gdvDetails.RowUpdating
        Try

            Dim row As GridViewRow = gdvDetails.Rows(e.RowIndex)

            Dim datetime As DateTime = (TryCast(row.FindControl("txtDatetime"), TextBox)).Text
            Dim cgg As String = (TryCast(row.FindControl("txtCGG"), TextBox)).Text
            Dim shg As String = (TryCast(row.FindControl("txtSHG"), TextBox)).Text
            Dim AlPer As String = (TryCast(row.FindControl("txtAl"), TextBox)).Text
            Dim Dross As String = (TryCast(row.FindControl("txtdross"), TextBox)).Text
            gdvDetails.EditIndex = -1
            Dim count As Integer = 0
            count = objController.UpdateIngotAddition(datetime.ToString("yyyy-MM-dd HH:mm:ss"), cgg, shg, AlPer, Dross)
            If count > 0 Then
                UserMsgBoxSuccess("Updated successfully.")
            End If
            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            objController.PopulateIngotDetails(fromDt, toDt, gdvDetails)
            MonthConsumption()

        Catch ex As Exception

        End Try
    End Sub

    Public Sub Drawchart(ByVal startdate As String, ByVal enddate As String)
        Try
            Dim dt As DataTable = objController.Getingotaddition(startdate, enddate)
            objController.PlotLineChartForIngotAddition(dt, Lit1, "container", "plot1")

            ' objController.PlotBarChart(dt, Lit1, "container", "plot1")
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub btnExportToExcel_Click(sender As Object, e As System.EventArgs) Handles btnExportToExcel.Click
        Try

            'Response.Clear()
            'Response.Buffer = True
            'Response.ClearContent()
            'Response.ClearHeaders()
            'Response.Charset = ""
            'Dim FileName = "Ingot Addition Details" + DateTime.Now + ".xls"
            'Dim strwritter As New StringWriter()
            'Dim htmltextwrtter As New HtmlTextWriter(strwritter)
            'Response.Cache.SetCacheability(HttpCacheability.NoCache)
            'Response.ContentType = "application/vnd.ms-excel"
            'Response.AddHeader("Content-Disposition", "attachment;filename=" + FileName)
            'gdvDetails.GridLines = GridLines.Both
            'gdvDetails.HeaderStyle.Font.Bold = True
            'gdvDetails.Columns(0).Visible = True
            'gdvDetails.Columns(5).Visible = False
            'gdvDetails.Columns(6).Visible = False
            'gdvDetails.RenderControl(htmltextwrtter)
            'Response.Write(strwritter.ToString())
            'Response.End()
            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value

            ExportExcel(fromDt, toDt)
            '  UserMsgBoxSuccess("Excel downloaded successfully.")

        Catch ex As Exception

        End Try
    End Sub
    Sub ExportExcel(ByVal startdate As String, ByVal enddate As String)
        Dim ds As DataSet = objController.ExportExcelIngot(startdate, enddate)
        Dim t1, t2 As Double
        t1 = 110
        t2 = 110
        Dim dt1, dt2, dt3, dt4 As DataTable
        dt1 = ds.Tables(0)
        dt2 = ds.Tables(1)
        dt3 = ds.Tables(2)
        dt4 = ds.Tables(3)


        Dim dt_SecondSheet As New DataTable
        dt_SecondSheet.Columns.Add("DATE")
        dt_SecondSheet.Columns.Add("CGG", GetType(Double))
        dt_SecondSheet.Columns.Add("SHG", GetType(Double))
        dt_SecondSheet.Columns.Add("AL5PER", GetType(Double))
        dt_SecondSheet.Columns.Add("DROSS", GetType(Double))

        For j As Integer = 0 To dt2.Rows.Count - 1
            Dim irow As DataRow = dt_SecondSheet.NewRow
            irow("DATE") = dt4.Rows(j)("DATE")
            irow("CGG") = dt2.Rows(j)("CGG")
            irow("SHG") = dt2.Rows(j)("SHG")
            irow("AL5PER") = dt2.Rows(j)("AL5PER")
            irow("DROSS") = dt2.Rows(j)("DROSS")

            dt_SecondSheet.Rows.Add(irow)


        Next




        Dim table As New DataTable
        table.Columns.Add("Date")
        table.Columns.Add("TotalIngotAddition(Ton)", GetType(Double))
        table.Columns.Add("Production", GetType(Double))
        table.Columns.Add("Kg/Ton", GetType(Double))
        table.Columns.Add("Total Input", GetType(Double))
        table.Columns.Add("Coated SA", GetType(Double))

        table.Columns.Add("Zn on strip( at +4 deviation)", GetType(Double))
        table.Columns.Add("Yesterday A shift level", GetType(Double))
        table.Columns.Add("Today A shift level", GetType(Double))
        table.Columns.Add("Add. Zn in bath", GetType(Double))
        table.Columns.Add("Avg. Zn on strip (theoretical) in gsm", GetType(Double))
        table.Columns.Add("Zn yield", GetType(Double))
        table.Columns.Add("Avg. Zn on strip (as per coating gauge) in gsm", GetType(Double))
        table.Columns.Add("Zn on strip( from coating gauge)", GetType(Double))
        table.Columns.Add("Zn yield (coating gauge)", GetType(Double))

        For i As Integer = 0 To dt_SecondSheet.Rows.Count - 1
            Dim row As DataRow = table.NewRow

            row("Date") = dt_SecondSheet.Rows(i)("DATE").ToString().Substring(0, 10)
            row("TotalIngotAddition(Ton)") = Math.Round(dt_SecondSheet.Rows(i)("CGG") + dt_SecondSheet.Rows(i)("SHG") + dt_SecondSheet.Rows(i)("AL5PER"), 2)
            row("Production") = Math.Round(dt3.Rows(i)("production_C"), 2)
            row("Kg/Ton") = Math.Round((dt_SecondSheet.Rows(i)("CGG") + dt_SecondSheet.Rows(i)("SHG") + dt_SecondSheet.Rows(i)("AL5PER")) * 1000 / dt3.Rows(i)("production_C"), 2)
            row("Total Input") = Math.Round((dt_SecondSheet.Rows(i)("CGG") + dt_SecondSheet.Rows(i)("SHG") + dt_SecondSheet.Rows(i)("AL5PER")) - dt_SecondSheet.Rows(i)("DROSS"), 2)
            row("Coated SA") = Math.Round(dt3.Rows(i)("SA_F"), 2)
            row("Zn on strip( at +4 deviation)") = Math.Round(dt3.Rows(i)("zn_on_strip_G"), 2)
            row("Yesterday A shift level") = t1
            row("Today A shift level") = t2
            row("Add. Zn in bath") = ((t1 - t2) / 10) * 410 * 320 * 7.13 / 1000000
            row("Avg. Zn on strip (theoretical) in gsm") = Math.Round((((dt_SecondSheet.Rows(i)("CGG") + dt_SecondSheet.Rows(i)("SHG") + dt_SecondSheet.Rows(i)("AL5PER")) - dt_SecondSheet.Rows(i)("DROSS")) - (((t1 - t2) / 10) * 410 * 320 * 7.13 / 1000000)) * 1000000 / dt3.Rows(i)("SA_F"), 2)
            row("Zn yield") = Math.Round((((dt_SecondSheet.Rows(i)("CGG") + dt_SecondSheet.Rows(i)("SHG") + dt_SecondSheet.Rows(i)("AL5PER")) - dt_SecondSheet.Rows(i)("DROSS")) - (((t1 - t2) / 10) * 410 * 320 * 7.13 / 1000000)) / dt3.Rows(i)("zn_on_strip_G"), 2)
            row("Avg. Zn on strip (as per coating gauge) in gsm") = Math.Round(dt3.Rows(i)("avg_zn_strip_M"), 2)
            row("Zn on strip( from coating gauge)") = Math.Round(dt3.Rows(i)("zn_strip_N"), 2)
            row("Zn yield (coating gauge)") = Math.Round((dt_SecondSheet.Rows(i)("CGG") + dt_SecondSheet.Rows(i)("SHG") + dt_SecondSheet.Rows(i)("AL5PER") - dt_SecondSheet.Rows(i)("DROSS")) / dt3.Rows(i)("zn_strip_N"), 2)

            table.Rows.Add(row)
        Next

        '  Dim package As New ExcelPackage(New FileInfo(dt1))
        Dim excelPackage As ExcelPackage = New ExcelPackage
        excelPackage.Workbook.Properties.Title = "Ingot Addition"
        'excelPackage.Workbook.Properties.Subject = "EPPlus demo export data"
        excelPackage.Workbook.Properties.Created = DateTime.Now
        Dim worksheet1 As ExcelWorksheet = excelPackage.Workbook.Worksheets.Add("Raw data of additions")
        Dim worksheet2 As ExcelWorksheet = excelPackage.Workbook.Worksheets.Add("Day wise")
        Dim worksheet3 As ExcelWorksheet = excelPackage.Workbook.Worksheets.Add("Zn Yield")
        worksheet1.Column(1).Style.Numberformat.Format = "yyyy-MM-dd HH:mm:ss"
        worksheet2.Column(1).Style.Numberformat.Format = "yyyy-MM-dd"
        worksheet3.Column(1).Style.Numberformat.Format = "yyyy-MM-dd"

        'Add some text to cell A1
        'worksheet1.Cells("A1").Value
        worksheet1.Cells("A1").LoadFromDataTable(dt1, True)
        worksheet2.Cells("A1").LoadFromDataTable(dt_SecondSheet, True)
        worksheet3.Cells("A1").LoadFromDataTable(table, True)

        worksheet1.Cells("A1:E1").Style.Font.Bold = True
        worksheet2.Cells("A1:E1").Style.Font.Bold = True
        worksheet3.Cells("A1:P1").Style.Font.Bold = True
        worksheet1.Cells("A1:E1").Style.Font.Color.SetColor(Color.Blue)
        worksheet2.Cells("A1:E1").Style.Font.Color.SetColor(Color.Blue)
        worksheet3.Cells("A1:P1").Style.Font.Color.SetColor(Color.Blue)

        'You could also use [line, column] notation:
        'worksheet.Cells(1, 2).Value = "This is cell B1!"
        Dim fi As FileInfo = New FileInfo("D:\TGWebPage\fpwebsite_development\DwnIngotDetails\IngotAddition.xlsx")
        excelPackage.SaveAs(fi)

        Try
            Dim excelFile = Directory.GetFiles(Server.MapPath("~/DwnIngotDetails/")).OrderByDescending(Function(f) New FileInfo(f).LastWriteTime).First()
            Dim fName As String = excelFile.Substring(excelFile.LastIndexOf("\") + 1)
            Response.Clear()
            Response.Buffer = True
            Response.Charset = ""
            Response.ContentType = "application/vnd.ms-excel"
            Response.AddHeader("content-disposition", "attachment; filename=" + fName)
            Response.WriteFile(excelFile)
            Response.End()
        Catch ex As Exception
            UserMsgBoxError("Failed to download the new file.")
        End Try


        ' excelPackage.Save()
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)
        ' Verifies that the control is rendered 
    End Sub

    Protected Sub btnEdit_Click(sender As Object, e As System.EventArgs) Handles btnEdit.Click
        
    End Sub

    'Protected Sub tmr1_Disposed(sender As Object, e As System.EventArgs) Handles tmr1.Disposed
    '    UserMsgBoxError("hi")
    'End Sub

    Protected Sub tmr1_Tick(sender As Object, e As System.EventArgs) Handles tmr1.Tick
        Try
            tmr1.Enabled = False
            btnSave.Enabled = False
            gdvDetails.Columns(7).Visible = False
        Catch ex As Exception

        End Try


    End Sub

    Protected Sub tmr2_Tick(sender As Object, e As System.EventArgs) Handles tmr2.Tick
        Try
            UserMsgBoxWarning("2 minutes left.")
            tmr2.Enabled = False
        Catch ex As Exception

        End Try

    End Sub

    
    Protected Sub btnLogin_Click(sender As Object, e As System.EventArgs) Handles btnLogin.Click
        Try

            'If txtUsername.Text.Trim() = "" Then
            '    UserMsgBoxWarning("Enter username.")
            '    txtUsername.Focus()
            If txtPassword.Text.Trim() = "" Then
                UserMsgBoxWarning("Enter password.")
                txtPassword.Focus()
            Else
                If objController.IsAValidUser("admin", txtPassword.Text.Trim()) Then
                    Session("username") = txtUsername.Text.Trim()
                    'Session("password") = New EncryptDecrypt.EncryptDecryptCls().EncryptWithMD5(txtPassword.Text.Trim())
                    Session("password") = txtPassword.Text.Trim()

                    txtUsername.Text = ""
                    txtPassword.Text = ""
                Else
                    txtUsername.Text = ""
                    txtPassword.Text = ""
                    UserMsgBoxWarning("Incorrect login details.")
                    Exit Sub
                End If
            End If

            tmr1.Enabled = True
            tmr2.Enabled = True

            btnSave.Enabled = True
            gdvDetails.Columns(7).Visible = True

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub tmr3_Tick(sender As Object, e As System.EventArgs) Handles tmr3.Tick
        Try
            UserMsgBoxWarning("60 seconds left.")
            tmr3.Enabled = False
        Catch ex As Exception

        End Try

    End Sub
    Private Sub gdvZnYield_RowCancelingEdit(sender As Object, e As GridViewCancelEditEventArgs) Handles gdvZnYield.RowCancelingEdit
        Try
            gdvZnYield.EditIndex = -1
            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            PopulateGridZnYield(fromDt, toDt)
        Catch ex As Exception

        End Try


    End Sub

    Sub InsertIngotAdditionShift(ByVal startdate As String, ByVal enddate As String)
        Try

            Dim ds As DataSet = objController.ExportExcelIngot(startdate, enddate)
            Dim dt2 As DataTable


            dt2 = ds.Tables(3)



            For i As Integer = 0 To dt2.Rows.Count - 1

                Dim d As DateTime = dt2.Rows(i)("DATE")

                Dim count As Integer = 0
                count = objController.InsertIngotAdditionShift(d.ToString("yyyy-MM-dd HH:mm:ss"), 110, 110)

            Next

        Catch ex As Exception

        End Try


    End Sub
    Private Sub gdvZnYield_RowEditing(sender As Object, e As GridViewEditEventArgs) Handles gdvZnYield.RowEditing
        Try
            gdvZnYield.EditIndex = e.NewEditIndex
            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            PopulateGridZnYield(fromDt, toDt)
        Catch ex As Exception

        End Try


    End Sub
    Private Sub gdvZnYield_RowUpdating(sender As Object, e As GridViewUpdateEventArgs) Handles gdvZnYield.RowUpdating
        Try

            Dim row As GridViewRow = gdvZnYield.Rows(e.RowIndex)

            Dim datetime As DateTime = (TryCast(row.FindControl("txtDate"), TextBox)).Text
            Yesterday_Shift = (TryCast(row.FindControl("txtYesterday"), TextBox)).Text
            Today_Shift = (TryCast(row.FindControl("txtToday"), TextBox)).Text
            gdvZnYield.EditIndex = -1

            Dim count As Integer = 0


            count = objController.UpdateIngotAdditionShift(datetime.ToString("yyyy-MM-dd HH:mm:ss"), Yesterday_Shift, Today_Shift)
            If count > 0 Then
                UserMsgBoxSuccess("Updated successfully.")
            End If

            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            PopulateGridZnYield(fromDt, toDt)

        Catch ex As Exception

        End Try
    End Sub

    Private Sub txtCggWeight_TextChanged(sender As Object, e As EventArgs) 'Handles txtCggWeight.TextChanged
        Try
            If txtCggWeight.Text >= 800 And txtCggWeight.Text <= 2800 Then

            Else
                UserMsgBoxWarning("Value Must be between 800 to 2800 .")
                txtCggWeight.Text = ""
            End If
        Catch ex As Exception

        End Try

    End Sub

    Private Sub txtShgWeight_TextChanged(sender As Object, e As EventArgs) 'Handles 'txtShgWeight.TextChanged
        Try
            If txtShgWeight.Text >= 800 And txtShgWeight.Text <= 2800 Then

            Else
                UserMsgBoxWarning("Value Must be between 800 to 2800 .")
                txtShgWeight.Text = ""
            End If
        Catch ex As Exception

        End Try

    End Sub

    Private Sub txtAlPerWeight_TextChanged(sender As Object, e As EventArgs) 'Handles txtAlPerWeight.TextChanged
        Try
            If txtAlPerWeight.Text >= 80 And txtAlPerWeight.Text <= 2800 Then

            Else
                UserMsgBoxWarning("Value Must be between 80 to 2800 .")
                txtAlPerWeight.Text = ""
            End If
        Catch ex As Exception

        End Try

    End Sub
End Class


