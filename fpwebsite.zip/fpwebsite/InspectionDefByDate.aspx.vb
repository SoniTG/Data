﻿Imports System.Data
Imports System.IO
Imports System.Data.OleDb
Imports System.Drawing

Partial Class InspectionDefByDate
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim objDataHandler As New DataHandler
    Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("ACPM_Ora").ConnectionString
    Dim Oleconnection_ora As New OleDbConnection(strConnectionString)
    Dim OleAdap As New OleDbDataAdapter
    Dim ds As New DataSet
    Dim dt As New DataTable
    Dim OleCom As New OleDbCommand
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    txtDate_TextChanged()
                End If

            Catch ex As Exception

            End Try

        End If

        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                'Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
                'Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                Dim dtStart As String = DateTime.Now.AddDays(-60).ToString("yyyy-MM-dd")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd")
                LoadDefectList(dtStart, dtEnd)
                LoadGradeTDC(dtStart, dtEnd)
                hfFrom.Value = dtStart
                hfTo.Value = dtEnd
                Dim strDefect As String = getSelectedData(lstDefName)
                Dim strSeverity As String = getSelectedData(lstSeverity)
                Dim strGrade As String = getSelectedData(lstGrade)
                Dim strTDC As String = getSelectedData(lstTDC)


                If strDefect.Length > 0 Then
                    strDefect = "'" & strDefect.Replace(",", "','") & "'"
                End If

                If strGrade.Length > 0 Then
                    strGrade = "'" & strGrade.Replace(",", "','") & "'"
                End If

                If strTDC.Length > 0 Then
                    strTDC = "'" & strTDC.Replace(",", "','") & "'"
                End If
                Dim poc As String = lstProcessingline.SelectedValue.ToString

                Dim dt As DataTable = objController.GetDataForInspection(dtStart, dtEnd, strDefect, poc, ddlMeasure.SelectedItem.ToString, lstProcessingline.SelectedItem.ToString, strSeverity, strGrade, strTDC)
                Dim yVal() As Decimal
                yVal = (From row In dt Select col = CDec(row("TotalDefect"))).ToArray()
                Dim y_min As String = yVal.Min() - (10 / 100 * yVal.Min)
                Dim y_max As String = yVal.Max() + (10 / 100 * yVal.Max)
                DrawChart(dtStart, dtEnd, strDefect, poc, strSeverity, strGrade, strTDC, dt, y_min, y_max)
            Catch ex As Exception

            End Try

        End If

    End Sub

    Function getSelectedData(ByRef lst As ListBox) As String
        Dim retVal As String = ""
        For Each lstItem As ListItem In lst.Items
            If lstItem.Selected = True Then
                retVal &= "," & lstItem.Text & ""
            End If
        Next

        If (retVal.Length > 0) Then
            Return retVal.Substring(1)
        Else
            Return retVal
        End If

    End Function

    Sub LoadGradeTDC(ByVal fromDt As String, ByVal toDt As String)
        'Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("SELECT DISTINCT GRADE FROM RCL_JCAP_SURFACE_INSPECTION where date_create between '" & fromDt & "' and '" & toDt & "' ORDER BY GRADE;SELECT DISTINCT TDC_NO FROM RCL_JCAP_SURFACE_INSPECTION where date_create between '" & fromDt & "' and '" & toDt & "' ORDER BY TDC_NO")
        Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("SELECT DISTINCT GRADE FROM RCL_JCAP_SURFACE_INSPECTION ORDER BY GRADE;SELECT DISTINCT TDC_NO FROM RCL_JCAP_SURFACE_INSPECTION ORDER BY TDC_NO")
        Dim dt As DataTable = ds.Tables(0)
        Dim dt1 As DataTable = ds.Tables(1)
        lstGrade.DataSource = dt
        lstGrade.DataTextField = "GRADE"
        lstGrade.DataValueField = "GRADE"
        lstGrade.DataBind()

        lstTDC.DataSource = dt1
        lstTDC.DataTextField = "TDC_NO"
        lstTDC.DataValueField = "TDC_NO"
        lstTDC.DataBind()

        For Each lst As ListItem In lstGrade.Items
            lst.Selected = True
        Next

        For Each lst As ListItem In lstTDC.Items
            lst.Selected = True
        Next

    End Sub

    Sub LoadDefectList(ByVal fromDt As String, ByVal toDt As String)
        'Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT DISTINCT Defect_Name FROM RCL_JCAP_SURFACE_INSPECTION where date_create between '" & fromDt & "' and '" & toDt & "' and Defect_Name !=''  ORDER BY DEFECT_NAME").Tables(0)
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT DISTINCT Defect_Name FROM RCL_JCAP_SURFACE_INSPECTION where Defect_Name !=''  ORDER BY DEFECT_NAME").Tables(0)
        lstDefName.DataSource = dt
        lstDefName.DataTextField = "Defect_Name"
        lstDefName.DataValueField = "Defect_Name"
        lstDefName.DataBind()
        For Each lst As ListItem In lstDefName.Items
            lst.Selected = True
        Next
        'If dt.Rows.Count > 0 Then
        '    lstDefName.Items.FindByText("SCUMD").Selected = True
        'End If
    End Sub


    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try
            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            'LoadDefectList(dtStart, dtEnd)
            'LoadGradeTDC(dtStart, dtEnd)
            hfFrom.Value = dtStart
            hfTo.Value = dtEnd
            Dim strDefect As String = getSelectedData(lstDefName)
            Dim strSeverity As String = getSelectedData(lstSeverity)
            Dim strGrade As String = getSelectedData(lstGrade)
            Dim strTDC As String = getSelectedData(lstTDC)


            If strDefect.Length > 0 Then
                strDefect = "'" & strDefect.Replace(",", "','") & "'"
            End If

            If strGrade.Length > 0 Then
                strGrade = "'" & strGrade.Replace(",", "','") & "'"
            End If

            If strTDC.Length > 0 Then
                strTDC = "'" & strTDC.Replace(",", "','") & "'"
            End If
            Dim poc As String = lstProcessingline.SelectedValue.ToString
            Dim dt As DataTable = objController.GetDataForInspection(dtStart, dtEnd, strDefect, poc, ddlMeasure.SelectedItem.ToString, lstProcessingline.SelectedItem.ToString, strSeverity, strGrade, strTDC)
            Dim yVal() As Decimal
            yVal = (From row In dt Select col = CDec(row("TotalDefect"))).ToArray()
            Dim y_min As String = yVal.Min() - (10 / 100 * yVal.Min)
            Dim y_max As String = yVal.Max() + (10 / 100 * yVal.Max)
            DrawChart(dtStart, dtEnd, strDefect, poc, strSeverity, strGrade, strTDC, dt, y_min, y_max)

        Catch ex As Exception
            Lit1.Text = ""
            Lit2.Text = ""
        End Try

    End Sub

    Sub DrawChart(ByVal FromDate As String, ByVal ToDate As String, ByVal DefectName As String, ByVal poc As String, ByVal Severity As String, ByVal Grade As String, ByVal TDC As String, ByVal dt As DataTable, ByVal y_min As String, ByVal y_max As String)
        Try
            Session("ddlMeasure") = "sum"
            If ddlMeasure.SelectedIndex > 0 Then
                Session("ddlMeasure") = "count"
            End If
            Dim strFromDate As String = FromDate
            Dim strToDate As String = ToDate
            ' Dim dt As DataTable = objController.GetDataForInspection(strFromDate, strToDate, DefectName, poc, Severity, Grade, TDC)
            'Dim dt1 As DataTable = GetInspectionData(strFromDate, strToDate)
            If dt.Rows.Count > 0 Then
                'objController.PlotLineChartForInspection(dt, "dateCreate", "TotalDefect", Lit1, "container", "plot1", "", "", 1)
                heading.Text = " Defect Trend W.r.t " & lstProcessingline.SelectedItem.ToString
                ymin.Text = y_min
                ymax.Text = y_max
                objController.PlotLineChartForInsp(lstProcessingline.SelectedItem.ToString, ddlMeasure.SelectedItem.ToString, dt, "dateCreate", "TotalDefect", Lit1, "container", "plot1", "", "", "surface", FromDate, ToDate, y_min, y_max)

            Else
                Lit1.Text = ""
            End If
            'If dt1.Rows.Count > 0 Then
            '    'objController.PlotLineChartForInsp(dt1, "dateCreate", "TotalDefect", Lit2, "container1", "plot2", "", "", "surface")
            'Else
            '    Lit2.Text = ""
            'End If
        Catch ex As Exception
            Lit1.Text = ""
            Lit2.Text = ""
        End Try
    End Sub
    Sub CloseConnection()
        Try
            If Oleconnection_ora.State <> ConnectionState.Closed Then
                Oleconnection_ora.Close()
            End If
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub
    Public Function Ora_selectquery(ByVal strselect As String) As OleDbDataAdapter
        OleCom.Connection = Oleconnection_ora
        OleCom.CommandText = strselect
        OleAdap.SelectCommand = OleCom
        Return OleAdap
    End Function

    Public Function GetInspectionData(ByVal FromDate As String, ByVal ToDate As String) As DataTable
        Try
            Dim strFromDate As String = FromDate
            Dim strToDate As String = ToDate
            CloseConnection()
            Oleconnection_ora.Open()
            ds.Clear()
            dt.Clear()
            Dim OraQuery As String = "select cast(date_create as date) as dateCreate,surface,sum(defect_length) as defect, count(Daughter_Coil) as coil,cast(cast(sum(defect_length) as numeric(8,3))/cast(count(Daughter_Coil) as numeric(8,3)) as numeric(8,3)) as TotalDefect  from CAPL_INSP_NEW where date_create between '" & FromDate & "' and '" & ToDate & "' and (Surface = 'B' or surface='T')  group by cast(date_create as date),surface order by cast(date_create as date)"
            Ora_selectquery(OraQuery)
            OleAdap.Fill(ds)
            dt = ds.Tables(0)
            Return dt
        Catch ex As Exception
            Lit1.Text = ""
            Lit2.Text = ""
        End Try
    End Function

    Protected Sub btnGo_Click(sender As Object, e As System.EventArgs) Handles btnGo.Click
        Try

       
        Dim strDefect As String = getSelectedData(lstDefName)
        Dim strSeverity As String = getSelectedData(lstSeverity)
        Dim strGrade As String = getSelectedData(lstGrade)
        Dim strTDC As String = getSelectedData(lstTDC)


        If strDefect.Length > 0 Then
            strDefect = "'" & strDefect.Replace(",", "','") & "'"
        End If

        If strGrade.Length > 0 Then
            strGrade = "'" & strGrade.Replace(",", "','") & "'"
        End If

        If strTDC.Length > 0 Then
            strTDC = "'" & strTDC.Replace(",", "','") & "'"
        End If
        Dim poc As String = lstProcessingline.SelectedValue.ToString
            Dim dt As DataTable = objController.GetDataForInspection(hfFrom.Value, hfTo.Value, strDefect, poc, ddlMeasure.SelectedItem.ToString, lstProcessingline.SelectedItem.ToString, strSeverity, strGrade, strTDC)

        Dim yVal() As Decimal
        yVal = (From row In dt Select col = CDec(row("TotalDefect"))).ToArray()
        Dim y_min As String = yVal.Min() - (10 / 100 * yVal.Min)
        Dim y_max As String = yVal.Max() + (10 / 100 * yVal.Max)
            DrawChart(hfFrom.Value, hfTo.Value, strDefect, poc, strSeverity, strGrade, strTDC, dt, y_min, y_max)
        Catch ex As Exception
            Lit1.Text = ""
            Lit2.Text = ""
        End Try
    End Sub

    Protected Sub Axis_btn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Axis_btn.Click
        Try

       
        Dim strDefect As String = getSelectedData(lstDefName)
        Dim strSeverity As String = getSelectedData(lstSeverity)
        Dim strGrade As String = getSelectedData(lstGrade)
        Dim strTDC As String = getSelectedData(lstTDC)


        If strDefect.Length > 0 Then
            strDefect = "'" & strDefect.Replace(",", "','") & "'"
        End If

        If strGrade.Length > 0 Then
            strGrade = "'" & strGrade.Replace(",", "','") & "'"
        End If

        If strTDC.Length > 0 Then
            strTDC = "'" & strTDC.Replace(",", "','") & "'"
        End If
        Dim poc As String = lstProcessingline.SelectedValue.ToString

            Dim dt As DataTable = objController.GetDataForInspection(hfFrom.Value, hfTo.Value, strDefect, poc, ddlMeasure.SelectedItem.ToString, lstProcessingline.SelectedItem.ToString, strSeverity, strGrade, strTDC)
        DrawChart(hfFrom.Value, hfTo.Value, strDefect, poc, strSeverity, strGrade, strTDC, dt, ymin.Text, ymax.Text)

        Catch ex As Exception
            Lit1.Text = ""
            Lit2.Text = ""
        End Try
    End Sub

   
   
    Protected Sub tdc_checkbox_CheckedChanged(sender As Object, e As System.EventArgs) Handles tdc_checkbox.CheckedChanged
        If tdc_checkbox.Checked = True Then
            lstGrade.Visible = False
        Else
            lstGrade.Visible = True
        End If
    End Sub
End Class
