﻿Imports System.Data
Imports System.IO
Imports System.Data.OleDb
Imports System.Drawing

Partial Class InspectionDefByLength
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim objDataHandler As New DataHandler
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        
        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    txtDate_TextChanged()
                End If

            Catch ex As Exception

            End Try

        End If

        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                hfFrom.Value = dtStart
                hfTo.Value = dtEnd
                'DrawChart(dtStart, dtEnd, ddlDefName.SelectedItem.Text, ddlSurface.SelectedValue.ToString())
                DrawChart(dtStart, dtEnd, ddlDefName.SelectedItem.Text, "")
            Catch ex As Exception

            End Try

        End If

    End Sub
    Sub DrawChart(ByVal FromDate As String, ByVal ToDate As String, ByVal DefectName As String, ByVal Surface As String)
        Try
            Dim strFromDate As String = FromDate
            Dim strToDate As String = ToDate
            Dim dt As DataTable = objController.GetDataForInspectionByLength(strFromDate, strToDate, DefectName, "B")
            Dim dt1 As DataTable = objController.GetDataForInspectionByLength(strFromDate, strToDate, DefectName, "T")

            If dt.Rows.Count > 0 Then
                objController.DrawHeatChartForInsDefByLen(dt, Lit1, "container", "BOTTOM")
                objController.DrawHeatChartForInsDefByLen(dt1, Lit2, "container1", "TOP", 1)
               
            Else
                Lit1.Text = ""
            End If
           
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try
            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            'DrawChart(dtStart, dtEnd, ddlDefName.SelectedItem.Text, ddlSurface.SelectedValue.ToString())
            DrawChart(dtStart, dtEnd, ddlDefName.SelectedItem.Text, "")
        Catch ex As Exception

        End Try

    End Sub

    
  
    Protected Sub ddlSurface_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlSurface.SelectedIndexChanged
        Try
            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            DrawChart(dtStart, dtEnd, ddlDefName.SelectedItem.Text, ddlSurface.SelectedValue.ToString())
        Catch ex As Exception

        End Try
    End Sub
End Class
