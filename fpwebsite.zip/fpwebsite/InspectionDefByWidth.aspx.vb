﻿Imports System.Data
Imports System.IO
Imports System.Data.OleDb
Imports System.Web.Services
Imports System.Data.SqlClient
Imports System.Drawing

Partial Class InspectionDefByWidth
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim objDataHandler As New DataHandler
    
    ''' '''''''''''''''''''''''''''''''''''''''''''
    Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("ACPM_Ora").ConnectionString
    Dim Oleconnection_ora As New OleDbConnection(strConnectionString)
    Dim OleAdap As New OleDbDataAdapter
    Dim ds, ds1 As New DataSet
    Dim dt, dt1 As New DataTable
    Dim OleCom As New OleDbCommand
    Dim defectName As String = ""
    Dim severity As String = ""
    ''' '''''''''''''''''''''''''''''''''''''''''''


    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
              
                If date_rd.Checked = True Then
                    txtCoilwise.Enabled = False
                    txtCoilwise.Text = Nothing
                    start.Visible = True
                    End_val.Visible = True
                    Label1.Visible = True
                    Label2.Visible = True
                    Lit1.Text = ""
                    Lit2.Text = ""
                Else
                    txtCoilwise.Enabled = True
                    start.Visible = False
                    End_val.Visible = False
                    Label1.Visible = False
                    Label2.Visible = False
                    Lit1.Text = ""
                    Lit2.Text = ""
                End If
                If p = "date" Then
                    txtDate_TextChanged()
                End If
                If mesrlist.SelectedItem.ToString = "Length" Then
                    Bu2.Text = "m"
                    Bu4.Text = "m"
                    Bu5.Text = "m"
                Else
                    Bu2.Text = "count"
                    Bu4.Text = "count"
                    Bu5.Text = "count"
                End If
            Catch ex As Exception

            End Try

        End If

        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                LoadDefectList(dtStart, dtEnd)
                LoadGradeTDC(dtStart, dtEnd)

                hfFrom.Value = dtStart
                hfTo.Value = dtEnd
                ''''''''''''''''''''''''''''''''''''

                ''''''''''''''''''''''''''''''''''''
                'DrawChart(dtStart, dtEnd, ddlDefName.SelectedItem.Text, ddlSurface.SelectedValue.ToString())
                Dim strDefect As String = getSelectedData(lstDefName)
                Dim strSeverity As String = getSelectedData(lstSeverity)
                Dim strGrade As String = getSelectedData(lstGrade)
                Dim strTDC As String = getSelectedData(lstTDC)
                Try
                    If strDefect.Length > 0 Then
                        strDefect = "'" & strDefect.Replace(",", "','") & "'"
                    End If

                    If strGrade.Length > 0 Then
                        strGrade = "'" & strGrade.Replace(",", "','") & "'"
                    End If

                    If strTDC.Length > 0 Then
                        strTDC = "'" & strTDC.Replace(",", "','") & "'"
                    End If

                Catch ex As Exception

                End Try
                'DrawChart(dtStart, dtEnd, ddlDefName.SelectedItem.Text, ddlSurface.SelectedValue.ToString())
                DrawChart(dtStart, dtEnd, strDefect, strSeverity, strGrade, strTDC)
            Catch ex As Exception

            End Try

        End If

    End Sub
    'Sub LoadGradeTDC(ByVal fromDt As String, ByVal toDt As String)
    '    'Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("SELECT DISTINCT GRADE FROM RCL_JCAP_SURFACE_INSPECTION where date_create between '" & fromDt & "' and '" & toDt & "'   ORDER BY GRADE;SELECT DISTINCT TDC_NO FROM RCL_JCAP_SURFACE_INSPECTION where date_create between '" & fromDt & "' and '" & toDt & "' and  TDC_NO != '' ORDER BY TDC_NO")
    '    Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("SELECT DISTINCT GRADE FROM RCL_JCAP_SURFACE_INSPECTION  ORDER BY GRADE;select distinct(TDC_No),CCL_TDC_AIM from RCL_JCAP_SURFACE_INSPECTION inner join CRM_HR_CR_RLN on Mother_Coil = CR_COIL_ID   order by TDC_No")
    '    Dim dt As DataTable = ds.Tables(0)
    '    Dim dt1 As DataTable = ds.Tables(1)
    '    lstGrade.DataSource = dt
    '    lstGrade.DataTextField = "GRADE"
    '    lstGrade.DataValueField = "GRADE"
    '    lstGrade.DataBind()

    '    Dim dtValue As DataTable
    '    Dim tdc_table As New DataTable
    '    '' Dim tdc_string As String = Nothing
    '    tdc_table.Columns.Add("tdc_text")
    '    tdc_table.Columns.Add("tdc_value")
    '    Dim dtDist As DataTable = dt1.DefaultView.ToTable(True, "TDC_No")
    '    For i As Integer = 0 To dtDist.Rows.Count - 1
    '        Dim tdc_string As String = Nothing
    '        Dim query = From val In dt1.AsEnumerable() Where val.Field(Of String)("TDC_No") = dtDist.Rows(i)(0) Select val
    '        dtValue = query.CopyToDataTable() ''distict values group
    '        For count As Integer = 0 To dtValue.Rows.Count - 1
    '            If count = 0 Then
    '                tdc_string &= dtValue.Rows(count)("CCL_TDC_AIM")
    '            Else
    '                tdc_string &= ","
    '                tdc_string &= dtValue.Rows(count)("CCL_TDC_AIM")
    '            End If

    '        Next
    '        Dim newRow As DataRow = tdc_table.NewRow()
    '        newRow("tdc_text") = dtValue.Rows(0)("TDC_No").ToString
    '        newRow("tdc_value") = tdc_string
    '        tdc_table.Rows.Add(newRow)
    '    Next
    '    lstTDC.DataSource = tdc_table
    '    lstTDC.DataTextField = "tdc_text"
    '    lstTDC.DataValueField = "tdc_value"
    '    lstTDC.DataBind()

    '    For Each lst As ListItem In lstGrade.Items
    '        lst.Selected = True
    '    Next

    '    'For Each lst As ListItem In lstTDC.Items
    '    '    lst.Selected = True
    '    'Next

    'End Sub


    Sub LoadGradeTDC(ByVal fromDt As String, ByVal toDt As String)
        'Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("SELECT DISTINCT GRADE FROM RCL_JCAP_SURFACE_INSPECTION where date_create between '" & fromDt & "' and '" & toDt & "'   ORDER BY GRADE;SELECT DISTINCT TDC_NO FROM RCL_JCAP_SURFACE_INSPECTION where date_create between '" & fromDt & "' and '" & toDt & "' and  TDC_NO != '' ORDER BY TDC_NO")
        Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("SELECT DISTINCT GRADE FROM RCL_JCAP_SURFACE_INSPECTION  ORDER BY GRADE;SELECT DISTINCT TDC_NO FROM RCL_JCAP_SURFACE_INSPECTION where  TDC_NO != '' ORDER BY TDC_NO")
        Dim dt As DataTable = ds.Tables(0)
        Dim dt1 As DataTable = ds.Tables(1)
        lstGrade.DataSource = dt
        lstGrade.DataTextField = "GRADE"
        lstGrade.DataValueField = "GRADE"
        lstGrade.DataBind()

        lstTDC.DataSource = dt1
        lstTDC.DataTextField = "TDC_NO"
        lstTDC.DataValueField = "TDC_NO"
        lstTDC.DataBind()

        For Each lst As ListItem In lstGrade.Items
            lst.Selected = True
        Next

        For Each lst As ListItem In lstTDC.Items
            lst.Selected = True
        Next

    End Sub


    Sub LoadDefectList(ByVal fromDt As String, ByVal toDt As String)
        ' Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT DISTINCT Defect_Name FROM RCL_JCAP_SURFACE_INSPECTION where date_create between '" & fromDt & "' and '" & toDt & "' AND Defect_Name != '' ORDER BY DEFECT_NAME").Tables(0)
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT DISTINCT Defect_Name FROM RCL_JCAP_SURFACE_INSPECTION where  Defect_Name != '' ORDER BY DEFECT_NAME").Tables(0)
        lstDefName.DataSource = dt
        lstDefName.DataTextField = "Defect_Name"
        lstDefName.DataValueField = "Defect_Name"
        lstDefName.DataBind()

        If dt.Rows.Count > 0 Then
            lstDefName.Items.FindByText("SCUM D").Selected = True
        End If
    End Sub

    Sub DrawChart(ByVal FromDate As String, ByVal ToDate As String, ByVal DefectName As String, ByVal Severity As String, ByVal Grade As String, ByVal TDC As String)
        Try
            Labelheader.Text = "Width_wise Defect Data w.r.t " & lstProcessingline.SelectedItem.ToString
            Dim strFromDate As String = FromDate
            Dim strToDate As String = ToDate
            Dim radio_select As String = Nothing
            If Convert.ToInt32(lowfrom.Text) < Convert.ToInt32(lowto.Text) Then
                If Convert.ToInt32(lowto.Text) <= Convert.ToInt32(midfrom.Text) Then
                    If Convert.ToInt32(midfrom.Text) <= Convert.ToInt32(highval.Text) Then

                        If coilid_rd.Checked = True Then
                            radio_select = "coil"
                        ElseIf date_rd.Checked = True Then
                            radio_select = "date"

                        End If
                        Dim dt As DataTable = objController.GetDataForInspectionByWidth(strFromDate, strToDate, DefectName, "B", start.Text, End_val.Text, mesrlist.SelectedItem.ToString, lstProcessingline.SelectedItem.ToString, lstProcessingline.SelectedValue.ToString, radio_select, txtCoilwise.Text, Severity, Grade, TDC)
                        'Dim dt1 As DataTable = objController.GetDataForInspectionByWidth(strFromDate, strToDate, DefectName, "T", mesrlist.SelectedItem.ToString, lstProcessingline.SelectedItem.ToString, Severity, Grade, TDC)
                        If dt.Rows.Count > 0 Then
                            Session("DefectName") = DefectName
                            Session("Severity") = Severity
                            Session("Grade") = Grade
                            Session("TDC") = TDC
                            Session("lowfrom") = lowfrom.Text
                            Session("lowto") = lowto.Text
                            Session("midfrom") = midfrom.Text
                            Session("midto") = midto.Text
                            Session("highval") = highval.Text
                            Session("process_line") = Convert.ToString(lstProcessingline.SelectedValue)
                            Session("process_line_name") = Convert.ToString(lstProcessingline.SelectedItem.Text)
                            ''SLAB REVERSAL
                            Dim process_a As String = Nothing
                            Dim process_b As String = Nothing
                            Dim slab_rev As String = objController.slab_reversal(lstProcessingline.SelectedItem.Text)
                            Dim s As String() = slab_rev.Split(New Char() {","c})
                            ''BOTTOM_PLOT
                            process_a = s(0)
                            ''TOP_PLOT
                            process_b = s(1)


                            ''BOTTOM
                            objController.DrawHeatChartForInsDefByWidth(lstProcessingline.SelectedItem.Text, dt, Lit1, "subcontainer1", 1, 5, lowfrom.Text, lowto.Text, midfrom.Text, midto.Text, highval.Text, mesrlist.SelectedItem.ToString, process_a, defectName:=DefectName.Replace("'", ""), grade:=Grade, tdcno:=TDC, proc:=radio_select, indx:=1)
                            ''TOP
                            objController.DrawHeatChartForInsDefByWidth(lstProcessingline.SelectedItem.Text, dt, Lit2, "subcontainer", 1, 5, lowfrom.Text, lowto.Text, midfrom.Text, midto.Text, highval.Text, mesrlist.SelectedItem.ToString, process_b, defectName:=DefectName.Replace("'", ""), grade:=Grade, tdcno:=TDC, proc:=radio_select, indx:=2)


                            If mesrlist.SelectedItem.ToString = "Length" Then
                                Bu2.Text = "m"
                                Bu4.Text = "m"
                                Bu5.Text = "m"
                            Else
                                Bu2.Text = "count"
                                Bu4.Text = "count"
                                Bu5.Text = "count"
                            End If
                        Else
                            Lit1.Text = ""
                            Lit2.Text = ""
                        End If

                    Else
                        Response.Write("<script type=""text/javascript"">alert(""value should be lower or equal last enterd value"");</script")
                    End If
                Else
                    Response.Write("<script type=""text/javascript"">alert(""value should be lower or equal last enterd value"");</script")
                End If
            Else
                Response.Write("<script type=""text/javascript"">alert(""value should be lower than last enterd value"");</script")
            End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try
            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value

            Dim strDefect As String = getSelectedData(lstDefName)
            Dim strSeverity As String = getSelectedData(lstSeverity)
            Dim strGrade As String = getSelectedData(lstGrade)
            Dim strTDC As String = getSelectedData(lstTDC)

            If strDefect.Length > 0 Then
                strDefect = "'" & strDefect.Replace(",", "','") & "'"
            End If

            If strGrade.Length > 0 Then
                strGrade = "'" & strGrade.Replace(",", "','") & "'"
            End If

            If strTDC.Length > 0 Then
                strTDC = "'" & strTDC.Replace(",", "','") & "'"
            End If

            DrawChart(dtStart, dtEnd, strDefect, strSeverity, strGrade, strTDC)
        Catch ex As Exception

        End Try

    End Sub

    Function getSelectedData(ByRef lst As ListBox) As String
        Dim retVal As String = ""
        Try
            For Each lstItem As ListItem In lst.Items
                If lstItem.Selected = True Then
                    retVal &= "," & lstItem.Value & ""
                End If
            Next

        Catch ex As Exception

        End Try

        If retVal.Length > 0 Then
            Return retVal.Substring(1)
        Else
            Return retVal
        End If


        'Return (retVal)
    End Function


    'Function getSelectedData(ByRef lst As ListBox) As String
    '    Dim retVal As String = ""
    '    Try
    '        For Each lstItem As ListItem In lst.Items
    '            If lstItem.Selected = True Then
    '                retVal &= "," & lstItem.Text & ""
    '            End If
    '        Next

    '    Catch ex As Exception

    '    End Try

    '    If retVal.Length > 0 Then
    '        Return retVal.Substring(1)
    '    Else
    '        Return retVal
    '    End If


    '    'Return (retVal)
    'End Function

    Protected Sub btnGo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnGo.Click
        Try

            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            'LoadDefectList(dtStart, dtEnd)

            Dim strDefect As String = getSelectedData(lstDefName)
            Dim strSeverity As String = getSelectedData(lstSeverity)
            Dim strGrade As String = getSelectedData(lstGrade)
            Dim strTDC As String = getSelectedData(lstTDC)

            If strDefect.Length > 0 Then
                strDefect = "'" & strDefect.Replace(",", "','") & "'"
            End If

            If strGrade.Length > 0 Then
                strGrade = "'" & strGrade.Replace(",", "','") & "'"
            End If

            If strTDC.Length > 0 Then
                strTDC = "'" & strTDC.Replace(",", "','") & "'"
            End If
            If date_rd.Checked = True Then
                DrawChart(dtStart, dtEnd, strDefect, strSeverity, strGrade, strTDC)
            ElseIf coilid_rd.Checked = True Then
                Dim dt As DataTable = GetInspectionWidthData(txtCoilwise.Text)

                Dim cnt As Integer = 1
                Dim lenCoil(0) As Integer
                Dim CoilIdArr(0) As String

                lenCoil(0) = dt.Rows(0)("ccl_length")
                Dim dt1 As DataSet = FetchSqlData1(txtCoilwise.Text)
                If dt1.Tables(0).Rows.Count > 1 Then
                    cnt = dt1.Tables(0).Rows.Count

                    ReDim CoilIdArr(cnt - 1)
                    For i As Integer = 0 To dt1.Tables(0).Rows.Count - 1
                        CoilIdArr(i) = dt1.Tables(0).Rows(i)("Daughter_Coil")
                    Next
                Else
                    CoilIdArr(0) = dt1.Tables(0).Rows(0)("Daughter_Coil")
                End If
                DrawChart(lenCoil, CoilIdArr, strDefect, strSeverity, strGrade, strTDC)
                ''''''''''''''''''''''''''''''''''''''''''''
            End If

        Catch ex As Exception

        End Try

    End Sub



    <WebMethod()>
    Public Shared Function GetAutoCompleteData(ByVal username As String) As List(Of String)
        Dim result As List(Of String) = New List(Of String)()

        Using con As SqlConnection = New SqlConnection("server=176.0.0.60\LPTGSQLDEV;database=FP_PROCESS_DATA;uid=153521;pwd=Welcome@135")

            Using cmd As SqlCommand = New SqlCommand("select distinct top 10 Mother_Coil from RCL_JCAP_SURFACE_INSPECTION  inner join CRM_HR_CR_RLN on Mother_Coil = CR_COIL_ID where Mother_Coil  LIKE '%'+@SearchText+'%'", con)
                con.Open()
                cmd.Parameters.AddWithValue("@SearchText", username)
                Dim dr As SqlDataReader = cmd.ExecuteReader()

                While dr.Read()
                    result.Add(String.Format("{0}", dr("Mother_Coil")))
                End While

                Return result
            End Using
        End Using
    End Function
    Function FetchSqlData(ByVal coilid As String, ByVal DefectName As String, ByVal Severity As String, ByVal Grade As String, ByVal TDC As String, ByVal length As String, ByVal total As Integer) As DataSet
        If (coilid.Substring(0, 1) = "J") Then
            coilid = coilid.Substring(0, 8) + "%"
        Else
            coilid = coilid.Substring(0, 7) + "%"
        End If
        ''SLAB REVERSAL
        Dim process_a As String = Nothing
        Dim process_b As String = Nothing
        Dim slab_rev As String = objController.slab_reversal(lstProcessingline.SelectedItem.Text)
        Dim s As String() = slab_rev.Split(New Char() {","c})
        ''BOTTOM_PLOT
        process_a = s(0)
        ''TOP_PLOT
        process_b = s(1)

        Dim fil As String = " select * from CRM_HR_CR_RLN where CR_COIL_ID like '" & txtCoilwise.Text & "'"

        Dim data As DataTable = objDataHandler.GetDataSetFromQuery(fil).Tables(0)
        Dim rcl_fil As String = Nothing
        If data.Rows(0)("JCAP_STATUS") = "Y" Then
            rcl_fil = ",,,"
            ''BOTTOM_PLOT
            process_a = "B"
            ''TOP_PLOT
            process_b = "T"

        Else
            If Not IsDBNull(data.Rows(0)("RCL1_DATETIME")) Then

                If lstProcessingline.SelectedItem.Text = "PLTCM" Then ''100 is used to invert head to tail and vice versa'' 6 is used  to invert OS to DS and vice versa
                    rcl_fil = ",,,"
                    'ElseIf lstProcessingline.SelectedItem.Text = "HSM" Then
                    '    rcl_fil = "100 -,,"

                ElseIf lstProcessingline.SelectedItem.Text = "ECL" Then
                    rcl_fil = ",6 -,"
                ElseIf lstProcessingline.SelectedItem.Text = "SPM" Then
                    rcl_fil = "100 -,,"
                ElseIf lstProcessingline.SelectedItem.Text = "BAF" Then
                    rcl_fil = ",6 -,"
                Else
                    rcl_fil = ",,,"
                End If
            ElseIf Not IsDBNull(data.Rows(0)("RCL2_DATETIME")) Then
                If lstProcessingline.SelectedItem.Text = "PLTCM" Then
                    rcl_fil = ",6 -,"
                    'ElseIf lstProcessingline.SelectedItem.Text = "HSM" Then
                    '    rcl_fil = "100 -,,"

                ElseIf lstProcessingline.SelectedItem.Text = "ECL" Then
                    rcl_fil = ",,,"
                ElseIf lstProcessingline.SelectedItem.Text = "SPM" Then
                    rcl_fil = "100 -,6 -,"
                ElseIf lstProcessingline.SelectedItem.Text = "BAF" Then
                    rcl_fil = ",,"

                Else
                    rcl_fil = ",,,"
                End If

            ElseIf Not IsDBNull(data.Rows(0)("RCL3_DATETIME")) Then
                If lstProcessingline.SelectedItem.Text = "PLTCM" Then
                    rcl_fil = " ,6 -,"
                    'ElseIf lstProcessingline.SelectedItem.Text = "HSM" Then
                    '    rcl_fil = "100 -,,"

                ElseIf lstProcessingline.SelectedItem.Text = "ECL" Then
                    rcl_fil = ",,,"
                ElseIf lstProcessingline.SelectedItem.Text = "SPM" Then
                    rcl_fil = "100 -,6 -,,"
                ElseIf lstProcessingline.SelectedItem.Text = "BAF" Then
                    rcl_fil = ",,,"
                Else
                    rcl_fil = ",,,"
                End If
            Else
                rcl_fil = ",,,"
                ''BOTTOM_PLOT
                process_a = "B"
                ''TOP_PLOT
                process_b = "T"

            End If


        End If

        Dim qur_fil() As String = rcl_fil.Split(",")

        Dim q As String = "select distinct date_create as dateCreate,Daughter_Coil,surface,Length_Coil,cast(Defect_St_Length  as numeric(5,0)) as Defect_St_Length,Defect_End_Length,cast(" & qur_fil(0) & "(cast(Defect_St_Length + " & length & " as numeric(8,4)) * 100/" & total & ") as numeric(8,4)) as DefectStart,cast(" & qur_fil(0) & "(cast(Defect_End_Length + " & length & " as numeric(8,4)) * 100/" & total & ") as numeric(8,4)) as DefectEnd,( " & qur_fil(1) & " Defect_St_Width) as Defect_St_Width  , (" & qur_fil(1) & " Defect_End_Width) as Defect_End_Width,severity,[Defect_Length] from [RCL_JCAP_SURFACE_INSPECTION] where Defect_Name in (" & DefectName & ") and  Surface = '" & process_b.Substring(0, 1) & "' and Daughter_coil like '" & coilid & "' and severity in (" & Severity & ") and TDC_No in (" & TDC & ") order by cast(Defect_St_Length as numeric(5,0));select distinct date_create as dateCreate,Daughter_Coil,surface,Length_Coil,cast(Defect_St_Length as numeric(5,0)) as Defect_St_Length,Defect_End_Length,cast(" & qur_fil(0) & "(cast(Defect_St_Length + " & length & " as numeric(8,4)) * 100/" & total & ") as numeric(8,4)) as DefectStart,cast(" & qur_fil(0) & "(cast(Defect_End_Length + " & length & " as numeric(8,4)) * 100/" & total & ") as numeric(8,4)) as DefectEnd,( " & qur_fil(1) & " Defect_St_Width) as Defect_St_Width  , (" & qur_fil(1) & " Defect_End_Width) as Defect_End_Width,severity,[Defect_Length] from [RCL_JCAP_SURFACE_INSPECTION] where Defect_Name in (" & DefectName & ") and  Surface = '" & process_a.Substring(0, 1) & "' and Daughter_coil like '" & coilid & "' and severity in (" & Severity & ") and TDC_No in (" & TDC & ")  order by cast(Defect_St_Length as numeric(5,0)) "
        Return objDataHandler.GetDataSetFromQuery(q)
    End Function

    Function FetchSqlData1(ByVal coilid As String) As DataSet
        coilid = coilid.Substring(0, 7)

        Dim q As String = "SELECT distinct(CASE WHEN Daughter_Coil  like 'J%' THEN CONCAT(SUBSTRING(Daughter_Coil,0,9),'00') ELSE CONCAT(SUBSTRING(Daughter_Coil,0,8),'000') END )  as Daughter_Coil   from [RCL_JCAP_SURFACE_INSPECTION] where Mother_Coil like '" & coilid & "%'"
        '' Dim q As String = "select distinct Daughter_Coil from [RCL_JCAP_SURFACE_INSPECTION] where Mother_Coil like c"
        Return objDataHandler.GetDataSetFromQuery(q)
    End Function

    Function FetchSqlData2(ByVal coilid As String, ByVal DefectName As String, ByVal Severity As String, ByVal Grade As String, ByVal TDC As String) As DataSet

        Dim q As String = "select Daughter_Coil, ( Length_Coil) as len from [RCL_JCAP_SURFACE_INSPECTION] where  Daughter_coil like '" & coilid & "'  and severity in (1,2,3,4,5,6,7)   order by len desc"
        Return objDataHandler.GetDataSetFromQuery(q)
    End Function




    'Function FetchSqlData(ByVal coilid As String, ByVal DefectName As String, ByVal Severity As String, ByVal Grade As String, ByVal TDC As String) As DataSet

    '    Dim q As String = "select distinct date_create as dateCreate,Daughter_Coil,surface,Length_Coil,cast(Defect_St_Length as numeric(5,0)) as Defect_St_Length,Defect_End_Length,cast((cast(Defect_St_Length as numeric(8,4)) * 100/Length_Coil) as numeric(8,4)) as DefectStart,cast((cast(Defect_End_Length as numeric(8,4)) * 100/Length_Coil) as numeric(8,4)) as DefectEnd,Defect_St_Width,Defect_End_Width,severity,[Defect_Length] from [RCL_JCAP_SURFACE_INSPECTION] where Defect_Name in (" & DefectName & ") and  Surface = 'T' and Daughter_coil like '" & coilid & "' and severity in (" & Severity & ") order by cast(Defect_St_Length as numeric(5,0));select distinct date_create as dateCreate,Daughter_Coil,surface,Length_Coil,cast(Defect_St_Length as numeric(5,0)) as Defect_St_Length,Defect_End_Length,cast((cast(Defect_St_Length as numeric(8,4)) * 100/Length_Coil) as numeric(8,4)) as DefectStart,cast((cast(Defect_End_Length as numeric(8,4)) * 100/Length_Coil) as numeric(8,4)) as DefectEnd,Defect_St_Width,Defect_End_Width,severity,[Defect_Length] from [RCL_JCAP_SURFACE_INSPECTION] where Defect_Name in (" & DefectName & ") and  Surface = 'B' and Daughter_coil like '" & coilid & "' and severity in (" & Severity & ")  order by cast(Defect_St_Length as numeric(5,0)) "
    '    Return objDataHandler.GetDataSetFromQuery(q)
    'End Function
    'Function FetchSqlData1(ByVal coilid As String) As DataSet
    '    coilid = coilid.Substring(0, 7)

    '    Dim q As String = "SELECT distinct(CASE WHEN Daughter_Coil  like 'J%' THEN CONCAT(SUBSTRING(Daughter_Coil,0,9),'00') ELSE CONCAT(SUBSTRING(Daughter_Coil,0,8),'000') END )  as Daughter_Coil   from [RCL_JCAP_SURFACE_INSPECTION] where Mother_Coil like '" & coilid & "%'"
    '    '' Dim q As String = "select distinct Daughter_Coil from [RCL_JCAP_SURFACE_INSPECTION] where Mother_Coil like c"
    '    Return objDataHandler.GetDataSetFromQuery(q)
    'End Function

    Sub DrawChart(ByVal lenCoil() As Integer, ByVal CoilIdArr() As String, ByVal DefectName As String, ByVal Sever As String, ByVal Grade As String, ByVal TDC As String, Optional ByVal stepValue As Integer = 5)
        Try


            Dim s As New StringBuilder("<script>")
            Lit1.Text = " "
            Lit2.Text = " "
            s.Append("var hours = ['OS', 'OSC', 'C', 'DSC', 'DS'];")
            s.Append("var days= [")
            Dim markLineData As String = ""
            Dim coilId As String = ""
            Dim stIdx As Integer = 0
            Dim stIdx_B As Integer = 0
            Dim dataIdx As Integer = 0
            Dim rowValforTooltip As String = "var row = Math.floor(parseInt(params.data[1])/" & 100 \ stepValue & ");"
            Dim data((100 \ stepValue) * (CoilIdArr.Length), 4) As Integer
            Dim data_B((100 \ stepValue) * (CoilIdArr.Length), 4) As Integer
            Dim temp As String = ""
            Dim dat As New DataTable
            Dim dt As DataTable
            Dim dt_B As DataTable
            dat.Columns.Add("coil_id")
            dat.Columns.Add("length")
            Dim drNewRow As DataRow
            For v As Integer = 0 To CoilIdArr.Length - 1

                Dim tem As String = ""
                'For k As Integer = 0 To CoilIdArr.Length - 1
                '    temp
                'Next


                If (CoilIdArr(v).Substring(0, 1) = "J") Then
                    temp = CoilIdArr(v).Substring(0, 8) + "%"
                Else
                    temp = CoilIdArr(v).Substring(0, 7) + "%"
                End If
                Dim dset As DataSet = FetchSqlData2(temp, DefectName, Sever, Grade, TDC)
                If dset.Tables(0).Rows.Count > 0 Then
                    drNewRow = dat.NewRow
                    drNewRow.Item("coil_id") = dset.Tables(0).Rows(0)("Daughter_Coil")
                    drNewRow.Item("length") = dset.Tables(0).Rows(0)("len")
                    dat.Rows.Add(drNewRow)
                End If
            Next
            Dim percent_cal As Integer = 0
            If dat.Rows.Count > 0 Then

                Dim total_l As Integer = 0
                For v As Integer = 0 To dat.Rows.Count - 1
                    total_l = total_l + dat.Rows(v)("length")
                Next
                percent_cal = total_l
                For v As Integer = 0 To dat.Rows.Count - 1
                    Dim tem_val As Integer = 0
                    If v <> 0 Then
                        For co As Integer = 0 To v - 1
                            tem_val = tem_val + dat.Rows(co)("length")
                        Next
                    End If

                    If v = 0 Then
                        Dim temp_dat As DataSet = FetchSqlData(dat.Rows(v)("coil_id"), DefectName, Sever, Grade, TDC, tem_val, total_l)
                        dt = temp_dat.Tables(0)
                        dt_B = temp_dat.Tables(1)
                    Else
                        Dim temp_dat As DataSet = FetchSqlData(dat.Rows(v)("coil_id"), DefectName, Sever, Grade, TDC, tem_val, total_l)
                        If dt.Rows.Count > 0 Then
                            dt.Merge(temp_dat.Tables(0), False, MissingSchemaAction.Ignore)
                            dt.AcceptChanges()
                        Else
                            dt = temp_dat.Tables(0)
                        End If
                        If dt_B.Rows.Count > 0 Then
                            dt_B.Merge(temp_dat.Tables(1), False, MissingSchemaAction.Ignore)
                            dt_B.AcceptChanges()
                        Else
                            dt_B = temp_dat.Tables(1)
                        End If

                    End If
                Next
            End If

            Dim i As Integer = 0

            ''''
            For som As Integer = 0 To dat.Rows.Count - 1
                Dim marker As Integer = 0
                Dim marker1 As Integer = 0
                Dim tot As Integer = 0
                If lstProcessingline.SelectedItem.Text = "SPM" Then
                    For eX As Integer = 0 To som
                        tot = tot + dat.Rows(eX)("length")
                    Next
                    marker = (tot / percent_cal) * 100
                    marker1 = (Math.Round(marker / 5)) * (5)
                    ''  If (Session("process_l") = "PLTCM" And Not dat.Rows(som)("coil_id").ToString.StartsWith("J")) Or Session("process_l") = "HSM" Or Session("process_l") = "SPM" Then
                    marker1 = 100 - marker1
                    '' End If
                    If som > 0 Then
                        If (marker - marker1) > 0 Then
                            coilId &= ",'" & dat.Rows(som)("coil_id") & "'"
                            markLineData &= ",{yAxis:'" & marker1 & "-" & marker1 + 5 & "',name:'" & dat.Rows(som)("coil_id") & "',label: {normal: {position: 'end',formatter:'" & dat.Rows(som)("coil_id") & "'}}}"

                        Else
                            coilId &= ",'" & dat.Rows(som)("coil_id") & "'"
                            markLineData &= ",{yAxis:'" & marker1 & "-" & marker1 + 5 & "',name:'" & dat.Rows(som)("coil_id") & "',label: {normal: {position: 'end',formatter:'" & dat.Rows(som)("coil_id") & "'}}}"

                        End If
                    End If

                    If som = 0 Then
                        coilId &= ",'" & dat.Rows(som)("coil_id") & "'"
                        markLineData &= ",{yAxis:'" & marker1 & "-" & marker1 + 5 & "',name:'" & dat.Rows(som)("coil_id") & "',label: {normal: {position: 'end',formatter:'" & dat.Rows(som)("coil_id") & "'}}}"
                    End If

                Else


                    If som > 0 Then
                        For e As Integer = 0 To som - 1
                            tot = tot + dat.Rows(e)("length")
                        Next
                        marker = (tot / percent_cal) * 100
                        marker1 = (Math.Round(marker / 5)) * (5)
                        If (marker - marker1) > 0 Then
                            coilId &= ",'" & dat.Rows(som)("coil_id") & "'"
                            markLineData &= ",{yAxis:'" & marker1 + 5 & "-" & marker1 + 10 & "',name:'" & dat.Rows(som)("coil_id") & "',label: {normal: {position: 'end',formatter:'" & dat.Rows(som)("coil_id") & "'}}}"

                        Else
                            coilId &= ",'" & dat.Rows(som)("coil_id") & "'"
                            markLineData &= ",{yAxis:'" & marker1 - 5 & "-" & marker1 & "',name:'" & dat.Rows(som)("coil_id") & "',label: {normal: {position: 'end',formatter:'" & dat.Rows(som)("coil_id") & "'}}}"

                        End If
                    End If

                    If som = 0 Then
                        coilId &= ",'" & dat.Rows(som)("coil_id") & "'"
                        markLineData &= ",{yAxis:'0-5',name:'" & dat.Rows(som)("coil_id") & "',label: {normal: {position: 'end',formatter:'" & dat.Rows(som)("coil_id") & "'}}}"
                    End If
                End If
            Next



            'coilId &= ",'" & CoilIdArr(i) & "'"
            'markLineData &= ",{yAxis:'(" & (i + 1) & ".) 0-5',name:'" & CoilIdArr(i) & "',label: {normal: {position: 'end',formatter:'" & CoilIdArr(i) & "'}}}"


            ''  Dim ds As DataSet = FetchSqlData(temp, DefectName, Sever, Grade, TDC)


            stIdx = i * 100 \ stepValue
            stIdx_B = i * 100 \ stepValue
            If i > 0 Then s.Append(",")
            For j As Integer = 0 To 100 - stepValue Step stepValue
                If j > 0 Then s.Append(",")
                If j = 0 Then
                    s.Append("'(" & (i + 1) & ".) " & j & "-" & (j + stepValue) & "'")
                Else
                    s.Append("'" & j & "-" & (j + stepValue) & "'")
                End If

            Next
            Dim stLen, enLen As Integer
            Dim stWidth, enWidth As Integer
            Dim severity As Double
            Dim coun As Integer
            For row As Integer = 0 To dt.Rows.Count - 1
                If Convert.ToInt32(dt.Rows(row)("Defect_St_Width")) > Convert.ToInt32(dt.Rows(row)("Defect_End_Width")) Then
                    stWidth = dt.Rows(row)("Defect_End_Width")
                    enWidth = dt.Rows(row)("Defect_St_Width")
                Else
                    stWidth = dt.Rows(row)("Defect_St_Width")
                    enWidth = dt.Rows(row)("Defect_End_Width")
                End If

                Dim tem As Integer = Nothing
                For c As Integer = 0 To 100 - stepValue Step stepValue
                    Dim start As Integer = dt.Rows(row)("DefectStart")
                    Dim endv As Integer = dt.Rows(row)("DefectEnd")
                    If ((start >= c And start <= c + stepValue) Or (endv >= c And endv <= c + stepValue)) Then
                        tem += 1
                    Else
                        If ((start >= c And start < c + stepValue) Or (endv >= c And endv < c + stepValue) Or (start >= c - (endv - start) And start < c + stepValue)) Then
                            tem += 1
                        End If
                    End If
                Next
                ''''''''''''''''''''''''''''''''

                If tem > 1 Then
                    For fir As Integer = 0 To 10
                        severity = (Convert.ToInt32(dt.Rows(row)("Defect_Length")) - fir) / tem
                        Dim st() As String = severity.ToString.Split(".")
                        If st.Length > 1 Then
                            Try
                                If st(1) = 0 Then
                                    coun = fir
                                    Exit For
                                Else
                                    Continue For
                                End If
                            Catch ex As Exception

                            End Try
                        Else
                            coun = fir
                            Exit For
                        End If
                    Next
                Else
                    severity = Convert.ToInt32(dt.Rows(row)("Defect_Length")) / tem
                    coun = 0
                End If
                ''''''''''''''''''''''''
                '' severity = Convert.ToInt32(dt.Rows(row)("Defect_Length")) / tem
                Dim flag As Integer = 0
                For c As Integer = 0 To 100 - stepValue Step stepValue
                    'dv(l)(6) <= minval And dv.Item(l)(7) >= minval) OrElse (dv(l)(6) <= maxval And dv.Item(l)(7) >= maxval
                    Dim start As Integer = dt.Rows(row)("DefectStart")
                    Dim endv As Integer = dt.Rows(row)("DefectEnd")
                    If ((endv - start) < 5) Then
                        If ((start >= c And start <= c + stepValue) Or (endv >= c And endv <= c + stepValue)) Then
                            ''If (start >= c And endv <= c + stepValue) Then
                            For d As Integer = stWidth To enWidth
                                If (data(stIdx + c / stepValue, d - 1)) = 0 Or data(stIdx + c / stepValue, d - 1) = Nothing Then
                                    If flag = 0 Then
                                        data(stIdx + c / stepValue, d - 1) = severity + coun
                                        flag = 1
                                    Else
                                        data(stIdx + c / stepValue, d - 1) = severity
                                    End If

                                Else
                                    If flag = 0 Then
                                        data(stIdx + c / stepValue, d - 1) = data(stIdx + c / stepValue, d - 1) + severity + coun
                                        flag = 1
                                    Else
                                        data(stIdx + c / stepValue, d - 1) = data(stIdx + c / stepValue, d - 1) + severity
                                    End If

                                End If

                            Next
                        End If
                    Else


                        If ((start >= c And start < c + stepValue) Or (endv >= c And endv < c + stepValue) Or (start >= c - (endv - start) And start < c + stepValue)) Then
                            For d As Integer = stWidth To enWidth
                                If (data(stIdx + c / stepValue, d - 1)) = 0 Or data(stIdx + c / stepValue, d - 1) = Nothing Then
                                    If flag = 0 Then
                                        data(stIdx + c / stepValue, d - 1) = severity + coun
                                        flag = 1
                                    Else
                                        data(stIdx + c / stepValue, d - 1) = severity
                                    End If

                                Else
                                    If flag = 0 Then
                                        data(stIdx + c / stepValue, d - 1) = data(stIdx + c / stepValue, d - 1) + severity + coun
                                        flag = 1
                                    Else
                                        data(stIdx + c / stepValue, d - 1) = data(stIdx + c / stepValue, d - 1) + severity
                                    End If

                                End If
                            Next

                        End If
                    End If
                Next
            Next

            For row As Integer = 0 To dt_B.Rows.Count - 1
                If Convert.ToInt32(dt_B.Rows(row)("Defect_St_Width")) > Convert.ToInt32(dt_B.Rows(row)("Defect_End_Width")) Then
                    stWidth = dt_B.Rows(row)("Defect_End_Width")
                    enWidth = dt_B.Rows(row)("Defect_St_Width")
                Else
                    stWidth = dt_B.Rows(row)("Defect_St_Width")
                    enWidth = dt_B.Rows(row)("Defect_End_Width")
                End If
                Dim tem As Integer = Nothing
                For c As Integer = 0 To 100 - stepValue Step stepValue
                    Dim start As Integer = dt_B.Rows(row)("DefectStart")
                    Dim endv As Integer = dt_B.Rows(row)("DefectEnd")
                    If ((endv - start) < 5) Then
                        If ((start >= c And start <= c + stepValue) Or (endv >= c And endv <= c + stepValue)) Then
                            tem += 1
                        End If
                    Else
                        If ((start >= c And start < c + stepValue) Or (endv >= c And endv < c + stepValue) Or (start >= c - (endv - start) And start < c + stepValue)) Then
                            tem += 1
                        End If
                    End If
                Next
                ''''''''''''''''''''''''''''''
                If tem > 1 Then
                    For fir As Integer = 0 To 10
                        severity = (Convert.ToInt32(dt_B.Rows(row)("Defect_Length")) - fir) / tem
                        Dim st() As String = severity.ToString.Split(".")
                        If st.Length > 1 Then
                            Try
                                If st(1) = 0 Then
                                    coun = fir
                                    Exit For
                                Else
                                    Continue For
                                End If
                            Catch ex As Exception

                            End Try
                        Else
                            coun = fir
                            Exit For
                        End If
                    Next
                Else
                    severity = (Convert.ToInt32(dt_B.Rows(row)("Defect_Length"))) / tem
                    coun = 0
                End If
                ''''''''''''''''''''''''''''''
                '' severity = Convert.ToInt32(dt_B.Rows(row)("Defect_Length")) / tem
                Dim flag As Integer = 0
                For c As Integer = 0 To 100 - stepValue Step stepValue

                    Dim start As Integer = dt_B.Rows(row)("DefectStart")
                    Dim endv As Integer = dt_B.Rows(row)("DefectEnd")
                    If ((endv - start) < 5) Then
                        'If (start >= c And endv <= c + stepValue) Then
                        If ((start >= c And start <= c + stepValue) Or (endv >= c And endv <= c + stepValue)) Then
                            For d As Integer = stWidth To enWidth
                                If (data_B(stIdx + c / stepValue, d - 1)) = 0 Or data_B(stIdx + c / stepValue, d - 1) = Nothing Then
                                    If flag = 0 Then
                                        data_B(stIdx + c / stepValue, d - 1) = severity + coun
                                        flag = 1
                                    Else
                                        data_B(stIdx + c / stepValue, d - 1) = severity
                                    End If
                                Else
                                    If flag = 0 Then
                                        data_B(stIdx + c / stepValue, d - 1) = data_B(stIdx + c / stepValue, d - 1) + severity + coun
                                        flag = 1
                                    Else
                                        data_B(stIdx + c / stepValue, d - 1) = data_B(stIdx + c / stepValue, d - 1) + severity
                                    End If


                                End If
                            Next
                        End If
                    Else
                        If ((start >= c And start < c + stepValue) Or (endv >= c And endv < c + stepValue) Or (start >= c - (endv - start) And start < c + stepValue)) Then
                            For d As Integer = stWidth To enWidth
                                If (data_B(stIdx + c / stepValue, d - 1)) = 0 Or data_B(stIdx + c / stepValue, d - 1) = Nothing Then
                                    If flag = 0 Then
                                        data_B(stIdx + c / stepValue, d - 1) = severity + coun
                                        flag = 1
                                    Else
                                        data_B(stIdx + c / stepValue, d - 1) = severity
                                    End If
                                Else
                                    If flag = 0 Then
                                        data_B(stIdx + c / stepValue, d - 1) = data_B(stIdx + c / stepValue, d - 1) + severity + coun
                                        flag = 1
                                    Else
                                        data_B(stIdx + c / stepValue, d - 1) = data_B(stIdx + c / stepValue, d - 1) + severity
                                    End If
                                End If
                            Next
                        End If
                    End If
                Next
            Next

           
4:

            s.Append("];")
            s.Append("var CoilId=[" & IIf(coilId.Length > 0, coilId.Substring(1), coilId) & "];")
            s.Append("var mlData=[" & IIf(markLineData.Length > 3, markLineData.Substring(1), markLineData) & "];")
            s.Append("var data=[")
            For row As Integer = 0 To UBound(data, 1)
                If row > 0 Then
                    s.Append(",")
                End If
                s.Append("[" & row & ",0," & getVal(data(row, 0)) & "," & data(row, 0) & "],[" & row & ",1," & getVal(data(row, 1)) & "," & data(row, 1) & "],[" & row & ",2," & getVal(data(row, 2)) & "," & data(row, 2) & "],[" & row & ",3," & getVal(data(row, 3)) & "," & data(row, 3) & "],[" & row & ",4," & getVal(data(row, 4)) & "," & data(row, 4) & "]")
            Next
            s.Append("];")

            s.Append("var data1=[")
            For row As Integer = 0 To UBound(data_B, 1)
                If row > 0 Then
                    s.Append(",")
                End If
                s.Append("[" & row & ",0," & getVal(data_B(row, 0)) & "," & data_B(row, 0) & "],[" & row & ",1," & getVal(data_B(row, 1)) & "," & data_B(row, 1) & "],[" & row & ",2," & getVal(data_B(row, 2)) & "," & data_B(row, 2) & "],[" & row & ",3," & getVal(data_B(row, 3)) & "," & data_B(row, 3) & "],[" & row & ",4," & getVal(data_B(row, 4)) & "," & data_B(row, 4) & "]")
            Next
            s.Append("];")

            ' s.Append("var data=[" & data & "];")
            s.Append("var dataT= data.map(function (item) {return [item[1], item[0], item[2] || '-'];});")
            s.Append("option = {title: {text:       'TOP',left:       'center'},toolbox: {feature: {dataZoom: { },saveAsImage: {}}},tooltip: {show:true,position:   'top', formatter: function (params) {" & rowValforTooltip & " console.log(params.data);var s = params.data[2];var def='';if (s==6){def='No defect';} else if (s==1){def='0'} else if (s==2){def='>6'} else {def='>11'} var i = params.data[1]*5 + params.data[0]; return 'Defect Length: ' + data[i][3] ;}},animation: false,grid: {height:'80%',width:'70%',x:'15%',y:'10%'},xAxis: {type:'category',data: hours,splitArea: {show: false}, name: 'Width--->',axisLabel: {fontWeight:'bold',fontSize:15,},nameTextStyle:{  fontSize:'15', fontWeight:'bold' },nameLocation: 'center', nameGap: 20},yAxis: {type:'category',data: days,interval:0,name: 'Length(%)',nameLocation: 'middle',nameGap: 70,axisLabel: {fontWeight:'bold',fontSize:15,},nameTextStyle:{  fontSize:'15', fontWeight:'bold' },splitArea: {show: false}},visualMap: {show:false, min: 1, max: 3,range:[1,3],inRange:{color:['#70A03D','#FFFF00','#ff0000']},calculable: true,orient:'horizontal',left:'center',bottom:'15%',outOfRange: {color:'#70A03D'}}, series: [{name:'Defect Inspection',type:'heatmap',data: dataT,markLine:{data:mlData},label: {normal: {show: true,color:'black',fontWeight:'bold',fontSize:15, formatter: (params) => { var i = params.data[1]*5 + params.data[0];if (params.data[2]< 4) {return data[i][3] }}}},itemStyle: {emphasis: {shadowBlur: 10,shadowColor:'rgba(0, 0, 0, 0.5)'}}}]};")
            s.Append("var myChart= echarts.init(document.getElementById('subcontainer'));")
            s.Append("myChart.setOption(option);")

            s.Append("var dataB= data1.map(function (item) {return [item[1], item[0], item[2] || '-'];});")
            s.Append("option1 = {title: {text:       'BOTTOM',left:       'center'},toolbox: {feature: {dataZoom: { },saveAsImage: {}}},tooltip: {show:true,position:   'top', formatter: function (params) {" & rowValforTooltip & " var s = params.data[2];var def='';if (s==6){def='No defect';} else if (s==1){def='0'} else if (s==2){def='>6'} else {def='>11'} var i = params.data[1]*5 + params.data[0]; return 'Defect Length : ' + data1[i][3] ;}},animation: false,grid: {height:'80%',width:'70%',x:'15%',y:'10%'},xAxis: {type:'category',data: hours,splitArea: {show: false}, name: 'Width--->',axisLabel: {fontWeight:'bold',fontSize:15,},nameTextStyle:{  fontSize:'15', fontWeight:'bold' },nameLocation: 'center', nameGap: 20},yAxis: {type:'category',data: days,interval:0,name: 'Length(%)',nameLocation: 'middle',nameGap: 70,axisLabel: {fontWeight:'bold',fontSize:15,},nameTextStyle:{  fontSize:'15', fontWeight:'bold' },splitArea: {show: false}},visualMap: {show:false, min: 1, max: 3,range:[1,3],inRange:{color:['#70A03D','#FFFF00','#ff0000']},calculable: true,orient:'horizontal',left:'center',bottom:'15%',outOfRange: {color:'#70A03D'}}, series: [{name:'Defect Inspection',type:'heatmap',data: dataB,markLine:{data:mlData},label: {normal: {show: true,color:'black',fontWeight:'bold',fontSize:15, formatter: (params) => { var i = params.data[1]*5 + params.data[0];if (params.data[2]< 4) {return data1[i][3] }}}},itemStyle: {emphasis: {shadowBlur: 10,shadowColor:'rgba(0, 0, 0, 0.5)'}}}]};")
            s.Append("var myChart1= echarts.init(document.getElementById('subcontainer1'));")
            s.Append("myChart1.setOption(option1);")
            s.Append("window.onresize = function() { myChart.resize();myChart1.resize();};")



            s.Append("</script>")
            Lit1.Text = s.ToString()
        Catch ex As Exception

        End Try
    End Sub

    


    Function getVal(ByVal v As Integer) As Integer
        If Convert.ToInt32(v) >= highval.Text Then
            v = 3
        ElseIf Convert.ToInt32(v) >= midfrom.Text And Convert.ToInt32(v) <= midto.Text Then
            v = 2
        ElseIf Convert.ToInt32(v) >= lowfrom.Text And Convert.ToInt32(v) <= lowto.Text Then
            v = 1
        End If

        Return v
    End Function

    Sub CloseConnection()
        Try
            If Oleconnection_ora.State <> ConnectionState.Closed Then
                Oleconnection_ora.Close()
            End If
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub
    Public Function Ora_selectquery(ByVal strselect As String) As OleDbDataAdapter
        OleCom.Connection = Oleconnection_ora
        OleCom.CommandText = strselect
        OleAdap.SelectCommand = OleCom
        Return OleAdap
    End Function
    Public Function GetInspectionWidthData(ByVal CoilId As String) As DataTable
        Try
            'CloseConnection()
            Oleconnection_ora.Open()
            ds.Clear()
            dt.Clear()
            If CoilId.StartsWith("J") Then
                CoilId = CoilId.Substring(1, 6)
            Else
                CoilId = CoilId.Substring(0, 6)
            End If
            Dim OraQuery As String = "Select HRP_ID_CR_COIL as CR_COIL_ID,CCL_ID_COIL as CR_DAUGHTER_COILID,ccl_length,CCL_SEC1 AS CR_THICKNESS,CCL_SEC2 AS CR_WIDTH,CCL_MS_PIECE_ACTL AS CR_COIL_WT,CCL_TDC_ACTL as CR_TDC,HRP_ID_PC_USRKEY AS HR_COIL_ID,HRP_SEC1_ENT AS HR_THICKNESS,HRP_SEC2_ENT AS HR_WIDTH,HRC_DT_PIECE_CRT AS HR_ROLLING_DT,to_char(HRP_TS_REC_CREATE, 'YYYY-MM-DD HH24:MI:SS') AS TCM_ROLLING_DT,HRP_MIN_SPD_PLT as PLTCM_MIS_SPD, HRP_AVG_SPD_PLT AS PLTCM_AVG_SPD,HRP_MAX_SPD_PLT AS PLTCM_MAX_SPD FROM CRMDBA.t_HR_COIL_PROCESS JOIN crmdba.t_hr_coil on HRP_ID_PC_USRKEY= HRC_ID_PC_USRKEY JOIN crmdba.t_cold_coil ON CCL_ID_HR_COIL= HRP_ID_PC_USRKEY where CCL_ID_COIL like '%" & CoilId & "%' order by CCL_ID_COIL"
            Ora_selectquery(OraQuery)
            OleAdap.Fill(ds)
            dt = ds.Tables(0)
            'Dim OraQuery1 As String = "select ccl_id_coil,ccl_length from crmdba.t_cold_coil where CCL_ID_HR_COIL = '" & dt.Rows(0)(0) & "' order by ccl_ts_creation"
            'Ora_selectquery(OraQuery1)
            'OleAdap.Fill(ds1)
            'dt1 = ds1.Tables(0)
            Return dt
        Catch ex As Exception
            Throw ex
        End Try
    End Function
End Class
