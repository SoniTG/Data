Imports System.Data.OleDb
Imports System.Data
Imports System.Web.Services
Imports System.Data.SqlClient
Imports System.IO
Imports Oracle.ManagedDataAccess.Client

Public Class Inspection_ByWidth_sub_chart
    Inherits System.Web.UI.Page
    Dim objDataHandler As New DataHandler
    Dim objController As New Controller
    Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("ACPM_Ora_New").ConnectionString
    'Dim Oleconnection_ora As New OleDbConnection(strConnectionString)
    Dim Oleconnection_ora As New OracleConnection(strConnectionString)
    'Dim OleAdap As New OleDbDataAdapter
    Dim OleAdap As New OracleDataAdapter
    Dim ds, ds1 As New DataSet
    Dim dt, dt1 As New DataTable
    'Dim OleCom As New OleDbCommand
    Dim OleCom As New OracleCommand
    Dim defectName As String = ""
    Dim severity As String = ""
    Dim tdc_s As String = ""
    Dim lowfrom, lowto, midfrom, midto, highval As Integer
    Dim process_line_sel, process_l As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'DrawChart(New Integer() {807, 1314, 898}, New String() {"9903771000", "9903772000", "9903773000"}, 20)
        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim coilid = Request.QueryString("subparam")
                defectName = Session("DefectName")
                severity = Session("Severity")
                tdc_s = Session("TDC")
                lowfrom = Session("lowfrom")
                lowto = Session("lowto")
                midfrom = Session("midfrom")
                midto = Session("midto")
                highval = Session("highval")
                lowfrom = Session("lowfrom")
                process_line_sel = Session("process_line")
                process_l = Session("process_line_name")
                Dim coilid1 = Request.QueryString("subparam")
                txtCoilwise.Text = coilid

                ''----------------------------------------------------------------------
                Session("c_id") = txtCoilwise.Text
                Session("process_lin_sel") = Session("process_line")
                Session("dname") = Session("DefectName")
                Session("sev") = Session("Severity")
                Session("tdc_ss") = Session("TDC")
                Session("lowfo") = Session("lowfrom")
                Session("lowt") = Session("lowto")
                Session("midfro") = Session("midfrom")
                Session("midt") = Session("midto")
                Session("hiaghva") = Session("highval")
                Session("lowfrom") = Session("lowfrom")
                Session("process_l") = Session("process_line_name")
                Dim dt As DataTable = GetInspectionWidthData(coilid)

                Dim cnt As Integer = 1
                Dim lenCoil(0) As Integer
                Dim CoilIdArr(0) As String

                lenCoil(0) = dt.Rows(0)("ccl_length")
                Dim dt1 As DataSet = FetchSqlData1(coilid1)
                If dt1.Tables(0).Rows.Count > 1 Then
                    cnt = dt1.Tables(0).Rows.Count

                    ReDim CoilIdArr(cnt - 1)
                    For i As Integer = 0 To dt1.Tables(0).Rows.Count - 1
                        CoilIdArr(i) = dt1.Tables(0).Rows(i)("Daughter_Coil")
                    Next
                Else
                    CoilIdArr(0) = dt1.Tables(0).Rows(0)("Daughter_Coil")
                End If

                DrawChart(lenCoil, CoilIdArr)
            Catch ex As Exception

            End Try
        End If
    End Sub








    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        defectName = Session("dname")
        severity = Session("sev")
        lowfrom = Session("lowfo")
        lowto = Session("lowt")
        midfrom = Session("midfro")
        midto = Session("midt")
        highval = Session("hiaghva")
        tdc_s = Session("tdc_ss")

        Try


            Dim dt As DataTable = GetInspectionWidthData(txtCoilwise.Text)
        Catch ex As Exception
            Exit Sub
        End Try
        Dim cnt As Integer = 1
        Dim lenCoil(0) As Integer
        Dim CoilIdArr(0) As String

        lenCoil(0) = dt.Rows(0)("ccl_length")
        Dim dt1 As DataSet = FetchSqlData1(txtCoilwise.Text)
        If dt1.Tables(0).Rows.Count > 1 Then
            cnt = dt1.Tables(0).Rows.Count

            ReDim CoilIdArr(cnt - 1)
            For i As Integer = 0 To dt1.Tables(0).Rows.Count - 1
                CoilIdArr(i) = dt1.Tables(0).Rows(i)("Daughter_Coil")
            Next
        Else
            CoilIdArr(0) = dt1.Tables(0).Rows(0)("Daughter_Coil")
        End If

        DrawChart(lenCoil, CoilIdArr)
    End Sub

    Function FetchSqlData(ByVal coilid As String, ByVal length As String, ByVal total As Integer) As DataSet

        If (coilid.Substring(0, 1) = "J") Then
            coilid = coilid.Substring(0, 8) + "%"
        Else
            coilid = coilid.Substring(0, 7) + "%"
        End If
        ''SLAB REVERSAL
        Dim process_a As String = Nothing
        Dim process_b As String = Nothing
        Dim slab_rev As String = objController.slab_reversal(Session("process_l"))
        Dim s As String() = slab_rev.Split(New Char() {","c})
        ''BOTTOM_PLOT
        process_a = s(0)
        ''TOP_PLOT
        process_b = s(1)

        Dim fil As String = " select * from CRM_HR_CR_RLN where CR_COIL_ID like '" & txtCoilwise.Text & "'"

        Dim data As DataTable = objDataHandler.GetDataSetFromQuery(fil).Tables(0)
        Dim rcl_fil As String = Nothing
        If data.Rows(0)("JCAP_STATUS").ToString = "Y" Then
            rcl_fil = ",,,"
            ''BOTTOM_PLOT
            process_a = "B"
            ''TOP_PLOT
            process_b = "T"

        Else
            If Not IsDBNull(data.Rows(0)("RCL1_DATETIME")) Then

                If Session("process_l") = "PLTCM" Then ''100 is used to invert head to tail and vice versa'' 6 is used  to invert OS to DS and vice versa
                    rcl_fil = ",,,"
                    'ElseIf Session("process_l") = "HSM" Then
                    '    rcl_fil = "100 -,,"
                ElseIf Session("process_l") = "ECL" Then
                    rcl_fil = ",6 -,"
                ElseIf Session("process_l") = "SPM" Then
                    rcl_fil = "100 -,,"
                ElseIf Session("process_l") = "BAF" Then
                    rcl_fil = ",6 -,"
                Else
                    rcl_fil = ",,,"
                End If
            ElseIf Not IsDBNull(data.Rows(0)("RCL2_DATETIME")) Then
                If Session("process_l") = "PLTCM" Then
                    rcl_fil = ",6 -,"
                    'ElseIf Session("process_l") = "HSM" Then
                    '    rcl_fil = "100 -,,"
                ElseIf Session("process_l") = "ECL" Then
                    rcl_fil = ",,,"
                ElseIf Session("process_l") = "SPM" Then
                    rcl_fil = "100 -,6 -,"
                ElseIf Session("process_l") = "BAF" Then
                    rcl_fil = ",,"

                Else
                    rcl_fil = ",,,"
                End If

            ElseIf Not IsDBNull(data.Rows(0)("RCL3_DATETIME")) Then
                If Session("process_l") = "PLTCM" Then
                    rcl_fil = " ,6 -,"
                    'ElseIf Session("process_l") = "HSM" Then
                    '    rcl_fil = "100 -,,"
                ElseIf Session("process_l") = "ECL" Then
                    rcl_fil = ",,,"
                ElseIf Session("process_l") = "SPM" Then
                    rcl_fil = "100 -,6 -,,"
                ElseIf Session("process_l") = "BAF" Then
                    rcl_fil = ",,,"
                Else
                    rcl_fil = ",,,"
                End If
            Else
                rcl_fil = ",,,"
                ''BOTTOM_PLOT
                process_a = "B"
                ''TOP_PLOT
                process_b = "T"
            End If
        End If

        Dim qur_fil() As String = rcl_fil.Split(",")


        Dim q As String = "select distinct date_create as dateCreate,Daughter_Coil,surface,Length_Coil,cast(Defect_St_Length  as numeric(5,0)) as Defect_St_Length,Defect_End_Length,cast(" & qur_fil(0) & "(cast(Defect_St_Length + " & length & " as numeric(8,4)) * 100/" & total & ") as numeric(8,4)) as DefectStart,cast(" & qur_fil(0) & "(cast(Defect_End_Length + " & length & " as numeric(8,4)) * 100/" & total & ") as numeric(8,4)) as DefectEnd,( " & qur_fil(1) & " Defect_St_Width) as Defect_St_Width  , (" & qur_fil(1) & " Defect_End_Width) as Defect_End_Width,severity,[Defect_Length] from [RCL_JCAP_SURFACE_INSPECTION] where Defect_Name in (" & defectName & ") and  Surface = '" & process_b.Substring(0, 1) & "' and Daughter_coil like '" & coilid & "' and severity in (" & severity & ") and TDC_No in (" & tdc_s & ") order by cast(Defect_St_Length as numeric(5,0));select distinct date_create as dateCreate,Daughter_Coil,surface,Length_Coil,cast(Defect_St_Length as numeric(5,0)) as Defect_St_Length,Defect_End_Length,cast(" & qur_fil(0) & "(cast(Defect_St_Length + " & length & " as numeric(8,4)) * 100/" & total & ") as numeric(8,4)) as DefectStart,cast(" & qur_fil(0) & "(cast(Defect_End_Length + " & length & " as numeric(8,4)) * 100/" & total & ") as numeric(8,4)) as DefectEnd,( " & qur_fil(1) & " Defect_St_Width) as Defect_St_Width  , (" & qur_fil(1) & " Defect_End_Width) as Defect_End_Width,severity,[Defect_Length] from [RCL_JCAP_SURFACE_INSPECTION] where Defect_Name in (" & defectName & ") and  Surface = '" & process_a.Substring(0, 1) & "' and Daughter_coil like '" & coilid & "' and severity in (" & severity & ") and TDC_No in (" & tdc_s & ")  order by cast(Defect_St_Length as numeric(5,0)) "
        Return objDataHandler.GetDataSetFromQuery(q)
    End Function
    Function FetchSqlData1(ByVal coilid As String) As DataSet
        coilid = coilid.Substring(0, 7)

        Dim q As String = "SELECT distinct(CASE WHEN Daughter_Coil  like 'J%' THEN CONCAT(SUBSTRING(Daughter_Coil,0,9),'00') ELSE CONCAT(SUBSTRING(Daughter_Coil,0,8),'000') END )  as Daughter_Coil   from [RCL_JCAP_SURFACE_INSPECTION] where Mother_Coil like '" & coilid & "%'"
        '' Dim q As String = "select distinct Daughter_Coil from [RCL_JCAP_SURFACE_INSPECTION] where Mother_Coil like c"
        Return objDataHandler.GetDataSetFromQuery(q)
    End Function
    Function FetchSqlData2(ByVal coilid As String, ByVal DefectName As String) As DataSet

        Dim q As String = "select Daughter_Coil, ( Length_Coil) as len from [RCL_JCAP_SURFACE_INSPECTION] where  Daughter_coil like '" & coilid & "' and severity in (1,2,3,4,5,6,7)    order by len desc"
        Return objDataHandler.GetDataSetFromQuery(q)
    End Function


    Sub DrawChart(ByVal lenCoil() As Integer, ByVal CoilIdArr() As String, Optional ByVal stepValue As Integer = 5)
        Try


            Dim s As New StringBuilder("<script>")

            s.Append("var hours = ['OS', 'OSC', 'C', 'DSC', 'DS'];")
            s.Append("var days= [")
            Dim markLineData As String = ""
            Dim coilId As String = ""
            Dim stIdx As Integer = 0
            Dim stIdx_B As Integer = 0
            Dim dataIdx As Integer = 0
            Dim rowValforTooltip As String = "var row = Math.floor(parseInt(params.data[1])/" & 100 \ stepValue & ");"
            Dim data((100 \ stepValue) * (CoilIdArr.Length), 4) As Double
            Dim data_B((100 \ stepValue) * (CoilIdArr.Length), 4) As Double
            Dim temp As String = ""
            Dim dat As New DataTable
            Dim dt As DataTable
            Dim dt_B As DataTable
            dat.Columns.Add("coil_id")
            dat.Columns.Add("length")
            Dim drNewRow As DataRow
            For v As Integer = 0 To CoilIdArr.Length - 1

                Dim tem As String = ""
                'For k As Integer = 0 To CoilIdArr.Length - 1
                '    temp
                'Next


                If (CoilIdArr(v).Substring(0, 1) = "J") Then
                    temp = CoilIdArr(v).Substring(0, 8) + "%"
                Else
                    temp = CoilIdArr(v).Substring(0, 7) + "%"
                End If
                Dim dset As DataSet = FetchSqlData2(temp, defectName)
                If dset.Tables(0).Rows.Count > 0 Then
                    drNewRow = dat.NewRow
                    drNewRow.Item("coil_id") = dset.Tables(0).Rows(0)("Daughter_Coil")
                    drNewRow.Item("length") = dset.Tables(0).Rows(0)("len")
                    dat.Rows.Add(drNewRow)
                End If
            Next
            Dim percent_cal As Integer = 0
            If dat.Rows.Count > 0 Then

                Dim total_l As Integer = 0
                For v As Integer = 0 To dat.Rows.Count - 1
                    total_l = total_l + dat.Rows(v)("length")
                Next
                percent_cal = total_l
                For v As Integer = 0 To dat.Rows.Count - 1
                    Dim tem_val As Integer = 0
                    If v <> 0 Then
                        For co As Integer = 0 To v - 1
                            tem_val = tem_val + dat.Rows(co)("length")
                        Next
                    End If

                    If v = 0 Then
                        Dim temp_dat As DataSet = FetchSqlData(dat.Rows(v)("coil_id"), tem_val, total_l)
                        dt = temp_dat.Tables(0)
                        dt_B = temp_dat.Tables(1)
                    Else
                        Dim temp_dat As DataSet = FetchSqlData(dat.Rows(v)("coil_id"), tem_val, total_l)
                        If dt.Rows.Count > 0 Then
                            dt.Merge(temp_dat.Tables(0), False, MissingSchemaAction.Ignore)
                            dt.AcceptChanges()
                        Else
                            dt = temp_dat.Tables(0)
                        End If
                        If dt_B.Rows.Count > 0 Then
                            dt_B.Merge(temp_dat.Tables(1), False, MissingSchemaAction.Ignore)
                            dt_B.AcceptChanges()
                        Else
                            dt_B = temp_dat.Tables(1)
                        End If

                    End If
                Next
            End If

            Dim i As Integer = 0

            ''''
            For som As Integer = 0 To dat.Rows.Count - 1
                Dim marker As Integer = 0
                Dim marker1 As Integer = 0
                Dim tot As Integer = 0
                If Session("process_l") = "SPM" Then
                    For eX As Integer = 0 To som
                        tot = tot + dat.Rows(eX)("length")
                    Next
                    marker = (tot / percent_cal) * 100
                    marker1 = (Math.Round(marker / 5)) * (5)
                    ''  If (Session("process_l") = "PLTCM" And Not dat.Rows(som)("coil_id").ToString.StartsWith("J")) Or Session("process_l") = "HSM" Or Session("process_l") = "SPM" Then
                    marker1 = 100 - marker1
                    '' End If
                    If som > 0 Then
                        If (marker - marker1) > 0 Then
                            coilId &= ",'" & dat.Rows(som)("coil_id") & "'"
                            markLineData &= ",{yAxis:'" & marker1 & "-" & marker1 + 5 & "',name:'" & dat.Rows(som)("coil_id") & "',label: {normal: {position: 'end',formatter:'" & dat.Rows(som)("coil_id") & "'}}}"

                        Else
                            coilId &= ",'" & dat.Rows(som)("coil_id") & "'"
                            markLineData &= ",{yAxis:'" & marker1 & "-" & marker1 + 5 & "',name:'" & dat.Rows(som)("coil_id") & "',label: {normal: {position: 'end',formatter:'" & dat.Rows(som)("coil_id") & "'}}}"

                        End If
                    End If

                    If som = 0 Then
                        coilId &= ",'" & dat.Rows(som)("coil_id") & "'"
                        markLineData &= ",{yAxis:'" & marker1 & "-" & marker1 + 5 & "',name:'" & dat.Rows(som)("coil_id") & "',label: {normal: {position: 'end',formatter:'" & dat.Rows(som)("coil_id") & "'}}}"
                    End If

                Else


                    If som > 0 Then
                        For e As Integer = 0 To som - 1
                            tot = tot + dat.Rows(e)("length")
                        Next
                        marker = (tot / percent_cal) * 100
                        marker1 = (Math.Round(marker / 5)) * (5)
                        If (marker - marker1) > 0 Then
                            coilId &= ",'" & dat.Rows(som)("coil_id") & "'"
                            markLineData &= ",{yAxis:'" & marker1 + 5 & "-" & marker1 + 10 & "',name:'" & dat.Rows(som)("coil_id") & "',label: {normal: {position: 'end',formatter:'" & dat.Rows(som)("coil_id") & "'}}}"

                        Else
                            coilId &= ",'" & dat.Rows(som)("coil_id") & "'"
                            markLineData &= ",{yAxis:'" & marker1 - 5 & "-" & marker1 & "',name:'" & dat.Rows(som)("coil_id") & "',label: {normal: {position: 'end',formatter:'" & dat.Rows(som)("coil_id") & "'}}}"

                        End If
                    End If

                    If som = 0 Then
                        coilId &= ",'" & dat.Rows(som)("coil_id") & "'"
                        markLineData &= ",{yAxis:'0-5',name:'" & dat.Rows(som)("coil_id") & "',label: {normal: {position: 'end',formatter:'" & dat.Rows(som)("coil_id") & "'}}}"
                    End If
                End If
            Next



            'coilId &= ",'" & CoilIdArr(i) & "'"
            'markLineData &= ",{yAxis:'(" & (i + 1) & ".) 0-5',name:'" & CoilIdArr(i) & "',label: {normal: {position: 'end',formatter:'" & CoilIdArr(i) & "'}}}"


            ''  Dim ds As DataSet = FetchSqlData(temp, DefectName, Sever, Grade, TDC)


            stIdx = i * 100 \ stepValue
            stIdx_B = i * 100 \ stepValue
            If i > 0 Then s.Append(",")
            For j As Integer = 0 To 100 - stepValue Step stepValue
                If j > 0 Then s.Append(",")
                If j = 0 Then
                    s.Append("'(" & (i + 1) & ".) " & j & "-" & (j + stepValue) & "'")
                Else
                    s.Append("'" & j & "-" & (j + stepValue) & "'")
                End If

            Next
            Dim stLen, enLen As Integer
            Dim stWidth, enWidth As Integer
            Dim severity As Double
            Dim coun As Integer
            For row As Integer = 0 To dt.Rows.Count - 1
                If Convert.ToInt32(dt.Rows(row)("Defect_St_Width")) > Convert.ToInt32(dt.Rows(row)("Defect_End_Width")) Then
                    stWidth = dt.Rows(row)("Defect_End_Width")
                    enWidth = dt.Rows(row)("Defect_St_Width")
                Else
                    stWidth = dt.Rows(row)("Defect_St_Width")
                    enWidth = dt.Rows(row)("Defect_End_Width")
                End If

                Dim tem As Integer = Nothing
                For c As Integer = 0 To 100 - stepValue Step stepValue
                    Dim start As Integer = dt.Rows(row)("DefectStart")
                    Dim endv As Integer = dt.Rows(row)("DefectEnd")
                    If ((start >= c And start <= c + stepValue) Or (endv >= c And endv <= c + stepValue)) Then
                        tem += 1
                    Else
                        If ((start >= c And start < c + stepValue) Or (endv >= c And endv < c + stepValue) Or (start >= c - (endv - start) And start < c + stepValue)) Then
                            tem += 1
                        End If
                    End If
                Next
                ''''''''''''''''''''''''''''''''

                If tem > 1 Then
                    For fir As Integer = 0 To 10
                        severity = (Convert.ToInt32(dt.Rows(row)("Defect_Length")) - fir) / tem
                        Dim st() As String = severity.ToString.Split(".")
                        If st.Length > 1 Then
                            Try
                                If st(1) = 0 Then
                                    coun = fir
                                    Exit For
                                Else
                                    Continue For
                                End If
                            Catch ex As Exception

                            End Try
                        Else
                            coun = fir
                            Exit For
                        End If
                    Next
                Else
                    severity = Convert.ToInt32(dt.Rows(row)("Defect_Length")) / tem
                    coun = 0
                End If
                ''''''''''''''''''''''''
                '' severity = Convert.ToInt32(dt.Rows(row)("Defect_Length")) / tem
                Dim flag As Integer = 0
                For c As Integer = 0 To 100 - stepValue Step stepValue
                    'dv(l)(6) <= minval And dv.Item(l)(7) >= minval) OrElse (dv(l)(6) <= maxval And dv.Item(l)(7) >= maxval
                    Dim start As Integer = dt.Rows(row)("DefectStart")
                    Dim endv As Integer = dt.Rows(row)("DefectEnd")
                    If ((endv - start) < 5) Then
                        If ((start >= c And start <= c + stepValue) Or (endv >= c And endv <= c + stepValue)) Then
                            ''If (start >= c And endv <= c + stepValue) Then
                            For d As Integer = stWidth To enWidth
                                If (data(stIdx + c / stepValue, d - 1)) = 0 Or data(stIdx + c / stepValue, d - 1) = Nothing Then
                                    If flag = 0 Then
                                        data(stIdx + c / stepValue, d - 1) = severity + coun
                                        flag = 1
                                    Else
                                        data(stIdx + c / stepValue, d - 1) = severity
                                    End If

                                Else
                                    If flag = 0 Then
                                        data(stIdx + c / stepValue, d - 1) = data(stIdx + c / stepValue, d - 1) + severity + coun
                                        flag = 1
                                    Else
                                        data(stIdx + c / stepValue, d - 1) = data(stIdx + c / stepValue, d - 1) + severity
                                    End If

                                End If

                            Next
                        End If
                    Else


                        If ((start >= c And start < c + stepValue) Or (endv >= c And endv < c + stepValue) Or (start >= c - (endv - start) And start < c + stepValue)) Then
                            For d As Integer = stWidth To enWidth
                                If (data(stIdx + c / stepValue, d - 1)) = 0 Or data(stIdx + c / stepValue, d - 1) = Nothing Then
                                    If flag = 0 Then
                                        data(stIdx + c / stepValue, d - 1) = severity + coun
                                        flag = 1
                                    Else
                                        data(stIdx + c / stepValue, d - 1) = severity
                                    End If

                                Else
                                    If flag = 0 Then
                                        data(stIdx + c / stepValue, d - 1) = data(stIdx + c / stepValue, d - 1) + severity + coun
                                        flag = 1
                                    Else
                                        data(stIdx + c / stepValue, d - 1) = data(stIdx + c / stepValue, d - 1) + severity
                                    End If

                                End If
                            Next

                        End If
                    End If
                Next
            Next

            For row As Integer = 0 To dt_B.Rows.Count - 1
                If Convert.ToInt32(dt_B.Rows(row)("Defect_St_Width")) > Convert.ToInt32(dt_B.Rows(row)("Defect_End_Width")) Then
                    stWidth = dt_B.Rows(row)("Defect_End_Width")
                    enWidth = dt_B.Rows(row)("Defect_St_Width")
                Else
                    stWidth = dt_B.Rows(row)("Defect_St_Width")
                    enWidth = dt_B.Rows(row)("Defect_End_Width")
                End If
                Dim tem As Integer = Nothing
                For c As Integer = 0 To 100 - stepValue Step stepValue
                    Dim start As Integer = dt_B.Rows(row)("DefectStart")
                    Dim endv As Integer = dt_B.Rows(row)("DefectEnd")
                    If ((endv - start) < 5) Then
                        If ((start >= c And start <= c + stepValue) Or (endv >= c And endv <= c + stepValue)) Then
                            tem += 1
                        End If
                    Else
                        If ((start >= c And start < c + stepValue) Or (endv >= c And endv < c + stepValue) Or (start >= c - (endv - start) And start < c + stepValue)) Then
                            tem += 1
                        End If
                    End If
                Next
                ''''''''''''''''''''''''''''''
                If tem > 1 Then
                    For fir As Integer = 0 To 10
                        severity = (Convert.ToInt32(dt_B.Rows(row)("Defect_Length")) - fir) / tem
                        Dim st() As String = severity.ToString.Split(".")
                        If st.Length > 1 Then
                            Try
                                If st(1) = 0 Then
                                    coun = fir
                                    Exit For
                                Else
                                    Continue For
                                End If
                            Catch ex As Exception

                            End Try
                        Else
                            coun = fir
                            Exit For
                        End If
                    Next
                Else
                    severity = (Convert.ToInt32(dt_B.Rows(row)("Defect_Length"))) / tem
                    coun = 0
                End If
                ''''''''''''''''''''''''''''''
                '' severity = Convert.ToInt32(dt_B.Rows(row)("Defect_Length")) / tem
                Dim flag As Integer = 0
                For c As Integer = 0 To 100 - stepValue Step stepValue

                    Dim start As Integer = dt_B.Rows(row)("DefectStart")
                    Dim endv As Integer = dt_B.Rows(row)("DefectEnd")
                    If ((endv - start) < 5) Then
                        'If (start >= c And endv <= c + stepValue) Then
                        If ((start >= c And start <= c + stepValue) Or (endv >= c And endv <= c + stepValue)) Then
                            For d As Integer = stWidth To enWidth
                                If (data_B(stIdx + c / stepValue, d - 1)) = 0 Or data_B(stIdx + c / stepValue, d - 1) = Nothing Then
                                    If flag = 0 Then
                                        data_B(stIdx + c / stepValue, d - 1) = severity + coun
                                        flag = 1
                                    Else
                                        data_B(stIdx + c / stepValue, d - 1) = severity
                                    End If
                                Else
                                    If flag = 0 Then
                                        data_B(stIdx + c / stepValue, d - 1) = data_B(stIdx + c / stepValue, d - 1) + severity + coun
                                        flag = 1
                                    Else
                                        data_B(stIdx + c / stepValue, d - 1) = data_B(stIdx + c / stepValue, d - 1) + severity
                                    End If


                                End If
                            Next
                        End If
                    Else
                        If ((start >= c And start < c + stepValue) Or (endv >= c And endv < c + stepValue) Or (start >= c - (endv - start) And start < c + stepValue)) Then
                            For d As Integer = stWidth To enWidth
                                If (data_B(stIdx + c / stepValue, d - 1)) = 0 Or data_B(stIdx + c / stepValue, d - 1) = Nothing Then
                                    If flag = 0 Then
                                        data_B(stIdx + c / stepValue, d - 1) = severity + coun
                                        flag = 1
                                    Else
                                        data_B(stIdx + c / stepValue, d - 1) = severity
                                    End If
                                Else
                                    If flag = 0 Then
                                        data_B(stIdx + c / stepValue, d - 1) = data_B(stIdx + c / stepValue, d - 1) + severity + coun
                                        flag = 1
                                    Else
                                        data_B(stIdx + c / stepValue, d - 1) = data_B(stIdx + c / stepValue, d - 1) + severity
                                    End If
                                End If
                            Next
                        End If
                    End If
                Next
            Next



4:

            s.Append("];")
            s.Append("var CoilId=[" & IIf(coilId.Length > 0, coilId.Substring(1), coilId) & "];")
            s.Append("var mlData=[" & IIf(markLineData.Length > 3, markLineData.Substring(1), markLineData) & "];")
            s.Append("var data=[")
            For row As Integer = 0 To UBound(data, 1)
                If row > 0 Then
                    s.Append(",")
                End If
                s.Append("[" & row & ",0," & getVal(data(row, 0)) & "," & data(row, 0) & "],[" & row & ",1," & getVal(data(row, 1)) & "," & data(row, 1) & "],[" & row & ",2," & getVal(data(row, 2)) & "," & data(row, 2) & "],[" & row & ",3," & getVal(data(row, 3)) & "," & data(row, 3) & "],[" & row & ",4," & getVal(data(row, 4)) & "," & data(row, 4) & "]")
            Next
            s.Append("];")

            s.Append("var data1=[")
            For row As Integer = 0 To UBound(data_B, 1)
                If row > 0 Then
                    s.Append(",")
                End If
                s.Append("[" & row & ",0," & getVal(data_B(row, 0)) & "," & data_B(row, 0) & "],[" & row & ",1," & getVal(data_B(row, 1)) & "," & data_B(row, 1) & "],[" & row & ",2," & getVal(data_B(row, 2)) & "," & data_B(row, 2) & "],[" & row & ",3," & getVal(data_B(row, 3)) & "," & data_B(row, 3) & "],[" & row & ",4," & getVal(data_B(row, 4)) & "," & data_B(row, 4) & "]")
            Next
            s.Append("];")
            ''color:['#70A03D','#FFFF00','#ff0000']
            ''color:['#70A03D','#FFFF00','#ff0000']
            ' s.Append("var data=[" & data & "];")
            s.Append("var dataT= data.map(function (item) {return [item[1], item[0], item[2] || '-'];});")
            s.Append("option = {title: {text:       'TOP',left:       'center'},toolbox: {feature: {dataZoom: { },saveAsImage: {}}},tooltip: {show:true,position:   'top', formatter: function (params) {" & rowValforTooltip & " console.log(params.data);var s = params.data[2];var def='';if (s==6){def='No defect';} else if (s==1){def='0'} else if (s==2){def='>6'} else {def='>11'} var i = params.data[1]*5 + params.data[0]; return 'Defect Length: ' + data[i][3] ;}},animation: false,grid: {height:'80%',width:'70%',x:'15%',y:'10%'},xAxis: {type:'category',data: hours,splitArea: {show: false}, name: 'Width--->',axisLabel: {fontWeight:'bold',fontSize:15,},nameTextStyle:{  fontSize:'15', fontWeight:'bold' },nameLocation: 'center', nameGap: 20},yAxis: {type:'category',data: days,name: 'Length(%)',nameLocation: 'middle',nameGap: 70,axisLabel: {fontWeight:'bold',fontSize:15,},nameTextStyle:{  fontSize:'15', fontWeight:'bold' },interval:0,splitArea: {show: false}},visualMap: {show:false, min: 1, max: 3,range:[1,3],inRange:{color:['#70A03D','#FFFF00','#ff0000']},calculable: true,orient:'horizontal',left:'center',bottom:'15%',outOfRange: {color:'#70A03D'}}, series: [{name:'Defect Inspection',type:'heatmap',data: dataT,markLine:{data:mlData},label: {normal: {show: true,color:'black',fontWeight:'bold',fontSize:15, formatter: (params) => { var i = params.data[1]*5 + params.data[0];if (params.data[2]< 4) {return data[i][3] }}}},itemStyle: {emphasis: {shadowBlur: 10,shadowColor:'rgba(0, 0, 0, 0.5)'}}}]};")
            s.Append("var myChart= echarts.init(document.getElementById('subcontainer'));")
            s.Append("myChart.setOption(option);")

            s.Append("var dataB= data1.map(function (item) {return [item[1], item[0], item[2] || '-'];});")
            s.Append("option1 = {title: {text:       'BOTTOM',left:       'center'},toolbox: {feature: {dataZoom: { },saveAsImage: {}}},tooltip: {show:true,position:   'top', formatter: function (params) {" & rowValforTooltip & " var s = params.data[2];var def='';if (s==6){def='No defect';} else if (s==1){def='0'} else if (s==2){def='>6'} else {def='>11'} var i = params.data[1]*5 + params.data[0]; return 'Defect Length : ' + data1[i][3] ;}},animation: false,grid: {height:'80%',width:'70%',x:'15%',y:'10%'},xAxis: {type:'category',data: hours,splitArea: {show: false}, name: 'Width--->',axisLabel: {fontWeight:'bold',fontSize:15,},nameTextStyle:{  fontSize:'15', fontWeight:'bold' },nameLocation: 'center', nameGap: 20},yAxis: {type:'category',data: days,name: 'Length(%)',nameLocation: 'middle',nameGap: 70,axisLabel: {fontWeight:'bold',fontSize:15,},nameTextStyle:{  fontSize:'15', fontWeight:'bold' },interval:0,splitArea: {show: false}},visualMap: {show:false, min: 1, max: 3,range:[1,3],inRange:{color:['#70A03D','#FFFF00','#ff0000']},calculable: true,orient:'horizontal',left:'center',bottom:'15%',outOfRange: {color:'#70A03D'}}, series: [{name:'Defect Inspection',type:'heatmap',data: dataB,markLine:{data:mlData},label: {normal: {show: true,color:'black',fontWeight:'bold',fontSize:15, formatter: (params) => { var i = params.data[1]*5 + params.data[0];if (params.data[2]< 4) {return data1[i][3] }}}},itemStyle: {emphasis: {shadowBlur: 10,shadowColor:'rgba(0, 0, 0, 0.5)'}}}]};")
            s.Append("var myChart1= echarts.init(document.getElementById('subcontainer1'));")
            s.Append("myChart1.setOption(option1);")
            s.Append("window.onresize = function() { myChart.resize();myChart1.resize();};")



            s.Append("</script>")

            Lit1.Text = s.ToString()
        Catch ex As Exception

        End Try

    End Sub

    Function getVal(ByVal v As Integer) As Integer
        If Convert.ToInt32(v) >= highval Then
            v = 3
        ElseIf Convert.ToInt32(v) >= midfrom And Convert.ToInt32(v) <= midto Then
            v = 2
        ElseIf Convert.ToInt32(v) >= lowfrom And Convert.ToInt32(v) <= lowto Then
            v = 1
        End If

        Return v
    End Function

    Sub CloseConnection()
        Try
            If Oleconnection_ora.State <> ConnectionState.Closed Then
                Oleconnection_ora.Close()
            End If
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub
    Public Function Ora_selectquery(ByVal strselect As String) As OracleDataAdapter 'OleDbDataAdapter
        OleCom.Connection = Oleconnection_ora
        OleCom.CommandText = strselect
        OleAdap.SelectCommand = OleCom
        Return OleAdap
    End Function
    Public Function GetInspectionWidthData(ByVal CoilId As String) As DataTable
        Try
            'CloseConnection()
            Oleconnection_ora.Open()
            ds.Clear()
            dt.Clear()
            If CoilId.StartsWith("J") Then
                CoilId = CoilId.Substring(1, 6)
            Else
                CoilId = CoilId.Substring(0, 6)
            End If
            Dim OraQuery As String = "Select HRP_ID_CR_COIL as CR_COIL_ID,CCL_ID_COIL as CR_DAUGHTER_COILID,ccl_length,CCL_SEC1 AS CR_THICKNESS,CCL_SEC2 AS CR_WIDTH,CCL_MS_PIECE_ACTL AS CR_COIL_WT,CCL_TDC_ACTL as CR_TDC,HRP_ID_PC_USRKEY AS HR_COIL_ID,HRP_SEC1_ENT AS HR_THICKNESS,HRP_SEC2_ENT AS HR_WIDTH,HRC_DT_PIECE_CRT AS HR_ROLLING_DT,to_char(HRP_TS_REC_CREATE, 'YYYY-MM-DD HH24:MI:SS') AS TCM_ROLLING_DT,HRP_MIN_SPD_PLT as PLTCM_MIS_SPD, HRP_AVG_SPD_PLT AS PLTCM_AVG_SPD,HRP_MAX_SPD_PLT AS PLTCM_MAX_SPD FROM CRMDBA.t_HR_COIL_PROCESS JOIN crmdba.t_hr_coil on HRP_ID_PC_USRKEY= HRC_ID_PC_USRKEY JOIN crmdba.t_cold_coil ON CCL_ID_HR_COIL= HRP_ID_PC_USRKEY where CCL_ID_COIL like '%" & CoilId & "%' order by CCL_ID_COIL"
            Ora_selectquery(OraQuery)
            OleAdap.Fill(ds)
            dt = ds.Tables(0)
            'Dim OraQuery1 As String = "select ccl_id_coil,ccl_length from crmdba.t_cold_coil where CCL_ID_HR_COIL = '" & dt.Rows(0)(0) & "' order by ccl_ts_creation"
            'Ora_selectquery(OraQuery1)
            'OleAdap.Fill(ds1)
            'dt1 = ds1.Tables(0)
            Return dt
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    <WebMethod()>
    Public Shared Function GetAutoCompleteData(ByVal username As String) As List(Of String)
        Dim result As List(Of String) = New List(Of String)()

        Using con As SqlConnection = New SqlConnection("server=176.0.0.60\LPTGSQLDEV;database=FP_PROCESS_DATA;uid=153521;pwd=Welcome@135")

            Using cmd As SqlCommand = New SqlCommand("select distinct top 10 Mother_Coil from RCL_JCAP_SURFACE_INSPECTION  inner join CRM_HR_CR_RLN on Mother_Coil = CR_COIL_ID where Mother_Coil  LIKE '%'+@SearchText+'%'", con)
                con.Open()
                cmd.Parameters.AddWithValue("@SearchText", username)
                Dim dr As SqlDataReader = cmd.ExecuteReader()

                While dr.Read()
                    result.Add(String.Format("{0}", dr("Mother_Coil")))
                End While

                Return result
            End Using
        End Using
    End Function


End Class