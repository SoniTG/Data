﻿Imports System.Data
Imports System.IO

Imports System.Web.Services
Imports System.Data.SqlClient
Imports System.Drawing
Partial Class Inspection_tdc
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim objDataHandler As New DataHandler
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    txtDate_TextChanged()
                End If


            Catch ex As Exception

            End Try

        End If

        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

                LoadGradeTDC(dtStart, dtEnd)
                Loadstatus(dtStart, dtEnd)
                LoadDefectList(dtStart, dtEnd)
                hfFrom.Value = dtStart
                hfTo.Value = dtEnd
                ''''''''''''''''''''''''''''''''''''

                ''''''''''''''''''''''''''''''''''''
                'DrawChart(dtStart, dtEnd, ddlDefName.SelectedItem.Text, ddlSurface.SelectedValue.ToString())
                Dim strDefect As String = getSelectedData(lstDefName)
                Dim strSeverity As String = getSelectedData(lstSeverity)
                Dim strGrade As String = getSelectedData(lstGrade)
                Dim strTDC As String = getSelectedData(lstTDC)
                Dim strstatus As String = getSelectedData(statuslist)
                Try
                    If strDefect.Length > 0 Then
                        strDefect = "'" & strDefect.Replace(",", "','") & "'"
                    End If

                    If strGrade.Length > 0 Then
                        strGrade = "'" & strGrade.Replace(",", "','") & "'"
                    End If

                    If strTDC.Length > 0 Then
                        strTDC = "'" & strTDC.Replace(",", "','") & "'"
                    End If

                    If strstatus.Length > 0 Then
                        strstatus = "'" & strstatus.Replace(",", "','") & "'"
                    End If
                Catch ex As Exception

                End Try
                'DrawChart(dtStart, dtEnd, ddlDefName.SelectedItem.Text, ddlSurface.SelectedValue.ToString())
                DrawChart(dtStart, dtEnd, strDefect, strSeverity, strGrade, strTDC, strstatus)
            Catch ex As Exception

            End Try

        End If

    End Sub

    Sub LoadGradeTDC(ByVal fromDt As String, ByVal toDt As String)
        'Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("SELECT DISTINCT GRADE FROM RCL_JCAP_SURFACE_INSPECTION where date_create between '" & fromDt & "' and '" & toDt & "'   ORDER BY GRADE;SELECT DISTINCT TDC_NO FROM RCL_JCAP_SURFACE_INSPECTION where date_create between '" & fromDt & "' and '" & toDt & "' and  TDC_NO != '' ORDER BY TDC_NO")
        Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("SELECT DISTINCT GRADE FROM RCL_JCAP_SURFACE_INSPECTION  ORDER BY GRADE;SELECT DISTINCT TDC_NO FROM RCL_JCAP_SURFACE_INSPECTION where  TDC_NO != '' ORDER BY TDC_NO")
        Dim dt As DataTable = ds.Tables(0)
        Dim dt1 As DataTable = ds.Tables(1)
        lstGrade.DataSource = dt
        lstGrade.DataTextField = "GRADE"
        lstGrade.DataValueField = "GRADE"
        lstGrade.DataBind()

        lstTDC.DataSource = dt1
        lstTDC.DataTextField = "TDC_NO"
        lstTDC.DataValueField = "TDC_NO"
        lstTDC.DataBind()

        For Each lst As ListItem In lstGrade.Items
            lst.Selected = True
        Next

        For Each lst As ListItem In lstTDC.Items
            lst.Selected = True
        Next

    End Sub

    Sub Loadstatus(ByVal fromDt As String, ByVal toDt As String)
        ' Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT DISTINCT Defect_Name FROM RCL_JCAP_SURFACE_INSPECTION where date_create between '" & fromDt & "' and '" & toDt & "' AND Defect_Name != '' ORDER BY DEFECT_NAME").Tables(0)
        Dim dt As DataTable = objDataHandler.GetOracleData1("select distinct(ccl_cd_status) from  crmdba.t_cold_coil").Tables(0)
        statuslist.DataSource = dt
        statuslist.DataTextField = "ccl_cd_status"
        statuslist.DataValueField = "ccl_cd_status"
        statuslist.DataBind()

        If dt.Rows.Count > 0 Then
            lstDefName.Items.FindByText("SCUMD").Selected = True
        End If
    End Sub
    Sub LoadDefectList(ByVal fromDt As String, ByVal toDt As String)
        ' Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT DISTINCT Defect_Name FROM RCL_JCAP_SURFACE_INSPECTION where date_create between '" & fromDt & "' and '" & toDt & "' AND Defect_Name != '' ORDER BY DEFECT_NAME").Tables(0)
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT DISTINCT Defect_Name FROM RCL_JCAP_SURFACE_INSPECTION where  Defect_Name != '' ORDER BY DEFECT_NAME").Tables(0)
        lstDefName.DataSource = dt
        lstDefName.DataTextField = "Defect_Name"
        lstDefName.DataValueField = "Defect_Name"
        lstDefName.DataBind()

        If dt.Rows.Count > 0 Then
            lstDefName.Items.FindByText("SCUMD").Selected = True
        End If
    End Sub

    Sub DrawChart(ByVal FromDate As String, ByVal ToDate As String, ByVal DefectName As String, ByVal Severity As String, ByVal Grade As String, ByVal TDC As String, ByVal status As String)
        Try
            Labelheader.Text = "Width_wise Defect Data w.r.t " & lstProcessingline.SelectedItem.ToString
            Dim strFromDate As String = FromDate
            Dim strToDate As String = ToDate
            Dim quiry_ora As String = ""
            Dim quiry_filter As String = ""
            Dim f1 As String = ""
            Dim f2 As String = ""
            quiry_filter = "select distinct(Mother_Coil) from RCL_JCAP_SURFACE_INSPECTION inner join CRM_HR_CR_RLN on substring(Mother_Coil,0,7) = substring(CR_COIL_ID,0,7)   where  " & lstProcessingline.SelectedValue.ToString & " between '" & FromDate & "' and '" & ToDate & " '"
            Dim ds As DataTable = objDataHandler.GetDataSetFromQuery(quiry_filter).Tables(0)
            ''''''''''''''''''''''''''''''
            Dim botom_data As New DataTable
            '' Mother_Coil,DEF_LEN,Surface,severity,TCM_ROLLING_DT
            botom_data.Columns.Add("Mother_Coil")
            botom_data.Columns.Add("DEF_LEN")
            botom_data.Columns.Add("Surface")
            botom_data.Columns.Add("severity")
            botom_data.Columns.Add("dat")
            Dim top_data As New DataTable
            top_data.Columns.Add("Mother_Coil")
            top_data.Columns.Add("DEF_LEN")
            top_data.Columns.Add("Surface")
            top_data.Columns.Add("severity")
            top_data.Columns.Add("dat")
            Dim full_data As New DataTable
            full_data.Columns.Add("Mother_Coil")
            full_data.Columns.Add("DEF_LEN")
            full_data.Columns.Add("Surface")
            full_data.Columns.Add("severity")
            full_data.Columns.Add("dat")
            Dim di As Integer
            If ds.Rows.Count >= 20000 Then
                di = 30
            ElseIf ds.Rows.Count >= 15000 Then
                di = 25
            ElseIf ds.Rows.Count >= 10000 Then
                di = 15
            ElseIf ds.Rows.Count >= 5000 Then
                di = 10
            ElseIf ds.Rows.Count >= 1000 Then
                di = 5
            Else
                di = 3
            End If
            '' If ds.Rows.Count >= 1000 Then
            Dim num As Integer = Convert.ToInt32(ds.Rows.Count) / di
            Dim from As Integer = 0
            Dim too As Integer
            For i As Integer = 1 To di

                too += num
                If i = di Then
                    For coun As Integer = from To ds.Rows.Count - 1
                        f1 &= "'" & ds.Rows(coun)("Mother_Coil") & "',"
                    Next
                Else
                    For coun As Integer = from To too
                        f1 &= "'" & ds.Rows(coun)("Mother_Coil") & "',"
                    Next
                End If

                from = too + 1
                f1 = f1.Remove(f1.Length - 1, 1)
                quiry_ora = "   select  ccl_id_coil from  crmdba.t_cold_coil where ccl_cd_status in ( " & status & " ) and ccl_id_coil in (" & f1 & ")"
                Dim dta1 As DataTable = objDataHandler.GetOracleData1(quiry_ora).Tables(0)
                For coun1 As Integer = 0 To dta1.Rows.Count - 1
                    f2 &= "'" & dta1.Rows(coun1)("ccl_id_coil") & "',"
                Next
                f2 = f2.Remove(f2.Length - 1, 1)

                Dim process_a As String = Nothing
                Dim process_b As String = Nothing
                Dim slab_rev As String = objController.slab_reversal(lstProcessingline.SelectedItem.Text)
                Dim s As String() = slab_rev.Split(New Char() {","c})
                ''BOTTOM_PLOT
                process_a = s(0)
                ''TOP_PLOT
                process_b = s(1)

                Dim dt As DataTable = objController.GetDataForInspection_tdc(f2, strFromDate, strToDate, DefectName, process_a.Substring(0, 1), lstmeasure.SelectedItem.Text, lstProcessingline.SelectedValue.ToString, Severity:=Severity, grade:=Grade, tdcno:=TDC)
                Dim temp As String = dt.Rows.Count



                botom_data.Merge(dt, False, MissingSchemaAction.Ignore)
                botom_data.AcceptChanges()
                Dim st As String = botom_data.Rows.Count
                Dim dt1 As DataTable = objController.GetDataForInspection_tdc(f2, strFromDate, strToDate, DefectName, process_b.Substring(0, 1), lstmeasure.SelectedItem.Text, lstProcessingline.SelectedValue.ToString, Severity:=Severity, grade:=Grade, tdcno:=TDC)

                top_data.Merge(dt1, False, MissingSchemaAction.Ignore)
                top_data.AcceptChanges()


                Dim dt2 As DataTable = objController.GetDataForInspection_tdc(f2, strFromDate, strToDate, DefectName, "none", lstmeasure.SelectedItem.Text, lstProcessingline.SelectedValue.ToString, Severity:=Severity, grade:=Grade, tdcno:=TDC)
                full_data.Merge(dt2, False, MissingSchemaAction.Ignore)
                full_data.AcceptChanges()

                f1 = Nothing
                f2 = Nothing
            Next
            If botom_data.Rows.Count > 0 Or top_data.Rows.Count > 0 Or full_data.Rows.Count > 0 Then
                Dim dataView As New DataView(botom_data)
                dataView.Sort = "dat desc"
                botom_data = dataView.ToTable()
                Dim dataView1 As New DataView(top_data)
                dataView1.Sort = "dat desc"
                top_data = dataView1.ToTable()
                Dim dataView2 As New DataView(full_data)
                dataView2.Sort = "dat desc"
                full_data = dataView2.ToTable()


                objController.Boxplot_tdc(botom_data, Lit1, "container", ymin.Text, ymax.Text, lstmeasure.SelectedItem.Text, "BOTTOM", defectName:=DefectName.Replace("'", ""), grade:=Grade, tdcno:=TDC, indx:=1)
                objController.Boxplot_tdc(top_data, Lit2, "container1", ymin.Text, ymax.Text, lstmeasure.SelectedItem.Text, "TOP", defectName:=DefectName.Replace("'", ""), grade:=Grade, tdcno:=TDC, indx:=2)
                objController.Boxplot_tdc(full_data, Lit3, "container2", ymin.Text, ymax.Text, lstmeasure.SelectedItem.Text, "BOTTOM & TOP", defectName:=DefectName.Replace("'", ""), grade:=Grade, tdcno:=TDC, indx:=3)

            Else
                Lit1.Text = ""
                Lit2.Text = ""
                Lit3.Text = ""
            End If







        Catch ex As Exception
            Lit1.Text = ""
            Lit2.Text = ""
            Lit3.Text = ""
        End Try

    End Sub
    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try
            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            'LoadDefectList(dtStart, dtEnd)
            'LoadGradeTDC(dtStart, dtEnd)
            'DrawChart(dtStart, dtEnd, ddlDefName.SelectedItem.Text, ddlSurface.SelectedValue.ToString())
            Dim strDefect As String = getSelectedData(lstDefName)
            Dim strSeverity As String = getSelectedData(lstSeverity)
            Dim strGrade As String = getSelectedData(lstGrade)
            Dim strTDC As String = getSelectedData(lstTDC)
            Dim strstatus As String = getSelectedData(statuslist)
            If strDefect.Length > 0 Then
                strDefect = "'" & strDefect.Replace(",", "','") & "'"
            End If

            If strGrade.Length > 0 Then
                strGrade = "'" & strGrade.Replace(",", "','") & "'"
            End If

            If strTDC.Length > 0 Then
                strTDC = "'" & strTDC.Replace(",", "','") & "'"
            End If
            If strstatus.Length > 0 Then
                strstatus = "'" & strstatus.Replace(",", "','") & "'"
            Else
                Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('SELECT STATUS VALUES');", True)
                Lit1.Text = ""
                Lit2.Text = ""
                Lit3.Text = ""
                Exit Sub
            End If
            'DrawChart(dtStart, dtEnd, ddlDefName.SelectedItem.Text, ddlSurface.SelectedValue.ToString())
            DrawChart(dtStart, dtEnd, strDefect, strSeverity, strGrade, strTDC, strstatus)
        Catch ex As Exception

        End Try

    End Sub

    Function getSelectedData(ByRef lst As ListBox) As String
        Dim retVal As String = ""
        Try
            For Each lstItem As ListItem In lst.Items
                If lstItem.Selected = True Then
                    retVal &= "," & lstItem.Text & ""
                End If
            Next

        Catch ex As Exception

        End Try

        If retVal.Length > 0 Then
            Return retVal.Substring(1)
        Else
            Return retVal
        End If


        'Return (retVal)
    End Function

    Protected Sub btnGo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnGo.Click
        Dim dtStart As String = hfFrom.Value
        Dim dtEnd As String = hfTo.Value
        'LoadDefectList(dtStart, dtEnd)

        Dim strDefect As String = getSelectedData(lstDefName)
        Dim strSeverity As String = getSelectedData(lstSeverity)
        Dim strGrade As String = getSelectedData(lstGrade)
        Dim strTDC As String = getSelectedData(lstTDC)
        Dim strstatus As String = getSelectedData(statuslist)
        If strDefect.Length > 0 Then
            strDefect = "'" & strDefect.Replace(",", "','") & "'"
        End If

        If strGrade.Length > 0 Then
            strGrade = "'" & strGrade.Replace(",", "','") & "'"
        End If

        If strTDC.Length > 0 Then
            strTDC = "'" & strTDC.Replace(",", "','") & "'"
        End If
        If strstatus.Length > 0 Then
            strstatus = "'" & strstatus.Replace(",", "','") & "'"
        Else
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('SELECT STATUS VALUES');", True)
            Lit1.Text = ""
            Lit2.Text = ""
            Lit3.Text = ""
            Exit Sub
        End If
        'DrawChart(dtStart, dtEnd, ddlDefName.SelectedItem.Text, ddlSurface.SelectedValue.ToString())
        DrawChart(dtStart, dtEnd, strDefect, strSeverity, strGrade, strTDC, strstatus)
    End Sub
    <WebMethod()>
    Public Shared Function GetAutoCompleteData(ByVal username As String) As List(Of String)
        Dim result As List(Of String) = New List(Of String)()

        Using con As SqlConnection = New SqlConnection("server=176.0.0.60\LPTGSQLDEV;database=FP_PROCESS_DATA;uid=153521;pwd=Welcome@135")

            Using cmd As SqlCommand = New SqlCommand("select distinct top 10 Mother_Coil from RCL_JCAP_SURFACE_INSPECTION  inner join CRM_HR_CR_RLN on Mother_Coil = CR_COIL_ID where Mother_Coil  LIKE '%'+@SearchText+'%'", con)
                con.Open()
                cmd.Parameters.AddWithValue("@SearchText", username)
                Dim dr As SqlDataReader = cmd.ExecuteReader()

                While dr.Read()
                    result.Add(String.Format("{0}", dr("Mother_Coil")))
                End While

                Return result
            End Using
        End Using
    End Function
End Class
