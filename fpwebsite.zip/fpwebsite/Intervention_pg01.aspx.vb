﻿Imports System.Data
Imports System.IO
Partial Class Intervention_pg01
    Inherits System.Web.UI.Page
    Dim objController As New Controller_E_Main
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub

    'Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load



    '    If Not Page.IsPostBack Then
    '        Try

    '            Dim dtStart As String = DateTime.Now.AddDays(-29).ToString("yyyy-MM-dd HH:mm")
    '            'Dim dtStart As DateTime = DateTime.Now.AddMonths(-4).ToString("yyyy-MM-dd HH:mm")
    '            Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

    '            objController.PopulateGrade(ddl_cylinder, dtStart, dtEnd)

    '        Catch ex As Exception

    '        End Try

    '    End If
    'End Sub


    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If gvDetails.Rows.Count > 0 Then
            gvDetails.UseAccessibleHeader = True
            gvDetails.HeaderRow.TableSection = TableRowSection.TableHeader
        End If
        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                objController.FnGetDataFromQuery1(ddl)
                ' objControllernew.FnGetDataFromQueryCylinder(ddl_cylinder)

                Dim dtStart As String = DateTime.Now.AddDays(-29).ToString("yyyy-MM-dd HH:mm")
                ' Dim dtStart As DateTime = DateTime.Now.AddMonths(-4).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

                objController.PopulateCylinder(ddl_cylinder, dtStart, dtEnd)



                objController.PopulateDetails(dtStart, dtEnd, gvDetails, ddl_cylinder)

                ' Dim query As String = "Select distinct SAMPLING_DATE as 'SAMPLING_DATE',COIL_ID,TEST_VALUE as 'TEST_VALUE','' as 'PARAM_TEST','' as 'PROCESS_LINE',GRADE as GRADE,TDC_NO as TDC_NO, CD_PROD as CD_PROD from T_DM1 where PARAM_TEST = 'PRM_TEST_VALUE_FEGA' and SAMPLING_DATE between '" & dtStart & "' and '" & dtEnd & "' and TEST_VALUE is not null and TEST_VALUE > 0 order by SAMPLING_DATE"
                'Dim query As String = "  SELECT [CRM_CGL2_STROKETIME_ALARM].csa_param_name, [CRM_MECH_MAINT_INTERVENTION].[EQUIP_NAME], [CRM_CGL2_STROKETIME_ALARM].[CSA_DATETIME] as 'ALARM_DATE', ACTION_TAKEN as 'ACTION_TAKEN', ACTION_BY AS 'ACTION_BY',  ACTION_ON AS 'ACTION_ON' , REMARK AS'REMARK'     FROM [CRM_CGL2_STROKETIME_ALARM] left  JOIN 	 [CRM_MECH_MAINT_INTERVENTION] ON [CRM_CGL2_STROKETIME_ALARM].[Csa_PARAM_NAME]=[CRM_MECH_MAINT_INTERVENTION].[EQUIP_NAME]  order by [Csa_DATETIME] desc"

                'objController.PopulateDailyReportData(query, gvDetails)
                'If gvDetails.Rows.Count > 0 Then
                '    gvDetails.UseAccessibleHeader = True
                '    gvDetails.HeaderRow.TableSection = TableRowSection.TableHeader
                '    '  gvDetails.DataSource = Nothing
                '    gvDetails.DataBind()
                'End If
            Catch ex As Exception
                Throw New Exception(ex.ToString())
            End Try


        End If
    End Sub

    Protected Sub ddl_cylinderIndexChanged(sender As Object, e As System.EventArgs) Handles ddl_cylinder.SelectedIndexChanged
        Try
            Dim dtStart As String = DateTime.Now.AddDays(-29).ToString("yyyy-MM-dd HH:mm")
            'Dim dtStart As DateTime = DateTime.Now.AddMonths(-4).ToString("yyyy-MM-dd HH:mm")
            Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        Catch ex As Exception

        End Try

    End Sub
   
    ' Dim query As String = "Select distinct SAMPLING_DATE as 'SAMPLING_DATE',COIL_ID,TEST_VALUE as 'TEST_VALUE','' as 'PARAM_TEST','' as 'PROCESS_LINE',GRADE as GRADE,TDC_NO as TDC_NO, CD_PROD as CD_PROD from T_DM1 where PARAM_TEST = 'PRM_TEST_VALUE_FEGA' and SAMPLING_DATE between '" & dtStart & "' and '" & dtEnd & "' and TEST_VALUE is not null and TEST_VALUE > 0 order by SAMPLING_DATE"
    'Dim query As String = "  SELECT [CRM_CGL2_STROKETIME_ALARM].csa_param_name, [CRM_MECH_MAINT_INTERVENTION].[EQUIP_NAME], [CRM_CGL2_STROKETIME_ALARM].[CSA_DATETIME] as 'ALARM_DATE', ACTION_TAKEN as 'ACTION_TAKEN', ACTION_BY AS 'ACTION_BY',  ACTION_ON AS 'ACTION_ON' , REMARK AS'REMARK'     FROM [CRM_CGL2_STROKETIME_ALARM] left outer JOIN 	 [CRM_MECH_MAINT_INTERVENTION] ON [CRM_CGL2_STROKETIME_ALARM].[Csa_PARAM_NAME]=[CRM_MECH_MAINT_INTERVENTION].[EQUIP_NAME]  order by [Csa_DATETIME] desc"

    '            objController.PopulateDailyReportData(query, gvDetails)
    '            If gvDetails.Rows.Count > 0 Then
    '                gvDetails.UseAccessibleHeader = True
    '                gvDetails.HeaderRow.TableSection = TableRowSection.TableHeader
    ''  gvDetails.DataSource = Nothing
    '                gvDetails.DataBind()
    '            End If
    '        Catch ex As Exception
    '            Throw New Exception(ex.ToString())
    '        End Try



    '    End If
    'End Sub

    Protected Sub ddlGrade_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddl_cylinder.SelectedIndexChanged
        Try
            Dim dtStart As String = DateTime.Now.AddDays(-29).ToString("yyyy-MM-dd HH:mm")
            'Dim dtStart As DateTime = DateTime.Now.AddMonths(-4).ToString("yyyy-MM-dd HH:mm")
            Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        Catch ex As Exception

        End Try

    End Sub


    Protected Sub Button1_Click(sender As Object, e As System.EventArgs) Handles Button1.Click
        '  objController.FunSubmit(ddl.SelectedValue, ddl_cylinder.SelectedValue)
        Dim dtStart As String = DateTime.Now.AddDays(-29).ToString("yyyy-MM-dd HH:mm")
        'Dim dtStart As DateTime = DateTime.Now.AddMonths(-4).ToString("yyyy-MM-dd HH:mm")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

        Dim query As String = "  SELECT [CRM_CGL2_STROKETIME_ALARM].csa_param_name, [CRM_MECH_MAINT_INTERVENTION].[EQUIP_NAME], [CRM_CGL2_STROKETIME_ALARM].[CSA_DATETIME] as 'ALARM_DATE', ACTION_TAKEN as 'ACTION_TAKEN', ACTION_BY AS 'ACTION_BY',  ACTION_ON AS 'ACTION_ON' , REMARK AS'REMARK'     FROM [CRM_CGL2_STROKETIME_ALARM] left outer JOIN 	 [CRM_MECH_MAINT_INTERVENTION] ON [CRM_CGL2_STROKETIME_ALARM].[Csa_PARAM_NAME]=[CRM_MECH_MAINT_INTERVENTION].[EQUIP_NAME] and csa_datetime=alarm_date  where Csa_PARAM_NAME = '" & ddl_cylinder.SelectedValue & "' order by [Csa_DATETIME] desc"

        ' objController.PopulateDailyReportData(query, gvDetails)

        objController.PopulateDetails(dtStart, dtEnd, gvDetails, ddl_cylinder)
        If gvDetails.Rows.Count > 0 Then
            gvDetails.UseAccessibleHeader = True
            gvDetails.HeaderRow.TableSection = TableRowSection.TableHeader
            '  gvDetails.DataSource = Nothing
            gvDetails.DataBind()
        End If
    End Sub

    'Protected Sub gvDetails_RowCancelingEdit(sender As Object, e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) Handles gvDetails.RowCancelingEdit
    '    gvDetails.EditIndex = -1
    '    '  ddlParamTest1_SelectedIndexChanged(sender, e)

    'End Sub

   

    Private Sub gdvDetails_RowCancelingEdit(sender As Object, e As GridViewCancelEditEventArgs) Handles gvDetails.RowCancelingEdit
        Try
            'objController.FunSubmit(ddl.SelectedValue, ddl_cylinder.SelectedValue)

            gvDetails.EditIndex = -1
            Dim dtStart As String = DateTime.Now.AddDays(-29).ToString("yyyy-MM-dd HH:mm")
            ' Dim dtStart As DateTime = DateTime.Now.AddMonths(-4).ToString("yyyy-MM-dd HH:mm")
            Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

            objController.PopulateDetails(dtStart, dtEnd, gvDetails, ddl_cylinder)

        Catch ex As Exception

        End Try

    End Sub




    'Private Sub gdvDetails_RowDeleting(sender As Object, e As GridViewDeleteEventArgs) Handles gdvDetails.RowDeleting
    '    Try
    '        'OpenModal(" ConfrmMsgModal")
    '        Dim fromDt As String = hfFrom.Value
    '        Dim toDt As String = hfTo.Value
    '        Dim row As GridViewRow = gdvDetails.Rows(e.RowIndex)

    '        Dim datetime As DateTime = (TryCast(row.FindControl("lblDatetime"), Label)).Text

    '        objController.DeleteIngot(datetime.ToString("yyyy-MM-dd HH:mm:ss"))
    '        UserMsgBoxSuccess("Deleted successfully.")
    '        objController.PopulateIngotDetails(fromDt, toDt, gdvDetails)
    '        MonthConsumption()
    '    Catch ex As Exception

    '    End Try


    'End Sub




    'Protected Sub gvDetails_RowEditing(sender As Object, e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles gvDetails.RowEditing
    '    gvDetails.EditIndex = e.NewEditIndex
    '    '  ddlParamTest1_SelectedIndexChanged(sender, e)
    'End Sub
    Private Sub gdvDetails_RowEditing(sender As Object, e As GridViewEditEventArgs) Handles gvDetails.RowEditing
        Try
            'objController.FunSubmit(ddl.SelectedValue, ddl_cylinder.SelectedValue)


            gvDetails.EditIndex = e.NewEditIndex
            Dim dtStart As String = DateTime.Now.AddDays(-29).ToString("yyyy-MM-dd HH:mm")
            ' Dim dtStart As DateTime = DateTime.Now.AddMonths(-4).ToString("yyyy-MM-dd HH:mm")
            Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

            objController.PopulateDetails(dtStart, dtEnd, gvDetails, ddl_cylinder)

        Catch ex As Exception

        End Try

    End Sub

    
    'Private Sub gdvDetails_RowUpdating(sender As Object, e As GridViewUpdateEventArgs) Handles gdvDetails.RowUpdating
    '    Try

    '        Dim row As GridViewRow = gdvDetails.Rows(e.RowIndex)

    '        Dim datetime As DateTime = (TryCast(row.FindControl("txtDatetime"), TextBox)).Text
    '        Dim cgg As String = (TryCast(row.FindControl("txtCGG"), TextBox)).Text
    '        Dim shg As String = (TryCast(row.FindControl("txtSHG"), TextBox)).Text
    '        Dim AlPer As String = (TryCast(row.FindControl("txtAl"), TextBox)).Text
    '        Dim Dross As String = (TryCast(row.FindControl("txtdross"), TextBox)).Text
    '        gdvDetails.EditIndex = -1
    '        Dim count As Integer = 0
    '        count = objController.UpdateIngotAddition(datetime.ToString("yyyy-MM-dd HH:mm:ss"), cgg, shg, AlPer, Dross)
    '        If count > 0 Then
    '            UserMsgBoxSuccess("Updated successfully.")
    '        End If
    '        Dim fromDt As String = hfFrom.Value
    '        Dim toDt As String = hfTo.Value
    '        objController.PopulateIngotDetails(fromDt, toDt, gdvDetails)
    '        MonthConsumption()

    '    Catch ex As Exception

    '    End Try
    'End Sub



    Protected Sub gvDetails_RowUpdating(sender As Object, e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles gvDetails.RowUpdating
        Try

            '        Dim row As GridViewRow = gdvDetails.Rows(e.RowIndex)
            'objController.FunSubmit(ddl.SelectedValue, ddl_cylinder.SelectedValue)


            Dim row As GridViewRow = gvDetails.Rows(e.RowIndex)
            Dim Alarm_date As DateTime = (TryCast(row.FindControl("lblDatetime"), Label)).Text
            Dim Action_Taken As String = (TryCast(row.FindControl("txtActionTaken"), TextBox)).Text
            Dim Action_By As String = (TryCast(row.FindControl("txtActionBy"), TextBox)).Text
            Dim Action_On As DateTime = (TryCast(row.FindControl("txtActionOn"), TextBox)).Text
            Dim Remark As String = (TryCast(row.FindControl("txtRemark"), TextBox)).Text
            'Dim ddlSection As DropDownList = ddl_Cylinder.SelectedValue
            'Dim ddl_Cylinder As String = (TryCast(row.FindControl("ddl_cylinder.SelectedValue"), TextBox)).Text
            ''CDate(dtTemp.Rows(i)(3).ToString().Replace("'", "")).ToString("yyyy-MM-dd HH:mm:ss")
            gvDetails.EditIndex = -1
            Dim count As Integer = 0

            count = objController.UpdateDailyReportData(Alarm_date.ToString("yyyy-MM-dd HH:mm:ss"), Action_Taken, Action_By, Action_On.ToString("yyyy-MM-dd HH:mm:ss"), Remark, ddl_cylinder, ddl.SelectedValue)

            If count > 0 Then
                UserMsgBoxSuccess("Updated successfully.")
            End If
            Dim dtStart As String = DateTime.Now.AddDays(-29).ToString("yyyy-MM-dd HH:mm")
            ' Dim dtStart As DateTime = DateTime.Now.AddMonths(-4).ToString("yyyy-MM-dd HH:mm")
            Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

            objController.PopulateDetails(dtStart, dtEnd, gvDetails, ddl_cylinder)
            ' MonthConsumption()


        Catch ex As Exception

        End Try
    End Sub

   
    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)
        ' Verifies that the control is rendered 
    End Sub

    'Public Sub DeleteIngot(ByVal datetime As String)
    '    objDataHandler.RunSimpleQuery("Delete from [FP_PROCESS_DATA].[dbo].[CGL2_INGOT_ADDITION] where CIA_TIMESTAMP='" & datetime & "'  ")
    'End Sub
End Class
