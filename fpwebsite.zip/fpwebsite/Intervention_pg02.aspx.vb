﻿
Partial Class Intervention_pg02
    Inherits System.Web.UI.Page

End Class
