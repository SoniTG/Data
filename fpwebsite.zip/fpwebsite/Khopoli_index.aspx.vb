﻿
Partial Class Khopoli_index
    Inherits System.Web.UI.Page

End Class
