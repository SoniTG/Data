﻿Imports System.Data
Imports System.IO
Imports System.Web.Services

Partial Class LD3_MILL_HOME
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim LD_TABLE As DataTable = objController.mater_page("LD3 & TSCR MILL")
                index_page(LD_TABLE, LD3_lit, "c1")
                index_page1(LD_TABLE, LD2_lit, "c1")

            Catch ex As Exception

            End Try
        End If
    End Sub

    Sub index_page(ByVal data As DataTable, ByVal divid As Literal, ByVal colorclass As String)
        '  If divid.Equals(CRM_lit) Then
       
        Try
            Dim liclass = "list-group-item " & colorclass
           
            Dim formation = Nothing
            Dim dv As DataView = data.DefaultView
            Dim temp1 As New DataTable
            Dim temp2 As New DataTable
            Dim temp3 As New DataTable
            Dim H As String = "D"
            Dim HM As String = "e"
            Dim DEMO As String = "HMO.aspx"
            Dim DEMO1 As String = "ComingSoon.aspx"
            Dim DEMO2 As String = "ComingSoon.aspx"
            Dim name As String = "HMO"
            Dim name1 As String = "New Euipment to be added"
            Dim name2 As String = "New Tab"
            Dim name3 As String = "New Tab"
            '  Dim technology As String = ddlTechnology.SelectedItem.Value
            ' Response.Redirect(String.Format("~/index.aspx?name={0}", HMO))

            ' formation &= " <h4>" & H & "</h4><ul class=""list-group"">"


         
            ' formation &= "<li class='" & liclass & "'>" & H & ""
            formation &= "<ul class=""list-group""><li class=""list-group-item""><a href='" & DEMO & "'>" & name & "</a>"

            'formation &= "<ul class=""list-group"">"
            'formation &= "<li class=""list-group-item""> <a id= '" & HM & "," & HMO & "' href='#' '  >" & DEMO & "</a></li>"

            'formation &= "  </ul>"
            formation &= "</li> </ul>"


            formation &= "<ul class=""list-group""><li class=""list-group-item""><a href='" & DEMO1 & "'>" & name1 & "</a>"

            'formation &= "<ul class=""list-group"">"
            'formation &= "<li class=""list-group-item""> <a id= '" & HM & "," & HMO & "' href='#' '  >" & DEMO & "</a></li>"

            'formation &= "  </ul>"
            formation &= "</li> </ul>"

            formation &= "<ul class=""list-group""><li class=""list-group-item""><a href='" & DEMO1 & "'>" & name1 & "</a>"


            formation &= "</li> </ul>"


            formation &= "</li>"
          
            formation &= "</ul> "
            divid.Text = formation

            Dim stri As String = formation
        Catch ex As Exception
            Throw ex
        End Try
        ' End If

    End Sub
    Sub index_page1(ByVal data As DataTable, ByVal divid As Literal, ByVal colorclass As String)
        '  If divid.Equals(CRM_lit) Then

        Try
            Dim liclass = "list-group-item " & colorclass

            Dim formation = Nothing
            Dim dv As DataView = data.DefaultView
            Dim temp1 As New DataTable
            Dim temp2 As New DataTable
            Dim temp3 As New DataTable
            Dim H As String = "D"
            Dim HM As String = "e"
            Dim DEMO As String = "ComingSoon.aspx"
            Dim DEMO1 As String = "ComingSoon.aspx"
            Dim DEMO2 As String = "ComingSoon.aspx"
            Dim name As String = "HMO"
            Dim name1 As String = "New Euipment to be added"
            Dim name2 As String = "New Tab"
            Dim name3 As String = "New Tab"

            '  Dim technology As String = ddlTechnology.SelectedItem.Value
            ' Response.Redirect(String.Format("~/index.aspx?name={0}", HMO))

            ' formation &= " <h4>" & H & "</h4><ul class=""list-group"">"



            ' formation &= "<li class='" & liclass & "'>" & H & ""
            formation &= "<ul class=""list-group""><li class=""list-group-item""><a href='" & DEMO & "'>" & name1 & "</a>"

            'formation &= "<ul class=""list-group"">"
            'formation &= "<li class=""list-group-item""> <a id= '" & HM & "," & HMO & "' href='#' '  >" & DEMO & "</a></li>"

            'formation &= "  </ul>"

            formation &= "</li>  </ul>"
            formation &= "<ul class=""list-group""><li class=""list-group-item""><a href='" & DEMO & "'>" & name1 & "</a>"


            formation &= "</li> </ul>"

            formation &= "<ul class=""list-group""><li class=""list-group-item""><a href='" & DEMO1 & "'>" & name1 & "</a>"


            formation &= "</li> </ul>"



            formation &= "</li>"

            formation &= "</ul> "
            divid.Text = formation

            Dim stri As String = formation
        Catch ex As Exception
            Throw ex
        End Try
        ' End If

    End Sub
End Class

'Partial Class LD3_MILL_HOME
'    Inherits System.Web.UI.Page

'End Class
