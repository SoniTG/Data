﻿Imports System.Data
Imports System.IO
Imports OfficeOpenXml


Partial Class LineChart
    Inherits System.Web.UI.Page

    Dim objdatahandler As New DataHandler
    Dim objController As New Controller


    Dim SELECT_LINE As String = ""
    Dim Select_Parameters As String = ""

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load


        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dSdate As DataSet = objdatahandler.GetDataSetFromQuery("select max(datetime) as DATETIME FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]")
                Dim dtdate As DataTable = dSdate.Tables(0)

                Dim ddtdate As DateTime = dtdate.Rows(0)("DATETIME")
                Dim frmDate As String = ddtdate.ToString("yyyy-MM-dd HH:mm:ss")

                'Dim toDate As String = ddtdate.AddHours(-1).ToString("yyyy-MM-dd HH:mm:ss")
                Dim toDate As String = ddtdate.AddDays(-3).ToString("yyyy-MM-dd HH:mm:ss")
                '=============LINEA AND B
                SELECT_LINE = Session("checkboxval")
                Select_Parameters = Session("checkLineChartParameters")

                Dim ds As DataSet = objdatahandler.GetDataSetFromQuery("SELECT   [DATETIME], " & Select_Parameters & "  FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL] where LINE =  '" & SELECT_LINE & "'  AND  [datetime] between '" & toDate & "' and '" & frmDate & "' and " & Select_Parameters & "  is not null ORDER BY DATETIME ASC")
                Dim dt As DataTable = ds.Tables(0)
                'between '" & frmDate & "' and '" & toDate & "'
                Try
                    Lit1.Text = ""

                    Dim yVal() As Decimal
                    yVal = (From row In dt Select col = CDec(row(Select_Parameters))).ToArray()

                    Dim y_min As String = -1
                    Dim y_max As String = yVal.Max() + 1


                    Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                     "$.jqplot.config.enablePlugins = true;" & vbCrLf
                    js &= "var line1 = ["
                    For i As Integer = 0 To dt.Rows.Count - 1
                        js &= "['" & CDate(dt.Rows(i)("DATETIME")).ToString("yyyy-MM-dd HH:mm:ss") & "'," & dt.Rows(i)(Select_Parameters) & "],"

                    Next
                    js &= "];"
                    'js &= "var line2 = ["
                    'For i As Integer = 0 To dt.Rows.Count - 1
                    '    js &= "['" & dt.Rows(i)("DATETIME") & "'," & dt.Rows(i)("BASE_VALUE_RECOM") & "],"

                    'Next
                    'js &= "];"
                    Dim plotname = "plot1"
                    Dim ContainerName = "container1"
                    js &= "var " & plotname & " = $.jqplot('" & ContainerName & "',[line1], {"
                    js &= "series:[{  showMarker:true,pointLabels: { show:false } ,label:'" & Select_Parameters & "'  }],"
                    js &= "axesDefaults: { tickRenderer: $.jqplot.CanvasAxisTickRenderer ,tickOptions: {  angle: 30 ,fontSize:  '8pt'  }},"
                    js &= "seriesColors:['#0B62A4'],"
                    js &= "axes: {labelOptions:{fontSize:  '8pt'},"
                    js &= "xaxis: {   label : " & """Time""" & ",labelOptions:{fontSize:  '8pt'},renderer:$.jqplot.DateAxisRenderer,tickOptions:{formatString:'%Y/%#m/%#d %H:%M:%S'}},"
                    js &= "yaxis: {type: 'value',min:" & y_min & ", max: " & y_max & " , label:'Parameters',labelRenderer: $.jqplot.CanvasAxisLabelRenderer }"
                    js &= "}, highlighter: {show: true}, cursor: { show: true, zoom:true,},grid: {backgroundColor:  'rgb(255,255,255)'} ,legend:{show:true,placement: 'OutsideGrid',rendererOptions: {numberRows: 1, marginTop: 10 },  renderer: $.jqplot.EnhancedLegendRenderer } });"
                    js &= "</script>"
                    Lit1.Text = js
                Catch ex As Exception

                    Throw ex
                End Try



            Catch ex As Exception

            End Try
        End If
    End Sub

    Protected Sub txtDate_TextChanged(sender As Object, e As System.EventArgs) Handles txtDate.TextChanged
        Try
            Dim fromDt As DateTime = hfFrom.Value
            Dim toDt As DateTime = hfTo.Value
            Dim DateDifference As String = DateDiff(DateInterval.Day, fromDt, toDt).ToString()
            If DateDifference > 3 Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "Pop", "$('#loginModal').modal('show');", True)
            Else
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "Pop", "$('#loginModal').modal('hide');", True)
                SELECT_LINE = Session("checkboxval")
                Select_Parameters = Session("checkLineChartParameters")

                Dim ds As DataSet = objdatahandler.GetDataSetFromQuery("SELECT   [DATETIME], " & Select_Parameters & "  FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL] where LINE =  '" & SELECT_LINE & "'  AND  [datetime] between '" & fromDt & "' and '" & toDt & "' and " & Select_Parameters & "  is not null ORDER BY DATETIME ASC")
                Dim dt As DataTable = ds.Tables(0)
                'between '" & frmDate & "' and '" & toDate & "'
                Try
                    Lit1.Text = ""

                    Dim yVal() As Decimal
                    yVal = (From row In dt Select col = CDec(row(Select_Parameters))).ToArray()

                    Dim y_min As String = -1
                    Dim y_max As String = yVal.Max() + 1


                    Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                         "$.jqplot.config.enablePlugins = true;" & vbCrLf
                    js &= "var line1 = ["
                    For i As Integer = 0 To dt.Rows.Count - 1
                        js &= "['" & CDate(dt.Rows(i)("DATETIME")).ToString("yyyy-MM-dd HH:mm:ss") & "'," & dt.Rows(i)(Select_Parameters) & "],"

                    Next
                    js &= "];"
                    'js &= "var line2 = ["
                    'For i As Integer = 0 To dt.Rows.Count - 1
                    '    js &= "['" & dt.Rows(i)("DATETIME") & "'," & dt.Rows(i)("BASE_VALUE_RECOM") & "],"

                    'Next
                    'js &= "];"
                    Dim plotname = "plot1"
                    Dim ContainerName = "container1"
                    js &= "var " & plotname & " = $.jqplot('" & ContainerName & "',[line1], {"
                    js &= "series:[{  showMarker:true,pointLabels: { show:false } ,label:'" & Select_Parameters & "'  }],"
                    js &= "axesDefaults: { tickRenderer: $.jqplot.CanvasAxisTickRenderer ,tickOptions: {  angle: 30 ,fontSize:  '8pt'  }},"
                    js &= "seriesColors:['#0B62A4'],"
                    js &= "axes: {labelOptions:{fontSize:  '8pt'},"
                    js &= "xaxis: {   label : " & """Time""" & ",labelOptions:{fontSize:  '8pt'},renderer:$.jqplot.DateAxisRenderer,tickOptions:{formatString:'%Y/%#m/%#d %H:%M:%S'}},"
                    js &= "yaxis: {type: 'value',min:" & y_min & ", max: " & y_max & " , label:'Parameters',labelRenderer: $.jqplot.CanvasAxisLabelRenderer }"
                    js &= "}, highlighter: {show: true}, cursor: { show: true, zoom:true,},grid: {backgroundColor:  'rgb(255,255,255)'} ,legend:{show:true,placement: 'OutsideGrid',rendererOptions: {numberRows: 1, marginTop: 10 },  renderer: $.jqplot.EnhancedLegendRenderer } });"
                    js &= "</script>"
                    Lit1.Text = js
                Catch ex As Exception

                    Throw ex
                End Try
            End If


        Catch ex As Exception

        End Try
    End Sub

    Private Sub lnkDownload_Click(sender As Object, e As EventArgs) Handles lnkDownload.Click
        Try
            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value

            SELECT_LINE = Session("checkboxval")
            Select_Parameters = Session("checkLineChartParameters")

            Dim ds As DataSet = objdatahandler.GetDataSetFromQuery("SELECT   FORMAT([DATETIME],'dd-MM-yyyy HH:mm:ss')  As [DATETIME], " & Select_Parameters & "  FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL] where LINE =  '" & SELECT_LINE & "'  AND  [datetime] between '" & fromDt & "' and '" & toDt & "' and " & Select_Parameters & "  is not null ORDER BY DATETIME ASC")
            Dim dt1 As DataTable = ds.Tables(0)
            Dim i As Integer = 1
            Using ep As New ExcelPackage()
                'For Each dt As DataTable In ds.Tables
                'Dim ws As ExcelWorksheet = ep.Workbook.Worksheets.Add("s" & i)
                Dim ws As ExcelWorksheet = ep.Workbook.Worksheets.Add("Download")
                ws.Cells("A1").LoadFromDataTable(dt1, True)

                'i += 1
                'Next
                Using ms As New MemoryStream
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    Response.AddHeader("content-disposition", "attachment; filename=download.xlsx")
                    ep.SaveAs(ms)
                    ms.WriteTo(Response.OutputStream)
                    Response.Flush()
                    Response.End()
                End Using
            End Using



        Catch ex As Exception

        End Try
    End Sub
End Class
