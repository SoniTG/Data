﻿Imports System.Data
Imports System.IO
Imports OfficeOpenXml


Partial Class LineChartHSM
    Inherits System.Web.UI.Page

    Dim objdatahandler As New DataHandler
    Dim objDataHandlerGcp As New DataHandlerGCP

    Dim SELECT_LINE As String = ""
    Dim Select_Parameters As String = ""
    Dim Date_Field As String = ""
    Dim DatabaseName As String = ""

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load


        If Not Page.IsPostBack Then
            Try
                'Dim dSdate As DataSet = objdatahandler.GetDataSetFromQuery("select max(datetime) as DATETIME FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]")
                'Dim dtdate As DataTable = dSdate.Tables(0)

                Dim dtdate As DataTable = objDataHandlerGcp.DataReading("select FORMAT_DATE('%F %T',DATE_TIME) as DATE_TIME FROM `tsl-datalake.PTG_PSA.HSM_REHT_FURNC` Order By DATE_TIME Desc Limit 1")
                'Dim ddtdate As DateTime = Convert.ToDateTime(dtdate.Rows(0)("DATETIME"))
                Dim ddtdate As DateTime = dtdate.Rows(0)("DATE_TIME")

                Dim frmDate As String = ddtdate.ToString("yyyy-MM-dd HH:mm:ss")

                'Dim toDate As String = ddtdate.AddHours(-1).ToString("yyyy-MM-dd HH:mm:ss")
                Dim toDate As String = ddtdate.AddDays(-3).ToString("yyyy-MM-dd HH:mm:ss")
                '=============LINEA AND B

                ''''''=======Need to Be Commented Below LIne=======================


                'Session("checkboxval") = "1"
                'Session("checkLineChartParameters") = "HEAT_RECOV_PERC"
                'Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
                'Session("DateField") = "DATE_TIME"

                SELECT_LINE = Session("checkboxval")
                Select_Parameters = Session("checkLineChartParameters")
                Date_Field = Session("DateField")
                DatabaseName = Session("DBName")

                'Dim ds As DataSet = objdatahandler.GetDataSetFromQuery("SELECT   [DATETIME], " & Select_Parameters & "  FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL] where LINE =  '" & SELECT_LINE & "'  AND  [datetime] between '" & toDate & "' and '" & frmDate & "' and " & Select_Parameters & "  is not null ORDER BY DATETIME ASC")

                'Dim dt As DataTable = ds.Tables(0)

                'Dim dt As DataTable = objDataHandlerGcp.DataReading("SELECT   DATE_TIME, " & Select_Parameters & "  FROM `tsl-datalake.PTG_PSA.HSM_REHT_FURNC` where FCE_ID =  " & SELECT_LINE & "  AND  DATE_TIME between '" & toDate & "' and '" & frmDate & "' and " & Select_Parameters & "  is not null ORDER BY DATE_TIME ASC")
                'Dim dt As DataTable = objDataHandlerGcp.DataReading("SELECT   FORMAT_DATE('%F %T',DATE_TIME) As DATE_TIME, " & Select_Parameters & "  FROM `" & DatabaseName & "` where FCE_ID =  " & SELECT_LINE & "  AND  DATE_TIME between '2023-05-01 11:59:23' and '2023-07-07 11:59:23' and " & Select_Parameters & "  is not null ORDER BY DATE_TIME ASC")
                Dim dt As DataTable = objDataHandlerGcp.DataReading("SELECT   FORMAT_DATE('%F %T'," & Date_Field & ") As DATE_TIME, " & Select_Parameters & "  FROM `" & DatabaseName & "` where FCE_ID =  " & SELECT_LINE & "  AND  " & Date_Field & " between '" & toDate & "' and '" & frmDate & "' and " & Select_Parameters & "  is not null ORDER BY " & Date_Field & " ASC")


                'between '" & frmDate & "' and '" & toDate & "'
                Try
                    Lit1.Text = ""

                    Dim yVal() As Decimal
                    yVal = (From row In dt Select col = CDec(row(Select_Parameters))).ToArray()

                    Dim y_min As String = -1
                    Dim y_max As String = yVal.Max() + 1


                    Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                     "$.jqplot.config.enablePlugins = true;" & vbCrLf
                    js &= "var line1 = ["
                    For i As Integer = 0 To dt.Rows.Count - 1
                        js &= "['" & CDate(dt.Rows(i)("DATE_TIME")).ToString("yyyy-MM-dd HH:mm:ss") & "'," & dt.Rows(i)(Select_Parameters) & "],"

                    Next
                    js &= "];"
                    'js &= "var line2 = ["
                    'For i As Integer = 0 To dt.Rows.Count - 1
                    '    js &= "['" & dt.Rows(i)("DATETIME") & "'," & dt.Rows(i)("BASE_VALUE_RECOM") & "],"

                    'Next
                    'js &= "];"
                    Dim plotname = "plot1"
                    Dim ContainerName = "container1"
                    js &= "var " & plotname & " = $.jqplot('" & ContainerName & "',[line1], {"
                    js &= "series:[{  showMarker:true,pointLabels: { show:false } ,label:'" & Select_Parameters & "'  }],"
                    js &= "axesDefaults: { tickRenderer: $.jqplot.CanvasAxisTickRenderer ,tickOptions: {  angle: 30 ,fontSize:  '8pt'  }},"
                    js &= "seriesColors:['#0B62A4'],"
                    js &= "axes: {labelOptions:{fontSize:  '8pt'},"
                    js &= "xaxis: {   label : " & """Time""" & ",labelOptions:{fontSize:  '8pt'},renderer:$.jqplot.DateAxisRenderer,tickOptions:{formatString:'%Y/%#m/%#d %H:%M:%S'}},"
                    js &= "yaxis: {type: 'value',min:" & y_min & ", max: " & y_max & " , label:'Parameters',labelRenderer: $.jqplot.CanvasAxisLabelRenderer }"
                    js &= "}, highlighter: {show: true}, cursor: { show: true, zoom:true,},grid: {backgroundColor:  'rgb(255,255,255)'} ,legend:{show:true,placement: 'OutsideGrid',rendererOptions: {numberRows: 1, marginTop: 10 },  renderer: $.jqplot.EnhancedLegendRenderer } });"
                    js &= "</script>"
                    Lit1.Text = js
                Catch ex As Exception

                    Throw New Exception(ex.ToString())
                End Try



            Catch ex As Exception
                Throw New Exception(ex.ToString())
            End Try
        End If
    End Sub

    Protected Sub txtDate_TextChanged(sender As Object, e As System.EventArgs) Handles txtDate.TextChanged
        Try
            'Session("checkboxval") = "1"
            'Session("checkLineChartParameters") = "HEAT_RECOV_PERC"
            'Session("DBName") = "tsl-datalake.PTG_PSA.HSM_REHT_FURNC"
            'Session("DateField") = "DATE_TIME"


            Dim fromDt As DateTime = hfFrom.Value
            Dim toDt As DateTime = hfTo.Value

            Dim StDate As String = fromDt.ToString("yyyy-MM-dd HH:mm:ss")
            Dim EndDate As String = toDt.ToString("yyyy-MM-dd HH:mm:ss")


            Dim DateDifference As String = DateDiff(DateInterval.Day, fromDt, toDt).ToString()
            If DateDifference > 3 Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "Pop", "$('#loginModal').modal('show');", True)
            Else
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "Pop", "$('#loginModal').modal('hide');", True)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "Pop", "$('#noDataModal').modal('hide');", True)

                SELECT_LINE = Session("checkboxval")
                Select_Parameters = Session("checkLineChartParameters")
                Date_Field = Session("DateField")
                DatabaseName = Session("DBName")

                'Dim ds As DataSet = objdatahandler.GetDataSetFromQuery("SELECT   [DATETIME], " & Select_Parameters & "  FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL] where LINE =  '" & SELECT_LINE & "'  AND  [datetime] between '" & fromDt & "' and '" & toDt & "' and " & Select_Parameters & "  is not null ORDER BY DATETIME ASC")
                'Dim dt As DataTable = ds.Tables(0)
                'between '" & frmDate & "' and '" & toDate & "'

                Dim dt As DataTable = objDataHandlerGcp.DataReading("SELECT   FORMAT_DATE('%F %T'," & Date_Field & ") As DATE_TIME, " & Select_Parameters & "  FROM `" & DatabaseName & "` where FCE_ID =  " & SELECT_LINE & "  AND  " & Date_Field & " between '" & EndDate & "' and '" & StDate & "' and " & Select_Parameters & "  is not null ORDER BY " & Date_Field & " ASC")
                If dt.Rows.Count > 0 Then
                    Try
                        Lit1.Text = ""

                        Dim yVal() As Decimal
                        yVal = (From row In dt Select col = CDec(row(Select_Parameters))).ToArray()

                        Dim y_min As String = -1
                        Dim y_max As String = yVal.Max() + 1


                        Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                             "$.jqplot.config.enablePlugins = true;" & vbCrLf
                        js &= "var line1 = ["
                        For i As Integer = 0 To dt.Rows.Count - 1
                            js &= "['" & CDate(dt.Rows(i)("DATETIME")).ToString("yyyy-MM-dd HH:mm:ss") & "'," & dt.Rows(i)(Select_Parameters) & "],"

                        Next
                        js &= "];"
                        'js &= "var line2 = ["
                        'For i As Integer = 0 To dt.Rows.Count - 1
                        '    js &= "['" & dt.Rows(i)("DATETIME") & "'," & dt.Rows(i)("BASE_VALUE_RECOM") & "],"

                        'Next
                        'js &= "];"
                        Dim plotname = "plot1"
                        Dim ContainerName = "container1"
                        js &= "var " & plotname & " = $.jqplot('" & ContainerName & "',[line1], {"
                        js &= "series:[{  showMarker:true,pointLabels: { show:false } ,label:'" & Select_Parameters & "'  }],"
                        js &= "axesDefaults: { tickRenderer: $.jqplot.CanvasAxisTickRenderer ,tickOptions: {  angle: 30 ,fontSize:  '8pt'  }},"
                        js &= "seriesColors:['#0B62A4'],"
                        js &= "axes: {labelOptions:{fontSize:  '8pt'},"
                        js &= "xaxis: {   label : " & """Time""" & ",labelOptions:{fontSize:  '8pt'},renderer:$.jqplot.DateAxisRenderer,tickOptions:{formatString:'%Y/%#m/%#d %H:%M:%S'}},"
                        js &= "yaxis: {type: 'value',min:" & y_min & ", max: " & y_max & " , label:'Parameters',labelRenderer: $.jqplot.CanvasAxisLabelRenderer }"
                        js &= "}, highlighter: {show: true}, cursor: { show: true, zoom:true,},grid: {backgroundColor:  'rgb(255,255,255)'} ,legend:{show:true,placement: 'OutsideGrid',rendererOptions: {numberRows: 1, marginTop: 10 },  renderer: $.jqplot.EnhancedLegendRenderer } });"
                        js &= "</script>"
                        Lit1.Text = js
                    Catch ex As Exception

                        Throw ex
                    End Try
                Else
                    'Response.Write("<script>alert('Data Not Available between the Choosen Dates. Please Select a Different Date Range.');</script>")
                    ScriptManager.RegisterStartupScript(Me, Me.GetType(), "showalert", "alert('Data Not Available between the Choosen Dates. Please Select a Different Date Range.');", True)
                    'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "Pop", "$('#noDataModal').modal('show');", True)
                End If

            End If


        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub

    'Private Sub lnkDownload_Click(sender As Object, e As EventArgs) Handles lnkDownload.Click
    '    Try
    '        Dim fromDt As String = hfFrom.Value
    '        Dim toDt As String = hfTo.Value

    '        SELECT_LINE = Session("checkboxval")
    '        Select_Parameters = Session("checkLineChartParameters")
    '        Date_Field = Session("DateField")
    '        DatabaseName = Session("DBName")

    '        'Dim ds As DataSet = objdatahandler.GetDataSetFromQuery("SELECT   FORMAT([DATETIME],'dd-MM-yyyy HH:mm:ss')  As [DATETIME], " & Select_Parameters & "  FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL] where LINE =  '" & SELECT_LINE & "'  AND  [datetime] between '" & fromDt & "' and '" & toDt & "' and " & Select_Parameters & "  is not null ORDER BY DATETIME ASC")
    '        'Dim dt1 As DataTable = ds.Tables(0)

    '        'Dim dt1 As DataTable = objDataHandlerGcp.DataReading("SELECT   FORMAT_DATE('%F %T',DATE_TIME) As DATE_TIME, " & Select_Parameters & "  FROM `" & DatabaseName & "` where FCE_ID =  " & SELECT_LINE & "  AND  DATE_TIME between '2023-05-01 11:59:23' and '2023-07-07 11:59:23' and " & Select_Parameters & "  is not null ORDER BY DATE_TIME ASC")
    '        Dim dt1 As DataTable = objDataHandlerGcp.DataReading("SELECT   FORMAT_DATE('%F %T'," & Date_Field & ") As DATE_TIME, " & Select_Parameters & "  FROM `" & DatabaseName & "` where FCE_ID =  " & SELECT_LINE & "  AND  " & Date_Field & " between '" & fromDt & "' and '" & toDt & "' and " & Select_Parameters & "  is not null ORDER BY " & Date_Field & " ASC")

    '        Dim i As Integer = 1
    '        Using ep As New ExcelPackage()
    '            'For Each dt As DataTable In ds.Tables
    '            'Dim ws As ExcelWorksheet = ep.Workbook.Worksheets.Add("s" & i)
    '            Dim ws As ExcelWorksheet = ep.Workbook.Worksheets.Add("Download")
    '            ws.Cells("A1").LoadFromDataTable(dt1, True)

    '            'i += 1
    '            'Next
    '            Using ms As New MemoryStream
    '                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    '                Response.AddHeader("content-disposition", "attachment; filename=download.xlsx")
    '                ep.SaveAs(ms)
    '                ms.WriteTo(Response.OutputStream)
    '                Response.Flush()
    '                Response.End()
    '            End Using
    '        End Using



    '    Catch ex As Exception
    '        Throw New Exception(ex.ToString())
    '    End Try
    'End Sub

    'Private Sub lnkDownloadNew_Click(sender As Object, e As EventArgs) Handles lnkDownloadNew.Click
    '    Try
    '        Dim fromDt As String = hfFrom.Value
    '        Dim toDt As String = hfTo.Value

    '        SELECT_LINE = Session("checkboxval")
    '        Select_Parameters = Session("checkLineChartParameters")
    '        Date_Field = Session("DateField")
    '        DatabaseName = Session("DBName")

    '        'Dim ds As DataSet = objdatahandler.GetDataSetFromQuery("SELECT   FORMAT([DATETIME],'dd-MM-yyyy HH:mm:ss')  As [DATETIME], " & Select_Parameters & "  FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL] where LINE =  '" & SELECT_LINE & "'  AND  [datetime] between '" & fromDt & "' and '" & toDt & "' and " & Select_Parameters & "  is not null ORDER BY DATETIME ASC")
    '        'Dim dt1 As DataTable = ds.Tables(0)

    '        'Dim dt1 As DataTable = objDataHandlerGcp.DataReading("SELECT   FORMAT_DATE('%F %T',DATE_TIME) As DATE_TIME, " & Select_Parameters & "  FROM `" & DatabaseName & "` where FCE_ID =  " & SELECT_LINE & "  AND  DATE_TIME between '2023-05-01 11:59:23' and '2023-07-07 11:59:23' and " & Select_Parameters & "  is not null ORDER BY DATE_TIME ASC")
    '        Dim dt1 As DataTable = objDataHandlerGcp.DataReading("SELECT   FORMAT_DATE('%F %T'," & Date_Field & ") As DATE_TIME, " & Select_Parameters & "  FROM `" & DatabaseName & "` where FCE_ID =  " & SELECT_LINE & "  AND  " & Date_Field & " between '" & fromDt & "' and '" & toDt & "' and " & Select_Parameters & "  is not null ORDER BY " & Date_Field & " ASC")
    '        If dt1.Rows.Count > 0 Then
    '            Dim attachment As String = "attachment; filename=city.xls"
    '            Response.ClearContent()
    '            Response.AddHeader("content-disposition", attachment)
    '            Response.ContentType = "application/vnd.ms-excel"
    '            Dim tab As String = ""
    '            For Each dc As DataColumn In dt1.Columns
    '                Response.Write(tab & dc.ColumnName)
    '                tab = "\t"
    '            Next

    '            Response.Write("\n")
    '            Dim i As Integer
    '            For Each dr As DataRow In dt1.Rows
    '                tab = ""
    '                For i = 0 To dt1.Columns.Count - 1
    '                    Response.Write(tab & dr(i).ToString())
    '                    tab = "\t"
    '                Next
    '                Response.Write("\n")
    '            Next
    '            Response.End()
    '        Else
    '            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "showalert", "alert('Data Not Available between the Choosen Dates. Please Select a Different Date Range.');", True)
    '        End If

    '    Catch ex As Exception
    '        Throw New Exception(ex.ToString())
    '    End Try
    'End Sub
End Class
