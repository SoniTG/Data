﻿Imports System.Data
Imports System.IO
Imports System.Data.OleDb
Imports System.Data.SqlClient

Partial Class Live_Stroke
    Inherits System.Web.UI.Page

    Dim objController As New Controller_E_Main
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Dim dt As New DataTable
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
            Dim dtStart As String = DateTime.Now.AddDays(-15).ToString("yyyy-MM-dd HH:mm:ss")
            Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
           
            ' DrawChart()

            'End If
        End If
    End Sub
    Sub DrawChart()
        Dim strfrmDt As String = DateTime.Now.AddDays(-15).ToString("yyyy-MM-dd HH:mm:ss")
        Dim strToDt As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        Dim dtmfrmDt As DateTime = strfrmDt
        Dim dtmToDt As DateTime = strToDt

        Dim dt As DataTable = objController.GetDashboardData("CRM_CGL2_STROKETIME_DATA", "CCS_DATETIME", "CCSA_PARAM_VAL", dtmfrmDt, dtmToDt)

        If dt.Rows.Count > 0 Then
            objController.PlotLineChart(dt, "CCS_DATETIME", "CCSA_PARAM_VAL", Lit1, "container", "plot1", " ", "")
        Else
            Lit1.Text = ""
        End If

        Dim dt1 As DataTable = objController.GetDashboardData1("CRM_CGL2_STROKETIME_DATA", "CCS_DATETIME", "CCSA_PARAM_VAL", dtmfrmDt, dtmToDt)

        If dt1.Rows.Count > 0 Then
            objController.PlotLineChart(dt1, "CCS_DATETIME", "CCSA_PARAM_VAL", Lit2, "container1", "plot2", " ", "")
        Else
            Lit2.Text = ""
        End If

        Dim dt2 As DataTable = objController.GetDashboardData2("CRM_CGL2_STROKETIME_DATA", "CCS_DATETIME", "CCSA_PARAM_VAL", dtmfrmDt, dtmToDt)

        If dt2.Rows.Count > 0 Then
            objController.PlotLineChart(dt2, "CCS_DATETIME", "CCSA_PARAM_VAL", Lit3, "container2", "plot3", " ", "")
        Else
            Lit3.Text = ""
        End If

        Dim dt3 As DataTable = objController.GetDashboardData3("CRM_CGL2_STROKETIME_DATA", "CCS_DATETIME", "CCSA_PARAM_VAL", dtmfrmDt, dtmToDt)

        If dt3.Rows.Count > 0 Then
            objController.PlotLineChart(dt3, "CCS_DATETIME", "CCSA_PARAM_VAL", Lit4, "container3", "plot4", " ", "")
        Else
            Lit4.Text = ""
        End If

    End Sub

    Protected Sub Button4_Click(sender As Object, e As System.EventArgs) Handles Button4.Click
        DrawChart()
    End Sub

    Protected Sub Button1_Click(sender As Object, e As System.EventArgs) Handles Button1.Click

    End Sub
End Class
