﻿Imports System.Data
Partial Class MasterPageMain
    Inherits System.Web.UI.MasterPage
    Dim objController As New Controller
   Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxSuccessWithUrl(ByVal Message As String, ByVal Url As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalertandredirect('" + Message + "', '" + Url + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Try
                If Not Session("homeurl") Is Nothing Then
                    ahome.HRef = Session("homeurl")
                    objController.CreateMenuBarHierarchyDirect(Session("SubDivId"), litMenu)
                Else
                    objController.CreateMenuBarHierarchyDirect(Session("SubDivId"), litMenu)
                End If

            Catch ex As Exception
                'objController.LogIssue(Session("username"), ex.ToString(), System.IO.Path.GetFileName(Request.Path))
                'UserMsgBoxError("Error has been logged. Please contact solution provider.")
            End Try

        End If
        
    End Sub
  Protected Sub btnLogin_Click(sender As Object, e As System.EventArgs) Handles btnLogin.Click
        If txtUsername.Text.Trim() = "" Then
            UserMsgBoxWarning("Enter username.")
            txtUsername.Focus()
        ElseIf txtPassword.Text.Trim() = "" Then
            UserMsgBoxWarning("Enter password.")
            txtPassword.Focus()
        Else
            If objController.IsAValidUserForDpcr("dpcr", txtUsername.Text.Trim(), txtPassword.Text.Trim()) Then 
                Session("username") = txtUsername.Text.Trim()
                'Session("password") = New EncryptDecrypt.EncryptDecryptCls().EncryptWithMD5(txtPassword.Text.Trim())
                Session("password") = txtPassword.Text.Trim()

                txtUsername.Text = ""
                txtPassword.Text = ""
                Response.Redirect("dpcr_editcustomer.aspx")
            Else
                txtUsername.Text = ""
                txtPassword.Text = ""
                UserMsgBoxWarning("Incorrect login details.")

            End If
        End If
    End Sub

End Class

