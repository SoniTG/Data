﻿Imports System.Data
Partial Class MasterPageMain
    Inherits System.Web.UI.MasterPage
End Class