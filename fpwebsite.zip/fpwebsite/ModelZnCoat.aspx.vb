﻿Imports System.Data
Imports System.IO
Imports System.Data.OleDb
Imports Oracle.ManagedDataAccess.Client
Partial Class Default2
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim objDataHandler As New DataHandler
    Dim AK_DIST_start As Double
    'Dim OleAdap As New OleDbDataAdapter
    Dim OraAdap As New OracleDataAdapter
    Dim schdeule_set, spd_set As New DataSet
    Dim schdeule_table, spd_table As New DataTable
    'Dim OleCom As New OleDbCommand
    Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("ACPM_Ora_New").ConnectionString
    'Dim Oleconnection_ora As New OleDbConnection(strConnectionString)
    Dim OraCon As New OracleConnection(strConnectionString)
    Dim OraCmd As New OracleCommand
    Dim top_proportion, bot_proportion As Double
    Dim total_coat As Double = 0
    Dim coat_diff_high As Integer = 20

    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Page.IsPostBack Then
            Try

                Dim p As String = Request("__EVENTARGUMENT")
                If (p = "sl1_spd") Then
                    ReCalculate(p)
                ElseIf p = "sl1_pr" Then
                    ReCalculate(p)
                End If

            Catch ex As Exception

            End Try
        End If
        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                'set value of rangeslider

                hfslider1.Value = 50
                hfslider2.Value = 400
                hfslider3.Value = 70
                hfslider4.Value = 500
                hfslider5.Value = 150
                hfslider6.Value = 250



                Dim dt2 As DataTable = objDataHandler.GetDataSetFromQuery("SELECT top 1 DateTime FROM [FP_PROCESS_DATA].[dbo].[CRM_CGL2_IBA_data]  " &
             " where [botcoat]>10 and [Airknife_pr_fr_set] > 0 and [speed] > 0   order by DateTime desc").Tables(0)
                ' Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                Dim dtend_date As DateTime = dt2.Rows(0)(0)

                Dim dtEnd As String = dtend_date.ToString("yyyy-MM-dd HH:mm")
                Dim dtStart As String = dtend_date.AddHours(-2).ToString("yyyy-MM-dd HH:mm")                'DateTime.Now.AddDays(-7).ToString("yyyy-MM-dd HH:mm")

                hfFrom.Value = dtStart
                hfTo.Value = dtEnd
                '   Dim datefilter As String = " DateTime between  '2022-02-02 16:36:16' and '2022-02-02 17:11:52' "
                '   Dim dt2 As DataTable = objDataHandler.GetDataSetFromQuery("SELECT avg([botcoat]) as coat,avg([speed]) as spd ,avg([Airknife_pr_fr_set]) as Pr " &
                '" FROM ( SELECT top 60 [botcoat], [speed], [Airknife_pr_fr_set]  FROM [FP_PROCESS_DATA].[dbo].[CRM_CGL2_IBA_data]  " &
                '" where [botcoat]>0 and [Airknife_pr_fr_set] > 0 and [speed] > 0 and " & datefilter & "  order by DateTime desc) T").Tables(0)

                '   ''Dim dt2 As datatable = objDataHandler.getdatasetfromquery("SELECT top 60 avg([botcoat]) as coat,avg([speed]) as spd     ,avg([Airknife_pr_fr_set]) as Pr FROM [FP_PROCESS_DATA].[dbo].[CRM_CGL2_IBA_data]  where [botcoat]>0 and [Airknife_pr_fr_set] > 0 and [speed] > 0").tables(0)
                '   Calculate(dt2)
                '   'Dim dt1 As DataTable = objDataHandler.GetDataSetFromQuery("SELECT top 1000 DateTime,[botcoat],[Airknife_pr_fr_set] as Airknife_Pr_Fr_Set,[speed] as Speed,([AKFR_OS_dist]+[AKFR_DS_dist]) as AK_Dist  FROM [FP_PROCESS_DATA].[dbo].[CRM_CGL2_IBA_data] where [botcoat]>0 and [Airknife_pr_fr_set] > 0 and [speed] > 0  order by [Datetime] desc").Tables(0)
                '   Dim dt1 As DataTable = objDataHandler.GetDataSetFromQuery("SELECT top 1000 DateTime,Length_prced_SPM as length,[botcoat],[Airknife_pr_fr_set] as Airknife_Pr_Fr_Set,[speed] as Speed,([AKFR_OS_dist]+[AKFR_DS_dist]) as AK_Dist " &
                '                                                             ", 0.000217653 * power(cast([Airknife_pr_fr_set] as float), -0.420641) * power(cast([speed] as float), 0.318106) * power(cast( " & AK_DIST_start & " as float), 4.80165) as Pred_Coat" &
                '                                                             " FROM [FP_PROCESS_DATA].[dbo].[CRM_CGL2_IBA_data] where" & datefilter & " order by [Datetime] ").Tables(0)

                '-------------------------Bottom coating-------------------------------------
                '----------------------------------------------------------------------------
                curr_datetime_lbl.Text = "Last updated: " & dtEnd
                FetchDataAndChartPlot(dtStart, dtEnd)
                calculate_scheduled_coil(dtStart, dtEnd)
            Catch ex As Exception
                ex.ToString()
            End Try

        End If

    End Sub

    Function cal_pressure(coat As Double, spd As Double, dist As Double) As Double
        Dim constant, Pr_fr_const, speed_const, dist_fr_const As Double
        Dim pressure As Double
        Pr_fr_const = -0.420641
        speed_const = 0.318106
        constant = 0.000217653
        dist_fr_const = 4.80165
        pressure = Math.Round(Math.Pow((coat) / (constant * Math.Pow(spd, speed_const) * Math.Pow(dist, dist_fr_const)), 1 / Pr_fr_const), 0)
        Return pressure
    End Function
    Protected Sub btnOk_Click(sender As Object, e As EventArgs) Handles btnOk.Click
        Dim ak_distance, coat, spd, pressure As Double
        If lblPreddist_1.Text = "Change not required" Then
            ak_distance = currset_AKDIST.Text
        Else
            ak_distance = modify_pr_txt1.Text
        End If

        spd = Convert.ToDouble(updated_spd1_txt.Text)
        coat = Convert.ToDouble(lblaimcoat_1.Text) / 2
        pressure = cal_pressure(coat, spd, ak_distance)
        If spd > 150 Or spd < 20 Then
            updated_pr1_txt.Text = "--Error--"
        Else
            updated_pr1_txt.Text = Math.Round(pressure, 0)
        End If
    End Sub
    Protected Sub btnOk1_Click(sender As Object, e As EventArgs) Handles btnOk1.Click

        Dim ak_distance, coat, spd, pressure As Double
        If lblPreddist_2.Text = "Change not required" Then
            ak_distance = currset_AKDIST.Text
        Else
            ak_distance = modify_pr_txt2.Text
        End If
        ak_distance = currset_AKDIST.Text
        spd = Convert.ToDouble(updated_spd2_txt.Text)
        coat = Convert.ToDouble(lblaimcoat_2.Text) / 2
        pressure = cal_pressure(coat, spd, ak_distance)
        If spd > 150 Or spd < 20 Then
            updated_pr2_txt.Text = "--Error--"
        Else
            updated_pr2_txt.Text = Math.Round(pressure, 0)
        End If

    End Sub
    Public Function calculate_scheduled_coil(ByVal dtStart As String, ByVal dtEnd As String)

        '--------------------sql part---taking current processed data from IBA/SQL DB and calculate AK distance
        Dim Pr_fr, dist_fr, speed, constant, ak_distance, coat_std As Double
        Dim Pr_fr_const, speed_const, dist_fr_const As Double
        Pr_fr_const = -0.420641
        speed_const = 0.318106
        constant = 0.000217653
        dist_fr_const = 4.80165
        Dim dt2 As DataTable = objDataHandler.GetDataSetFromQuery("SELECT avg([Topcoat]) as coat,avg([speed]) as spd ,avg([Airknife_pr_rr_set]) as Pr " &
             " FROM ( SELECT top 50 [Topcoat], [speed], [Airknife_pr_rr_set]  FROM [FP_PROCESS_DATA].[dbo].[CRM_CGL2_IBA_data]  " &
             " where [Topcoat]>10 and [Airknife_pr_fr_set] > 0 and [speed] > 0 and  DateTime between  '" & dtStart & "' and '" & dtEnd & "'    order by DateTime desc) T").Tables(0)
        ak_distance = Calculate(dt2, constant, Pr_fr_const, speed_const, dist_fr_const)
        speed = dt2.Rows(0)("spd")
        coat_std = dt2.Rows(0)("coat")

        Dim no_of_sched_coil As Integer = 3
        Dim coil_cnt As Integer = 0
        Dim start_coil As Integer = 0
        Dim coil_id_ora(no_of_sched_coil), cd_coat_ora(no_of_sched_coil), coil_tdc(no_of_sched_coil), coil_thick(no_of_sched_coil), coil_width(no_of_sched_coil), coil_grade(no_of_sched_coil) As String
        Dim coat_amt_ora(no_of_sched_coil), Pr_pred_future(no_of_sched_coil), pred_spd, coil_spd(no_of_sched_coil) As Double

        '----------------------------line speed factor---------------------
        Dim spd_qry As String = "select * from(select cgd_id_coil as id_coil, to_char(cgd_ts_end,'YYYY-MM-DD HH24:MI:SS') as ts_end,cgd_cd_grade, cgd_sec1_coil as thickness, cgd_width as width,cgd_tas_prc_scspd as linespd from crmcg2.t_cg2_daughter_rpt order by ts_end desc) where rownum < 10"
        Ora_selectquery(spd_qry)
        OraAdap.Fill(spd_set)
        spd_table = spd_set.Tables(0)
        pred_spd = line_speed_predict(spd_table.Rows(0)("cgd_cd_grade"), spd_table.Rows(0)("width") / 1000, spd_table.Rows(0)("thickness") / 1000)
        Dim spd_factor = speed / pred_spd
        '------------oracle part--to find pressure for the next few coils based on the input from above

        Dim OraQuery As String

        schdeule_set.Clear()
        schdeule_table.Clear()
        OraQuery = "select * from (select pdl_id_coil,pdl_cd_status,pdl_no_seq,trunc(pdl_sec1_coil,2) as pdl_sec1_coil ,trunc(pdl_sec2_coil,0) as pdl_sec2_coil ,pdl_ln_coil,pdl_grd_steel,pdl_cd_prod,pdl_cd_coat,pdl_id_schedule,PDL_PROC_SPEED,PDL_TP_COAT_AMT,PDL_BT_COAT_AMT, pdl_tdc_no  from v_pr_data_ip_cg2 " &
            "where(pdl_cd_status = 'UP' or pdl_cd_status = 'WW' or  pdl_cd_status = 'WC' or  pdl_cd_status = 'WS') and pdl_ts_creation > to_char(to_date(sysdate-2,'DD-MM-YYYY HH24:MI:SS')) order by pdl_id_pdi  asc) T1 where rownum<=20 order by rownum"

        Ora_selectquery(OraQuery)
        OraAdap.Fill(schdeule_set)
        schdeule_table = schdeule_set.Tables(0)


        If schdeule_table.Rows.Count = 0 Then
            Exit Function
        End If
        For i = start_coil To schdeule_table.Rows.Count - 1
            coil_id_ora(i) = schdeule_table.Rows(i)("pdl_id_coil")
            coat_amt_ora(i) = schdeule_table.Rows(i)("PDL_TP_COAT_AMT")
            cd_coat_ora(i) = schdeule_table.Rows(i)("pdl_cd_coat")
            coil_tdc(i) = schdeule_table.Rows(i)("pdl_tdc_no")
            coil_thick(i) = schdeule_table.Rows(i)("pdl_sec1_coil")
            coil_width(i) = schdeule_table.Rows(i)("pdl_sec2_coil")
            coil_grade(i) = schdeule_table.Rows(i)("pdl_grd_steel")

            '*********************************************

            pred_spd = line_speed_predict(coil_grade(i), coil_width(i) / 1000, coil_thick(i) / 1000) * spd_factor
            'max line speed is 150... if pred comes > 150 due to speed factor, then speed factor is not included for those cases.
            If pred_spd > 150 Then
                pred_spd = line_speed_predict(coil_grade(i), coil_width(i) / 1000, coil_thick(i) / 1000)
            End If
            coil_spd(i) = pred_spd
            'the current coil (0th) to be shown with the current speed as it cannot be suggested to comprimise production
            If i = start_coil Then
                coil_spd(i) = Convert.ToDouble(currset_spd.Text)
            End If

            '*********************************************

            Pr_pred_future(i) = Math.Pow((coat_amt_ora(i)) / (constant * Math.Pow(coil_spd(i), speed_const) * Math.Pow(ak_distance, dist_fr_const)), 1 / Pr_fr_const)
            'the current coil (0th) to be shown with the current speed as it cannot be suggested to comprimise production
            If i > start_coil Then
                'Pr_pred_future(i) = check_pr_value(Pr_pred_future(i), coat_amt_ora(i - 1), coat_amt_ora(i), i)
                Pr_pred_future(i) = check_pr_value_prbased(Pr_pred_future(i), i, coil_spd(i), coat_amt_ora(i))
            End If

            '*********************************************

            'pressure = Math.Pow(Convert.ToDouble(coil1_thick_txt.Text) / (0.000217653 * Math.Pow(speed, 0.318106) * Math.Pow(ak_distance, 4.80165)), 1 / -0.420641)
            'If ak_distance < 16.3 Then
            '    pressure = Math.Pow((coil1_thick_txt.Text - 7) / (0.0000000000158 * Math.Pow(speed, 0.3718433) * Math.Pow(ak_distance, 10.1752)), 1 / -0.2547844)
            'End If
            coil_cnt = coil_cnt + 1
            If coil_cnt = no_of_sched_coil Then Exit For
        Next i

        '--------------------coil id     tdc      q code-----------------------'
        lblCoil_0.Text = coil_id_ora(0) & "  :  " & coil_tdc(0) & "  :  " & cd_coat_ora(0)
        lblCoil_1.Text = coil_id_ora(1) & "  :  " & coil_tdc(1) & "  :  " & cd_coat_ora(1)
        lblCoil_2.Text = coil_id_ora(2) & "  :  " & coil_tdc(2) & "  :  " & cd_coat_ora(2)

        '--------------------thickness and width -----------------------'
        lblgwt1.Text = coil_thick(0) & "  /  " & coil_width(0)
        lblgwt2.Text = coil_thick(1) & "  /  " & coil_width(1)
        lblgwt3.Text = coil_thick(2) & "  /  " & coil_width(2)

        '------------------- speed    -----------------------'
        lblspd1.Text = "Actual:" & currset_spd.Text  'Math.Round(coil_spd(0), 0)
        lblspd2.Text = Math.Round(coil_spd(1), 0)
        lblspd3.Text = Math.Round(coil_spd(2), 0)

        '------------------- coating     aim and targt   -----------------------'
        lblaimcoat_0.Text = "Target: " & Math.Round(coat_amt_ora(0), 0) * 2
        lblaimcoat_0_1.Text = "Actual: " & Math.Round(Convert.ToDouble(currset_coat_tot.Text), 0)
        lblaimcoat_1.Text = Math.Round(coat_amt_ora(1), 0) * 2
        lblaimcoat_2.Text = Math.Round(coat_amt_ora(2), 0) * 2

        '---------------Simulator  --- initilize  ----- text for for fixing coating weight in the calculator --'
        coil1_thick_txt.Text = Math.Round(coat_amt_ora(0), 0)

        '------------------- pressure     aim and targt   -----------------------'
        '---------------this is for the prediction of pressure for the current coil---------------------'
        If cd_coat_ora(0) = "Z60" Or Pr_pred_future(0) > 600 Then
            lblPredFuture_0.Text = "Target: 600 *"
            lblPredFuture_0_1.Text = "Actual: " & currset_pres.Text
            hfslider2.Value = 600
            hfAK.Value = 600
        Else
            lblPredFuture_0.Text = "Target: " & Math.Round(Pr_pred_future(0), 0) & " *"
            lblPredFuture_0_1.Text = "Actual: " & currset_pres.Text
            hfslider2.Value = Math.Round(Pr_pred_future(0), 0)
            hfAK.Value = Math.Round(Pr_pred_future(0), 0)
        End If
        '---------------this is for the prediction of pressure for the next coil---------------------'
        If cd_coat_ora(1) = "Z60" Or Pr_pred_future(1) > 600 Then
            lblPredFuture_1.Text = "Target: 600 *"
            'hfslider2.Value = 600
        Else
            lblPredFuture_1.Text = "Target: " & Math.Round(Pr_pred_future(1), 0) & " *"
            'hfslider2.Value = Math.Round(Pr_pred_future(0), 0)
        End If
        '---------------this is for the prediction of pressure for the nextto next  coil---------------------'
        If cd_coat_ora(2) = "Z60" Or Pr_pred_future(2) > 600 Then
            lblPredFuture_2.Text = "Target: 600 *"
            hfslider2.Value = 600
        Else
            lblPredFuture_2.Text = "Target: " & Math.Round(Pr_pred_future(2), 0) & " *"
            ' hfslider2.Value = Math.Round(Pr_pred_future(0), 0)
        End If

        '-----------------------------------------------------------------------------------------


        Pr_fr = Math.Pow(coat_std / (constant * Math.Pow(speed, speed_const) * Math.Pow(ak_distance, dist_fr_const)), 1 / Pr_fr_const)

        ' & 
        'AK_DIST_SIMULATE_TXT.Text = "" ' Math.Round(ak_distance, 2)
        hfslider3.Value = Math.Round(ak_distance, 2)
        If hfslider3.Value < 15 Or hfslider3.Value > 23 Then
            UserMsgBoxError("Air knife gap not in range")
        End If

        'If AK_DIST_SIMULATE_TXT.Text < 15 Or AK_DIST_SIMULATE_TXT.Text > 23 Then
        '    UserMsgBoxError("Air knife gap not in range")
        'End If


        hfslider1.Value = Math.Round(coil_spd(0), 0)
        'PR_PRED.Text = " @" & Math.Round(speed, 0) & " m/min for " & cd_coat_ora(0) & ""

        If (total_coat) > Math.Round(coat_amt_ora(0), 0) * 2 Or total_coat <= Convert.ToDouble(Mid(cd_coat_ora(0), 2, 3)) Then
            currset_coat_tot.ForeColor = Drawing.Color.Red
        Else
            currset_coat_tot.ForeColor = Drawing.Color.Green
        End If

        Return 0

    End Function

    Function check_pr_value_prbased(ByRef pred_pres As Double, ByVal idx As Integer, ByVal spd As Double, ByVal coat As Double) As Double
        '**********if the difference between the current and next coating is higher by x value, then distance needs to be changed.
        'spd = 120
        'coat = 139.5
        'pred_pres = 600
        If (pred_pres) > 580 Then

            If idx = 1 Then
                lblPreddist_1.Text = "decrease dist"
                find_optimal_dist(idx, "decrease dist", spd, coat, pred_pres)
            End If
            If idx = 2 Then
                lblPreddist_2.Text = "decrease dist"
                find_optimal_dist(idx, "decrease dist", spd, coat, pred_pres)
            End If

            'increase AK distance
        ElseIf (pred_pres) < 150 Then
            If idx = 1 Then
                lblPreddist_1.Text = "increase dist"
                find_optimal_dist(idx, "increase dist", spd, coat, pred_pres)
            End If
            If idx = 2 Then
                lblPreddist_2.Text = "increase dist"
                find_optimal_dist(idx, "increase dist", spd, coat, pred_pres)
            End If
            'decrease AK distance
        Else
            'No change in distance
            If idx = 1 Then
                lblPreddist_1.Text = "Change not required"
            End If
            If idx = 2 Then
                lblPreddist_2.Text = "Change not required"
            End If
        End If


        Return pred_pres
    End Function

    Sub find_optimal_dist(ByVal idx As Integer, ByVal pr_change_direction As String, ByVal spd As Double, ByVal coat As Double, ByVal pred_pres As Double)
        Dim constant, ak_distance, pr, temp_dist As Double
        Dim Pr_fr_const, speed_const, dist_fr_const As Double
        Pr_fr_const = -0.420641
        speed_const = 0.318106
        constant = 0.000217653
        dist_fr_const = 4.80165
        ak_distance = currset_AKDIST.Text
        temp_dist = ak_distance
        pr = pred_pres


        Dim dt_pr As DataTable = objDataHandler.GetDataSetFromQuery("SELECT avg([Airknife_pr_rr_set]) as Pr " &
             " FROM [FP_PROCESS_DATA].[dbo].[CRM_CGL2_IBA_data]  " &
             " where [Topcoat] between " & coat - 10 & " and " & coat + 10 & " and [speed]  between " & spd - 3 & " and " & spd + 3 & "  and [speed] > 30   " &
             "").Tables(0)

        pr = dt_pr.Rows(0)("pr")
        Dim modify_dist As Double = Math.Pow(coat / (constant * Math.Pow(pr, Pr_fr_const) * Math.Pow(spd, speed_const)), 1 / dist_fr_const)

        If idx = 1 Then
            modify_pr_txt1.Text = Math.Round((ak_distance - modify_dist) / ak_distance * 100, 1)  'Math.Round(modify_dist, 2)
        End If
        If idx = 2 Then
            modify_pr_txt2.Text = Math.Round((ak_distance - modify_dist) / ak_distance * 100, 1)  ' Math.Round(modify_dist, 2)
        End If

    End Sub
    Function check_pr_value(ByRef pred_pres As Double, ByVal prev_coat As Double, ByVal next_coat As Double, ByVal idx As Integer) As Double
        '**********if the difference between the current and next coating is higher by x value, then distance needs to be changed.

        If (next_coat - prev_coat) > coat_diff_high Then
            If idx = 1 Then
                lblPreddist_1.Text = "increase dist"
            End If
            If idx = 2 Then
                lblPreddist_2.Text = "increase dist"
            End If
            'increase AK distance
        ElseIf (next_coat - prev_coat) < (-1 * coat_diff_high) Then
            If idx = 1 Then
                lblPreddist_1.Text = "decrease dist"
            End If
            If idx = 2 Then
                lblPreddist_2.Text = "decrease dist"
            End If
            'decrease AK distance
        Else
            'No change in distance
            If idx = 1 Then
                lblPreddist_1.Text = "Change Not required"
            End If
            If idx = 2 Then
                lblPreddist_2.Text = "Change Not required"
            End If
        End If
        Return pred_pres
    End Function

    Function line_speed_predict(lsp_grade As String, lsp_width As Double, lsp_thickness As Double)
        Dim temperature As Integer
        Dim tph_furn, lsd, max_tph, line_speed_pred, LS1 As Double
        If lsp_grade = "CQ" Then
            temperature = 730
        End If
        If lsp_grade = "DQ" Then
            temperature = 730
        End If
        If lsp_grade = "DDQ" Then
            temperature = 800
        End If
        If lsp_grade = "EIF" Then
            temperature = 830
        End If
        If lsp_grade = "HIF" Then
            temperature = 830
        End If
        If lsp_grade = "GA" Then
            temperature = 850
        End If

        'throughput allowable by furnace
        tph_furn = 84.65387 + 32.90893 * Math.Cos(temperature * 0.0089967 + 1.6110504)   'cos to be taken in degree. radian conversion is not required
        'line speed allowable
        lsd = tph_furn * 1.51
        'max allowable thru
        max_tph = lsp_width * lsp_thickness * 60 * 150 * 7850 / 1000

        If max_tph >= tph_furn Then

            LS1 = tph_furn * 1000 / (7850 * 60 * lsp_width * lsp_thickness)
            If (LS1 * (lsp_thickness * 1000)) > lsd Then
                line_speed_pred = lsd / (lsp_thickness * 1000)
            Else
                line_speed_pred = LS1
            End If
        Else
            If (lsd / (lsp_thickness * 1000)) > 150 Then
                line_speed_pred = 150
            Else
                line_speed_pred = lsd / (lsp_thickness * 1000)
            End If
        End If
        Return (line_speed_pred)

    End Function
    Public Function Ora_selectquery(ByVal strselect As String) As OracleDataAdapter
        Try

            OraCmd.Connection = OraCon

            OraCmd.CommandText = strselect
            OraAdap.SelectCommand = OraCmd

            Return OraAdap

        Catch ex As Exception

        End Try
    End Function
    Sub FetchDataAndChartPlot(ByVal dtStart As String, ByVal dtEnd As String)

        Dim top_coat As Double = 0
        Dim bottom_coat As Double = 0
        Dim dt2 As DataTable = objDataHandler.GetDataSetFromQuery("Select avg([botcoat]) As coat,avg([speed]) As spd ,avg([Airknife_pr_fr_set]) As Pr " &
             " FROM ( Select top 50 [botcoat], [speed], [Airknife_pr_fr_set]  FROM [FP_PROCESS_DATA].[dbo].[CRM_CGL2_IBA_data]  " &
             " where [botcoat]>10 And [Airknife_pr_fr_set] > 0 And [speed] > 0 And  DateTime between  '" & dtStart & "' and '" & dtEnd & "'    order by DateTime desc) T").Tables(0)
        Dim Pr_fr, dist_fr, speed, constant, AK_DIST_start1, AK_DIST_start2 As Double
        Pr_fr = -0.420641
        speed = 0.318106
        constant = 0.000217653
        dist_fr = 4.80165
        AK_DIST_start1 = Calculate(dt2, constant, Pr_fr, speed, dist_fr)
        total_coat = dt2.Rows(0)("coat")
        bottom_coat = dt2.Rows(0)("coat")
        Pr_fr = -0.720641
        speed = 0.618106
        constant = 0.000217653
        dist_fr = 4.90165
        AK_DIST_start2 = Calculate(dt2, constant, Pr_fr, speed, dist_fr)
        '= ROUND(0.000217653 * POWER(E2, -0.720641) * POWER(D2, 0.618106) * POWER(16.65, 4.90165), 2)
        'Dim dt1 As DataTable = objDataHandler.GetDataSetFromQuery("SELECT top 1000 DateTime,Length_prced_SPM as length,[botcoat],[Airknife_pr_fr_set] as Pressure_Fr_Set,[speed] as Speed,([AKFR_OS_dist]+[AKFR_DS_dist]) as Distance_Fr " &
        '                                                         ", 0.000217653 * power(cast([Airknife_pr_fr_set] as float), -0.420641) * power(cast([speed] as float), 0.318106) * power(cast( " & AK_DIST_start1 & " as float), 4.80165) as Pred_Coat" &
        '                                                          ", 0.000217653 * power(cast([Airknife_pr_fr_set] as float), -0.720641) * power(cast([speed] as float), 0.618106) * power(cast( " & AK_DIST_start2 & " as float), 4.90165) as Pred_Coat1" &
        '                                                         " FROM [FP_PROCESS_DATA].[dbo].[CRM_CGL2_IBA_data] order by [Datetime] desc").Tables(0)
        Dim dt1 As DataTable = objDataHandler.GetDataSetFromQuery(" With cte As (SELECT  [Datetime] ,[Length_prced_SPM], " &
                                    " Length_prced_SPM - lag(length_prced_spm) over(order by datetime desc) As c1 From [FP_PROCESS_DATA].[dbo].[CRM_CGL2_IBA_data]) " &
                                    " Select  [DateTime], Length_prced_SPM As length, [botcoat], [Airknife_pr_fr_set] As Pressure_Fr_Set, [speed] As Speed, ([AKFR_OS_dist]+[AKFR_DS_dist]) As Distance_Fr,  " &
                                    "         0.000217653 * power(cast([Airknife_pr_fr_set] as float), -0.420641) * power(cast([speed] as float), 0.318106) * power(cast( " & AK_DIST_start1 & " as float), 4.80165) as Pred_Coat " &
                                    "        ,   avg([botcoat]) OVER(ORDER BY [Datetime]  ROWS BETWEEN 50 PRECEDING AND CURRENT ROW ) as MOV_AVG " &
                                    "          from  [FP_PROCESS_DATA].[dbo].[CRM_CGL2_IBA_data] where  [DateTime] between  '" & dtStart & "' and '" & dtEnd & "' and  Length_prced_SPM > 0 and  [Airknife_pr_fr_set] > 0 and  [speed] > 0  order by [Datetime] ").Tables(0)
        '              "       , 0.000217653 * power(cast([Airknife_pr_fr_set] as float), -0.720641) * power(cast([speed] as float), 0.618106) * power(cast( " & AK_DIST_start2 & " as float), 4.90165) as Pred_Coat1 " &





        'For i As Integer = 0 To dt1.Rows.Count - 11
        '    ' [DateTime], Length_prced_SPM As length, [botcoat], [Airknife_pr_fr_set] As Pressure_Fr_Set, [speed] As Speed, ([AKFR_OS_dist]+[AKFR_DS_dist]) As Distance_Fr
        '    If Math.Abs(dt1.Rows(i)("Distance_Fr") - dt1.Rows(i + 1)("Distance_Fr")) < 0.02 Then

        '    End If
        'Next i
        PlotLineEChart1(dt1, "DateTime", "Speed", "Distance_Fr", "Pressure_Fr_Set", Lit1, "chart1", "plot1")
        PlotLineEChart2(dt1, "DateTime", "Pred_Coat", "MOV_AVG", "botcoat", Lit2, "chart2", "plot2")


        '-------------------------Top coating-------------------------------------
        '----------------------------------------------------------------------------
        dt1.Clear()
        dt2.Clear()

        dt2 = objDataHandler.GetDataSetFromQuery("Select avg([Topcoat]) As coat, avg([speed]) As spd, avg([Airknife_pr_rr_set]) As Pr " &
             " FROM ( Select top 50 [Topcoat], [speed], [Airknife_pr_rr_set]  FROM [FP_PROCESS_DATA].[dbo].[CRM_CGL2_IBA_data]  " &
             " where [Topcoat]>10 And [Airknife_pr_rr_set] > 0 And [speed] > 0 and  DateTime between  '" & dtStart & "' and '" & dtEnd & "'    order by DateTime desc) T").Tables(0)
        Pr_fr = -0.420641
        speed = 0.318106
        constant = 0.000217653
        dist_fr = 4.80165
        AK_DIST_start1 = Calculate(dt2, constant, Pr_fr, speed, dist_fr)

        'Pr_fr = -0.720641
        'speed = 0.618106
        'constant = 0.000217653
        'dist_fr = 4.90165
        'AK_DIST_start2 = Calculate(dt2, constant, Pr_fr, speed, dist_fr)

        'dt1 = objDataHandler.GetDataSetFromQuery("Select top 1000 DateTime,Length_prced_SPM As length,[Topcoat],[Airknife_pr_rr_set] As Pressure_Set,[speed] As Speed,([AKRR_OS_dist]+[AKRR_DS_dist]) As Distance " &
        '                                                         ", 0.000217653 * power(cast([Airknife_pr_rr_set] As float), -0.420641) * power(cast([speed] As float), 0.318106) * power(cast( " & AK_DIST_start1 & " As float), 4.80165) As Pred_Coat" &
        '                                                          ", 0.000217653 * power(cast([Airknife_pr_rr_set] As float), -0.720641) * power(cast([speed] As float), 0.618106) * power(cast( " & AK_DIST_start2 & " As float), 4.90165) As Pred_Coat1" &
        '                                                         " FROM [FP_PROCESS_DATA].[dbo].[CRM_CGL2_IBA_data] order by [Datetime] desc").Tables(0)
        dt1 = objDataHandler.GetDataSetFromQuery(" With cte As (SELECT  [Datetime] ,[Length_prced_SPM], " &
                                    " Length_prced_SPM - lag(length_prced_spm) over(order by datetime desc) As c1 From [FP_PROCESS_DATA].[dbo].[CRM_CGL2_IBA_data]) " &
                                    " Select  [DateTime], Length_prced_SPM As length, [Topcoat], [Airknife_pr_rr_set] As Pressure_Set, [speed] As Speed, ([AKRR_OS_dist] + [AKRR_DS_dist]) As Distance,  " &
                                    "         0.000217653 * power(cast([Airknife_pr_rr_set] as float), -0.420641) * power(cast([speed] as float), 0.318106) * power(cast( " & AK_DIST_start1 & " As float), 4.80165) as Pred_Coat " &
                                    "        ,   avg([Topcoat]) OVER(ORDER BY [Datetime]  ROWS BETWEEN 50 PRECEDING AND CURRENT ROW ) as MOV_AVG " &
                                    "          from  [FP_PROCESS_DATA].[dbo].[CRM_CGL2_IBA_data] where  [DateTime]  between  '" & dtStart & "' and '" & dtEnd & "' and  Length_prced_SPM > 0 and  [Airknife_pr_fr_set] > 0 and  [speed] > 0  order by [Datetime] ").Tables(0)
        '       "       , 0.000217653 * power(cast([Airknife_pr_rr_set] as float), -0.720641) * power(cast([speed] as float), 0.618106) * power(cast( " & AK_DIST_start2 & " As float), 4.90165) as Pred_Coat1 " &
        PlotLineEChart1(dt1, "DateTime", "Speed", "Distance", "Pressure_Set", Lit4, "chart4", "plot4")
        PlotLineEChart2(dt1, "DateTime", "Pred_Coat", "MOV_AVG", "Topcoat", Lit5, "chart5", "plot5")
        'PlotLineEChart(dt1, "DateTime", "Speed", "Pressure_Fr_Set", Lit4, "chart4", "plot4")
        'PlotLineEChart1(dt1, "DateTime", "botcoat", "Pred_Coat", "AK_Dist", Lit5, "chart5", "plot5")

        top_coat = dt2.Rows(0)("coat")
        top_proportion = top_coat / (top_coat + bottom_coat)
        bot_proportion = bottom_coat / (top_coat + bottom_coat)
        currset_coat_top.Text = Math.Round(top_coat, 1)
        currset_coat_bot.Text = Math.Round(bottom_coat, 1)
        currset_spd.Text = Math.Round(dt2.Rows(0)("spd"), 0)
        currset_pres.Text = Math.Round(dt2.Rows(0)("pr"), 0)
        currset_AKDIST.Text = Math.Round(AK_DIST_start1, 1)
        currset_coat_tot.Text = top_coat + bottom_coat
        total_coat = top_coat + bottom_coat

    End Sub

    Public Sub PlotLineEChart(ByVal dt As DataTable, ByVal xcol As String, ByVal ycol1 As String, ByVal ycol2 As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String)
        ' Try

        LiteralName.Text = ""

        Dim dv As DataView = dt.DefaultView
        dv.Sort = "DateTime"

        dt = dv.ToTable

        Dim data As String = Nothing
        Dim data1 As String = Nothing
        Dim date_val As String = Nothing
        For I As Integer = 0 To dt.Rows.Count - 1
            data &= dt.Rows(I)(ycol1) & ","
            data1 &= dt.Rows(I)(ycol2) & ","
            date_val &= "'" & CDate(dt.Rows(I)(xcol)).ToString("yyyy-MM-dd HH:mm:ss") & "',"
        Next

        'Dim ymax1, ymin1, ymax2, ymin2 As Double
        Dim ymin1 As Double = dt.Compute("min(" & ycol1 & ")", "")
        Dim ymax1 As Double = dt.Compute("max(" & ycol1 & ")", "")
        Dim ymin2 As Double = dt.Compute("min(" & ycol2 & ")", "")
        Dim ymax2 As Double = dt.Compute("max(" & ycol2 & ")", "")

        ymin1 = Math.Floor(ymin1 - (ymin1 * 0.1))
        ymax1 = Math.Floor(ymax1 + (ymax1 * 0.1))
        ymin2 = Math.Floor(ymin2 - (ymin2 * 0.05))
        ymax2 = Math.Floor(ymax2 + (ymax2 * 0.05))


        '' dv.Item(0)("lenseverity")
        Dim s As New StringBuilder("<script>")


        s.Append(" var myChart = echarts.init(document.getElementById('" & ContainerName & "'));")

        s.Append("option = {")
        s.Append("title: {")
        s.Append("text: ''")
        s.Append("},")
        s.Append("tooltip: {")
        s.Append("trigger: 'axis'")
        s.Append("},")
        s.Append(" legend: {left:'center',data:['" & ycol1 & "','" & ycol2 & "']},")
        's.Append(" legend: {left: 10,data:['s1','s2']},")
        s.Append("xAxis: {")
        s.Append("data: [" & date_val & "]")
        s.Append("},")
        s.Append("yAxis: [{name:'" & ycol1 & "',min:" & ymin1 & ",max:" & ymax1 & ",splitNumber:5,")
        s.Append("splitLine: {")
        s.Append("show: false")
        s.Append("}")
        s.Append("},{name: '" & ycol2 & "',min:" & ymin2 & ",max:" & ymax2 & ",splitNumber:5, splitLine:  {show: false}}],")
        s.Append("toolbox: {")
        s.Append("left: 'right',")
        s.Append("feature: {")
        s.Append("dataZoom: {")
        s.Append("yAxisIndex: 'none'")
        s.Append("},")
        s.Append("restore: {},")
        s.Append("saveAsImage: {}")
        s.Append("}")
        s.Append("},")

        s.Append("series: [")
        s.Append("{name:'" & ycol1 & "',")
        s.Append("type: 'line',")
        s.Append("data: [" & data & "]")
        's.Append(", lineStyle: {color:  'green'}")
        s.Append("},")
        s.Append("{name:'" & ycol2 & "',")
        s.Append("type: 'line', yAxisIndex: 1,")
        s.Append("data: [" & data1 & "]")
        s.Append("},")

        s.Append("]")
        s.Append("};")

        s.Append(" myChart.setOption(option);")
        s.Append("</script>")
        LiteralName.Text = s.ToString()


        'Catch ex As Exception

        'End Try
    End Sub

    Public Sub PlotLineEChart1(ByVal dt As DataTable, ByVal xcol As String, ByVal ycol1 As String, ByVal ycol2 As String, ByVal ycol3 As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String)
        ' Try

        LiteralName.Text = ""

        Dim dv As DataView = dt.DefaultView
        dv.Sort = "DateTime"

        dt = dv.ToTable
        Dim len As Double = dt.Rows(0)("length")
        Dim data As String = Nothing
        Dim data1 As String = Nothing
        Dim data3 As String = Nothing
        Dim date_val As String = Nothing
        For I As Integer = 50 To dt.Rows.Count - 50
            data &= dt.Rows(I)(ycol1) & ","

            data1 &= dt.Rows(I)(ycol2) & ","

            data3 &= dt.Rows(I)(ycol3) & ","
            date_val &= "'" & CDate(dt.Rows(I)(xcol)).ToString("yyyy-MM-dd HH:mm:ss") & "',"
        Next

        'Dim ymax1, ymin1, ymax2, ymin2 As Double
        Dim ymin1 As Double = dt.Compute("min(" & ycol1 & ")", "")
        Dim ymax1 As Double = dt.Compute("max(" & ycol1 & ")", "")
        Dim ymin2 As Double = dt.Compute("min(" & ycol2 & ")", "")
        Dim ymax2 As Double = dt.Compute("max(" & ycol2 & ")", "")
        Dim ymin3 As Double = dt.Compute("min(" & ycol3 & ")", "")
        Dim ymax3 As Double = dt.Compute("max(" & ycol3 & ")", "")


        ymin1 = Math.Min(ymin1, ymin2)
        ymax1 = Math.Max(ymax1, ymax2)

        ymin1 = Math.Floor(ymin1 - (ymin1 * 0.1))
        ymax1 = Math.Floor(ymax1 + (ymax1 * 0.1))

        ymin3 = Math.Floor(ymin3 - (ymin3 * 0.05))
        ymax3 = Math.Floor(ymax3 + (ymax3 * 0.05))


        '' dv.Item(0)("lenseverity")
        Dim s As New StringBuilder("<script>")


        s.Append(" var myChart = echarts.init(document.getElementById('" & ContainerName & "'));")

        s.Append("option = {")
        s.Append("title: {")
        s.Append("text: ''")
        s.Append("},color:['#fa594d','#19a81d','#4039fa'],")
        s.Append("tooltip: {")
        s.Append("trigger: 'axis'")
        s.Append("},legend: {left:'center',data:['" & ycol1 & "','" & ycol2 & "','" & ycol3 & "']},")
        s.Append("xAxis: {")
        s.Append("data: [" & date_val & "]")
        s.Append("},")
        s.Append("yAxis: [{name:'" & ycol1 & "',min:" & ymin1 & ",max:" & ymax1 & ",splitNumber:5,")
        s.Append("splitLine: {")
        s.Append("show: false")
        s.Append("}")
        s.Append("},{name: '" & ycol3 & "',min:" & ymin3 & ",max:" & ymax3 & ",splitNumber:5, splitLine:  {show: false}}],")
        s.Append("toolbox: {")
        s.Append("left: 'right',")
        s.Append("feature: {")
        s.Append("dataZoom: {")
        s.Append("yAxisIndex: 'none'")
        s.Append("},")
        s.Append("restore: {},")
        s.Append("saveAsImage: {}")
        s.Append("}")
        s.Append("},")

        s.Append("series: [")
        s.Append("{name:'" & ycol1 & "',")
        s.Append("type: 'line',")
        s.Append("lineStyle: {width: 3}, ")
        s.Append("data: [" & data & "]")
        s.Append("},")
        s.Append("{name:'" & ycol2 & "',")
        s.Append("type: 'line', ")
        s.Append("lineStyle: {width: 3}, ")
        s.Append("data: [" & data1 & "]")
        s.Append("},")
        s.Append("{name:'" & ycol3 & "',")
        s.Append("type: 'line', yAxisIndex: 1, ")
        s.Append("lineStyle: {width: 3}, ")
        s.Append("data: [" & data3 & "]")
        s.Append("},")
        s.Append("]")
        s.Append("};")

        s.Append(" myChart.setOption(option);")
        s.Append("</script>")
        LiteralName.Text = s.ToString()


        'Catch ex As Exception

        'End Try
    End Sub
    Public Sub PlotLineEChart2(ByVal dt As DataTable, ByVal xcol As String, ByVal ycol1 As String, ByVal ycol2 As String, ByVal ycol3 As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String)
        ' Try

        LiteralName.Text = ""

        Dim dv As DataView = dt.DefaultView
        dv.Sort = "DateTime"

        dt = dv.ToTable
        Dim len As Double = dt.Rows(0)("length")
        Dim data As String = Nothing
        Dim data1 As String = Nothing
        Dim data3 As String = Nothing
        Dim date_val As String = Nothing
        For I As Integer = 50 To dt.Rows.Count - 50
            data &= dt.Rows(I - 48)(ycol1) & ","

            data1 &= dt.Rows(I - 48)(ycol2) & ","

            data3 &= dt.Rows(I)(ycol3) & ","
            date_val &= "'" & CDate(dt.Rows(I)(xcol)).ToString("yyyy-MM-dd HH:mm:ss") & "',"
        Next

        'Dim ymax1, ymin1, ymax2, ymin2 As Double
        Dim ymin1 As Double = dt.Compute("min(" & ycol1 & ")", "")
        Dim ymax1 As Double = dt.Compute("max(" & ycol1 & ")", "")
        Dim ymin2 As Double = dt.Compute("min(" & ycol2 & ")", "")
        Dim ymax2 As Double = dt.Compute("max(" & ycol2 & ")", "")
        Dim ymin3 As Double = dt.Compute("min(" & ycol3 & ")", "")
        Dim ymax3 As Double = dt.Compute("max(" & ycol3 & ")", "")


        ymin1 = Math.Min(ymin1, ymin2)
        If ymin3 > 0 Then
            ymin1 = Math.Min(ymin1, ymin2)
        End If
        ymax1 = Math.Max(ymax1, ymax2)
        ymax1 = Math.Max(ymax1, ymax3)

        ymin1 = Math.Floor(ymin1 - (ymin1 * 0.1))
        ymax1 = Math.Floor(ymax1 + (ymax1 * 0.1))
        ymin1 = 30
        'ymin3 = Math.Floor(ymin3 - (ymin3 * 0.05))
        'ymax3 = Math.Floor(ymax3 + (ymax3 * 0.05))


        '' dv.Item(0)("lenseverity")
        Dim s As New StringBuilder("<script>")


        s.Append(" var myChart = echarts.init(document.getElementById('" & ContainerName & "'));")

        s.Append("option = {")
        s.Append("title: {")
        s.Append("text: ''")
        s.Append("},color:['#f7b2ad','#19a81d','#4039fa'],")
        s.Append("tooltip: {")
        s.Append("trigger: 'axis'")
        s.Append("},legend: {left:'center',data:['" & ycol1 & "','" & ycol2 & "','" & ycol3 & "']},")
        s.Append("xAxis: {")
        s.Append(" axisLine: {lineStyle: { color: '#050505',width: 1}},")
        s.Append("data: [" & date_val & "]")
        s.Append("},")
        s.Append("yAxis: [{name:'" & ycol1 & "',min:" & ymin1 & ",max:" & ymax1 & ",splitNumber:5,")
        s.Append(" axisLine: {lineStyle: { color: '#050505',width: 1}},") '5359fc
        s.Append("splitLine: {")
        s.Append("show: false")
        s.Append("}")
        s.Append("},")
        's.Append("{name: '" & ycol3 & "',min:" & ymin3 & ",max:" & ymax3 & ",splitNumber:5, splitLine:  {show: false}}")
        s.Append("],")
        s.Append("toolbox: {")
        s.Append("left: 'right',")
        s.Append("feature: {")
        s.Append("dataZoom: {")
        's.Append("yAxisIndex: 'none'")
        s.Append("},")
        s.Append("restore: {},")
        s.Append("saveAsImage: {}")
        s.Append("}")
        s.Append("},")

        s.Append("series: [")
        s.Append("{name:'" & ycol3 & "',")
        s.Append("type: 'line',  ")
        's.Append("type: 'line', yAxisIndex: 1, ")
        's.Append("lineStyle: {color: '#f7b2ad',width: 1}, ")
        s.Append("lineStyle: {width: 1}, ")
        s.Append("data: [" & data3 & "]")
        s.Append("},")

        s.Append("{name:'" & ycol2 & "',")
        s.Append("type: 'line', ")
        's.Append("lineStyle: {color: '#19a81d',width: 3}, ")
        s.Append("lineStyle: {width: 3}, ")
        s.Append("data: [" & data1 & "]")
        s.Append("},")

        s.Append("{name:'" & ycol1 & "',")
        s.Append("type: 'line',")
        's.Append("lineStyle: {color: '#4039fa',width: 3}, ")
        s.Append("lineStyle: {width: 3}, ")
        s.Append("data: [" & data & "]")
        s.Append("},")

        s.Append("]")
        s.Append("};")

        s.Append(" myChart.setOption(option);")
        s.Append("</script>")
        LiteralName.Text = s.ToString()


        'Catch ex As Exception

        'End Try
    End Sub
    Sub ReCalculate(ByVal which As String)

        Dim pressure, speed, ak_distance, coat_simulate As Double
        Dim constant, Pr_fr_const, speed_const, dist_fr_const As Double
        pressure = hfslider2.Value
        speed = hfslider1.Value
        Pr_fr_const = -0.420641
        speed_const = 0.318106
        constant = 0.000217653
        dist_fr_const = 4.80165
        coat_simulate = Convert.ToDouble(coil1_thick_txt.Text)
        If coat_simulate = 0 Or coat_simulate <= 30 Or coat_simulate >= 300 Then
            UserMsgBoxError("Please check the coating values")
            Exit Sub
        Else
            coat_simulate = coil1_thick_txt.Text
        End If
        'ak_distance = Session("ak_distance")
        'ak_distance = Math.Pow((coat_simulate * 2) / 0.000000876, 1 / 6.5292981871)
        'AK_DIST_SIMULATE_TXT.Text = 17 'Math.Round(ak_distance, 2)
        'ak_distance = Convert.ToDouble(AK_DIST_SIMULATE_TXT.Text)
        ak_distance = Convert.ToDouble(hfslider3.Value)
        If ak_distance < 15 Or ak_distance > 23 Then
            UserMsgBoxError("Air knife gap not in range")
            Exit Sub
        End If
        ' ak_distance = Math.Pow(coat_simulate / (constant * Math.Pow(pressure, Pr_fr_const) * Math.Pow(speed, speed_const)), 1 / dist_fr_const)
        If which.Contains("sl1") Then
            If chk1.Checked = False Then
                If coil1_thick_txt.Text >= 43 Then
                    coil1_thick_txt.Text = Math.Round(0.000217653 * Math.Pow(pressure, -0.420641) * Math.Pow(speed, 0.318106) * Math.Pow(ak_distance, 4.80165), 2)
                    '-0.2547844	0.3718433	10.1752	7	1.58E-11
                    'pr  spd	dist	coat	const
                Else
                    coil1_thick_txt.Text = Math.Round(0.0000000000158 * Math.Pow(pressure, -0.2547844) * Math.Pow(speed, 0.3718433) * Math.Pow(ak_distance, 10.1752), 2) + 7
                End If
            Else
                If which.EndsWith("pr") Then  'pressure change
                    speed = Math.Pow(coil1_thick_txt.Text / (0.000217653 * Math.Pow(pressure, -0.420641) * Math.Pow(ak_distance, 10.1752)), 1 / 0.318106)
                    If ak_distance < 16.3 Then
                        speed = Math.Pow((coil1_thick_txt.Text - 7) / (0.0000000000158 * Math.Pow(pressure, -0.2547844) * Math.Pow(ak_distance, 10.1752)), 1 / 0.3718433)
                    End If

                    hfslider1.Value = Math.Round(speed, 0)
                    'txtLineSpeed.text = Math.Round(speed, 0)

                    If Math.Round(speed, 0) > 150 Then
                        UserMsgBoxError("Line Speed value " & Math.Round(speed, 0) & " is not feasible")
                        hfslider1.Value = 150
                        'txtLineSpeed.text = 150
                    End If

                    If Math.Round(speed, 0) < 30 Then
                        hfslider1.Value = 30
                        'txtLineSpeed.text = 30
                        UserMsgBoxError("Line Speed value " & Math.Round(speed, 0) & " is not feasible")
                    End If
                Else
                    pressure = Math.Pow(Convert.ToDouble(coil1_thick_txt.Text) / (0.000217653 * Math.Pow(speed, 0.318106) * Math.Pow(ak_distance, 4.80165)), 1 / -0.420641)
                    If ak_distance < 16.3 Then
                        pressure = Math.Pow((coil1_thick_txt.Text - 7) / (0.0000000000158 * Math.Pow(speed, 0.3718433) * Math.Pow(ak_distance, 10.1752)), 1 / -0.2547844)
                    End If
                    hfslider2.Value = Math.Round(pressure, 0)
                    'txtAirPressure.text = Math.Round(pressure, 0)

                    If Math.Round(pressure, 0) > 600 Then
                        hfslider2.Value = 600
                        'txtAirPressure.text = 650
                        UserMsgBoxError("Air knife Pressure predicted is above 600 mbar")
                    End If

                    If Math.Round(pressure, 0) < 100 Then
                        hfslider2.Value = 100
                        'txtAirPressure.text = 100
                        UserMsgBoxError("Pressure value " & Math.Round(pressure, 0) & " is not feasible")
                    End If
                End If
            End If
            hfAK.Value = hfslider2.Value
            'AK_DIST_SIMULATE_TXT.Text = Math.Round(ak_distance, 2)
        End If


    End Sub

    Function Calculate(ByVal dt As DataTable, ByVal constant As Double, ByVal Pr_coeff As Double, ByVal spd_coeff As Double, ByVal dist_coeff As Double) As Double

        'AK_Distance = power([botcoat] / (0.000217653 * power([Airknife_pr_fr_set], -0.420641) * power([speed], 0.318106)), 1 / 4.80165)
        Dim ak_distance As Double = Math.Pow(dt.Rows(0)("coat") / (constant * Math.Pow(dt.Rows(0)("pr"), Pr_coeff) * Math.Pow(dt.Rows(0)("spd"), spd_coeff)), 1 / dist_coeff)
        Session("ak_distance") = ak_distance
        '  hfAK.Value = Math.Round(ak_distance, 2)
        Dim pressure As Double = dt.Rows(0)("pr")
        Dim speed As Double = dt.Rows(0)("spd")

        'coatwt = 0.000217653*〖𝑃𝑟𝑒𝑠𝑠𝑢𝑟𝑒〗^(−0.420641)* 〖𝑆𝑝𝑒𝑒𝑑〗^(0.318106 )* 〖𝐴𝑖𝑟\_𝑘𝑛𝑖𝑓𝑒\_𝑑𝑖𝑠𝑡𝑎𝑛𝑐𝑒〗^(4.80165 )


        'txtCoatWt.Text = Math.Round(constant * Math.Pow(pressure, Pr_coeff) * Math.Pow(speed, spd_coeff) * Math.Pow(ak_distance, dist_coeff), 2)
        'txtAirPressure.Text = Math.Round(pressure, 0)
        'txtLineSpeed.Text = Math.Round(speed, 0)

        AK_DIST_start = ak_distance
        Return ak_distance
    End Function

    Protected Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click
        FetchDataAndChartPlot(hfFrom.Value, hfTo.Value)
    End Sub


End Class
