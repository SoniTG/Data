﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Data.SqlClient
Imports System.Data
Imports System.Web.Script.Serialization
Imports System.IO

Partial Class Morgoil
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
            date1.Text = DateTime.Now.AddDays(-1).ToString("dd-MM-yyyy HH:mm:ss") & "&nbsp;" & " TO " & "&nbsp;" & DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss")
            Dim current_time As Date = Date.Now
        End If

    End Sub
End Class

