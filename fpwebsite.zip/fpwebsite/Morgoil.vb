﻿Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.Linq
Imports System.Data
Imports System.Data.SqlClient
Imports System.Data.OracleClient
Imports System
Imports System.Collections.Generic
Imports System.Configuration
Imports System.Web.Script.Serialization

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
<System.Web.Script.Services.ScriptService()> _
<WebService(Namespace:="http://tempuri.org/")> _
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Public Class Morgoil
    Inherits System.Web.Services.WebService
    Public Sub FnGetPageHits()
        Dim count As Integer = 0
        Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("LPTGSQLDEV").ConnectionString
        Using dt = New DataTable
            Using sqlCon = New SqlConnection(strConnectionString)
                Using sqlDa = New SqlDataAdapter("SELECT TIMESTAMP FROM PAGE_HIT_DTLS WHERE PAGE_NAME IN ('Morgoil.aspx')", sqlCon)
                    sqlDa.Fill(dt)
                    count = IIf(dt.Rows.Count = 0, 0, dt.Rows.Count)
                End Using
            End Using
        End Using
        Context.Response.Write(count)
    End Sub

    <WebMethod()>
    Public Sub FnSavePageHits(ByVal LoginTime As String, ByVal PageName As String)
        Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("LPTGSQLDEV").ConnectionString
        Using sqlCon = New SqlConnection(strConnectionString)
            Using sqlCmd = New SqlCommand("INSERT INTO PAGE_HIT_DTLS(page_name,[timestamp]) VALUES('" & PageName & "','" & LoginTime & "')", sqlCon)
                sqlCon.Open()
                sqlCmd.ExecuteNonQuery()
                sqlCmd.Clone()
            End Using
        End Using
    End Sub

    <WebMethod()>
    Public Sub Getdata2()
        Dim ld As List(Of dataget) = New List(Of dataget)()
        Dim CS As String = ConfigurationManager.ConnectionStrings("DBCS").ConnectionString
        Using con As New SqlConnection(CS)
            Using cmd As New SqlCommand("SELECT * FROM ( SELECT [COIL_ID], [MORGOIL_LUB] , [START_TIME] ,[STAND]   FROM [FP_PROCESS_DATA].[dbo].[TSCR_MILL_MORGOIL] ) AS SourceTable PIVOT(max([MORGOIL_LUB]) FOR [STAND] IN([F1], [F2],[F3],[F4],[F5] , [F6])) AS PivotTable where [START_TIME] between GETDATE()-1 AND GETDATE() order by START_TIME desc;", con)
                cmd.CommandType = CommandType.Text
                Using sda As New SqlDataAdapter(cmd)
                    Using dt As New DataSet()
                        sda.Fill(dt)
                        Dim i As Integer = 0
                        Dim coilid As String = ""
                        Dim starttime As String = ""
                        Dim f1 As String = ""
                        Dim f2 As String = ""
                        Dim f3 As String = ""
                        Dim f4 As String = ""
                        Dim f5 As String = ""
                        Dim f6 As String = ""

                        For i = 0 To dt.Tables(0).Rows.Count - 1
                            Dim data As dataget = New dataget()
                            data.coilid = coilid & dt.Tables(0).Rows(i)("COIL_ID")
                            data.starttime = starttime & dt.Tables(0).Rows(i)("START_TIME")

                            data.f1 = f1 & dt.Tables(0).Rows(i)("F1")
                            data.f2 = f2 & dt.Tables(0).Rows(i)("F2")
                            data.f3 = f3 & dt.Tables(0).Rows(i)("F3")
                            data.f4 = f4 & dt.Tables(0).Rows(i)("F4")
                            data.f5 = f5 & dt.Tables(0).Rows(i)("F5")
                            data.f6 = f6 & dt.Tables(0).Rows(i)("F6")

                            ld.Add(data)
                        Next
                        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
                        Context.Response.Write(js.Serialize(ld))
                    End Using
                End Using
            End Using
        End Using

    End Sub

    Public Class dataget
        Public Property coilid As String
        Public Property starttime As String
        Public Property f1 As String
        Public Property f2 As String
        Public Property f3 As String
        Public Property f4 As String
        Public Property f5 As String
        Public Property f6 As String
      

    End Class



    <WebMethod()>
    Public Sub GetdataWR()
        Dim ld As List(Of datagetWRDS) = New List(Of datagetWRDS)()
        Dim CS As String = ConfigurationManager.ConnectionStrings("DBCS").ConnectionString
        Using con As New SqlConnection(CS)
            Using cmd As New SqlCommand(" SELECT * FROM( SELECT [COIL_ID], [START_TIME], [WR_BENDING],[STAND] ,[SIDE] FROM [FP_PROCESS_DATA].[dbo].[TSCR_MILL_WRBENDING]) AS SourceTable PIVOT(max([WR_BENDING]) FOR [STAND] IN([F1], [F2],[F3],[F4],[F5],F6)) AS PivotTable WHERE SIDE = 'ds' order by START_TIME desc; SELECT * FROM( SELECT [COIL_ID], [START_TIME], [WR_BENDING],[STAND] ,[SIDE] FROM [FP_PROCESS_DATA].[dbo].[TSCR_MILL_WRBENDING]) AS SourceTable1 PIVOT(max([WR_BENDING]) FOR [STAND] IN([F1],[F2],[F3],[F4],[F5],F6)) AS PivotTable1  WHERE SIDE = 'os' order by START_TIME desc;", con)
                cmd.CommandType = CommandType.Text
                Using sda As New SqlDataAdapter(cmd)
                    Using dS As New DataSet()
                        sda.Fill(dS)
                        Dim dt As DataTable = dS.Tables(0)
                        Dim dt1 As DataTable = dS.Tables(1)
                        Dim c As Integer = 0
                        Dim i As Integer = 0

                        Dim coilid As String = ""
                        Dim starttime As String = ""
                        Dim f1 As String = ""
                        Dim f2 As String = ""
                        Dim f3 As String = ""
                        Dim f4 As String = ""
                        Dim f5 As String = ""
                        Dim f6 As String = ""
                        Dim Of1 As String = ""
                        Dim Of2 As String = ""
                        Dim Of3 As String = ""
                        Dim Of4 As String = ""
                        Dim Of5 As String = ""
                        Dim Of6 As String = ""

                        If dS.Tables(0).Rows.Count > dS.Tables(1).Rows.Count Then
                            c = dS.Tables(1).Rows.Count
                        ElseIf dS.Tables(0).Rows.Count < dS.Tables(1).Rows.Count Then
                            c = dS.Tables(0).Rows.Count
                        Else
                            c = dS.Tables(0).Rows.Count
                        End If

                        For i = 0 To c - 1

                            Dim data As datagetWRDS = New datagetWRDS()

                            'For i = 0 To dt.Rows.Count - 1
                            If dS.Tables(0).Rows(i)("COIL_ID") = dS.Tables(1).Rows(i)("COIL_ID") Then
                                data.coilid = coilid & dS.Tables(0).Rows(i)("COIL_ID")
                                data.starttime = starttime & dS.Tables(0).Rows(i)("START_TIME")
                                data.f1 = f1 & dS.Tables(0).Rows(i)("F1")
                                data.f2 = f2 & dS.Tables(0).Rows(i)("F2")
                                data.f3 = f3 & dS.Tables(0).Rows(i)("F3")
                                data.f4 = f4 & dS.Tables(0).Rows(i)("F4")
                                data.f5 = f5 & dS.Tables(0).Rows(i)("F5")
                                data.f6 = f6 & dS.Tables(0).Rows(i)("F6")



                                'Next
                                'For j = 0 To dt1.Rows.Count - 1

                                data.Of1 = Of1 & dS.Tables(1).Rows(i)("F1")
                                data.Of2 = Of2 & dS.Tables(1).Rows(i)("F2")
                                data.Of3 = Of3 & dS.Tables(1).Rows(i)("F3")
                                data.Of4 = Of4 & dS.Tables(1).Rows(i)("F4")
                                data.Of5 = Of5 & dS.Tables(1).Rows(i)("F5")
                                data.Of6 = Of6 & dS.Tables(1).Rows(i)("F6")
                                ld.Add(data)
                            Else
                                Continue For
                            End If
                            'Next

                        Next
                        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
                        Context.Response.Write(js.Serialize(ld))
                    End Using
                End Using
            End Using
        End Using

    End Sub
    Public Class datagetWRDS
        Public Property coilid As String
        Public Property starttime As String
        Public Property f1 As String
        Public Property f2 As String
        Public Property f3 As String
        Public Property f4 As String
        Public Property f5 As String
        Public Property f6 As String
        Public Property Of1 As String
        Public Property Of2 As String
        Public Property Of3 As String
        Public Property Of4 As String
        Public Property Of5 As String
        Public Property Of6 As String


    End Class
End Class