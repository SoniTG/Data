﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Data.SqlClient
Imports System.Data
Imports System.Web.Script.Serialization
Partial Class Morgoil_Analysis
    Inherits System.Web.UI.Page

End Class
