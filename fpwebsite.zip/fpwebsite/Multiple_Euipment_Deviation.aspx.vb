﻿Imports System.Data
Imports System.IO

Imports System.Web.Services
Imports System.Data.SqlClient
Imports System.Drawing
Partial Class Multiple_Euipment_Deviation
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim objDataHandler As New DataHandler
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    txtDate_TextChanged()
                End If


            Catch ex As Exception

            End Try

        End If

        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

                loadequip(dtStart, dtEnd)

                hfFrom.Value = dtStart
                hfTo.Value = dtEnd
                ''''''''''''''''''''''''''''''''''''

                ''''''''''''''''''''''''''''''''''''
                'DrawChart(dtStart, dtEnd, ddlDefName.SelectedItem.Text, ddlSurface.SelectedValue.ToString())

                Dim strGrade As String = getSelectedData(lstGrade)

                Try

                    If strGrade.Length > 0 Then
                        strGrade = "'" & strGrade.Replace(",", "','") & "'"
                    End If


                Catch ex As Exception

                End Try
                ' Dim strGrade As String = getSelectedData(lstGrade)
                Dim dt As DataTable = objController.PopulaleDynamiclineDataENTRY(dtStart, dtEnd, strGrade, ddl1.SelectedItem.Text)

                dt.DefaultView.Sort = "BUSINESS_RULE DESC"
                dt = dt.DefaultView.ToTable
                Dim dtDist As DataTable = dt.DefaultView.ToTable(True, "BUSINESS_RULE", "EQUIPMENT") ' objController.GetDynamicHeaderENTRY(strGrade) 'dt.DefaultView.ToTable(True, "CCS_PARAM_NAME")

                CreateDynamicContainer(dtDist)

                Dim dtLimits As DataTable = objController.POPULATEDataForLimits(strGrade)
                '   Dim distLimits As DataTable = dtLimits.DefaultView.ToTable(True, "B_RULE", "EQUIPMENT") 'dt.DefaultView.ToTable(True, "CCS_PARAM_NAME")

                GetData(dt, dtDist, dtLimits)
                ' DrawChart(dtStart, dtEnd, strGrade)
            Catch ex As Exception

            End Try

        End If

    End Sub


    Sub loadequip(ByVal fromDt As String, ByVal toDt As String)

        ' Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("SELECT  distinct [EQUIPMENT]   FROM [FP_PROCESS_DATA].[dbo].[TSCR_MULTIPLE_EQUIPMENT_DEVSTION]  order by [EQUIPMENT] desc")
        Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("SELECT  distinct [EQUIPMENT]  FROM [FP_PROCESS_DATA].[dbo].[TSCR_MILL_BUSINESS_RULE] order by [EQUIPMENT] desc")

        Dim dt As DataTable = ds.Tables(0)
        '  Dim dt1 As DataTable = ds.Tables(1)
        lstGrade.DataSource = dt
        lstGrade.DataTextField = "EQUIPMENT"
        lstGrade.DataValueField = "EQUIPMENT"
        lstGrade.DataBind()


        For Each lst As ListItem In lstGrade.Items
            lst.Selected = True
        Next


    End Sub


    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try
            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value

            Dim strGrade As String = getSelectedData(lstGrade)


            If strGrade.Length > 0 Then
                strGrade = "'" & strGrade.Replace(",", "','") & "'"
            End If


            'DrawChart(dtStart, dtEnd, ddlDefName.SelectedItem.Text, ddlSurface.SelectedValue.ToString())
            '  DrawChart(dtStart, dtEnd, strGrade)
            Dim dt As DataTable = objController.PopulaleDynamiclineDataENTRY(dtStart, dtEnd, strGrade, ddl1.SelectedItem.Text)



            dt.DefaultView.Sort = "BUSINESS_RULE DESC"
            dt = dt.DefaultView.ToTable
            Dim dtDist As DataTable = dt.DefaultView.ToTable(True, "BUSINESS_RULE", "EQUIPMENT") 'objController.GetDynamicHeaderENTRY(strGrade) 'dt.DefaultView.ToTable(True, "CCS_PARAM_NAME")

            CreateDynamicContainer(dtDist)

            Dim dtLimits As DataTable = objController.POPULATEDataForLimits(strGrade)
            '  Dim distLimits As DataTable = dtLimits.DefaultView.ToTable(True, "B_RULE", "EQUIPMENT") 'dt.DefaultView.ToTable(True, "CCS_PARAM_NAME")

            GetData(dt, dtDist, dtLimits)
        Catch ex As Exception

        End Try

    End Sub


    Protected Sub btnGo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnGo.Click

        'If ddl1.SelectedIndex = 0 Then
        '    UserMsgBoxError("Select caster")
        '    Return
        'End If

        Dim dtStart As String = hfFrom.Value
        Dim dtEnd As String = hfTo.Value
        'LoadDefectList(dtStart, dtEnd)


        Dim strGrade As String = getSelectedData(lstGrade)


        If strGrade.Length > 0 Then
            strGrade = "'" & strGrade.Replace(",", "','") & "'"
        End If

        Dim dt As DataTable = objController.PopulaleDynamiclineDataENTRY(dtStart, dtEnd, strGrade, ddl1.SelectedItem.Text)




        dt.DefaultView.Sort = "BUSINESS_RULE DESC"
        dt = dt.DefaultView.ToTable

        Dim dtDist As DataTable = dt.DefaultView.ToTable(True, "BUSINESS_RULE", "EQUIPMENT") 'dt.DefaultView.ToTable(True, "CCS_PARAM_NAME")

        CreateDynamicContainer(dtDist)


        Dim dtLimits As DataTable = objController.POPULATEDataForLimits(strGrade)
        '   Dim distLimits As DataTable = dtLimits.DefaultView.ToTable(True, "B_RULE", "EQUIPMENT") 'dt.DefaultView.ToTable(True, "CCS_PARAM_NAME")

        If dt.Rows.Count > 0 Then
              GetData(dt, dtDist, dtLimits)
        End If


        GetData(dt, dtDist, dtLimits)
        'DrawChart(dtStart, dtEnd, ddlDefName.SelectedItem.Text, ddlSurface.SelectedValue.ToString())
        ' DrawChart(dtStart, dtEnd, strGrade)
    End Sub

    Function getSelectedData(ByRef lst As ListBox) As String
        Dim retVal As String = ""
        Try
            For Each lstItem As ListItem In lst.Items
                If lstItem.Selected = True Then
                    retVal &= "," & lstItem.Text & ""
                End If
            Next

        Catch ex As Exception

        End Try

        If retVal.Length > 0 Then
            Return retVal.Substring(1)
        Else
            Return retVal
        End If


        'Return (retVal)
    End Function




    'Sub DrawChartTop(ByVal FromDt As String, ByVal ToDt As String)
    '    Try

    '        Dim dtStart As String = FromDt
    '        Dim dtEnd As String = ToDt


    '        Dim dt As DataTable = objController.POPULATELD3DATA(dtStart, dtEnd)

    '        Dim dtcast2 As DataTable = objController.POPULATELD3DATAforcaster2(dtStart, dtEnd)
    '        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

    '        Dim dtcast1chart3 As DataTable = objController.LD3_DataCaster1_chart3(dtStart, dtEnd)
    '        Dim dtcast2chart3 As DataTable = objController.LD3_DataCaster2_chart3(dtStart, dtEnd)

    '        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

    '        If dt.Rows.Count > 0 Then
    '            'objController.lineForLD3MILL(dt, Lit1, "container1", "plot", "", "SIDE")

    '            '  PlotLineChart(dt, "HMO_TIMESTAMP", "HMO_DEV", Lit1, "container1", "plot1", "", "", "SIDE")
    '            objController.LD3LINECHART(dt, Lit1, "container1", "plot1", "")

    '        End If

    '        If dtcast2.Rows.Count > 0 Then

    '            objController.LD3LINECHART(dtcast2, Lit2, "container2", "plot2", "")

    '        End If


    '    Catch ex As Exception

    '    End Try
    'End Sub

    Sub GetData(ByVal dt As DataTable, ByVal distinct As DataTable, ByVal dtlimits As DataTable)
        Try
            Dim dvLimits As DataView = dtlimits.DefaultView
            Dim dv As DataView = dt.DefaultView
            Dim l As Literal
            Dim COUNT As Integer = 1


            'Dim strGrade As String = getSelectedData(lstGrade)


            'If strGrade.Length > 0 Then
            '    strGrade = "'" & strGrade.Replace(",", "','") & "'"
            'End If
            '    Dim literals = Page.Controls.OfType(Of Literal)()
            Dim literals = Page.Master.FindControl("content_body").Controls.OfType(Of Literal)()
            ' Dim literals = form1.Controls.OfType(Of Literal)() '("LiteralID")
            Dim dtStart As String = DateTime.Now.AddDays(-30).ToString("yyyy-MM-dd HH:mm:ss")
            Dim litidx As Integer = 1
            For dis As Integer = 0 To distinct.Rows.Count - 1
                dv.RowFilter = "EQUIPMENT='" & distinct.Rows(dis)(1) & "' "
                Dim tempdt As DataTable = dv.ToTable
                Dim tempdtlimits As DataTable = dvLimits.ToTable
                Dim dv1 As DataView = dt.AsDataView
                Dim dv_limit As DataView = tempdtlimits.AsDataView
                Dim dtDist As DataTable = tempdt.DefaultView.ToTable(True, "BUSINESS_RULE", "EQUIPMENT")
                For j As Integer = 0 To dtDist.Rows.Count - 1
                    dv1.RowFilter = "BUSINESS_RULE = '" & dtDist.Rows(j)("BUSINESS_RULE") & "' and EQUIPMENT = '" & dtDist.Rows(j)("EQUIPMENT") & "'"
                    dv_limit.RowFilter = "B_RULE = '" & dtDist.Rows(j)("BUSINESS_RULE") & "' and EQUIPMENT = '" & dtDist.Rows(j)("EQUIPMENT") & "'"
                    For Each lit In literals
                        Dim i As Integer = j + 1
                        If (lit.ID = "Lit" & litidx) Then
                            l = lit
                            lit.Text = ""

                            If tempdt.Rows.Count > 0 Then

                                objController.PlotLineEChart(dv1.ToTable, l, "cy" & litidx, "plot" & dis & "", dtStart, dv_limit.ToTable)
                                litidx += 1
                                Exit For
                                'PlotLineEChart
                            Else litidx += 1
                            End If

                        Else
                            Continue For
                        End If
                    Next

                    dv1.RowFilter = ""
                    dv_limit.RowFilter = ""
                Next

                dv.RowFilter = ""
            Next
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

    End Sub




    Sub CreateDynamicContainer(ByVal dt As DataTable)


        Try
            Dim appendString = ""
            For i As Integer = 0 To dt.Rows.Count - 1
                appendString &= "<div class='col-md-6'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>" & dt.Rows(i)("BUSINESS_RULE") & "</h3> <span></span></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='cy" & i + 1 & "' style='height: 200px;'></div></div></div></div>"
            Next
            divHolder.InnerHtml = appendString
        Catch ex As Exception

        End Try

    End Sub


    Protected Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        Response.Redirect("Multiple_Euipment_Deviation.aspx")
    End Sub
End Class
