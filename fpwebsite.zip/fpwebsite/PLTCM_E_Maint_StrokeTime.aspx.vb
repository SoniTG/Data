﻿

Imports System.Data
Imports System.IO

Partial Class PLTCM_E_Maint_StrokeTime
    Inherits System.Web.UI.Page

    Dim objdatahandler As New DataHandler
    Dim objController As New Controller
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
            Dim frmDate As String = DateTime.Now.AddDays(-7).ToString("yyyy-MM-dd HH:mm:ss")
            Dim toDate As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            Dim ds As DataSet = objdatahandler.GetDataSetFromQuery("select csa_param_name,csa_datetime,(CSA_PARAM_VALUE-CSA_PARAM_LIMIT) as dif from [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_PL_WELDER_STROKETIME_ALARM] where csa_param_name <> 'POR2 MANDREL TIME - EXPAND [Sec]' and CSA_DATETIME between '" & frmDate & "' and '" & toDate & "' order by 1,csa_datetime; select distinct csa_param_name from [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_PL_WELDER_STROKETIME_ALARM] where csa_param_name <> 'POR2 MANDREL TIME - EXPAND [Sec]' and CSA_DATETIME between '" & frmDate & "' and '" & toDate & "';select count(*),csa_param_name from [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_PL_WELDER_STROKETIME_ALARM]  where csa_param_name <> 'POR2 MANDREL TIME - EXPAND [Sec]' and CSA_DATETIME between '" & frmDate & "' and '" & toDate & "' group by csa_param_name order by 1 desc")
            If ds.Tables(0).Rows.Count > 0 Then
                Dim maxseries As Integer = ds.Tables(2).Rows(0)(0)
                Dim noalarms As Integer = ds.Tables(1).Rows.Count

                Dim js As New StringBuilder
                Dim tick As New StringBuilder("[")
                js.Append("<script>")
                js.Append("var s1=[")
                Dim dv As DataView = ds.Tables(0).DefaultView
                For i As Integer = 0 To noalarms - 1

                    dv.RowFilter = "CSA_PARAM_NAME='" & ds.Tables(1).Rows(i)(0) & "'"

                    If i > 0 Then
                        js.Append(",")
                        tick.Append(",")
                    End If
                    tick.Append("'" & ds.Tables(1).Rows(i)(0) & "'")
                    js.Append("[")
                    For j As Integer = 0 To dv.Count - 1
                        If j > 0 Then js.Append(",")
                        Try
                            js.Append(dv.Item(j)(2))
                        Catch ex As Exception

                        End Try

                    Next
                    js.Append("]")
                    dv.RowFilter = ""
                Next
                tick.Append("]")
                js.Append("];")

                js.Append("var dRenderer = function () {var data = [];var maxl = " & maxseries & ";")
                js.Append("for (j = 0; j < maxl; j++) {var temp = [];")
                js.Append("for (i = 0; i < " & noalarms & "; i++) {if (typeof s1[i][j] === 'undefined') {temp.push(0);}else {temp.push(s1[i][j]);}}")
                js.Append("data.push(temp);} return data;};")
                js.Append("plot3 = $.jqplot('chart1', [], { stackSeries: true,dataRenderer: dRenderer,seriesDefaults: {renderer: $.jqplot.BarRenderer,rendererOptions: {")
                js.Append("barMargin: 30,},},axes: {xaxis: {renderer: $.jqplot.CategoryAxisRenderer,ticks:" & tick.ToString & "},yaxis: {")
                js.Append("padMin: 0}},axesDefaults: {tickRenderer: $.jqplot.CanvasAxisTickRenderer ,tickOptions: {angle: -30,fontSize: '10pt'}}});")

                js.Append("</script>")

                Literal1.Text = js.ToString
            End If

        End If
    End Sub
End Class



