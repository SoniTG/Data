﻿
Partial Class Page0001
    Inherits System.Web.UI.Page

End Class
