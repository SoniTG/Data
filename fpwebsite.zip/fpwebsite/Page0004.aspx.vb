﻿
Partial Class Page0004
    Inherits System.Web.UI.Page

End Class
