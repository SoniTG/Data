﻿
Partial Class Page0005
    Inherits System.Web.UI.Page

End Class
