﻿Imports System.Data
Imports System.IO
Imports System.Data.OleDb
Imports System.Data.DataTable
Imports System.Drawing
Imports System.Collections.Generic
Imports System.Web.UI
Imports System.Web.Script.Serialization

Partial Class Pltcm_Jcap_cold_hold
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    txtDate_TextChanged()
                End If
            Catch ex As Exception

            End Try

        End If

        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-6).ToString("yyyy-MM-dd HH:mm:ss")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")

                ' Dim dt As DataTable = objController.GetPLTCMjcapdata("CRM_PLTCM_PROCESS_DATA_COILWISE", dtStart, dtEnd)
                GetData(dtStart, dtEnd)

            Catch ex As Exception

            End Try

        End If
      
    End Sub
    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try
            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            GetData(dtStart, dtEnd)
        Catch ex As Exception

        End Try
    End Sub
    Sub GetData(ByVal dtStart As String, ByVal dtEnd As String)
        Try

            Dim dt As DataTable = objController.GetPLTCMjcapdata("CRM_PLTCM_PROCESS_DATA_COILWISE", dtStart, dtEnd)
            Dim table As New DataTable
            table.Columns.Add("HR_DATE_TIME")
            table.Columns.Add("CR_DATE_TIME")
            table.Columns.Add("HR_COIL_ID")
            table.Columns.Add("CR_COIL_ID")
            table.Columns.Add("CR_WIDTH")
            table.Columns.Add("CR_THICKNESS")
            table.Columns.Add("CR_THICKNESS_DEV")
            'table.Columns.Add("MIN_DEV")
            'table.Columns.Add("MAX_DEV")
            'table.Columns.Add("AVG_DEV")
            table.Columns.Add("HEAD")
            table.Columns.Add("TAIL")
            table.Columns.Add("HOLD")
            Dim IDS As List(Of String) = (From p In dt.AsEnumerable() Select p.Field(Of String)("HR_COIL_ID")).Distinct().ToList()
            For Each name As String In IDS
                Dim FALG1 As Integer = 0
                Dim FALG2 As Integer = 0
                Dim newRow As DataRow = table.NewRow()
                For COUNT As Integer = 0 To dt.Rows.Count - 1
                    If name.Equals(dt.Rows(COUNT)("HR_COIL_ID")) And FALG1 = 0 Then
                        FALG1 = 1
                        newRow("HR_DATE_TIME") = dt.Rows(COUNT)("HR_DATE_TIME").ToString
                        newRow("CR_DATE_TIME") = dt.Rows(COUNT)("CR_DATE_TIME").ToString
                        newRow("HR_COIL_ID") = dt.Rows(COUNT)("HR_COIL_ID").ToString
                        newRow("CR_COIL_ID") = dt.Rows(COUNT)("CR_COIL_ID").ToString
                        newRow("CR_WIDTH") = dt.Rows(COUNT)("CR_WIDTH").ToString
                        newRow("CR_THICKNESS") = dt.Rows(COUNT)("CR_THICKNESS").ToString
                        newRow("CR_THICKNESS_DEV") = dt.Rows(COUNT)("CR_THICKNESS_DEV").ToString
                        'newRow("MIN_DEV") = dt.Rows(COUNT)("MIN_DEV").ToString
                        'newRow("MAX_DEV") = dt.Rows(COUNT)("MAX_DEV").ToString
                        'newRow("AVG_DEV") = dt.Rows(COUNT)("AVG_DEV").ToString
                    End If

                    For COUNT1 As Integer = 0 To dt.Rows.Count - 1
                        FALG2 = 1
                        If name.Equals(dt.Rows(COUNT1)("HR_COIL_ID")) Then
                            Dim END_VAL As Integer = dt.Rows(COUNT1)("COIL_LEN") - 11
                            Dim coil_val As Integer = dt.Rows(COUNT1)("COIL_LEN") / 2
                            If dt.Rows(COUNT1)("DEV_EN_LN") = "no dev" Then
                                newRow("HEAD") = "NO"
                                newRow("TAIL") = "NO"
                                newRow("HOLD") = "NO"
                                Exit For
                            End If
                            If Convert.ToInt32(dt.Rows(COUNT1)("DEV_EN_LN")) < coil_val Then
                                newRow("HEAD") = "YES"
                                If Convert.ToInt32(dt.Rows(COUNT1)("DEV_EN_LN")) > 10 And Convert.ToInt32(dt.Rows(COUNT1)("DEV_EN_LN")) < END_VAL Then
                                    newRow("HOLD") = "YES"
                                End If
                            ElseIf Convert.ToInt32(dt.Rows(COUNT1)("DEV_EN_LN")) > coil_val Then
                                newRow("TAIL") = "YES"
                                If Convert.ToInt32(dt.Rows(COUNT1)("DEV_EN_LN")) > 10 And Convert.ToInt32(dt.Rows(COUNT1)("DEV_EN_LN")) < END_VAL Then
                                    newRow("HOLD") = "YES"
                                End If
                            End If
                        End If

                    Next
                    If FALG2 = 1 And FALG1 = 1 Then
                        Exit For
                    End If
                Next
                If newRow("HEAD") Is DBNull.Value Then
                    newRow("HEAD") = "NO"
                End If
                If newRow("TAIL") Is DBNull.Value Then
                    newRow("TAIL") = "NO"
                End If
                If newRow("HOLD") Is DBNull.Value Then
                    newRow("HOLD") = "NO"
                End If
                table.Rows.Add(newRow)
            Next

            DataDetailAnalysis(table)

        Catch ex As Exception

        End Try

    End Sub
    Sub DataDetailAnalysis(ByVal tab As DataTable)
        Try
        MAINGRID.DataSource = tab
            MAINGRID.DataBind()
        Catch ex As Exception

        End Try
        'MAINGRID.Columns("METERS").Visible = False
        'MAINGRID.Columns("DEV_SL_NO").Visible = False
        'MAINGRID.Columns("DEV_ST_LN").Visible = False
        'MAINGRID.Columns("DEV_EN_LN").Visible = False

    End Sub
    Protected Sub GridView1_RowCommand(sender As Object, e As GridViewCommandEventArgs)


        If e.CommandName = "Select" Then
            'Determine the RowIndex of the Row whose LinkButton was clicked.
            Dim rowIndex As Integer = Convert.ToInt32(e.CommandArgument)
            MAINGRID.Rows(Session("rowind")).BackColor = Color.White
            Session("rowind") = rowIndex
            MAINGRID.Rows(rowIndex).BackColor = Color.BurlyWood
            'Reference the GridView Row.

            Dim row As GridViewRow = MAINGRID.Rows(rowIndex)

            'Fetch value of Name.
            Session("HR_ID") = row.Cells(2).Text
            Session("CR_ID") = row.Cells(3).Text
            Session("WIDTH_CR") = row.Cells(4).Text
            Session("THICNESS_CR") = row.Cells(5).Text
            Session("Dev_val") = row.Cells(6).Text
            Session("METERS") = 0

            'Fetch value of Country.
            ' Dim country As String = row.Cells(1).Text

            '' ClientScript.RegisterStartupScript(Me.GetType(), "alert", "alert('Name: " & row.Cells(2).Text & "\nCountry: " & row.Cells(3).Text & "');", True)
            ClientScript.RegisterStartupScript(Me.GetType(), "OpenWindow", "window.open('Sub_Pltcm_jcap_coil_hold.aspx','_blank','toolbar=no,location=no,directories=no,status=no,scrollbars=yes,resizable=no,top=100,left=200,width=800,height=400');", True)
            ''Response.Redirect("InspectionDefByWidth.aspx")
        End If
    End Sub

    'Private Sub MAINGRID_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles MAINGRID.RowDataBound
    '    'If e.Row.RowType = DataControlRowType.DataRow Then
    '    'Dim t1_act As String = DataBinder.Eval(e.Row.DataItem, "HOLD")

    '    'If t1_act = "YES" Then
    '    '    e.Row.Cells(12).BackColor = Color.Gray
    '    '    e.Row.Cells(12).ForeColor = Color.LightGreen

    '    'Else

    '    'End If
    '    'End If

    'End Sub
End Class
