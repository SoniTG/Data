﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Drawing
Imports System.Globalization
Imports System.IO
Imports System.Linq


Partial Class Pltcm_std_motor_health
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")

                If p = "date" Then
                    DrawBxPlot(hfFrom.Value, hfTo.Value)
                End If
            Catch ex As Exception

            End Try

        End If

        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))

                Dim fromdate As DateTime = DateTime.Now.AddDays(-1).ToString
                Dim todate As DateTime = DateTime.Now.ToString
                DrawBxPlot(fromdate, todate)


            Catch ex As Exception

            End Try

        End If

    End Sub
    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try
            DrawBxPlot(hfFrom.Value, hfTo.Value)
        Catch ex As Exception

        End Try
    End Sub
    Sub DrawBxPlot(ByVal fromdate As DateTime, ByVal totime As DateTime)

        'Dim dtStart As String = hfFrom.Value
        'Dim dtEnd As String = hfTo.Value
        '   Dim dt_con3 As DataTable = objController.GettempdistChartData(fromdate, totime)
        Dim dt_con3 As DataTable = objController.motorwending(fromdate, totime)

        If dt_con3.Rows.Count > 0 Then

     
            objController.PlotStackedChart_new(dt_con3, Lit1, "container3", "plot3", "Distribution(%)", fromdate)
        Else
            Lit1.Text = ""
        End If
        Dim dt_con4 As DataTable = objController.motorbearing(fromdate, totime)
        If dt_con4.Rows.Count > 0 Then
            objController.PlotStackedChart_new1(dt_con4, Lit2, "container4", "plot4", "Distribution(%)", fromdate)
        Else
            Lit1.Text = ""
        End If

    End Sub
End Class
