﻿Imports System.Data
Imports System.IO
Imports iTextSharp.text
Imports iTextSharp.text.html.simpleparser
Imports iTextSharp.text.pdf
Imports iTextSharp.tool.xml
Imports System.Net
Imports iTextSharp.text.html
Imports System.Data.SqlClient
Imports OfficeOpenXml
Partial Class Production_Summary
    Inherits System.Web.UI.Page

    Dim objController As New Controller
    Private _getBase64String As Object
    Dim maindt As New DataTable
    Dim dtdownload As New DataTable
    Dim DIMDT As New DataTable
    Dim date_HRCbarplot As String = ""
    Dim data_HRCbarplot As String = ""
    Dim date_CASTbarplot As String = ""
    Dim data_CASTbarplot As String = ""
    Dim date_NET_YIELD_barplot As String = ""
    Dim data_NET_YIELD_barplot As String = ""
    Dim TOTAL_SPEC As String = ""
    Dim ddlprod As DropDownList = Nothing
    Function getdatatable(ByVal query As String) As DataTable
        Dim fndatatable As New DataTable
        Dim connection As String = "Password=Welcome@135;Pooling=False;Persist Security Info=True;User ID=153521;Initial Catalog=FP_PROCESS_DATA;Data Source=176.0.0.60\lptgsqldev"
        Using con As New SqlConnection(connection)
            Using cmd As New SqlCommand(query, con)
                cmd.CommandType = CommandType.Text
                Using sda As New SqlDataAdapter(cmd)
                    'Using dt As New DataTable()
                    sda.Fill(fndatatable)
                    'End Using
                End Using
            End Using
        End Using
        Return fndatatable
    End Function
    Private Property GetBase64String(url As String) As Object
        Get
            Return _getBase64String
        End Get
        Set(value As Object)
            _getBase64String = value
        End Set
    End Property

    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    'Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
    '    If Not Page.IsPostBack Then
    '        Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
    '        Dim frmDate As String = DateTime.Now.AddDays(-5).ToString("yyyy-MM-dd")
    '        Dim toDate As String = DateTime.Now.AddDays(-10).ToString("yyyy-MM-dd")

    '        Dim strfrmDt As String = frmDate
    '        Dim strToDt As String = toDate
    '        getdataForGrid(frmDate, toDate)
    '    End If
    'End Sub



    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    txtDate_TextChanged()

                End If
            Catch ex As Exception

            End Try

        End If

        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtEnd As String = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd")
                Dim dtStart As String = DateTime.Now.ToString("yyyy-MM-dd")

                Dim strfrmDt As String = dtStart
                Dim strToDt As String = dtEnd


                Dim Month As String = DateTime.Now.ToString("MM")

                Dim year As String = DateTime.Now.ToString("yyyy")

                Dim first_date As String = 1



                Dim stdate As String = year & "-" & Month & "-" & first_date
                '  Dim stdate As String = DateTime.Now.AddDays(-3).ToString("yyyy-MM-dd")
                Dim enddate As String = DateTime.Now.ToString("yyyy-MM-dd")

                'Dim stdate As String = hfFrom.Value
                'Dim enddate As String = hfTo.Value



                ' getdataForGrid(strfrmDt, strToDt)
                getdataForGrid(stdate, enddate)

                ' Populateprod(ddlprod, stdate, enddate)
                get_daywisedata_for_chart(stdate, enddate)

                DRAW_CHART_FOR_PROD_HRC(stdate, enddate)

                DRAW_CHART_FOR_PROD_CAST(stdate, enddate)
                DRAW_CHART_FOR_PROD_NET_YIELD(stdate, enddate)

                GETSPEC_TOTAL(stdate, enddate)

                'Dim sum, count As Double
                'For Each s As String In TOTAL_SPEC.Split(",")
                '    If Not String.IsNullOrEmpty(s) Then
                '        sum += s
                '        count += 1
                '    End If

                'Next
                'Dim VAL_SPEC As Decimal = sum / count
                'Dim SPECTOTAL As Decimal = FormatNumber(VAL_SPEC, 4)





                Dim QUERY = "Select top 1  * FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY]  where PRODUCTION ='HRC' order by DATETIME desc"

                Dim getdtSPEC As DataTable = getdatatable(QUERY)

                Dim SPECTOTAL As Decimal = getdtSPEC.Rows.Item(0)("CUM_SPEC_FUEL_CON")

                lblMAXDATETIME.Text = SPECTOTAL 'sum / count


            Catch ex As Exception
                Throw ex
            End Try
        End If

    End Sub



    Sub getdataForGrid(ByVal FromDt As String, ByVal ToDt As String)
        'Dim enDate As String = FromDt
        'Dim stDate As String = ToDt

        Dim enDate As String = ToDt
        Dim stDate As String = FromDt


        rptGRID.Visible = True

        maindt.Columns.Add("datetime")
        maindt.Columns.Add("PRODUCTION")
        maindt.Columns.Add("ON_DATE")
        maindt.Columns.Add("TO_DATE")
        maindt.Columns.Add("TOTAL_GAS_CON")
        maindt.Columns.Add("ON_SPEC_FUEL_CON")
        maindt.Columns.Add("Day_wise_Specific_Fuel_Consumption")

        Dim query As String = "Select CONVERT(VARCHAR(10),datetime,105) as datetime, [PRODUCTION], [ON_DATE], [TO_DATE],[TOTAL_GAS_CON],[ON_SPEC_FUEL_CON],[CUM_SPEC_FUEL_CON] FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY]  " &
                                   "where DATETIME between '" & stDate & "' and '" & enDate & "'  order by DATETIME,PRODUCTION ASC"



        Dim count As Short = 0
        Dim getdt As DataTable = getdatatable(query)

        Dim min As String = ""

        Dim max As String = ""
        Try
            If getdt.Rows.Count > 0 Then
                'For i As Integer = 0 To getdt.Rows.Count - 1
                '  Dim lfcdec_query As String = "select CONVERT(VARCHAR(10),datetime,120) as datetime,PRODUCTION,ON_DATE,TO_DATE,TOTAL_GAS_CON from TSCR_FURNACE_OPT_FINAL_SUMMARY  WHERE DATETIME BETWEEN '" & ToDt & "' AND '" & FromDt & "' order by DATETIME desc "

                Dim lfcdec_query As String = "SELECT CONVERT(VARCHAR(10),datetime,105) as datetime,   CAST(ROUND(avg(CV), 2) AS DECIMAL(10,2)) as cv FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]  Where  DATETIME between '" & stDate & "' and '" & enDate & "' and cv is not null  group by CONVERT(VARCHAR(10),datetime,105) 	order by CONVERT(VARCHAR(10),datetime,105) asc"

                Dim decisiondt As DataTable = getdatatable(lfcdec_query)
                If decisiondt.Rows.Count > 0 Then
                    Dim query1 As String = "Select CONVERT(VARCHAR(10),datetime,105) as datetime, [PRODUCTION], [ON_DATE], [TO_DATE],[TOTAL_GAS_CON], [ON_SPEC_FUEL_CON],[CUM_SPEC_FUEL_CON]  FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY]   " &
                                   "where DATETIME between '" & stDate & "' and '" & enDate & "' AND  PRODUCTION = 'HRC' order by DATETIME,PRODUCTION ASC"
                    Dim HRC As DataTable = getdatatable(query1)


                    Dim queryCAST As String = "Select CONVERT(VARCHAR(10),datetime,105) as datetime, [PRODUCTION], [ON_DATE], [TO_DATE],[TOTAL_GAS_CON],[ON_SPEC_FUEL_CON],[CUM_SPEC_FUEL_CON] FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY]   " &
                     "where DATETIME between '" & stDate & "' and '" & enDate & "' AND  PRODUCTION = 'CAST' order by DATETIME,PRODUCTION ASC"
                    Dim CAST As DataTable = getdatatable(queryCAST)

                    For j As Integer = 0 To getdt.Rows.Count - 1
                        Try


                            maindt.Rows.Add()

                            maindt(count)("datetime") = getdt.Rows.Item(j)(0)
                            maindt(count)("PRODUCTION") = getdt.Rows.Item(j)(1).Replace("NET YEILD", "NET YIELD") 'getdt.Rows.Item(j)(1)
                            maindt(count)("ON_DATE") = getdt.Rows.Item(j)(2)
                            maindt(count)("TO_DATE") = getdt.Rows.Item(j)(3)

                            If IsDBNull(getdt.Rows.Item(j)(4)) Then
                                maindt(count)("TOTAL_GAS_CON") = 0
                            Else
                                maindt(count)("TOTAL_GAS_CON") = getdt.Rows.Item(j)(4)
                            End If

                            'If IsDBNull(getdt.Rows.Item(j)(5)) Then
                            '    maindt(count)("CUM_SPEC_FUEL_CON") = 0
                            'Else
                            '    maindt(count)("CUM_SPEC_FUEL_CON") = getdt.Rows.Item(j)(5)
                            'End If



                            If maindt(count)("PRODUCTION") = getdt.Rows.Item(j)(1) Then
                                getdt.Rows.Item(j)(1).Replace("NET YEILD", "NET YIELD")
                            End If




                            ' Dim row As DataRow = decisiondt.Select("datetime='" & getdt.Rows(j)(0) & "'")(0) error coming out of index 22/08/2022 Ritika


                            Dim HRCDT As DataRow = HRC.Select("datetime='" & getdt.Rows(j)(0) & "'")(0)
                            Dim CAST_DT As DataRow = CAST.Select("datetime='" & getdt.Rows(j)(0) & "'")(0)

                            If IsDBNull(getdt.Rows.Item(j)(4)) And IsDBNull(getdt.Rows.Item(j)(2)) Then 'or replace from and  and getdt.rows.item(j)(2) from getdt.rows.item(j)(4)
                                maindt(count)("Day_wise_Specific_Fuel_Consumption") = 0

                            Else
                                'If maindt.Rows.Count = 1 Then
                                If maindt(count)("PRODUCTION") = "CAST" Then
                                    Dim valcast As Decimal = CAST_DT.Item(6) '((getdt.Rows.Item(j)(4) * row.Item(1)) / ((CAST_DT.Item(2)) * 1000000))
                                    Dim speccast As Decimal = 0.0
                                    speccast = FormatNumber(valcast, 4)
                                    ' maindt(count)("datetime") = getdt.Rows.Item(j)(0)

                                    maindt(count)("Day_wise_Specific_Fuel_Consumption") = speccast.ToString()
                                    '  maindt(count)("Day_wise_Specific_Fuel_Consumption") = speccast.ToString()

                                    Dim VALONDATECAST As Decimal = CAST_DT.Item(5) '((getdt.Rows.Item(j)(4) * row.Item(1)) / ((CAST_DT.Item(2)) * 1000000))
                                    Dim SPECONDATECAST As Decimal = 0.0
                                    SPECONDATECAST = FormatNumber(VALONDATECAST, 4)
                                    ' maindt(count)("datetime") = getdt.Rows.Item(j)(0)

                                    maindt(count)("ON_SPEC_FUEL_CON") = SPECONDATECAST.ToString()


                                ElseIf maindt(count)("PRODUCTION") = "HRC" Then
                                    Dim val As Decimal = HRCDT.Item(6) '((getdt.Rows.Item(j)(4) * row.Item(1)) / ((HRCDT.Item(2)) * 1000000))
                                    Dim spec As Decimal = 0.0
                                    spec = FormatNumber(val, 4)
                                    maindt(count)("Day_wise_Specific_Fuel_Consumption") = spec.ToString()


                                    Dim valONDATE As Decimal = HRCDT.Item(5) '((getdt.Rows.Item(j)(4) * row.Item(1)) / ((HRCDT.Item(2)) * 1000000))
                                    Dim specONDATE As Decimal = 0.0
                                    specONDATE = FormatNumber(valONDATE, 4)
                                    maindt(count)("ON_SPEC_FUEL_CON") = specONDATE.ToString()

                                End If

                            End If








                            count += 1

                        Catch ex As Exception
                            Continue For
                            Throw ex
                        End Try
                    Next '  End If

                    '  Next
                    '   End If
                    '  End If
                End If
                'Next
            Else
                ' maindt = '

            End If
            rptGRID.DataSource = maindt
            Session("Datatable") = maindt
            rptGRID.DataBind()
            Dim dtdll As DataTable = maindt.DefaultView.ToTable(True, "PRODUCTION")
            Dim ddl As DropDownList = CType(rptGRID.Controls(0).Controls(0).FindControl("ddlBRule"), DropDownList)
            ddl.DataSource = dtdll
            ddl.DataTextField = "PRODUCTION"
            ddl.DataValueField = "PRODUCTION"
            ddl.DataBind()
            ddl.Items.Insert(0, "All")
        Catch ex As Exception
            Throw ex
        End Try



    End Sub


    
    Protected Sub rptGRID_ItemDataBound(sender As Object, e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles rptGRID.ItemDataBound
        If rptGRID.Items.Count = 0 Then
            If e.Item.ItemType = ListItemType.Footer Then
                Dim dvNoRec As HtmlGenericControl = TryCast(e.Item.FindControl("dvNoRecords"), HtmlGenericControl)
                If dvNoRec IsNot Nothing Then
                    dvNoRec.Visible = True
                End If
            End If
        End If
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)
        ' Verifies that the control is rendered 

    End Sub
    Protected Sub btnDownload_Click(sender As Object, e As System.EventArgs) Handles btnDownload.Click

        'Try
        '        'gvCoilData1.Columns(0).Visible = False
        '        Response.ClearContent()
        '        Response.Buffer = True
        '    Response.AddHeader("content-disposition", String.Format("attachment; filename={0}", "report.xls"))
        '    Response.ContentEncoding = Encoding.UTF8
        '        Response.ContentType = "application/ms-excel"
        '        Dim sw As New StringWriter()
        '        Dim htw As New HtmlTextWriter(sw)
        '        rptGRID.RenderControl(htw)
        '        Response.Write(sw.ToString())
        '        Response.End()

        '    Catch ex As Exception
        '    Finally
        '        'gvCoilData1.Columns(0).Visible = True
        '    End Try
        Dim p As String = Request("__EVENTARGUMENT")
        If p = "date" Then
            Dim changedate_startdt As String = hfFrom.Value
            Dim changedate_enddtchangedate_enddt As String = hfTo.Value
            Dim dtchangedate As String = "Select CONVERT(VARCHAR(10),datetime,105) as DATETIME, [PRODUCTION], [ON_DATE], [TO_DATE],[TOTAL_GAS_CON],[ON_SPEC_FUEL_CON],[CUM_SPEC_FUEL_CON] FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY]   " &
                                   "where DATETIME between '" & changedate_startdt & "' and '" & changedate_enddtchangedate_enddt & "'  order by DATETIME ,PRODUCTION asc"
            Dim getchangedt As DataTable = getdatatable(dtchangedate)
        Else
            Dim dtstrt As String = hfFrom.Value ' DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd") '("yyyy-MM-dd")
            Dim dtend As String = hfTo.Value 'DateTime.Now.ToString("yyyy-MM-dd")



            'Dim dt As String = "Select CONVERT(VARCHAR(10),datetime,105) as datetime, [PRODUCTION], [ON_DATE], [TO_DATE],TOTAL_GAS_CON FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY]  " &
            '                           "where DATETIME between '" & dtstrt & "' and '" & dtend & "'  order by PRODUCTION asc"


            'Dim getdt As DataTable = getdatatable(dt)





            dtdownload.Columns.Add("DATETIME")
            dtdownload.Columns.Add("PRODUCTION")
            dtdownload.Columns.Add("ON_DATE", GetType(Double))
            dtdownload.Columns.Add("TO_DATE", GetType(Double))
            dtdownload.Columns.Add("TOTAL_GAS_CON", GetType(Double))
            dtdownload.Columns.Add("ON_SPEC_FUEL_CON", GetType(Double))
            dtdownload.Columns.Add("Day_wise_Specific_Fuel_Consumption", GetType(Double))

            Dim query As String = "Select CONVERT(VARCHAR(10),datetime,105) as datetime, [PRODUCTION], [ON_DATE], [TO_DATE],[TOTAL_GAS_CON],  [ON_SPEC_FUEL_CON],[CUM_SPEC_FUEL_CON]  FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY]   " &
                                       "where DATETIME between '" & dtstrt & "' and '" & dtend & "'  order by DATETIME,PRODUCTION asc"



            Dim count As Short = 0
            Dim getdt As DataTable = getdatatable(query)

            Dim min As String = ""

            Dim max As String = ""
            Try
                If getdt.Rows.Count > 0 Then
                    'For i As Integer = 0 To getdt.Rows.Count - 1
                    '  Dim lfcdec_query As String = "select CONVERT(VARCHAR(10),datetime,120) as datetime,PRODUCTION,ON_DATE,TO_DATE,TOTAL_GAS_CON from TSCR_FURNACE_OPT_FINAL_SUMMARY  WHERE DATETIME BETWEEN '" & ToDt & "' AND '" & FromDt & "' order by DATETIME desc "

                    Dim lfcdec_query As String = "SELECT CONVERT(VARCHAR(10),datetime,105) as datetime,   CAST(ROUND(avg(CV), 2) AS DECIMAL(10,2)) as cv FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]  Where  DATETIME between '" & dtstrt & "' and '" & dtend & "' and cv is not null  group by CONVERT(VARCHAR(10),datetime,105) 	order by CONVERT(VARCHAR(10),datetime,105) asc"

                    Dim decisiondt As DataTable = getdatatable(lfcdec_query)
                    If decisiondt.Rows.Count > 0 Then
                        Dim query1 As String = "Select CONVERT(VARCHAR(10),datetime,105) as datetime, [PRODUCTION], [ON_DATE], [TO_DATE],[TOTAL_GAS_CON], [ON_SPEC_FUEL_CON],[CUM_SPEC_FUEL_CON]  FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY]   " &
                                       "where DATETIME between '" & dtstrt & "' and '" & dtend & "' AND  PRODUCTION = 'HRC' order by DATETIME,PRODUCTION asc"
                        Dim HRC As DataTable = getdatatable(query1)

                        Dim queryCAST As String = "Select CONVERT(VARCHAR(10),datetime,105) as datetime, [PRODUCTION], [ON_DATE], [TO_DATE],[TOTAL_GAS_CON], [ON_SPEC_FUEL_CON],[CUM_SPEC_FUEL_CON]  FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY]   " &
                     "where DATETIME between '" & dtstrt & "' and '" & dtend & "' AND  PRODUCTION = 'CAST' order by DATETIME , PRODUCTION asc"
                        Dim CAST As DataTable = getdatatable(queryCAST)

                        For j As Integer = 0 To getdt.Rows.Count - 1
                            Try
                                dtdownload.Rows.Add()

                                dtdownload(count)("DATETIME") = getdt.Rows.Item(j)(0)
                                dtdownload(count)("PRODUCTION") = getdt.Rows.Item(j)(1).Replace("NET YEILD", "NET YIELD") 'getdt.Rows.Item(j)(1)
                                dtdownload(count)("ON_DATE") = getdt.Rows.Item(j)(2)
                                dtdownload(count)("TO_DATE") = getdt.Rows.Item(j)(3)

                                If IsDBNull(getdt.Rows.Item(j)(4)) Then
                                    dtdownload(count)("TOTAL_GAS_CON") = 0
                                Else
                                    dtdownload(count)("TOTAL_GAS_CON") = getdt.Rows.Item(j)(4)
                                End If

                                'If dtdownload(count)("PRODUCTION") = getdt.Rows.Item(j)(1) Then
                                '    getdt.Rows.Item(j)(1).Replace("NET YEILD", "NET YIELD")
                                'End If

                                '  Dim row As DataRow = decisiondt.Select("DATETIME='" & getdt.Rows(j)(0) & "'")(0)


                                Dim HRCDT As DataRow = HRC.Select("DATETIME='" & getdt.Rows(j)(0) & "'")(0)
                                Dim CAST_DT As DataRow = CAST.Select("datetime='" & getdt.Rows(j)(0) & "'")(0)

                                If IsDBNull(getdt.Rows.Item(j)(4)) And IsDBNull(getdt.Rows.Item(j)(2)) Then 'or replace from and  and getdt.rows.item(j)(2) from getdt.rows.item(j)(4)

                                    dtdownload(count)("Day_wise_Specific_Fuel_Consumption") = 0

                                Else

                                    'For



                                    If dtdownload.Rows(count)("PRODUCTION") = "CAST" Then
                                        Dim valcast As Decimal = CAST_DT.Item(6) '((getdt.Rows.Item(j)(4) * row.Item(1)) / ((CAST_DT.Item(2)) * 1000000))
                                        Dim speccast As Decimal = 0.0
                                        speccast = FormatNumber(valcast, 4)

                                        dtdownload(count)("Day_wise_Specific_Fuel_Consumption") = speccast.ToString()

                                        Dim VALONDATECAST As Decimal = CAST_DT.Item(5) '((getdt.Rows.Item(j)(4) * row.Item(1)) / ((CAST_DT.Item(2)) * 1000000))
                                        Dim SPECONDATECAST As Decimal = 0.0
                                        SPECONDATECAST = FormatNumber(VALONDATECAST, 4)
                                        ' maindt(count)("datetime") = getdt.Rows.Item(j)(0)

                                        dtdownload(count)("ON_SPEC_FUEL_CON") = SPECONDATECAST.ToString()

                                    End If


                                    If dtdownload.Rows(count)("PRODUCTION") = "HRC" Then
                                        Dim val As Decimal = HRCDT.Item(6) '((getdt.Rows.Item(j)(4) * row.Item(1)) / ((HRCDT.Item(2)) * 1000000))
                                        Dim spec As Decimal = 0.0
                                        spec = FormatNumber(val, 4)
                                        dtdownload(count)("Day_wise_Specific_Fuel_Consumption") = spec.ToString()


                                        Dim valONDATE As Decimal = HRCDT.Item(5) '((getdt.Rows.Item(j)(4) * row.Item(1)) / ((HRCDT.Item(2)) * 1000000))
                                        Dim specONDATE As Decimal = 0.0
                                        specONDATE = FormatNumber(valONDATE, 4)
                                        dtdownload(count)("ON_SPEC_FUEL_CON") = specONDATE.ToString()


                                    End If






                                    'If CAST.Rows(1)("PRODUCTION") = "CAST"  Then
                                    '    Dim valcast As Decimal = ((getdt.Rows.Item(j)(4) * row.Item(1)) / ((CAST_DT.Item(2)) * 1000000))
                                    '    Dim speccast As Decimal = 0.0
                                    '    speccast = FormatNumber(valcast, 4)

                                    '    dtdownload(count)("Day_wise_Specific_Fuel_Consumption") = speccast.ToString()
                                    'ElseIf HRC.Rows(1)("PRODUCTION") = "HRC" Then
                                    'Dim val As Decimal = ((getdt.Rows.Item(j)(4) * row.Item(1)) / ((HRCDT.Item(2)) * 1000000))
                                    '    Dim spec As Decimal = 0.0
                                    '    spec = FormatNumber(val, 4)
                                    '    dtdownload(count)("Day_wise_Specific_Fuel_Consumption") = spec.ToString()
                                    'End If



                                    'Dim val As Decimal = ((getdt.Rows.Item(j)(4) * row.Item(1)) / ((HRCDT.Item(2)) * 1000000))
                                    'Dim spec As Decimal = FormatNumber(val, 4)
                                    'dtdownload(count)("Day_wise_Specific_Fuel_Consumption") = spec ' ((getdt.Rows.Item(j)(4) * row.Item(1)) / ((HRCDT.Item(2)) * 1000000))

                                End If

                                count += 1

                            Catch ex As Exception

                                dtdownload(count)("Day_wise_Specific_Fuel_Consumption") &= "0" '((getdt.Rows.Item(j)(4) * row.Item(1)) / ((HRCDT.Item(2)) * 1000000)) & ","

                                Continue For ' Throw ex
                            End Try
                        Next

                    End If

                Else

                End If
                dtdownload.DefaultView.Sort = "datetime desc "
                Dim datavalue As DataTable = dtdownload

                downloadfile(datavalue)

            Catch ex As Exception
                Throw ex
            End Try




        End If






    End Sub

    Protected Sub downloadfile(ByVal dt As DataTable)
        'Response.Clear()
        'Response.ClearHeaders()
        'Response.ClearContent()
        'Response.Buffer = True
        'Response.AddHeader("content-disposition", String.Format("attachment; filename={0}", "report.xls"))
        'Response.ContentEncoding = Encoding.UTF8
        'Response.ContentType = "application/ms-excel"

        'Response.Write(hfData.Value.Replace("&gt;", ">").Replace("&lt;", "<"))
        'Response.Flush()
        'Response.End()


        HttpContext.Current.Response.Clear()
        HttpContext.Current.Response.ClearContent()
        HttpContext.Current.Response.ClearHeaders()
        HttpContext.Current.Response.Buffer = True
        HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.UTF8
        HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache)
        HttpContext.Current.Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        HttpContext.Current.Response.AddHeader("content-disposition", "attachment;filename=export.xlsx")



        Using pack As New ExcelPackage()
            Dim ws As ExcelWorksheet = pack.Workbook.Worksheets.Add("export")
            ws.Cells("A1").LoadFromDataTable(dt, True)
            ws.Cells.Style.Font.SetFromFont(New System.Drawing.Font("Calibri", 12))
            ws.Cells.AutoFitColumns()

            Using objRange As ExcelRange = ws.Cells("A1:F1")

                objRange.Style.Font.Bold = True
                objRange.Style.HorizontalAlignment = Style.ExcelHorizontalAlignment.Center
                objRange.Style.VerticalAlignment = Style.ExcelVerticalAlignment.Center
                ' ws.Cells["A1:A25"].Style.Numberformat.Format = "0.00";
            End Using







            Dim stval, enval As String
            Dim fromrow, torow As Integer
            For i As Integer = 2 To ws.Dimension.End.Row

                If stval = "" Then
                    fromrow = i
                    stval = ws.Cells(i, 1).Value
                End If
                For j As Integer = i + 1 To ws.Dimension.End.Row
                    enval = ws.Cells(i + 1, 1).Value
                    If stval = enval Then
                        torow = j
                        '  ws.Cells.Style.Numberformat.Format = "0.00"
                        Continue For
                    Else
                        ' Style.Numberformat.Format = "0.00"
                        ' ws.Cells("F" & fromrow & ":F" & torow).Merge = True
                        stval = enval
                        i = j - 1
                        fromrow = j
                        ' ws.Cells.Style.Numberformat.Format = "0.00"
                    End If
                Next

            Next
            ' ws.Cells("C:f").Style.Numberformat.Format = "#,##0.00"
            ' ws.Cells("C:f").Style.Numberformat.Format = "0%"
            ' File.WriteAllBytes(OUTPUT, package.GetAsByteArray());
            ' ws.Cells.Style.Numberformat.Format = "0.00"
            ' ws.Cells("F" & fromrow & ":F" & torow).Merge = True

            '  ws.Cells("C:f").Style.Numberformat.Format = "#,##0.00"
            '  File.WriteAllBytes(OUTPUT, package.GetAsByteArray())
            Dim MS As New System.IO.MemoryStream()
            pack.SaveAs(MS)
            MS.WriteTo(HttpContext.Current.Response.OutputStream)
        End Using


        HttpContext.Current.Response.Flush()

    End Sub

    

    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try

            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            getdataForGrid(dtStart, dtEnd)

            get_daywisedata_for_chart(dtStart, dtEnd)

            DRAW_CHART_FOR_PROD_HRC(dtStart, dtEnd)
            DRAW_CHART_FOR_PROD_CAST(dtStart, dtEnd)
            DRAW_CHART_FOR_PROD_NET_YIELD(dtStart, dtEnd)

        Catch ex As Exception

        End Try
    End Sub




    Sub DRAW_CHART_FOR_PROD_HRC(ByVal fromDt As String, ByVal toDt As String)
        Try

            ''  Dim frmDate As String = DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 6, 0, 0)
            'Dim frmDate As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            'Dim toDate As String = DateTime.Now.AddMonths(0).ToString("yyyy-MM-dd HH:mm:ss")

            Dim strToDt As String = toDt
            Dim strfrmDt As String = fromDt

            'Dim GETDDT_maindtChart As DataSet = objController.GETDDT_Chart(strfrmDt, strToDt) 'frmDate, toDate(02/11/2021)
            'Dim get_HRC As DataSet = objController.getHRC(strfrmDt, strToDt) 'frmDate, toDate(02/11/2021)
            'Dim GET_CV_VALUE As DataSet = objController.GETCV_vALUE(strfrmDt, strToDt) 'frmDate, toDate(02/11/2021)



            Dim dstemp As DataSet = objController.GetDateForHRC_SUMMARY_Report_Chart(strfrmDt, strToDt) 'frmDate, toDate(02/11/2021)
            PLOT_ECHART_PROD(dstemp.Tables(0), Literal1, "container1", "plot1", data_HRCbarplot)


        Catch ex As Exception
            Throw ex
        End Try


    End Sub
    Sub DRAW_CHART_FOR_PROD_CAST(ByVal fromDt As String, ByVal toDt As String)
        Try

            ''  Dim frmDate As String = DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 6, 0, 0)
            'Dim frmDate As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            'Dim toDate As String = DateTime.Now.AddMonths(0).ToString("yyyy-MM-dd HH:mm:ss")

            Dim strfrmDt As String = fromDt
            Dim strToDt As String = toDt



            Dim dstemp As DataSet = objController.GetDateForCAST_SUMMARY_Report_Chart(strfrmDt, strToDt) 'frmDate, toDate(02/11/2021)
            PLOT_ECHART_PROD(dstemp.Tables(0), Literal2, "container2", "plot2", data_CASTbarplot)


        Catch ex As Exception
            Throw ex
        End Try


    End Sub
    Sub DRAW_CHART_FOR_PROD_NET_YIELD(ByVal fromDt As String, ByVal toDt As String)
        Try

            ''  Dim frmDate As String = DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 6, 0, 0)
            'Dim frmDate As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            'Dim toDate As String = DateTime.Now.AddMonths(0).ToString("yyyy-MM-dd HH:mm:ss")

            Dim strfrmDt As String = fromDt
            Dim strToDt As String = toDt


            Dim dstemp As DataSet = objController.GetDateForNET_YIELD_SUMMARY_Report_Chart(strfrmDt, strToDt) 'frmDate, toDate(02/11/2021)
            '  PLOT_ECHART_PROD(dstemp.Tables(0), Literal3, "container3", "plot3", data_NET_YIELD_barplot)
            plot_3_chart(dstemp.Tables(0), Literal3, "container3", "plot3")

        Catch ex As Exception
            Throw ex
        End Try


    End Sub


    Public Sub plot_3_chart(ByVal dt As DataTable, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String)
        Try
            LiteralName.Text = ""
            Dim ticks As String

            ' dt.DefaultView.Sort = "DAY asc"
            Dim line1, line2, line3 As String
            For i As Integer = 0 To dt.Rows.Count - 1
                If i > 0 Then
                    ticks &= ","
                    line1 &= ","
                    line2 &= ","
                    'line3 &= ","
                End If
                ticks &= "'" & dt.Rows(i)(0) & "'"
                If IsDBNull(dt.Rows(i)(1)) Then
                    line1 &= 0
                Else
                    line1 &= dt.Rows(i)(1)
                End If
                If IsDBNull(dt.Rows(i)(2)) Then
                    line2 &= 0
                Else
                    line2 &= dt.Rows(i)(2)
                End If

            Next

            Dim s As New StringBuilder("<script>")

            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            s.Append("var myChart = echarts.init(document.getElementById('" & ContainerName & "'));")
            s.Append("option = {    tooltip: {   trigger: 'axis',  axisPointer: {   type: 'cross', crossStyle: {   color: '#999'  }  } },")
            s.Append("toolbox: {  feature: {  dataView: {show: true, readOnly: false},  magicType: {show: true, type: ['line', 'bar']},  restore: {show: true},  saveAsImage: {show: true}  }  },")
            s.Append("legend: {  orient: 'vertical',bottom: 'bottom', data: ['ON DATE YIELD','CUMULATIVE YIELD'],  center: '1%',textStyle:  {  fontSize: 8} },")
            s.Append("xAxis: [ {  type: 'category',  data: [" & ticks & "],    axisPointer: { type: 'shadow'   }       }   ],   ")
            s.Append("yAxis: [  {   type: 'value',splitLine:{show:false}, name: 'ON DATE YIELD', nameTextStyle:{fontSize:8}, max: 150,  axisLabel: {  formatter: '{value}'    }    },      {    type: 'value',         name: 'CUMULATIVE YIELD', nameTextStyle:{fontSize:8},  max: 150,   axisLabel: {            formatter: '{value}'        }        }   ],")
            s.Append("series: [  {   name: 'ON DATE YIELD',  type: 'bar',  data: [" & line1 & "]  },   {           name: 'CUMULATIVE YIELD',           type: 'bar',    yAxisIndex: 1, data: [" & line2 & "]")
            s.Append("}   ]};")

            s.Append(" myChart.setOption(option);")
            s.Append("</script>")
            LiteralName.Text = s.ToString()
        Catch ex As Exception
            Dim i As String = ""

        End Try

    End Sub





    Public Sub PLOT_ECHART_PROD(ByVal dt As DataTable, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal DT_LINE3 As String)
        Try
            LiteralName.Text = ""
            Dim ticks As String

            ' dt.DefaultView.Sort = "DAY asc"
            Dim line1, line2, line3 As String
            For i As Integer = 0 To dt.Rows.Count - 1
                If i > 0 Then
                    ticks &= ","
                    line1 &= ","
                    line2 &= ","
                    line3 = DT_LINE3 'String.Format("{0:0.00}", Convert.ToDecimal(DT_LINE3)) 'String.Format("{0:0.00}", DT_LINE3) 'DT_LINE3
                End If
                ticks &= "'" & dt.Rows(i)(0) & "'"
                If IsDBNull(dt.Rows(i)(1)) Then
                    line1 &= 0
                Else
                    line1 &= dt.Rows(i)(1)
                End If
                If IsDBNull(dt.Rows(i)(2)) Then
                    line2 &= 0
                Else
                    line2 &= dt.Rows(i)(2)
                End If
                '  If IsDBNull(HRC_DT_LINE3) Then
                'ine3 &= 0
                '   Else
                'line3 &= HRC_DT_LINE3
                '  End If
            Next
            'line3 = String.Format("{0:0.00}", DT_LINE3)
            Dim s As New StringBuilder("<script>")

            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            s.Append("var myChart = echarts.init(document.getElementById('" & ContainerName & "'));")
            s.Append("option = {    tooltip: {   trigger: 'axis',  axisPointer: {   type: 'cross', crossStyle: {   color: '#999'  }  } },")
            s.Append("toolbox: {  feature: {  dataView: {show: true, readOnly: false},  magicType: {show: true, type: ['line', 'bar']},  restore: {show: true},  saveAsImage: {show: true}  }  },")
            s.Append("legend: {   orient: 'vertical',bottom: 'bottom', data: ['ON DATE PRODUCTION','CUMULATIVE PRODUCTION','SPECIFIC FUEL CON'] ,  center: '1%',textStyle:  {  fontSize: 8} },")
            s.Append("xAxis: [ {  type: 'category',  data: [" & ticks & "],    axisPointer: { type: 'shadow'   }       }   ],   ")
            s.Append("yAxis: [  {   type: 'value',splitLine:{show:false}, name: 'ON DATE PRODUCTION',  nameTextStyle:{fontSize:8},  axisLabel: {  formatter: '{value}'    }    },     {   type: 'value', name: 'SPECIFIC FUEL CON',  nameTextStyle:{fontSize:8}, min: 0 ,  axisLabel: {  formatter: '{value}'  }    },       ],")
            s.Append("series: [  {   name: 'ON DATE PRODUCTION',  type: 'bar',  data: [" & line1 & "]  },   {           name: 'CUMULATIVE PRODUCTION',           type: 'bar',  data: [" & line2 & "]}, {           name: 'SPECIFIC FUEL CON',           type: 'line',    yAxisIndex: 1, data: [" & line3 & "]")
            s.Append("}   ]};")

            s.Append(" myChart.setOption(option);")
            s.Append("</script>")
            LiteralName.Text = s.ToString()
        Catch ex As Exception
            Dim i As String = ""

        End Try

    End Sub





    Sub get_daywisedata_for_chart(ByVal FromDt As String, ByVal ToDt As String)
        Dim enDate As String = ToDt
        Dim stDate As String = FromDt

        Dim query As String = "Select CONVERT(VARCHAR(10),datetime,120) as datetime, [PRODUCTION], [ON_DATE], [TO_DATE],[TOTAL_GAS_CON],[CUM_SPEC_FUEL_CON] FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY]    " &
                                   "where DATETIME between '" & stDate & "' and '" & enDate & "' and PRODUCTION = 'HRC' order by DATETIME asc"

        Dim count As Short = 0
        Dim getdt As DataTable = getdatatable(query)

        Dim queryCAST_DT As String = "Select CONVERT(VARCHAR(10),datetime,120) as datetime, [PRODUCTION], [ON_DATE], [TO_DATE],[TOTAL_GAS_CON],[CUM_SPEC_FUEL_CON] FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY]    " &
                                   "where DATETIME between '" & stDate & "' and '" & enDate & "' and PRODUCTION = 'CAST' order by DATETIME asc"

        ' Dim count As Short = 0
        Dim getCAST_dt As DataTable = getdatatable(queryCAST_DT)

        Dim query_NET_YIELD_DT As String = "Select CONVERT(VARCHAR(10),datetime,120) as datetime, [PRODUCTION], [ON_DATE], [TO_DATE],[TOTAL_GAS_CON],[CUM_SPEC_FUEL_CON] FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY]   " &
                                   "where DATETIME between '" & stDate & "' and '" & enDate & "' and PRODUCTION = 'NET YEILD'  order by DATETIME asc"

        ' Dim count As Short = 0
        Dim getNET_YIELD_dt As DataTable = getdatatable(query_NET_YIELD_DT)







        Dim lfcdec_query As String = "SELECT CONVERT(VARCHAR(10),datetime,120) as datetime,   CAST(ROUND(avg(CV), 2) AS DECIMAL(10,2)) as cv FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]  Where  DATETIME between '" & stDate & "' and '" & enDate & "' and cv is not null group by CONVERT(VARCHAR(10),datetime,120) 	order by CONVERT(VARCHAR(10),datetime,120) asc"

        Dim decisiondt As DataTable = getdatatable(lfcdec_query)

        Dim min As String = ""
        Dim max As String = ""
        Try
            If getdt.Rows.Count > 0 Then

                If decisiondt.Rows.Count > 0 Then
                    Dim query1 As String = "Select CONVERT(VARCHAR(10),datetime,120) as datetime, [PRODUCTION], [ON_DATE], [TO_DATE],[TOTAL_GAS_CON],[CUM_SPEC_FUEL_CON] FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY]    " &
                                   "where DATETIME between '" & stDate & "' and '" & enDate & "'  AND  PRODUCTION = 'HRC' order by DATETIME asc"
                    Dim HRC As DataTable = getdatatable(query1)

                    For j As Integer = 0 To getdt.Rows.Count - 1
                        Try
                            'Dim row As DataRow = decisiondt.Select("datetime='" & getdt.Rows(j)(0) & "'")(0)


                            Dim HRCDT As DataRow = HRC.Select("datetime='" & getdt.Rows(j)(0) & "'")(0)
                            'Dim CAST_DT As DataRow = CAST.Select("datetime='" & getdt.Rows(j)(0) & "'")(0)
                            'Dim NETYIELD_DT As DataRow = NET_YIELD.Select("datetime='" & getdt.Rows(j)(0) & "'")(0)

                            If IsDBNull(getdt.Rows.Item(j)(4)) Or IsDBNull(getdt.Rows.Item(j)(2)) Then 'or replace from and  and getdt.rows.item(j)(2) from getdt.rows.item(j)(4)


                                date_HRCbarplot &= "'" & getdt.Rows(j)(0).ToString & "',"
                                data_HRCbarplot &= 0 & ","
                                'date_CASTbarplot &= "'" & getdt.Rows(j)(0).ToString & "',"
                                'data_CASTbarplot &= 0 & ","
                                'date_NET_YIELD_barplot &= "'" & getdt.Rows(j)(0).ToString & "',"
                                'data_NET_YIELD_barplot = 0 & ","
                                '' maindt(count)("Day_wise_Specific_Fuel_Consumption") = 0

                            Else
                                '(Total Gas consumption * avg(CV))/(Total Throughput*1000000)

                                ' maindt(count)("Day_wise_Specific_Fuel_Consumption") = ((getdt.Rows.Item(j)(4) * row.Item(1)) / ((HRCDT.Item(2)) * 1000000))

                                'Dim val As Decimal = ((getdt.Rows.Item(j)(4) * row.Item(1)) / ((HRCDT.Item(2)) * 1000000))
                                'Dim spec As Decimal = FormatNumber(val, 4)
                                ''  maindt(count)("Day_wise_Specific_Fuel_Consumption") = spec ' ((getdt.Rows.Item(j)(4) * row.Item(1)) / ((HRCDT.Item(2)) * 1000000))




                                date_HRCbarplot &= "'" & getdt.Rows(j)(0).ToString & "',"
                                Dim valhrc As Decimal = HRCDT.Item(5) '((getdt.Rows.Item(j)(4) * row.Item(1)) / ((HRCDT.Item(2)) * 1000000))
                                Dim spechrc As Decimal = FormatNumber(valhrc, 4)




                                data_HRCbarplot &= spechrc & "," '((getdt.Rows.Item(j)(4) * row.Item(1)) / ((HRCDT.Item(2)) * 1000000)) & ","




                                'date_CASTbarplot &= "'" & getdt.Rows(j)(0).ToString & "',"
                                'data_CASTbarplot &= ((getdt.Rows.Item(j)(4) * row.Item(1)) / ((CAST_DT.Item(2)) * 1000000)) & ","
                                'date_NET_YIELD_barplot &= "'" & getdt.Rows(j)(0).ToString & "',"
                                'data_NET_YIELD_barplot &= ((getdt.Rows.Item(j)(4) * row.Item(1)) / ((NETYIELD_DT.Item(2)) * 1000000)) & ","

                            End If
                            ' End If
                            count += 1
                        Catch ex As Exception

                            data_HRCbarplot &= "," '((getdt.Rows.Item(j)(4) * row.Item(1)) / ((HRCDT.Item(2)) * 1000000)) & ","

                            Continue For ' Throw ex
                        End Try
                    Next

                End If

            End If


        Catch ex As Exception
            Throw ex
        End Try

        Try
            If getCAST_dt.Rows.Count > 0 Then

                If decisiondt.Rows.Count > 0 Then

                    Dim queryCAST As String = "Select CONVERT(VARCHAR(10),datetime,120) as datetime, [PRODUCTION], [ON_DATE], [TO_DATE],[TOTAL_GAS_CON],[CUM_SPEC_FUEL_CON]  FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY]  " &
                                   "where DATETIME between '" & stDate & "' and '" & enDate & "'    AND  PRODUCTION = 'CAST' order by DATETIME asc"
                    Dim CAST As DataTable = getdatatable(queryCAST)

                    For j As Integer = 0 To getCAST_dt.Rows.Count - 1
                        Try
                            ' Dim row As DataRow = decisiondt.Select("datetime='" & getCAST_dt.Rows(j)(0) & "'")(0)


                            Dim CAST_DT As DataRow = CAST.Select("datetime='" & getCAST_dt.Rows(j)(0) & "'")(0)

                            If IsDBNull(getCAST_dt.Rows.Item(j)(4)) Or IsDBNull(getCAST_dt.Rows.Item(j)(2)) Then 'or replace from and  and getdt.rows.item(j)(2) from getdt.rows.item(j)(4)
                                date_CASTbarplot &= "'" & getCAST_dt.Rows(j)(0).ToString & "',"
                                data_CASTbarplot &= 0 & ","

                            Else
                                date_CASTbarplot &= "'" & getCAST_dt.Rows(j)(0).ToString & "',"

                                Dim valcast As Decimal = CAST_DT.Item(5) ' ((getCAST_dt.Rows.Item(j)(4) * row.Item(1)) / ((CAST_DT.Item(2)) * 1000000))
                                Dim speccast As Decimal = FormatNumber(valcast, 4)


                                data_CASTbarplot &= speccast & ","   '((getCAST_dt.Rows.Item(j)(4) * row.Item(1)) / ((CAST_DT.Item(2)) * 1000000)) & ","

                            End If
                            ' End If
                            count += 1
                        Catch ex As Exception
                            data_CASTbarplot &= ","
                            Continue For ' Throw ex
                        End Try
                    Next



                End If
                'Next

            End If


        Catch ex As Exception
            Throw ex
        End Try


        Try
            If getNET_YIELD_dt.Rows.Count > 0 Then

                If decisiondt.Rows.Count > 0 Then

                    Dim queryNET_YIELD As String = "Select CONVERT(VARCHAR(10),datetime,120) as datetime, [PRODUCTION], [ON_DATE], [TO_DATE],[TOTAL_GAS_CON],[CUM_SPEC_FUEL_CON]  FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY]  " &
                                  "where DATETIME between '" & stDate & "' and '" & enDate & "' AND  PRODUCTION = 'NET YEILD' order by DATETIME asc"
                    Dim NET_YIELD As DataTable = getdatatable(queryNET_YIELD)

                    For j As Integer = 0 To getNET_YIELD_dt.Rows.Count - 1
                        Try
                            ' Dim row As DataRow = decisiondt.Select("datetime='" & getNET_YIELD_dt.Rows(j)(0) & "'")(0)


                            Dim NETYIELD_DT As DataRow = NET_YIELD.Select("datetime='" & getNET_YIELD_dt.Rows(j)(0) & "'")(0)

                            If IsDBNull(getNET_YIELD_dt.Rows.Item(j)(4)) Or IsDBNull(getNET_YIELD_dt.Rows.Item(j)(2)) Then 'or replace from and  and getdt.rows.item(j)(2) from getdt.rows.item(j)(4)
                                date_NET_YIELD_barplot &= "'" & getNET_YIELD_dt.Rows(j)(0).ToString & "',"
                                data_NET_YIELD_barplot = 0 & ","

                            Else
                                date_NET_YIELD_barplot &= "'" & getNET_YIELD_dt.Rows(j)(0).ToString & "',"

                                Dim valyield As Decimal = NETYIELD_DT.Item(5) ' ((getNET_YIELD_dt.Rows.Item(j)(4) * row.Item(1)) / ((NETYIELD_DT.Item(2)) * 1000000))
                                Dim specyield As Decimal = FormatNumber(valyield, 4)



                                data_NET_YIELD_barplot &= specyield & "," '((getNET_YIELD_dt.Rows.Item(j)(4) * row.Item(1)) / ((NETYIELD_DT.Item(2)) * 1000000)) & ","

                            End If

                            count += 1
                        Catch ex As Exception
                            data_NET_YIELD_barplot &= ","
                            Continue For ' Throw ex
                        End Try
                    Next

                End If


            End If


        Catch ex As Exception
            Throw ex
        End Try


    End Sub


    Sub GETSPEC_TOTAL(ByVal FromDt As String, ByVal ToDt As String)
        Dim enDate As String = ToDt
        Dim stDate As String = FromDt

        Dim query As String = "Select CONVERT(VARCHAR(10),datetime,120) as datetime, [PRODUCTION], [ON_DATE], [TO_DATE], [TOTAL_GAS_CON],[CUM_SPEC_FUEL_CON]  FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY]  " &
                                   "where DATETIME between '" & stDate & "' and '" & enDate & "' and PRODUCTION = 'HRC'    order by DATETIME asc"

        Dim count As Short = 0
        Dim getdt As DataTable = getdatatable(query)








        Dim lfcdec_query As String = "SELECT CONVERT(VARCHAR(10),datetime,120) as datetime,   CAST(ROUND(avg(CV), 2) AS DECIMAL(10,2)) as cv FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL]  Where  DATETIME between '" & stDate & "' and '" & enDate & "' and cv is not null group by CONVERT(VARCHAR(10),datetime,120) 	order by CONVERT(VARCHAR(10),datetime,120) asc"

        Dim decisiondt As DataTable = getdatatable(lfcdec_query)

        Dim min As String = ""
        Dim max As String = ""
        Try
            If getdt.Rows.Count > 0 Then

                If decisiondt.Rows.Count > 0 Then
                    Dim query1 As String = "Select CONVERT(VARCHAR(10),datetime,120) as datetime, [PRODUCTION], [ON_DATE], [TO_DATE],[TOTAL_GAS_CON],[CUM_SPEC_FUEL_CON]  FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY]   " &
                                   "where DATETIME between '" & stDate & "' and '" & enDate & "'   and PRODUCTION ='HRC' order by DATETIME asc"
                    Dim HRC As DataTable = getdatatable(query1)

                    For j As Integer = 0 To getdt.Rows.Count - 1
                        Try
                            'Dim row As DataRow = decisiondt.Select("datetime='" & getdt.Rows(j)(0) & "'")(0)


                            Dim HRCDT As DataRow = HRC.Select("datetime='" & getdt.Rows(j)(0) & "'")(0)

                            If IsDBNull(getdt.Rows.Item(j)(4)) Or IsDBNull(getdt.Rows.Item(j)(2)) Then 'or replace from and  and getdt.rows.item(j)(2) from getdt.rows.item(j)(4)


                                '  TOTAL_SPEC &= "'" & getdt.Rows(j)(0).ToString & "',"
                                TOTAL_SPEC &= 0 & ","

                            Else

                                ' TOTAL_SPEC &= "'" & getdt.Rows(j)(0).ToString & "',"
                                Dim valhrc As Decimal = HRCDT.Item(5) ' ((getdt.Rows.Item(j)(4) * row.Item(1)) / ((HRCDT.Item(2)) * 1000000))
                                Dim spe_totalhrc As Decimal = FormatNumber(valhrc, 4)




                                TOTAL_SPEC &= spe_totalhrc & ","
                            End If
                            ' End If
                            count += 1
                        Catch ex As Exception

                            TOTAL_SPEC &= "," '((getdt.Rows.Item(j)(4) * row.Item(1)) / ((HRCDT.Item(2)) * 1000000)) & ","

                            Continue For ' Throw ex
                        End Try
                    Next

                End If

            End If


        Catch ex As Exception
            Throw ex
        End Try



    End Sub

    'Public Sub Populateprod(ByVal prodDropDown As DropDownList, ByVal FromDate As String, ByVal ToDate As String)
    '    Try

    '        Dim query1 As String = "SELECT distinct PRODUCTION FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY]  where PRODUCTION between '" & FromDate & "' and '" & ToDate & "' ORDER BY PRODUCTION"
    '        Dim HRC As DataTable = getdatatable(query1)
    '        prodDropDown.DataSource = HRC
    '        '  GradeDropDown.DataSource = GetDataSetFromQuery("SELECT distinct PRM_CD_GRADE from T_CGL_FUR_PARAM where PRM_TS_END between '" & FromDate & "' and '" & ToDate & "' ORDER BY PRM_CD_GRADE").Tables(0)
    '        prodDropDown.DataTextField = "PRODUCTION"
    '        prodDropDown.DataValueField = "PRODUCTION"
    '        prodDropDown.DataBind()
    '        prodDropDown.Items.Insert(0, "All")
    '        prodDropDown.SelectedIndex = 0
    '    Catch ex As Exception
    '        Throw New Exception(ex.ToString())
    '    End Try


    'End Sub
    ''Protected Sub OnItemDataBound(ByVal FromDate As String, ByVal ToDate As String, ByVal e As RepeaterItemEventArgs)
    '    If e.Item.ItemType = ListItemType.Item OrElse e.Item.ItemType = ListItemType.AlternatingItem Then
    '        'Find the DropDownList in the Repeater Item.
    '        Dim ddlCountries As DropDownList = (TryCast(e.Item.FindControl("ddlBRule"), DropDownList))

    '        Dim query1 As String = "SELECT distinct PRODUCTION FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY]  where PRODUCTION between '" & FromDate & "' and '" & ToDate & "' ORDER BY PRODUCTION"
    '        Dim HRC As DataTable = getdatatable(query1)

    '        ddlCountries.DataSource = getdatatable("SELECT distinct PRODUCTION FROM [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_OPT_FINAL_SUMMARY]  where PRODUCTION between '" & FromDate & "' and '" & ToDate & "' ORDER BY PRODUCTION")
    '        ddlCountries.DataTextField = "PRODUCTION"
    '        ddlCountries.DataValueField = "PRODUCTION"
    '        ddlCountries.DataBind()

    '        'Add Default Item in the DropDownList.
    '        ddlCountries.Items.Insert(0, "All")

    '        'Select the Country of Customer in DropDownList.
    '        Dim country As String = (TryCast(e.Item.DataItem, DataRowView))("PRODUCTION").ToString()
    '        ddlCountries.Items.FindByValue(country).Selected = True
    '    End If
    'End Sub


    Protected Sub ddlBRule_SelectedIndexChanged(sender As Object, e As EventArgs)
        Dim dt As DataTable = CType(Session("Datatable"), DataTable)
        Dim dtdll As DataTable = dt.DefaultView.ToTable(True, "PRODUCTION")
        Dim ddl As DropDownList = CType(sender, DropDownList)
        Dim selitem As String = "All"
        Dim selectedIndex As Integer = ddl.SelectedIndex
        If ddl.SelectedItem.Value <> "All" Then
            dt = dt.Select("PRODUCTION='" & ddl.SelectedItem.Text & "'").CopyToDataTable
        End If
        rptGRID.DataSource = dt
        rptGRID.DataBind()
        'Dim dtdll As DataTable = dt.DefaultView.ToTable(True, "PRODUCTION")
        Dim ddl1 As DropDownList = CType(rptGRID.Controls(0).Controls(0).FindControl("ddlBRule"), DropDownList)
        ddl1.DataSource = dtdll
        ddl1.DataTextField = "PRODUCTION"
        ddl1.DataValueField = "PRODUCTION"
        ddl1.DataBind()
        ddl1.Items.Insert(0, "All")
        ddl1.SelectedIndex = selectedIndex
    End Sub
End Class
