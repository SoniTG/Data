Imports System.Data
Imports System.IO
Imports System.Net
Imports System.Drawing
Imports System.Data.OleDb
Imports OfficeOpenXml
Imports System.Data.OracleClient
Partial Class RBD_ToolBox_at_TSCR
    Inherits System.Web.UI.Page
    Dim objController As New Controller_CoilDeviation
    Dim objDataHandler As New DataHandler

    Private _getBase64String As Object

    Private Property GetBase64String(url As String) As Object
        Get
            Return _getBase64String
        End Get
        Set(value As Object)
            _getBase64String = value
        End Set
    End Property

    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    txtDate_TextChanged()
                End If
            Catch ex As Exception

            End Try

        End If

        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = Now.AddDays(-30).ToString("yyyy-MM-dd")
                Dim dtEnd As String = Now.ToString("yyyy-MM-dd")
                hfFrom.Value = dtStart
                hfTo.Value = dtEnd
                'Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                'Dim dt As DataTable = objController.oradataRBD_Toolbox_TSCR(dtStart, dtEnd)
                'DataDetailAnalysis(dt)
                main()
            Catch ex As Exception

            End Try

        End If
    End Sub
    'Dim maindt As New DataTable
    Sub DataDetailAnalysis(ByVal tab As DataTable)
        Try


            For i As Integer = 0 To tab.Rows.Count - 1

                For j As Integer = 2 To tab.Columns.Count - 1

                    If tab.Rows(i)(j).ToString = "01-Jan-00 12:00:00 AM" Or tab.Rows(i)(j).ToString = "01-01-1900 00:00:00" Then
                        tab.Rows(i)(j) = DBNull.Value
                    End If
                Next
            Next
        Catch ex As Exception

        End Try
        GridView1.DataSource = tab
        GridView1.DataBind()

        'If GridView1.Rows.Count > 0 Then
        GridView1.UseAccessibleHeader = True
        GridView1.HeaderRow.TableSection = TableRowSection.TableHeader
        'End If

    End Sub
    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try
            'GetData()
            main()
        Catch ex As Exception

        End Try
    End Sub
    Sub main()
        Dim l As Literal
        Dim startDate As String = hfFrom.Value
        Dim endDate As String = hfTo.Value
        Dim dt As DataTable = objController.oradataRBD_Toolbox_TSCR(startDate, endDate)
        GridView1.DataSource = dt
        GridView1.DataBind()
        Dim dt1 As DataTable = objController.oradataRBD_Toolbox_TSCR1(startDate, endDate)
        GridView2.DataSource = dt1
        GridView2.DataBind()
        CreateDynamicContainer1(dt)
        CreateDynamicContainer(dt1)

        Dim literals = Page.Master.FindControl("content_body").Controls.OfType(Of Literal)()
        For Each lit In literals
            Dim i As Integer = 0
            If (lit.ID = "Lit1") Then
                l = lit
                If dt.Rows.Count > 0 Then
                    PlotLineEChart(dt, l, "cy2")

                End If

            End If
            If (lit.ID = "Lit2") Then
                l = lit
                If dt1.Rows.Count > 0 Then
                    PlotLineEChart(dt1, l, "cy1")

                End If
            End If
        Next




    End Sub

    Sub GetData()
        Try
            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            Dim dt As DataTable = objController.oradataRBD_Toolbox_TSCR(dtStart, dtEnd)
            DataDetailAnalysis(dt)

        Catch ex As Exception

        End Try

    End Sub

    Sub CreateDynamicContainer(ByVal dt As DataTable)


        Try
            Dim appendString = ""
            'For i As Integer = 0 To dt.Rows.Count - 1
            appendString &= "<div class='col-md-6'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>TREND Of Top Surface DEFECT, %</h3> <span></span></div><ul class='panel-controls' style='margin-top: 2px;'></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='cy1' style='height: 400px;'></div></div></div></div>"
            'Next
            divHolder1.InnerHtml = appendString
        Catch ex As Exception

        End Try

    End Sub
    Sub CreateDynamicContainer1(ByVal dt As DataTable)


        Try
            Dim appendString = ""
            'For i As Integer = 0 To dt.Rows.Count - 1
            appendString &= "<div class='col-md-6'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>TREND Of Bottom Surface DEFECT, %</h3> <span></span></div><ul class='panel-controls' style='margin-top: 2px;'></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='cy2' style='height: 400px;'></div></div></div></div>"
            'Next
            divHolder.InnerHtml = appendString
        Catch ex As Exception

        End Try

    End Sub
    'Public Sub DrawCharts()
    '    Dim startDate As String = hfFrom.Value
    '    Dim endDate As String = hfTo.Value
    '    Dim dt_Plot1 As DataTable = objController.oradataRBD_Toolbox_TSCR_Plot1(startDate, endDate)

    '    If dt_Plot1.Rows.Count > 0 Then
    '        PlotLinegraph(dt_Plot1, "main1", Lit1)

    '    End If
    'End Sub

    Public Sub PlotLineEChart(ByVal dt As DataTable, ByVal LiteralName As Literal, ByVal ContainerName As String)
        ' Try

        LiteralName.Text = ""

        Dim data As String = ""
        Dim data_CoilID As String = Nothing
        Dim data_Width As String = Nothing
        Dim data_length As String = Nothing
        Dim data_Area As String = Nothing
        Dim date_val As String = Nothing
        For I As Integer = 0 To dt.Rows.Count - 1
            data_CoilID &= "'" & dt.Rows(I)("COILID") & "',"
            data_Width &= dt.Rows(I)("Width_Affected_pct") & ","
            data_length &= dt.Rows(I)("Length_Affected_pct") & ","
            data_Area &= dt.Rows(I)("Area_Affected_pct") & ","
            date_val &= "'" & dt.Rows(I)("Prod_Date") & "',"
        Next

        Dim s As New StringBuilder("<script>")

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        s.Append(" var myChart = echarts.init(document.getElementById('" & ContainerName & "'));")
        s.Append(" var coilid = [" & data_CoilID & "];")
        s.Append("option = {")
        s.Append("title: {")
        s.Append("text:''")
        s.Append("},")
        's.Append("tooltip: {")
        s.Append("tooltip: {formatter:function(params){return 'X: ' + params.name + '<br/>Y: ' + params.data + '<br/>Coil Id: ' + coilid[params.dataIndex];},")
        s.Append("trigger: 'item'")
        s.Append("},")
        s.Append("legend:  {bottom: 5},")
        s.Append("grid: {left:   '3%',right:  '1%',bottom:  '12%',containLabel: true},")
        s.Append("toolbox: {show: true,feature: {dataZoom: {},restore: {},saveAsImage: {}}},")
        s.Append("xAxis: {")
        s.Append("data: [" & date_val & "]")
        s.Append("},")
        s.Append("yAxis: [{type : 'value',splitLine:{show:false},axisLabel : {formatter: '{value}',fontWeight:'bold'},name: 'Affected portion, %',nameLocation: 'middle',nameGap: 50,nameTextStyle: {fontWeight:'bold'} }],")
        s.Append("toolbox: {")
        s.Append("left: 'center',")
        s.Append("feature: {")
        s.Append("dataZoom: {")
        s.Append("yAxisIndex: 'none'")
        s.Append("},")
        s.Append("restore: {},")
        s.Append("saveAsImage: {}")
        s.Append("}")
        s.Append("},")
        s.Append("dataZoom: [{")
        s.Append("}, {")
        s.Append("type: 'inside'")
        s.Append("}],")

        s.Append("series: [")
        s.Append("{ name:'Width',")
        s.Append("type:'line',color: '#3e86f0' ,")
        's.Append("stack: 'temp',")
        s.Append("data: [" & data_Width & "], itemStyle: {borderWidth: 2, borderColor: '#EE6666', color: '#32a852'}},")
        s.Append("{ name:'Length',")
        s.Append("type:'line',color: '#225b9c' ,")
        s.Append("data: [" & data_length & "],  itemStyle: {borderWidth: 2, borderColor: '#EE6666', color: 'red' } },")

        s.Append("{ name:'Area',")
        s.Append("type:'line',color: '#a11b5e' ,")
        s.Append("data: [" & data_Area & "], itemStyle: {borderWidth: 2, borderColor: '#EE6666', color: 'blue' }},")
        s.Append("]")
        s.Append("};")

        s.Append(" myChart.setOption(option);")
        s.Append("</script>")
        LiteralName.Text = s.ToString()


        'Catch ex As Exception

        'End Try
    End Sub



End Class
