﻿Imports System.Data
Imports System.IO
Imports System.Data.OleDb
Imports System.Data.SqlClient
Imports OfficeOpenXml

Partial Class SPMBAFDetails
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Dim dt As New DataTable
    Dim dtCutOff As DataTable

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try

                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    txtDate_TextChanged()
                End If

            Catch ex As Exception

            End Try
        End If
        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                ddlFilter.SelectedIndex = 1
                Dim dtStart As String = DateTime.Now.AddDays(-10).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

                Dim filter As String = ""

                filter = " where  " & ddlFilter.SelectedValue.ToString() & " between '" & dtStart & "' and '" & dtEnd & "' and TDC_No = 'TE13' order by " & ddlFilter.SelectedValue.ToString() & " desc"

                dt = objController.GetSPMBAFData(filter)

                If dt.Rows.Count > 0 Then

                    gvData.Visible = True

                    gvData.DataSource = dt
                    gvData.DataBind()
                    gvData.UseAccessibleHeader = True
                    gvData.HeaderRow.TableSection = TableRowSection.TableHeader
                End If


            Catch ex As Exception

            End Try




        End If
    End Sub
    Protected Sub txtCoilwise_TextChanged(sender As Object, e As EventArgs) Handles txtCoilwise.TextChanged
        Try
            If txtCoilwise.Text IsNot "" Then
                txtDate_TextChanged()
            End If
        Catch ex As Exception

        End Try



    End Sub

    Protected Sub btnDownload_Click(sender As Object, e As EventArgs) Handles btnDownload.Click

        If gvData.Rows.Count > 0 Then
                Try

                    Response.ClearContent()
                    Response.Buffer = True
                    Response.AddHeader("content-disposition", String.Format("attachment; filename={0}", "CoilDetail.xls"))
                    Response.ContentEncoding = Encoding.UTF8
                    Response.ContentType = "application/ms-excel"
                    Dim sw As New StringWriter()
                    Dim htw As New HtmlTextWriter(sw)
                    gvData.RenderControl(htw)
                    Response.Write(sw.ToString())
                    Response.End()

                Catch ex As Exception
                Finally

                End Try
            End If


    End Sub

    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)
        ' Verifies that the control is rendered 
    End Sub
    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try

            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            Dim filter As String = ""

            If ddlFilter.SelectedItem.Text = "Coil Id" Then


                filter = " where " & ddlFilter.SelectedValue.ToString() & " = '" & txtCoilwise.Text.ToString() & "'"



            ElseIf ddlFilter.SelectedItem.Text = "Spm Processing Date" Then

                filter = " where " & ddlFilter.SelectedValue.ToString() & " between '" & CDate(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & CDate(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "' and TDC_No = 'TE13'  order by " & ddlFilter.SelectedValue.ToString() & " desc"



            End If

            dt = objController.GetSPMBAFData(filter)

            If dt.Rows.Count > 0 Then

                gvData.Visible = True

                gvData.DataSource = dt
                    gvData.DataBind()
                    gvData.UseAccessibleHeader = True
                    gvData.HeaderRow.TableSection = TableRowSection.TableHeader





            End If
            If dt.Rows.Count = 0 Then
                gvData.DataSource = ""
                gvData.DataBind()

            End If

        Catch ex As Exception

        End Try
    End Sub


    Protected Sub ddlFilter_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlFilter.SelectedIndexChanged
        Try

            txtCoilwise.Text = ""
            If ddlFilter.SelectedItem.Text = "Spm Processing Date" Then
                txtCoilwise.Enabled = False
                txtDate_TextChanged()
            Else
                txtCoilwise.Enabled = True
                txtCoilwise.Focus()
                gvData.DataSource = ""
                gvData.DataBind()


            End If


        Catch ex As Exception

        End Try
    End Sub






End Class
