﻿Imports System.Data
Imports System.IO
Imports System.Data.OleDb
Imports System.Drawing

Partial Class SPM_Diagnostics
    Inherits System.Web.UI.Page

    Dim objController As New Controller
    Dim objDataHandler As New DataHandler
    Dim HeaderName() As String
    Dim paramname As String
    Dim HeaderDifferentialName() As String
    Dim paramdifferentialname As String

    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub

    Sub registerDate()
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "register", "register();", True)
    End Sub
    Dim dtTBM As DataTable

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try
                ' MultiView1.ActiveViewIndex = 2
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-30).ToString("yyyy-MM-dd")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd")
              
                CreateDynamicContainer_Differential()
                CreateChart_Differential(HeaderDifferentialName)
            Catch ex As Exception

            End Try

        End If

        If Not Page.IsPostBack Then
            Try
                ' MultiView1.ActiveViewIndex = 2
                ' Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-30).ToString("yyyy-MM-dd")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd")

                CreateDynamicContainer_Differential()
                CreateChart_Differential(HeaderDifferentialName)
            Catch ex As Exception

            End Try

        End If

    End Sub
    Sub CreateDynamicContainer_Differential()
        Try
            Dim dt As DataTable = objDataHandler.GetDataSetFromQuery(" select distinct rTrim(ltrim(t1.SignalName)) as SignalName,SignalAlias  from [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_CGL2_DifferentialVal] t1 inner join [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_CGL2_Differential_Limit] t2 on rTrim(ltrim(t1.SignalName))=rTrim(ltrim(t2.SignalName)) order by 1").Tables(0)

            Dim appendString = ""
            ReDim HeaderDifferentialName(dt.Rows.Count - 1)
            For i As Integer = 0 To dt.Rows.Count - 1
                HeaderDifferentialName(i) = dt.Rows(i)(0).ToString().Trim
                appendString &= "<div class='col-md-12'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>" & dt.Rows(i)(1).ToString() & "</h3> <span></span></div><ul class='panel-controls' style='margin-top: 2px;'></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='c" & i.ToString() & "' style='height: 200px;'></div></div></div></div>"
            Next
            paramdifferentialname = "[" & String.Join("],[", HeaderDifferentialName) & "]"
            divHolder.InnerHtml = appendString
        Catch ex As Exception

        End Try

    End Sub

    Sub ClearLiterals()
        Dim literals = form1.Controls.OfType(Of Literal)() '("LiteralID")
        For Each lit In literals
            lit.Text = ""
        Next
    End Sub
    Private Sub CreateChart_Differential(HeaderDifferentialName As String())
        Try
            Dim dtStart As String = DateTime.Now.AddDays(-30).ToString("yyyy-MM-dd")
            Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd")

            Dim l As Literal

            For i As Integer = 0 To HeaderDifferentialName.Length - 1
                Dim literals = form1.Controls.OfType(Of Literal)() '("LiteralID")
                For Each lit In literals
                    If (lit.ID = "Lit" & i + 1) Then
                        l = lit
                        Exit For
                    End If
                Next
                Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select fileDatetime,rTrim(ltrim(SignalName)) as SignalName,SignalMaxVal from [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_CGL2_DifferentialVal] where fileDatetime between '" & dtStart & "' and '" & dtEnd & " 23:59:59' and rtrim(ltrim(SignalName))='" & HeaderDifferentialName(i) & "' order by 1").Tables(0)

                objController.PlotLineChartForCGL2Maint(dt, "fileDatetime", "SignalMaxVal", l, "c" & i, "plot" & i + 1, "", "", i + 1)

            Next
        Catch ex As Exception

        End Try

    End Sub
    Private Sub CreateChart(HeaderName As String())
        Try
            Dim dtStart As String = DateTime.Now.AddDays(-30).ToString("yyyy-MM-dd")
            Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd")

            Dim l As Literal
            'Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select * from (select CCS_DATETIME as CCSA_DATETIME,ccs_param_name,max(ccsa_param_val) as param_val FROM [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_CGL2_STROKETIME_DATA]   where ccs_datetime between '" & dtStart & "' and '" & dtEnd & "' group by CCS_DATETIME,ccs_param_name ) t PIVOT(max(param_val) FOR ccs_param_name IN (" & paramname & ")) AS pivot_table order by ccsa_datetime desc").Tables(0)

            For i As Integer = 0 To HeaderName.Length - 1
                Dim literals = form1.Controls.OfType(Of Literal)() '("LiteralID")
                For Each lit In literals
                    If (lit.ID = "Lit" & i + 1) Then
                        l = lit
                        Exit For
                    End If
                Next
                Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select CCS_DATETIME,rTrim(ltrim(CCS_PARAM_NAME)) as SignalName,CCSA_PARAM_VAL,SeqNo from [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_CGL2_STROKETIME_DATA] where CCS_DATETIME between '" & dtStart & "' and '" & dtEnd & " 23:59:59' and rtrim(ltrim(CCS_PARAM_NAME))='" & HeaderName(i) & "' order by 1,SeqNo").Tables(0)
                If dt.Rows.Count > 0 Then
                    objController.PlotLineChartForCGL2Maint(dt, "CCS_DATETIME", "CCSA_PARAM_VAL", l, "c" & i, "plot" & i + 1, "", "", i + 1)
                End If

            Next
        Catch ex As Exception

        End Try

    End Sub

  

    'Protected Sub btnDifferential_Click(sender As Object, e As System.EventArgs) Handles btnDifferential.Click
    '    ClearLiterals()
    '    divHolder.InnerHtml = ""
    '    'MultiView1.ActiveViewIndex = 2
    '    CreateDynamicContainer_Differential()
    '    CreateChart_Differential(HeaderDifferentialName)
    'End Sub
   


   

End Class