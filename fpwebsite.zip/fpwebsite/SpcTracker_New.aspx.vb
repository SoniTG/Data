﻿Imports System.Data
Imports System.IO
Imports System.Data.OleDb
Imports System.Text
Imports System.Security.Cryptography
Partial Class SpcTracker_New
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    'Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("ACPM_Ora").ConnectionString
    'Dim Oleconnection_ora As New OleDbConnection(strConnectionString)
    'Dim OleAdap As New OleDbDataAdapter
    'Dim OleCom As New OleDbCommand
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
                'If p = "txtdate" Then
                '     txtDate_TextChanged()
                ' End If

                Dim filter As String = ""

                'If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
                '    filter &= " and GRADE = '" & ddlGrade.SelectedItem.Text & "'"
                'End If
                'If ddlTdc.SelectedItem.Text.ToLower <> "all" Then
                '    filter &= " and TDC_No = '" & ddlTdc.SelectedItem.Text & "'"
                'End If

                If ddlParam.SelectedItem.Text <> "All" Then
                    filter = objController.PopulateParamForSPC(ddlParam.SelectedItem.Text)
                Else
                    filter = "1=1"
                End If

                gvCoilData1.DataSource = objController.GetDataForSpcTracker(hfFrom.Value, hfTo.Value, filter)
                gvCoilData1.DataBind()
            Catch ex As Exception

            End Try
        End If

        'If gvCoilData1.Rows.Count > 0 Then
        '    gvCoilData1.UseAccessibleHeader = True
        '    gvCoilData1.HeaderRow.TableSection = TableRowSection.TableHeader
        'End If




        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddMonths(-1).ToString("yyyy-MM-dd")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd")
             

                objController.PopulateDefectForSPC(ddlParam)
                Dim filter As String = ""
                If ddlParam.SelectedItem.Text <> "All" Then
                    filter = objController.PopulateParamForSPC(ddlParam.SelectedItem.Text)
                Else
                    filter = "1=1"
                End If

                gvCoilData1.DataSource = objController.GetDataForSpcTracker(dtStart, dtEnd, filter)
                gvCoilData1.DataBind()

            Catch ex As Exception

            End Try
        End If
    End Sub

    
    
    
    

    

    'Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
    '    Try

    '        Dim dtStart As String = hfFrom.Value
    '        Dim dtEnd As String = hfTo.Value
    '        If (hfIsButton.Value = "false") Then

    '            'objController.PopulateGradeForSPCTacker(ddlGrade, dtStart, dtEnd)
    '            'objController.PopulateTdcForSPCTacker(ddlTdc, dtStart, dtEnd, "")
    '            Dim filter As String = " 1=1"
    '            'If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
    '            '    filter &= " and GRADE = '" & ddlGrade.SelectedItem.Text & "'"
    '            'End If
    '            'If ddlTdc.SelectedItem.Text.ToLower <> "all" Then
    '            '    filter &= " and TDC_No = '" & ddlTdc.SelectedItem.Text & "'"
    '            'End If

    '            If objController.GetDataForSpcTracker(dtStart, dtEnd, filter).Rows.Count > 0 Then
    '                gvCoilData1.DataSource = objController.GetDataForSpcTracker(dtStart, dtEnd, filter)
    '                gvCoilData1.DataBind()

    '            End If

    '        End If
    '    Catch ex As Exception

    '    End Try

    'End Sub

    'Protected Sub ddlGrade_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlGrade.SelectedIndexChanged
    '    'Try

    '    '    Dim fromDt As String = hfFrom.Value
    '    '    Dim toDt As String = hfTo.Value


    '    '    If ddlGrade.SelectedItem.Text.ToLower = "all" Then

    '    '        objController.PopulateTdcForSPCTacker(ddlTdc, fromDt, toDt, "")

    '    '    Else
    '    '        objController.PopulateTdcForSPCTacker(ddlTdc, fromDt, toDt, ddlGrade.SelectedItem.Text)
    '    '        Dim filter As String = " 1=1"
    '    '        If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
    '    '            filter &= " and GRADE = '" & ddlGrade.SelectedItem.Text & "'"
    '    '        End If
    '    '        If ddlTdc.SelectedItem.Text.ToLower <> "all" Then
    '    '            filter &= " and TDC_No = '" & ddlTdc.SelectedItem.Text & "'"
    '    '        End If

    '    '        If objController.GetDataForSpcTracker(fromDt, toDt, filter).Rows.Count > 0 Then
    '    '            gvCoilData1.DataSource = objController.GetDataForSpcTracker(fromDt, toDt, filter)
    '    '            gvCoilData1.DataBind()

    '    '        End If
    '    '    End If


    '    'Catch ex As Exception

    '    'End Try
    'End Sub

    Protected Sub gvCoilData1_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles gvCoilData1.RowCommand
        Try
            Dim index As Integer = CType(CType(e.CommandSource, Button).NamingContainer, GridViewRow).RowIndex
            'Dim param As String = HttpUtility.UrlEncode(Encrypt(gvCoilData1.Rows(index).Cells(1).Text.ToString()))
            Dim param As String = gvCoilData1.Rows(index).Cells(1).Text.ToString()
            'Session("ParamTest") = gvCoilData1.Rows(index).Cells(1).Text.ToString()
            'Session("ParamTest1") = gvCoilData1.Rows(index).Cells(2).Text.ToString()
            '            Dim dt As String = HttpUtility.UrlEncode(Encrypt(CType(e.CommandSource, Button).CommandArgument))
            Dim dt As String = CType(e.CommandSource, Button).CommandArgument
            'Dim dtFrom As Date = CDate("01-" & dt.Substring(0, 2) & "-" & dt.Substring(3, 4))

            'Dim dtFrom As Date = CDate(dt.Substring(0, 4) & "-" & dt.Substring(6, 7) & "- 01").ToString("yyyy-MM-dd")
            'Dim dtTo As Date = dtFrom.AddMonths(1).AddDays(-1)

            'Dim dt1 As New DataTable
            'dt1 = objController.PopulateDataForSPCTacker(dtFrom.ToString("yyyy-MMM-dd"), dtTo.ToString("yyyy-MMM-dd"), Session("ParamTest"), ddlGrade.SelectedValue.ToString(), ddlTdc.SelectedValue.ToString())
            'If dt1.Rows.Count > 0 Then
            '    objController.PlotLineChartForSPC(dt1, "SAMPLING_DATE", "TEST_VALUE", Lit1, "container", "plot1", Session("ParamTest1"), "", "1")
            'End If
            'Response.Redirect("spmdetailanalysis.aspx")
            Dim s As String = "window.open('CRM_DailyReport.aspx?ParamName=" & param & "&DateVal=" & CDate("01-" & dt).ToString("yyyy-MM-dd") & "','_blank');"
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "alertscript", s, True)

        Catch ex As Exception

        End Try
    End Sub
    
    Private Function Encrypt(clearText As String) As String
        'Dim EncryptionKey As String = "MAKV2SPBNI99212"
        Dim EncryptionKey As String = "TGGWL"
        Dim clearBytes As Byte() = Encoding.Unicode.GetBytes(clearText)
        Using encryptor As Aes = Aes.Create()
            Dim pdb As New Rfc2898DeriveBytes(EncryptionKey, New Byte() {&H49, &H76, &H61, &H6E, &H20, &H4D, _
             &H65, &H64, &H76, &H65, &H64, &H65, _
             &H76})
            encryptor.Key = pdb.GetBytes(32)
            encryptor.IV = pdb.GetBytes(16)
            Using ms As New MemoryStream()
                Using cs As New CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write)
                    cs.Write(clearBytes, 0, clearBytes.Length)
                    cs.Close()
                End Using
                clearText = Convert.ToBase64String(ms.ToArray())
            End Using
        End Using
        Return clearText
    End Function
   

    Protected Sub gvCoilData1_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvCoilData1.RowDataBound
        Try
            If e.Row.RowType = DataControlRowType.Header Then

                For i As Integer = 3 To e.Row.Cells.Count - 1
                    e.Row.Cells(i).Text = CDate(e.Row.Cells(i).Text).ToString("MMM-yyyy")
                Next

            End If
            If e.Row.RowType = DataControlRowType.DataRow Then
                'e.Row.Cells(0).HorizontalAlign = HorizontalAlign.Center
                e.Row.Cells(1).BackColor = Drawing.Color.FromArgb(255, 255, 255)
                e.Row.Cells(1).Font.Bold = True
                e.Row.Cells(1).ForeColor = Drawing.Color.Black
                e.Row.Cells(1).HorizontalAlign = HorizontalAlign.Left
                e.Row.Cells(2).BackColor = Drawing.Color.FromArgb(255, 255, 255)
                e.Row.Cells(2).Font.Bold = True
                e.Row.Cells(2).ForeColor = Drawing.Color.Black
                e.Row.Cells(2).HorizontalAlign = HorizontalAlign.Center
                '---------------------------------------------------------------------------------------------------------------------------------------------------------------
                Dim val15 As Double = 0.0
                If e.Row.Cells(3).Text = "&nbsp;" Then
                    val15 = 0.0
                Else
                    val15 = Double.Parse(e.Row.Cells(3).Text)
                End If
                'val15 = Double.Parse(e.Row.Cells(3).Text)

                'If IsDBNull(val15) Then
                '    val15 = 0.0
                'End If
                If val15 > 1.33 Then
                    e.Row.Cells(3).BackColor = Drawing.Color.Green
                ElseIf val15 >= 0.5 And val15 < 1.33 Then
                    e.Row.Cells(3).BackColor = Drawing.Color.FromArgb(255, 199, 0)
                ElseIf val15 < 0.5 Then
                    e.Row.Cells(3).BackColor = Drawing.Color.Red
                End If
                e.Row.Cells(3).Font.Bold = True
                e.Row.Cells(3).HorizontalAlign = HorizontalAlign.Center

                'Dim hl As New HyperLink
                ''hl.ID = "2"
                'hl.Text = e.Row.Cells(3).Text
                'hl.NavigateUrl = "#"

                Dim hl15 As New Button
                'hl15.Width = e.Row.Cells(3).Width.ToString()

                If e.Row.Cells(3).Text = "&nbsp;" Then
                    hl15.Text = 0.0
                Else
                    hl15.Text = e.Row.Cells(3).Text
                End If
                'hl15.Text = e.Row.Cells(3).Text
                hl15.CommandArgument = gvCoilData1.HeaderRow.Cells(3).Text
                hl15.BackColor = e.Row.Cells(3).BackColor
                hl15.ForeColor = Drawing.Color.White
                e.Row.Cells(3).Controls.Add(hl15)
                '---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                Dim val As Double = 0.0
                If e.Row.Cells(4).Text = "&nbsp;" Then
                    val = 0.0
                Else
                    val = Double.Parse(e.Row.Cells(4).Text)
                End If
                'val = Double.Parse(e.Row.Cells(4).Text)

                'If IsDBNull(val) Then
                '    val = 0.0
                'End If
                If val > 1.33 Then
                    e.Row.Cells(4).BackColor = Drawing.Color.Green
                ElseIf val >= 0.5 And val < 1.33 Then
                    e.Row.Cells(4).BackColor = Drawing.Color.FromArgb(255, 199, 0)
                ElseIf val < 0.5 Then
                    e.Row.Cells(4).BackColor = Drawing.Color.Red
                End If
                e.Row.Cells(4).Font.Bold = True
                e.Row.Cells(4).HorizontalAlign = HorizontalAlign.Center

                'Dim hl As New HyperLink
                ''hl.ID = "3"
                'hl.Text = e.Row.Cells(4).Text
                'hl.NavigateUrl = "#"

                Dim hl As New Button
                'hl.Width = e.Row.Cells(4).Width.ToString()
                If e.Row.Cells(4).Text = "&nbsp;" Then
                    hl.Text = 0.0
                Else
                    hl.Text = e.Row.Cells(4).Text
                End If
                'hl.Text = e.Row.Cells(4).Text
                hl.CommandName = "test"
                hl.CommandArgument = gvCoilData1.HeaderRow.Cells(4).Text
                hl.BackColor = e.Row.Cells(4).BackColor
                hl.ForeColor = Drawing.Color.White
                e.Row.Cells(4).Controls.Add(hl)


                '---------------------------------------------------------------------------------------------------------------------------------------------------------------------------


                Dim val1 As Double = 0.0
                If e.Row.Cells(5).Text = "&nbsp;" Then
                    val1 = 0.0
                Else
                    val1 = Double.Parse(e.Row.Cells(5).Text)
                End If

                'val1 = Double.Parse(e.Row.Cells(5).Text)
                'If IsDBNull(val1) Then
                '    val1 = 0.0
                'End If
                If val1 > 1.33 Then
                    e.Row.Cells(5).BackColor = Drawing.Color.Green
                    'hl1.BackColor = e.Row.Cells(5).BackColor
                ElseIf val1 >= 0.5 And val1 < 1.33 Then
                    e.Row.Cells(5).BackColor = Drawing.Color.FromArgb(255, 199, 0)
                    'hl.BackColor = e.Row.Cells(5).BackColor
                ElseIf val1 < 0.5 Then
                    e.Row.Cells(5).BackColor = Drawing.Color.Red
                    'hl.BackColor = e.Row.Cells(5).BackColor
                End If
                e.Row.Cells(5).Font.Bold = True
                e.Row.Cells(5).HorizontalAlign = HorizontalAlign.Center

                Dim hl1 As New Button
                'hl1.Width = e.Row.Cells(5).Width.ToString()
                If e.Row.Cells(5).Text = "&nbsp;" Then
                    hl1.Text = 0.0
                Else
                    hl1.Text = e.Row.Cells(5).Text
                End If
                'hl1.Text = e.Row.Cells(5).Text
                hl1.CommandArgument = gvCoilData1.HeaderRow.Cells(5).Text
                hl1.BackColor = e.Row.Cells(5).BackColor
                hl1.ForeColor = Drawing.Color.White
                e.Row.Cells(5).Controls.Add(hl1)
                '-----------------------------------------------------------------------------------------------------------------------------------------------------------------------

                Dim val2 As Double = 0.0
                If e.Row.Cells(6).Text = "&nbsp;" Then
                    val2 = 0.0
                Else
                    val2 = Double.Parse(e.Row.Cells(6).Text)
                End If
                'val2 = Double.Parse(e.Row.Cells(6).Text)
                'If IsDBNull(val2) Then
                '    val2 = 0.0
                'End If
                If val2 > 1.33 Then
                    e.Row.Cells(6).BackColor = Drawing.Color.Green
                    'hl1.BackColor = e.Row.Cells(6).BackColor
                ElseIf val2 >= 0.5 And val2 < 1.33 Then
                    e.Row.Cells(6).BackColor = Drawing.Color.FromArgb(255, 199, 0)
                    'hl1.BackColor = e.Row.Cells(6).BackColor
                ElseIf val2 < 0.5 Then
                    e.Row.Cells(6).BackColor = Drawing.Color.Red
                    'hl1.BackColor = e.Row.Cells(6).BackColor
                End If
                e.Row.Cells(6).Font.Bold = True
                e.Row.Cells(6).HorizontalAlign = HorizontalAlign.Center

                Dim hl2 As New Button
                'hl2.Width = e.Row.Cells(6).Width.ToString()
                If e.Row.Cells(6).Text = "&nbsp;" Then
                    hl2.Text = 0.0
                Else
                    hl2.Text = e.Row.Cells(6).Text
                End If
                'hl2.Text = e.Row.Cells(6).Text
                hl2.CommandArgument = gvCoilData1.HeaderRow.Cells(6).Text
                hl2.BackColor = e.Row.Cells(6).BackColor
                hl2.ForeColor = Drawing.Color.White
                e.Row.Cells(6).Controls.Add(hl2)
                '-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                Dim val3 As Double = 0.0
                If e.Row.Cells(7).Text = "&nbsp;" Then
                    val3 = 0.0
                Else
                    val3 = Double.Parse(e.Row.Cells(7).Text)
                End If
                'val3 = Double.Parse(e.Row.Cells(7).Text)
                'If IsDBNull(val3) Then
                '    val3 = 0.0
                'End If
                If val3 > 1.33 Then
                    e.Row.Cells(7).BackColor = Drawing.Color.Green
                ElseIf val3 >= 0.5 And val3 < 1.33 Then
                    e.Row.Cells(7).BackColor = Drawing.Color.FromArgb(255, 199, 0)
                ElseIf val3 < 0.5 Then
                    e.Row.Cells(7).BackColor = Drawing.Color.Red
                End If
                e.Row.Cells(7).Font.Bold = True
                e.Row.Cells(7).HorizontalAlign = HorizontalAlign.Center

                Dim hl3 As New Button
                'hl3.Width = e.Row.Cells(7).Width.ToString()
                If e.Row.Cells(7).Text = "&nbsp;" Then
                    hl3.Text = 0.0
                Else
                    hl3.Text = e.Row.Cells(7).Text
                End If
                'hl3.Text = e.Row.Cells(7).Text
                hl3.CommandArgument = gvCoilData1.HeaderRow.Cells(7).Text
                hl3.BackColor = e.Row.Cells(7).BackColor
                hl3.ForeColor = Drawing.Color.White
                e.Row.Cells(7).Controls.Add(hl3)
                '-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                Dim val4 As Double = 0.0
                If e.Row.Cells(8).Text = "&nbsp;" Then
                    val4 = 0.0
                Else
                    val4 = Double.Parse(e.Row.Cells(8).Text)
                End If
                'val4 = Double.Parse(e.Row.Cells(8).Text)
                'If IsDBNull(val4) Then
                '    val4 = 0.0
                'End If
                If val4 > 1.33 Then
                    e.Row.Cells(8).BackColor = Drawing.Color.Green
                ElseIf val4 >= 0.5 And val4 < 1.33 Then
                    e.Row.Cells(8).BackColor = Drawing.Color.FromArgb(255, 199, 0)
                ElseIf val4 < 0.5 Then
                    e.Row.Cells(8).BackColor = Drawing.Color.Red
                End If
                e.Row.Cells(8).Font.Bold = True
                e.Row.Cells(8).HorizontalAlign = HorizontalAlign.Center

                Dim hl4 As New Button
                'hl4.Width = e.Row.Cells(8).Width.ToString()

                If e.Row.Cells(8).Text = "&nbsp;" Then
                    hl4.Text = 0.0
                Else
                    hl4.Text = e.Row.Cells(8).Text
                End If
                'hl4.Text = e.Row.Cells(8).Text
                hl4.CommandArgument = gvCoilData1.HeaderRow.Cells(8).Text
                hl4.BackColor = e.Row.Cells(8).BackColor
                hl4.ForeColor = Drawing.Color.White
                e.Row.Cells(8).Controls.Add(hl4)
                '-----------------------------------------------------------------------------------------------------------------------------------------------------------------
                Dim val5 As Double = 0.0
                If e.Row.Cells(9).Text = "&nbsp;" Then
                    val5 = 0.0
                Else
                    val5 = Double.Parse(e.Row.Cells(9).Text)
                End If
                'val5 = Double.Parse(e.Row.Cells(9).Text)
                'If IsDBNull(val5) Then
                '    val5 = 0.0
                'End If
                If val5 > 1.33 Then
                    e.Row.Cells(9).BackColor = Drawing.Color.Green
                ElseIf val5 >= 0.5 And val5 < 1.33 Then
                    e.Row.Cells(9).BackColor = Drawing.Color.FromArgb(255, 199, 0)
                ElseIf val5 < 0.5 Then
                    e.Row.Cells(9).BackColor = Drawing.Color.Red
                End If
                e.Row.Cells(9).Font.Bold = True
                e.Row.Cells(9).HorizontalAlign = HorizontalAlign.Center

                Dim hl5 As New Button
                'hl5.Width = e.Row.Cells(9).Width.ToString()
                If e.Row.Cells(9).Text = "&nbsp;" Then
                    hl5.Text = 0.0
                Else
                    hl5.Text = e.Row.Cells(9).Text
                End If
                'hl5.Text = e.Row.Cells(9).Text
                hl5.CommandArgument = gvCoilData1.HeaderRow.Cells(9).Text
                hl5.BackColor = e.Row.Cells(9).BackColor
                hl5.ForeColor = Drawing.Color.White
                e.Row.Cells(9).Controls.Add(hl5)
                '---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

                Dim val6 As Double = 0.0
                If e.Row.Cells(10).Text = "&nbsp;" Then
                    val6 = 0.0
                Else
                    val6 = Double.Parse(e.Row.Cells(10).Text)
                End If
                'val6 = Double.Parse(e.Row.Cells(10).Text)
                'If IsDBNull(val6) Then
                '    val6 = 0.0
                'End If
                If val6 > 1.33 Then
                    e.Row.Cells(10).BackColor = Drawing.Color.Green
                ElseIf val6 >= 0.5 And val6 < 1.33 Then
                    e.Row.Cells(10).BackColor = Drawing.Color.FromArgb(255, 199, 0)
                ElseIf val6 < 0.5 Then
                    e.Row.Cells(10).BackColor = Drawing.Color.Red
                End If
                e.Row.Cells(10).Font.Bold = True
                e.Row.Cells(10).HorizontalAlign = HorizontalAlign.Center

                Dim hl6 As New Button
                'hl6.Width = e.Row.Cells(10).Width.ToString()

                If e.Row.Cells(10).Text = "&nbsp;" Then
                    hl6.Text = 0.0
                Else
                    hl6.Text = e.Row.Cells(10).Text
                End If
                'hl6.Text = e.Row.Cells(10).Text
                hl6.CommandArgument = gvCoilData1.HeaderRow.Cells(10).Text
                hl6.BackColor = e.Row.Cells(10).BackColor
                hl6.ForeColor = Drawing.Color.White
                e.Row.Cells(10).Controls.Add(hl6)
                '-----------------------------------------------------------------------------------------------------------------------------------------------------------------

                Dim val7 As Double = 0.0
                If e.Row.Cells(11).Text = "&nbsp;" Then
                    val7 = 0.0
                Else
                    val7 = Double.Parse(e.Row.Cells(11).Text)
                End If
                'val7 = Double.Parse(e.Row.Cells(11).Text)
                'If IsDBNull(val7) Then
                '    val7 = 0.0
                'End If
                If val7 > 1.33 Then
                    e.Row.Cells(11).BackColor = Drawing.Color.Green
                ElseIf val7 >= 0.5 And val7 < 1.33 Then
                    e.Row.Cells(11).BackColor = Drawing.Color.FromArgb(255, 199, 0)
                ElseIf val7 < 0.5 Then
                    e.Row.Cells(11).BackColor = Drawing.Color.Red
                End If
                e.Row.Cells(11).Font.Bold = True
                e.Row.Cells(11).HorizontalAlign = HorizontalAlign.Center

                Dim hl7 As New Button
                'hl7.Width = e.Row.Cells(11).Width.ToString()
                If e.Row.Cells(11).Text = "&nbsp;" Then
                    hl7.Text = 0.0
                Else
                    hl7.Text = e.Row.Cells(11).Text
                End If
                'hl7.Text = e.Row.Cells(11).Text
                hl7.CommandArgument = gvCoilData1.HeaderRow.Cells(11).Text
                hl7.BackColor = e.Row.Cells(11).BackColor
                hl7.ForeColor = Drawing.Color.White
                e.Row.Cells(11).Controls.Add(hl7)
                '-----------------------------------------------------------------------------------------------------------------------------------------------------------------

                Dim val8 As Double = 0.0
                If e.Row.Cells(12).Text = "&nbsp;" Then
                    val8 = 0.0
                Else
                    val8 = Double.Parse(e.Row.Cells(12).Text)
                End If
                'val8 = Double.Parse(e.Row.Cells(12).Text)
                'If IsDBNull(val8) Then
                '    val8 = 0.0
                'End If
                If val8 > 1.33 Then
                    e.Row.Cells(12).BackColor = Drawing.Color.Green
                ElseIf val8 >= 0.5 And val8 < 1.33 Then
                    e.Row.Cells(12).BackColor = Drawing.Color.FromArgb(255, 199, 0)
                ElseIf val8 < 0.5 Then
                    e.Row.Cells(12).BackColor = Drawing.Color.Red
                End If
                e.Row.Cells(12).Font.Bold = True
                e.Row.Cells(12).HorizontalAlign = HorizontalAlign.Center

                Dim hl8 As New Button
                'hl8.Width = e.Row.Cells(12).Width.ToString()
                If e.Row.Cells(12).Text = "&nbsp;" Then
                    hl8.Text = 0.0
                Else
                    hl8.Text = e.Row.Cells(12).Text
                End If
                'hl8.Text = e.Row.Cells(12).Text
                hl8.CommandArgument = gvCoilData1.HeaderRow.Cells(12).Text
                hl8.BackColor = e.Row.Cells(12).BackColor
                hl8.ForeColor = Drawing.Color.White
                e.Row.Cells(12).Controls.Add(hl8)
                '----------------------------------------------------------------------------------------------------------------------------------------------------------------

                Dim val9 As Double = 0.0
                If e.Row.Cells(13).Text = "&nbsp;" Then
                    val9 = 0.0
                Else
                    val9 = Double.Parse(e.Row.Cells(13).Text)
                End If
                'val9 = Double.Parse(e.Row.Cells(13).Text)
                'If IsDBNull(val9) Then
                '    val9 = 0.0
                'End If
                If val9 > 1.33 Then
                    e.Row.Cells(13).BackColor = Drawing.Color.Green
                ElseIf val9 >= 0.5 And val9 < 1.33 Then
                    e.Row.Cells(13).BackColor = Drawing.Color.FromArgb(255, 199, 0)
                ElseIf val9 < 0.5 Then
                    e.Row.Cells(13).BackColor = Drawing.Color.Red
                End If
                e.Row.Cells(13).Font.Bold = True
                e.Row.Cells(13).HorizontalAlign = HorizontalAlign.Center

                Dim hl9 As New Button
                'hl9.Width = e.Row.Cells(13).Width.ToString()
                If e.Row.Cells(13).Text = "&nbsp;" Then
                    hl9.Text = 0.0
                Else
                    hl9.Text = e.Row.Cells(13).Text
                End If
                'hl9.Text = e.Row.Cells(13).Text
                hl9.CommandArgument = gvCoilData1.HeaderRow.Cells(13).Text
                hl9.BackColor = e.Row.Cells(13).BackColor
                hl9.ForeColor = Drawing.Color.White
                e.Row.Cells(13).Controls.Add(hl9)
                '-----------------------------------------------------------------------------------------------------------------------------------------------------------------

                Dim val10 As Double = 0.0
                If e.Row.Cells(14).Text = "&nbsp;" Then
                    val10 = 0.0
                Else
                    val10 = Double.Parse(e.Row.Cells(14).Text)
                End If

                'val10 = Double.Parse(e.Row.Cells(14).Text)
                'If IsDBNull(val10) Then
                '    val10 = 0.0
                'End If
                If val10 > 1.33 Then
                    e.Row.Cells(14).BackColor = Drawing.Color.Green
                ElseIf val10 >= 0.5 And val10 < 1.33 Then
                    e.Row.Cells(14).BackColor = Drawing.Color.FromArgb(255, 199, 0)
                ElseIf val10 < 0.5 Then
                    e.Row.Cells(14).BackColor = Drawing.Color.Red
                End If
                e.Row.Cells(14).Font.Bold = True
                e.Row.Cells(14).HorizontalAlign = HorizontalAlign.Center

                Dim hl10 As New Button
                'hl10.Width = e.Row.Cells(14).Width.ToString()
                If e.Row.Cells(14).Text = "&nbsp;" Then
                    hl10.Text = 0.0
                Else
                    hl10.Text = e.Row.Cells(14).Text
                End If
                'hl10.Text = e.Row.Cells(14).Text
                hl10.CommandArgument = gvCoilData1.HeaderRow.Cells(14).Text
                hl10.BackColor = e.Row.Cells(14).BackColor
                hl10.ForeColor = Drawing.Color.White
                e.Row.Cells(14).Controls.Add(hl10)
                'hl10.ForeColor = Drawing.Color.White
                '---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

                'Dim val11 As Double = 0.0
                'val11 = Double.Parse(e.Row.Cells(14).Text)
                ''If IsDBNull(val11) Then
                ''    val11 = 0.0
                ''End If
                'If val11 > 1.33 Then
                '    e.Row.Cells(14).BackColor = Drawing.Color.Green
                'ElseIf val11 >= 1.0 And val11 < 1.33 Then
                '    e.Row.Cells(14).BackColor = Drawing.Color.FromArgb(255, 199, 0)
                'ElseIf val11 < 1.0 Then
                '    e.Row.Cells(14).BackColor = Drawing.Color.Red
                'End If
                'e.Row.Cells(14).Font.Bold = True
                'e.Row.Cells(14).HorizontalAlign = HorizontalAlign.Center


                'Dim hl11 As New Button
                ''hl11.Width = e.Row.Cells(14).Width.ToString()
                'hl11.Text = e.Row.Cells(14).Text
                'hl11.CommandArgument = gvCoilData1.HeaderRow.Cells(14).Text
                'hl11.BackColor = e.Row.Cells(14).BackColor
                'hl11.ForeColor = Drawing.Color.White
                'e.Row.Cells(14).Controls.Add(hl11)
                ''e.Row.Cells(14).ForeColor = Drawing.Color.White
                ''hl11.ForeColor = Drawing.Color.White
                '-----------------------------------------------------------------------------------------------------------------------------------------------------------------
            End If
        Catch ex As Exception

        End Try

    End Sub



    Protected Sub ddlParam_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlParam.SelectedIndexChanged
        Dim dtStart As String = DateTime.Now.AddMonths(-1).ToString("yyyy-MM-dd")
        Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd")
        Dim filter As String = ""
        If ddlParam.SelectedItem.Text <> "All" Then
            filter = objController.PopulateParamForSPC(ddlParam.SelectedItem.Text)
        Else
            filter = "1=1"
        End If

        gvCoilData1.DataSource = objController.GetDataForSpcTracker(dtStart, dtEnd, filter)
        gvCoilData1.DataBind()
    End Sub
End Class
