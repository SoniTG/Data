﻿Imports System.Data
Imports System.IO
Imports System.Data.OleDb
Imports System.Text
Imports System.Security.Cryptography
Partial Class SpcTracker_New_Crcw
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    'Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("ACPM_Ora").ConnectionString
    'Dim Oleconnection_ora As New OleDbConnection(strConnectionString)
    'Dim OleAdap As New OleDbDataAdapter
    'Dim OleCom As New OleDbCommand
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
                'If p = "txtdate" Then
                '     txtDate_TextChanged()
                ' End If

                Dim filter As String = "1=1"
                'If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
                '    filter &= " and GRADE = '" & ddlGrade.SelectedItem.Text & "'"
                'End If
                'If ddlTdc.SelectedItem.Text.ToLower <> "all" Then
                '    filter &= " and TDC_No = '" & ddlTdc.SelectedItem.Text & "'"
                'End If


                gvCoilData1.DataSource = objController.GetDataForSpcTrackerCrcw(hfFrom.Value, hfTo.Value, filter)
                gvCoilData1.DataBind()
            Catch ex As Exception

            End Try
        End If

        'If gvCoilData1.Rows.Count > 0 Then
        '    gvCoilData1.UseAccessibleHeader = True
        '    gvCoilData1.HeaderRow.TableSection = TableRowSection.TableHeader
        'End If




        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddMonths(-1).ToString("yyyy-MM-dd")
                'Dim dtStart As DateTime = DateTime.Now.AddMonths(-6).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd")
                'objController.PopulateGradeForSPCTacker(ddlGrade, dtStart, dtEnd)
                'objController.PopulateTdcForSPCTacker(ddlTdc, dtStart, dtEnd, "")

                Dim filter As String = "1=1"
                'If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
                '    filter &= " and GRADE = '" & ddlGrade.SelectedItem.Text & "'"
                'End If
                'If ddlTdc.SelectedItem.Text.ToLower <> "all" Then
                '    filter &= " and TDC_No = '" & ddlTdc.SelectedItem.Text & "'"
                'End If



                gvCoilData1.DataSource = objController.GetDataForSpcTrackerCrcw(dtStart, dtEnd, filter)
                gvCoilData1.DataBind()

            Catch ex As Exception

            End Try
        End If
    End Sub








    'Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
    '    Try

    '        Dim dtStart As String = hfFrom.Value
    '        Dim dtEnd As String = hfTo.Value
    '        If (hfIsButton.Value = "false") Then

    '            'objController.PopulateGradeForSPCTacker(ddlGrade, dtStart, dtEnd)
    '            'objController.PopulateTdcForSPCTacker(ddlTdc, dtStart, dtEnd, "")
    '            Dim filter As String = " 1=1"
    '            'If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
    '            '    filter &= " and GRADE = '" & ddlGrade.SelectedItem.Text & "'"
    '            'End If
    '            'If ddlTdc.SelectedItem.Text.ToLower <> "all" Then
    '            '    filter &= " and TDC_No = '" & ddlTdc.SelectedItem.Text & "'"
    '            'End If

    '            If objController.GetDataForSpcTracker(dtStart, dtEnd, filter).Rows.Count > 0 Then
    '                gvCoilData1.DataSource = objController.GetDataForSpcTracker(dtStart, dtEnd, filter)
    '                gvCoilData1.DataBind()

    '            End If

    '        End If
    '    Catch ex As Exception

    '    End Try

    'End Sub

    'Protected Sub ddlGrade_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlGrade.SelectedIndexChanged
    '    'Try

    '    '    Dim fromDt As String = hfFrom.Value
    '    '    Dim toDt As String = hfTo.Value


    '    '    If ddlGrade.SelectedItem.Text.ToLower = "all" Then

    '    '        objController.PopulateTdcForSPCTacker(ddlTdc, fromDt, toDt, "")

    '    '    Else
    '    '        objController.PopulateTdcForSPCTacker(ddlTdc, fromDt, toDt, ddlGrade.SelectedItem.Text)
    '    '        Dim filter As String = " 1=1"
    '    '        If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
    '    '            filter &= " and GRADE = '" & ddlGrade.SelectedItem.Text & "'"
    '    '        End If
    '    '        If ddlTdc.SelectedItem.Text.ToLower <> "all" Then
    '    '            filter &= " and TDC_No = '" & ddlTdc.SelectedItem.Text & "'"
    '    '        End If

    '    '        If objController.GetDataForSpcTracker(fromDt, toDt, filter).Rows.Count > 0 Then
    '    '            gvCoilData1.DataSource = objController.GetDataForSpcTracker(fromDt, toDt, filter)
    '    '            gvCoilData1.DataBind()

    '    '        End If
    '    '    End If


    '    'Catch ex As Exception

    '    'End Try
    'End Sub

    Protected Sub gvCoilData1_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles gvCoilData1.RowCommand
        Try
            Dim index As Integer = CType(CType(e.CommandSource, Button).NamingContainer, GridViewRow).RowIndex
            'Dim param As String = HttpUtility.UrlEncode(Encrypt(gvCoilData1.Rows(index).Cells(1).Text.ToString()))
            Dim param As String = gvCoilData1.Rows(index).Cells(1).Text.ToString()
            'Session("ParamTest") = gvCoilData1.Rows(index).Cells(1).Text.ToString()
            'Session("ParamTest1") = gvCoilData1.Rows(index).Cells(2).Text.ToString()
            '            Dim dt As String = HttpUtility.UrlEncode(Encrypt(CType(e.CommandSource, Button).CommandArgument))
            Dim dt As String = CType(e.CommandSource, Button).CommandArgument
            'Dim dtFrom As Date = CDate("01-" & dt.Substring(0, 2) & "-" & dt.Substring(3, 4))

            'Dim dtFrom As Date = CDate(dt.Substring(0, 4) & "-" & dt.Substring(6, 7) & "- 01").ToString("yyyy-MM-dd")
            'Dim dtTo As Date = dtFrom.AddMonths(1).AddDays(-1)

            'Dim dt1 As New DataTable
            'dt1 = objController.PopulateDataForSPCTacker(dtFrom.ToString("yyyy-MMM-dd"), dtTo.ToString("yyyy-MMM-dd"), Session("ParamTest"), ddlGrade.SelectedValue.ToString(), ddlTdc.SelectedValue.ToString())
            'If dt1.Rows.Count > 0 Then
            '    objController.PlotLineChartForSPC(dt1, "SAMPLING_DATE", "TEST_VALUE", Lit1, "container", "plot1", Session("ParamTest1"), "", "1")
            'End If
            'Response.Redirect("spmdetailanalysis.aspx")
            Dim s As String = "window.open('CRM_DailyReport_Crcw.aspx?ParamName=" & param & "&DateVal=" & CDate("01-" & dt).ToString("yyyy-MM-dd") & "','_blank');"
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "alertscript", s, True)

        Catch ex As Exception

        End Try
    End Sub

    Private Function Encrypt(clearText As String) As String
        'Dim EncryptionKey As String = "MAKV2SPBNI99212"
        Dim EncryptionKey As String = "TGGWL"
        Dim clearBytes As Byte() = Encoding.Unicode.GetBytes(clearText)
        Using encryptor As Aes = Aes.Create()
            Dim pdb As New Rfc2898DeriveBytes(EncryptionKey, New Byte() {&H49, &H76, &H61, &H6E, &H20, &H4D,
             &H65, &H64, &H76, &H65, &H64, &H65,
             &H76})
            encryptor.Key = pdb.GetBytes(32)
            encryptor.IV = pdb.GetBytes(16)
            Using ms As New MemoryStream()
                Using cs As New CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write)
                    cs.Write(clearBytes, 0, clearBytes.Length)
                    cs.Close()
                End Using
                clearText = Convert.ToBase64String(ms.ToArray())
            End Using
        End Using
        Return clearText
    End Function


    Protected Sub gvCoilData1_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvCoilData1.RowDataBound
        Try
            If e.Row.RowType = DataControlRowType.Header Then

                For i As Integer = 3 To e.Row.Cells.Count - 1
                    e.Row.Cells(i).Text = CDate(e.Row.Cells(i).Text).ToString("MMM-yyyy")
                Next

            End If
            If e.Row.RowType = DataControlRowType.DataRow Then
                'e.Row.Cells(0).HorizontalAlign = HorizontalAlign.Center
                e.Row.Cells(1).BackColor = Drawing.Color.FromArgb(255, 255, 255)
                e.Row.Cells(1).Font.Bold = True
                e.Row.Cells(1).ForeColor = Drawing.Color.Black
                e.Row.Cells(1).HorizontalAlign = HorizontalAlign.Left
                e.Row.Cells(2).BackColor = Drawing.Color.FromArgb(255, 255, 255)
                e.Row.Cells(2).Font.Bold = True
                e.Row.Cells(2).ForeColor = Drawing.Color.Black
                e.Row.Cells(2).HorizontalAlign = HorizontalAlign.Center
                '---------------------------------------------------------------------------------------------------------------------------------------------------------------

                'loop
                For cnt As Integer = 3 To e.Row.Cells.Count - 1
                    Dim val15 As Double = 0.0
                    If e.Row.Cells(cnt).Text = "&nbsp;" Then
                        val15 = 0.0
                    Else
                        val15 = Double.Parse(e.Row.Cells(cnt).Text)
                    End If
                    'val15 = Double.Parse(e.Row.Cells(cnt).Text)

                    'If IsDBNull(val15) Then
                    '    val15 = 0.0
                    'End If
                    If val15 > 1.33 Then
                        e.Row.Cells(cnt).BackColor = Drawing.Color.Green 'Drawing.Color.FromArgb(148, 201, 95)
                    ElseIf val15 >= 0.5 And val15 < 1.33 Then
                        e.Row.Cells(cnt).BackColor = Drawing.Color.FromArgb(255, 199, 0)
                    ElseIf val15 < 0.5 Then
                        'e.Row.Cells(cnt).BackColor = Drawing.Color.Red
                        e.Row.Cells(cnt).BackColor = Drawing.Color.FromArgb(255, 77, 77)
                    End If
                    e.Row.Cells(cnt).Font.Bold = True
                    e.Row.Cells(cnt).HorizontalAlign = HorizontalAlign.Center

                    'Dim hl As New HyperLink
                    ''hl.ID = "2"
                    'hl.Text = e.Row.Cells(cnt).Text
                    'hl.NavigateUrl = "#"

                    Dim hl15 As New Button
                    'hl15.Width = e.Row.Cells(cnt).Width.ToString()

                    If e.Row.Cells(cnt).Text = "&nbsp;" Then
                        hl15.Text = 0.0
                    Else
                        hl15.Text = Math.Round(Decimal.Parse(e.Row.Cells(cnt).Text), 1)
                        'hl15.Text = e.Row.Cells(cnt).Text
                    End If
                    'hl15.Text = e.Row.Cells(cnt).Text
                    hl15.CommandArgument = gvCoilData1.HeaderRow.Cells(cnt).Text
                    hl15.BackColor = e.Row.Cells(cnt).BackColor
                    hl15.ForeColor = Drawing.Color.White
                    e.Row.Cells(cnt).Controls.Add(hl15)
                Next

                'end loop


              
            End If
        Catch ex As Exception

        End Try

    End Sub

    'Protected Sub ddlTdc_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlTdc.SelectedIndexChanged
    '    'Try

    '    '    Dim fromDt As String = hfFrom.Value
    '    '    Dim toDt As String = hfTo.Value


    '    '    Dim filter As String = " 1=1"
    '    '    If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
    '    '        filter &= " and GRADE = '" & ddlGrade.SelectedItem.Text & "'"
    '    '    End If
    '    '    If ddlTdc.SelectedItem.Text.ToLower <> "all" Then
    '    '        filter &= " and TDC_No = '" & ddlTdc.SelectedItem.Text & "'"
    '    '    End If

    '    '    If objController.GetDataForSpcTracker(fromDt, toDt, filter).Rows.Count > 0 Then
    '    '        gvCoilData1.DataSource = objController.GetDataForSpcTracker(fromDt, toDt, filter)
    '    '        gvCoilData1.DataBind()

    '    '    End If



    '    'Catch ex As Exception

    '    'End Try
    '    'Try


    '    '    txtDate_TextChanged()
    '    'Catch ex As Exception

    '    'End Try
    'End Sub







End Class
