﻿Imports System.Data
Imports System.IO
Imports System.Data.SqlClient
Imports System.Data.DataTable
Imports System.Drawing
Imports System.Collections.Generic
Imports System.Web.UI
Imports System.Web.Script.Serialization
Imports OfficeOpenXml

Partial Class Sub_Pltcm_jcap_coil_hold
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString
    Dim sql As New SqlConnection(strConnectionString)
    Dim OleAdap As New SqlDataAdapter
    Dim ds, ds1 As New DataSet
    Dim dt, dt1 As New DataTable
    Dim OleCom As New SqlCommand
    Dim coil_id As String = ""
    Dim width_data_a() As String = Nothing
    Dim severity As String = ""
    Dim CR_ID As String = ""
  
    Dim DEF_METERS As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
        End If
        Dim dt As New DataTable
        Dim width_data As String = Nothing
        Dim index As String = Nothing
        Try
            coil_id = Session("HR_ID")
            severity = Session("Dev_val")
            CR_ID = Session("CR_ID")
            'CR_WIDTH = Session("WIDTH_CR")
            'CR_THICKNESS = Session("THICNESS_CR")
            DEF_METERS = Session("METERS")
            ''-----------------------------
            CR_COIL_ID.Text = Session("CR_ID")
            HR_COIL_ID.Text = Session("HR_ID")
            CR_WIDTH.Text = Session("WIDTH_CR")
            CR_THICKNESS.Text = Session("THICNESS_CR")
            'DEFECT.Text = Session("METERS")
            THICKNESS_DEV.Text = Session("Dev_val")

            Dim query As String = "select * from CRM_PLTCM_PROCESS_DATA_COILWISE where HR_COIL_ID = '" & coil_id & "' "

            Try
                sql.Open()
                Dim da As New SqlDataAdapter(query, sql)
                da.SelectCommand.CommandTimeout = 10000
                da.Fill(dt)
            Catch ex As Exception
                sql.Close()
                Throw New Exception(ex.ToString())
            End Try

            Dim bytes() As Byte = dt.Rows(0)("RAW_DATA_FILE")
            Dim ms As New MemoryStream
            ms.Write(bytes, 0, bytes.Length)
            Dim ep As New ExcelPackage(ms)
            Dim excelTB As DataTable = toDataTableDetail(ep)
            'excelTB.Rows(0)("CR_WIDTH")
            If excelTB.Columns.Contains("CR_THICKNESS_DEV") Then

                For coun As Integer = 0 To excelTB.Rows.Count - 1
                    If Not excelTB.Rows(coun)("CR_THICKNESS_DEV") Is DBNull.Value Then
                        width_data &= Math.Round(excelTB.Rows(coun)("CR_THICKNESS_DEV") / 1000, 3) & ","
                        index &= coun & ","
                    End If
                Next
                width_data = width_data.Substring(0, width_data.Length - 1)
                'width_data = width_data.Split(",")

            End If
            lit1.Text = Nothing
            lit1.Text = " "
            Dim marker As String = Trim(severity)
            Dim val As String = Regex.Replace(marker, "[^A-Za-z0-9\.]", "")
            Dim width_data_a() As String = width_data.Split(",")
            Dim s As New StringBuilder("<script type='text/javascript'>")
            s.Append("var myChart = echarts.init(document.getElementById('main'));")
            s.Append("var colors = ['#5793f3', '#d14a61'];option = { title: {text: 'JCAP THICKNESS DEVIATION'},color: colors, tooltip: {  trigger: 'axis', formatter: function(params, ticket, callback) {   console.log(params); var res = 'Length(m) : '+ params[0].name; for (var i = 0, l = params.length; i < l; i++) { res += '<br/>' + 'Thickness(mm) : ' + params[i].value;    }    setTimeout(function() { callback(ticket, res);  }, 100);  return 'loading'; }  },toolbox: {show: true,feature:{dataZoom: {yAxisIndex: 'none' },magicType: {show: true, type: ['line', 'bar']},restore: {show: true}}},grid: { top: 70,bottom: 50},")
            s.Append("xAxis: [{ type: 'category',name:'Length(meters)',nameLocation:   'middle',nameGap: 30,splitArea: {show: false}, axisTick: {alignWithLabel: true }, axisLine: { onZero: false,lineStyle: {color: colors[1]}},")
            s.Append("axisPointer: {label: {formatter: function (params) {return 'Width'+  (params.seriesData.length ? '：' + params.seriesData[0].data : ''); } } }, data:[" & index & "] },")
            s.Append("{type: 'category',axisTick: {alignWithLabel: true},axisLine: {onZero: false,lineStyle: {color: colors[1]}}}],yAxis: [{type: 'value',name:'Thickness(mm)',nameLocation:   'middle',nameGap: 40,splitArea: {show: false} }],")
            s.Append("series: [{ type: 'line',smooth: true, data:[" & width_data & "],markLine : { itemStyle : {normal: {color:'#ff0000'}},data :[{yAxis:" & val & "},{yAxis:-" & val & "}],}}]};")
            s.Append("myChart.setOption(option);")
            s.Append("window.onresize = function() { myChart.resize();};")
            s.Append("</script>")
            lit1.Text = s.ToString()
        Catch ex As Exception
        End Try
    End Sub
    Function toDataTableDetail(ByRef ep As ExcelPackage) As DataTable
        Dim workSheet As ExcelWorksheet = ep.Workbook.Worksheets.First()
        Dim table As New DataTable
        For i As Integer = 0 To workSheet.Dimension.End.Column - 1
            Dim s = workSheet.Cells(1, i + 1).Text
            If s = "" Then
                s = "C" & i
            End If
            table.Columns.Add(s)
        Next

        For rowNumber As Integer = 2 To workSheet.Dimension.End.Row
            'If workSheet.Cells(rowNumber, 5).Text = "" Then
            '    Exit For
            'End If
            Dim row = workSheet.Cells(rowNumber, 1, rowNumber, workSheet.Dimension.End.Column)
            Dim newRow = table.NewRow()
            For Each cell In row
                newRow(cell.Start.Column - 1) = cell.Text
            Next

            table.Rows.Add(newRow)
        Next

        Return table
    End Function
End Class
