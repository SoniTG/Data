﻿Imports System.Data
Imports System.IO
Imports System.Web.Services
Imports System.Data.SqlClient
Imports System.Data.OleDb

Partial Class TSK_Chart_UTS_YS
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Dim dtSDFMDP As New DataTable
    Dim dtSDDCEP As New DataTable
    Dim dtSDHSBP As New DataTable
    Dim dtSDIMPP As New DataTable
    Dim dtSDR2CE As New DataTable
    Dim dt_plot As New DataTable


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            Try
                ' Dim dt As DataTable = Session("dt_master")
                Dim dt As DataTable
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))

                Dim CoilId As String = ""
                Dim Value As String = ""
                Dim grade As String = ""
                Dim db_name_str As String = ""
                Dim UTS_Min As String = ""
                Dim UTS_Max As String = ""
                Dim YS_Min As String = ""
                Dim YS_Max As String = ""
                ' Dim uts_value As Double = 0
                'Dim uts_coeff(), ys_coeff() As Double
                'Dim position_array_ys(), position_array_uts() As Integer
                'Dim filter, add_column_str As String

                ''grade = Request.QueryString("Grade")



                If Request.QueryString("CoilId") <> "" And Request.QueryString("Value") <> "" And Request.QueryString("UTSMin") <> "" And Request.QueryString("UTSMax") <> "" And Request.QueryString("YSMin") <> "" And Request.QueryString("YSMax") <> "" Then
                    CoilId = Request.QueryString("CoilId")
                    Value = Request.QueryString("Value")
                    'db_name_str = Request.QueryString("Value")
                    UTS_Min = Request.QueryString("UTSMin")
                    UTS_Max = Request.QueryString("UTSMax")
                    YS_Min = Request.QueryString("YSMin")
                    YS_Max = Request.QueryString("YSMax")

                    dt = objController.GetTSKDataForGroupDetails("TSK_Property_Pred_Lengthwise", CoilId)
                    'If Value = "UTS" Then

                    '    objController.PlotLineEChartForTSKChart(dt, Lit1, "container1", "plot1", "Length", "Pred_UTS", "Length", "Value")
                    'End If
                    'If Value = "YS" Then

                    '    objController.PlotLineEChartForTSKChart(dt, Lit1, "container1", "plot1", "Length", "Pred_YS", "Length", "Value")
                    'End If

                    'For i As Integer = 0 To dt.Rows.Count - 1
                    '    If dt.Rows(i)("HR_COIL_ID") = CoilId Then
                    '        grade = dt.Rows(i)("Grade")
                    '        If grade = "LC" Then
                    '            uts_coeff = {-2.230135804, 464.172412, 52.54695622, -490.9573871, 697.1667996, 143.849006, 62.6890293, 3704.550669, 98.98973578, -10526.68616, -431.2567754, 513.3645848, -0.011755185, -0.085712166, 0, 0, 375.518}
                    '            ys_coeff = {-3.878131548, -586.2108225, -28.62687826, -317.3201799, -348.9159796, -55.91522759, -60.3956354, -4155.802956, 20.69461165, -2764.830201, -386.928498, -365.3402191, -0.117365243, 0.025939517, 112.7530412, -0.018400687, -43.09}
                    '            position_array_uts = {12, 13}
                    '            position_array_ys = {12, 13}
                    '        ElseIf grade = "LCMA"
                    '            uts_coeff = {-2.92361726, 1056.929485, 99.83403311, -431.9206418, 756.848828, 83.16600953, 112.3251512, -4856.544943, 50.89151262, 2283.579354, 1670.111235, 1969.349592, -10722.78502, -0.52030023, 144.226273, -182.9898857, 416.2332482, 0.042245932, 0.053353389, 0.000286801, 0.05079482, -198.9818757, 187.75}
                    '            ys_coeff = {-2.481676916, -236.0722114, 5.045563137, 0, -126.0190107, 37.21346597, -29.31660677, 0, -143.349466, -109.0746584, 285.4587457, -142.6371342, -17886.77543, -0.174146852, -99.14824581, 150.9248598, -163.4019299, -0.070214389, 0.049271932, 0, -0.039113091, -73.1891958, 13.12}
                    '            position_array_uts = {17, 18}
                    '            position_array_ys = {17, 18}
                    '        ElseIf grade = "PeriC-MA"
                    '            uts_coeff = {-1.917303158, 479.4740156, 125.1229678, -361.6684269, 448.5773269, 116.1934212, 78.20267807, -2161.33259, -109.5314673, 2287.544962, 1921.617579, 12165.24975, 0.054026453, -5.057851636, 233.8391906, 561.0637831, 0.112948319, -0.330209019, 0.048774336, -183.3265761, 20.77259759, -31.37692633, 538.42}
                    '            ys_coeff = {-1.79960241, -364.3170361, -5.375871778, 0, -119.0753584, -36.25389227, 0, 0, -54.97939396, -90.31413192, 482.2864014, -3371.534019, 0.075788094, -55.309625, 68.10370745, -213.3674099, -0.060418991, 0.040825448, 0, 0, -2.517399504, -5.375871778, -73.1}
                    '            position_array_uts = {16, 17}
                    '            position_array_ys = {16, 17}
                    '        ElseIf grade = "MC/HC"
                    '            uts_coeff = {-3.659528542, 856.7975397, 89.48143685, -129.6986479, 497.6355582, 179.0911874, 3599.777263, 330.2088893, 796.294065, 1524.750464, 1221.133957, 77.20952727, -575.467115, 0.172112367, -0.366808252, -0.044996941, -410.8082302, 0, 360.39}
                    '            ys_coeff = {-1.901918577, -361.6740916, 13.18527071, 96.01366617, -121.3794586, 118.7706059, 1385.833336, -39.83239424, 537.7878332, 206.6848442, 122.2890948, 0, 0, -0.011974557, 0.173875098, -0.015866762, -781.504432, 100.2580916, -209.2}
                    '            position_array_uts = {16, 17}
                    '            position_array_ys = {16, 17}
                    '        ElseIf grade = "PeriC"
                    '            uts_coeff = {603.7111113, 70.7650059, -480.7881237, 540.4674703, 128.3405821, 91.6662846, 15.95099348, 3730.994774, 23.4459113, -0.000645304, -0.102912197, 0.168229729, -0.275667871, -2.248985908, -32.3597454, 463.26}
                    '            ys_coeff = {-370.4772689, 17.1742568, -232.4725245, -151.5398992, -16.03992763, 67.03657097, 90.22756548, 45.9890065, -27.27091154, -0.001050462, -0.157251165, 0.100722786, 0.059115926, -1.43607011, 88.40871762, 40.94}
                    '            position_array_uts = {11, 12}
                    '            position_array_ys = {11, 12}
                    '        End If
                    '        If dt.Rows(i)("db_plot_str") = "dtSDFMDP" Then
                    '            dt_plot = objController.GetDataForTSKChart("tsl-datalake-prod.TSKDWH_HSM.T_O_SDFMDP", CoilId, " COIL, POS, ITM01 ", " order by POS ")
                    '        ElseIf dt.Rows(i)("db_plot_str") = "dtSDDCEP" Then
                    '            dt_plot = objController.GetDataForTSKChart("tsl-datalake-prod.TSKDWH_HSM.T_O_SDDCEP", CoilId, " COIL, POS, ITM01 ", " order by POS ")
                    '        End If
                    '        dt_plot.Columns.Add("Pred_UTS")
                    '        dt_plot.Columns.Add("Pred_YS")

                    '        For k As Integer = 0 To dt_plot.Rows.Count - 1
                    '            uts_value = 0
                    '            For coeff_int As Integer = 0 To uts_coeff.Length - 2
                    '                If coeff_int <> position_array_uts(dt.Rows(i)("Index_coeff_start")) Then
                    '                    uts_value = uts_value + uts_coeff(coeff_int) * dt.Rows(i)(7 + coeff_int)
                    '                Else
                    '                    uts_value = uts_value + uts_coeff(coeff_int) * dt_plot.Rows(k)("ITM01")
                    '                End If

                    '            Next coeff_int
                    '            uts_value = uts_value + uts_coeff(uts_coeff.Length - 1)
                    '            dt_plot.Rows(k)("Pred_UTS") = Math.Round(uts_value, 0)
                    '        Next k
                    '        Exit For
                    '    End If
                    'Next i
                    If Value = "UTS" Then
                        Session("Name") = "UTS"
                        objController.PlotLineEChartForTSKChartNew(dt, Lit1, "container1", "plot1", "Length", "Pred_UTS", "Length", "Value, MPa", UTS_Min, UTS_Max, "")
                    End If
                    If Value = "YS" Then
                        Session("Name") = "YS"
                        objController.PlotLineEChartForTSKChartNew(dt, Lit1, "container1", "plot1", "Length", "Pred_YS", "Length", "Value, MPa", YS_Min, YS_Max, "")
                    End If


                End If
            Catch ex As Exception

            End Try
        End If
    End Sub





















End Class
