﻿Imports System.Data
Imports System.IO
Partial Class TSK_GroupwiseView1
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Dim p As String = Request("__EVENTARGUMENT")
            If p = "date" Then
                txtDate1_TextChanged()
            End If
        End If
        If Not Page.IsPostBack Then
            Try

                'Dim dah As New DataHandler
                'dah.GetDataSetFromQueryGC("select * from `tsl-datalake-prod.TSKDWH.V_A_HR_AGG_PARAMS` limit 100")

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                ' Dim dtStart1 As String = DateTime.Now.AddDays(-90).ToString("yyyy-MM-dd HH:mm")
                Dim dtStart1 As String = DateTime.Now.AddDays(-30).ToString("yyyy-MM-dd")
                ''Dim dtStart As DateTime = DateTime.Now.AddMonths(-4).ToString("yyyy-MM-dd HH:mm")
                'Dim dtEnd1 As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd1 As String = DateTime.Now.ToString("yyyy-MM-dd")
                'objController.PopulateGradeForTSKDetails(ddlGrade1, dtStart1, dtEnd1, " T_TSK_DETAILS")
                'Dim Filter As String = ""
                Dim Grade As String = ""
                'If Grade.ToLower <> "all" And Grade <> "" Then
                '    If Grade <> "" Then
                '        Filter &= " And GRADE = '" & Grade & "'"
                '    End If
                'End If
                'If ddlGrade1.SelectedItem.Text <> "" Then
                '    Grade = ddlGrade1.SelectedItem.Text

                'End If
                If ddlGrade1.Items.Count > 0 Then
                    Grade = ddlGrade1.SelectedItem.Text
                Else
                    Grade = " 1=1 "
                End If
                objController.PopulateGradeForTSKDetails(ddlGrade1, lstGrade1, dtStart1, dtEnd1, " `tsl-datalake-prod.TSKDWH.V_A_HR_AGG_PARAMS`", txtFromThickness1.Text, txtToThickness1.Text, txtFromWidth1.Text, txtToWidth1.Text, Grade)

                'objController.PopulateAimCodeForTSKDetails(lstGrade1, dtStart1, dtEnd1, ddlGrade1.SelectedItem.Text, " `tsl-datalake-prod.TSKDWH.V_A_HR_AGG_PARAMS`")
                Dim strGrade As String = getSelectedData(lstGrade1)
                If strGrade.Length > 0 Then
                    strGrade = "'" & strGrade.Replace(",", "','") & "'"
                End If


                Dim filter1 As String = " and 1=1"
                'If ddlGrade1.SelectedItem.Text.ToLower <> "all" Then
                '    filter1 &= " and GRADE = '" & ddlGrade1.SelectedItem.Text & "'"
                'End If
                If strGrade <> "" Then
                    filter1 &= " and HR_AIM_QCODE in (" & strGrade & ")"
                End If
                If txtFromThickness1.Text <> "" And txtToThickness1.Text <> "" Then
                    filter1 &= " and HR_THICKNESS between " & txtFromThickness1.Text & " and " & txtToThickness1.Text & ""
                End If
                If txtFromWidth1.Text <> "" And txtToWidth1.Text <> "" Then
                    'filter &= " and HR_SLAB_WIDTH between " & txtWidthFrom.Text / 1000 & " and " & txtWidthTo.Text / 1000 & ""
                    filter1 &= " and HR_SLAB_WIDTH between " & txtFromWidth1.Text & " and " & txtToWidth1.Text & ""
                End If


                DrawChartTop1(dtStart1, dtEnd1, filter1, ddlGrade1.SelectedItem.Text)
            Catch ex As Exception

            End Try
        End If
    End Sub
    Sub DrawChartTop1(ByVal FromDt As String, ByVal ToDt As String, ByVal Filter As String, ByVal Grade As String)
        Try
            Dim add_column_str As String
            Dim ArrMin() As Double
            Dim ArrMax() As Double
            add_column_str = ""
            If Grade = "LC" Then
                Filter &= " and (HR_LSA_C/10000 between 0.02 and 0.07) and (HR_LSA_MN/10000 between 0 and 2) and (HR_LSA_V/10000 between 0 and 0.005)  And (HR_LSA_NB/10000 between 0 and 0.005) and (HR_LSA_TI/10000 between 0 and 0.005) and ((HR_LSA_TI + HR_LSA_NB + HR_LSA_V)/10000 <= 0.005) "
                add_column_str = " HR_THICKNESS ,HR_LSA_C/10000 ,HR_LSA_MN/10000 ,HR_LSA_S/10000 ,HR_LSA_P/10000 ,HR_LSA_SI/10000 ,HR_LSA_TOT_AL/10000 ,(HR_LSA_N/10000)/10000 ,HR_LSA_CR/10000 ,HR_LSA_B/10000 ,HR_LSA_Cu/10000 ,HR_LSA_NI/10000 ,FM_EXT_TE  ,RT_CLG_TE,HR_LSA_MO/10000, FC_DCHRG_TE_TAIL "
                ArrMin = {1.6, 0.025, 0.117, 0.0016, 0.007, 0.003, 0.002, 0.0019, 0.012, 0, 0.004, 0.019, 827, 543, 0, 1169}
                'ArrMax = {10, 0.07, 0.51, 0.0223, 0.039, 0.25, 0.087, 0.0082, 0.04, 0.0024, 0.016, 0.035, 957, 703, 0.105, 1275}
                ArrMax = {10, 0.07, 0.51, 0.0223, 0.039, 0.25, 0.087, 0.0082, 0.04, 0.0024, 0.016, 0.035, 958, 704, 0.105, 1276}

            ElseIf Grade = "LCMA"
                Filter &= " and (HR_LSA_C/10000  between 0.02 And 0.07) And (HR_LSA_V/10000 between 0 And 0.25) And (HR_LSA_NB/10000 between 0 And 0.1) And (HR_LSA_TI/10000 between 0 And 0.12) And ((HR_LSA_TI + HR_LSA_NB + HR_LSA_V)/10000 > 0.005) "
                add_column_str = " HR_THICKNESS,HR_LSA_C/10000,HR_LSA_MN/10000,HR_LSA_S/10000,HR_LSA_P/10000,HR_LSA_SI/10000,HR_LSA_TOT_AL/10000,(HR_LSA_N/10000)/10000,HR_LSA_CR/10000,HR_LSA_TI/10000,HR_LSA_Nb/10000,(HR_LSA_V/10000),HR_LSA_B/10000,HR_LSA_Ca/10000 ,HR_LSA_Cu/10000,HR_LSA_NI/10000 ,HR_LSA_MO/10000,FM_EXT_TE,RT_CLG_TE,RM_R2_BAR_THK,FM_ENT_TE_TAIL ,FM_F7_REDUCTION "
                ArrMin = {1.6, 0.0298, 0.1411, 0.0006, 0.008, 0.006, 0.02, 0.001, 0.003, 0, 0, 0, 0, 0, 0.002, 0.0026, 0, 811, 378, 31000, 890, 0.07}
                'ArrMax = {25, 0.07, 2, 0.022, 0.14, 0.438, 0.1, 0.0107, 0.424, 0.109, 0.08, 0.068, 0.0024, 49, 0.382, 0.398, 0.255, 941, 663, 60000, 1059, 0.178}
                ArrMax = {25, 0.07, 2, 0.022, 0.14, 0.438, 0.1, 0.0107, 0.424, 0.109, 0.08, 0.068, 0.0024, 49, 0.382, 0.398, 0.255, 942, 664, 60001, 1060, 0.178}
            ElseIf Grade = "PeriC-MA"
                'Filter &= " and (HR_LSA_C/10000 between 0.071 and 0.16) and (HR_LSA_V/10000 between 0 And 0.2) And (HR_LSA_NB/10000 between 0 And 0.1) And (HR_LSA_TI/10000 between 0 And 0.12) And ((HR_LSA_TI + HR_LSA_NB +  HR_LSA_V)/10000 > 0.005) "
                Filter &= " and ((HR_LSA_C/10000 between 0.071 and 0.16) and (HR_LSA_V/10000 between 0 And 0.2) And (HR_LSA_NB/10000 between 0 And 0.1) And (HR_LSA_TI/10000 between 0 And 0.12) And ((HR_LSA_TI + HR_LSA_NB +  HR_LSA_V)/10000 > 0.005) or ((HR_LSA_C/10000 > 0.16 and HR_LSA_C/10000 < 0.18) and ((HR_LSA_TI + HR_LSA_NB + HR_LSA_V)/10000 > 0.005) and (2.5 * (0.5 - 1/10000*(HR_LSA_C + 0.04 * HR_LSA_MN + 0.1 * HR_LSA_NI + 0.7 * (HR_LSA_N/10000) - 0.14 * HR_LSA_SI - 0.04 *  HR_LSA_CR -0.1 * HR_LSA_MO - 0.24 * HR_LSA_TI - 0.7 * HR_LSA_S)) >= 0.85 )))"
                add_column_str = " HR_THICKNESS,HR_LSA_C/10000,HR_LSA_MN/10000,HR_LSA_S/10000,HR_LSA_P/10000,HR_LSA_SI/10000,HR_LSA_TOT_AL/10000,(HR_LSA_N/10000)/10000,HR_LSA_CR/10000,HR_LSA_TI/10000,HR_LSA_Nb/10000,HR_LSA_B/10000,HR_LSA_Ca/10000 ,HR_LSA_Cu/10000,HR_LSA_NI/10000 ,HR_LSA_MO/10000, HR_LSA_V/10000 , FM_EXT_TE,RT_CLG_TE,RT_INTER_TE,FM_F7_REDUCTION "
                ArrMin = {2, 0.071, 0.342, 0.001, 0.009, 0.006, 0.022, 0.0025, 0.013, 0, 0, 0, 0, 0.004, 0.012, 0, 0.001, 787, 518, 440, 0.079}
                'ArrMax = {25, 0.16, 1.952, 0.0147, 0.14, 0.46, 0.096, 0.0112, 0.46, 0.115, 0.065, 0.0017, 40, 0.392, 0.409, 0.255, 0.195, 950, 677, 853, 0.169}
                ArrMax = {25, 0.16, 1.952, 0.0147, 0.14, 0.46, 0.096, 0.0112, 0.46, 0.115, 0.065, 0.0017, 40, 0.392, 0.409, 0.255, 0.195, 951, 678, 854, 0.169}
            ElseIf Grade = "MC/HC"
                ' Filter &= " and (HR_LSA_C/10000 > 0.16 And HR_LSA_C/10000 < 0.18) And (2.5 * (0.5 - 1/10000*(HR_LSA_C + 0.04 * HR_LSA_MN + 0.1 * HR_LSA_NI +  0.7 * (HR_LSA_N/10000)/10000 - 0.14 * HR_LSA_SI - 0.04 * HR_LSA_CR - 0.1 * HR_LSA_MO - 0.24 * HR_LSA_TI - 0.7 * HR_LSA_S)) < 0.85 ) "
                Filter &= " and ((HR_LSA_C/10000 > 0.16 And HR_LSA_C/10000 < 0.18) And (2.5 * (0.5 - 1/10000*(HR_LSA_C + 0.04 * HR_LSA_MN + 0.1 * HR_LSA_NI +  0.7 * (HR_LSA_N/10000) - 0.14 * HR_LSA_SI - 0.04 * HR_LSA_CR - 0.1 * HR_LSA_MO - 0.24 * HR_LSA_TI - 0.7 * HR_LSA_S)) < 0.85 ) or ((HR_LSA_C/10000 >= 0.18 And HR_LSA_C/10000 < 0.8))) "
                add_column_str = " HR_THICKNESS,HR_LSA_C/10000,HR_LSA_MN/10000,HR_LSA_S/10000,HR_LSA_P/10000,HR_LSA_SI/10000,(HR_LSA_N/10000)/10000,HR_LSA_CR/10000,HR_LSA_TI/10000,HR_LSA_Nb/10000,(HR_LSA_V/10000),HR_LSA_Cu/10000,HR_LSA_MO/10000,FM_EXT_TE,RT_CLG_TE,RT_INTER_TE,HR_LSA_TOT_AL/10000 "
                ArrMin = {1.6, 0.161, 0.404, 0.001, 0.009, 0.005, 0.0025, 0.013, 0.001, 0.001, 0.001, 0.004, 0, 798, 505, 440, 0.006}
                'ArrMax = {25, 0.592, 1.59, 0.0136, 0.036, 0.31, 0.0094, 0.3, 0.037, 0.06, 0.11, 0.253, 0.057, 946, 659, 774, 0.1}
                ArrMax = {25, 0.592, 1.59, 0.0136, 0.036, 0.31, 0.0094, 0.3, 0.037, 0.06, 0.11, 0.253, 0.057, 947, 660, 775, 0.1}
            ElseIf Grade = "PeriC"
                'Filter &= " and (HR_LSA_C/10000 > 0.16 and HR_LSA_C/ 10000 < 0.18) And ((HR_LSA_TI + HR_LSA_NB + HR_LSA_V)/10000 > 0.005) And (2.5 * (0.5 - 1/10000*(HR_LSA_C + 0.04 *  HR_LSA_MN +0.1 * HR_LSA_NI + 0.7 * (HR_LSA_N / 10000) / 10000 - 0.14 * HR_LSA_SI - 0.04 * HR_LSA_CR - 0.1 * HR_LSA_MO - 0.24 * HR_LSA_TI -0.7 * HR_LSA_S)) >= 0.85 ) "
                Filter &= " and ((HR_LSA_C/10000 > 0.16 and HR_LSA_C/ 10000 < 0.18) And ((HR_LSA_TI + HR_LSA_NB + HR_LSA_V)/10000 > 0.005) And (2.5 * (0.5 - 1/10000*(HR_LSA_C + 0.04 *  HR_LSA_MN +0.1 * HR_LSA_NI + 0.7 * (HR_LSA_N / 10000)  - 0.14 * HR_LSA_SI - 0.04 * HR_LSA_CR - 0.1 * HR_LSA_MO - 0.24 * HR_LSA_TI -0.7 * HR_LSA_S)) >= 0.85 ) or (HR_LSA_C/10000 between 0.071 and 0.16) and (HR_LSA_V/10000 between 0 and 0.005)  And (HR_LSA_NB/10000 between 0 And 0.005) And (HR_LSA_TI/10000 between 0 And 0.005) And ((HR_LSA_TI + HR_LSA_NB + HR_LSA_V)/10000 <= 0.005))"
                add_column_str = " HR_LSA_C/10000,HR_LSA_MN/10000,HR_LSA_S/10000,HR_LSA_P/10000,HR_LSA_SI/10000,HR_LSA_TOT_AL/10000,HR_LSA_CR/10000,(HR_LSA_N/10000)/10000,HR_LSA_Cu/10000,RM_R2_BAR_THK,FM_ENT_TE_TAIL ,FM_EXT_TE,RT_CLG_TE,HR_THICKNESS,FM_F7_REDUCTION "
                ArrMin = {0.072, 0.133, 0.0009, 0.008, 0.004, 0.002, 0.005, 0.0021, 0.003, 31000, 815, 797, 510, 1.6, 0.074}
                'ArrMax = {0.16, 1.29, 0.0168, 0.14, 0.447, 0.098, 0.438, 0.0105, 0.367, 55000, 1064, 942, 673, 25, 0.189}
                ArrMax = {0.16, 1.29, 0.0168, 0.14, 0.447, 0.098, 0.438, 0.0105, 0.367, 55001, 1065, 943, 674, 25, 0.189}
            End If

            Dim strfrmDt As String = FromDt
            Dim strToDt As String = ToDt
            Dim value As Double = 0.0
            Dim dt As DataTable
            Dim dt1 As DataTable
            If Grade = "LC" Then
                dt = objController.GetDataForTSKDetails1("`tsl-datalake-prod.TSKDWH.V_A_HR_AGG_PARAMS`", strfrmDt, strToDt, "HR_CRT_DTTM", Filter, Grade, add_column_str)
                dt1 = objController.GetDataForTSKDetails2("`tsl-datalake-prod.TSKDWH.V_A_HR_AGG_PARAMS`", strfrmDt, strToDt, "HR_CRT_DTTM", Filter, Grade, add_column_str)

            Else
                dt = objController.GetDataForTSKDetails1("`tsl-datalake-prod.TSKDWH.V_A_HR_AGG_PARAMS`", strfrmDt, strToDt, "HR_CRT_DTTM", Filter, Grade, add_column_str)
            End If

            'Dim dt1 As DataTable = objController.GetDataForTSKDetails("`tsl-datalake-prod.TSKDWH.V_A_HR_AGG_PARAMS`", strfrmDt, strToDt, "HR_CRT_DTTM", Filter, Grade, "YS")
            Dim TotalNo As Double = 0.0
            Dim TotalNo1 As Double = 0.0
            Dim Within10Mpa As Double = 0.0
            Dim Within10Mpa1 As Double = 0.0
            Dim Within15Mpa As Double = 0.0
            Dim Within15Mpa1 As Double = 0.0
            Dim Within20Mpa As Double = 0.0
            Dim Within20Mpa1 As Double = 0.0
            Dim standev As Double = 0.0
            Dim standev1 As Double = 0.0
            If dt.Rows.Count > 0 Then
                If Grade = "LC" Then
                    value = 12.65 ' 8.35
                ElseIf Grade = "LCMA"
                    value = 16.46201434
                ElseIf Grade = "PeriC-MA"
                    value = 14.78454646
                ElseIf Grade = "MC/HC"
                    value = 14.753276
                ElseIf Grade = "PeriC"
                    value = 11.3975
                Else
                    value = 0.0
                End If
                If Grade = "LC" Then
                    objController.PlotScatterEChartForTSKGroupwiseView(dt1, Lit3, "container3", "plot3", "Predicted_YS", "HR_YS", "Predicted YS, MPa", "YS, MPa", value, TotalNo, Within10Mpa, Within15Mpa, Within20Mpa, standev, ArrMin, ArrMax)

                Else
                    objController.PlotScatterEChartForTSKGroupwiseView(dt, Lit3, "container3", "plot3", "Predicted_UTS", "HR_UTS", "Predicted UTS, MPa", "UTS, MPa", value, TotalNo, Within10Mpa, Within15Mpa, Within20Mpa, standev, ArrMin, ArrMax)
                End If

                ''objController.PlotLineEChartForTSKGroupwiseView(dt, Lit1, "container1", "plot1", "Predicted_UTS", "HR_UTS", "", "UTS, MPa", value, "Predicted UTS", "Actual UTS", ArrMin, ArrMax)
                'objController.PlotLineEChartForTSKGroupwiseView1(dt, Lit1, "container1", "plot1", "Predicted_UTS", "HR_UTS", "", "UTS, MPa", value, "Predicted", "Actual", ArrMin, ArrMax)


                lblN.Text = TotalNo
                lblW10Mpa.Text = Math.Round(Within10Mpa, 0)
                lblW15Mpa.Text = Math.Round(Within15Mpa, 0)
                lblW20Mpa.Text = Math.Round(Within20Mpa, 0)
                'lblStdev.Text = Math.Round(standev, 1)
            Else
                Lit3.Text = ""
                Lit3.Text &= "<script>$('#container3').html('<p>No Data</p>');</script>"
                Lit1.Text = ""
                Lit1.Text &= "<script>$('#container1').html('<p>No Data</p>');</script>"
            End If
            If dt.Rows.Count > 0 Then
                If Grade = "LC" Then
                    value = 16.73
                ElseIf Grade = "LCMA" Then
                    value = 13.809
                ElseIf Grade = "PeriC-MA" Then
                    value = 11.64622991
                ElseIf Grade = "MC/HC" Then
                    value = 12.63416
                ElseIf Grade = "PeriC" Then
                    value = 17.3055
                Else
                    value = 0.0
                End If
                'objController.PlotScatterEChartForTSKGroupwiseViewYS(dt1, Lit4, "container4", "plot4", "Predicted_YS", "HR_YS", "Predicted YS, Mpa", "YS, Mpa", value)
                objController.PlotScatterEChartForTSKGroupwiseView(dt, Lit4, "container4", "plot4", "Predicted_YS", "HR_YS", "Predicted YS, MPa", "YS, MPa", value, TotalNo1, Within10Mpa1, Within15Mpa1, Within20Mpa1, standev1, ArrMin, ArrMax)
                'objController.PlotLineEChartForTSKGroupwiseView1(dt, Lit2, "container2", "plot2", "Predicted_YS", "HR_YS", "", "YS, MPa", value, "Predicted", "Actual", ArrMin, ArrMax)
                lblN1.Text = TotalNo1
                lblW10Mpa1.Text = Math.Round(Within10Mpa1, 0)
                lblW15Mpa1.Text = Math.Round(Within15Mpa1, 0)
                lblW20Mpa1.Text = Math.Round(Within20Mpa1, 0)
                'lblStdev1.Text = Math.Round(standev1, 1)
            Else
                Lit4.Text = ""
                Lit4.Text &= "<script>$('#container4').html('<p>No Data</p>');</script>"
                Lit2.Text = ""
                Lit2.Text &= "<script>$('#container2').html('<p>No Data</p>');</script>"
            End If




        Catch ex As Exception

        End Try
    End Sub
    Private Sub txtDate1_TextChanged() '(sender As Object, e As EventArgs) 'Handles txtDate1.TextChanged



        Try
            'If ddlGrade1.SelectedItem.Text.ToLower = "all" Then


            Dim fromDt As String = hfFrom1.Value
            Dim toDt As String = hfTo1.Value



            '    Dim filter As String = " And 1=1"
            '    'If ddlGrade1.SelectedItem.Text.ToLower <> "all" Then
            '    '    filter &= " And GRADE = '" & ddlGrade1.SelectedItem.Text & "'"
            '    'End If
            '    Dim strGrade As String = getSelectedData(lstGrade1)
            '    If strGrade.Length > 0 Then
            '        strGrade = "'" & strGrade.Replace(",", "','") & "'"
            '    End If
            '    If strGrade <> "" Then
            '        filter &= " and HR_AIM_QCODE in (" & strGrade & ")"
            '    End If
            '    If txtFromThickness1.Text <> "" And txtToThickness1.Text <> "" Then
            '        filter &= " and HR_THICKNESS between " & txtFromThickness1.Text & " and " & txtToThickness1.Text & ""
            '        'divHolder.Attributes.Add("style", "display:none")
            '    End If
            '    If txtFromWidth1.Text <> "" And txtToWidth1.Text <> "" Then
            '        'filter &= " and HR_SLAB_WIDTH between " & txtWidthFrom.Text / 1000 & " and " & txtWidthTo.Text / 1000 & ""
            '        filter &= " and HR_SLAB_WIDTH between " & txtFromWidth1.Text & " and " & txtToWidth1.Text & ""
            '    End If
            '    DrawChartTop1(fromDt, toDt, filter, ddlGrade1.SelectedItem.Text)
            ''Dim Grade As String = ""

            ''If ddlGrade1.Items.Count > 0 Then
            ''    Grade = ddlGrade1.SelectedItem.Text
            ''Else
            ''    Grade = " 1=1 "
            ''End If
            ''objController.PopulateGradeForTSKDetails(ddlGrade1, lstGrade1, fromDt, toDt, " `tsl-datalake-prod.TSKDWH.V_A_HR_AGG_PARAMS`", txtFromThickness1.Text, txtToThickness1.Text, txtFromWidth1.Text, txtToWidth1.Text, Grade)


            Dim Grade As String = ""
            ddlGrade1.DataSource = ""
            ddlGrade1.DataBind()
            lstGrade1.DataSource = ""
            lstGrade1.DataBind()
            txtFromThickness1.Text = ""
            txtToThickness1.Text = ""
            txtFromWidth1.Text = ""
            txtToWidth1.Text = ""
            Lit1.Text = ""
            Lit2.Text = ""
            Lit3.Text = ""
            Lit4.Text = ""
            lblN.Text = ""
            lblN1.Text = ""
            lblW10Mpa.Text = ""
            lblW10Mpa1.Text = ""
            lblW15Mpa.Text = ""
            lblW15Mpa1.Text = ""
            lblW20Mpa.Text = ""
            lblW20Mpa1.Text = ""
            'lblStdev.Text = ""
            'lblStdev1.Text = ""

            If ddlGrade1.Items.Count > 0 Then
                Grade = ddlGrade1.SelectedItem.Text
            Else
                Grade = " 1=1 "
            End If
            objController.PopulateGradeForTSKDetails(ddlGrade1, lstGrade1, fromDt, toDt, " `tsl-datalake-prod.TSKDWH.V_A_HR_AGG_PARAMS`", txtFromThickness1.Text, txtToThickness1.Text, txtFromWidth1.Text, txtToWidth1.Text, Grade)



            'End If

        Catch ex As Exception

        End Try

    End Sub

    Private Sub ddlGrade1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlGrade1.SelectedIndexChanged
        Try

            Dim fromDt As String = hfFrom1.Value
            Dim toDt As String = hfTo1.Value


            Dim Grade As String = ""

            If ddlGrade1.Items.Count > 0 Then
                Grade = ddlGrade1.SelectedItem.Text
            Else
                Grade = " 1=1 "
            End If
            objController.PopulateGradeForTSKDetails(ddlGrade1, lstGrade1, fromDt, toDt, " `tsl-datalake-prod.TSKDWH.V_A_HR_AGG_PARAMS`", txtFromThickness1.Text, txtToThickness1.Text, txtFromWidth1.Text, txtToWidth1.Text, Grade)

            'objController.PopulateAimCodeForTSKDetails(lstGrade1, dtStart1, dtEnd1, ddlGrade1.SelectedItem.Text, " `tsl-datalake-prod.TSKDWH.V_A_HR_AGG_PARAMS`")
            Dim strGrade As String = getSelectedData(lstGrade1)
            If strGrade.Length > 0 Then
                strGrade = "'" & strGrade.Replace(",", "','") & "'"
            End If

            lblN.Text = ""
            'lblStdev.Text = ""
            lblW10Mpa.Text = ""
            lblW15Mpa.Text = ""
            lblW20Mpa.Text = ""
            lblN1.Text = ""
            'lblStdev1.Text = ""
            lblW10Mpa1.Text = ""
            lblW15Mpa1.Text = ""
            lblW20Mpa1.Text = ""
            Lit1.Text = ""
            Lit2.Text = ""
            Lit3.Text = ""
            Lit4.Text = ""

            'Dim filter As String = " and 1=1"
            ''If ddlGrade1.SelectedItem.Text.ToLower <> "all" Then
            ''    filter &= " and GRADE = '" & ddlGrade1.SelectedItem.Text & "'"
            ''End If
            'If strGrade <> "" Then
            '    filter &= " and HR_AIM_QCODE in (" & strGrade & ")"
            'End If
            'If txtFromThickness1.Text <> "" And txtToThickness1.Text <> "" Then
            '    filter &= " and HR_THICKNESS between " & txtFromThickness1.Text & " and " & txtToThickness1.Text & ""
            '    'divHolder.Attributes.Add("style", "display:none")
            'End If
            'If txtFromWidth1.Text <> "" And txtToWidth1.Text <> "" Then
            '    'filter &= " and HR_SLAB_WIDTH between " & txtWidthFrom.Text / 1000 & " and " & txtWidthTo.Text / 1000 & ""
            '    filter &= " and HR_SLAB_WIDTH between " & txtFromWidth1.Text & " and " & txtToWidth1.Text & ""
            'End If
            'DrawChartTop1(fromDt, toDt, filter, ddlGrade1.SelectedItem.Text)



        Catch ex As Exception

        End Try
    End Sub

    Private Sub txtFromThickness1_TextChanged(sender As Object, e As EventArgs) Handles txtFromThickness1.TextChanged
        'txtDate1_TextChanged(sender, e)
    End Sub

    Private Sub txtToThickness1_TextChanged(sender As Object, e As EventArgs) Handles txtToThickness1.TextChanged
        'txtDate1_TextChanged(sender, e)
    End Sub

    Private Sub txtFromWidth1_TextChanged(sender As Object, e As EventArgs) Handles txtFromWidth1.TextChanged
        'txtDate1_TextChanged(sender, e)
    End Sub

    Private Sub txtToWidth1_TextChanged(sender As Object, e As EventArgs) Handles txtToWidth1.TextChanged
        'txtDate1_TextChanged(sender, e)
    End Sub
    Function getSelectedData(ByRef lst As ListBox) As String
        Dim retVal As String = ""
        For Each lstItem As ListItem In lst.Items
            If lstItem.Selected = True Then
                retVal &= "," & lstItem.Text & ""
            End If
        Next

        If (retVal.Length > 0) Then
            Return retVal.Substring(1)
        Else
            Return retVal
        End If

    End Function

    Private Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click
        Try
            Dim fromDt As String = hfFrom1.Value
            Dim toDt As String = hfTo1.Value

            Dim filter As String = " And 1=1"
            'If ddlGrade1.SelectedItem.Text.ToLower <> "all" Then
            '    filter &= " And GRADE = '" & ddlGrade1.SelectedItem.Text & "'"
            'End If
            Dim strGrade As String = getSelectedData(lstGrade1)
            If strGrade.Length > 0 Then
                strGrade = "'" & strGrade.Replace(",", "','") & "'"
            End If
            If strGrade <> "" Then
                filter &= " and HR_AIM_QCODE in (" & strGrade & ")"
            End If
            If txtFromThickness1.Text <> "" And txtToThickness1.Text <> "" Then
                filter &= " and HR_THICKNESS between " & txtFromThickness1.Text & " and " & txtToThickness1.Text & ""
                'divHolder.Attributes.Add("style", "display:none")
            End If
            If txtFromWidth1.Text <> "" And txtToWidth1.Text <> "" Then
                'filter &= " and HR_SLAB_WIDTH between " & txtWidthFrom.Text / 1000 & " and " & txtWidthTo.Text / 1000 & ""
                filter &= " and HR_SLAB_WIDTH between " & txtFromWidth1.Text & " and " & txtToWidth1.Text & ""
            End If
            DrawChartTop1(fromDt, toDt, filter, ddlGrade1.SelectedItem.Text)
        Catch ex As Exception

        End Try
    End Sub
End Class
