﻿Imports System.Data
Imports System.IO
Partial Class TSK_Groupwise_Details_New
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim dtSDFMDP As New DataTable
    Dim dtSDDCEP As New DataTable
    Dim dtSDHSBP As New DataTable
    Dim dtSDIMPP As New DataTable
    Dim dtSDR2CE As New DataTable
    Public dt As DataTable
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Dim p As String = Request("__EVENTARGUMENT")
            If p = "date" Then
                txtDate1_TextChanged()
            End If
        End If
        If Not Page.IsPostBack Then
            Try

                'Dim dah As New DataHandler
                'dah.GetDataSetFromQueryGC("select * from `tsl-datalake-prod.TSKDWH.V_A_HR_AGG_PARAMS` limit 100")

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))

                Dim dtStart1 As String = DateTime.Now.AddDays(-9).ToString("yyyy-MM-dd 06:00:00")

                Dim dtEnd1 As String = DateTime.Now.ToString("yyyy-MM-dd 23:59:00")


                Dim Grade As String = ""

                If ddlGrade1.Items.Count > 0 Then
                    Grade = ddlGrade1.SelectedItem.Text.Trim()
                Else
                    Grade = " 1=1 "
                End If
                objController.PopulateGradeForTSKDetailsNew(ddlGrade1, lstGrade1, dtStart1, dtEnd1, "TSK_Property_Pred_Lengthwise", txtFromThickness1.Text, txtToThickness1.Text, txtFromWidth1.Text, txtToWidth1.Text, Grade)

                'objController.PopulateAimCodeForTSKDetails(lstGrade1, dtStart1, dtEnd1, ddlGrade1.SelectedItem.Text, " `tsl-datalake-prod.TSKDWH.V_A_HR_AGG_PARAMS`")
                Dim strGrade As String = getSelectedData(lstGrade1)
                If strGrade.Length > 0 Then
                    strGrade = "'" & strGrade.Replace(",", "','").Trim() & "'"
                End If


                Dim filter1 As String = " and 1=1"
                'If ddlGrade1.SelectedItem.Text.ToLower <> "all" Then
                '    filter1 &= " and GRADE = '" & ddlGrade1.SelectedItem.Text & "'"
                'End If
                If strGrade <> "" Then
                    filter1 &= " and HR_AIM_QCODE in (" & strGrade & ")"
                End If
                If txtFromThickness1.Text <> "" And txtToThickness1.Text <> "" Then
                    filter1 &= " and HR_THICKNESS between '" & txtFromThickness1.Text & "' and '" & txtToThickness1.Text & "'"
                End If
                If txtFromWidth1.Text <> "" And txtToWidth1.Text <> "" Then
                    'filter &= " and HR_SLAB_WIDTH between " & txtWidthFrom.Text / 1000 & " and " & txtWidthTo.Text / 1000 & ""
                    filter1 &= " and HR_SLAB_WIDTH between '" & txtFromWidth1.Text & "' and '" & txtToWidth1.Text & "'"
                End If


                ''DrawChartTop1(dtStart1, dtEnd1, filter1, ddlGrade1.SelectedItem.Text)
            Catch ex As Exception

            End Try
        End If
    End Sub
    Sub DrawChartTop1(ByVal FromDt As String, ByVal ToDt As String, ByVal Filter As String, ByVal Grade As String)
        Try
            'Dim add_column_str As String
            'Dim ArrMin(), ArrMax() As Double
            'Dim uts_coeff(), ys_coeff() As Double
            'Dim position_array_ys(), position_array_uts() As Integer

            ' position_array_uts --> this is the array index of the coefficients whose is stored. this index is related to the lengthwise database
            'add_column_str = ""
            If Grade = "LC" Then
                Filter &= " and Grade = 'LC' "
                ''Filter &= " and (HR_LSA_C/10000 between 0.02 and 0.07) and (HR_LSA_MN/10000 between 0 and 2) and (HR_LSA_V/10000 between 0 and 0.005)  And (HR_LSA_NB/10000 between 0 and 0.005) and (HR_LSA_TI/10000 between 0 and 0.005) and ((HR_LSA_TI + HR_LSA_NB + HR_LSA_V)/10000 <= 0.005) "
                ''add_column_str = " HR_THICKNESS ,HR_LSA_C/10000 ,HR_LSA_MN/10000 ,HR_LSA_S/10000 ,HR_LSA_P/10000 ,HR_LSA_SI/10000 ,HR_LSA_TOT_AL/10000 ,(HR_LSA_N/10000)/10000 ,HR_LSA_CR/10000 ,HR_LSA_B/10000 ,HR_LSA_Cu/10000 ,HR_LSA_NI/10000 ,FM_EXT_TE  ,RT_CLG_TE,HR_LSA_MO/10000, FC_DCHRG_TE_TAIL "
                'ArrMin = {1.6, 0.025, 0.117, 0.0016, 0.007, 0.003, 0.002, 0.0019, 0.012, 0, 0.004, 0.019, 827, 543, 0, 1169}
                ''ArrMax = {10, 0.07, 0.51, 0.0223, 0.039, 0.25, 0.087, 0.0082, 0.04, 0.0024, 0.016, 0.035, 957, 703, 0.105, 1275}
                'ArrMax = {10, 0.07, 0.51, 0.0223, 0.039, 0.25, 0.087, 0.0082, 0.04, 0.0024, 0.016, 0.035, 958, 704, 0.105, 1276}
                'uts_coeff = {-2.230135804, 464.172412, 52.54695622, -490.9573871, 697.1667996, 143.849006, 62.6890293, 3704.550669, 98.98973578, -10526.68616, -431.2567754, 513.3645848, -0.011755185, -0.085712166, 0, 0, 375.518}
                'ys_coeff = {-3.878131548, -586.2108225, -28.62687826, -317.3201799, -348.9159796, -55.91522759, -60.3956354, -4155.802956, 20.69461165, -2764.830201, -386.928498, -365.3402191, -0.117365243, 0.025939517, 112.7530412, -0.018400687, -43.09}
                'position_array_uts = {12, 13}
                'position_array_ys = {12, 13}
            ElseIf Grade = "LCMA"
                Filter &= " and Grade = 'LCMA' "
                ''Filter &= " and (HR_LSA_C/10000  between 0.02 And 0.07) And (HR_LSA_V/10000 between 0 And 0.25) And (HR_LSA_NB/10000 between 0 And 0.1) And (HR_LSA_TI/10000 between 0 And 0.12) And ((HR_LSA_TI + HR_LSA_NB + HR_LSA_V)/10000 > 0.005) "
                ''add_column_str = " HR_THICKNESS,HR_LSA_C/10000,HR_LSA_MN/10000,HR_LSA_S/10000,HR_LSA_P/10000,HR_LSA_SI/10000,HR_LSA_TOT_AL/10000,(HR_LSA_N/10000)/10000,HR_LSA_CR/10000,HR_LSA_TI/10000,HR_LSA_Nb/10000,(HR_LSA_V/10000),HR_LSA_B/10000,HR_LSA_Ca/10000 ,HR_LSA_Cu/10000,HR_LSA_NI/10000 ,HR_LSA_MO/10000,FM_EXT_TE,RT_CLG_TE,RM_R2_BAR_THK,FM_ENT_TE_TAIL ,FM_F7_REDUCTION "
                'ArrMin = {1.6, 0.0298, 0.1411, 0.0006, 0.008, 0.006, 0.02, 0.001, 0.003, 0, 0, 0, 0, 0, 0.002, 0.0026, 0, 811, 378, 31000, 890, 0.07}
                ''ArrMax = {25, 0.07, 2, 0.022, 0.14, 0.438, 0.1, 0.0107, 0.424, 0.109, 0.08, 0.068, 0.0024, 49, 0.382, 0.398, 0.255, 941, 663, 60000, 1059, 0.178}
                'ArrMax = {25, 0.07, 2, 0.022, 0.14, 0.438, 0.1, 0.0107, 0.424, 0.109, 0.08, 0.068, 0.0024, 49, 0.382, 0.398, 0.255, 942, 664, 60001, 1060, 0.178}
                'uts_coeff = {-2.92361726, 1056.929485, 99.83403311, -431.9206418, 756.848828, 83.16600953, 112.3251512, -4856.544943, 50.89151262, 2283.579354, 1670.111235, 1969.349592, -10722.78502, -0.52030023, 144.226273, -182.9898857, 416.2332482, 0.042245932, 0.053353389, 0.000286801, 0.05079482, -198.9818757, 187.75}
                'ys_coeff = {-2.481676916, -236.0722114, 5.045563137, 0, -126.0190107, 37.21346597, -29.31660677, 0, -143.349466, -109.0746584, 285.4587457, -142.6371342, -17886.77543, -0.174146852, -99.14824581, 150.9248598, -163.4019299, -0.070214389, 0.049271932, 0, -0.039113091, -73.1891958, 13.12}
                'position_array_uts = {17, 18}
                'position_array_ys = {17, 18}
            ElseIf Grade = "PeriC-MA"
                Filter &= " and Grade = 'PeriC-MA' "
                ''Filter &= " and (HR_LSA_C/10000 between 0.071 and 0.16) and (HR_LSA_V/10000 between 0 And 0.2) And (HR_LSA_NB/10000 between 0 And 0.1) And (HR_LSA_TI/10000 between 0 And 0.12) And ((HR_LSA_TI + HR_LSA_NB +  HR_LSA_V)/10000 > 0.005) "
                ''Filter &= " and ((HR_LSA_C/10000 between 0.071 and 0.16) and (HR_LSA_V/10000 between 0 And 0.2) And (HR_LSA_NB/10000 between 0 And 0.1) And (HR_LSA_TI/10000 between 0 And 0.12) And ((HR_LSA_TI + HR_LSA_NB +  HR_LSA_V)/10000 > 0.005) or ((HR_LSA_C/10000 > 0.16 and HR_LSA_C/10000 < 0.18) and ((HR_LSA_TI + HR_LSA_NB + HR_LSA_V)/10000 > 0.005) and (2.5 * (0.5 - 1/10000*(HR_LSA_C + 0.04 * HR_LSA_MN + 0.1 * HR_LSA_NI + 0.7 * (HR_LSA_N/10000) - 0.14 * HR_LSA_SI - 0.04 *  HR_LSA_CR -0.1 * HR_LSA_MO - 0.24 * HR_LSA_TI - 0.7 * HR_LSA_S)) >= 0.85 )))"
                ''add_column_str = " HR_THICKNESS,HR_LSA_C/10000,HR_LSA_MN/10000,HR_LSA_S/10000,HR_LSA_P/10000,HR_LSA_SI/10000,HR_LSA_TOT_AL/10000,(HR_LSA_N/10000)/10000,HR_LSA_CR/10000,HR_LSA_TI/10000,HR_LSA_Nb/10000,HR_LSA_B/10000,HR_LSA_Ca/10000 ,HR_LSA_Cu/10000,HR_LSA_NI/10000 ,HR_LSA_MO/10000,  FM_EXT_TE,RT_CLG_TE,RT_INTER_TE,FM_F7_REDUCTION , ln(HR_LSA_V/10000) as Ln_V, (HR_LSA_MN/10000*HR_LSA_MN/10000) as Mn_sq"
                'ArrMin = {2, 0.071, 0.342, 0.001, 0.009, 0.006, 0.022, 0.0025, 0.013, 0, 0, 0, 0, 0.004, 0.012, 0, 0.001, 787, 518, 440, 0.079}
                ''ArrMax = {25, 0.16, 1.952, 0.0147, 0.14, 0.46, 0.096, 0.0112, 0.46, 0.115, 0.065, 0.0017, 40, 0.392, 0.409, 0.255, 0.195, 950, 677, 853, 0.169}
                'ArrMax = {25, 0.16, 1.952, 0.0147, 0.14, 0.46, 0.096, 0.0112, 0.46, 0.115, 0.065, 0.0017, 40, 0.392, 0.409, 0.255, 0.195, 951, 678, 854, 0.169}
                'uts_coeff = {-1.917303158, 479.4740156, 125.1229678, -361.6684269, 448.5773269, 116.1934212, 78.20267807, -2161.33259, -109.5314673, 2287.544962, 1921.617579, 12165.24975, 0.054026453, -5.057851636, 233.8391906, 561.0637831, 0.112948319, -0.330209019, 0.048774336, -183.3265761, 20.77259759, -31.37692633, 538.42}
                'ys_coeff = {-1.79960241, -364.3170361, -5.375871778, 0, -119.0753584, -36.25389227, 0, 0, -54.97939396, -90.31413192, 482.2864014, -3371.534019, 0.075788094, -55.309625, 68.10370745, -213.3674099, -0.060418991, 0.040825448, 0, 0, -2.517399504, -5.375871778, -73.1}
                'position_array_uts = {16, 17}
                'position_array_ys = {16, 17}
            ElseIf Grade = "MC/HC"
                Filter &= " and Grade = 'MC/HC' "
                '' Filter &= " and (HR_LSA_C/10000 > 0.16 And HR_LSA_C/10000 < 0.18) And (2.5 * (0.5 - 1/10000*(HR_LSA_C + 0.04 * HR_LSA_MN + 0.1 * HR_LSA_NI +  0.7 * (HR_LSA_N/10000)/10000 - 0.14 * HR_LSA_SI - 0.04 * HR_LSA_CR - 0.1 * HR_LSA_MO - 0.24 * HR_LSA_TI - 0.7 * HR_LSA_S)) < 0.85 ) "
                ''Filter &= " and ((HR_LSA_C/10000 > 0.16 And HR_LSA_C/10000 < 0.18) And (2.5 * (0.5 - 1/10000*(HR_LSA_C + 0.04 * HR_LSA_MN + 0.1 * HR_LSA_NI +  0.7 * (HR_LSA_N/10000) - 0.14 * HR_LSA_SI - 0.04 * HR_LSA_CR - 0.1 * HR_LSA_MO - 0.24 * HR_LSA_TI - 0.7 * HR_LSA_S)) < 0.85 ) or ((HR_LSA_C/10000 >= 0.18 And HR_LSA_C/10000 < 0.8))) "
                ''add_column_str = " HR_THICKNESS,HR_LSA_C/10000,HR_LSA_MN/10000,HR_LSA_S/10000,HR_LSA_P/10000,HR_LSA_SI/10000,(HR_LSA_N/10000)/10000,HR_LSA_CR/10000,HR_LSA_TI/10000,HR_LSA_Nb/10000,(HR_LSA_V/10000),HR_LSA_Cu/10000,HR_LSA_MO/10000,FM_EXT_TE,RT_CLG_TE,RT_INTER_TE,HR_LSA_TOT_AL/10000 "
                'ArrMin = {1.6, 0.161, 0.404, 0.001, 0.009, 0.005, 0.0025, 0.013, 0.001, 0.001, 0.001, 0.004, 0, 798, 505, 440, 0.006}
                ''ArrMax = {25, 0.592, 1.59, 0.0136, 0.036, 0.31, 0.0094, 0.3, 0.037, 0.06, 0.11, 0.253, 0.057, 946, 659, 774, 0.1}
                'ArrMax = {25, 0.592, 1.59, 0.0136, 0.036, 0.31, 0.0094, 0.3, 0.037, 0.06, 0.11, 0.253, 0.057, 947, 660, 775, 0.1}
                'uts_coeff = {-3.659528542, 856.7975397, 89.48143685, -129.6986479, 497.6355582, 179.0911874, 3599.777263, 330.2088893, 796.294065, 1524.750464, 1221.133957, 77.20952727, -575.467115, 0.172112367, -0.366808252, -0.044996941, -410.8082302, 0, 360.39}
                'ys_coeff = {-1.901918577, -361.6740916, 13.18527071, 96.01366617, -121.3794586, 118.7706059, 1385.833336, -39.83239424, 537.7878332, 206.6848442, 122.2890948, 0, 0, -0.011974557, 0.173875098, -0.015866762, -781.504432, 100.2580916, -209.2}
                'position_array_uts = {16, 17}
                'position_array_ys = {16, 17}
            ElseIf Grade = "PeriC"
                Filter &= " and Grade = 'PeriC' "
                ''Filter &= " and (HR_LSA_C/10000 > 0.16 and HR_LSA_C/ 10000 < 0.18) And ((HR_LSA_TI + HR_LSA_NB + HR_LSA_V)/10000 > 0.005) And (2.5 * (0.5 - 1/10000*(HR_LSA_C + 0.04 *  HR_LSA_MN +0.1 * HR_LSA_NI + 0.7 * (HR_LSA_N / 10000) / 10000 - 0.14 * HR_LSA_SI - 0.04 * HR_LSA_CR - 0.1 * HR_LSA_MO - 0.24 * HR_LSA_TI -0.7 * HR_LSA_S)) >= 0.85 ) "
                ''Filter &= " and ((HR_LSA_C/10000 > 0.16 and HR_LSA_C/ 10000 < 0.18) And ((HR_LSA_TI + HR_LSA_NB + HR_LSA_V)/10000 > 0.005) And (2.5 * (0.5 - 1/10000*(HR_LSA_C + 0.04 *  HR_LSA_MN +0.1 * HR_LSA_NI + 0.7 * (HR_LSA_N / 10000)  - 0.14 * HR_LSA_SI - 0.04 * HR_LSA_CR - 0.1 * HR_LSA_MO - 0.24 * HR_LSA_TI -0.7 * HR_LSA_S)) >= 0.85 ) or (HR_LSA_C/10000 between 0.071 and 0.16) and (HR_LSA_V/10000 between 0 and 0.005)  And (HR_LSA_NB/10000 between 0 And 0.005) And (HR_LSA_TI/10000 between 0 And 0.005) And ((HR_LSA_TI + HR_LSA_NB + HR_LSA_V)/10000 <= 0.005))"
                ''add_column_str = " HR_LSA_C/10000,HR_LSA_MN/10000,HR_LSA_S/10000,HR_LSA_P/10000,HR_LSA_SI/10000,HR_LSA_TOT_AL/10000,HR_LSA_CR/10000,(HR_LSA_N/10000)/10000,HR_LSA_Cu/10000,RM_R2_BAR_THK,FM_ENT_TE_TAIL ,FM_EXT_TE,RT_CLG_TE,HR_THICKNESS,FM_F7_REDUCTION "
                'ArrMin = {0.072, 0.133, 0.0009, 0.008, 0.004, 0.002, 0.005, 0.0021, 0.003, 31000, 815, 797, 510, 1.6, 0.074}
                ''ArrMax = {0.16, 1.29, 0.0168, 0.14, 0.447, 0.098, 0.438, 0.0105, 0.367, 55000, 1064, 942, 673, 25, 0.189}
                'ArrMax = {0.16, 1.29, 0.0168, 0.14, 0.447, 0.098, 0.438, 0.0105, 0.367, 55001, 1065, 943, 674, 25, 0.189}
                'uts_coeff = {603.7111113, 70.7650059, -480.7881237, 540.4674703, 128.3405821, 91.6662846, 15.95099348, 3730.994774, 23.4459113, -0.000645304, -0.102912197, 0.168229729, -0.275667871, -2.248985908, -32.3597454, 463.26}
                'ys_coeff = {-370.4772689, 17.1742568, -232.4725245, -151.5398992, -16.03992763, 67.03657097, 90.22756548, 45.9890065, -27.27091154, -0.001050462, -0.157251165, 0.100722786, 0.059115926, -1.43607011, 88.40871762, 40.94}
                'position_array_uts = {11, 12}
                'position_array_ys = {11, 12}
            End If

            Dim strfrmDt As String = FromDt
            Dim strToDt As String = ToDt
            Dim value As Double = 0.0

            ''Dim dt As DataTable = objController.GetDataForTSKDetails1("`tsl-datalake-prod.TSKDWH.V_A_HR_AGG_PARAMS`", strfrmDt, strToDt, "HR_CRT_DTTM", Filter, Grade, add_column_str)
            'dt = objController.GetDataForTSKDetails_tdc("`tsl-datalake-prod.TSKDWH.V_A_HR_AGG_PARAMS`", strfrmDt, strToDt, "HR_CRT_DTTM", Filter, Grade, add_column_str)
            dt = objController.GetDataForTSKGroupDetails("TSK_Property_Pred_Lengthwise", strfrmDt, strToDt, Filter)

            If dt.Rows.Count = 0 Then
                Exit Sub
            End If
            'Dim CoilId As String = ""
            'Dim range(1), range_FMDP(1), range_DCEP(1), range3, range4, delta(uts_coeff.Length - 1) As Double
            'Dim select_int As Integer = 0

            'Dim Lengthwise_db_STR() As String = {"dtSDFMDP", "dtSDDCEP"}

            ''select_dt = ""
            'dt.Columns.Add("Grade")
            'dt.Columns.Add("DB_PLOT_STR")
            'dt.Columns.Add("UTS_outlimit")
            'dt.Columns.Add("YS_outlimit")
            'dt.Columns.Add("Index_coeff_start")

            ''dtSDFMDP = 0
            ''dtSDDCEP = 1
            ''dtSDIMPP = 2
            ''dtSDHSBP = 3
            ''dtSDR2CE = 4


            ''Step 1: For each data table extract hte length wise parameters
            ''Step 2: For each dt find the min-max of the parameter after removing head/tail portion
            ''Step 3: find in which dt, the range is high [using the coefficients;;;select the dt
            ''step 4: find the UTS and YS along the length for that dt
            'For i As Integer = 0 To dt.Rows.Count - 1
            '    CoilId = dt.Rows(i)("HR_COIL_ID")
            '    dt.Rows(i)("Grade") = Grade
            '    dtSDFMDP = objController.GetDataForTSKChart("tsl-datalake-prod.TSKDWH_HSM.T_O_SDFMDP", CoilId, " COIL, POS, ITM01 ", " order by POS ") ' FM delivery pyro
            '    dtSDDCEP = objController.GetDataForTSKChart("tsl-datalake-prod.TSKDWH_HSM.T_O_SDDCEP", CoilId, " COIL, POS, ITM01 ", " order by POS ") ' down coiler entry pyro 
            '    dtSDIMPP = objController.GetDataForTSKChart("tsl-datalake-prod.TSKDWH_HSM.T_O_SDIMPP", CoilId, " COIL, POS, ITM01 ", " order by POS ") ' intermediate positin pyro 
            '    'dtSDHSBP = objController.GetDataForTSKChart("tsl-datalake-prod.TSKDWH_HSM.T_O_SDHSBP", CoilId, " COIL, POS, ITM01 ", " order by POS ") ' HSB entry pyro
            '    'dtSDR2CE = objController.GetDataForTSKChart("tsl-datalake-prod.TSKDWH_HSM.T_O_SDR2CE", CoilId, " COIL, POS, ITM12 ", " order by PASSNO, POS ") ' R2 center data itm12 gauge meter thickness
            '    'send the table , column name and the cutoff limit to remove outliers where are very low
            '    range_FMDP = find_range_fn(dtSDFMDP, "ITM01", 500)
            '    range_DCEP = find_range_fn(dtSDDCEP, "ITM01", 500)
            '    'dt.Rows(i)("DB_PLOT_STR") = position_array_uts(0)
            '    range(0) = range_FMDP.Max - range_FMDP.Min
            '    range(1) = range_DCEP.Max - range_DCEP.Min
            '    select_int = 0
            '    For j As Integer = 0 To position_array_uts.Length - 1
            '        delta(j) = Math.Abs(range(j) * uts_coeff(position_array_uts(j)))
            '        If j > 0 Then
            '            If delta(j) > delta(j - 1) Then
            '                ' dt.Rows(i)("DB_PLOT_STR") = position_array_uts(j)
            '                dt.Rows(i)("DB_PLOT_STR") = Lengthwise_db_STR(j)
            '                select_int = j
            '            End If
            '        End If
            '    Next j
            '    For j As Integer = 0 To position_array_uts.Length - 1
            '        delta(j) = Math.Abs(range(j) * uts_coeff(position_array_uts(j)))
            '        If j > 0 Then
            '            If delta(j) > delta(j - 1) Then
            '                ' dt.Rows(i)("DB_PLOT_STR") = position_array_uts(j)
            '                dt.Rows(i)("DB_PLOT_STR") = Lengthwise_db_STR(j)
            '                select_int = j
            '            End If
            '        End If
            '    Next j


            '    Dim select_dt As New DataTable
            '    Dim select_range(1) As Double
            '    If select_int = 0 Then
            '        select_dt = dtSDFMDP
            '        select_range = range_FMDP
            '        dt.Rows(i)("DB_PLOT_STR") = Lengthwise_db_STR(select_int)
            '        dt.Rows(i)("Index_coeff_start") = select_int
            '    ElseIf select_int = 1 Then
            '        select_dt = dtSDDCEP
            '        select_range = range_DCEP
            '        dt.Rows(i)("DB_PLOT_STR") = Lengthwise_db_STR(select_int)
            '        dt.Rows(i)("Index_coeff_start") = select_int
            '    ElseIf select_int = 2 Then
            '    ElseIf select_int = 3 Then

            '    End If

            '    Dim uts_value As Double = 0
            '    If dt.Rows(i)("UTS_MAX") = 0 Then
            '        dt.Rows(i)("UTS_MAX") = 10000
            '    End If
            '    If dt.Rows(i)("YS_MAX") = 0 Then
            '        dt.Rows(i)("YS_MAX") = 10000
            '    End If
            '    For k As Integer = 0 To select_range.Length - 1
            '        uts_value = 0
            '        For coeff_int As Integer = 0 To uts_coeff.Length - 2
            '            If coeff_int <> position_array_uts(select_int) Then
            '                uts_value = uts_value + uts_coeff(coeff_int) * dt.Rows(i)(7 + coeff_int)
            '            Else
            '                uts_value = uts_value + uts_coeff(coeff_int) * select_range(k)
            '            End If

            '        Next coeff_int
            '        uts_value = uts_value + uts_coeff(uts_coeff.Length - 1)

            '        If uts_value < dt.Rows(i)("UTS_MIN") Or uts_value > dt.Rows(i)("UTS_MAX") Then
            '            dt.Rows(i)("UTS_outlimit") = "YES"
            '            Exit For
            '        Else
            '            dt.Rows(i)("UTS_outlimit") = "NO"
            '        End If
            '    Next k



            '    'For k As Integer = 0 To select_dt.Rows.Count - 1
            '    '    For coeff_int As Integer = 0 To uts_coeff.Length - 2
            '    '        If coeff_int <> position_array_uts(select_int) Then
            '    '            uts_value = uts_value + uts_coeff(coeff_int) * dt.Rows(i)(7 + coeff_int)
            '    '        Else
            '    '            uts_value = uts_value + uts_coeff(coeff_int) * select_dt.Rows(k)("ITM01")
            '    '        End If

            '    '    Next coeff_int
            '    '    uts_value = uts_value + uts_coeff(uts_coeff.Length - 1)
            '    '    select_dt.Rows(k)("UTS_Pred") = uts_value
            '    'Next k

            'Next i
            ''CoilId = Request.QueryString("CoilId")
            ''    Value = Request.QueryString("Value")
            'Session("dt_master") = dt

            If dt.Rows.Count > 0 Then

                gvData.DataSource = dt
                gvData.DataBind()
                gvData.UseAccessibleHeader = True
                gvData.HeaderRow.TableSection = TableRowSection.TableHeader


            End If




        Catch ex As Exception
            ex.ToString()
        End Try
    End Sub
    'Function find_range_fn(ByVal dt As DataTable, ByVal col As String, cutoff As Double)
    '    Dim data_array(dt.Rows.Count - 1), data_array2(dt.Rows.Count - 1) As Integer
    '    Dim stdev, avg_val As Double
    '    Dim min_max(1) As Double
    '    Dim count As Integer = 0
    '    For i As Integer = 0 To dt.Rows.Count - 1
    '        If dt.Rows(i)(col) > cutoff Then
    '            ReDim Preserve data_array(count)
    '            data_array(count) = dt.Rows(i)(col)
    '            count = count + 1
    '        End If
    '    Next i
    '    avg_val = objController.avg(data_array)
    '    stdev = objController.stdDev(data_array)
    '    count = 0
    '    ReDim data_array2(0)
    '    For i As Integer = 9 To data_array.Length - 10
    '        If data_array(i) > avg_val - 5 * stdev Then
    '            ReDim Preserve data_array2(count)
    '            data_array2(count) = dt.Rows(i)(col)
    '            count = count + 1
    '        End If
    '    Next i
    '    stdev = objController.stdDev(data_array2)
    '    min_max(0) = data_array2.Min()
    '    min_max(1) = data_array2.Max()
    '    Return (min_max)
    'End Function
    Private Sub txtDate1_TextChanged() '(sender As Object, e As EventArgs) 'Handles txtDate1.TextChanged



        Try





            Dim fromDt As String = hfFrom1.Value
                Dim toDt As String = hfTo1.Value

                'Dim fromDt As String = "2022-03-14 06:00:00"

                'Dim toDt As String = "2022-03-14 23:59:00"


                Dim Grade As String = ""
                ddlGrade1.DataSource = ""
                ddlGrade1.DataBind()
                lstGrade1.DataSource = ""
                lstGrade1.DataBind()
                txtFromThickness1.Text = ""
                txtToThickness1.Text = ""
                txtFromWidth1.Text = ""
                txtToWidth1.Text = ""
            gvData.DataSource = Nothing
            gvData.DataBind()

            If ddlGrade1.Items.Count > 0 Then
                    Grade = ddlGrade1.SelectedItem.Text.Trim()
                Else
                    Grade = " 1=1 "
                End If
                'objController.PopulateGradeForTSKDetails(ddlGrade1, lstGrade1, fromDt, toDt, " `tsl-datalake-prod.TSKDWH.V_A_HR_AGG_PARAMS`", txtFromThickness1.Text, txtToThickness1.Text, txtFromWidth1.Text, txtToWidth1.Text, Grade)
                objController.PopulateGradeForTSKDetailsNew(ddlGrade1, lstGrade1, fromDt, toDt, "TSK_Property_Pred_Lengthwise", txtFromThickness1.Text, txtToThickness1.Text, txtFromWidth1.Text, txtToWidth1.Text, Grade)





        Catch ex As Exception

        End Try

    End Sub

    Private Sub ddlGrade1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlGrade1.SelectedIndexChanged
        Try

            Dim fromDt As String = hfFrom1.Value
            Dim toDt As String = hfTo1.Value

            'Dim fromDt As String = "2022-03-14 06:00:00"

            'Dim toDt As String = "2022-03-14 23:59:00"
            gvData.DataSource = Nothing
            gvData.DataBind()
            Dim Grade As String = ""

            If ddlGrade1.Items.Count > 0 Then
                Grade = ddlGrade1.SelectedItem.Text.Trim()
            Else
                Grade = " 1=1 "
            End If
            'objController.PopulateGradeForTSKDetails(ddlGrade1, lstGrade1, fromDt, toDt, " `tsl-datalake-prod.TSKDWH.V_A_HR_AGG_PARAMS`", txtFromThickness1.Text, txtToThickness1.Text, txtFromWidth1.Text, txtToWidth1.Text, Grade)
            objController.PopulateGradeForTSKDetailsNew(ddlGrade1, lstGrade1, fromDt, toDt, "TSK_Property_Pred_Lengthwise", txtFromThickness1.Text, txtToThickness1.Text, txtFromWidth1.Text, txtToWidth1.Text, Grade)

            'objController.PopulateAimCodeForTSKDetails(lstGrade1, dtStart1, dtEnd1, ddlGrade1.SelectedItem.Text, " `tsl-datalake-prod.TSKDWH.V_A_HR_AGG_PARAMS`")
            Dim strGrade As String = getSelectedData(lstGrade1)
            If strGrade.Length > 0 Then
                strGrade = "'" & strGrade.Replace(",", "','").Trim() & "'"
            End If







        Catch ex As Exception

        End Try
    End Sub

    Private Sub txtFromThickness1_TextChanged(sender As Object, e As EventArgs) Handles txtFromThickness1.TextChanged
        'txtDate1_TextChanged(sender, e)
    End Sub

    Private Sub txtToThickness1_TextChanged(sender As Object, e As EventArgs) Handles txtToThickness1.TextChanged
        'txtDate1_TextChanged(sender, e)
    End Sub

    Private Sub txtFromWidth1_TextChanged(sender As Object, e As EventArgs) Handles txtFromWidth1.TextChanged
        'txtDate1_TextChanged(sender, e)
    End Sub

    Private Sub txtToWidth1_TextChanged(sender As Object, e As EventArgs) Handles txtToWidth1.TextChanged
        'txtDate1_TextChanged(sender, e)
    End Sub
    Function getSelectedData(ByRef lst As ListBox) As String
        Dim retVal As String = ""
        For Each lstItem As ListItem In lst.Items
            If lstItem.Selected = True Then
                retVal &= "," & lstItem.Text & ""
            End If
        Next

        If (retVal.Length > 0) Then
            Return retVal.Substring(1)
        Else
            Return retVal
        End If

    End Function

    Private Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click
        Try
            Dim fromDt As String = hfFrom1.Value
            Dim toDt As String = hfTo1.Value
            'Dim fromDt As String = "2022-03-14 06:00:00" 'DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd 06:00:00")

            'Dim toDt As String = "2022-03-14 23:59:00"

            Dim filter As String = " And 1=1"
            'If ddlGrade1.SelectedItem.Text.ToLower <> "all" Then
            '    filter &= " And GRADE = '" & ddlGrade1.SelectedItem.Text & "'"
            'End If
            Dim strGrade As String = getSelectedData(lstGrade1)
            If strGrade.Length > 0 Then
                strGrade = "'" & strGrade.Replace(",", "','").Trim() & "'"
            End If
            If strGrade <> "" Then
                filter &= " and QCode in (" & strGrade & ")"
            End If
            If txtFromThickness1.Text <> "" And txtToThickness1.Text <> "" Then
                filter &= " and Thickness between '" & txtFromThickness1.Text & "' and '" & txtToThickness1.Text & "'"
                'divHolder.Attributes.Add("style", "display:none")
            End If
            If txtFromWidth1.Text <> "" And txtToWidth1.Text <> "" Then
                'filter &= " and HR_SLAB_WIDTH between " & txtWidthFrom.Text / 1000 & " and " & txtWidthTo.Text / 1000 & ""
                filter &= " and Width between '" & txtFromWidth1.Text & "' and '" & txtToWidth1.Text & "'"
            End If
            DrawChartTop1(fromDt, toDt, filter, ddlGrade1.SelectedItem.Text.Trim())
        Catch ex As Exception

        End Try
    End Sub

    Private Sub gvData_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles gvData.RowCommand
        Try
            Dim index As Integer = CType(CType(e.CommandSource, Button).NamingContainer, GridViewRow).RowIndex
            'Dim coilid As String = gvData.Rows(index).Cells(1).Text.ToString()
            Dim coilid As String = CType(gvData.Rows(index).Cells(0).FindControl("lblHrCoilId"), Label).Text.Trim()
            Dim Value As String = CType(e.CommandSource, Button).Text.Trim()
            'Dim dt As String = CDate(gvData.Rows(index).Cells(2).Text).ToString("dd-MM-yyyy HH:mm:ss")
            'Dim grade As String = gvData.Rows(index).Cells(3).Text.ToString()
            'Dim dt As String = CType(e.CommandSource, Button).CommandArgument
            ''Dim dtFrom As Date = CDate("01-" & dt.Substring(0, 2) & "-" & dt.Substring(3, 4))
            ''Dim dtFrom As Date = CDate(dt.Substring(0, 4) & "-" & dt.Substring(6, 7) & "- 01").ToString("yyyy-MM-dd")
            ''Dim dtTo As Date = dtFrom.AddMonths(1).AddDays(-1)
            'Dim s As String = "window.open('CRM_DailyReport.aspx?ParamName=" & param & "&DateVal=" & CDate("01-" & dt).ToString("yyyy-MM-dd") & "','_blank');"
            'Page.ClientScript.RegisterStartupScript(Me.GetType(), "alertscript", s, True)

            Dim Grade As String = ""
            Dim Filter As String = ""
            Dim db_name_str As String = ""
            Dim UTS_Min As String=""
            Dim UTS_Max As String = ""
            Dim YS_Min As String = ""
            Dim YS_Max As String = ""
            Grade = CType(gvData.Rows(index).Cells(0).FindControl("lblGrade"), Label).Text.Trim()
            db_name_str = CType(gvData.Rows(index).Cells(0).FindControl("lblGrade"), Label).Text.Trim()
            UTS_Min = CType(gvData.Rows(index).Cells(0).FindControl("lblUTSMin"), Label).Text.Trim()
            UTS_Max = CType(gvData.Rows(index).Cells(0).FindControl("lblUTSMax"), Label).Text.Trim()
            YS_Min = CType(gvData.Rows(index).Cells(0).FindControl("lblYSMin"), Label).Text.Trim()
            YS_Max = CType(gvData.Rows(index).Cells(0).FindControl("lblYSMax"), Label).Text.Trim()
            Dim s As String = "window.open('TSK_Chart_UTS_YS.aspx?CoilId=" & coilid & "&Value=" & Value & "&UTSMin=" & UTS_Min & "&UTSMax=" & UTS_Max & "&YSMin=" & YS_Min & "&YSMax=" & YS_Max & "','_blank');"
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "alertscript", s, True)

        Catch ex As Exception

        End Try
    End Sub


    Private Sub gvData_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles gvData.RowDataBound
        'If e.Row.RowType = DataControlRowType.DataRow Then
        '    Dim PredictedYS As Double = 0.0
        '    Dim ActualYS As Double = 0.0
        Dim UTS_chk_str As String = ""
        Dim YS_chk_str As String = ""
        '    Dim db_name_str As String = ""
        '    Dim grade_str As String = ""
        '    Dim index_coeff As Int32


        '    'dt.Columns.Add("YS_outlimit")
        '    'dt.Columns.Add("Index_coeff_start")

        '    'Dim uts_value As Double = 0
        '    'Dim dt_plot As DataTable
        '    'PredictedYS = Double.Parse(e.Row.Cells(6).Text)
        '    'ActualYS = Double.Parse(e.Row.Cells(7).Text)
        '    If Not IsDBNull(DataBinder.Eval(e.Row.DataItem, "UTS_outlimit")) Then
        '        UTS_chk_str = DataBinder.Eval(e.Row.DataItem, "UTS_outlimit")
        '        If UTS_chk_str = "YES" Then
        '            Dim btnYS As Button = CType(e.Row.FindControl("btnUTS"), Button)
        '            btnYS.BackColor = Drawing.Color.Red
        '            btnYS.ForeColor = Drawing.Color.AntiqueWhite
        '        End If

        '    End If

        '    If Not IsDBNull(DataBinder.Eval(e.Row.DataItem, "DB_PLOT_STR")) Then
        '        db_name_str = DataBinder.Eval(e.Row.DataItem, "DB_PLOT_STR")
        '    End If
        '    If Not IsDBNull(DataBinder.Eval(e.Row.DataItem, "Grade")) Then
        '        grade_str = DataBinder.Eval(e.Row.DataItem, "Grade")
        '    End If
        '    If Not IsDBNull(DataBinder.Eval(e.Row.DataItem, "Index_coeff_start")) Then
        '        index_coeff = DataBinder.Eval(e.Row.DataItem, "Index_coeff_start")
        '    End If


        '    If Not IsDBNull(DataBinder.Eval(e.Row.DataItem, "Predicted_YS")) Then
        '        PredictedYS = DataBinder.Eval(e.Row.DataItem, "Predicted_YS")
        '    End If

        '    If Not IsDBNull(DataBinder.Eval(e.Row.DataItem, "HR_YS")) Then
        '        ActualYS = DataBinder.Eval(e.Row.DataItem, "HR_YS")
        '    End If




        'End If
        Try
            If e.Row.RowType = DataControlRowType.DataRow Then
                'If e.Row.Cells(13).Text = "N" Then
                '    Dim btnUTS As Button = CType(e.Row.FindControl("btnUTS"), Button)
                '    btnUTS.BackColor = Drawing.Color.Green
                '    btnUTS.ForeColor = Drawing.Color.AntiqueWhite
                'Else
                '    Dim btnUTS As Button = CType(e.Row.FindControl("btnUTS"), Button)
                '    btnUTS.BackColor = Drawing.Color.Red
                '    btnUTS.ForeColor = Drawing.Color.AntiqueWhite
                'End If
                'If e.Row.Cells(14).Text = "N" Then
                '    Dim btnYS As Button = CType(e.Row.FindControl("btnYS"), Button)
                '    btnYS.BackColor = Drawing.Color.Green
                '    btnYS.ForeColor = Drawing.Color.AntiqueWhite
                'Else
                '    Dim btnYS As Button = CType(e.Row.FindControl("btnYS"), Button)
                '    btnYS.BackColor = Drawing.Color.Red
                '    btnYS.ForeColor = Drawing.Color.AntiqueWhite
                'End If

                If Not IsDBNull(DataBinder.Eval(e.Row.DataItem, "OutLimit_uts")) Then
                    UTS_chk_str = DataBinder.Eval(e.Row.DataItem, "OutLimit_uts")
                    If Trim(UTS_chk_str) = "Y" Then
                        Dim btnUTS As Button = CType(e.Row.FindControl("btnUTS"), Button)
                        btnUTS.BackColor = Drawing.Color.Red
                        btnUTS.ForeColor = Drawing.Color.AntiqueWhite
                    Else
                        Dim btnUTS As Button = CType(e.Row.FindControl("btnUTS"), Button)
                        btnUTS.BackColor = Drawing.Color.Green
                        btnUTS.ForeColor = Drawing.Color.AntiqueWhite
                    End If

                End If

                If Not IsDBNull(DataBinder.Eval(e.Row.DataItem, "OutLimit_ys")) Then
                    YS_chk_str = DataBinder.Eval(e.Row.DataItem, "OutLimit_ys")
                    If Trim(YS_chk_str) = "Y" Then
                        Dim btnYS As Button = CType(e.Row.FindControl("btnYS"), Button)
                        btnYS.BackColor = Drawing.Color.Red
                        btnYS.ForeColor = Drawing.Color.AntiqueWhite
                    Else
                        Dim btnYS As Button = CType(e.Row.FindControl("btnYS"), Button)
                        btnYS.BackColor = Drawing.Color.Green
                        btnYS.ForeColor = Drawing.Color.AntiqueWhite
                    End If

                End If



            End If

        Catch ex As Exception

        End Try
    End Sub

End Class
