﻿Imports System.Data
Imports System.IO
Imports System.Web.Services

Partial Class Exception_Coils
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim objDataHandler As New DataHandler
    Dim coil_count As Integer = 0


    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Sub AddSearchCoilInList(ByVal coilid As String)
        cblcoilid.Items.Clear()
        If coilid = "" Then
            PopulateCoilID()
        Else
            cblcoilid.Items.Add(New ListItem(coilid.Trim, coilid.Trim))
        End If

    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    txtDate_TextChanged()
                End If
                Dim t As String = Request("__EVENTTARGET")
                If t = "searchcoil" Then
                    AddSearchCoilInList(p)
                End If
            Catch ex As Exception


            End Try

        End If

        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd 06:00:00")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd 06:00:00")
                hfFrom.Value = dtStart
                hfTo.Value = dtEnd
                PopulateCoilID()

                PopulateParameters()
                If coil_count > 0 Then
                    'GetData()
                    For i As Integer = 0 To cblParameters.Items.Count - 1
                        If i = 2 Then
                            Exit For
                        End If
                        cblParameters.Items(i).Selected = True
                    Next

                    btnSubmit_Click(sender, e)
                End If

            Catch ex As Exception

            End Try

        End If

    End Sub

    Sub PopulateCoilID()
        Dim dt As New DataTable
        Dim dtStart As String = hfFrom.Value
        Dim dtEnd As String = hfTo.Value
        dt = objDataHandler.GetDataSetFromQuery("select distinct  [Coil_ID],[DT] from [TSM_Process_data].[dbo].[TSM_MAILALERT]  where [DT] between   '" & hfFrom.Value & "' and '" & hfTo.Value & "'  and Coil_ID is not null  order by [DT]").Tables(0)
        cblcoilid.DataSource = dt
        cblcoilid.DataTextField = "Coil_ID"
        cblcoilid.DataValueField = "Coil_ID"
        cblcoilid.DataBind()
        coil_count = dt.Rows.Count
        For Each l As ListItem In cblcoilid.Items
            l.Selected = True
        Next
    End Sub

    Sub PopulateParameters()
        Dim dt As New DataTable

        dt = objDataHandler.GetDataSetFromQuery("SELECT [YAxisCol],idx FROM [TSM_Process_data].[dbo].[T_CHART] where isactive=1 and [SubUnit] like 'NCRM2%'").Tables(0)
        cblParameters.DataSource = dt
        cblParameters.DataTextField = "YAxisCol"
        cblParameters.DataValueField = "idx"
        cblParameters.DataBind()
        For Each l As ListItem In cblParameters.Items
            l.Selected = False
        Next
    End Sub
    Sub CreateDynamicContainer(ByVal dt As DataTable)


        Try
            Dim appendString = ""
            For i As Integer = 0 To dt.Rows.Count - 1
                appendString &= "<div class='col-md-6'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3 class='header1'>" & dt.Rows(i)("HeaderName") & "</h3> <span></span></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='c" & dt.Rows(i)("idx") & "' style='height: 200px;'></div></div></div></div>"

            Next
            divHolder.InnerHtml = appendString
        Catch ex As Exception

        End Try


    End Sub
    Sub GetData()
        Try

            Dim select_coilid As String = ""
            For i As Integer = 0 To cblcoilid.Items.Count - 1
                If cblcoilid.Items(i).Selected = True Then
                    select_coilid &= ",'" & cblcoilid.Items(i).Value.Trim & "'"
                    'Response.Write(i)
                End If
            Next
            select_coilid = select_coilid.Substring(1)

            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value


            'loop for selected coilid


            'loop for selected parameter
            Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select * From [TSM_Process_data].[dbo].[T_CHART] where isactive=1 and [SubUnit] like 'NCRM2%' order by idx").Tables(0)

            For i As Integer = 0 To cblParameters.Items.Count - 1
                If cblParameters.Items(i).Selected = False Then
                    dt.Rows.Remove(dt.Select("idx=" & cblParameters.Items(i).Value)(0))
                    'dt.Rows.Add(cblParameters.Items(i).Text, cblParameters.Items(i).Value)
                End If
            Next
            dt.AcceptChanges()

            CreateDynamicContainer(dt)
            Dim l As Literal
            l = Page.Master.FindControl("content_body").FindControl("Lit1")
            l.Text = ""
            For i As Integer = 0 To dt.Rows.Count - 1

                Dim dtval As DataTable = getDataForChart(dt.Rows(i)("idx"), select_coilid)
                Dim dt_length As DataTable = get_length_items(select_coilid) '
                If dt.Rows(i)("idx") = 1 Or dt.Rows(i)("idx") = 2 Then
                    l.Text &= PlotLineChart1(dtval, dt_length, dt.Rows(i)("XAxisCol"), Trim(dt.Rows(i)("YAxisCol")), "c" & dt.Rows(i)("Idx"), "plot" & dt.Rows(i)("Idx"), dt.Rows(i)("YAxisUnit").ToString, dt.Rows(i)("Idx"), dt.Rows(i)("LSL").ToString, dt.Rows(i)("USL").ToString, dt.Rows(i)("MIN").ToString, dt.Rows(i)("MAX").ToString, dt.Rows(i)("idx"))
                Else
                    l.Text &= PlotLineChart(dtval, dt_length, dt.Rows(i)("XAxisCol"), Trim(dt.Rows(i)("YAxisCol")), "c" & dt.Rows(i)("Idx"), "plot" & dt.Rows(i)("Idx"), dt.Rows(i)("YAxisUnit").ToString, dt.Rows(i)("Idx"), dt.Rows(i)("LSL").ToString, dt.Rows(i)("USL").ToString, dt.Rows(i)("MIN").ToString, dt.Rows(i)("MAX").ToString, i)
                End If
            Next


        Catch ex As Exception
            Throw ex
        End Try

    End Sub
    Function get_length_items(select_coilid As String) As DataTable
        Dim query As String
        query = "with cte as ( SELECT  [Coil_ID],Length_ETR,case when Length_ETR - lead(Length_ETR)  over(order by datetime) < 0 then 1 else 0 end as ETR " &
",[Length_DTR]  ,case when [Length_DTR] - lead(Length_DTR) over(order by datetime) < 0 then 1 else 0 end as DTR,datetime " &
"  FROM [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data]  where ThicknessDeviation is not null  " &
"  And ltrim(rtrim(coil_id)) in (" & select_coilid & ") ) " &
"select coil_id,sum(etr) as ETR,sum(Dtr) as DTR, case when sum(etr)>sum(dtr) then 'Length_ETR' else 'Length_DTR' end as colu_name " &
"From cte group by coil_id"
        Return objDataHandler.GetDataSetFromQuery(query).Tables(0)
    End Function

    <WebMethod()>
    Public Shared Function GetAutoCompleteData(ByVal coilidinput As String) As List(Of String)
        Dim result As List(Of String) = New List(Of String)()
        coilidinput = coilidinput.Trim
        Dim objhandler As New DataHandler
        Dim dt As DataTable = objhandler.GetDataSetFromQuery("SELECT  distinct [Coil_ID] FROM [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where [Coil_ID] LIKE '%" & coilidinput & "%'").Tables(0)

        For i As Integer = 0 To dt.Rows.Count - 1
            result.Add(dt.Rows(i)(0).ToString)
        Next
        Return result
    End Function
    Function getDataForChart(ByVal idx As Integer, ByVal select_coilid As String) As DataTable
        Dim queries(40) As String
        queries(0) = ""

        'queries(1) = "Select [Length_DTR], [Length_ETR], Coil_ID,ThicknessDeviation, Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ThicknessDeviation is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(2) = "Select [Length_DTR], [Length_ETR], Coil_ID,ActualThickness , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(3) = "Select [Length_DTR], [Length_ETR],Coil_ID,RollForce , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(4) = "Select [Length_DTR], [Length_ETR],Coil_ID,Differential_RF , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(5) = "Select [Length_DTR], [Length_ETR],Coil_ID,RollGap , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(6) = "Select [Length_DTR], [Length_ETR],Coil_ID,Differential_RollGap , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(7) = "Select [Length_DTR], [Length_ETR],Coil_ID,Speed , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(8) = "Select [Length_DTR], [Length_ETR],Coil_ID,Tension_Entry , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(9) = "Select [Length_DTR], [Length_ETR],Coil_ID,Tension_Exit , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(10) = "Select [Length_DTR], [Length_ETR],Coil_ID,Bending_Pos , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(11) = "Select [Length_DTR], [Length_ETR],Coil_ID,Bending_Neg , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"

        queries(1) = "Select [Length_DTR], [Length_ETR], Coil_ID,ThicknessDeviation, Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ThicknessDeviation is not null and  (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        queries(2) = "Select [Length_DTR], [Length_ETR], Coil_ID,ActualThickness , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        queries(3) = "Select [Length_DTR], [Length_ETR],Coil_ID,RollForce , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and  (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        queries(4) = "Select [Length_DTR], [Length_ETR],Coil_ID,Differential_RF , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        queries(5) = "Select [Length_DTR], [Length_ETR],Coil_ID,RollGap , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and  (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        queries(6) = "Select [Length_DTR], [Length_ETR],Coil_ID,Differential_RollGap , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        queries(7) = "Select [Length_DTR], [Length_ETR],Coil_ID,Speed , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        queries(8) = "Select [Length_DTR], [Length_ETR],Coil_ID,Tension_Entry , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        queries(9) = "Select [Length_DTR], [Length_ETR],Coil_ID,Tension_Exit , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        queries(10) = "Select [Length_DTR], [Length_ETR],Coil_ID,Bending_Pos , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        queries(11) = "Select [Length_DTR], [Length_ETR],Coil_ID,Bending_Neg , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"


        Return objDataHandler.GetDataSetFromQuery(queries(idx)).Tables(0)
    End Function


    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try
            divHolder.InnerHtml = ""
            PopulateCoilID()
            PopulateParameters()
            GetData()
            'CreateDynamicContainer()
        Catch ex As Exception

        End Try

    End Sub
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click

        GetData()
    End Sub
    Function stdDev(ByVal MyArray As Object) As Object
        Dim Result, n, a, m As Double 'returning array
        Dim dSumX2, dsumX, sum As Double
        sum = 0
        dsumX = 0
        dSumX2 = 0
        n = 0
        For i As Integer = LBound(MyArray) To UBound(MyArray)
            sum = sum + MyArray(i)
            n += 1
        Next i
        a = sum / n
        n = 0
        For i As Integer = LBound(MyArray) To UBound(MyArray)

            dSumX2 = Math.Pow(a - MyArray(i), 2)

            dsumX = dsumX + dSumX2
            n += 1
        Next i
        If (n < 2) Then
            m = 0
        Else
            m = dsumX / (n - 1)
        End If

        Result = Math.Sqrt(m)
        stdDev = Result
    End Function

    Public Function PlotLineChart1(ByVal dt As DataTable, ByVal dt_length As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal ContainerName As String, ByVal PlotName As String, ByVal YAxisLabelName As String, ByVal index As String, ByVal lsl As String, ByVal usl As String, ByVal min As String, ByVal max As String, ByVal ij As Integer) As String
        Try

            Dim yVal() As Decimal
            Dim data_coilid As String = ""
            Dim data_coilid_lbl As String = ""

            yVal = (From row In dt Select col = CDec(IIf(IsDBNull(row(YAxisColName)), 0, row(YAxisColName)))).ToArray()
            If yVal.Length = 0 Then Return ""
            Dim stdev_val As Double = stdDev(yVal)
            Dim y_min As String = ""
            If min <> "" Then
                y_min = min
            Else
                If stdev_val < 0.00001 Or stdev_val = 0 Then
                    y_min = yVal.Min() - (1 / 100 * yVal.Min)
                Else
                    y_min = yVal.Min() - (1 / 100 * yVal.Min) ' Math.Min(yVal.Min() - (1 / 100 * yVal.Min), yVal.Average - 6 * stdev_val)
                End If

            End If

            Dim y_max As String = ""
            If max <> "" Then
                y_max = max
            Else
                If stdev_val < 0.00001 Or stdev_val = 0 Then
                    y_max = yVal.Max() + (1 / 100 * yVal.Max)
                Else
                    y_max = yVal.Max() + (1 / 100 * yVal.Max) ' Math.Max(yVal.Max() + (1 / 100 * yVal.Max), yVal.Average + 6 * stdev_val)
                End If

            End If

            If lsl = "" Then
                lsl = Math.Max(yVal.Average - 3 * stdev_val, Convert.ToDouble(y_min))
            End If
            If usl = "" Then
                usl = yVal.Average + 3 * stdev_val
            End If

            Dim data As String = Nothing
            Dim data_upperlimit As String = Nothing
            Dim data_ulimit, data_llimit As Double
            Dim data_lowerlimit As String = Nothing
            Dim data1 As String = Nothing
            Dim date_val As String = Nothing
            Dim min1, max1 As Double
            Dim length As String = Nothing
            Dim selected_col As String = Nothing
            Dim label_position As Double
            selected_col = ""
            'If (dt.Rows(0)("Length_DTR") - dt.Rows(dt.Rows.Count - 1)("Length_DTR")) > 0 Then
            '    selected_col = "Length_DTR"
            'Else
            '    selected_col = "Length_ETR"
            'End If
            min1 = 10
            max1 = -10

            data_ulimit = 0
            data_llimit = 0

            'FinalPassThicknessSET
            'upto 1 mm     +-0.02mm                 
            '1.1 to 2      +-0.03
            '2.01  3       +-0.04
            '>3.01         +-0.05
            If YAxisColName = "ActualThickness" Then
                label_position = 2.5
                For I As Integer = 0 To dt.Rows.Count - 2
                    data &= dt.Rows(I)(YAxisColName) & ","

                    'date_val &= "'" & CDate(dt.Rows(I)(XAxisColName)).ToString("yyyy-MM-dd HH:mm:ss") & "',"
                    date_val &= "'" & CDate(dt.Rows(I)(XAxisColName)).ToString("dd-MMM HH:mm") & "',"
                    'add coil id to the 1st row of the coil
                    'then subsequent rows do not add coil id
                    ' for the last row add the next coil id
                    If I = 0 Then
                        data_coilid &= "'" & dt.Rows(I)("Coil_ID") & "',"
                        data_coilid_lbl &= "'" & dt.Rows(I)("Coil_ID") & ", L: 0 ',"
                        'data_coilid_lbl &= "'" & dt.Rows(I)("Coil_ID") & "',"
                    ElseIf dt.Rows(I)("Coil_ID") = dt.Rows(I + 1)("Coil_ID") Then
                        data_coilid &= "' ',"
                        If selected_col = "" Then
                            For coil_len_int As Integer = 0 To dt_length.Rows.Count - 1
                                If dt.Rows(I)("Coil_ID") = dt_length.Rows(coil_len_int)("coil_id") Then
                                    selected_col = dt_length.Rows(coil_len_int)("colu_name")
                                    Exit For
                                    'colu_name
                                End If
                            Next coil_len_int
                        End If
                        data_coilid_lbl &= "'" & dt.Rows(I)("Coil_ID") & ", L:" & dt.Rows(I)(selected_col) & "',"
                        'data_coilid_lbl &= "'" & dt.Rows(I)("Coil_ID") & "',"
                    Else
                        data_coilid &= "'" & dt.Rows(I + 1)("Coil_ID") & "',"
                        data_coilid_lbl &= "'" & dt.Rows(I + 1)("Coil_ID") & ", L: 0 ',"
                        'data_coilid_lbl &= "'" & dt.Rows(I)("Coil_ID") & "',"
                        selected_col = ""
                    End If


                    'date_val &= "'" & dt.Rows(I)(XAxisColName) & "',"
                    If dt.Rows(I)("FinalPassThicknessSET") <= 1 Then
                        data_ulimit = dt.Rows(I)("FinalPassThicknessSET") + 0.02
                        data_llimit = dt.Rows(I)("FinalPassThicknessSET") - 0.02
                        data_upperlimit &= data_ulimit & ","
                        data_lowerlimit &= data_llimit & ","
                    ElseIf dt.Rows(I)("FinalPassThicknessSET") > 1 And dt.Rows(I)("FinalPassThicknessSET") <= 2 Then
                        data_ulimit = dt.Rows(I)("FinalPassThicknessSET") + 0.03
                        data_llimit = dt.Rows(I)("FinalPassThicknessSET") - 0.03
                        data_upperlimit &= data_ulimit & ","
                        data_lowerlimit &= data_llimit & ","
                    ElseIf dt.Rows(I)("FinalPassThicknessSET") > 2 And dt.Rows(I)("FinalPassThicknessSET") <= 3 Then
                        data_ulimit = dt.Rows(I)("FinalPassThicknessSET") + 0.04
                        data_llimit = dt.Rows(I)("FinalPassThicknessSET") - 0.04
                        data_upperlimit &= data_ulimit & ","
                        data_lowerlimit &= data_llimit & ","
                    ElseIf dt.Rows(I)("FinalPassThicknessSET") > 3 Then
                        data_ulimit = dt.Rows(I)("FinalPassThicknessSET") + 0.05
                        data_llimit = dt.Rows(I)("FinalPassThicknessSET") - 0.05
                        data_upperlimit &= data_ulimit & ","
                        data_lowerlimit &= data_llimit & ","
                    End If
                    If data_llimit < min1 Then min1 = data_llimit
                    If data_ulimit > max1 Then max1 = data_ulimit
                Next
            End If
            If YAxisColName = "ThicknessDeviation" Then
                label_position = 0.015
                For I As Integer = 0 To dt.Rows.Count - 2
                    data &= dt.Rows(I)(YAxisColName) & ","
                    'date_val &= "'" & CDate(dt.Rows(I)(XAxisColName)).ToString("yyyy-MM-dd HH:mm:ss") & "',"
                    date_val &= "'" & CDate(dt.Rows(I)(XAxisColName)).ToString("dd-MMM HH:mm") & "',"
                    'If I = 0 Then
                    '    data_coilid &= "'" & dt.Rows(I)("Coil_ID") & "',"
                    '    data_coilid_lbl &= "'" & dt.Rows(I)("Coil_ID") & ", L: 0 ',"
                    'ElseIf dt.Rows(I)("Coil_ID") = dt.Rows(I + 1)("Coil_ID") Then
                    '    data_coilid &= "' ',"
                    'Else
                    '    data_coilid &= "'" & dt.Rows(I + 1)("Coil_ID") & "',"
                    'End If


                    'data_coilid_lbl &= "'" & dt.Rows(I)("Coil_ID") & "',"
                    If I = 0 Then
                        data_coilid &= "'" & dt.Rows(I)("Coil_ID") & "',"
                        data_coilid_lbl &= "'" & dt.Rows(I)("Coil_ID") & ", L: 0 ',"
                    ElseIf dt.Rows(I)("Coil_ID") = dt.Rows(I + 1)("Coil_ID") Then
                        data_coilid &= "' ',"
                        If selected_col = "" Then
                            For coil_len_int As Integer = 0 To dt_length.Rows.Count - 1
                                If dt.Rows(I)("Coil_ID") = dt_length.Rows(coil_len_int)("coil_id") Then
                                    selected_col = dt_length.Rows(coil_len_int)("colu_name")
                                    Exit For
                                    'colu_name
                                End If
                            Next coil_len_int
                        End If
                        data_coilid_lbl &= "'" & dt.Rows(I)("Coil_ID") & ", L:" & dt.Rows(I)(selected_col) & "',"
                    Else
                        data_coilid &= "'" & dt.Rows(I + 1)("Coil_ID") & "',"
                        data_coilid_lbl &= "'" & dt.Rows(I + 1)("Coil_ID") & ", L: 0 ',"
                        selected_col = ""
                    End If

                    If dt.Rows(I)("FinalPassThicknessSET") <= 1 Then
                        data_ulimit = 0.02
                        data_llimit = -0.02
                        data_upperlimit &= data_ulimit & ","
                        data_lowerlimit &= data_llimit & ","
                    ElseIf dt.Rows(I)("FinalPassThicknessSET") > 1 And dt.Rows(I)("FinalPassThicknessSET") <= 2 Then
                        data_ulimit = 0.03
                        data_llimit = -0.03
                        data_upperlimit &= data_ulimit & ","
                        data_lowerlimit &= data_llimit & ","
                    ElseIf dt.Rows(I)("FinalPassThicknessSET") > 2 And dt.Rows(I)("FinalPassThicknessSET") <= 3 Then
                        data_ulimit = 0.04
                        data_llimit = -0.04
                        data_upperlimit &= data_ulimit & ","
                        data_lowerlimit &= data_llimit & ","
                    ElseIf dt.Rows(I)("FinalPassThicknessSET") > 3 Then
                        data_ulimit = 0.05
                        data_llimit = -0.05
                        data_upperlimit &= data_ulimit & ","
                        data_lowerlimit &= data_llimit & ","
                    End If
                    If data_llimit < min1 Then min1 = data_llimit
                    If data_ulimit > max1 Then max1 = data_ulimit
                Next

            End If
            y_min = Math.Min(Convert.ToDouble(y_min), min1 - 1 / 100 * min1)
            y_max = Math.Max(Convert.ToDouble(y_max), max1 + 1 / 100 * max1)
            Dim s As New StringBuilder("<script>")
            s.Append("var coilid" & ij & "=[" & data_coilid & "];")
            s.Append("var axisData" & ij & " = [" & data_coilid_lbl & "];")
            s.Append("var datalabel = axisData" & ij & ".map(function (item1, i) { return (" & label_position & "); });")
            s.Append(" var " & PlotName & "= echarts.init(document.getElementById('" & ContainerName & "'));")

            s.Append("option" & index & " = {")
            s.Append("title: {")
            s.Append("text: ''")
            s.Append("},grid:{left:'10%',right:'5%',bottom:'10%',top:'15%'},")
            s.Append("tooltip: {")
            s.Append("trigger: 'axis' ")
            s.Append(",formatter:function(params){return params[0].marker + ' ' + params[0].name + '<br/>Value:' + params[0].value + '<br/>CoilID:' + axisData" & ij & "[params[0].dataIndex]}")
            s.Append(",alwaysShowContent: true")
            s.Append("},")
            s.Append("xAxis: {")
            s.Append("data: [" & date_val & "] ")
            s.Append(",   axisLine: {lineStyle: { color: '#050505',width:1,} }")
            s.Append("},")
            s.Append("yAxis: {name : '" & YAxisLabelName & "',interval: 0.02,nameLocation: 'middle',max:" & Math.Round(Convert.ToDouble(y_max), 3) & ",min:" & Math.Round(Convert.ToDouble(y_min), 3) & ", nameGap: 50,nameTextStyle:{fontFamily:'Calibri',fontWeight:'bold',fontSize:'14'},")
            s.Append("splitLine: {")
            s.Append("show: false")
            s.Append("}")
            s.Append(",   axisLine: {lineStyle: { color: '#050505',width:1,} }")
            s.Append("},")
            s.Append("toolbox: {")
            s.Append("left: 'right',")
            s.Append("feature: {")
            s.Append("dataZoom: {")
            s.Append("")
            s.Append("},")
            s.Append("restore: {},")
            s.Append("saveAsImage: {}")
            s.Append("}")
            s.Append("},")
            s.Append("series: [")
            s.Append("{")
            s.Append("type: 'scatter',")
            s.Append("data: [" & data & "]")
            's.Append(",markLine:{symbol: 'none',data:[{yAxis:" & lsl & ",name:'LSL',label:{formatter:'LSL'},lineStyle: {color:'black',type:'dashed',width:3}},{yAxis:" & usl & ",name:'USL',label:{formatter:'USL'},lineStyle: {color:'black',type:'dashed',width:3}}]}")
            s.Append(", itemStyle: {       shadowBlur: 5,       shadowColor: 'rgba(120, 36, 50, 0.5)',      shadowOffsetY: 5,      borderWidth: 1,      borderColor: '#212020',      color: 'yellow'}") 'EE6666
            s.Append(", symbolSize: 5,")
            s.Append("},")
            s.Append("{")
            s.Append("type: 'line',")
            s.Append("data: [" & data & "]")
            s.Append(", itemStyle: {borderWidth: 2, borderColor: '#3d3d3d', color: '#ff9f63'}")
            s.Append(", symbolSize: 4,")
            s.Append("},")
            s.Append("{")
            s.Append("type: 'line',")
            s.Append("data: [" & data_upperlimit & "]")
            s.Append(", itemStyle: {color: 'red'}") 'borderColor: '#EE6666',  
            s.Append(", symbolSize: 2,")
            s.Append("},")
            s.Append("{")
            s.Append("type: 'line',")
            s.Append("data: [" & data_lowerlimit & "]")
            s.Append(", itemStyle: { color: 'red'}")
            s.Append(", symbolSize: 2,")
            s.Append("},")
            s.Append("{")
            s.Append(" type: 'graph', layout: 'none',  coordinateSystem: 'cartesian2d',   symbolSize: 1, itemStyle:{color:'white'},")
            's.Append(" label: { show: true, fontSize: 18,formatter:function(param) {return coilid[param.dataIndex]}, backgroundColor: 'rgb(242,242,242)', borderColor: '#aaa',  borderWidth: 1, borderRadius: 4,padding: [4, 10],lineHeight: 26, position: 'right', distance: 0, rotate: 90, },")
            s.Append(" label: { show: true, color:'blue',fontSize: 14,fontWeight:'bold', formatter:function(param) {return coilid" & ij & "[param.dataIndex]}, position: 'right', distance: 0, rotate: 60, },")
            s.Append("data: datalabel")
            s.Append("}")

            s.Append("]")
            s.Append("};")

            s.Append(" " & PlotName & ".setOption(option" & index & ");")
            'If ij = 2 Then
            '    s.Append("" & PlotName & ".on('click',function(params){var hwidth = window.innerWidth;window.open('TSM_Khapoli_process_data_report.aspx?subparam=' + escape(axisData" & ij & "[params.dataIndex].trim()) + '', ""_blank"", ""toolbar=no,location=no,directories=no,status=no,scrollbars=yes,resizable=no,top=100,left=200,width=hwidth,height=600"");});")
            'End If
            s.Append("</script>")
            Return s.ToString

        Catch ex As Exception
            Return ""
        End Try
    End Function

    Public Function PlotLineChart(ByVal dt As DataTable, ByVal dt_length As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal ContainerName As String, ByVal PlotName As String, ByVal YAxisLabelName As String, ByVal index As String, ByVal lsl As String, ByVal usl As String, ByVal min As String, ByVal max As String, ByVal ij As Integer) As String
        Try

            Dim yVal() As Decimal
            Dim data_coilid As String = ""


            yVal = (From row In dt Select col = CDec(IIf(IsDBNull(row(YAxisColName)), 0, row(YAxisColName)))).ToArray()
            If yVal.Length = 0 Then Return ""
            Dim stdev_val As Double = stdDev(yVal)
            Dim y_min As String = ""
            If min <> "" Then
                y_min = min
            Else
                If stdev_val < 0.00001 Or stdev_val = 0 Then
                    y_min = yVal.Min() - (1 / 100 * yVal.Min)
                Else
                    y_min = yVal.Min() - (1 / 100 * yVal.Min) 'Math.Max(yVal.Min() - (1 / 100 * yVal.Min), yVal.Average - 6 * stdev_val)
                End If

            End If

            Dim y_max As String = ""
            If max <> "" Then
                y_max = max
            Else
                If stdev_val < 0.00001 Or stdev_val = 0 Then
                    y_max = yVal.Max() + (1 / 100 * yVal.Max)
                Else
                    y_max = yVal.Max() + (1 / 100 * yVal.Max) 'Math.Min(yVal.Max() + (1 / 100 * yVal.Max), yVal.Average + 6 * stdev_val)
                End If

            End If

            If lsl = "" Then
                lsl = Math.Max(yVal.Average - 3 * stdev_val, Convert.ToDouble(y_min))
            End If
            If usl = "" Then
                usl = yVal.Average + 3 * stdev_val
            End If

            Dim data As String = Nothing

            Dim data1 As String = Nothing
            Dim date_val As String = Nothing
            Dim selected_col As String = Nothing
            Dim label_position As Double
            selected_col = ""
            'FinalPassThicknessSET
            'upto 1 mm     +-0.02mm                 
            '1.1 to 2      +-0.03
            '2.01  3       +-0.04
            '>3.01         +-0.05

            For I As Integer = 0 To dt.Rows.Count - 2
                data &= dt.Rows(I)(YAxisColName) & ","
                'date_val &= "'" & CDate(dt.Rows(I)(XAxisColName)).ToString("yyyy-MM-dd HH:mm:ss") & "',"
                date_val &= "'" & CDate(dt.Rows(I)(XAxisColName)).ToString("dd-MMM HH:mm") & "',"
                'data_coilid &= "'" & dt.Rows(I)("Coil_ID") & "',"
                If I = 0 Then
                    'data_coilid &= "'" & dt.Rows(I)("Coil_ID") & "',"
                    data_coilid &= "'" & dt.Rows(I)("Coil_ID") & ", L: 0 ',"
                ElseIf dt.Rows(I)("Coil_ID") = dt.Rows(I + 1)("Coil_ID") Then
                    ' data_coilid &= "' ',"
                    If selected_col = "" Then
                        For coil_len_int As Integer = 0 To dt_length.Rows.Count - 1
                            If dt.Rows(I)("Coil_ID") = dt_length.Rows(coil_len_int)("coil_id") Then
                                selected_col = dt_length.Rows(coil_len_int)("colu_name")
                                Exit For
                                'colu_name
                            End If
                        Next coil_len_int
                    End If
                    data_coilid &= "'" & dt.Rows(I)("Coil_ID") & ", L:" & dt.Rows(I)(selected_col) & "',"
                Else
                    'data_coilid &= "'" & dt.Rows(I + 1)("Coil_ID") & "',"
                    data_coilid &= "'" & dt.Rows(I + 1)("Coil_ID") & ", L: 0 ',"
                    selected_col = ""
                End If
            Next

            Dim s As New StringBuilder("<script>")
            s.Append("var coilid" & ij & "=[" & data_coilid & "];")
            s.Append(" var " & PlotName & "= echarts.init(document.getElementById('" & ContainerName & "'));")

            s.Append("option" & index & " = {")
            s.Append("title: {")
            s.Append("text: ''")
            s.Append("},grid:{left:'10%',right:'5%',bottom:'10%'},")
            s.Append("tooltip: {")
            s.Append("trigger: 'axis' ")
            s.Append(",formatter:function(params){return params[0].marker + ' ' + params[0].name + '<br/>Value:' + params[0].value + '<br/>CoilID:' + coilid" & ij & "[params[0].dataIndex]}")
            s.Append("},")
            s.Append("xAxis: {")
            s.Append("data: [" & date_val & "] ")
            s.Append(",   axisLine: {lineStyle: { color: '#050505',width:1,} }")
            s.Append("},")
            s.Append("yAxis: {name : '" & YAxisLabelName & "', nameLocation: 'middle',max:" & Math.Round(Convert.ToDouble(y_max), 3) & ",min:" & Math.Round(Convert.ToDouble(y_min), 3) & ", nameGap: 50,nameTextStyle:{fontFamily:'Calibri',fontWeight:'bold',fontSize:'14'},")
            s.Append("splitLine: {")
            s.Append("show: false")
            s.Append("}")
            s.Append(",   axisLine: {lineStyle: { color: '#050505',width:1,} }")
            s.Append("},")
            s.Append("toolbox: {")
            s.Append("left: 'right',")
            s.Append("feature: {")
            s.Append("dataZoom: {")
            s.Append("")
            s.Append("},")
            s.Append("restore: {},")
            s.Append("saveAsImage: {}")
            s.Append("}")
            s.Append("},")
            s.Append("series: [")
            s.Append("{")
            s.Append("type: 'scatter',")
            s.Append("data: [" & data & "]")
            's.Append(",markLine:{symbol: 'none',data:[{yAxis:" & lsl & ",name:'LSL',label:{formatter:'LSL'},lineStyle: {color:'black',type:'dashed',width:3}},{yAxis:" & usl & ",name:'USL',label:{formatter:'USL'},lineStyle: {color:'black',type:'dashed',width:3}}]}")
            s.Append(", itemStyle: {       shadowBlur: 5,       shadowColor: 'rgba(120, 36, 50, 0.5)',      shadowOffsetY: 5,      borderWidth: 1,      borderColor: '#212020',      color: 'yellow'}") 'EE6666
            s.Append(", symbolSize: 5,")
            s.Append("},")
            s.Append("{")
            s.Append("type: 'line',")
            s.Append("data: [" & data & "]")
            s.Append(", itemStyle: {borderWidth: 2, borderColor: '#3d3d3d', color: '#ff9f63'}")
            's.Append(", symbolSize: 4,")
            s.Append("}")

            s.Append("]")
            s.Append("};")

            s.Append(" " & PlotName & ".setOption(option" & index & ");")

            s.Append("</script>")
            Return s.ToString

        Catch ex As Exception
            Return ""
        End Try
    End Function
End Class
