﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Web.Services

Partial Class TSM_Khapoli_CCL_data
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim objDataHandler As New DataHandler
    Dim coil_count As Integer = 0
    Dim connectionString As String = "server=176.0.0.60\LPTGSQLDEV;database=TSM_Process_data;uid=153521;pwd=Welcome@135"

    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    'Sub AddSearchCoilInList(ByVal coilid As String)
    '    cblcoilid.Items.Clear()
    '    If coilid = "" Then
    '        PopulateCoilID()
    '    Else
    '        cblcoilid.Items.Add(New ListItem(coilid.Trim, coilid.Trim))
    '    End If

    'End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try

                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    txtDate_TextChanged()

                End If
                Dim t As String = Request("__EVENTTARGET")
                If t = "searchcoil" Then
                    'AddSearchCoilInList(p)
                End If
            Catch ex As Exception

            End Try

        End If

        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))

                Dim dtStart As String = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd HH:mm:ss")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                hfFrom.Value = dtStart
                hfTo.Value = dtEnd


                Dim query As String = ""
                Dim dtColumns As New DataTable()
                query = "SELECT distinct convert(varchar,[Coil_st_time],120) as Coil_st_time FROM [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] WHERE [Coil_st_time]  IS NOT NULL and [Coil_st_time] between '" & dtStart & "' and '" & dtEnd & "' order by Coil_st_time "
                'Dim conditions As List(Of String) = New List(Of String)()
                'For Each selectedItem As String In selectedItems
                '    conditions.Add("[" & selectedItem & "] IS NOT NULL")
                'Next
                'query += String.Join(" OR ", conditions)

                Using connection As New SqlConnection(connectionString)
                    Using command As New SqlCommand(query, connection)
                        connection.Open()
                        dtColumns.Load(command.ExecuteReader())
                        CheckBoxListDate.DataSource = dtColumns
                        CheckBoxListDate.DataTextField = "Coil_st_time"
                        CheckBoxListDate.DataValueField = "Coil_st_time"
                        CheckBoxListDate.DataBind()
                    End Using
                End Using

            Catch ex As Exception

            End Try

        End If

    End Sub

    Sub CreateDynamicContainer(ByVal dt As DataTable)


        Try
            Dim appendString = ""
            For i As Integer = 0 To dt.Rows.Count - 1
                appendString &= "<div class='col-md-6'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3 class='header1'>" & dt.Rows(i)("HeaderName") & "</h3> <span></span></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='c" & dt.Rows(i)("idx") & "' style='height: 200px;'></div></div></div></div>"

            Next
            divHolder.InnerHtml = appendString
        Catch ex As Exception

        End Try


    End Sub
    Sub GetData()
        Try

            Dim select_coilid As String = ""
            For i As Integer = 0 To CheckBoxListDate.Items.Count - 1
                If CheckBoxListDate.Items(i).Selected = True Then
                    select_coilid &= ",'" & CheckBoxListDate.Items(i).Value.Trim & "'"
                    'Response.Write(i)
                End If
            Next
            select_coilid = select_coilid.Substring(1)

            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value


            'loop for selected coilid


            'loop for selected parameter
            Dim selectedGroupId As String = ListBoxParametersGroup.SelectedValue
            Dim query As String = ""
            If selectedGroupId = "0" Then
                query = "select * From [TSM_Process_data].[dbo].[T_CHART] where isactive=1 and [SubUnit] like 'CCL%' order by idx"
            ElseIf selectedGroupId = "1" Then
                query = "select * From [TSM_Process_data].[dbo].[T_CHART] where isactive=1 and [SubUnit] like 'CCL%' and subgroup like 'Chem%' order by idx "
            ElseIf selectedGroupId = "2" Then
                query = "select * From [TSM_Process_data].[dbo].[T_CHART] where isactive=1 and [SubUnit] like 'CCL%' and subgroup like 'PrimeCoater%' order by idx "
            ElseIf selectedGroupId = "3" Then
                query = "select * From [TSM_Process_data].[dbo].[T_CHART] where isactive=1 and [SubUnit] like 'CCL%' and subgroup like 'FinishCoate%' order by idx "
            ElseIf selectedGroupId = "4" Then
                query = "select * From [TSM_Process_data].[dbo].[T_CHART] where isactive=1 and [SubUnit] like 'CCL%' and subgroup like 'Incinerato%' order by idx "
            ElseIf selectedGroupId = "5" Then
                query = "select * From [TSM_Process_data].[dbo].[T_CHART] where isactive=1 and [SubUnit] like 'CCL%' and subgroup like 'PrimeOven%' order by idx "
            ElseIf selectedGroupId = "6" Then
                query = "select * From [TSM_Process_data].[dbo].[T_CHART] where isactive=1 and [SubUnit] like 'CCL%' and subgroup like 'FinishOve%' order by idx "
            ElseIf selectedGroupId = "7" Then
                query = "select * From [TSM_Process_data].[dbo].[T_CHART] where isactive=1 and [SubUnit] like 'CCL%' and subgroup like 'Line%' order by idx "
            End If
            Dim dt As DataTable = objDataHandler.GetDataSetFromQuery(query).Tables(0)

            For i As Integer = 0 To CheckBoxListParametersSubGroup.Items.Count - 1
                If CheckBoxListParametersSubGroup.Items(i).Selected = False Then
                    dt.Rows.Remove(dt.Select("idx=" & CheckBoxListParametersSubGroup.Items(i).Value)(0))
                    'dt.Rows.Add(cblParameters.Items(i).Text, cblParameters.Items(i).Value)
                End If
            Next
            dt.AcceptChanges()

            CreateDynamicContainer(dt)
            Dim l As Literal
            l = Page.Master.FindControl("content_body").FindControl("Lit1")
            l.Text = ""
            For i As Integer = 0 To dt.Rows.Count - 1

                Dim dtval As DataTable = getDataForChart(dt.Rows(i)("idx"), select_coilid)
                'Dim dt_length As DataTable = get_length_items(select_coilid) '
                l.Text &= PlotLineChart(dtval, dt.Rows(i)("XAxisCol"), Trim(dt.Rows(i)("YAxisCol")), "c" & dt.Rows(i)("Idx"), "plot" & dt.Rows(i)("Idx"), dt.Rows(i)("YAxisUnit").ToString, dt.Rows(i)("Idx"), dt.Rows(i)("LSL").ToString, dt.Rows(i)("USL").ToString, dt.Rows(i)("MIN").ToString, dt.Rows(i)("MAX").ToString, dt.Rows(i)("idx"))
                ' l.Text &= PlotLineChart(dtval, dt.Rows(i)("XAxisCol"), Trim(dt.Rows(i)("YAxisCol")), "c" & dt.Rows(i)("Idx"), "plot" & dt.Rows(i)("Idx"), dt.Rows(i)("YAxisUnit").ToString, dt.Rows(i)("Idx"), dt.Rows(i)("LSL").ToString, dt.Rows(i)("USL").ToString, dt.Rows(i)("MIN").ToString, dt.Rows(i)("MAX").ToString, dt.Rows(i)("idx"))
            Next


        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    Function getDataForChart(ByVal idx As Integer, ByVal select_coilid As String) As DataTable
        Dim queries(50) As String
        queries(0) = ""

        'queries(1) = "Select [Length_DTR], [Length_ETR], Coil_ID,ThicknessDeviation, Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ThicknessDeviation is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(2) = "Select [Length_DTR], [Length_ETR], Coil_ID,ActualThickness , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(3) = "Select [Length_DTR], [Length_ETR],Coil_ID,RollForce , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(4) = "Select [Length_DTR], [Length_ETR],Coil_ID,Differential_RF , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(5) = "Select [Length_DTR], [Length_ETR],Coil_ID,RollGap , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(6) = "Select [Length_DTR], [Length_ETR],Coil_ID,Differential_RollGap , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(7) = "Select [Length_DTR], [Length_ETR],Coil_ID,Speed , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(8) = "Select [Length_DTR], [Length_ETR],Coil_ID,Tension_Entry , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(9) = "Select [Length_DTR], [Length_ETR],Coil_ID,Tension_Exit , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(10) = "Select [Length_DTR], [Length_ETR],Coil_ID,Bending_Pos , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(11) = "Select [Length_DTR], [Length_ETR],Coil_ID,Bending_Neg , Datetime,FinalPassThicknessSET from [TSM_Process_data].[dbo].[T_Khapoli_NCRM_process_data] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"


        queries(1) = "Select [Datetime], Coil_ID,CC_THEAD_APP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(2) = "Select [Datetime], Coil_ID,CC_THEAD_PKP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(3) = "Select [Datetime], Coil_ID,CC_BHEAD_APP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(4) = "Select [Datetime], Coil_ID,CC_BHEAD_PKP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(5) = "Select [Datetime], Coil_ID,CHDRYR_CONTROL_TEMP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(6) = "Select [Datetime], Coil_ID,CHDRYR_SAFE_TEMP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(7) = "Select [Datetime], Coil_ID,PC_THEAD_APP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(8) = "Select [Datetime], Coil_ID,PC_THEAD_PKP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(9) = "Select [Datetime], Coil_ID,PC_BHEAD_APP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(10) = "Select [Datetime], Coil_ID,PC_BHEAD_PKP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(11) = "Select [Datetime], Coil_ID,FC_THEADANEW_APP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(12) = "Select [Datetime], Coil_ID,FC_THEADANEW_PKP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(13) = "Select [Datetime], Coil_ID,FC_THEADA_APP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(14) = "Select [Datetime], Coil_ID,FC_THEADA_PKP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(15) = "Select [Datetime], Coil_ID,FC_THEADA_MET from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(16) = "Select [Datetime], Coil_ID,FC_BHEAD_APP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(17) = "Select [Datetime], Coil_ID,FC_BHEAD_PKP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(18) = "Select [Datetime], Coil_ID,FC_THEADB_APP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(19) = "Select [Datetime], Coil_ID,FC_THEADB_PKP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(20) = "Select [Datetime], Coil_ID,FC_THEADB_MET from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(21) = "Select [Datetime], Coil_ID,INCN_CONTROL_TEMP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(22) = "Select [Datetime], Coil_ID,INCN_SAFE_TEMP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(23) = "Select [Datetime], Coil_ID,INCN_RPM from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(24) = "Select [Datetime], Coil_ID,OVEN_EXH_RPM_FDBK from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(25) = "Select [Datetime], Coil_ID,FRESH_AIR_RPM_FDBK from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(26) = "Select [Datetime], Coil_ID,PO_ZO1_CONT_TEMP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(27) = "Select [Datetime], Coil_ID,PO_ZO1_SAFE_TEMP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(28) = "Select [Datetime], Coil_ID,PO_ZO2_CONT_TEMP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(29) = "Select [Datetime], Coil_ID,PO_ZO2_SAFE_TEMP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(30) = "Select [Datetime], Coil_ID,PO_ZO3_CONT_TEMP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(31) = "Select [Datetime], Coil_ID,PO_ZO3_SAFE_TEMP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(32) = "Select [Datetime], Coil_ID,PO_PYROMETER_FB from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(33) = "Select [Datetime], Coil_ID,PROVN_FAN1_SPD from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(34) = "Select [Datetime], Coil_ID,PROVN_FAN2_SPD from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(35) = "Select [Datetime], Coil_ID,PROVN_FAN3_SPD from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(36) = "Select [Datetime], Coil_ID,FO_ZO1_CONTROL_TEMP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(37) = "Select [Datetime], Coil_ID,FO_ZO1_SAFE_TEMP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(38) = "Select [Datetime], Coil_ID,FO_ZO2_CONTROL_TEMP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(39) = "Select [Datetime], Coil_ID,FO_ZO2_SAFE_TEMP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(40) = "Select [Datetime], Coil_ID,FO_ZO3_CONTROL_TEMP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(41) = "Select [Datetime], Coil_ID,FO_ZO3_SAFE_TEMP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(42) = "Select [Datetime], Coil_ID,FO_ZO4_CONTROL_TEMP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(43) = "Select [Datetime], Coil_ID,FO_ZO4_SAFE_TEMP from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(44) = "Select [Datetime], Coil_ID,FNOVN_FAN1_SPD from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(45) = "Select [Datetime], Coil_ID,FNOVN_FAN2_SPD from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(46) = "Select [Datetime], Coil_ID,FNOVN_FAN3_SPD from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(47) = "Select [Datetime], Coil_ID,FNOVN_FAN4_SPD from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
        queries(48) = "Select [Datetime], Coil_ID,LINESPEED from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"
		queries(49) = "Select [Datetime], Coil_ID,FNOVN_PYRO from [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] where [Coil_st_time]  is not null and  [Coil_st_time]  in (" & select_coilid & ") order by Datetime"


        Return objDataHandler.GetDataSetFromQuery(queries(idx)).Tables(0)
    End Function


    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try
            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value


            Dim query As String = ""
            Dim dtColumns As New DataTable()
            query = "SELECT distinct [Coil_st_time] FROM [TSM_Process_data].[dbo].[T_Khopoli_CCL_process_data] WHERE [Coil_st_time]  IS NOT NULL and [Coil_st_time] between '" & dtStart & "' and '" & dtEnd & "'  order by Coil_st_time "
            'Dim conditions As List(Of String) = New List(Of String)()
            'For Each selectedItem As String In selectedItems
            '    conditions.Add("[" & selectedItem & "] IS NOT NULL")
            'Next
            'query += String.Join(" OR ", conditions)

            Using connection As New SqlConnection(connectionString)
                Using command As New SqlCommand(query, connection)
                    connection.Open()
                    dtColumns.Load(command.ExecuteReader())
                    CheckBoxListDate.DataSource = dtColumns
                    CheckBoxListDate.DataTextField = "Coil_st_time"
                    CheckBoxListDate.DataValueField = "Coil_st_time"
                    CheckBoxListDate.DataBind()
                End Using
            End Using

            'divHolder.InnerHtml = ""
            'PopulateCoilID()
            'PopulateParameters()
            'GetData()
            ''CreateDynamicContainer()
        Catch ex As Exception

        End Try

    End Sub
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click

        GetData()
    End Sub
    Function stdDev(ByVal MyArray As Object) As Object
        Dim Result, n, a, m As Double 'returning array
        Dim dSumX2, dsumX, sum As Double
        sum = 0
        dsumX = 0
        dSumX2 = 0
        n = 0
        For i As Integer = LBound(MyArray) To UBound(MyArray)
            sum = sum + MyArray(i)
            n += 1
        Next i
        a = sum / n
        n = 0
        For i As Integer = LBound(MyArray) To UBound(MyArray)

            dSumX2 = Math.Pow(a - MyArray(i), 2)

            dsumX = dsumX + dSumX2
            n += 1
        Next i
        If (n < 2) Then
            m = 0
        Else
            m = dsumX / (n - 1)
        End If

        Result = Math.Sqrt(m)
        stdDev = Result
    End Function

    Public Function PlotLineChart(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal ContainerName As String, ByVal PlotName As String, ByVal YAxisLabelName As String, ByVal index As String, ByVal lsl As String, ByVal usl As String, ByVal min As String, ByVal max As String, ByVal ij As Integer) As String
        Try

            Dim yVal() As Decimal
            Dim data_coilid As String = ""
            Dim lcl, ucl As Double


            yVal = (From row In dt Select col = CDec(IIf(IsDBNull(row(YAxisColName)), 0, row(YAxisColName)))).ToArray()
            If yVal.Length = 0 Then Return ""
            Dim stdev_val As Double = stdDev(yVal)
            Dim y_min As String = ""
            If min <> "" Then
                y_min = min
            Else
                If stdev_val < 0.00001 Or stdev_val = 0 Then
                    y_min = yVal.Min() - (1 / 100 * yVal.Min)
                Else
                    y_min = yVal.Min() - (1 / 100 * yVal.Min) 'Math.Max(yVal.Min() - (1 / 100 * yVal.Min), yVal.Average - 6 * stdev_val)
                End If

            End If

            Dim y_max As String = ""
            If max <> "" Then
                y_max = max
            Else
                If stdev_val < 0.00001 Or stdev_val = 0 Then
                    y_max = yVal.Max() + (1 / 100 * yVal.Max)
                Else
                    y_max = yVal.Max() + (1 / 100 * yVal.Max) 'Math.Min(yVal.Max() + (1 / 100 * yVal.Max), yVal.Average + 6 * stdev_val)
                End If

            End If

            lcl = yVal.Average - 3 * stdev_val
            ucl = yVal.Average + 3 * stdev_val

            If lsl = "" Then
                lsl = yVal.Average - 3 * stdev_val
            End If
            If usl = "" Then
                usl = yVal.Average + 3 * stdev_val
            End If
            y_min = Math.Min(Convert.ToDouble(y_min), Convert.ToDouble(lsl))
            y_max = Math.Max(Convert.ToDouble(y_max), Convert.ToDouble(usl))
            Dim data As String = Nothing

            Dim data1 As String = Nothing
            Dim date_val As String = Nothing
            Dim selected_col As String = Nothing
            Dim label_position As Double
            selected_col = ""
            'FinalPassThicknessSET
            'upto 1 mm     +-0.02mm                 
            '1.1 to 2      +-0.03
            '2.01  3       +-0.04
            '>3.01         +-0.05

            For I As Integer = 0 To dt.Rows.Count - 2
                data &= dt.Rows(I)(YAxisColName) & ","
                'date_val &= "'" & CDate(dt.Rows(I)(XAxisColName)).ToString("yyyy-MM-dd HH:mm:ss") & "',"
                date_val &= "'" & CDate(dt.Rows(I)(XAxisColName)).ToString("dd-MMM HH:mm") & "',"
                'data_coilid &= "'" & dt.Rows(I)("Coil_ID") & "',"
                If I = 0 Then
                    'data_coilid &= "'" & dt.Rows(I)("Coil_ID") & "',"
                    data_coilid &= "'" & dt.Rows(I)("Coil_ID") & ", L: 0 ',"
                ElseIf dt.Rows(I)("Coil_ID") = dt.Rows(I + 1)("Coil_ID") Then
                    ' data_coilid &= "' ',"
                    'If selected_col = "" Then
                    '    For coil_len_int As Integer = 0 To dt_length.Rows.Count - 1
                    '        If dt.Rows(I)("Coil_ID") = dt_length.Rows(coil_len_int)("coil_id") Then
                    '            selected_col = dt_length.Rows(coil_len_int)("colu_name")
                    '            Exit For
                    '            'colu_name
                    '        End If
                    '    Next coil_len_int
                    'End If
                    data_coilid &= "'" & dt.Rows(I)("Coil_ID") & "',"
                Else
                    'data_coilid &= "'" & dt.Rows(I + 1)("Coil_ID") & "',"
                    data_coilid &= "'" & dt.Rows(I + 1)("Coil_ID") & "',"
                    selected_col = ""
                End If
            Next

            Dim s As New StringBuilder("<script>")
            s.Append("var coilid" & ij & "=[" & data_coilid & "];")
            s.Append(" var " & PlotName & "= echarts.init(document.getElementById('" & ContainerName & "'));")

            s.Append("option" & index & " = {")
            s.Append("title: {")
            s.Append("text: ''")
            s.Append("},grid:{left:'10%',right:'5%',bottom:'10%'},")
            s.Append("tooltip: {")
            s.Append("trigger: 'axis' ")
            s.Append(",formatter:function(params){return params[0].marker + ' ' + params[0].name + '<br/>Value:' + params[0].value + '<br/>CoilID:' + coilid" & ij & "[params[0].dataIndex]}")
            s.Append("},")
            s.Append("xAxis: {")
            s.Append("data: [" & date_val & "] ")
            s.Append(",   axisLine: {lineStyle: { color: '#050505',width:1,} }")
            s.Append("},")
            s.Append("yAxis: {name : '" & YAxisLabelName & "', nameLocation: 'middle',max:" & Math.Round(Convert.ToDouble(y_max), 3) & ",min:" & Math.Round(Convert.ToDouble(y_min), 3) & ", nameGap: 50,nameTextStyle:{fontFamily:'Calibri',fontWeight:'bold',fontSize:'14'},")
            s.Append("splitLine: {")
            s.Append("show: false")
            s.Append("}")
            s.Append(",   axisLine: {lineStyle: { color: '#050505',width:1,} }")
            s.Append("},")
            s.Append("toolbox: {")
            s.Append("left: 'right',")
            s.Append("feature: {")
            s.Append("dataZoom: {")
            s.Append("")
            s.Append("},")
            s.Append("restore: {},")
            s.Append("saveAsImage: {}")
            s.Append("}")
            s.Append("},")
            s.Append("series: [")
            s.Append("{")
            s.Append("type: 'scatter',")
            s.Append("data: [" & data & "]")
            's.Append(",markLine:{symbol: 'none',data:[{yAxis:" & lcl & ",name:'LCL',label:{formatter:'LCL'},lineStyle: {color:'#0398fc',type:'dashed',width:2}},{yAxis:" & ucl & ",name:'UCL',label:{formatter:'UCL'},lineStyle: {color:'#0398fc',type:'dashed',width:2}}]}")
            s.Append(",markLine:{symbol: 'none',data:[{yAxis:" & lsl & ",name:'LSL',label:{formatter:'LSL'},lineStyle: {color:'#ed4c40',type:'dashed',width:2}},{yAxis:" & usl & ",name:'USL',label:{formatter:'USL'},lineStyle: {color:'#ed4c40',type:'dashed',width:2}}]}")
            s.Append(", itemStyle: {       shadowBlur: 5,       shadowColor: 'rgba(120, 36, 50, 0.5)',      shadowOffsetY: 5,      borderWidth: 1,      borderColor: '#212020',      color: 'yellow'}") 'EE6666
            s.Append(", symbolSize: 5,")
            s.Append("},")
            s.Append("{")
            s.Append("type: 'line',")
            s.Append("data: [" & data & "]")
            s.Append(", itemStyle: {borderWidth: 2, borderColor: '#3d3d3d', color: '#ff9f63'}")
            's.Append(", symbolSize: 4,")
            s.Append("}")

            s.Append("]")
            s.Append("};")

            s.Append(" " & PlotName & ".setOption(option" & index & ");")

            s.Append("</script>")
            Return s.ToString

        Catch ex As Exception
            Return ""
        End Try
    End Function

    Private Sub ListBoxParametersGroup_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBoxParametersGroup.SelectedIndexChanged
        Dim query As String = ""
        'Dim connectionString As String = "server=176.0.0.60\LPTGSQLDEV;database=TSM_Process_data;uid=153521;pwd=Welcome@135"
        Dim dtColumns As New DataTable()
        Dim selectedGroupId As String = ListBoxParametersGroup.SelectedValue
        If selectedGroupId = 0 Then
            dtColumns.Columns.Add("ColumnName")
            query = "  select [YAxisCol], [HeaderName],idx  FROM [TSM_Process_data].[dbo].[T_CHART] where SubUnit like 'CCL%'  order by idx"
        Else

            dtColumns.Columns.Add("ColumnName")

            If selectedGroupId = "1" Then
                query = "  select [YAxisCol], [HeaderName],idx  FROM [TSM_Process_data].[dbo].[T_CHART] where SubUnit like 'CCL%' and subgroup like 'Chem%' order by idx"
            ElseIf selectedGroupId = "2" Then
                query = "select [YAxisCol], [HeaderName],idx From [TSM_Process_data].[dbo].[T_CHART] where isactive=1 and [SubUnit] like 'CCL%' and subgroup like 'PrimeCoater%' order by idx "
            ElseIf selectedGroupId = "3" Then
                query = "select [YAxisCol], [HeaderName],idx From [TSM_Process_data].[dbo].[T_CHART] where isactive=1 and [SubUnit] like 'CCL%' and subgroup like 'FinishCoate%' order by idx "
            ElseIf selectedGroupId = "4" Then
                query = "select [YAxisCol], [HeaderName],idx From [TSM_Process_data].[dbo].[T_CHART] where isactive=1 and [SubUnit] like 'CCL%' and subgroup like 'Incinerato%' order by idx "
            ElseIf selectedGroupId = "5" Then
                query = "select [YAxisCol], [HeaderName],idx From [TSM_Process_data].[dbo].[T_CHART] where isactive=1 and [SubUnit] like 'CCL%' and subgroup like 'PrimeOven%' order by idx "
            ElseIf selectedGroupId = "6" Then
                query = "select [YAxisCol], [HeaderName],idx From [TSM_Process_data].[dbo].[T_CHART] where isactive=1 and [SubUnit] like 'CCL%' and subgroup like 'FinishOve%' order by idx "
            ElseIf selectedGroupId = "7" Then
                query = "select [YAxisCol], [HeaderName],idx From [TSM_Process_data].[dbo].[T_CHART] where isactive=1 and [SubUnit] like 'CCL%' and subgroup like 'Line%' order by idx "
            End If
        End If


        Dim dtSubGroups As New DataTable()

        Using connection As New SqlConnection(connectionString)
            Using command As New SqlCommand(query, connection)
                connection.Open()
                dtSubGroups.Load(command.ExecuteReader())
            End Using
        End Using

        'Dim selectAllRow As DataRow = dtSubGroups.NewRow()
        'selectAllRow("HeaderName") = "Select All"
        'selectAllRow("idx") = 0
        'dtSubGroups.Rows.InsertAt(selectAllRow, 0)

        'For Each column As DataColumn In dtSubGroups.Columns
        '    dtColumns.Rows.Add(column.ColumnName)
        'Next

        CheckBoxListParametersSubGroup.DataSource = dtSubGroups
        CheckBoxListParametersSubGroup.DataTextField = "HeaderName"
        CheckBoxListParametersSubGroup.DataValueField = "idx"
        CheckBoxListParametersSubGroup.DataBind()
        chkSelectAll.Visible = True
    End Sub

    Private Sub CheckBoxListParametersSubGroup_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CheckBoxListParametersSubGroup.SelectedIndexChanged
        'CheckBoxListDate.Items.Clear()
        'Dim selectedHeaderName As String = CheckBoxListParametersSubGroup.SelectedItem.Text


        Dim selectedItems As List(Of String) = New List(Of String)()
        If CheckBoxListParametersSubGroup.SelectedIndex <> -1 Then
            For Each item As ListItem In CheckBoxListParametersSubGroup.Items
                If item.Selected Then
                    selectedItems.Add(item.Value)
                End If
            Next
        End If




    End Sub

    Private Sub chkSelectAll_CheckedChanged(sender As Object, e As EventArgs) Handles chkSelectAll.CheckedChanged
        If chkSelectAll.Checked Then
            For Each item As ListItem In CheckBoxListParametersSubGroup.Items
                item.Selected = True
            Next
        Else
            For Each item As ListItem In CheckBoxListParametersSubGroup.Items
                item.Selected = False
            Next

        End If


    End Sub

    Private Sub chkCoilStartTime_CheckedChanged(sender As Object, e As EventArgs) Handles chkCoilStartTime.CheckedChanged
        If chkCoilStartTime.Checked Then
            For Each item As ListItem In CheckBoxListDate.Items
                item.Selected = True
            Next
        Else
            For Each item As ListItem In CheckBoxListDate.Items
                item.Selected = False
            Next
        End If
    End Sub
End Class
