﻿
Imports System.Data

Partial Class TSM_Performance_Coating
    Inherits System.Web.UI.Page
    Dim objDataHandler As New DataHandler
    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Private Sub TSM_Performance_Coating_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            DrawDynamicContainer()

            'c2
            Dim last5day As String = DateTime.Now.AddDays(-7).ToString("yyyy-MM-dd")
            Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select [SAMPLING_DATE],avg(cpk) FROM [TSM_Process_data].[dbo].[T_CCL_CPK_Value] where sampling_date>='" & last5day & "' group by sampling_date order by sampling_date").Tables(0)
            DrawBarTrend("c2", dt, 35)

            'c1
            Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("select [SAMPLING_DATE],cpk FROM [TSM_Process_data].[dbo].[T_CCL_CPK_Value] where sampling_date='" & DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd 00:00:00") & "';select AVG(cpk),STDEV(cpk) from [TSM_Process_data].[dbo].[T_CCL_CPK_Value] where sampling_date='" & DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd 00:00:00") & "'")
            PlotHistECharts("c1", ds.Tables(0), ds.Tables(1))
            litdate.Text = DateTime.Now.AddDays(-1).ToString("dd-MMM")
            litdate1.Text = DateTime.Now.AddDays(-1).ToString("dd-MMM")

            dt = objDataHandler.GetDataSetFromQuery("SELECT TOP 5 PARAM_ALIAS AS PARAM,CAST(ROUND(CPK,2) AS NUMERIC(8,2)) as CPK FROM [TSM_Process_data].[dbo].[T_CCL_CPK_Value] WHERE SAMPLING_DATE = '" & DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd 00:00:00") & "' ORDER BY CPK DESC").Tables(0)
            Repeater1.DataSource = dt
            Repeater1.DataBind()

            dt = objDataHandler.GetDataSetFromQuery("SELECT TOP 5 PARAM_ALIAS AS PARAM,CAST(ROUND(CPK,2) AS NUMERIC(8,2)) as CPK FROM [TSM_Process_data].[dbo].[T_CCL_CPK_Value] WHERE SAMPLING_DATE = '" & DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd 00:00:00") & "' ORDER BY CPK ASC").Tables(0)
            Repeater2.DataSource = dt
            Repeater2.DataBind()


        End If
    End Sub

    Sub PlotHistECharts(ByVal container As String, ByVal dt As DataTable, ByVal dt1 As DataTable)

        Dim data As String = "" '"LastBarA"
        For i = 0 To dt.Rows.Count - 1
            data &= "," & dt.Rows(i)(1)
        Next
        If data.Length = 0 Then
            Return
        End If

        Dim xvalues() As Double = {-4, -3, -2.5, -2, -1.9, -1.8, -1.7, -1.6, -1.5, -1.4, -1.3, -1.2, -1.1, -1, -0.9, -0.8, -0.7, -0.6, -0.5, -0.4, -0.3, -0.2, -0.1, 0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2, 2.1, 2.2, 2.3, 2.4, 2.5, 3,4}
        Dim yvalues(xvalues.Length - 1) As Double
        Dim xvalues_aim() As Integer = {-4, -3, -2.5, -2, -1.9, -1.8, -1.7, -1.6, -1.5, -1.4, -1.3, -1.2, -1.1, -1, -0.9, -0.8, -0.7, -0.6, -0.5, -0.4, -0.3, -0.2, -0.1, 0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2, 2.1, 2.2, 2.3, 2.4, 2.5, 3,4}
        Dim yvalues_aim(xvalues.Length - 1) As Double
        'calc gaussian curve
        Dim avg, stdev, avg_aim, stdev_aim As Double
        avg = dt1.Rows(0)(0)
        stdev = dt1.Rows(0)(1)
        avg_aim = 1.33
        stdev_aim = 0.3
        For i As Integer = 0 To UBound(xvalues)
            yvalues(i) = (1 / (stdev * (Math.Sqrt(2 * Math.PI)))) * Math.Exp(-1 * (xvalues(i) - avg) * (xvalues(i) - avg) / (2 * stdev * stdev))
            yvalues_aim(i) = (1 / (stdev_aim * (Math.Sqrt(2 * Math.PI)))) * Math.Exp(-1 * (xvalues(i) - avg_aim) * (xvalues(i) - avg_aim) / (2 * stdev_aim * stdev_aim))
        Next

        Dim ydata, ydata_aim As String
        For i As Integer = 0 To UBound(xvalues)
            ydata &= ",[" & xvalues(i) & "," & yvalues(i) & "]"
            ydata_aim &= ",[" & xvalues(i) & "," & yvalues_aim(i) & "]"
        Next

        data = data.Substring(1)
        Lit2.Text = ""
        Dim js = "<script>var bins = ecStat.histogram([" & data & "]); " &
             "echarts.init(document.getElementById('" & container & "')).setOption({grid:{left:'3%',right:'3%',bottom:'3%',top:'3%',containLabel:!0}, " &
"xAxis :  [{scale:!0,min:-4, max:4},{type:'value',min:-4, max:4, show:false}], " &
"yAxis:[{},{show:false}],legend:{show:true}, " &
"series:[{name:'CpK',type:'bar',barWidth:'99.3%',label:{normal:{show:0,position:'insideTop'}},data:bins.data}, " &
        "{name:'Actual Distribution',type:'line',xAxisIndex:1,yAxisIndex:1,smooth:true,data:[" & ydata.Substring(1) & "]}, " &
        "{name:'Aim',type:'line',xAxisIndex:1,yAxisIndex:1,smooth:true,data:[" & ydata_aim.Substring(1) & "]} " &
        "]});</script>"
        Lit2.Text = js
    End Sub


    Sub DrawBarTrend(ByVal container As String, ByVal dt As DataTable, ByVal namegap As Integer)
        Dim xdata, ydata As String
        If dt.Rows.Count = 0 Then
            Return
        End If
        xdata &= ",'Prev Best'"
        For i As Integer = 0 To dt.Rows.Count - 1
            xdata &= ",'" & CDate(dt.Rows(i)(0)).ToString("dd-MMM") & "'"
            ydata &= "," & Math.Round(dt.Rows(i)(1), 1)
        Next

        Dim s As New StringBuilder("<script>")
        s.Append("echarts.init(document.getElementById('" & container & "')).setOption({")
        s.Append("grid:{left:'20%'},tooltip:{trigger:'item'},xAxis: {type: 'category',data: [")
        s.Append(xdata.Substring(1))
        s.Append("]},yAxis: {name:'Capability Index, CpK',nameLocation:'middle',nameGap:" & namegap & ",type: 'value'},series: [{ data: [null,")
        s.Append(ydata.Substring(1))
        s.Append("],type: 'line'},{data: [0.5],type: 'bar'} ]")


        s.Append("});")
        s.Append("</script>")

        Lit1.Text &= s.ToString
    End Sub

    Private Sub DrawDynamicContainer()
        Try
            Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT DISTINCT SUBGROUP,[Sequence] FROM [TSM_Process_data].[dbo].[T_CHART] WHERE SubUnit='CCL' and ltrim(rtrim(subgroup)) <> 'Linespeed' ORDER BY [Sequence]").Tables(0)
            Dim arr = dt.AsEnumerable.Select(Function(x) x.Field(Of String)("SUBGROUP")).ToArray


            Dim col_cnt As Integer = 2
            Dim appendString = ""
            Dim appendString1 = ""
            Dim last5day As String = DateTime.Now.AddDays(-7).ToString("yyyy-MM-dd")

            For i As Integer = 0 To arr.Length - 1
                appendString &= "<div class='col-md-" & col_cnt & "'><div class='panel panel-default'><div class='panel-heading bg-other'><div class='panel-title-box'><h3>" & arr(i).ToString() & "</h3> <span></span></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='container" & i.ToString() & "' style='height: 260px;'></div></div></div></div>"
                Dim dt1 As DataTable = objDataHandler.GetDataSetFromQuery("select [SAMPLING_DATE],avg(cpk) FROM [TSM_Process_data].[dbo].[T_CCL_CPK_Value] where sampling_date>='" & last5day & "' and PARAM_TEST in (SELECT yaxiscol from [TSM_Process_data].[dbo].[T_CHART] WHERE SubUnit='CCL' and ltrim(rtrim(subgroup))='" & arr(i).Trim & "') group by sampling_date order by sampling_date").Tables(0)
                DrawBarTrend("container" & i.ToString() & "", dt1, 30)
                dt = objDataHandler.GetDataSetFromQuery("SELECT PARAM_ALIAS AS PARAM,CAST(ROUND(CPK,2) AS NUMERIC(8,2)) as CPK FROM [TSM_Process_data].[dbo].[T_CCL_CPK_Value] WHERE SAMPLING_DATE = '" & DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd 00:00:00") & "' and PARAM_TEST in (SELECT yaxiscol from [TSM_Process_data].[dbo].[T_CHART] WHERE SubUnit='CCL' and ltrim(rtrim(subgroup))='" & arr(i).Trim & "') ORDER BY CPK DESC").Tables(0)
                Dim datastring As String = ""
                For j As Integer = 0 To dt.Rows.Count - 1
                    datastring &= "<tr style='background-color:" & GetRowColor(dt.Rows(j)(1)) & "'><td>" & dt.Rows(j)(0) & "</td><td>" & dt.Rows(j)(1) & "</td></tr>"
                Next
                appendString1 &= "<div class='col-md-" & col_cnt & "'><div class='panel panel-default'><div class='panel-body padding-0'><div><table class='table table-responsive t'><thead><tr><th>Parameter</th><th>CpK</th></tr></thead><tbody>" & datastring & "</tbody></table></div></div></div></div>"

            Next
            divHolder.InnerHtml = appendString & appendString1
        Catch ex As Exception

        End Try
    End Sub

    Private Function GetRowColor(ByVal cpk As Double) As String
        Select Case cpk
            Case < 0.5
                Return "#f8d7cd"  'red

            Case < 1.2
                Return "#fac858"

            Case >= 1.2
                Return "#70ad47"  'green
        End Select
    End Function
End Class
