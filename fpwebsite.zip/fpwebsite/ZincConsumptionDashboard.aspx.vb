﻿Imports System.Data
Imports System.Data.OleDb
Imports System.IO
Partial Class ZincConsumptionDashboard
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("ACPM_Ora").ConnectionString
    Dim Oleconnection_ora As New OleDbConnection(strConnectionString)
    Dim OleAdap As New OleDbDataAdapter
    Dim ds, ds1, ds2, ds3, ds4, ds5, ds6, ds7, ds10 As New DataSet
    Dim dt, dt1, dt2, dt3, dt4, dt5, dt6, dt7, dt10 As New DataTable
    Dim OleCom As New OleDbCommand
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-29).ToString("yyyy-MM-dd HH:mm")
                'Dim dtStart As DateTime = DateTime.Now.AddMonths(-4).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

                ' Dim filter As String = " 1=1"
                DrawChartTop(dtStart, dtEnd)
            Catch ex As Exception
                '  Throw ex
            End Try
        End If
    End Sub




    Sub DrawChartTop(ByVal FromDt As String, ByVal ToDt As String)
        Try

            Dim strfrmDt As String = FromDt
            Dim strToDt As String = ToDt

            Dim DTCGL1 As DataTable = GetDataForCGL1()
            Dim DTCGL2 As DataTable = GetDataForCGL2()

            Lit1.Text = DrawPie(DTCGL1, "container2")
            Lit2.Text = DrawPie(DTCGL2, "container5")

            Dim DTCGL3 As DataTable = GetDataForCGL1Stack()
            Dim DTCGL4 As DataTable = GetDataForCGL2Stack()
            PlotChartForZincStackBar(DTCGL3, Lit3, "container3", "plot1")
            PlotChartForZincStackBar(DTCGL4, Lit4, "container6", "plot2")

            Dim DTCGL5 As DataTable = GetDataForLineChart()

            PlotLineChartForZinc(DTCGL5, "date1", "cd", Lit5, "container4", "plot3", "", "", "grade")

            Dim DTCGL6 As DataTable = GetDataForGridview()
            gvCoilData1.DataSource = DTCGL6
            gvCoilData1.DataBind()

            Dim DTCGL7 As DataTable = GetDataForZnConsumed()
            PlotChartForZincBar(DTCGL7, Lit6, "container", "plot4")

            Dim dstemp As DataSet = GetDataForAim()

            PlotChartForZincYieldBar(dstemp.Tables(2), Lit7, "container1", "plot5")




        Catch ex As Exception
            '  Throw ex
        End Try
    End Sub

    Private Function DrawPie(ByVal dTCGL1 As DataTable, container As String) As String
        Dim s As New StringBuilder(" ")
        s.Append(" <script>opt" & container & " ={tooltip:{trigger:'item' },series:[{name: 'PCode' , type:'pie' ,radius:['30%' ,'50%' ], label:{show:true,fontSize:'15' },data:[")
        For row As Integer = 0 To dTCGL1.Rows.Count - 1
            s.Append(" {value:" & dTCGL1.Rows(row)(0) & " ,name:' " & dTCGL1.Rows(row)(1) & " ' },")
        Next
        s.Append(" ]}]};var " & container & "=echarts.init(document.getElementById('" & container & "'));" & container & ".setOption(opt" & container & "); </script>")
        Return s.ToString
    End Function

    Protected Sub txtDate_TextChanged(sender As Object, e As System.EventArgs) Handles txtDate.TextChanged
        Try


            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value

            Dim filter As String = " 1=1"

            'DrawChartTop(fromDt, toDt, filter)
        Catch ex As Exception

        End Try
    End Sub
    Sub CloseConnection()
        Try
            If Oleconnection_ora.State <> ConnectionState.Closed Then
                Oleconnection_ora.Close()
            End If
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

    End Sub
    Public Function Ora_selectquery(ByVal strselect As String) As OleDbDataAdapter
        Try

            OleCom.Connection = Oleconnection_ora
            OleCom.CommandText = strselect
            OleAdap.SelectCommand = OleCom

            Return OleAdap

        Catch ex As Exception

        End Try
    End Function
    Public Function GetDataForZnConsumed() As DataTable

        Dim endate As Date = Date.Now
        Dim stdate As DateTime = endate.AddMonths(-12)
        CloseConnection()
        Oleconnection_ora.Open()
        Dim dh As New DataHandler
        Dim OraQuery As String = "select dt,sum(zinc_aim) as zinc_aim from( SELECT to_char(dcc_ts_end, 'YYYY-MM') as dt, round(sum((dcc_ln_coil*dcc_sec2_coil)/1000) * (sum((dcc_ln_coil*dcc_sec2_coil)/1000 * 120)/sum((dcc_ln_coil*dcc_sec2_coil)/1000) + 4) *1.14969*1.033/1000000,2) as zinc_aim FROM v_cg1_galv_coil where to_char(dcc_ts_end, 'YYYY-MM-DD') > '" & stdate.ToString("yyyy-MM-dd") & "' and to_char(dcc_ts_end, 'YYYY-MM-DD HH24:MI') < '" & endate.ToString("yyyy-MM-dd") & " 06:00' and dcc_prod_cd = 'C05' group by to_char(dcc_ts_end, 'YYYY-MM') union SELECT to_char(dcc_ts_end, 'YYYY-MM'), round(sum((dcc_ln_coil*dcc_sec2_coil)/1000) * (sum((dcc_ln_coil*dcc_sec2_coil)/1000 * 80)/sum((dcc_ln_coil*dcc_sec2_coil)/1000) + 4) *1.14969*1.033/1000000,2) as soft_Zinc_Aim_tonnage FROM v_cg1_galv_coil where to_char(dcc_ts_end, 'YYYY-MM-DD') > '" & stdate.ToString("yyyy-MM-dd") & "' and to_char(dcc_ts_end, 'YYYY-MM-DD HH24:MI') < '" & endate.ToString("yyyy-MM-dd") & " 06:00' and dcc_prod_cd = 'C02' group by to_char(dcc_ts_end, 'YYYY-MM') union SELECT to_char(prm_ts_end, 'YYYY-MM'), round(sum((prm_ln_coil*prm_sec2_coil)/1000) * (sum((prm_ln_coil*prm_sec2_coil)/1000 * substr(prm_cd_coat,2,3))/sum((prm_ln_coil*prm_sec2_coil)/1000) + 4) *0.98*1.18818/1000000,2) as ZS_Zinc_Aim_tonnage FROM crmdba.t_cgl_fur_param where to_char(prm_ts_end, 'YYYY-MM-DD') > '" & stdate.ToString("yyyy-MM-dd") & "' and to_char(prm_ts_end, 'YYYY-MM-DD HH24:MI') < '" & endate.ToString("yyyy-MM-dd") & " 06:00' and prm_cd_prod = 'C10' group by to_char(prm_ts_end, 'YYYY-MM') union SELECT to_char(prm_ts_end, 'YYYY-MM'), round(sum((prm_ln_coil*prm_sec2_coil)/1000) * (sum((prm_ln_coil*prm_sec2_coil)/1000 * substr(prm_cd_coat,2,3))/sum((prm_ln_coil*prm_sec2_coil)/1000) + 4) *0.98*1.18818/1000000,2) as GA_Zinc_Aim_tonnage FROM crmdba.t_cgl_fur_param where to_char(prm_ts_end, 'YYYY-MM-DD') > '" & stdate.ToString("yyyy-MM-dd") & "' and to_char(prm_ts_end, 'YYYY-MM-DD HH24:MI') < '" & endate.ToString("yyyy-MM-dd") & " 06:00' and prm_cd_prod = 'C03' group by to_char(prm_ts_end, 'YYYY-MM')) group by dt order by 1"
        Dim q1 As String = "select * from [FP_PROCESS_DATA].[dbo].[V_Zinc_Cons_Details]"
        Ora_selectquery(OraQuery)
        OleAdap.Fill(ds6)
        dt6 = ds6.Tables(0)
        dt10 = dh.GetDataSetFromQuery(q1).Tables(0)

        dt6.Columns.Add("series2", GetType(Double))

        For row As Integer = 0 To dt6.Rows.Count - 1
            Dim dttemp As New DataTable
            Ora_selectquery("select max(tpr_ms_act_mth_dt)  from v_production_summary where to_char(tpr_dt_prod,'YYYY-MM') = '" & dt6.Rows(row)(0) & "' and tpr_parameter like 'SALEABLE PRODUCTION'")
            OleAdap.Fill(dttemp)
            If dttemp.Rows.Count > 0 Then
                dt6.Rows(row)(1) /= dttemp.Rows(0)(0)

            End If
            Dim dr() As DataRow = dt10.Select("year_month='" & dt6.Rows(row)(0) & "'")
            If dr.Count > 0 Then
                dt6.Rows(row)("series2") = Math.Round(dr(0)(3) * 1000 / dttemp.Rows(0)(0), 2)
            Else
                dt6.Rows(row)("series2") = 0
            End If
        Next
        Return dt6
    End Function
    Public Function GetDataForCGL1() As DataTable
        CloseConnection()
        Oleconnection_ora.Open()
        Dim OraQuery As String = " SELECT COUNT(*) AS CNT,decode(dcc_prod_cd,'C02' ,'SOFT' ,'C05' ,'HARD') AS PRODCD from v_cg1_galv_coil where DCC_TS_END > to_date('2020-12-01', 'YYYY-MM-DD') and  DCC_TS_END < to_date('2021-01-01 06:00', 'YYYY-MM-DD HH24:MI') GROUP BY decode(dcc_prod_cd,'C02' ,'SOFT' ,'C05' ,'HARD')"
        Ora_selectquery(OraQuery)
        OleAdap.Fill(ds)
        dt = ds.Tables(0)
        Return dt
    End Function

    Public Function GetDataForCGL2() As DataTable
        CloseConnection()
        Oleconnection_ora.Open()
        Dim OraQuery As String = "SELECT COUNT(*) AS CNT,decode(prm_cd_prod,'C03' ,'GA' ,'C10' ,'ZS' ) AS PRODCD FROM crmdba.t_cgl_fur_param WHERE prm_ts_end > to_date('2020-12-01', 'YYYY-MM-DD') and  prm_ts_end < to_date('2021-01-01 06:00', 'YYYY-MM-DD HH24:MI') GROUP BY decode(prm_cd_prod,'C03' ,'GA' ,'C10' ,'ZS' )"
        Ora_selectquery(OraQuery)
        OleAdap.Fill(ds1)
        dt1 = ds1.Tables(0)
        Return dt1
    End Function
    Public Function GetDataForCGL1Stack() As DataTable
        CloseConnection()
        Oleconnection_ora.Open()
        Dim OraQuery As String = "select to_char(DCC_TS_END,'YYYY-MM') as DCC_TS_END , SUM(DECODE(dcc_prod_cd,'C02',dcc_ms_coil_act/1000)) as SOFT,SUM(DECODE(dcc_prod_cd,'C05',dcc_ms_coil_act/1000)) as HARD from v_cg1_galv_coil where DCC_TS_END between add_months(sysdate,-11) and sysdate group by to_char(DCC_TS_END,'YYYY-MM') order by 1"
        Ora_selectquery(OraQuery)
        OleAdap.Fill(ds2)
        dt2 = ds2.Tables(0)
        Return dt2
    End Function
    Public Function GetDataForCGL2Stack() As DataTable
        CloseConnection()
        Oleconnection_ora.Open()
        Dim OraQuery As String = "select to_char(prm_ts_end,'YYYY-MM') as prm_ts_end, SUM(DECODE(prm_cd_prod,'C03',prm_ms_coil_actl/1000)) as GA,SUM(DECODE(prm_cd_prod,'C10',prm_ms_coil_actl/1000)) as ZS from crmdba.t_cgl_fur_param where prm_ts_end between add_months(sysdate,-11) and sysdate group by to_char(prm_ts_end,'YYYY-MM') order by 1"
        Ora_selectquery(OraQuery)
        OleAdap.Fill(ds3)
        dt3 = ds3.Tables(0)
        Return dt3
    End Function
    Public Function GetDataForLineChart() As DataTable
        CloseConnection()
        Oleconnection_ora.Open()
        Dim OraQuery As String = "select date1, round(sum(req_zn_sa)/sum(surface_area),2) as cd,decode(grade,'C03','GA','C10','ZS') as grade from ( SELECT to_char(prm_ts_end, 'YYYY-MM') as date1, prm_cd_prod as grade,(prm_ln_coil*prm_sec2_coil)/1000 *  substr(prm_cd_coat,2,3) as Req_zn_sa, ((prm_ln_coil*prm_sec2_coil)/1000) as surface_area FROM crmdba.t_cgl_fur_param where   prm_ts_end between add_months(sysdate,-11) and sysdate) group by date1,grade order by 1"
        Ora_selectquery(OraQuery)
        OleAdap.Fill(ds4)
        dt4 = ds4.Tables(0)
        Return dt4
    End Function

    Public Function GetDataForAim() As DataSet
        Dim endate As Date = Date.Now
        Dim stdate As DateTime = endate.AddMonths(-12)

        Dim ds8 As New DataSet
        Dim q1 As String = "SELECT to_char(prm_ts_end, 'YYYY-MM') as DT, round(sum((prm_ln_coil*prm_sec2_coil)/1000) *(sum((prm_ln_coil*prm_sec2_coil)/1000 * substr(prm_cd_coat,2,3))/sum((prm_ln_coil*prm_sec2_coil)/1000) + 4) /1000000,2) as Aim_CGL2 FROM crmdba.t_cgl_fur_param where to_char(prm_ts_end, 'YYYY-MM-DD') > '" & stdate.ToString("yyyy-MM-dd") & "' and to_char(prm_ts_end, 'YYYY-MM-DD HH24:MI') < '" & endate.ToString("yyyy-MM-dd") & " 06:00' and prm_cd_prod in ('C03','C10') group by to_char(prm_ts_end, 'YYYY-MM') order by 1"
        Dim q2 As String = "select * from [FP_PROCESS_DATA].[dbo].[V_Zinc_Details] where year_month>='" & stdate.ToString("yyyy-MM") & "'"
        Dim q3 As String = "SELECT to_char(dcc_ts_end, 'YYYY-MM') as DT, round(sum((dcc_ln_coil*dcc_sec2_coil)/1000) * (sum((dcc_ln_coil*dcc_sec2_coil)/1000 *  120)/sum((dcc_ln_coil*dcc_sec2_coil)/1000) + 4) /1000000,2) as Aim_CGL1 FROM v_cg1_galv_coil where to_char(dcc_ts_end, 'YYYY-MM-DD') > '" & stdate.ToString("yyyy-MM-dd") & "' and to_char(dcc_ts_end, 'YYYY-MM-DD HH24:MI') < '" & endate.ToString("yyyy-MM-dd") & " 06:00' and dcc_prod_cd in ('C05') group by to_char(dcc_ts_end, 'YYYY-MM') order by 1"
        Dim q4 As String = "SELECT to_char(dcc_ts_end, 'YYYY-MM') as DT, round(sum((dcc_ln_coil*dcc_sec2_coil)/1000) * (sum((dcc_ln_coil*dcc_sec2_coil)/1000 *  80)/sum((dcc_ln_coil*dcc_sec2_coil)/1000) + 4) /1000000,2) as Aim_CGL1 FROM v_cg1_galv_coil where to_char(dcc_ts_end, 'YYYY-MM-DD') > '" & stdate.ToString("yyyy-MM-dd") & "' and to_char(dcc_ts_end, 'YYYY-MM-DD HH24:MI') < '" & endate.ToString("yyyy-MM-dd") & " 06:00' and dcc_prod_cd in ('C02') group by to_char(dcc_ts_end, 'YYYY-MM') order by 1"
        Dim dh As New DataHandler
        CloseConnection()
        Oleconnection_ora.Open()
        Ora_selectquery(q1)
        OleAdap.Fill(ds8, "Aim_CGl2")

        Ora_selectquery(q3)
        OleAdap.Fill(ds8, "Aim_CGl1")

        Dim dt8 As DataTable = dh.GetDataSetFromQuery(q2).Tables(0)
        Dim dt9 As DataTable = dt8.Copy

        ds8.Tables.Add(dt9)

        Ora_selectquery(q4)
        OleAdap.Fill(ds8, "Aim_CGl1_2")

        dt9.Columns.Add("cgl1yield", GetType(Double))
        dt9.Columns.Add("cgl2yield", GetType(Double))
        For i As Integer = 0 To dt9.Rows.Count - 1
            Dim mnth As String = dt9.Rows(i)(0)
            Dim temp() As DataRow = ds8.Tables("Aim_CGl2").Select("DT='" & mnth & "'")
            If temp.Length > 0 Then
                If dt9.Rows(i)("CGL2") > 0 Then
                    dt9.Rows(i)("cgl2yield") = dt9.Rows(i)("CGL2") * 100 / temp(0)(1)
                Else
                    dt9.Rows(i)("cgl2yield") = 0
                End If
            End If

            Dim totcgl1 As Double = 0
            temp = ds8.Tables("Aim_CGl1").Select("DT='" & mnth & "'")
            If temp.Length > 0 Then
                totcgl1 += temp(0)(1)
            End If
            temp = ds8.Tables("Aim_CGl1_2").Select("DT='" & mnth & "'")
            If temp.Length > 0 Then
                totcgl1 += temp(0)(1)
            End If

            If dt9.Rows(i)("CGL1") > 0 Then
                dt9.Rows(i)("cgl1yield") = dt9.Rows(i)("CGL1") * 100 / totcgl1
            Else
                dt9.Rows(i)("cgl1yield") = 0
            End If

        Next


        Return ds8
    End Function

    Public Sub PlotChartForZincStackBar(ByVal dt As DataTable, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String)
        Try
            LiteralName.Text = ""
            'Dim min_time, max_time As String
            'min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-30), "yyyy-MM-dd HH:mm")
            'max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm")
            'Dim yVal() As Decimal
            'yVal = (From row In dt Select col = CDec(row(YAxisColName))).ToArray()
            'Dim y_min As String = yVal.Min()
            'Dim y_max As String = yVal.Max()
            'Dim y_min As String = yVal.Min() - (10 / 100 * yVal.Min)
            'Dim y_max As String = yVal.Max() + (10 / 100 * yVal.Max)
            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                 "$.jqplot.config.enablePlugins = true;" & vbCrLf
            Dim ticks As String = "["
            Dim line1, line2, line3 As String
            line1 &= "["
            line2 &= "["
            line3 &= "["
            Dim labels As String = "['" & dt.Columns(1).ColumnName & "','" & dt.Columns(2).ColumnName & "']"
            For i As Integer = 0 To dt.Rows.Count - 1
                If i > 0 Then
                    ticks &= ","
                    line1 &= ","
                    line2 &= ","
                    line3 &= ","
                End If
                ticks &= "'" & dt.Rows(i)(0) & "'"
                If IsDBNull(dt.Rows(i)(1)) Then
                    line1 &= 0
                Else
                    line1 &= dt.Rows(i)(1)
                End If
                If IsDBNull(dt.Rows(i)(2)) Then
                    line2 &= 0
                Else
                    line2 &= dt.Rows(i)(2)
                End If

                'line3 &= dt.Rows(i)("plt3")

            Next
            ticks &= "]"
            line1 &= "]"
            line2 &= "]"
            line3 &= "]"

            js &= "var ticks=" & ticks & ";"
            js &= "var pl1=" & line1 & ";"
            js &= "var pl2=" & line2 & ";"
            'js &= "var pl3=" & line3 & ";"

            js &= "var " & PlotName & " = $.jqplot('" & ContainerName & "', [pl1,pl2], {"
            js &= " stackSeries: true,captureRightClick: true,highlighter: {show: true,tooltipContentEditor: function (str, seriesIndex, pointIndex, plot) {var html = '<div>Month: ' + plot.options.axes.xaxis.ticks[pointIndex] + '<br/>Data: ' + Math.round(plot.data[seriesIndex][pointIndex]); return html;}},"
            js &= "seriesDefaults:{renderer:$.jqplot.BarRenderer, rendererOptions: {barMargin: 20,highlightMouseDown: true},pointLabels: {show: false}},"
            js &= "  axesDefaults: { tickRenderer: $.jqplot.CanvasAxisTickRenderer, tickOptions: {  angle: 30,fontSize:   '10pt' } },"
            js &= "seriesColors:['#0B62A4','#B62455','#4DA74D'],"
            js &= "axes: {"
            js &= "xaxis: { renderer: $.jqplot.CategoryAxisRenderer,ticks: " & ticks & "  },"
            js &= "yaxis: { padMin: 0,label:'Weight(T)',labelRenderer: $.jqplot.CanvasAxisLabelRenderer },"
            js &= "},legend: {show: true, location: 's',labels:" & labels & ",renderer: $.jqplot.EnhancedLegendRenderer,placement:  'outside',placement: 'outsideGrid',rendererOptions:{numberColumns:3}}});"
            js &= "</script>"
            LiteralName.Text = js

        Catch ex As Exception
            Dim i As String = ""

        End Try

    End Sub

    Public Sub PlotChartForZincBar(ByVal dt As DataTable, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String)
        Try
            LiteralName.Text = ""
            'Dim min_time, max_time As String
            'min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-30), "yyyy-MM-dd HH:mm")
            'max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm")
            'Dim yVal() As Decimal
            'yVal = (From row In dt Select col = CDec(row(YAxisColName))).ToArray()
            'Dim y_min As String = yVal.Min()
            'Dim y_max As String = yVal.Max()
            'Dim y_min As String = yVal.Min() - (10 / 100 * yVal.Min)
            'Dim y_max As String = yVal.Max() + (10 / 100 * yVal.Max)
            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                 "$.jqplot.config.enablePlugins = true;" & vbCrLf
            Dim ticks As String = "["
            Dim line1, line2, line3 As String
            line1 &= "["
            line2 &= "["
            line3 &= "["
            Dim labels As String = "['Plan','Actual']"
            For i As Integer = 0 To dt.Rows.Count - 1
                If i > 0 Then
                    ticks &= ","
                    line1 &= ","
                    line2 &= ","
                    'line3 &= ","
                End If
                ticks &= "'" & dt.Rows(i)(0) & "'"
                If IsDBNull(dt.Rows(i)(1)) Then
                    line1 &= 0
                Else
                    line1 &= dt.Rows(i)(1) * 1000
                End If
                If IsDBNull(dt.Rows(i)("series2")) Then
                    line2 &= 0
                Else
                    line2 &= dt.Rows(i)("series2")
                End If

                'line3 &= dt.Rows(i)("plt3")

            Next
            ticks &= "]"
            line1 &= "]"
            line2 &= "]"
            line3 &= "]"

            js &= "var ticks=" & ticks & ";"
            js &= "var pl1=" & line1 & ";"
            js &= "var pl2=" & line2 & ";"
            'js &= "var pl3=" & line3 & ";"

            js &= "var " & PlotName & " = $.jqplot('" & ContainerName & "', [pl1,pl2], {"
            js &= " captureRightClick: true,highlighter: {show: true,tooltipContentEditor: function (str, seriesIndex, pointIndex, plot) {var html = '<div>Month: ' + plot.options.axes.xaxis.ticks[pointIndex] + '<br/>Data: ' + Math.round(plot.data[seriesIndex][pointIndex]); return html;}},"
            js &= "seriesDefaults:{renderer:$.jqplot.BarRenderer, rendererOptions: {barMargin: 10,highlightMouseDown: true},pointLabels: {show: false}},"
            js &= "  axesDefaults: { tickRenderer: $.jqplot.CanvasAxisTickRenderer, tickOptions: {  angle: 30,fontSize:   '10pt' } },"
            js &= "seriesColors:['#0B62A4','#B62455','#4DA74D'],"
            js &= "axes: {"
            js &= "xaxis: { renderer: $.jqplot.CategoryAxisRenderer,ticks: " & ticks & "  },"
            js &= "yaxis: { padMin: 0,label:'',labelRenderer: $.jqplot.CanvasAxisLabelRenderer },"
            js &= "},legend: {show: true, location: 's',labels:" & labels & ",renderer: $.jqplot.EnhancedLegendRenderer,placement:  'outside',placement: 'outsideGrid',rendererOptions:{numberColumns:3}}});"
            js &= "</script>"
            ' js &= "}});"
            LiteralName.Text = js

        Catch ex As Exception
            Dim i As String = ""

        End Try

    End Sub
    Public Sub PlotLineChartForZinc(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String, ByVal GroupByColName As String)
        Try
            'For i As Integer = 0 To dt.Rows.Count - 1
            '    If IsDBNull(dt.Rows(i)("LTRI_PARA_MIN")) Then
            '        dt.Rows(i)("LTRI_PARA_MIN") = dt.Rows(i)("LTRI_PARA_MIN").ToString().Replace(vbNull, vbDecimal)
            '    End If
            'Next
            LiteralName.Text = ""
            Dim min_time, max_time As String
            min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-30), "yyyy-MM-dd HH:mm")
            max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm")

            'Dim xTimestampVal(), yVal() As String
            Dim yVal() As Decimal

            'xTimestampVal = (From row In dt Select col = row(XAxisColName).ToString).ToArray
            yVal = (From row In dt Select col = CDec(row(YAxisColName))).ToArray()

            'Dim y_min As String = yVal.Min()
            'Dim y_max As String = yVal.Max()
            Dim y_min As String = yVal.Min() - (10 / 100 * yVal.Min)
            Dim y_max As String = yVal.Max() + (10 / 100 * yVal.Max)

            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf
            dt.DefaultView.RowFilter = ""
            Dim dtGrades As DataTable = dt.DefaultView.ToTable(True, GroupByColName) 'All distinct Grades
            Dim dvDefault As DataView = dt.DefaultView
            Dim flag As Boolean = False
            For i As Integer = 0 To dtGrades.Rows.Count - 1
                js &= "var line" & (i + 1).ToString & " = ["
                dvDefault.RowFilter = "" & GroupByColName & "='" & dtGrades.Rows(i)(0) & "'"
                For j As Integer = 0 To dvDefault.Count - 1
                    If j > 0 Then
                        js &= ","
                    End If
                    js &= "["
                    Dim dtTime As DateTime = dvDefault.Item(j)("date1")
                    If IsDBNull(dvDefault.Item(j)(GroupByColName)) Then
                        If IsDBNull(dvDefault.Item(j)("cd")) = False Then
                            js &= "'" & dtTime.ToString("yyyy-MM") & "', " & dvDefault.Item(j)("cd") & ", " & "null"
                        Else
                            js &= "'" & dtTime.ToString("yyyy-MM") & "', " & "null, null"
                        End If
                    Else
                        If IsDBNull(dvDefault.Item(j)("cd")) = False Then
                            js &= "'" & dtTime.ToString("yyyy-MM") & "', " & dvDefault.Item(j)("cd") & ", '(" & dvDefault.Item(j)(GroupByColName).ToString().Trim & ")'"
                            'js &= "'" & dtTime.ToString("yyyy-MM-dd HH:mm") & "', " & dvDefault.Item(j)("CLR_TEST_VALUE") & ", 'Pot'"
                        End If
                    End If
                    js &= "]"
                Next
                js &= "];" & vbCrLf
                flag = True
            Next

            Dim strg As String = ""
            Dim strseries As String = ""
            If flag Then
                strg = "[line1"
                strseries = " {pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
                For i As Integer = 1 To dtGrades.Rows.Count - 1
                    strg = strg + ",line" & i + 1
                    strseries = strseries + ", {pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
                Next
                strg &= "]"
            End If
            js &= "var seriesName = ['"
            Dim str As String = ""
            For i As Integer = 0 To dtGrades.Rows.Count - 1
                str &= dtGrades.Rows(i)(0).ToString().Trim() + "', '"
            Next
            str = str.Remove(str.LastIndexOf(", '"))
            str &= "];"
            js &= str
            js &= "opts = {" & vbCrLf &
            "title: '" & ChartTitle & "',highlighter: {show: true,tooltipContentEditor: function (str, seriesIndex, pointIndex, plot) {var html = '<div>Month: ' + plot.data[seriesIndex][pointIndex][0] + '<br/>Data: ' + Math.round(plot.data[seriesIndex][pointIndex][1]); return html;}}," & vbCrLf &
            "series:[" & strseries & "]," & vbCrLf &
            "seriesColors: ['#4C4ED8','#EF3862','#8A1EEE','#0982EC','#0FBDE3','#043D1D','#059B11','#E1EB05','#666699','#F4ED03','#EF8355','#818181','#FFA500', '#006400','#F10000','#996633','#ECAE06','#009999','#800000','#F05904']," & vbCrLf &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            " angle: 30,fontSize:   '10pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "renderer: $.jqplot.CategoryAxisRenderer" & vbCrLf &
            "}," & vbCrLf &
            "yaxis: { " & vbCrLf &
            "tickOptions: { formatString: '%d' }," & vbCrLf &
            "min: " & y_min & "," & vbCrLf &
            "max: " & y_max & "," & vbCrLf &
            "autoscale:true," & vbCrLf &
            "label: '" & YAxisLabelName & "'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "showTooltip: false," & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "animate: true," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf &
            "legend: {" & vbCrLf &
            "show: true," & vbCrLf &
            "location: 's'," & vbCrLf &
            "labels: seriesName," & vbCrLf &
            "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf &
            "placement: 'outsideGrid'," & vbCrLf &
            "rendererOptions: {" & vbCrLf &
            "numberRows: 1," & vbCrLf &
            "marginTop: 10" & vbCrLf &
            "}" & vbCrLf &
            "}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "', " & strg & ", opts);" & vbCrLf &
            "</script>" & vbCrLf

            LiteralName.Text = js
        Catch ex As Exception

        End Try
    End Sub

    Public Function GetDataForGridview() As DataTable
        CloseConnection()
        Oleconnection_ora.Open()

        Dim endate As Date = Date.Now
        Dim stdate As Date = endate.AddMonths(-11)

        Dim dstring As String = ""

        While stdate <= endate
            dstring &= "," & "min(decode(ddt,'" & stdate.ToString("yyyy-MM") & "',thickness)) """ & stdate.ToString("MM-yyyy") & """"
            stdate = stdate.AddMonths(1)
        End While

        Dim OraQuery As String = "select prodcd" & dstring & " " &
"from (select to_char(prm_ts_end,'YYYY-MM') as ddt,decode(prm_cd_prod,'C02','SOFT','C03','GA','C05','HARD','C10','ZS') as prodcd, round(avg(prm_sec1_coil),2) as thickness " &
"From crmdba.t_cgl_fur_param Where prm_ts_end between add_months(sysdate,-11) and sysdate group by to_char(prm_ts_end, 'YYYY-MM'),prm_cd_prod " &
"union select to_char(dcc_ts_end,'YYYY-MM'),decode(dcc_prod_cd,'C02','SOFT','C03','GA','C05','HARD','C10','ZS') as prodcd, round(avg(dcc_sec1_coil),2) as thicjness from v_cg1_galv_coil " &
" where dcc_ts_end between add_months(sysdate,-11) and sysdate group by to_char(dcc_ts_end, 'YYYY-MM'),dcc_prod_cd) group by prodcd"
        Ora_selectquery(OraQuery)
        OleAdap.Fill(ds5)
        dt5 = ds5.Tables(0)
        Return dt5
    End Function

    Private Sub gvCoilData1_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles gvCoilData1.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim grp As String = DataBinder.Eval(e.Row.DataItem, "prodcd")
            For c As Integer = 1 To e.Row.Cells.Count - 1
                If grp = "SOFT" Then
                    If e.Row.Cells(c).Text <> "&nbsp;" Then

                        If CDbl(e.Row.Cells(c).Text >= 0.55) Then
                            e.Row.Cells(c).BackColor = Drawing.Color.LightGreen
                        Else
                            '                            e.Row.Cells(c).BackColor = Drawing.Color.Crimson
                            e.Row.Cells(c).BackColor = Drawing.Color.FromArgb(249, 98, 96)
                        End If
                    End If
                End If
                If grp = "HARD" Then
                    If e.Row.Cells(c).Text <> "&nbsp;" Then

                        If CDbl(e.Row.Cells(c).Text >= 0.46) Then
                            e.Row.Cells(c).BackColor = Drawing.Color.LightGreen
                        Else
                            'e.Row.Cells(c).BackColor = Drawing.Color.Crimson
                            e.Row.Cells(c).BackColor = Drawing.Color.FromArgb(249, 98, 96)
                        End If
                    End If
                End If
                If grp = "GA" Or grp = "ZS" Then
                    If e.Row.Cells(c).Text <> "&nbsp;" Then

                        If CDbl(e.Row.Cells(c).Text >= 0.98) Then
                            e.Row.Cells(c).BackColor = Drawing.Color.LightGreen
                        Else
                            'e.Row.Cells(c).BackColor = Drawing.Color.Crimson
                            e.Row.Cells(c).BackColor = Drawing.Color.FromArgb(249, 98, 96)
                        End If
                    End If
                End If
            Next

        End If
    End Sub

    Public Sub PlotChartForZincYieldBar(ByVal dt As DataTable, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String)
        Try
            LiteralName.Text = ""
            'Dim min_time, max_time As String
            'min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-30), "yyyy-MM-dd HH:mm")
            'max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm")
            'Dim yVal() As Decimal
            'yVal = (From row In dt Select col = CDec(row(YAxisColName))).ToArray()
            'Dim y_min As String = yVal.Min()
            'Dim y_max As String = yVal.Max()
            'Dim y_min As String = yVal.Min() - (10 / 100 * yVal.Min)
            'Dim y_max As String = yVal.Max() + (10 / 100 * yVal.Max)
            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                 "$.jqplot.config.enablePlugins = true;" & vbCrLf
            Dim ticks As String = "["
            Dim line1, line2, line3 As String
            line1 &= "["
            line2 &= "["
            line3 &= "["
            Dim labels As String = "['CGL1','CGL2']"
            For i As Integer = 0 To dt.Rows.Count - 1
                If i > 0 Then
                    ticks &= ","
                    line1 &= ","
                    line2 &= ","
                    'line3 &= ","
                End If
                ticks &= "'" & dt.Rows(i)(0) & "'"
                If IsDBNull(dt.Rows(i)(3)) Then
                    line1 &= 0
                Else
                    line1 &= dt.Rows(i)(3)
                End If
                If IsDBNull(dt.Rows(i)(4)) Then
                    line2 &= 0
                Else
                    line2 &= dt.Rows(i)(4)
                End If

                'line3 &= dt.Rows(i)("plt3")

            Next
            ticks &= "]"
            line1 &= "]"
            line2 &= "]"
            line3 &= "]"

            js &= "var ticks=" & ticks & ";"
            js &= "var pl1=" & line1 & ";"
            js &= "var pl2=" & line2 & ";"
            'js &= "var pl3=" & line3 & ";"

            js &= "var " & PlotName & " = $.jqplot('" & ContainerName & "', [pl1,pl2], {"
            js &= " captureRightClick: true,highlighter: {show: true,tooltipContentEditor: function (str, seriesIndex, pointIndex, plot) {var html = '<div>Month: ' + plot.options.axes.xaxis.ticks[pointIndex] + '<br/>Data: ' + Math.round(plot.data[seriesIndex][pointIndex]); return html;}},"
            js &= "seriesDefaults:{renderer:$.jqplot.BarRenderer, rendererOptions: {barMargin: 10,highlightMouseDown: true},pointLabels: {show: false}},"
            js &= "  axesDefaults: { tickRenderer: $.jqplot.CanvasAxisTickRenderer, tickOptions: {  angle: 30,fontSize:   '10pt' } },"
            js &= "seriesColors:['#0B62A4','#B62455','#4DA74D'],"
            js &= "axes: {"
            js &= "xaxis: { renderer: $.jqplot.CategoryAxisRenderer,ticks: " & ticks & "  },"
            js &= "yaxis: { min: 50.0,max:130.0,label:'',labelRenderer: $.jqplot.CanvasAxisLabelRenderer },"
            js &= "},legend: {show: true, location: 's',labels:" & labels & ",renderer: $.jqplot.EnhancedLegendRenderer,placement:  'outside',placement: 'outsideGrid',rendererOptions:{numberColumns:3}}});"
            js &= "</script>"
            LiteralName.Text = js

        Catch ex As Exception
            Dim i As String = ""

        End Try

    End Sub

End Class
