﻿Imports System.Data
Imports System.IO
Imports iTextSharp.text
Imports iTextSharp.text.html.simpleparser
Imports iTextSharp.text.pdf
Imports iTextSharp.tool.xml
Imports System.Net
Imports iTextSharp.text.html
Imports System.Data.SqlClient
Imports OfficeOpenXml
Imports System.Web
Imports System.Web.Services
Imports System.Web.Script.Serialization
Imports System.Web.UI

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
<System.Web.Script.Services.ScriptService()>
<WebService(Namespace:="http://tempuri.org/")>
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)>
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ZoneTempLineChart
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim objdatahandler As New DataHandler

    Dim Line As String
    Dim ColName As String
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Try
            If Not Page.IsPostBack Then

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
                'Dim dtStart As DateTime = DateTime.Now.AddMonths(-4).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                Dim check As String = Nothing

                'Dim Line As String = Session("Furnace")
                'Dim ColName As String = Session("ZoneTemp")
                'Dim StartTime As String = Session("StartDt")
                'Dim EndTime As String = Session("EndDt")
                'GenerateChart(Line, ColName, StartTime, EndTime)

                'ClientScript.RegisterStartupScript(Me.[GetType](), "clientScript", "function openWindow() { window.open('" & url & "'?Furnace='" & Line & "'& ZoneTemp='" & ZoneTC & "'& StartDt='" & dtStart & "'& EndDt='" & dtEnd & "' & Zone='" & Zone & "' & TC='" & TC & "','_blank', 'height=500,width=1400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no'); }  openWindow();", True)


            End If
            If Request.QueryString("Zone") <> "HistDataLineADrive" And Request.QueryString("Zone") <> "HistDataLineAOS" And Request.QueryString("Zone") <> "HistDataLineABoth" _
               And Request.QueryString("Zone") <> "HistDataLineBDrive" And Request.QueryString("Zone") <> "HistDataLineBOS" And Request.QueryString("Zone") <> "HistDataLineBBoth" Then

                If Request.QueryString("Furnace") <> "" And Request.QueryString("ZoneTemp") <> "" And Request.QueryString("StartDt") <> "" And Request.QueryString("EndDt") <> "" And Request.QueryString("Zone") <> "" And Request.QueryString("TC") <> "" Then
                    Line = Request.QueryString("Furnace")
                    If (Request.QueryString("TC") = "Avg") Then
                        'ColName = HttpUtility.UrlDecode(Server.HtmlDecode(Request.QueryString("ZoneTemp")))
                        ColName = Request.QueryString("ZoneTemp")
                    Else
                        ColName = Request.QueryString("ZoneTemp")
                    End If


                    Dim StartTime As String = Request.QueryString("StartDt")
                    Dim EndTime As String = Request.QueryString("EndDt")
                    Dim FurnaceZone As String = Request.QueryString("Zone")
                    Dim ZoneTC As String = Request.QueryString("TC")
                    GenerateChart(Line, ColName, StartTime, EndTime, FurnaceZone, ZoneTC)
                End If
            Else
                If Request.QueryString("Furnace") <> "" And Request.QueryString("ZoneTemp") <> "" And Request.QueryString("StartDt") <> "" And Request.QueryString("EndDt") <> "" And Request.QueryString("Zone") <> "" Then
                    Line = Request.QueryString("Furnace") 'Furnace LINE A
                    'If (Request.QueryString("TC") = "Avg") Then
                    '    'ColName = HttpUtility.UrlDecode(Server.HtmlDecode(Request.QueryString("ZoneTemp")))
                    '    ColName = Request.QueryString("ZoneTemp")
                    'Else
                    '    ColName = Request.QueryString("ZoneTemp")
                    'End If

                    ColName = Request.QueryString("ZoneTemp") 'Column Names that has to be included in Query
                    Dim StartTime As String = Request.QueryString("StartDt")
                    Dim EndTime As String = Request.QueryString("EndDt")
                    Dim FurnaceZone As String = Request.QueryString("Zone") 'HistDataLineADrive
                    'Dim ZoneTC As String = Request.QueryString("TC")
                    If FurnaceZone = "HistDataLineADrive" Then
                        GenerateHistoryChartLineADS(Line, ColName, StartTime, EndTime, FurnaceZone)
                    ElseIf FurnaceZone = "HistDataLineAOS" Then
                        GenerateHistoryChartLineAOS(Line, ColName, StartTime, EndTime, FurnaceZone)
                    ElseIf FurnaceZone = "HistDataLineABoth" Then
                        GenerateHistoryChartLineABS(Line, ColName, StartTime, EndTime, FurnaceZone)
                    ElseIf FurnaceZone = "HistDataLineBDrive" Then
                        GenerateHistoryChartLineBDS(Line, ColName, StartTime, EndTime, FurnaceZone)
                    ElseIf FurnaceZone = "HistDataLineBOS" Then
                        GenerateHistoryChartLineBOS(Line, ColName, StartTime, EndTime, FurnaceZone)
                    ElseIf FurnaceZone = "HistDataLineBBoth" Then
                        GenerateHistoryChartLineBBS(Line, ColName, StartTime, EndTime, FurnaceZone)
                    End If
                End If
            End If

        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Protected Sub txtDate_TextChanged(sender As Object, e As System.EventArgs) Handles txtDate.TextChanged
        Try
            If Request.QueryString("Zone") = "HistDataLineADrive" Then
                Dim fromDt As String = hfFrom.Value
                Dim toDt As String = hfTo.Value
                'Dim Line As String = Session("Furnace")
                'Dim ColName As String = Session("ZoneTemp")
                Dim FurnaceLine As String = Line
                Dim ThermoCpl As String = ColName
                Dim StartTime As String = fromDt
                Dim EndTime As String = toDt
                Dim FurnaceZone As String = Request.QueryString("Zone")
                Dim ZoneTC As String = Request.QueryString("TC")
                GenerateHistoryChartLineADS(Line, ColName, StartTime, EndTime, FurnaceZone)
            ElseIf Request.QueryString("Zone") = "HistDataLineAOS" Then
                Dim fromDt As String = hfFrom.Value
                Dim toDt As String = hfTo.Value
                'Dim Line As String = Session("Furnace")
                'Dim ColName As String = Session("ZoneTemp")
                Dim FurnaceLine As String = Line
                Dim ThermoCpl As String = ColName
                Dim StartTime As String = fromDt
                Dim EndTime As String = toDt
                Dim FurnaceZone As String = Request.QueryString("Zone")
                Dim ZoneTC As String = Request.QueryString("TC")
                GenerateHistoryChartLineAOS(Line, ColName, StartTime, EndTime, FurnaceZone)
            ElseIf Request.QueryString("Zone") = "HistDataLineABoth" Then
                Dim fromDt As String = hfFrom.Value
                Dim toDt As String = hfTo.Value
                'Dim Line As String = Session("Furnace")
                'Dim ColName As String = Session("ZoneTemp")
                Dim FurnaceLine As String = Line
                Dim ThermoCpl As String = ColName
                Dim StartTime As String = fromDt
                Dim EndTime As String = toDt
                Dim FurnaceZone As String = Request.QueryString("Zone")
                Dim ZoneTC As String = Request.QueryString("TC")
                GenerateHistoryChartLineABS(Line, ColName, StartTime, EndTime, FurnaceZone)
            ElseIf Request.QueryString("Zone") = "HistDataLineBDrive" Then
                Dim fromDt As String = hfFrom.Value
                Dim toDt As String = hfTo.Value
                'Dim Line As String = Session("Furnace")
                'Dim ColName As String = Session("ZoneTemp")
                Dim FurnaceLine As String = Line
                Dim ThermoCpl As String = ColName
                Dim StartTime As String = fromDt
                Dim EndTime As String = toDt
                Dim FurnaceZone As String = Request.QueryString("Zone")
                Dim ZoneTC As String = Request.QueryString("TC")
                GenerateHistoryChartLineBDS(Line, ColName, StartTime, EndTime, FurnaceZone)
            ElseIf Request.QueryString("Zone") = "HistDataLineBOS" Then
                Dim fromDt As String = hfFrom.Value
                Dim toDt As String = hfTo.Value
                'Dim Line As String = Session("Furnace")
                'Dim ColName As String = Session("ZoneTemp")
                Dim FurnaceLine As String = Line
                Dim ThermoCpl As String = ColName
                Dim StartTime As String = fromDt
                Dim EndTime As String = toDt
                Dim FurnaceZone As String = Request.QueryString("Zone")
                Dim ZoneTC As String = Request.QueryString("TC")
                GenerateHistoryChartLineBOS(Line, ColName, StartTime, EndTime, FurnaceZone)
            ElseIf Request.QueryString("Zone") = "HistDataLineBBoth" Then
                Dim fromDt As String = hfFrom.Value
                Dim toDt As String = hfTo.Value
                'Dim Line As String = Session("Furnace")
                'Dim ColName As String = Session("ZoneTemp")
                Dim FurnaceLine As String = Line
                Dim ThermoCpl As String = ColName
                Dim StartTime As String = fromDt
                Dim EndTime As String = toDt
                Dim FurnaceZone As String = Request.QueryString("Zone")
                Dim ZoneTC As String = Request.QueryString("TC")
                GenerateHistoryChartLineBBS(Line, ColName, StartTime, EndTime, FurnaceZone)
            Else
                Dim fromDt As String = hfFrom.Value
                Dim toDt As String = hfTo.Value
                'Dim Line As String = Session("Furnace")
                'Dim ColName As String = Session("ZoneTemp")
                Dim FurnaceLine As String = Line
                Dim ThermoCpl As String = ColName
                Dim StartTime As String = fromDt
                Dim EndTime As String = toDt
                Dim FurnaceZone As String = Request.QueryString("Zone")
                Dim ZoneTC As String = Request.QueryString("TC")
                GenerateChart(Line, ColName, StartTime, EndTime, FurnaceZone, ZoneTC)
            End If
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Protected Sub GenerateChart(Furnace As String, Column As String, strtDate As String, enDate As String, FurnaceZone As String, ZoneTC As String)
        Try
            Dim sqlQuery As String
            Dim LegenDesc As String
            Dim s As StringBuilder = New StringBuilder()
            Literal1.Text = Nothing


            If ZoneTC = "Avg" Then

                sqlQuery = "Select FORMAT(TIMESTAMP,'dd-MM-yyyy HH:mm:ss') As TIMESTAMP,LINE, Cast(" & Column & " As Integer) As AvgTemp From [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ZONE_TEMP] Where LINE = '" & Furnace & "'"
                sqlQuery &= " AND TIMESTAMP BETWEEN '" & strtDate & "' AND '" & enDate & "' Order By TIMESTAMP ASC"

                'sqlQuery = "Select TIMESTAMP,LINE, Cast(" & Column & " As Integer) As AvgTemp From [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ZONE_TEMP] Where LINE = '" & Furnace & "'"
                'sqlQuery &= " AND TIMESTAMP BETWEEN '2022-03-20 10:00' AND '2022-03-20 11:00' Order By TIMESTAMP ASC"

            Else

                sqlQuery = "Select FORMAT(TIMESTAMP,'dd-MM-yyyy HH:mm:ss') As TIMESTAMP,LINE, Cast(" & Column & " As Integer) As " & Column & " From [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ZONE_TEMP] Where LINE = '" & Furnace & "'"
                sqlQuery &= " AND TIMESTAMP BETWEEN '" & strtDate & "' AND '" & enDate & "' Order By TIMESTAMP ASC"

                'sqlQuery = "Select TIMESTAMP,LINE, Cast(" & Column & " As Integer) As " & Column & " From [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ZONE_TEMP] Where LINE = '" & Furnace & "'"
                'sqlQuery &= " AND TIMESTAMP BETWEEN '2022-03-20 10:00' AND '2022-03-20 11:00' Order By TIMESTAMP ASC"
            End If


            Dim ds As DataSet = objdatahandler.GetDataSetFromQuery(sqlQuery)
            Dim dt As DataTable = ds.Tables(0)

            Dim data As String = Nothing
            Dim date_val As String = Nothing
            If ZoneTC = "Avg" Then
                Column = "AvgTemp"
                'LegenDesc = "Furnace-" & Session("Furnace") & " " & Session("Zone") & " Average Temperature"
                LegenDesc = "Furnace-" & Line & " " & FurnaceZone & " Average Temperature"
            Else
                'LegenDesc = "Furnace-" & Session("Furnace") & " " & Session("Zone") & " " & Session("TC") & " Temperature"
                LegenDesc = "Furnace-" & Line & " " & FurnaceZone & " " & ZoneTC & " Temperature"
            End If

            For I As Integer = 0 To dt.Rows.Count - 1
                data &= dt(I)(Column) & ","
                date_val &= "'" & dt(I)("TIMESTAMP") & "',"
            Next

            Dim ymin As Double = Convert.ToDouble(dt.Compute("min(" & Column & ")", "")) - 100
            Dim ymax As Double = Convert.ToDouble(dt.Compute("max(" & Column & ")", "")) + 100

            'Dim LegenDesc As String = "Furnace-" & Session("Furnace") & " " & Session("Zone") & " " & Session("TC")

            s.Append("<script>")
            s.Append("var myChart = echarts.init(document.getElementById('main'));")
            's.Append("const colors = ['#5470C6', '#91CC75', '#EE6666'];")
            s.Append("const colors = ['#5470C6'];")
            s.Append("option = {")
            s.Append("color: colors,")
            s.Append("tooltip:")
            s.Append("{")
            s.Append("trigger: 'axis',")
            s.Append("axisPointer:")
            s.Append("{")
            s.Append("type: 'cross'")
            s.Append("}")
            s.Append("},")
            s.Append("grid:")
            s.Append("{")
            's.Append("right: '20%',")
            s.Append("right: '5%',")
            s.Append("bottom: '30%'")
            's.Append("bottom: '20%'")
            s.Append("},")
            s.Append("toolbox:")
            s.Append("{")
            s.Append("feature:")
            s.Append("{")
            s.Append("dataView: { show: true, readOnly: false },")
            s.Append("restore: { show: true },")
            s.Append("saveAsImage: { show: true }")
            s.Append("}")
            s.Append("},")
            s.Append("legend:")
            s.Append("{")
            's.Append("data:['TC Temp']")
            s.Append("data:['" & LegenDesc & "']")
            s.Append("},")
            s.Append("xAxis:")
            s.Append("[")
            s.Append("{")
            s.Append("type: 'category',")
            s.Append("axisTick:")
            s.Append("{")
            s.Append("alignWithLabel: true")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            s.Append("show: true,")
            s.Append("rotate: 45")
            s.Append("},")
            s.Append("data:[" & date_val & "]")
            s.Append("}")
            s.Append("],")
            s.Append("yAxis:")
            s.Append("[")
            s.Append("{")
            s.Append("type: 'value',")
            s.Append("name: 'TC Temp',")
            s.Append("min: " & ymin & ",")
            s.Append("max: " & ymax & ",")
            s.Append("position: 'left',")
            s.Append("axisLine:")
            s.Append("{")
            s.Append("show: true,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[0]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            s.Append("formatter: '{value} '")
            s.Append("}")
            s.Append("},")
            s.Append("],")
            s.Append("series:")
            s.Append("[")
            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: '" & LegenDesc & "',")
            s.Append("type: 'line',")
            s.Append("data:[")
            s.Append(data)
            s.Append("]")
            s.Append("},")
            s.Append("]")
            s.Append("};")
            s.Append("myChart.setOption(option);")
            s.Append("</script>")
            Literal1.Text = s.ToString()
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub GenerateHistoryChartLineADS(Furnace As String, Column As String, strtDate As String, enDate As String, FurnaceZone As String)
        Try
            Dim sqlQuery As String
            Dim LegenDesc As String
            Dim s As StringBuilder = New StringBuilder()
            Literal1.Text = Nothing
            Dim ColumnName() As String = Column.Split(",")
            Dim ModifyColumn As String
            For i As Integer = 0 To ColumnName.Length - 1
                If i = ColumnName.Length - 1 Then
                    ModifyColumn &= "Cast(" & ColumnName(i) & " As Integer) As " & ColumnName(i) & " "
                Else
                    ModifyColumn &= "Cast(" & ColumnName(i) & " As Integer) As " & ColumnName(i) & ", "
                End If
            Next
            ' Cast(" & ColumnName(i) & " As Integer)

            ''If ZoneTC = "Avg" Then

            ''    sqlQuery = "Select TIMESTAMP,LINE, Cast(" & Column & " As Integer) As AvgTemp From [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ZONE_TEMP] Where LINE = '" & Furnace & "'"
            ''    sqlQuery &= " AND TIMESTAMP BETWEEN '" & strtDate & "' AND '" & enDate & "' Order By TIMESTAMP ASC"

            ''    'sqlQuery = "Select TIMESTAMP,LINE, Cast(" & Column & " As Integer) As AvgTemp From [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ZONE_TEMP] Where LINE = '" & Furnace & "'"
            ''    'sqlQuery &= " AND TIMESTAMP BETWEEN '2022-03-20 10:00' AND '2022-03-20 11:00' Order By TIMESTAMP ASC"

            ''Else

            ''    sqlQuery = "Select TIMESTAMP,LINE, Cast(" & Column & " As Integer) As " & Column & " From [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ZONE_TEMP] Where LINE = '" & Furnace & "'"
            ''    sqlQuery &= " AND TIMESTAMP BETWEEN '" & strtDate & "' AND '" & enDate & "' Order By TIMESTAMP ASC"

            ''    'sqlQuery = "Select TIMESTAMP,LINE, Cast(" & Column & " As Integer) As " & Column & " From [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ZONE_TEMP] Where LINE = '" & Furnace & "'"
            ''    'sqlQuery &= " AND TIMESTAMP BETWEEN '2022-03-20 10:00' AND '2022-03-20 11:00' Order By TIMESTAMP ASC"
            ''End If

            'sqlQuery = "Select TIMESTAMP,LINE, Cast(" & Column & " As Integer) From [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ZONE_TEMP] Where LINE = '" & Furnace & "'"
            'sqlQuery &= " AND TIMESTAMP BETWEEN '" & strtDate & "' AND '" & enDate & "' Order By TIMESTAMP ASC"

            sqlQuery = "Select FORMAT(TIMESTAMP,'dd-MM-yyyy HH:mm:ss') As TIMESTAMP,LINE, " & ModifyColumn & " From [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ZONE_TEMP] Where LINE = '" & Furnace & "'"
            sqlQuery &= " AND TIMESTAMP BETWEEN '" & strtDate & "' AND '" & enDate & "' Order By TIMESTAMP ASC"

            Dim ds As DataSet = objdatahandler.GetDataSetFromQuery(sqlQuery)
            Dim dt As DataTable = ds.Tables(0)

            Dim dataZ1_TC1 As String = Nothing
            Dim dataZ1_TC3 As String = Nothing
            Dim dataZ2_TC2 As String = Nothing
            Dim dataZ3_TC1 As String = Nothing
            Dim dataZ3_TC3 As String = Nothing
            Dim dataZ4_TC2 As String = Nothing
            Dim dataZ5_TC2 As String = Nothing
            Dim dataZ6_TC2 As String = Nothing
            Dim dataZ7_TC2 As String = Nothing
            Dim dataZ8_TC2 As String = Nothing
            Dim dataZ9_TC1 As String = Nothing
            Dim dataZ9_TC3 As String = Nothing

            Dim date_val As String = Nothing
            'If ZoneTC = "Avg" Then
            '    Column = "AvgTemp"
            '    'LegenDesc = "Furnace-" & Session("Furnace") & " " & Session("Zone") & " Average Temperature"
            '    LegenDesc = "Furnace-" & Line & " " & FurnaceZone & " Average Temperature"
            'Else
            '    'LegenDesc = "Furnace-" & Session("Furnace") & " " & Session("Zone") & " " & Session("TC") & " Temperature"
            '    LegenDesc = "Furnace-" & Line & " " & FurnaceZone & " " & ZoneTC & " Temperature"
            'End If
            LegenDesc = "'Zone1_TC1','Zone1_TC3','Zone2_TC2','Zone3_TC1','Zone3_TC3','Zone4_TC2','Zone5_TC2','Zone6_TC2','Zone7_TC2','Zone8_TC2','Zone9_TC1','Zone9_TC3'"
            Dim LegendDescSeries() As String = LegenDesc.Split(",")


            For I As Integer = 0 To dt.Rows.Count - 1
                dataZ1_TC1 &= dt(I)("Zone1_TC1") & ","
                dataZ1_TC3 &= dt(I)("Zone1_TC3") & ","
                dataZ2_TC2 &= dt(I)("Zone2_TC2") & ","
                dataZ3_TC1 &= dt(I)("Zone3_TC1") & ","
                dataZ3_TC3 &= dt(I)("Zone3_TC3") & ","
                dataZ4_TC2 &= dt(I)("Zone4_TC2") & ","
                dataZ5_TC2 &= dt(I)("Zone5_TC2") & ","
                dataZ6_TC2 &= dt(I)("Zone6_TC2") & ","
                dataZ7_TC2 &= dt(I)("Zone7_TC2") & ","
                dataZ8_TC2 &= dt(I)("Zone8_TC2") & ","
                dataZ9_TC1 &= dt(I)("Zone9_TC1") & ","
                dataZ9_TC3 &= dt(I)("Zone9_TC3") & ","

                date_val &= "'" & dt(I)("TIMESTAMP") & "',"
            Next

            'Dim ymin As Double = Convert.ToDouble(dt.Compute("min(" & Column & ")", "")) - 100
            'Dim ymax As Double = Convert.ToDouble(dt.Compute("max(" & Column & ")", "")) + 100

            Dim ymin As Double = 0.0
            Dim ymax As Double = 0.0

            Dim yminZone1_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone1_TC1)", "")) - 100
            Dim yminZone1_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone1_TC3)", "")) - 100
            Dim yminZone2_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone2_TC2)", "")) - 100
            Dim yminZone3_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone3_TC1)", "")) - 100
            Dim yminZone3_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone3_TC3)", "")) - 100
            Dim yminZone4_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone4_TC2)", "")) - 100
            Dim yminZone5_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone5_TC2)", "")) - 100
            Dim yminZone6_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone6_TC2)", "")) - 100
            Dim yminZone7_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone7_TC2)", "")) - 100
            Dim yminZone8_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone8_TC2)", "")) - 100
            Dim yminZone9_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone9_TC1)", "")) - 100
            Dim yminZone9_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone9_TC3)", "")) - 100

            Dim ymaxZone1_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone1_TC1)", "")) + 100
            Dim ymaxZone1_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone1_TC3)", "")) + 100
            Dim ymaxZone2_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone2_TC2)", "")) + 100
            Dim ymaxZone3_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone3_TC1)", "")) + 100
            Dim ymaxZone3_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone3_TC3)", "")) + 100
            Dim ymaxZone4_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone4_TC2)", "")) + 100
            Dim ymaxZone5_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone5_TC2)", "")) + 100
            Dim ymaxZone6_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone6_TC2)", "")) + 100
            Dim ymaxZone7_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone7_TC2)", "")) + 100
            Dim ymaxZone8_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone8_TC2)", "")) + 100
            Dim ymaxZone9_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone9_TC1)", "")) + 100
            Dim ymaxZone9_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone9_TC3)", "")) + 100

            ymax = ymaxZone1_TC1

            If ymaxZone1_TC1 > ymax Then
                ymax = ymaxZone1_TC1
            End If
            If ymaxZone1_TC3 > ymax Then
                ymax = ymaxZone1_TC3
            End If
            If ymaxZone2_TC2 > ymax Then
                ymax = ymaxZone2_TC2
            End If
            If ymaxZone3_TC1 > ymax Then
                ymax = ymaxZone3_TC1
            End If
            If ymaxZone3_TC3 > ymax Then
                ymax = ymaxZone3_TC3
            End If
            If ymaxZone4_TC2 > ymax Then
                ymax = ymaxZone4_TC2
            End If
            If ymaxZone5_TC2 > ymax Then
                ymax = ymaxZone5_TC2
            End If
            If ymaxZone6_TC2 > ymax Then
                ymax = ymaxZone6_TC2
            End If
            If ymaxZone7_TC2 > ymax Then
                ymax = ymaxZone7_TC2
            End If
            If ymaxZone8_TC2 > ymax Then
                ymax = ymaxZone8_TC2
            End If
            If ymaxZone9_TC1 > ymax Then
                ymax = ymaxZone9_TC1
            End If
            If ymaxZone9_TC3 > ymax Then
                ymax = ymaxZone9_TC3
            End If

            ymin = yminZone1_TC1

            If yminZone1_TC1 < ymin Then
                ymin = yminZone1_TC1
            End If
            If yminZone1_TC3 < ymin Then
                ymin = yminZone1_TC3
            End If
            If yminZone2_TC2 < ymin Then
                ymin = yminZone2_TC2
            End If
            If yminZone3_TC1 < ymin Then
                ymin = yminZone3_TC1
            End If
            If yminZone3_TC3 < ymin Then
                ymin = yminZone3_TC3
            End If
            If yminZone4_TC2 < ymin Then
                ymin = yminZone4_TC2
            End If
            If yminZone5_TC2 < ymin Then
                ymin = yminZone5_TC2
            End If
            If yminZone6_TC2 < ymin Then
                ymin = yminZone6_TC2
            End If
            If yminZone7_TC2 < ymin Then
                ymin = yminZone7_TC2
            End If
            If yminZone8_TC2 < ymin Then
                ymin = yminZone8_TC2
            End If
            If yminZone9_TC1 < ymin Then
                ymin = yminZone9_TC1
            End If
            If yminZone9_TC3 < ymin Then
                ymin = yminZone9_TC3
            End If


            'Dim LegenDesc As String = "Furnace-" & Session("Furnace") & " " & Session("Zone") & " " & Session("TC")

            ''------------------------------ Arranged Color Codes -----------------------------------------
            ''Red:#FF0000;Lime Green:#00FF00;Green:#008000;Navy blue:#000080;Black:#000000
            ''Magenta:#FF00FF;Brown:#A52A2A;Olive:#808000;Maroon:#800000;Teal:#008080
            ''Purple:#800080;Blue Gray:#98AFC7;DodgerBlue (W3C):#1E90FF;Deep Teal:#033E3E;SeaGreen (W3C):#2E8B57	
            ''Jade:#00A36C;Venom Green:#728C00;Pine Green:#387C44;Deep Yellow:#F6BE00;Copper:#B87333	
            ''Wood:#966F33;Antique Bronze:#665D1E;Taupe:#483C32;Milk Chocolate:#513B1C;Mahogany:#C04000	
            ''Tomato Sauce Red: #B21807;Orchid Purple:#B048B5;Bright Grape:#6F2DA8;Red Blood:#660000	
            ''#F39C12;#FF5733;#2E86C1

            s.Append("<script>")
            's.Append("var myChart = echarts.init(document.getElementById('main'));")
            s.Append("var myChart = echarts.init(document.getElementById('main'), null, {")
            s.Append("width:1200,")
            s.Append("height:500")
            s.Append("});")
            's.Append("const colors = ['#5470C6', '#91CC75', '#EE6666'];")
            's.Append("const colors = ['#5470C6'];")
            s.Append("const colors = ['#FF0000', '#008000', '#000080','#000000','#FF00FF','#A52A2A','#808000','#800000','#008080','#800080','#98AFC7','#513B1C'];")
            s.Append("option = {")
            s.Append("color: colors,")
            s.Append("tooltip:")
            s.Append("{")
            s.Append("trigger: 'axis',")
            s.Append("axisPointer:")
            s.Append("{")
            s.Append("type: 'cross'")
            s.Append("}")
            s.Append("},")
            s.Append("grid:")
            s.Append("{")
            's.Append("right: '20%',")
            s.Append("right: '5%',")
            s.Append("bottom: '30%'")
            's.Append("bottom: '20%'")
            s.Append("},")
            s.Append("toolbox:")
            s.Append("{")
            s.Append("feature:")
            s.Append("{")
            s.Append("dataView: { show: true, readOnly: false },")
            s.Append("restore: { show: true },")
            s.Append("saveAsImage: { show: true }")
            s.Append("}")
            s.Append("},")
            s.Append("legend:")
            s.Append("{")
            's.Append("data:['TC Temp']")
            s.Append("data:[" & LegenDesc & "],")
            s.Append("orient:'horizontal',")
            's.Append("right:10,")
            s.Append("bottom:'0%',")
            's.Append("top:'bottom',")
            's.Append("type:'scroll'")
            s.Append("},")
            s.Append("xAxis:")
            s.Append("[")
            s.Append("{")
            s.Append("type: 'category',")
            s.Append("axisTick:")
            s.Append("{")
            s.Append("alignWithLabel: true")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            s.Append("show: true,")
            s.Append("rotate: 45")
            s.Append("},")
            s.Append("data:[" & date_val & "]")
            s.Append("}")
            s.Append("],")
            s.Append("yAxis:")
            s.Append("[")
            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("name: " & LegendDescSeries(0) & ",")
            s.Append("name: 'Temp. Range',")
            s.Append("min: " & ymin & ",")
            s.Append("max: " & ymax & ",")
            s.Append("position: 'left',")
            s.Append("axisLine:")
            s.Append("{")
            s.Append("show: true,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[0]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            s.Append("formatter: '{value} '")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[1]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[2]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[3]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[4]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[5]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[6]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[7]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[8]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[9]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[10]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[11]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("],")
            s.Append("series:")
            s.Append("[")
            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(0) & ",")
            s.Append("type: 'line',")
            s.Append("data:[")
            s.Append(dataZ1_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(1) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 1,")
            s.Append("data:[")
            s.Append(dataZ1_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(2) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 2,")
            s.Append("data:[")
            s.Append(dataZ2_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(3) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 3,")
            s.Append("data:[")
            s.Append(dataZ3_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(4) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 4,")
            s.Append("data:[")
            s.Append(dataZ3_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(5) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 5,")
            s.Append("data:[")
            s.Append(dataZ4_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(6) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 6,")
            s.Append("data:[")
            s.Append(dataZ5_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(7) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 7,")
            s.Append("data:[")
            s.Append(dataZ6_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(8) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 8,")
            s.Append("data:[")
            s.Append(dataZ7_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(9) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 9,")
            s.Append("data:[")
            s.Append(dataZ8_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(10) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 10,")
            s.Append("data:[")
            s.Append(dataZ9_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(11) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 11,")
            s.Append("data:[")
            s.Append(dataZ9_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("]")
            s.Append("};")
            s.Append("myChart.setOption(option);")
            s.Append("</script>")
            Literal1.Text = s.ToString()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Protected Sub GenerateHistoryChartLineAOS(Furnace As String, Column As String, strtDate As String, enDate As String, FurnaceZone As String)
        Try
            Dim sqlQuery As String
            Dim LegenDesc As String
            Dim s As StringBuilder = New StringBuilder()
            Literal1.Text = Nothing
            Dim ColumnName() As String = Column.Split(",")
            Dim ModifyColumn As String
            For i As Integer = 0 To ColumnName.Length - 1
                If i = ColumnName.Length - 1 Then
                    ModifyColumn &= "Cast(" & ColumnName(i) & " As Integer) As " & ColumnName(i) & " "
                Else
                    ModifyColumn &= "Cast(" & ColumnName(i) & " As Integer) As " & ColumnName(i) & ", "
                End If
            Next

            sqlQuery = "Select FORMAT(TIMESTAMP,'dd-MM-yyyy HH:mm:ss') As TIMESTAMP,LINE, " & ModifyColumn & " From [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ZONE_TEMP] Where LINE = '" & Furnace & "'"
            sqlQuery &= " AND TIMESTAMP BETWEEN '" & strtDate & "' AND '" & enDate & "' Order By TIMESTAMP ASC"

            Dim ds As DataSet = objdatahandler.GetDataSetFromQuery(sqlQuery)
            Dim dt As DataTable = ds.Tables(0)
            'ZONE1_TC2,ZONE2_TC1,ZONE2_TC3,ZONE3_TC2,ZONE4_TC1,ZONE4_TC3,ZONE5_TC1,ZONE5_TC3,ZONE6_TC1,ZONE6_TC3,ZONE7_TC1,ZONE7_TC3,ZONE8_TC1,ZONE8_TC3,ZONE9_TC2

            Dim dataZ1_TC2 As String = Nothing
            Dim dataZ2_TC1 As String = Nothing
            Dim dataZ2_TC3 As String = Nothing
            Dim dataZ3_TC2 As String = Nothing
            Dim dataZ4_TC1 As String = Nothing
            Dim dataZ4_TC3 As String = Nothing
            Dim dataZ5_TC1 As String = Nothing
            Dim dataZ5_TC3 As String = Nothing
            Dim dataZ6_TC1 As String = Nothing
            Dim dataZ6_TC3 As String = Nothing
            Dim dataZ7_TC1 As String = Nothing
            Dim dataZ7_TC3 As String = Nothing
            Dim dataZ8_TC1 As String = Nothing
            Dim dataZ8_TC3 As String = Nothing
            Dim dataZ9_TC2 As String = Nothing

            Dim date_val As String = Nothing
            'If ZoneTC = "Avg" Then
            '    Column = "AvgTemp"
            '    'LegenDesc = "Furnace-" & Session("Furnace") & " " & Session("Zone") & " Average Temperature"
            '    LegenDesc = "Furnace-" & Line & " " & FurnaceZone & " Average Temperature"
            'Else
            '    'LegenDesc = "Furnace-" & Session("Furnace") & " " & Session("Zone") & " " & Session("TC") & " Temperature"
            '    LegenDesc = "Furnace-" & Line & " " & FurnaceZone & " " & ZoneTC & " Temperature"
            'End If
            'LegenDesc = "'Zone1_TC1','Zone1_TC3','Zone2_TC2','Zone3_TC1','Zone3_TC3','Zone4_TC2','Zone5_TC2','Zone6_TC2','Zone7_TC2','Zone8_TC2','Zone9_TC1','Zone9_TC3'"
            LegenDesc = "'ZONE1_TC2','ZONE2_TC1','ZONE2_TC3','ZONE3_TC2','ZONE4_TC1','ZONE4_TC3','ZONE5_TC1','ZONE5_TC3','ZONE6_TC1','ZONE6_TC3','ZONE7_TC1','ZONE7_TC3','ZONE8_TC1','ZONE8_TC3','ZONE9_TC2'"
            Dim LegendDescSeries() As String = LegenDesc.Split(",")


            For I As Integer = 0 To dt.Rows.Count - 1
                dataZ1_TC2 &= dt(I)("Zone1_TC2") & ","
                dataZ2_TC1 &= dt(I)("Zone2_TC1") & ","
                dataZ2_TC3 &= dt(I)("Zone2_TC3") & ","
                dataZ3_TC2 &= dt(I)("Zone3_TC2") & ","
                dataZ4_TC1 &= dt(I)("Zone4_TC1") & ","
                dataZ4_TC3 &= dt(I)("Zone4_TC3") & ","
                dataZ5_TC1 &= dt(I)("Zone5_TC1") & ","
                dataZ5_TC3 &= dt(I)("Zone5_TC3") & ","
                dataZ6_TC1 &= dt(I)("Zone6_TC1") & ","
                dataZ6_TC3 &= dt(I)("Zone6_TC3") & ","
                dataZ7_TC1 &= dt(I)("Zone7_TC1") & ","
                dataZ7_TC3 &= dt(I)("Zone7_TC3") & ","
                dataZ8_TC1 &= dt(I)("Zone8_TC1") & ","
                dataZ8_TC3 &= dt(I)("Zone8_TC3") & ","
                dataZ9_TC2 &= dt(I)("Zone9_TC2") & ","

                date_val &= "'" & dt(I)("TIMESTAMP") & "',"
            Next

            'Dim ymin As Double = Convert.ToDouble(dt.Compute("min(" & Column & ")", "")) - 100
            'Dim ymax As Double = Convert.ToDouble(dt.Compute("max(" & Column & ")", "")) + 100

            Dim ymin As Double = 0.0
            Dim ymax As Double = 0.0

            Dim yminZone1_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone1_TC2)", "")) - 100
            Dim yminZone2_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone2_TC1)", "")) - 100
            Dim yminZone2_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone2_TC3)", "")) - 100
            Dim yminZone3_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone3_TC2)", "")) - 100
            Dim yminZone4_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone4_TC1)", "")) - 100
            Dim yminZone4_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone4_TC3)", "")) - 100
            Dim yminZone5_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone5_TC1)", "")) - 100
            Dim yminZone5_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone5_TC3)", "")) - 100
            Dim yminZone6_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone6_TC1)", "")) - 100
            Dim yminZone6_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone6_TC3)", "")) - 100
            Dim yminZone7_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone7_TC1)", "")) - 100
            Dim yminZone7_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone7_TC3)", "")) - 100
            Dim yminZone8_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone8_TC1)", "")) - 100
            Dim yminZone8_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone8_TC3)", "")) - 100
            Dim yminZone9_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone9_TC2)", "")) - 100

            Dim ymaxZone1_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone1_TC2)", "")) + 100
            Dim ymaxZone2_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone2_TC1)", "")) + 100
            Dim ymaxZone2_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone2_TC3)", "")) + 100
            Dim ymaxZone3_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone3_TC2)", "")) + 100
            Dim ymaxZone4_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone4_TC1)", "")) + 100
            Dim ymaxZone4_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone4_TC3)", "")) + 100
            Dim ymaxZone5_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone5_TC1)", "")) + 100
            Dim ymaxZone5_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone5_TC3)", "")) + 100
            Dim ymaxZone6_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone6_TC1)", "")) + 100
            Dim ymaxZone6_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone6_TC3)", "")) + 100
            Dim ymaxZone7_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone7_TC1)", "")) + 100
            Dim ymaxZone7_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone7_TC3)", "")) + 100
            Dim ymaxZone8_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone8_TC1)", "")) + 100
            Dim ymaxZone8_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone8_TC3)", "")) + 100
            Dim ymaxZone9_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone9_TC2)", "")) + 100

            ymax = ymaxZone1_TC2

            If ymaxZone1_TC2 > ymax Then
                ymax = ymaxZone1_TC2
            End If
            If ymaxZone2_TC1 > ymax Then
                ymax = ymaxZone2_TC1
            End If
            If ymaxZone2_TC3 > ymax Then
                ymax = ymaxZone2_TC3
            End If
            If ymaxZone3_TC2 > ymax Then
                ymax = ymaxZone3_TC2
            End If
            If ymaxZone4_TC1 > ymax Then
                ymax = ymaxZone4_TC1
            End If
            If ymaxZone4_TC3 > ymax Then
                ymax = ymaxZone4_TC3
            End If
            If ymaxZone5_TC1 > ymax Then
                ymax = ymaxZone5_TC1
            End If
            If ymaxZone5_TC3 > ymax Then
                ymax = ymaxZone5_TC3
            End If
            If ymaxZone6_TC1 > ymax Then
                ymax = ymaxZone6_TC1
            End If
            If ymaxZone6_TC3 > ymax Then
                ymax = ymaxZone6_TC3
            End If
            If ymaxZone7_TC1 > ymax Then
                ymax = ymaxZone7_TC1
            End If
            If ymaxZone7_TC3 > ymax Then
                ymax = ymaxZone7_TC3
            End If
            If ymaxZone8_TC1 > ymax Then
                ymax = ymaxZone8_TC1
            End If
            If ymaxZone8_TC3 > ymax Then
                ymax = ymaxZone8_TC3
            End If
            If ymaxZone9_TC2 > ymax Then
                ymax = ymaxZone9_TC2
            End If

            ymin = yminZone1_TC2

            If yminZone1_TC2 < ymin Then
                ymin = yminZone1_TC2
            End If
            If yminZone2_TC1 < ymin Then
                ymin = yminZone2_TC1
            End If
            If yminZone2_TC3 < ymin Then
                ymin = yminZone2_TC3
            End If
            If yminZone3_TC2 < ymin Then
                ymin = yminZone3_TC2
            End If
            If yminZone4_TC1 < ymin Then
                ymin = yminZone4_TC1
            End If
            If yminZone4_TC3 < ymin Then
                ymin = yminZone4_TC3
            End If
            If yminZone5_TC1 < ymin Then
                ymin = yminZone5_TC1
            End If
            If yminZone5_TC3 < ymin Then
                ymin = yminZone5_TC3
            End If
            If yminZone6_TC1 < ymin Then
                ymin = yminZone6_TC1
            End If
            If yminZone6_TC3 < ymin Then
                ymin = yminZone6_TC3
            End If
            If yminZone7_TC1 < ymin Then
                ymin = yminZone7_TC1
            End If
            If yminZone7_TC3 < ymin Then
                ymin = yminZone7_TC3
            End If
            If yminZone8_TC1 < ymin Then
                ymin = yminZone8_TC1
            End If
            If yminZone8_TC3 < ymin Then
                ymin = yminZone8_TC3
            End If
            If yminZone9_TC2 < ymin Then
                ymin = yminZone9_TC2
            End If


            'Dim LegenDesc As String = "Furnace-" & Session("Furnace") & " " & Session("Zone") & " " & Session("TC")

            ''------------------------------ Arranged Color Codes -----------------------------------------
            ''Red:#FF0000;Lime Green:#00FF00;Green:#008000;Navy blue:#000080;Black:#000000
            ''Magenta:#FF00FF;Brown:#A52A2A;Olive:#808000;Maroon:#800000;Teal:#008080
            ''Purple:#800080;Blue Gray:#98AFC7;DodgerBlue (W3C):#1E90FF;Deep Teal:#033E3E;SeaGreen (W3C):#2E8B57	
            ''Jade:#00A36C;Venom Green:#728C00;Pine Green:#387C44;Deep Yellow:#F6BE00;Copper:#B87333	
            ''Wood:#966F33;Antique Bronze:#665D1E;Taupe:#483C32;Milk Chocolate:#513B1C;Mahogany:#C04000	
            ''Tomato Sauce Red: #B21807;Orchid Purple:#B048B5;Bright Grape:#6F2DA8;Red Blood:#660000	
            ''#F39C12;#FF5733;#2E86C1

            s.Append("<script>")
            's.Append("var myChart = echarts.init(document.getElementById('main'));")
            s.Append("var myChart = echarts.init(document.getElementById('main'), null, {")
            s.Append("width:1200,")
            s.Append("height:500")
            s.Append("});")
            's.Append("const colors = ['#5470C6', '#91CC75', '#EE6666'];")
            's.Append("const colors = ['#5470C6'];")
            s.Append("const colors = ['#FF0000', '#008000', '#000080','#000000','#FF00FF','#A52A2A','#808000','#800000','#008080','#800080','#98AFC7','#513B1C','#B87333','#966F33','#665D1E'];")
            s.Append("option = {")
            s.Append("color: colors,")
            s.Append("tooltip:")
            s.Append("{")
            s.Append("trigger: 'axis',")
            s.Append("axisPointer:")
            s.Append("{")
            s.Append("type: 'cross'")
            s.Append("}")
            s.Append("},")
            s.Append("grid:")
            s.Append("{")
            's.Append("right: '20%',")
            s.Append("right: '5%',")
            s.Append("bottom: '30%'")
            's.Append("bottom: '20%'")
            s.Append("},")
            s.Append("toolbox:")
            s.Append("{")
            s.Append("feature:")
            s.Append("{")
            s.Append("dataView: { show: true, readOnly: false },")
            s.Append("restore: { show: true },")
            s.Append("saveAsImage: { show: true }")
            s.Append("}")
            s.Append("},")
            s.Append("legend:")
            s.Append("{")
            's.Append("data:['TC Temp']")
            s.Append("data:[" & LegenDesc & "],")
            s.Append("orient:'horizontal',")
            's.Append("right:10,")
            s.Append("bottom:'0%',")
            's.Append("top:'bottom',")
            's.Append("type:'scroll'")
            s.Append("},")
            s.Append("xAxis:")
            s.Append("[")
            s.Append("{")
            s.Append("type: 'category',")
            s.Append("axisTick:")
            s.Append("{")
            s.Append("alignWithLabel: true")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            s.Append("show: true,")
            s.Append("rotate: 45")
            s.Append("},")
            s.Append("data:[" & date_val & "]")
            s.Append("}")
            s.Append("],")
            s.Append("yAxis:")
            s.Append("[")
            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("name: " & LegendDescSeries(0) & ",")
            s.Append("name: 'Temp. Range',")
            s.Append("min: " & ymin & ",")
            s.Append("max: " & ymax & ",")
            s.Append("position: 'left',")
            s.Append("axisLine:")
            s.Append("{")
            s.Append("show: true,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[0]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            s.Append("formatter: '{value} '")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[1]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[2]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[3]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[4]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[5]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[6]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[7]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[8]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[9]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[10]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[11]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[12]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[13]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[14]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("],")
            s.Append("series:")
            s.Append("[")
            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(0) & ",")
            s.Append("type: 'line',")
            s.Append("data:[")
            s.Append(dataZ1_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(1) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 1,")
            s.Append("data:[")
            s.Append(dataZ2_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(2) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 2,")
            s.Append("data:[")
            s.Append(dataZ2_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(3) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 3,")
            s.Append("data:[")
            s.Append(dataZ3_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(4) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 4,")
            s.Append("data:[")
            s.Append(dataZ4_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(5) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 5,")
            s.Append("data:[")
            s.Append(dataZ4_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(6) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 6,")
            s.Append("data:[")
            s.Append(dataZ5_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(7) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 7,")
            s.Append("data:[")
            s.Append(dataZ5_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(8) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 8,")
            s.Append("data:[")
            s.Append(dataZ6_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(9) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 9,")
            s.Append("data:[")
            s.Append(dataZ6_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(10) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 10,")
            s.Append("data:[")
            s.Append(dataZ7_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(11) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 11,")
            s.Append("data:[")
            s.Append(dataZ7_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(12) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 12,")
            s.Append("data:[")
            s.Append(dataZ8_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(13) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 13,")
            s.Append("data:[")
            s.Append(dataZ8_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(14) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 14,")
            s.Append("data:[")
            s.Append(dataZ9_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("]")
            s.Append("};")
            s.Append("myChart.setOption(option);")
            s.Append("</script>")
            Literal1.Text = s.ToString()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Protected Sub GenerateHistoryChartLineABS(Furnace As String, Column As String, strtDate As String, enDate As String, FurnaceZone As String)
        Try
            Dim sqlQuery As String
            Dim LegenDesc As String
            Dim s As StringBuilder = New StringBuilder()
            Literal1.Text = Nothing
            Dim ColumnName() As String = Column.Split(",")
            Dim ModifyColumn As String
            For i As Integer = 0 To ColumnName.Length - 1
                If i = ColumnName.Length - 1 Then
                    ModifyColumn &= "Cast(" & ColumnName(i) & " As Integer) As " & ColumnName(i) & " "
                Else
                    ModifyColumn &= "Cast(" & ColumnName(i) & " As Integer) As " & ColumnName(i) & ", "
                End If
            Next

            sqlQuery = "Select FORMAT(TIMESTAMP,'dd-MM-yyyy HH:mm:ss') As TIMESTAMP,LINE, " & ModifyColumn & " From [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ZONE_TEMP] Where LINE = '" & Furnace & "'"
            sqlQuery &= " AND TIMESTAMP BETWEEN '" & strtDate & "' AND '" & enDate & "' Order By TIMESTAMP ASC"

            Dim ds As DataSet = objdatahandler.GetDataSetFromQuery(sqlQuery)
            Dim dt As DataTable = ds.Tables(0)

            Dim dataZ1_TC1 As String = Nothing
            Dim dataZ1_TC3 As String = Nothing
            Dim dataZ2_TC2 As String = Nothing
            Dim dataZ3_TC1 As String = Nothing
            Dim dataZ3_TC3 As String = Nothing
            Dim dataZ4_TC2 As String = Nothing
            Dim dataZ5_TC2 As String = Nothing
            Dim dataZ6_TC2 As String = Nothing
            Dim dataZ7_TC2 As String = Nothing
            Dim dataZ8_TC2 As String = Nothing
            Dim dataZ9_TC1 As String = Nothing
            Dim dataZ9_TC3 As String = Nothing

            Dim dataZ1_TC2 As String = Nothing
            Dim dataZ2_TC1 As String = Nothing
            Dim dataZ2_TC3 As String = Nothing
            Dim dataZ3_TC2 As String = Nothing
            Dim dataZ4_TC1 As String = Nothing
            Dim dataZ4_TC3 As String = Nothing
            Dim dataZ5_TC1 As String = Nothing
            Dim dataZ5_TC3 As String = Nothing
            Dim dataZ6_TC1 As String = Nothing
            Dim dataZ6_TC3 As String = Nothing
            Dim dataZ7_TC1 As String = Nothing
            Dim dataZ7_TC3 As String = Nothing
            Dim dataZ8_TC1 As String = Nothing
            Dim dataZ8_TC3 As String = Nothing
            Dim dataZ9_TC2 As String = Nothing

            Dim date_val As String = Nothing
            'If ZoneTC = "Avg" Then
            '    Column = "AvgTemp"
            '    'LegenDesc = "Furnace-" & Session("Furnace") & " " & Session("Zone") & " Average Temperature"
            '    LegenDesc = "Furnace-" & Line & " " & FurnaceZone & " Average Temperature"
            'Else
            '    'LegenDesc = "Furnace-" & Session("Furnace") & " " & Session("Zone") & " " & Session("TC") & " Temperature"
            '    LegenDesc = "Furnace-" & Line & " " & FurnaceZone & " " & ZoneTC & " Temperature"
            'End If

            LegenDesc = "'Zone1_TC1','Zone1_TC3','Zone2_TC2','Zone3_TC1','Zone3_TC3','Zone4_TC2','Zone5_TC2','Zone6_TC2','Zone7_TC2','Zone8_TC2','Zone9_TC1','Zone9_TC3',"
            LegenDesc &= "'ZONE1_TC2','ZONE2_TC1','ZONE2_TC3','ZONE3_TC2','ZONE4_TC1','ZONE4_TC3','ZONE5_TC1','ZONE5_TC3','ZONE6_TC1','ZONE6_TC3','ZONE7_TC1','ZONE7_TC3','ZONE8_TC1','ZONE8_TC3','ZONE9_TC2'"
            Dim LegendDescSeries() As String = LegenDesc.Split(",")


            For I As Integer = 0 To dt.Rows.Count - 1
                dataZ1_TC1 &= dt(I)("Zone1_TC1") & ","
                dataZ1_TC3 &= dt(I)("Zone1_TC3") & ","
                dataZ2_TC2 &= dt(I)("Zone2_TC2") & ","
                dataZ3_TC1 &= dt(I)("Zone3_TC1") & ","
                dataZ3_TC3 &= dt(I)("Zone3_TC3") & ","
                dataZ4_TC2 &= dt(I)("Zone4_TC2") & ","
                dataZ5_TC2 &= dt(I)("Zone5_TC2") & ","
                dataZ6_TC2 &= dt(I)("Zone6_TC2") & ","
                dataZ7_TC2 &= dt(I)("Zone7_TC2") & ","
                dataZ8_TC2 &= dt(I)("Zone8_TC2") & ","
                dataZ9_TC1 &= dt(I)("Zone9_TC1") & ","
                dataZ9_TC3 &= dt(I)("Zone9_TC3") & ","

                dataZ1_TC2 &= dt(I)("Zone1_TC2") & ","
                dataZ2_TC1 &= dt(I)("Zone2_TC1") & ","
                dataZ2_TC3 &= dt(I)("Zone2_TC3") & ","
                dataZ3_TC2 &= dt(I)("Zone3_TC2") & ","
                dataZ4_TC1 &= dt(I)("Zone4_TC1") & ","
                dataZ4_TC3 &= dt(I)("Zone4_TC3") & ","
                dataZ5_TC1 &= dt(I)("Zone5_TC1") & ","
                dataZ5_TC3 &= dt(I)("Zone5_TC3") & ","
                dataZ6_TC1 &= dt(I)("Zone6_TC1") & ","
                dataZ6_TC3 &= dt(I)("Zone6_TC3") & ","
                dataZ7_TC1 &= dt(I)("Zone7_TC1") & ","
                dataZ7_TC3 &= dt(I)("Zone7_TC3") & ","
                dataZ8_TC1 &= dt(I)("Zone8_TC1") & ","
                dataZ8_TC3 &= dt(I)("Zone8_TC3") & ","
                dataZ9_TC2 &= dt(I)("Zone9_TC2") & ","

                date_val &= "'" & dt(I)("TIMESTAMP") & "',"
            Next

            'Dim ymin As Double = Convert.ToDouble(dt.Compute("min(" & Column & ")", "")) - 100
            'Dim ymax As Double = Convert.ToDouble(dt.Compute("max(" & Column & ")", "")) + 100

            Dim ymin As Double = 0.0
            Dim ymax As Double = 0.0

            Dim yminZone1_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone1_TC1)", "")) - 100
            Dim yminZone1_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone1_TC3)", "")) - 100
            Dim yminZone2_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone2_TC2)", "")) - 100
            Dim yminZone3_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone3_TC1)", "")) - 100
            Dim yminZone3_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone3_TC3)", "")) - 100
            Dim yminZone4_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone4_TC2)", "")) - 100
            Dim yminZone5_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone5_TC2)", "")) - 100
            Dim yminZone6_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone6_TC2)", "")) - 100
            Dim yminZone7_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone7_TC2)", "")) - 100
            Dim yminZone8_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone8_TC2)", "")) - 100
            Dim yminZone9_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone9_TC1)", "")) - 100
            Dim yminZone9_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone9_TC3)", "")) - 100

            Dim ymaxZone1_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone1_TC1)", "")) + 100
            Dim ymaxZone1_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone1_TC3)", "")) + 100
            Dim ymaxZone2_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone2_TC2)", "")) + 100
            Dim ymaxZone3_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone3_TC1)", "")) + 100
            Dim ymaxZone3_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone3_TC3)", "")) + 100
            Dim ymaxZone4_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone4_TC2)", "")) + 100
            Dim ymaxZone5_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone5_TC2)", "")) + 100
            Dim ymaxZone6_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone6_TC2)", "")) + 100
            Dim ymaxZone7_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone7_TC2)", "")) + 100
            Dim ymaxZone8_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone8_TC2)", "")) + 100
            Dim ymaxZone9_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone9_TC1)", "")) + 100
            Dim ymaxZone9_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone9_TC3)", "")) + 100

            Dim yminZone1_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone1_TC2)", "")) - 100
            Dim yminZone2_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone2_TC1)", "")) - 100
            Dim yminZone2_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone2_TC3)", "")) - 100
            Dim yminZone3_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone3_TC2)", "")) - 100
            Dim yminZone4_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone4_TC1)", "")) - 100
            Dim yminZone4_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone4_TC3)", "")) - 100
            Dim yminZone5_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone5_TC1)", "")) - 100
            Dim yminZone5_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone5_TC3)", "")) - 100
            Dim yminZone6_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone6_TC1)", "")) - 100
            Dim yminZone6_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone6_TC3)", "")) - 100
            Dim yminZone7_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone7_TC1)", "")) - 100
            Dim yminZone7_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone7_TC3)", "")) - 100
            Dim yminZone8_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone8_TC1)", "")) - 100
            Dim yminZone8_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone8_TC3)", "")) - 100
            Dim yminZone9_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone9_TC2)", "")) - 100

            Dim ymaxZone1_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone1_TC2)", "")) + 100
            Dim ymaxZone2_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone2_TC1)", "")) + 100
            Dim ymaxZone2_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone2_TC3)", "")) + 100
            Dim ymaxZone3_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone3_TC2)", "")) + 100
            Dim ymaxZone4_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone4_TC1)", "")) + 100
            Dim ymaxZone4_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone4_TC3)", "")) + 100
            Dim ymaxZone5_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone5_TC1)", "")) + 100
            Dim ymaxZone5_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone5_TC3)", "")) + 100
            Dim ymaxZone6_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone6_TC1)", "")) + 100
            Dim ymaxZone6_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone6_TC3)", "")) + 100
            Dim ymaxZone7_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone7_TC1)", "")) + 100
            Dim ymaxZone7_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone7_TC3)", "")) + 100
            Dim ymaxZone8_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone8_TC1)", "")) + 100
            Dim ymaxZone8_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone8_TC3)", "")) + 100
            Dim ymaxZone9_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone9_TC2)", "")) + 100

            ymax = ymaxZone1_TC2

            If ymaxZone1_TC2 > ymax Then
                ymax = ymaxZone1_TC2
            End If
            If ymaxZone2_TC1 > ymax Then
                ymax = ymaxZone2_TC1
            End If
            If ymaxZone2_TC3 > ymax Then
                ymax = ymaxZone2_TC3
            End If
            If ymaxZone3_TC2 > ymax Then
                ymax = ymaxZone3_TC2
            End If
            If ymaxZone4_TC1 > ymax Then
                ymax = ymaxZone4_TC1
            End If
            If ymaxZone4_TC3 > ymax Then
                ymax = ymaxZone4_TC3
            End If
            If ymaxZone5_TC1 > ymax Then
                ymax = ymaxZone5_TC1
            End If
            If ymaxZone5_TC3 > ymax Then
                ymax = ymaxZone5_TC3
            End If
            If ymaxZone6_TC1 > ymax Then
                ymax = ymaxZone6_TC1
            End If
            If ymaxZone6_TC3 > ymax Then
                ymax = ymaxZone6_TC3
            End If
            If ymaxZone7_TC1 > ymax Then
                ymax = ymaxZone7_TC1
            End If
            If ymaxZone7_TC3 > ymax Then
                ymax = ymaxZone7_TC3
            End If
            If ymaxZone8_TC1 > ymax Then
                ymax = ymaxZone8_TC1
            End If
            If ymaxZone8_TC3 > ymax Then
                ymax = ymaxZone8_TC3
            End If
            If ymaxZone9_TC2 > ymax Then
                ymax = ymaxZone9_TC2
            End If


            If ymaxZone1_TC1 > ymax Then
                ymax = ymaxZone1_TC1
            End If
            If ymaxZone1_TC3 > ymax Then
                ymax = ymaxZone1_TC3
            End If
            If ymaxZone2_TC2 > ymax Then
                ymax = ymaxZone2_TC2
            End If
            If ymaxZone3_TC1 > ymax Then
                ymax = ymaxZone3_TC1
            End If
            If ymaxZone3_TC3 > ymax Then
                ymax = ymaxZone3_TC3
            End If
            If ymaxZone4_TC2 > ymax Then
                ymax = ymaxZone4_TC2
            End If
            If ymaxZone5_TC2 > ymax Then
                ymax = ymaxZone5_TC2
            End If
            If ymaxZone6_TC2 > ymax Then
                ymax = ymaxZone6_TC2
            End If
            If ymaxZone7_TC2 > ymax Then
                ymax = ymaxZone7_TC2
            End If
            If ymaxZone8_TC2 > ymax Then
                ymax = ymaxZone8_TC2
            End If
            If ymaxZone9_TC1 > ymax Then
                ymax = ymaxZone9_TC1
            End If
            If ymaxZone9_TC3 > ymax Then
                ymax = ymaxZone9_TC3
            End If


            ymin = yminZone1_TC2

            If yminZone1_TC2 < ymin Then
                ymin = yminZone1_TC2
            End If
            If yminZone2_TC1 < ymin Then
                ymin = yminZone2_TC1
            End If
            If yminZone2_TC3 < ymin Then
                ymin = yminZone2_TC3
            End If
            If yminZone3_TC2 < ymin Then
                ymin = yminZone3_TC2
            End If
            If yminZone4_TC1 < ymin Then
                ymin = yminZone4_TC1
            End If
            If yminZone4_TC3 < ymin Then
                ymin = yminZone4_TC3
            End If
            If yminZone5_TC1 < ymin Then
                ymin = yminZone5_TC1
            End If
            If yminZone5_TC3 < ymin Then
                ymin = yminZone5_TC3
            End If
            If yminZone6_TC1 < ymin Then
                ymin = yminZone6_TC1
            End If
            If yminZone6_TC3 < ymin Then
                ymin = yminZone6_TC3
            End If
            If yminZone7_TC1 < ymin Then
                ymin = yminZone7_TC1
            End If
            If yminZone7_TC3 < ymin Then
                ymin = yminZone7_TC3
            End If
            If yminZone8_TC1 < ymin Then
                ymin = yminZone8_TC1
            End If
            If yminZone8_TC3 < ymin Then
                ymin = yminZone8_TC3
            End If
            If yminZone9_TC2 < ymin Then
                ymin = yminZone9_TC2
            End If


            If yminZone1_TC1 < ymin Then
                ymin = yminZone1_TC1
            End If
            If yminZone1_TC3 < ymin Then
                ymin = yminZone1_TC3
            End If
            If yminZone2_TC2 < ymin Then
                ymin = yminZone2_TC2
            End If
            If yminZone3_TC1 < ymin Then
                ymin = yminZone3_TC1
            End If
            If yminZone3_TC3 < ymin Then
                ymin = yminZone3_TC3
            End If
            If yminZone4_TC2 < ymin Then
                ymin = yminZone4_TC2
            End If
            If yminZone5_TC2 < ymin Then
                ymin = yminZone5_TC2
            End If
            If yminZone6_TC2 < ymin Then
                ymin = yminZone6_TC2
            End If
            If yminZone7_TC2 < ymin Then
                ymin = yminZone7_TC2
            End If
            If yminZone8_TC2 < ymin Then
                ymin = yminZone8_TC2
            End If
            If yminZone9_TC1 < ymin Then
                ymin = yminZone9_TC1
            End If
            If yminZone9_TC3 < ymin Then
                ymin = yminZone9_TC3
            End If


            'Dim LegenDesc As String = "Furnace-" & Session("Furnace") & " " & Session("Zone") & " " & Session("TC")

            ''------------------------------ Arranged Color Codes -----------------------------------------
            ''Red:#FF0000;Lime Green:#00FF00;Green:#008000;Navy blue:#000080;Black:#000000
            ''Magenta:#FF00FF;Brown:#A52A2A;Olive:#808000;Maroon:#800000;Teal:#008080
            ''Purple:#800080;Blue Gray:#98AFC7;DodgerBlue (W3C):#1E90FF;Deep Teal:#033E3E;SeaGreen (W3C):#2E8B57	
            ''Jade:#00A36C;Venom Green:#728C00;Pine Green:#387C44;Deep Yellow:#F6BE00;Copper:#B87333	
            ''Wood:#966F33;Antique Bronze:#665D1E;Taupe:#483C32;Milk Chocolate:#513B1C;Mahogany:#C04000	
            ''Tomato Sauce Red: #B21807;Orchid Purple:#B048B5;Bright Grape:#6F2DA8;Red Blood:#660000	
            ''#F39C12;#FF5733;#2E86C1

            s.Append("<script>")
            's.Append("var myChart = echarts.init(document.getElementById('main'));")
            s.Append("var myChart = echarts.init(document.getElementById('main'), null, {")
            s.Append("width:1200,")
            s.Append("height:600")
            s.Append("});")
            's.Append("const colors = ['#5470C6', '#91CC75', '#EE6666'];")
            's.Append("const colors = ['#5470C6'];")
            s.Append("const colors = ['#FF0000','#00FF00', '#008000', '#000080','#000000','#FF00FF','#A52A2A','#808000','#800000','#008080','#800080','#98AFC7','#1E90FF',")
            s.Append("'#033E3E','#2E8B57','#00A36C','#728C00','#387C44','#F6BE00','#B87333','#966F33','#665D1E','#483C32','#513B1C','#C04000','#B048B5','#6F2DA8'];")
            s.Append("option = {")
            s.Append("color: colors,")
            s.Append("tooltip:")
            s.Append("{")
            s.Append("trigger: 'axis',")
            s.Append("axisPointer:")
            s.Append("{")
            s.Append("type: 'cross'")
            s.Append("}")
            s.Append("},")
            s.Append("grid:")
            s.Append("{")
            's.Append("right: '20%',")
            s.Append("right: '5%',")
            s.Append("bottom: '30%'")
            's.Append("bottom: '20%'")
            s.Append("},")
            s.Append("toolbox:")
            s.Append("{")
            s.Append("feature:")
            s.Append("{")
            s.Append("dataView: { show: true, readOnly: false },")
            s.Append("restore: { show: true },")
            s.Append("saveAsImage: { show: true }")
            s.Append("}")
            s.Append("},")
            s.Append("legend:")
            s.Append("{")
            's.Append("data:['TC Temp']")
            s.Append("data:[" & LegenDesc & "],")
            s.Append("orient:'horizontal',")
            's.Append("right:10,")
            s.Append("bottom:'0%',")
            's.Append("top:'bottom',")
            's.Append("type:'scroll'")
            s.Append("},")
            s.Append("xAxis:")
            s.Append("[")
            s.Append("{")
            s.Append("type: 'category',")
            s.Append("axisTick:")
            s.Append("{")
            s.Append("alignWithLabel: true")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            s.Append("show: true,")
            s.Append("rotate: 45")
            s.Append("},")
            s.Append("data:[" & date_val & "]")
            s.Append("}")
            s.Append("],")
            s.Append("yAxis:")
            s.Append("[")
            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("name: " & LegendDescSeries(0) & ",")
            s.Append("name: 'Temp. Range',")
            s.Append("min: " & ymin & ",")
            s.Append("max: " & ymax & ",")
            s.Append("position: 'left',")
            s.Append("axisLine:")
            s.Append("{")
            s.Append("show: true,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[0]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            s.Append("formatter: '{value} '")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[1]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[2]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[3]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[4]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[5]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[6]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[7]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[8]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[9]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[10]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[11]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[12]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[13]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[14]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[15]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[16]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[17]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[18]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[19]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[20]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[21]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[22]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[23]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[24]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[25]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[26]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("],")
            s.Append("series:")
            s.Append("[")
            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(0) & ",")
            s.Append("type: 'line',")
            s.Append("data:[")
            s.Append(dataZ1_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(1) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 1,")
            s.Append("data:[")
            s.Append(dataZ1_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(2) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 2,")
            s.Append("data:[")
            s.Append(dataZ2_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(3) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 3,")
            s.Append("data:[")
            s.Append(dataZ3_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(4) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 4,")
            s.Append("data:[")
            s.Append(dataZ3_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(5) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 5,")
            s.Append("data:[")
            s.Append(dataZ4_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(6) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 6,")
            s.Append("data:[")
            s.Append(dataZ5_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(7) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 7,")
            s.Append("data:[")
            s.Append(dataZ6_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(8) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 8,")
            s.Append("data:[")
            s.Append(dataZ7_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(9) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 9,")
            s.Append("data:[")
            s.Append(dataZ8_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(10) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 10,")
            s.Append("data:[")
            s.Append(dataZ9_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(11) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 11,")
            s.Append("data:[")
            s.Append(dataZ9_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(12) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 12,")
            s.Append("data:[")
            s.Append(dataZ1_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(13) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 13,")
            s.Append("data:[")
            s.Append(dataZ2_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(14) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 14,")
            s.Append("data:[")
            s.Append(dataZ2_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(15) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 15,")
            s.Append("data:[")
            s.Append(dataZ3_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(16) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 16,")
            s.Append("data:[")
            s.Append(dataZ4_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(17) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 17,")
            s.Append("data:[")
            s.Append(dataZ4_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(18) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 18,")
            s.Append("data:[")
            s.Append(dataZ5_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(19) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 19,")
            s.Append("data:[")
            s.Append(dataZ5_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(20) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 20,")
            s.Append("data:[")
            s.Append(dataZ6_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(21) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 21,")
            s.Append("data:[")
            s.Append(dataZ6_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(22) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 22,")
            s.Append("data:[")
            s.Append(dataZ7_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(23) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 23,")
            s.Append("data:[")
            s.Append(dataZ7_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(24) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 24,")
            s.Append("data:[")
            s.Append(dataZ8_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(25) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 25,")
            s.Append("data:[")
            s.Append(dataZ8_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(26) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 26,")
            s.Append("data:[")
            s.Append(dataZ9_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("]")
            s.Append("};")
            s.Append("myChart.setOption(option);")
            s.Append("</script>")
            Literal1.Text = s.ToString()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Protected Sub GenerateHistoryChartLineBDS(Furnace As String, Column As String, strtDate As String, enDate As String, FurnaceZone As String)
        Try
            Dim sqlQuery As String
            Dim LegenDesc As String
            Dim s As StringBuilder = New StringBuilder()
            Literal1.Text = Nothing
            Dim ColumnName() As String = Column.Split(",")
            Dim ModifyColumn As String
            For i As Integer = 0 To ColumnName.Length - 1
                If i = ColumnName.Length - 1 Then
                    ModifyColumn &= "Cast(" & ColumnName(i) & " As Integer) As " & ColumnName(i) & " "
                Else
                    ModifyColumn &= "Cast(" & ColumnName(i) & " As Integer) As " & ColumnName(i) & ", "
                End If
            Next
            ' Cast(" & ColumnName(i) & " As Integer)

            ''If ZoneTC = "Avg" Then

            ''    sqlQuery = "Select TIMESTAMP,LINE, Cast(" & Column & " As Integer) As AvgTemp From [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ZONE_TEMP] Where LINE = '" & Furnace & "'"
            ''    sqlQuery &= " AND TIMESTAMP BETWEEN '" & strtDate & "' AND '" & enDate & "' Order By TIMESTAMP ASC"

            ''    'sqlQuery = "Select TIMESTAMP,LINE, Cast(" & Column & " As Integer) As AvgTemp From [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ZONE_TEMP] Where LINE = '" & Furnace & "'"
            ''    'sqlQuery &= " AND TIMESTAMP BETWEEN '2022-03-20 10:00' AND '2022-03-20 11:00' Order By TIMESTAMP ASC"

            ''Else

            ''    sqlQuery = "Select TIMESTAMP,LINE, Cast(" & Column & " As Integer) As " & Column & " From [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ZONE_TEMP] Where LINE = '" & Furnace & "'"
            ''    sqlQuery &= " AND TIMESTAMP BETWEEN '" & strtDate & "' AND '" & enDate & "' Order By TIMESTAMP ASC"

            ''    'sqlQuery = "Select TIMESTAMP,LINE, Cast(" & Column & " As Integer) As " & Column & " From [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ZONE_TEMP] Where LINE = '" & Furnace & "'"
            ''    'sqlQuery &= " AND TIMESTAMP BETWEEN '2022-03-20 10:00' AND '2022-03-20 11:00' Order By TIMESTAMP ASC"
            ''End If

            'sqlQuery = "Select TIMESTAMP,LINE, Cast(" & Column & " As Integer) From [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ZONE_TEMP] Where LINE = '" & Furnace & "'"
            'sqlQuery &= " AND TIMESTAMP BETWEEN '" & strtDate & "' AND '" & enDate & "' Order By TIMESTAMP ASC"

            sqlQuery = "Select FORMAT(TIMESTAMP,'dd-MM-yyyy HH:mm:ss') As TIMESTAMP,LINE, " & ModifyColumn & " From [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ZONE_TEMP] Where LINE = '" & Furnace & "'"
            sqlQuery &= " AND TIMESTAMP BETWEEN '" & strtDate & "' AND '" & enDate & "' Order By TIMESTAMP ASC"

            Dim ds As DataSet = objdatahandler.GetDataSetFromQuery(sqlQuery)
            Dim dt As DataTable = ds.Tables(0)

            Dim dataZ1_TC1 As String = Nothing
            Dim dataZ1_TC3 As String = Nothing
            Dim dataZ2_TC2 As String = Nothing
            Dim dataZ3_TC1 As String = Nothing
            Dim dataZ3_TC3 As String = Nothing
            Dim dataZ4_TC2 As String = Nothing
            Dim dataZ5_TC1 As String = Nothing
            Dim dataZ5_TC3 As String = Nothing
            Dim dataZ6_TC2 As String = Nothing
            Dim dataZ7_TC2 As String = Nothing
            Dim dataZ8_TC2 As String = Nothing

            Dim date_val As String = Nothing
            'If ZoneTC = "Avg" Then
            '    Column = "AvgTemp"
            '    'LegenDesc = "Furnace-" & Session("Furnace") & " " & Session("Zone") & " Average Temperature"
            '    LegenDesc = "Furnace-" & Line & " " & FurnaceZone & " Average Temperature"
            'Else
            '    'LegenDesc = "Furnace-" & Session("Furnace") & " " & Session("Zone") & " " & Session("TC") & " Temperature"
            '    LegenDesc = "Furnace-" & Line & " " & FurnaceZone & " " & ZoneTC & " Temperature"
            'End If
            LegenDesc = "'ZONE1_TC1','ZONE1_TC3','ZONE2_TC2','ZONE3_TC1','ZONE3_TC3','ZONE4_TC2','ZONE5_TC1','ZONE5_TC3','ZONE6_TC2','ZONE7_TC2','ZONE8_TC2'"
            Dim LegendDescSeries() As String = LegenDesc.Split(",")


            For I As Integer = 0 To dt.Rows.Count - 1
                dataZ1_TC1 &= dt(I)("Zone1_TC1") & ","
                dataZ1_TC3 &= dt(I)("Zone1_TC3") & ","
                dataZ2_TC2 &= dt(I)("Zone2_TC2") & ","
                dataZ3_TC1 &= dt(I)("Zone3_TC1") & ","
                dataZ3_TC3 &= dt(I)("Zone3_TC3") & ","
                dataZ4_TC2 &= dt(I)("Zone4_TC2") & ","
                dataZ5_TC1 &= dt(I)("Zone5_TC1") & ","
                dataZ5_TC3 &= dt(I)("Zone5_TC3") & ","
                dataZ6_TC2 &= dt(I)("Zone6_TC2") & ","
                dataZ7_TC2 &= dt(I)("Zone7_TC2") & ","
                dataZ8_TC2 &= dt(I)("Zone8_TC2") & ","

                date_val &= "'" & dt(I)("TIMESTAMP") & "',"
            Next

            'Dim ymin As Double = Convert.ToDouble(dt.Compute("min(" & Column & ")", "")) - 100
            'Dim ymax As Double = Convert.ToDouble(dt.Compute("max(" & Column & ")", "")) + 100

            Dim ymin As Double = 0.0
            Dim ymax As Double = 0.0

            Dim yminZone1_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone1_TC1)", "")) - 100
            Dim yminZone1_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone1_TC3)", "")) - 100
            Dim yminZone2_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone2_TC2)", "")) - 100
            Dim yminZone3_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone3_TC1)", "")) - 100
            Dim yminZone3_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone3_TC3)", "")) - 100
            Dim yminZone4_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone4_TC2)", "")) - 100
            Dim yminZone5_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone5_TC1)", "")) - 100
            Dim yminZone5_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone5_TC3)", "")) - 100
            Dim yminZone6_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone6_TC2)", "")) - 100
            Dim yminZone7_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone7_TC2)", "")) - 100
            Dim yminZone8_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone8_TC2)", "")) - 100


            Dim ymaxZone1_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone1_TC1)", "")) + 100
            Dim ymaxZone1_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone1_TC3)", "")) + 100
            Dim ymaxZone2_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone2_TC2)", "")) + 100
            Dim ymaxZone3_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone3_TC1)", "")) + 100
            Dim ymaxZone3_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone3_TC3)", "")) + 100
            Dim ymaxZone4_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone4_TC2)", "")) + 100
            Dim ymaxZone5_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone5_TC1)", "")) + 100
            Dim ymaxZone5_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone5_TC3)", "")) + 100
            Dim ymaxZone6_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone6_TC2)", "")) + 100
            Dim ymaxZone7_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone7_TC2)", "")) + 100
            Dim ymaxZone8_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone8_TC2)", "")) + 100


            ymax = ymaxZone1_TC1

            If ymaxZone1_TC1 > ymax Then
                ymax = ymaxZone1_TC1
            End If
            If ymaxZone1_TC3 > ymax Then
                ymax = ymaxZone1_TC3
            End If
            If ymaxZone2_TC2 > ymax Then
                ymax = ymaxZone2_TC2
            End If
            If ymaxZone3_TC1 > ymax Then
                ymax = ymaxZone3_TC1
            End If
            If ymaxZone3_TC3 > ymax Then
                ymax = ymaxZone3_TC3
            End If
            If ymaxZone4_TC2 > ymax Then
                ymax = ymaxZone4_TC2
            End If
            If ymaxZone5_TC1 > ymax Then
                ymax = ymaxZone5_TC1
            End If
            If ymaxZone5_TC3 > ymax Then
                ymax = ymaxZone5_TC3
            End If
            If ymaxZone6_TC2 > ymax Then
                ymax = ymaxZone6_TC2
            End If
            If ymaxZone7_TC2 > ymax Then
                ymax = ymaxZone7_TC2
            End If
            If ymaxZone8_TC2 > ymax Then
                ymax = ymaxZone8_TC2
            End If

            ymin = yminZone1_TC1

            If yminZone1_TC1 < ymin Then
                ymin = yminZone1_TC1
            End If
            If yminZone1_TC3 < ymin Then
                ymin = yminZone1_TC3
            End If
            If yminZone2_TC2 < ymin Then
                ymin = yminZone2_TC2
            End If
            If yminZone3_TC1 < ymin Then
                ymin = yminZone3_TC1
            End If
            If yminZone3_TC3 < ymin Then
                ymin = yminZone3_TC3
            End If
            If yminZone4_TC2 < ymin Then
                ymin = yminZone4_TC2
            End If
            If yminZone5_TC1 < ymin Then
                ymin = yminZone5_TC1
            End If
            If yminZone5_TC3 < ymin Then
                ymin = yminZone5_TC3
            End If
            If yminZone6_TC2 < ymin Then
                ymin = yminZone6_TC2
            End If
            If yminZone7_TC2 < ymin Then
                ymin = yminZone7_TC2
            End If
            If yminZone8_TC2 < ymin Then
                ymin = yminZone8_TC2
            End If

            'Dim LegenDesc As String = "Furnace-" & Session("Furnace") & " " & Session("Zone") & " " & Session("TC")

            ''------------------------------ Arranged Color Codes -----------------------------------------
            ''Red:#FF0000;Lime Green:#00FF00;Green:#008000;Navy blue:#000080;Black:#000000
            ''Magenta:#FF00FF;Brown:#A52A2A;Olive:#808000;Maroon:#800000;Teal:#008080
            ''Purple:#800080;Blue Gray:#98AFC7;DodgerBlue (W3C):#1E90FF;Deep Teal:#033E3E;SeaGreen (W3C):#2E8B57	
            ''Jade:#00A36C;Venom Green:#728C00;Pine Green:#387C44;Deep Yellow:#F6BE00;Copper:#B87333	
            ''Wood:#966F33;Antique Bronze:#665D1E;Taupe:#483C32;Milk Chocolate:#513B1C;Mahogany:#C04000	
            ''Tomato Sauce Red: #B21807;Orchid Purple:#B048B5;Bright Grape:#6F2DA8;Red Blood:#660000	
            ''#F39C12;#FF5733;#2E86C1

            s.Append("<script>")
            's.Append("var myChart = echarts.init(document.getElementById('main'));")
            s.Append("var myChart = echarts.init(document.getElementById('main'), null, {")
            s.Append("width:1200,")
            s.Append("height:500")
            s.Append("});")
            's.Append("const colors = ['#5470C6', '#91CC75', '#EE6666'];")
            's.Append("const colors = ['#5470C6'];")
            s.Append("const colors = ['#FF0000', '#008000', '#000080','#000000','#FF00FF','#A52A2A','#808000','#800000','#008080','#800080','#98AFC7'];")
            s.Append("option = {")
            s.Append("color: colors,")
            s.Append("tooltip:")
            s.Append("{")
            s.Append("trigger: 'axis',")
            s.Append("axisPointer:")
            s.Append("{")
            s.Append("type: 'cross'")
            s.Append("}")
            s.Append("},")
            s.Append("grid:")
            s.Append("{")
            's.Append("right: '20%',")
            s.Append("right: '5%',")
            s.Append("bottom: '30%'")
            's.Append("bottom: '20%'")
            s.Append("},")
            s.Append("toolbox:")
            s.Append("{")
            s.Append("feature:")
            s.Append("{")
            s.Append("dataView: { show: true, readOnly: false },")
            s.Append("restore: { show: true },")
            s.Append("saveAsImage: { show: true }")
            s.Append("}")
            s.Append("},")
            s.Append("legend:")
            s.Append("{")
            's.Append("data:['TC Temp']")
            s.Append("data:[" & LegenDesc & "],")
            s.Append("orient:'horizontal',")
            's.Append("right:10,")
            s.Append("bottom:'0%',")
            's.Append("top:'bottom',")
            's.Append("type:'scroll'")
            s.Append("},")
            s.Append("xAxis:")
            s.Append("[")
            s.Append("{")
            s.Append("type: 'category',")
            s.Append("axisTick:")
            s.Append("{")
            s.Append("alignWithLabel: true")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            s.Append("show: true,")
            s.Append("rotate: 45")
            s.Append("},")
            s.Append("data:[" & date_val & "]")
            s.Append("}")
            s.Append("],")
            s.Append("yAxis:")
            s.Append("[")
            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("name: " & LegendDescSeries(0) & ",")
            s.Append("name: 'Temp. Range',")
            s.Append("min: " & ymin & ",")
            s.Append("max: " & ymax & ",")
            s.Append("position: 'left',")
            s.Append("axisLine:")
            s.Append("{")
            s.Append("show: true,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[0]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            s.Append("formatter: '{value} '")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[1]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[2]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[3]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[4]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[5]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[6]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[7]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[8]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[9]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[10]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[11]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("],")
            s.Append("series:")
            s.Append("[")
            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(0) & ",")
            s.Append("type: 'line',")
            s.Append("data:[")
            s.Append(dataZ1_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(1) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 1,")
            s.Append("data:[")
            s.Append(dataZ1_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(2) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 2,")
            s.Append("data:[")
            s.Append(dataZ2_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(3) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 3,")
            s.Append("data:[")
            s.Append(dataZ3_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(4) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 4,")
            s.Append("data:[")
            s.Append(dataZ3_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(5) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 5,")
            s.Append("data:[")
            s.Append(dataZ4_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(6) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 6,")
            s.Append("data:[")
            s.Append(dataZ5_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(7) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 7,")
            s.Append("data:[")
            s.Append(dataZ5_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(8) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 8,")
            s.Append("data:[")
            s.Append(dataZ6_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(9) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 9,")
            s.Append("data:[")
            s.Append(dataZ7_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(10) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 10,")
            s.Append("data:[")
            s.Append(dataZ8_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("]")
            s.Append("};")
            s.Append("myChart.setOption(option);")
            s.Append("</script>")
            Literal1.Text = s.ToString()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Protected Sub GenerateHistoryChartLineBOS(Furnace As String, Column As String, strtDate As String, enDate As String, FurnaceZone As String)
        Try
            Dim sqlQuery As String
            Dim LegenDesc As String
            Dim s As StringBuilder = New StringBuilder()
            Literal1.Text = Nothing
            Dim ColumnName() As String = Column.Split(",")
            Dim ModifyColumn As String
            For i As Integer = 0 To ColumnName.Length - 1
                If i = ColumnName.Length - 1 Then
                    ModifyColumn &= "Cast(" & ColumnName(i) & " As Integer) As " & ColumnName(i) & " "
                Else
                    ModifyColumn &= "Cast(" & ColumnName(i) & " As Integer) As " & ColumnName(i) & ", "
                End If
            Next

            sqlQuery = "Select FORMAT(TIMESTAMP,'dd-MM-yyyy HH:mm:ss') As TIMESTAMP,LINE, " & ModifyColumn & " From [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ZONE_TEMP] Where LINE = '" & Furnace & "'"
            sqlQuery &= " AND TIMESTAMP BETWEEN '" & strtDate & "' AND '" & enDate & "' Order By TIMESTAMP ASC"

            Dim ds As DataSet = objdatahandler.GetDataSetFromQuery(sqlQuery)
            Dim dt As DataTable = ds.Tables(0)
            'ZONE1_TC2,ZONE2_TC1,ZONE2_TC3,ZONE3_TC2,ZONE4_TC1,ZONE4_TC3,ZONE5_TC1,ZONE5_TC3,ZONE6_TC1,ZONE6_TC3,ZONE7_TC1,ZONE7_TC3,ZONE8_TC1,ZONE8_TC3,ZONE9_TC2

            Dim dataZ1_TC2 As String = Nothing
            Dim dataZ2_TC1 As String = Nothing
            Dim dataZ2_TC3 As String = Nothing
            Dim dataZ3_TC2 As String = Nothing
            Dim dataZ4_TC1 As String = Nothing
            Dim dataZ4_TC3 As String = Nothing
            Dim dataZ5_TC2 As String = Nothing
            Dim dataZ6_TC1 As String = Nothing
            Dim dataZ6_TC3 As String = Nothing
            Dim dataZ7_TC1 As String = Nothing
            Dim dataZ7_TC3 As String = Nothing
            Dim dataZ8_TC1 As String = Nothing
            Dim dataZ8_TC3 As String = Nothing

            Dim date_val As String = Nothing
            'If ZoneTC = "Avg" Then
            '    Column = "AvgTemp"
            '    'LegenDesc = "Furnace-" & Session("Furnace") & " " & Session("Zone") & " Average Temperature"
            '    LegenDesc = "Furnace-" & Line & " " & FurnaceZone & " Average Temperature"
            'Else
            '    'LegenDesc = "Furnace-" & Session("Furnace") & " " & Session("Zone") & " " & Session("TC") & " Temperature"
            '    LegenDesc = "Furnace-" & Line & " " & FurnaceZone & " " & ZoneTC & " Temperature"
            'End If
            'LegenDesc = "'Zone1_TC1','Zone1_TC3','Zone2_TC2','Zone3_TC1','Zone3_TC3','Zone4_TC2','Zone5_TC2','Zone6_TC2','Zone7_TC2','Zone8_TC2','Zone9_TC1','Zone9_TC3'"
            LegenDesc = "'ZONE1_TC2','ZONE2_TC1','ZONE2_TC3','ZONE3_TC2','ZONE4_TC1','ZONE4_TC3','ZONE5_TC2','ZONE6_TC1','ZONE6_TC3','ZONE7_TC1','ZONE7_TC3','ZONE8_TC1','ZONE8_TC3'"
            Dim LegendDescSeries() As String = LegenDesc.Split(",")


            For I As Integer = 0 To dt.Rows.Count - 1
                dataZ1_TC2 &= dt(I)("Zone1_TC2") & ","
                dataZ2_TC1 &= dt(I)("Zone2_TC1") & ","
                dataZ2_TC3 &= dt(I)("Zone2_TC3") & ","
                dataZ3_TC2 &= dt(I)("Zone3_TC2") & ","
                dataZ4_TC1 &= dt(I)("Zone4_TC1") & ","
                dataZ4_TC3 &= dt(I)("Zone4_TC3") & ","
                dataZ5_TC2 &= dt(I)("Zone5_TC2") & ","
                dataZ6_TC1 &= dt(I)("Zone6_TC1") & ","
                dataZ6_TC3 &= dt(I)("Zone6_TC3") & ","
                dataZ7_TC1 &= dt(I)("Zone7_TC1") & ","
                dataZ7_TC3 &= dt(I)("Zone7_TC3") & ","
                dataZ8_TC1 &= dt(I)("Zone8_TC1") & ","
                dataZ8_TC3 &= dt(I)("Zone8_TC3") & ","

                date_val &= "'" & dt(I)("TIMESTAMP") & "',"
            Next

            'Dim ymin As Double = Convert.ToDouble(dt.Compute("min(" & Column & ")", "")) - 100
            'Dim ymax As Double = Convert.ToDouble(dt.Compute("max(" & Column & ")", "")) + 100

            Dim ymin As Double = 0.0
            Dim ymax As Double = 0.0

            Dim yminZone1_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone1_TC2)", "")) - 100
            Dim yminZone2_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone2_TC1)", "")) - 100
            Dim yminZone2_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone2_TC3)", "")) - 100
            Dim yminZone3_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone3_TC2)", "")) - 100
            Dim yminZone4_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone4_TC1)", "")) - 100
            Dim yminZone4_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone4_TC3)", "")) - 100
            Dim yminZone5_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone5_TC2)", "")) - 100
            Dim yminZone6_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone6_TC1)", "")) - 100
            Dim yminZone6_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone6_TC3)", "")) - 100
            Dim yminZone7_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone7_TC1)", "")) - 100
            Dim yminZone7_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone7_TC3)", "")) - 100
            Dim yminZone8_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone8_TC1)", "")) - 100
            Dim yminZone8_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone8_TC3)", "")) - 100


            Dim ymaxZone1_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone1_TC2)", "")) + 100
            Dim ymaxZone2_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone2_TC1)", "")) + 100
            Dim ymaxZone2_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone2_TC3)", "")) + 100
            Dim ymaxZone3_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone3_TC2)", "")) + 100
            Dim ymaxZone4_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone4_TC1)", "")) + 100
            Dim ymaxZone4_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone4_TC3)", "")) + 100
            Dim ymaxZone5_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone5_TC2)", "")) + 100
            Dim ymaxZone6_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone6_TC1)", "")) + 100
            Dim ymaxZone6_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone6_TC3)", "")) + 100
            Dim ymaxZone7_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone7_TC1)", "")) + 100
            Dim ymaxZone7_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone7_TC3)", "")) + 100
            Dim ymaxZone8_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone8_TC1)", "")) + 100
            Dim ymaxZone8_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone8_TC3)", "")) + 100


            ymax = ymaxZone1_TC2

            If ymaxZone1_TC2 > ymax Then
                ymax = ymaxZone1_TC2
            End If
            If ymaxZone2_TC1 > ymax Then
                ymax = ymaxZone2_TC1
            End If
            If ymaxZone2_TC3 > ymax Then
                ymax = ymaxZone2_TC3
            End If
            If ymaxZone3_TC2 > ymax Then
                ymax = ymaxZone3_TC2
            End If
            If ymaxZone4_TC1 > ymax Then
                ymax = ymaxZone4_TC1
            End If
            If ymaxZone4_TC3 > ymax Then
                ymax = ymaxZone4_TC3
            End If
            If ymaxZone5_TC2 > ymax Then
                ymax = ymaxZone5_TC2
            End If
            If ymaxZone6_TC1 > ymax Then
                ymax = ymaxZone6_TC1
            End If
            If ymaxZone6_TC3 > ymax Then
                ymax = ymaxZone6_TC3
            End If
            If ymaxZone7_TC1 > ymax Then
                ymax = ymaxZone7_TC1
            End If
            If ymaxZone7_TC3 > ymax Then
                ymax = ymaxZone7_TC3
            End If
            If ymaxZone8_TC1 > ymax Then
                ymax = ymaxZone8_TC1
            End If
            If ymaxZone8_TC3 > ymax Then
                ymax = ymaxZone8_TC3
            End If

            ymin = yminZone1_TC2

            If yminZone1_TC2 < ymin Then
                ymin = yminZone1_TC2
            End If
            If yminZone2_TC1 < ymin Then
                ymin = yminZone2_TC1
            End If
            If yminZone2_TC3 < ymin Then
                ymin = yminZone2_TC3
            End If
            If yminZone3_TC2 < ymin Then
                ymin = yminZone3_TC2
            End If
            If yminZone4_TC1 < ymin Then
                ymin = yminZone4_TC1
            End If
            If yminZone4_TC3 < ymin Then
                ymin = yminZone4_TC3
            End If
            If yminZone5_TC2 < ymin Then
                ymin = yminZone5_TC2
            End If
            If yminZone6_TC1 < ymin Then
                ymin = yminZone6_TC1
            End If
            If yminZone6_TC3 < ymin Then
                ymin = yminZone6_TC3
            End If
            If yminZone7_TC1 < ymin Then
                ymin = yminZone7_TC1
            End If
            If yminZone7_TC3 < ymin Then
                ymin = yminZone7_TC3
            End If
            If yminZone8_TC1 < ymin Then
                ymin = yminZone8_TC1
            End If
            If yminZone8_TC3 < ymin Then
                ymin = yminZone8_TC3
            End If

            'Dim LegenDesc As String = "Furnace-" & Session("Furnace") & " " & Session("Zone") & " " & Session("TC")

            ''------------------------------ Arranged Color Codes -----------------------------------------
            ''Red:#FF0000;Lime Green:#00FF00;Green:#008000;Navy blue:#000080;Black:#000000
            ''Magenta:#FF00FF;Brown:#A52A2A;Olive:#808000;Maroon:#800000;Teal:#008080
            ''Purple:#800080;Blue Gray:#98AFC7;DodgerBlue (W3C):#1E90FF;Deep Teal:#033E3E;SeaGreen (W3C):#2E8B57	
            ''Jade:#00A36C;Venom Green:#728C00;Pine Green:#387C44;Deep Yellow:#F6BE00;Copper:#B87333	
            ''Wood:#966F33;Antique Bronze:#665D1E;Taupe:#483C32;Milk Chocolate:#513B1C;Mahogany:#C04000	
            ''Tomato Sauce Red: #B21807;Orchid Purple:#B048B5;Bright Grape:#6F2DA8;Red Blood:#660000	
            ''#F39C12;#FF5733;#2E86C1

            s.Append("<script>")
            's.Append("var myChart = echarts.init(document.getElementById('main'));")
            s.Append("var myChart = echarts.init(document.getElementById('main'), null, {")
            s.Append("width:1200,")
            s.Append("height:500")
            s.Append("});")
            's.Append("const colors = ['#5470C6', '#91CC75', '#EE6666'];")
            's.Append("const colors = ['#5470C6'];")
            s.Append("const colors = ['#FF0000', '#008000', '#000080','#000000','#FF00FF','#A52A2A','#808000','#800000','#008080','#800080','#98AFC7','#513B1C','#B87333'];")
            s.Append("option = {")
            s.Append("color: colors,")
            s.Append("tooltip:")
            s.Append("{")
            s.Append("trigger: 'axis',")
            s.Append("axisPointer:")
            s.Append("{")
            s.Append("type: 'cross'")
            s.Append("}")
            s.Append("},")
            s.Append("grid:")
            s.Append("{")
            's.Append("right: '20%',")
            s.Append("right: '5%',")
            s.Append("bottom: '30%'")
            's.Append("bottom: '20%'")
            s.Append("},")
            s.Append("toolbox:")
            s.Append("{")
            s.Append("feature:")
            s.Append("{")
            s.Append("dataView: { show: true, readOnly: false },")
            s.Append("restore: { show: true },")
            s.Append("saveAsImage: { show: true }")
            s.Append("}")
            s.Append("},")
            s.Append("legend:")
            s.Append("{")
            's.Append("data:['TC Temp']")
            s.Append("data:[" & LegenDesc & "],")
            s.Append("orient:'horizontal',")
            's.Append("right:10,")
            s.Append("bottom:'0%',")
            's.Append("top:'bottom',")
            's.Append("type:'scroll'")
            s.Append("},")
            s.Append("xAxis:")
            s.Append("[")
            s.Append("{")
            s.Append("type: 'category',")
            s.Append("axisTick:")
            s.Append("{")
            s.Append("alignWithLabel: true")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            s.Append("show: true,")
            s.Append("rotate: 45")
            s.Append("},")
            s.Append("data:[" & date_val & "]")
            s.Append("}")
            s.Append("],")
            s.Append("yAxis:")
            s.Append("[")
            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("name: " & LegendDescSeries(0) & ",")
            s.Append("name: 'Temp. Range',")
            s.Append("min: " & ymin & ",")
            s.Append("max: " & ymax & ",")
            s.Append("position: 'left',")
            s.Append("axisLine:")
            s.Append("{")
            s.Append("show: true,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[0]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            s.Append("formatter: '{value} '")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[1]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[2]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[3]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[4]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[5]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[6]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[7]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[8]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[9]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[10]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[11]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[12]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("],")
            s.Append("series:")
            s.Append("[")
            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(0) & ",")
            s.Append("type: 'line',")
            s.Append("data:[")
            s.Append(dataZ1_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(1) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 1,")
            s.Append("data:[")
            s.Append(dataZ2_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(2) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 2,")
            s.Append("data:[")
            s.Append(dataZ2_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(3) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 3,")
            s.Append("data:[")
            s.Append(dataZ3_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(4) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 4,")
            s.Append("data:[")
            s.Append(dataZ4_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(5) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 5,")
            s.Append("data:[")
            s.Append(dataZ4_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(6) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 6,")
            s.Append("data:[")
            s.Append(dataZ5_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(7) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 7,")
            s.Append("data:[")
            s.Append(dataZ6_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(8) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 8,")
            s.Append("data:[")
            s.Append(dataZ6_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(9) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 9,")
            s.Append("data:[")
            s.Append(dataZ7_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(10) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 10,")
            s.Append("data:[")
            s.Append(dataZ7_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(11) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 11,")
            s.Append("data:[")
            s.Append(dataZ8_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(12) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 12,")
            s.Append("data:[")
            s.Append(dataZ8_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("]")
            s.Append("};")
            s.Append("myChart.setOption(option);")
            s.Append("</script>")
            Literal1.Text = s.ToString()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Protected Sub GenerateHistoryChartLineBBS(Furnace As String, Column As String, strtDate As String, enDate As String, FurnaceZone As String)
        Try
            Dim sqlQuery As String
            Dim LegenDesc As String
            Dim s As StringBuilder = New StringBuilder()
            Literal1.Text = Nothing
            Dim ColumnName() As String = Column.Split(",")
            Dim ModifyColumn As String
            For i As Integer = 0 To ColumnName.Length - 1
                If i = ColumnName.Length - 1 Then
                    ModifyColumn &= "Cast(" & ColumnName(i) & " As Integer) As " & ColumnName(i) & " "
                Else
                    ModifyColumn &= "Cast(" & ColumnName(i) & " As Integer) As " & ColumnName(i) & ", "
                End If
            Next

            sqlQuery = "Select FORMAT(TIMESTAMP,'dd-MM-yyyy HH:mm:ss') As TIMESTAMP,LINE, " & ModifyColumn & " From [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ZONE_TEMP] Where LINE = '" & Furnace & "'"
            sqlQuery &= " AND TIMESTAMP BETWEEN '" & strtDate & "' AND '" & enDate & "' Order By TIMESTAMP ASC"

            Dim ds As DataSet = objdatahandler.GetDataSetFromQuery(sqlQuery)
            Dim dt As DataTable = ds.Tables(0)

            Dim dataZ1_TC1 As String = Nothing
            Dim dataZ1_TC3 As String = Nothing
            Dim dataZ2_TC2 As String = Nothing
            Dim dataZ3_TC1 As String = Nothing
            Dim dataZ3_TC3 As String = Nothing
            Dim dataZ4_TC2 As String = Nothing
            Dim dataZ5_TC1 As String = Nothing
            Dim dataZ5_TC3 As String = Nothing
            Dim dataZ6_TC2 As String = Nothing
            Dim dataZ7_TC2 As String = Nothing
            Dim dataZ8_TC2 As String = Nothing

            Dim dataZ1_TC2 As String = Nothing
            Dim dataZ2_TC1 As String = Nothing
            Dim dataZ2_TC3 As String = Nothing
            Dim dataZ3_TC2 As String = Nothing
            Dim dataZ4_TC1 As String = Nothing
            Dim dataZ4_TC3 As String = Nothing
            Dim dataZ5_TC2 As String = Nothing
            Dim dataZ6_TC1 As String = Nothing
            Dim dataZ6_TC3 As String = Nothing
            Dim dataZ7_TC1 As String = Nothing
            Dim dataZ7_TC3 As String = Nothing
            Dim dataZ8_TC1 As String = Nothing
            Dim dataZ8_TC3 As String = Nothing

            Dim date_val As String = Nothing
            'If ZoneTC = "Avg" Then
            '    Column = "AvgTemp"
            '    'LegenDesc = "Furnace-" & Session("Furnace") & " " & Session("Zone") & " Average Temperature"
            '    LegenDesc = "Furnace-" & Line & " " & FurnaceZone & " Average Temperature"
            'Else
            '    'LegenDesc = "Furnace-" & Session("Furnace") & " " & Session("Zone") & " " & Session("TC") & " Temperature"
            '    LegenDesc = "Furnace-" & Line & " " & FurnaceZone & " " & ZoneTC & " Temperature"
            'End If

            LegenDesc = "'ZONE1_TC1','ZONE1_TC3','ZONE2_TC2','ZONE3_TC1','ZONE3_TC3','ZONE4_TC2','ZONE5_TC1','ZONE5_TC3','ZONE6_TC2','ZONE7_TC2','ZONE8_TC2',"
            LegenDesc &= "'ZONE1_TC2','ZONE2_TC1','ZONE2_TC3','ZONE3_TC2','ZONE4_TC1','ZONE4_TC3','ZONE5_TC2','ZONE6_TC1','ZONE6_TC3','ZONE7_TC1','ZONE7_TC3','ZONE8_TC1','ZONE8_TC3'"
            Dim LegendDescSeries() As String = LegenDesc.Split(",")


            For I As Integer = 0 To dt.Rows.Count - 1
                dataZ1_TC1 &= dt(I)("Zone1_TC1") & ","
                dataZ1_TC3 &= dt(I)("Zone1_TC3") & ","
                dataZ2_TC2 &= dt(I)("Zone2_TC2") & ","
                dataZ3_TC1 &= dt(I)("Zone3_TC1") & ","
                dataZ3_TC3 &= dt(I)("Zone3_TC3") & ","
                dataZ4_TC2 &= dt(I)("Zone4_TC2") & ","
                dataZ5_TC1 &= dt(I)("Zone5_TC1") & ","
                dataZ5_TC3 &= dt(I)("Zone5_TC3") & ","
                dataZ6_TC2 &= dt(I)("Zone6_TC2") & ","
                dataZ7_TC2 &= dt(I)("Zone7_TC2") & ","
                dataZ8_TC2 &= dt(I)("Zone8_TC2") & ","

                dataZ1_TC2 &= dt(I)("Zone1_TC2") & ","
                dataZ2_TC1 &= dt(I)("Zone2_TC1") & ","
                dataZ2_TC3 &= dt(I)("Zone2_TC3") & ","
                dataZ3_TC2 &= dt(I)("Zone3_TC2") & ","
                dataZ4_TC1 &= dt(I)("Zone4_TC1") & ","
                dataZ4_TC3 &= dt(I)("Zone4_TC3") & ","
                dataZ5_TC2 &= dt(I)("Zone5_TC2") & ","
                dataZ6_TC1 &= dt(I)("Zone6_TC1") & ","
                dataZ6_TC3 &= dt(I)("Zone6_TC3") & ","
                dataZ7_TC1 &= dt(I)("Zone7_TC1") & ","
                dataZ7_TC3 &= dt(I)("Zone7_TC3") & ","
                dataZ8_TC1 &= dt(I)("Zone8_TC1") & ","
                dataZ8_TC3 &= dt(I)("Zone8_TC3") & ","

                date_val &= "'" & dt(I)("TIMESTAMP") & "',"
            Next

            'Dim ymin As Double = Convert.ToDouble(dt.Compute("min(" & Column & ")", "")) - 100
            'Dim ymax As Double = Convert.ToDouble(dt.Compute("max(" & Column & ")", "")) + 100

            Dim ymin As Double = 0.0
            Dim ymax As Double = 0.0

            Dim yminZone1_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone1_TC1)", "")) - 100
            Dim yminZone1_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone1_TC3)", "")) - 100
            Dim yminZone2_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone2_TC2)", "")) - 100
            Dim yminZone3_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone3_TC1)", "")) - 100
            Dim yminZone3_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone3_TC3)", "")) - 100
            Dim yminZone4_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone4_TC2)", "")) - 100
            Dim yminZone5_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone5_TC1)", "")) - 100
            Dim yminZone5_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone5_TC3)", "")) - 100
            Dim yminZone6_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone6_TC2)", "")) - 100
            Dim yminZone7_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone7_TC2)", "")) - 100
            Dim yminZone8_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone8_TC2)", "")) - 100

            Dim yminZone1_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone1_TC2)", "")) - 100
            Dim yminZone2_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone2_TC1)", "")) - 100
            Dim yminZone2_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone2_TC3)", "")) - 100
            Dim yminZone3_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone3_TC2)", "")) - 100
            Dim yminZone4_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone4_TC1)", "")) - 100
            Dim yminZone4_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone4_TC3)", "")) - 100
            Dim yminZone5_TC2 As Double = Convert.ToDouble(dt.Compute("min(Zone5_TC2)", "")) - 100
            Dim yminZone6_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone6_TC1)", "")) - 100
            Dim yminZone6_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone6_TC3)", "")) - 100
            Dim yminZone7_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone7_TC1)", "")) - 100
            Dim yminZone7_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone7_TC3)", "")) - 100
            Dim yminZone8_TC1 As Double = Convert.ToDouble(dt.Compute("min(Zone8_TC1)", "")) - 100
            Dim yminZone8_TC3 As Double = Convert.ToDouble(dt.Compute("min(Zone8_TC3)", "")) - 100

            Dim ymaxZone1_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone1_TC1)", "")) + 100
            Dim ymaxZone1_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone1_TC3)", "")) + 100
            Dim ymaxZone2_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone2_TC2)", "")) + 100
            Dim ymaxZone3_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone3_TC1)", "")) + 100
            Dim ymaxZone3_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone3_TC3)", "")) + 100
            Dim ymaxZone4_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone4_TC2)", "")) + 100
            Dim ymaxZone5_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone5_TC1)", "")) + 100
            Dim ymaxZone5_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone5_TC3)", "")) + 100
            Dim ymaxZone6_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone6_TC2)", "")) + 100
            Dim ymaxZone7_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone7_TC2)", "")) + 100
            Dim ymaxZone8_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone8_TC2)", "")) + 100

            Dim ymaxZone1_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone1_TC2)", "")) + 100
            Dim ymaxZone2_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone2_TC1)", "")) + 100
            Dim ymaxZone2_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone2_TC3)", "")) + 100
            Dim ymaxZone3_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone3_TC2)", "")) + 100
            Dim ymaxZone4_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone4_TC1)", "")) + 100
            Dim ymaxZone4_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone4_TC3)", "")) + 100
            Dim ymaxZone5_TC2 As Double = Convert.ToDouble(dt.Compute("max(Zone5_TC2)", "")) + 100
            Dim ymaxZone6_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone6_TC1)", "")) + 100
            Dim ymaxZone6_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone6_TC3)", "")) + 100
            Dim ymaxZone7_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone7_TC1)", "")) + 100
            Dim ymaxZone7_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone7_TC3)", "")) + 100
            Dim ymaxZone8_TC1 As Double = Convert.ToDouble(dt.Compute("max(Zone8_TC1)", "")) + 100
            Dim ymaxZone8_TC3 As Double = Convert.ToDouble(dt.Compute("max(Zone8_TC3)", "")) + 100

            ymax = ymaxZone1_TC1

            If ymaxZone1_TC1 > ymax Then
                ymax = ymaxZone1_TC1
            End If
            If ymaxZone1_TC3 > ymax Then
                ymax = ymaxZone1_TC3
            End If
            If ymaxZone2_TC2 > ymax Then
                ymax = ymaxZone2_TC2
            End If
            If ymaxZone3_TC1 > ymax Then
                ymax = ymaxZone3_TC1
            End If
            If ymaxZone3_TC3 > ymax Then
                ymax = ymaxZone3_TC3
            End If
            If ymaxZone4_TC2 > ymax Then
                ymax = ymaxZone4_TC2
            End If
            If ymaxZone5_TC1 > ymax Then
                ymax = ymaxZone5_TC1
            End If
            If ymaxZone5_TC3 > ymax Then
                ymax = ymaxZone5_TC3
            End If
            If ymaxZone6_TC2 > ymax Then
                ymax = ymaxZone6_TC2
            End If
            If ymaxZone7_TC2 > ymax Then
                ymax = ymaxZone7_TC2
            End If
            If ymaxZone8_TC2 > ymax Then
                ymax = ymaxZone8_TC2
            End If

            If ymaxZone1_TC2 > ymax Then
                ymax = ymaxZone1_TC2
            End If
            If ymaxZone2_TC1 > ymax Then
                ymax = ymaxZone2_TC1
            End If
            If ymaxZone2_TC3 > ymax Then
                ymax = ymaxZone2_TC3
            End If
            If ymaxZone3_TC2 > ymax Then
                ymax = ymaxZone3_TC2
            End If
            If ymaxZone4_TC1 > ymax Then
                ymax = ymaxZone4_TC1
            End If
            If ymaxZone4_TC3 > ymax Then
                ymax = ymaxZone4_TC3
            End If
            If ymaxZone5_TC2 > ymax Then
                ymax = ymaxZone5_TC2
            End If
            If ymaxZone6_TC1 > ymax Then
                ymax = ymaxZone6_TC1
            End If
            If ymaxZone6_TC3 > ymax Then
                ymax = ymaxZone6_TC3
            End If
            If ymaxZone7_TC1 > ymax Then
                ymax = ymaxZone7_TC1
            End If
            If ymaxZone7_TC3 > ymax Then
                ymax = ymaxZone7_TC3
            End If
            If ymaxZone8_TC1 > ymax Then
                ymax = ymaxZone8_TC1
            End If
            If ymaxZone8_TC3 > ymax Then
                ymax = ymaxZone8_TC3
            End If

            ymin = yminZone1_TC1

            If yminZone1_TC1 < ymin Then
                ymin = yminZone1_TC1
            End If
            If yminZone1_TC3 < ymin Then
                ymin = yminZone1_TC3
            End If
            If yminZone2_TC2 < ymin Then
                ymin = yminZone2_TC2
            End If
            If yminZone3_TC1 < ymin Then
                ymin = yminZone3_TC1
            End If
            If yminZone3_TC3 < ymin Then
                ymin = yminZone3_TC3
            End If
            If yminZone4_TC2 < ymin Then
                ymin = yminZone4_TC2
            End If
            If yminZone5_TC1 < ymin Then
                ymin = yminZone5_TC1
            End If
            If yminZone5_TC3 < ymin Then
                ymin = yminZone5_TC3
            End If
            If yminZone6_TC2 < ymin Then
                ymin = yminZone6_TC2
            End If
            If yminZone7_TC2 < ymin Then
                ymin = yminZone7_TC2
            End If
            If yminZone8_TC2 < ymin Then
                ymin = yminZone8_TC2
            End If

            If yminZone1_TC2 < ymin Then
                ymin = yminZone1_TC2
            End If
            If yminZone2_TC1 < ymin Then
                ymin = yminZone2_TC1
            End If
            If yminZone2_TC3 < ymin Then
                ymin = yminZone2_TC3
            End If
            If yminZone3_TC2 < ymin Then
                ymin = yminZone3_TC2
            End If
            If yminZone4_TC1 < ymin Then
                ymin = yminZone4_TC1
            End If
            If yminZone4_TC3 < ymin Then
                ymin = yminZone4_TC3
            End If
            If yminZone5_TC2 < ymin Then
                ymin = yminZone5_TC2
            End If
            If yminZone6_TC1 < ymin Then
                ymin = yminZone6_TC1
            End If
            If yminZone6_TC3 < ymin Then
                ymin = yminZone6_TC3
            End If
            If yminZone7_TC1 < ymin Then
                ymin = yminZone7_TC1
            End If
            If yminZone7_TC3 < ymin Then
                ymin = yminZone7_TC3
            End If
            If yminZone8_TC1 < ymin Then
                ymin = yminZone8_TC1
            End If
            If yminZone8_TC3 < ymin Then
                ymin = yminZone8_TC3
            End If

            'Dim LegenDesc As String = "Furnace-" & Session("Furnace") & " " & Session("Zone") & " " & Session("TC")

            ''------------------------------ Arranged Color Codes -----------------------------------------
            ''Red:#FF0000;Lime Green:#00FF00;Green:#008000;Navy blue:#000080;Black:#000000
            ''Magenta:#FF00FF;Brown:#A52A2A;Olive:#808000;Maroon:#800000;Teal:#008080
            ''Purple:#800080;Blue Gray:#98AFC7;DodgerBlue (W3C):#1E90FF;Deep Teal:#033E3E;SeaGreen (W3C):#2E8B57	
            ''Jade:#00A36C;Venom Green:#728C00;Pine Green:#387C44;Deep Yellow:#F6BE00;Copper:#B87333	
            ''Wood:#966F33;Antique Bronze:#665D1E;Taupe:#483C32;Milk Chocolate:#513B1C;Mahogany:#C04000	
            ''Tomato Sauce Red: #B21807;Orchid Purple:#B048B5;Bright Grape:#6F2DA8;Red Blood:#660000	
            ''#F39C12;#FF5733;#2E86C1

            s.Append("<script>")
            's.Append("var myChart = echarts.init(document.getElementById('main'));")
            s.Append("var myChart = echarts.init(document.getElementById('main'), null, {")
            s.Append("width:1200,")
            s.Append("height:600")
            s.Append("});")
            's.Append("const colors = ['#5470C6', '#91CC75', '#EE6666'];")
            's.Append("const colors = ['#5470C6'];")
            s.Append("const colors = ['#FF0000','#00FF00', '#008000', '#000080','#000000','#FF00FF','#A52A2A','#808000','#800000','#008080','#800080','#98AFC7','#1E90FF',")
            s.Append("'#033E3E','#2E8B57','#00A36C','#728C00','#387C44','#F6BE00','#B87333','#966F33','#665D1E','#483C32','#513B1C'];")
            s.Append("option = {")
            s.Append("color: colors,")
            s.Append("tooltip:")
            s.Append("{")
            s.Append("trigger: 'axis',")
            s.Append("axisPointer:")
            s.Append("{")
            s.Append("type: 'cross'")
            s.Append("}")
            s.Append("},")
            s.Append("grid:")
            s.Append("{")
            's.Append("right: '20%',")
            s.Append("right: '5%',")
            s.Append("bottom: '30%'")
            's.Append("bottom: '20%'")
            s.Append("},")
            s.Append("toolbox:")
            s.Append("{")
            s.Append("feature:")
            s.Append("{")
            s.Append("dataView: { show: true, readOnly: false },")
            s.Append("restore: { show: true },")
            s.Append("saveAsImage: { show: true }")
            s.Append("}")
            s.Append("},")
            s.Append("legend:")
            s.Append("{")
            's.Append("data:['TC Temp']")
            s.Append("data:[" & LegenDesc & "],")
            s.Append("orient:'horizontal',")
            's.Append("right:10,")
            s.Append("bottom:'0%',")
            's.Append("top:'bottom',")
            's.Append("type:'scroll'")
            s.Append("},")
            s.Append("xAxis:")
            s.Append("[")
            s.Append("{")
            s.Append("type: 'category',")
            s.Append("axisTick:")
            s.Append("{")
            s.Append("alignWithLabel: true")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            s.Append("show: true,")
            s.Append("rotate: 45")
            s.Append("},")
            s.Append("data:[" & date_val & "]")
            s.Append("}")
            s.Append("],")
            s.Append("yAxis:")
            s.Append("[")
            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("name: " & LegendDescSeries(0) & ",")
            s.Append("name: 'Temp. Range',")
            s.Append("min: " & ymin & ",")
            s.Append("max: " & ymax & ",")
            s.Append("position: 'left',")
            s.Append("axisLine:")
            s.Append("{")
            s.Append("show: true,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[0]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            s.Append("formatter: '{value} '")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[1]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[2]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[3]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[4]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[5]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[6]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[7]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[8]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[9]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[10]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[11]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[12]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[13]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[14]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[15]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[16]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[17]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[18]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[19]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[20]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[21]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[22]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("{")
            s.Append("type: 'value',")
            's.Append("name: 'TC Temp',")
            's.Append("min: " & ymin & ",")
            's.Append("max: " & ymax & ",")
            's.Append("position: 'left',")
            s.Append("position: 'right',")
            s.Append("axisLine:")
            s.Append("{")
            's.Append("show: true,")
            s.Append("show: false,")
            s.Append("lineStyle:")
            s.Append("{")
            s.Append("color: colors[23]")
            s.Append("}")
            s.Append("},")
            s.Append("axisLabel:")
            s.Append("{")
            's.Append("formatter: '{value} '")
            s.Append("show:false")
            s.Append("}")
            s.Append("},")

            s.Append("],")
            s.Append("series:")
            s.Append("[")
            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(0) & ",")
            s.Append("type: 'line',")
            s.Append("data:[")
            s.Append(dataZ1_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(1) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 1,")
            s.Append("data:[")
            s.Append(dataZ1_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(2) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 2,")
            s.Append("data:[")
            s.Append(dataZ2_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(3) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 3,")
            s.Append("data:[")
            s.Append(dataZ3_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(4) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 4,")
            s.Append("data:[")
            s.Append(dataZ3_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(5) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 5,")
            s.Append("data:[")
            s.Append(dataZ4_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(6) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 6,")
            s.Append("data:[")
            s.Append(dataZ5_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(7) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 7,")
            s.Append("data:[")
            s.Append(dataZ5_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(8) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 8,")
            s.Append("data:[")
            s.Append(dataZ6_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(9) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 9,")
            s.Append("data:[")
            s.Append(dataZ7_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(10) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 10,")
            s.Append("data:[")
            s.Append(dataZ8_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(11) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 11,")
            s.Append("data:[")
            s.Append(dataZ1_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(12) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 12,")
            s.Append("data:[")
            s.Append(dataZ2_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(13) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 13,")
            s.Append("data:[")
            s.Append(dataZ2_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(14) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 14,")
            s.Append("data:[")
            s.Append(dataZ3_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(15) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 15,")
            s.Append("data:[")
            s.Append(dataZ4_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(16) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 16,")
            s.Append("data:[")
            s.Append(dataZ4_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(17) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 17,")
            s.Append("data:[")
            s.Append(dataZ5_TC2)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(18) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 18,")
            s.Append("data:[")
            s.Append(dataZ6_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(19) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 19,")
            s.Append("data:[")
            s.Append(dataZ6_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(20) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 20,")
            s.Append("data:[")
            s.Append(dataZ7_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(21) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 21,")
            s.Append("data:[")
            s.Append(dataZ7_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(22) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 22,")
            s.Append("data:[")
            s.Append(dataZ8_TC1)
            s.Append("]")
            s.Append("},")

            s.Append("{")
            's.Append("name: 'TC Temp',")
            s.Append("name: " & LegendDescSeries(23) & ",")
            s.Append("type: 'line',")
            s.Append("yAxisIndex: 23,")
            s.Append("data:[")
            s.Append(dataZ8_TC3)
            s.Append("]")
            s.Append("},")

            s.Append("]")
            s.Append("};")
            s.Append("myChart.setOption(option);")
            s.Append("</script>")
            Literal1.Text = s.ToString()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Public Sub Download_Click()
        Try
            Dim StartTime As String
            Dim EndTime As String
            Dim dtdownload As New DataTable
            Dim sqlQuery As String
            Dim Line As String
            Dim ColName As String
            Dim FurnaceZone As String
            Dim ZoneTC As String

            Dim ds As DataSet
            Dim dt As DataTable

            If Request.QueryString("Zone") <> "HistDataLineADrive" And Request.QueryString("Zone") <> "HistDataLineAOS" And Request.QueryString("Zone") <> "HistDataLineABoth" _
              And Request.QueryString("Zone") <> "HistDataLineBDrive" And Request.QueryString("Zone") <> "HistDataLineBOS" And Request.QueryString("Zone") <> "HistDataLineBBoth" Then

                If Request.QueryString("Furnace") <> "" And Request.QueryString("ZoneTemp") <> "" And Request.QueryString("StartDt") <> "" And Request.QueryString("EndDt") <> "" And Request.QueryString("Zone") <> "" And Request.QueryString("TC") <> "" Then
                    Line = Request.QueryString("Furnace")
                    If (Request.QueryString("TC") = "Avg") Then
                        ColName = Request.QueryString("ZoneTemp")
                    Else
                        ColName = Request.QueryString("ZoneTemp")
                    End If

                    StartTime = hfDldFrom.Value
                    EndTime = hfDldTo.Value

                    FurnaceZone = Request.QueryString("Zone")
                    ZoneTC = Request.QueryString("TC")

                    If ZoneTC = "Avg" Then
                        sqlQuery = "Select FORMAT(TIMESTAMP,'dd-MM-yyyy HH:mm:ss') As TIMESTAMP,LINE, Cast(" & ColName & " As Integer) As AvgTemp From [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ZONE_TEMP] Where LINE = '" & Line & "'"
                        sqlQuery &= " AND TIMESTAMP BETWEEN '" & StartTime & "' AND '" & EndTime & "' Order By TIMESTAMP ASC"
                    Else
                        sqlQuery = "Select FORMAT(TIMESTAMP,'dd-MM-yyyy HH:mm:ss') As TIMESTAMP,LINE, Cast(" & ColName & " As Integer) As " & ColName & " From [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ZONE_TEMP] Where LINE = '" & Line & "'"
                        sqlQuery &= " AND TIMESTAMP BETWEEN '" & StartTime & "' AND '" & EndTime & "' Order By TIMESTAMP ASC"
                    End If
                    ds = objdatahandler.GetDataSetFromQuery(sqlQuery)
                    dt = ds.Tables(0)
                End If

                dtdownload.Columns.Add("TIMESTAMP")
                dtdownload.Columns.Add("LINE")
                If Request.QueryString("TC") = "Avg" Then
                    dtdownload.Columns.Add("Avg -" + Line.Substring(1, 17), GetType(Double))
                Else
                    dtdownload.Columns.Add(ZoneTC, GetType(Double))
                End If

                Dim count As Integer = 0

                If dt.Rows.Count > 0 Then
                    For j As Integer = 0 To dt.Rows.Count - 1
                        dtdownload.Rows.Add()

                        dtdownload(count)("TIMESTAMP") = dt.Rows.Item(j)(0)
                        dtdownload(count)("LINE") = dt.Rows.Item(j)(1)
                        If Request.QueryString("TC") = "Avg" Then
                            dtdownload(count)("AvgTemp") = dt.Rows.Item(j)(2)
                        Else
                            dtdownload(count)(ZoneTC) = dt.Rows.Item(j)(2)
                        End If
                        count += 1
                    Next
                End If
                dtdownload.DefaultView.Sort = "TIMESTAMP desc "
                Dim datavalue As DataTable = dtdownload
                ExporttoExcel(datavalue, "TCTemp")
            Else
                Download_HistoryData()
            End If

        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Public Sub Download_HistoryData()
        Try
            Dim StartTime As String
            Dim EndTime As String
            Dim dtdownload As New DataTable
            Dim sqlQuery As String
            Dim Line As String
            Dim ColName As String
            Dim ColumnName() As String
            Dim FurnaceZone As String
            Dim ZoneTC As String

            Dim ds As DataSet
            Dim dt As DataTable

            If Request.QueryString("Furnace") <> "" And Request.QueryString("ZoneTemp") <> "" And Request.QueryString("StartDt") <> "" And Request.QueryString("EndDt") <> "" _
                And Request.QueryString("Zone") <> "" Then

                Line = Request.QueryString("Furnace")
                ColName = Request.QueryString("ZoneTemp")
                ColumnName = ColName.Split(",")
                Dim ModifyColumn As String
                For i As Integer = 0 To ColumnName.Length - 1
                    If i = ColumnName.Length - 1 Then
                        ModifyColumn &= "Cast(" & ColumnName(i) & " As Integer) As " & ColumnName(i) & " "
                    Else
                        ModifyColumn &= "Cast(" & ColumnName(i) & " As Integer) As " & ColumnName(i) & ", "
                    End If
                Next
                'If (Request.QueryString("TC") = "Avg") Then
                '    ColName = Request.QueryString("ZoneTemp")
                'Else
                '    ColName = Request.QueryString("ZoneTemp")
                'End If

                StartTime = hfDldFrom.Value
                EndTime = hfDldTo.Value

                FurnaceZone = Request.QueryString("Zone")
                ZoneTC = Request.QueryString("TC")

                'If ZoneTC = "Avg" Then
                '    sqlQuery = "Select FORMAT(TIMESTAMP,'dd-MM-yyyy HH:mm:ss') As TIMESTAMP,LINE, Cast(" & ColName & " As Integer) As AvgTemp From [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ZONE_TEMP] Where LINE = '" & Line & "'"
                '    sqlQuery &= " AND TIMESTAMP BETWEEN '" & StartTime & "' AND '" & EndTime & "' Order By TIMESTAMP ASC"
                'Else
                '    sqlQuery = "Select FORMAT(TIMESTAMP,'dd-MM-yyyy HH:mm:ss') As TIMESTAMP,LINE, Cast(" & ColName & " As Integer) As " & ColName & " From [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ZONE_TEMP] Where LINE = '" & Line & "'"
                '    sqlQuery &= " AND TIMESTAMP BETWEEN '" & StartTime & "' AND '" & EndTime & "' Order By TIMESTAMP ASC"
                'End If
                sqlQuery = "Select FORMAT(TIMESTAMP,'dd-MM-yyyy HH:mm:ss') As TIMESTAMP,LINE, " & ModifyColumn & " From [FP_PROCESS_DATA].[dbo].[TSCR_FURNACE_ZONE_TEMP] Where LINE = '" & Line & "'"
                sqlQuery &= " AND TIMESTAMP BETWEEN '" & StartTime & "' AND '" & EndTime & "' Order By TIMESTAMP ASC"

                ds = objdatahandler.GetDataSetFromQuery(sqlQuery)
                dt = ds.Tables(0)
            End If

            dtdownload.Columns.Add("TIMESTAMP")
            dtdownload.Columns.Add("LINE")
            'If Request.QueryString("TC") = "Avg" Then
            '    dtdownload.Columns.Add("Avg -" + Line.Substring(1, 17), GetType(Double))
            'Else
            '    dtdownload.Columns.Add(ZoneTC, GetType(Double))
            'End If
            For j As Integer = 0 To ColumnName.Length - 1
                dtdownload.Columns.Add(ColumnName(j), GetType(Double))
            Next

            Dim count As Integer = 0

            If dt.Rows.Count > 0 Then
                For j As Integer = 0 To dt.Rows.Count - 1
                    dtdownload.Rows.Add()

                    dtdownload(count)("TIMESTAMP") = dt.Rows.Item(j)(0)
                    dtdownload(count)("LINE") = dt.Rows.Item(j)(1)
                    'If Request.QueryString("TC") = "Avg" Then
                    '    dtdownload(count)("AvgTemp") = dt.Rows.Item(j)(2)
                    'Else
                    '    dtdownload(count)(ZoneTC) = dt.Rows.Item(j)(2)
                    'End If
                    For k As Integer = 0 To ColumnName.Length - 1
                        'dtdownload.Columns.Add(ColumnName(j), GetType(Double))
                        dtdownload(count)(ColumnName(k)) = dt.Rows.Item(j)(k + 2)
                    Next
                    count += 1
                Next
            End If
            dtdownload.DefaultView.Sort = "TIMESTAMP desc "
            Dim datavalue As DataTable = dtdownload
            ExporttoExcel(datavalue, "TCTemp")
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Public Sub ExporttoExcel(ByVal table As DataTable, ByVal filename As String)
        HttpContext.Current.Response.Clear()
        HttpContext.Current.Response.ClearContent()
        HttpContext.Current.Response.ClearHeaders()
        HttpContext.Current.Response.Buffer = True
        HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.UTF8
        HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache)
        HttpContext.Current.Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        HttpContext.Current.Response.AddHeader("content-disposition", "attachment;filename=GridData.xlsx")

        Using pack As ExcelPackage = New ExcelPackage()
            Dim ws As ExcelWorksheet = pack.Workbook.Worksheets.Add(filename)
            ws.Cells("A1").LoadFromDataTable(table, True)
            Dim ms = New System.IO.MemoryStream()
            pack.SaveAs(ms)
            ms.WriteTo(HttpContext.Current.Response.OutputStream)
        End Using

        HttpContext.Current.Response.Flush()
        'HttpContext.Current.Response.[End]()
    End Sub
End Class
