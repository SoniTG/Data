﻿Imports System.Data
Imports System.IO
Partial Class analysis
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        Dim p As String = Request("__EVENTARGUMENT")
        If p = "trend" Then

            GoBtnClick()
        ElseIf p = "line" Then

            GoBtnClick("line")

        End If

        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-29).ToString("yyyy-MM-dd HH:mm")
                'Dim dtStart As DateTime = DateTime.Now.AddMonths(-4).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

                objController.PopulateGrade(ddlGrade, dtStart, dtEnd)
                objController.PopulateTdc(ddlTdc, dtStart, dtEnd, ddlGrade.SelectedItem.Text)
                objController.PopulateRough(ddlThickness, dtStart, dtEnd, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
                objController.LoadColumnName(clbParamTest)
            Catch ex As Exception

            End Try

        End If
    End Sub


    Protected Sub btnOk_Click(sender As Object, e As EventArgs) Handles btnOk.Click
        GoBtnClick(getChartType)
    End Sub

    Function getChartType() As String
        If hfRadio.Value = "0" Then
            Return "trend"
        Else
            Return "line"
        End If
    End Function

    Sub GoBtnClick(Optional chartType As String = "trend")
        Try

            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            Dim str1 As String = ""
            Dim count As Integer = 0
            Dim appendString = ""
            For i As Integer = 0 To clbParamTest.Items.Count - 1
                If clbParamTest.Items(i).Selected Then
                    count += 1
                    str1 &= "," & clbParamTest.Items(i).Value
                    appendString &= "<div class='col-md-2'></div><div class='col-md-10'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>" & clbParamTest.Items(i).Text & "</h3> <span></span></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='" & clbParamTest.Items(i).Value & "' style='height: 200px;'></div></div></div></div>"


                End If
            Next
            divHolder.InnerHtml = appendString
            If str1 = "" Then

            Else
                str1 = str1.Substring(1)

                Dim filter As String = " 1=1"
                If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
                    filter &= " and PRM_CD_GRADE = '" & ddlGrade.SelectedItem.Text & "'"
                End If
                If ddlTdc.SelectedItem.Text.ToLower <> "all" Then
                    filter &= " and PRM_TDC_NO = '" & ddlTdc.SelectedItem.Text & "'"
                End If
                If ddlThickness.SelectedItem.Text.ToLower <> "all" Then
                    filter &= " and PRM_CD_SURF_ROUGH = '" & ddlThickness.SelectedItem.Value & "'"
                End If
                If chartType = "line" Then
                    filter &= " and " & str1 & " is not null and " & str1 & ">0"
                End If
                DrawChartTop(str1, fromDt, toDt, filter, chartType)
            End If
        Catch ex As Exception

        End Try
    End Sub

    Sub DrawChartTop(ByVal ColumnName As String, ByVal FromDt As String, ByVal ToDt As String, ByVal Filter As String, ByVal chartType As String)
        Try

            Dim strfrmDt As String = FromDt
            Dim strToDt As String = ToDt


            Dim dt As DataTable = objController.GetDataForAnalysis("T_CGL_FUR_PARAM", strfrmDt, strToDt, "PRM_TS_END", ColumnName, Filter)
            'Dim yVal As String = ""
            Dim a() As String = ColumnName.Split(",")
            Dim l As Literal
            For i As Integer = 0 To UBound(a)
                Dim literals = Page.Master.FindControl("content_body").Controls.OfType(Of Literal)()
                For Each lit In literals
                    If (lit.ID = "Lit" & i + 1) Then
                        l = lit
                        Exit For
                    End If
                Next
                ' Dim literal As Literal = CType(Me.Master.FindControl("Lit" & i + 1), Literal)
                
                objController.PlotLineChartForAnalysis(dt, "PRM_TS_END", a(i), l, a(i), "plot" & i + 1, "", "", i, chartType)
            Next




        Catch ex As Exception

        End Try
    End Sub
    Protected Sub ddlGrade_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlGrade.SelectedIndexChanged
        Try
            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            objController.PopulateTdc(ddlTdc, fromDt, toDt, ddlGrade.SelectedItem.Text)
            objController.PopulateRough(ddlThickness, fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
            btnOk_Click(sender, e)
        Catch ex As Exception

        End Try
       
    End Sub
    Protected Sub ddlTdc_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlTdc.SelectedIndexChanged
        Try
            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            objController.PopulateRough(ddlThickness, fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
            btnOk_Click(sender, e)
        Catch ex As Exception

        End Try
       
    End Sub

    
    Protected Sub ddlThickness_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlThickness.SelectedIndexChanged
        Try
            btnOk_Click(sender, e)
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub txtDate_TextChanged(sender As Object, e As System.EventArgs) Handles txtDate.TextChanged
        Try
            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            If ddlGrade.SelectedIndex > 0 And ddlTdc.SelectedIndex > 0 And ddlThickness.SelectedIndex > 0 Then
                objController.PopulateGrade(ddlGrade, fromDt, toDt)
                objController.PopulateTdc(ddlTdc, fromDt, toDt, ddlGrade.SelectedItem.Text)
                objController.PopulateRough(ddlThickness, fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
            End If
            btnOk_Click(sender, e)
        Catch ex As Exception

        End Try
      

    End Sub
End Class
