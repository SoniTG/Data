﻿Imports System.Data
Imports System.IO
Imports iTextSharp.text
Imports iTextSharp.text.html.simpleparser
Imports iTextSharp.text.pdf
Imports iTextSharp.tool.xml
Partial Class bathmanagementreport
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim objEffectiveAlFeCalculation As New EffectiveAlFeCalculation
    Dim arrSolCurve_Al(), arrSolCurve_Fe() As Double
    Public Shared T_Bath_C, T_Bath_K, Al_tot_old, Fe_Tot_old, Al_eff, Fe_eff, Fe1, Fe2, J_Calc, Fe_solb, xTemp, Fe_tot As Double
    Dim cummCount As Integer = 5

    Sub POTStatusData()
        Try

            Dim ds As DataSet = objController.LoadPOTStatus(DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd HH:mm:ss"), DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"))
            Dim campaign As DataTable = ds.Tables(0).DefaultView.ToTable(True, "PRM_CD_SURF_ROUGH")

            Dim text1, text2 As String
            Dim coil As Integer = 0
            'Label3.Text = "GI"
            'Label2.Text = "GA"
            For row As Integer = 0 To campaign.Rows.Count - 1
                If (campaign.Rows(row)(0) = "A") Then
                    Dim totCoil As Integer = ds.Tables(0).Compute("count(PRM_CD_SURF_ROUGH)", "PRM_CD_SURF_ROUGH='A'")
                    'coil = ds.Tables(0).Compute("count(PRM_ZINC_POT_TMP)", "PRM_ZINC_POT_TMP>475 or PRM_ZINC_POT_TMP<465")
                    coil = ds.Tables(0).Compute("count(PRM_ZINC_POT_TMP)", "PRM_CD_SURF_ROUGH='A' and (PRM_ZINC_POT_TMP>464 or PRM_ZINC_POT_TMP<456)")
                    text1 = coil & "/" & totCoil
                    lblPotCount.Text = "GA"
                    lblPotCount1.Text = text1
                    Exit For
                Else
                    Dim totCoil As Integer = ds.Tables(0).Compute("count(PRM_CD_SURF_ROUGH)", "PRM_CD_SURF_ROUGH='Z'")
                    'coil = ds.Tables(0).Compute("count(PRM_ZINC_POT_TMP)", "PRM_ZINC_POT_TMP>462 or PRM_ZINC_POT_TMP<458")
                    coil = ds.Tables(0).Compute("count(PRM_ZINC_POT_TMP)", "PRM_CD_SURF_ROUGH='Z' and (PRM_ZINC_POT_TMP>464 or PRM_ZINC_POT_TMP<456)")
                    text2 = coil & "/" & totCoil
                    lblPotCount.Text = "GI"
                    lblPotCount1.Text = text2
                    Exit For
                End If
            Next
            Dim dv As DataView = ds.Tables(0).DefaultView
            'dv.RowFilter = "PRM_CD_SURF_ROUGH='A' and PRM_ZINC_POT_TMP>475 or PRM_ZINC_POT_TMP<465"
            dv.RowFilter = "PRM_CD_SURF_ROUGH='A' and (PRM_ZINC_POT_TMP>464 or PRM_ZINC_POT_TMP<456)"
            Dim dtA As DataTable = dv.ToTable
            dv.RowFilter = ""
            'dv.RowFilter = "PRM_CD_SURF_ROUGH='Z' and PRM_ZINC_POT_TMP>462 or PRM_ZINC_POT_TMP<458"
            dv.RowFilter = "PRM_CD_SURF_ROUGH='Z' and (PRM_ZINC_POT_TMP>464 or PRM_ZINC_POT_TMP<456)"
            Dim dtZ As DataTable = dv.ToTable
            dv.RowFilter = ""

            If lblPotCount.Text = "GA" Then
                dgv3.DataSource = dtA
                dgv3.DataBind()
            Else
                dgv3.DataSource = dtZ
                dgv3.DataBind()
            End If

            'dgv.DataSource = dtA
            'dgv.DataBind()
            'dgv2.DataSource = dtZ
            'dgv2.DataBind()

            'If text1 <> "" Then
            '    Label1.Text = text1

            'Else
            '    Label1.Text = "0/0"
            'End If
            'If text2 <> "" Then
            '    Label4.Text = text2
            'Else
            '    Label4.Text = "0/0"
            'End If

        Catch ex As Exception

        End Try
    End Sub

    Sub CreateGraph()
        Try

            'lblError.Text = ""
            'Al Effective
            '###########################
            ' Dim objEffectiveAlFeCalculation As New EffectiveAlFeCalculation
            Al_tot_old = "0.1322"
            Fe_Tot_old = "0.0383"
            T_Bath_C = "460"
            T_Bath_K = "460" + 273.15

            objEffectiveAlFeCalculation.Main(T_Bath_C, T_Bath_K)
            ViewState("txtAITriplePoint") = Math.Round(objEffectiveAlFeCalculation.Al_trip, 4)
            ViewState("txtFETriplePoint") = Math.Round(objEffectiveAlFeCalculation.Fe_trip, 4)

            'objEffectiveAlFeCalculation.mtdEffectivAlFeCal(Al_tot_old, T_Bath_K, objEffectiveAlFeCalculation.Al_trip, objEffectiveAlFeCalculation.Fe_trip)
            objEffectiveAlFeCalculation.Aleffcal(Al_tot_old, Fe_Tot_old)

            ViewState("txtAITriplePoint") = Math.Round(objEffectiveAlFeCalculation.Al_trip, 4)
            ViewState("txtFETriplePoint") = Math.Round(objEffectiveAlFeCalculation.Fe_trip, 4)
            Al_eff = Math.Round(objEffectiveAlFeCalculation.Al_liq, 4)
            If Al_eff = 0 Then
                'litLineGraph.Text = ""
                ViewState("txtAIEffective") = ""
                ViewState("txtFEEffective") = ""
                ViewState("txtAITriplePoint") = ""
                ViewState("txtFETriplePoint") = ""
                'lblError.Text = "Effective AL = 0; ""Inappropriate values of Total AL or Total FE"""
                'UserMsgBox("Inappropriate values for Total AL or Total FE.")
                Exit Sub
            End If
            ViewState("txtAIEffective") = Al_eff

            Fe_eff = Math.Round(objEffectiveAlFeCalculation.Fe_liq, 4)
            ViewState("txtFEEffective") = Fe_eff
            '###########################


            'Dim objEffectiveAlFeCalculation As New EffectiveAlFeCalculation
            Al_tot_old = ViewState("txtTotalAI")

            Dim AL_St_pnt, Fe_St_pnt, AL_End_pnt, Fe_End_pnt, Al_increment As Double
            AL_St_pnt = 0.08
            Fe_St_pnt = 0.0
            AL_End_pnt = 0.26
            Fe_End_pnt = 0.05
            Dim no_iteration As Integer
            no_iteration = (AL_End_pnt - AL_St_pnt) * 10000 + 1
            Al_increment = 0.0001
            ReDim Preserve arrSolCurve_Al(no_iteration - 1)
            ReDim Preserve arrSolCurve_Fe(no_iteration - 1)
            For i As Integer = 0 To no_iteration - 1
                Al_tot_old = Math.Round(AL_St_pnt + i * Al_increment, 4)

                objEffectiveAlFeCalculation.mtdEffectivAlFeCal(Al_tot_old, T_Bath_K, objEffectiveAlFeCalculation.Al_trip, objEffectiveAlFeCalculation.Fe_trip)
                arrSolCurve_Al(i) = Al_tot_old
                arrSolCurve_Fe(i) = Math.Round(objEffectiveAlFeCalculation.Fe_liq, 4)

            Next

            equation_line()
            PlotLineChart("% Al", "% Fe", litLineGraph, "divContainer", "plot1", "Fe-Al-Zn* Ternary Phase Diagram at " & ViewState("txtPotTemp") & " ℃", "Y Label")

            'PlotCurve()
            'equation_line()

        Catch ex As Exception

        End Try

    End Sub
    Dim arrSlope(25, 1) As Double
    Public Sub equation_line()
        Try

            'get slope
            Al_tot_old = ViewState("txtTotalAI")
            Fe_Tot_old = ViewState("txtTotalFE")
            Dim Slope_line As Decimal = (Fe_Tot_old - Fe_eff) / (Al_tot_old - Al_eff)

            Dim intercept As Decimal = Fe_Tot_old - Slope_line * Al_tot_old
            'chrtSolubilityCurve.Series.Add("Line")
            'chrtSolubilityCurve.Series("Line").ChartType = SeriesChartType.Line
            'chrtSolubilityCurve.Series("Line").Color = Color.Brown
            'chrtSolubilityCurve.Series("Line").BorderDashStyle = ChartDashStyle.Dash


            Dim y As Decimal = 0
            Dim x As Decimal = 0
            For i As Integer = 0 To 25
                y = y + i * 0.05
                x = (y - intercept) / Slope_line

                arrSlope(i, 0) = x
                arrSlope(i, 1) = y
                If x > 0.25 Then
                    Exit For
                End If
                'chrtSolubilityCurve.Series("Line").Points.AddXY(x, y)
                'chrtSolubilityCurve.Series("Line").ToolTip = " X Value : #VALX  Y Value : #VALY "
            Next

        Catch ex As Exception

        End Try

    End Sub
    Public Sub LoadValues()
        Try

            ViewState("txtTotalAI") = "0.1322"
            ViewState("txtTotalFE") = "0.0383"
            T_Bath_C = "460"
            T_Bath_K = T_Bath_C + 273.15

            Dim dsAlFeData As DataSet = objController.GetAlFeData("L")
            If dsAlFeData.Tables.Count > 0 Then
                Dim dtAlData As DataTable = dsAlFeData.Tables(0)
                Dim dtFeData As DataTable = dsAlFeData.Tables(1)

                If dtAlData.Rows.Count > 0 Then
                    ViewState("txtTotalAI") = dtAlData.Rows(0)("CLR_TEST_VALUE")

                    If CDec(dtAlData.Rows(0)("CLR_PARAM_MIN")) = 0.125 Then
                        ViewState("txtPotTemp") = "470"
                    ElseIf CDec(dtAlData.Rows(0)("CLR_PARAM_MIN")) = 0.165 Or CDec(dtAlData.Rows(0)("CLR_PARAM_MIN")) = 0.15 Then
                        ViewState("txtPotTemp") = "460"
                    End If

                    ViewState("lblSamplingDateAL") = CDate(dtAlData.Rows(0)("CLR_DT_SAMPLING_DATE")).ToString("yyyy-MM-dd HH:mm")
                End If
                If dtFeData.Rows.Count > 0 Then
                    ViewState("txtTotalFE") = dtFeData.Rows(0)("CLR_TEST_VALUE")
                    ViewState("lblSamplingDateAL") = CDate(dtFeData.Rows(0)("CLR_DT_SAMPLING_DATE")).ToString("yyyy-MM-dd HH:mm")
                End If
                'lblSamplingDateFE.Text = "Sampling Date " & CDate(dtAlData.Rows(0)("CLR_DT_SAMPLING_DATE")).ToString("dd-MMM-yyyy HH:mm:ss")
            End If

            Al_tot_old = ViewState("txtTotalAI")
            Fe_Tot_old = ViewState("txtTotalFE")

        Catch ex As Exception

        End Try
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                LoadValues()
                Dim fromdt As DateTime
                Dim todt As DateTime
                Dim dtt As DateTime
                dtt = CDate(ViewState("lblSamplingDateAL")).ToString("yyyy-MM-dd")
                If CInt(CDate(dtt).ToString("dd")) <= 5 Then
                    fromdt = Now.AddMonths(-1).ToString("yyyy-MM-") & "25"
                Else
                    fromdt = Now.ToString("yyyy-MM-") & "01"

                End If
                todt = Now.ToString("yyyy-MM-dd")


                'CreateGraph()
                TransitionGraph()
                EffectiveAlAndFeChart()
                POTStatusData()
                DrawChartTop("CLR_PROCESS_LINE = 'L' AND (CLR_PARAM_TEST in ('ZAAL','ZAGA','ZAZS') or CLR_PARAM_TEST in ('ZAFE'))", "Lab - Al & Fe", "first", Lit1, Lit3, fromdt.ToString("yyyy-MM-dd"), todt.ToString("yyyy-MM-dd"))

                DrawLine()
                DrawLine_Seconds()

                DrawPotTempChart()

            Catch ex As Exception

            End Try
        End If
    End Sub

    Sub DrawPotTempChart()
        Try
            Dim ds As DataTable = objController.GetPotTempData(DateTime.Now.AddDays(-3).ToString("yyyy-MM-dd HH:mm:ss"), DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"))
            objController.PlotLineChartForBathManagement(ds, "prm_ts_end", "PRM_ZINC_POT_TMP", litPot, "divControlChart", "plot5", "Pot Temp", "", 11)

        Catch ex As Exception

        End Try
       
    End Sub

    Sub DrawLine()
        Try

            Dim ds As DataSet = objController.LoadBathMgmtRejectionData(DateTime.Now.AddDays(-3).ToString("yyyy-MM-dd 06:00:00"), DateTime.Now.ToString("yyyy-MM-dd 06:00:00"))
            Dim xAxis, yAxis As String
            For i As Integer = 0 To ds.Tables(0).Rows.Count - 1
                xAxis &= ",'" & ds.Tables(0).Rows(i)(1) & "'"
                yAxis &= "," & ds.Tables(0).Rows(i)(0) & ""

            Next
            If xAxis = "" Then Return
            ' ddRejectioncontainer
            Dim s As New StringBuilder("")
            s.Append("<script>optionddRejectionContainer = {grid:{top:'5%'},tooltip:{trigger:'axis'},xAxis:{type:'category',data:[")
            s.Append(xAxis.Substring(1) & "]},yAxis:{type:'value'},series:[{data:[" & yAxis.Substring(1) & "],type:'line'}]};")
            s.Append("dd_Rejection = echarts.init(document.getElementById('ddRejectioncontainer'));")
            s.Append("dd_Rejection.setOption(optionddRejectionContainer);</script>")
            litddRejection.Text = s.ToString

            ' ddDailyParetoContainer
            DrawPareto(ds.Tables(1), litddDailyPareto, "ddDailyParetoContainer")
            Dim dtCumm As DataTable
            If ds.Tables(2).Rows.Count > 5 Then
                dtCumm = New DataTable
                dtCumm.Columns.Add("Wt", GetType(String))
                dtCumm.Columns.Add("CD_DESC", GetType(String))
                For c As Integer = 0 To cummCount - 1  'ds.Tables(2).Rows.Count - 1
                    dtCumm.Rows.Add(ds.Tables(2).Rows(c)(0), ds.Tables(2).Rows(c)(1))
                Next
                'Dim others As Double = 0.0
                'For c As Integer = cummCount To ds.Tables(2).Rows.Count - 1
                '    others += ds.Tables(2).Rows(c)(0)
                'Next
                'dtCumm.Rows.Add(others, "Others")
            Else
                dtCumm = ds.Tables(2)
            End If
            DrawPareto(dtCumm, litddCumulativePareto, "ddCumlParetoContainer")

        Catch ex As Exception

        End Try
    End Sub

    Sub DrawPareto(ByRef dt As DataTable, ByRef lit As Literal, ByVal containerName As String)
        Try

            Dim totWt As Double = dt.AsEnumerable().Sum(Function(row) Double.Parse(row.Field(Of String)("Wt"))) 'dt.Compute("Sum(Convert([wt],System.Double))", "")
            Dim res As String = "["
            Dim data_yaxis_left As String = "["
            Dim xaxis As String = "["
            Dim temp As Double = 0.0

            For r As Integer = 0 To dt.Rows.Count - 1
                If r > 0 Then
                    res &= ","
                    data_yaxis_left &= ","
                    xaxis &= ","
                End If
                temp += dt.Rows(r)(0)

                res &= Math.Round(temp * 100 / totWt, 2)
                data_yaxis_left &= dt.Rows(r)(0)
                xaxis &= "'" & dt.Rows(r)(1) & "'"
            Next
            res &= "]"
            data_yaxis_left &= "]"
            xaxis &= "]"
            Dim s As String = "<script>var res=" & res & ";var data_yaxis_left=" & data_yaxis_left & ";var xaxis=" & xaxis & ";option" & containerName & "={grid:{bottom:'35%',top:'5%'},tooltip:{trigger:'axis'},xAxis:[{type:'category',data:xaxis,axisLabel:{rotate:45,interval:0,margin:5}},{type:'category',boundaryGap:!0,data:[]}],yAxis:[{type:'value'},{axisLabel:{formatter:function(a){return a+'%'}},type:'value',max:100,min:0,splitLine:{show:false}}],series:[{name:'T',type:'bar',xAxisIndex:0,yAxisIndex:0,data:data_yaxis_left},{name:'%',yAxisIndex:1,data:res,type:'line',smooth:!0}]};"
            s &= containerName & "= echarts.init(document.getElementById('" & containerName & "'));"
            s &= containerName & ".setOption(option" & containerName & ");</script>"
            lit.Text = s

        Catch ex As Exception

        End Try
    End Sub


    Sub DrawLine_Seconds()
        Try

            Dim ds As DataSet = objController.LoadBathMgmtRejectionData_Seconds(DateTime.Now.AddDays(-3).ToString("yyyy-MM-dd 06:00:00"), DateTime.Now.ToString("yyyy-MM-dd 06:00:00"))
            Dim xAxis, yAxis As String
            For i As Integer = 0 To ds.Tables(0).Rows.Count - 1
                xAxis &= ",'" & ds.Tables(0).Rows(i)(1) & "'"
                yAxis &= "," & ds.Tables(0).Rows(i)(0) & ""

            Next
            If xAxis = "" Then Return
            ' ddRejectioncontainer
            Dim s As New StringBuilder("")
            s.Append("<script>optionContainer_RejSec = {grid:{top:'5%'},tooltip:{trigger:'axis'},xAxis:{type:'category',data:[")
            s.Append(xAxis.Substring(1) & "]},yAxis:{type:'value'},series:[{data:[" & yAxis.Substring(1) & "],type:'line'}]};")
            s.Append("Container_RejSec = echarts.init(document.getElementById('Container_RejSec'));")
            s.Append("Container_RejSec.setOption(optionContainer_RejSec);</script>")
            litRejectionSecond.Text = s.ToString

            ' ddDailyParetoContainer
            DrawPareto(ds.Tables(1), litSecondDailyPareto, "Container_DailyPareto")
            Dim dtCumm As DataTable
            If ds.Tables(2).Rows.Count > 5 Then
                dtCumm = New DataTable
                dtCumm.Columns.Add("Wt", GetType(String))
                dtCumm.Columns.Add("CD_DESC", GetType(String))
                For c As Integer = 0 To cummCount - 1  'ds.Tables(2).Rows.Count - 1
                    dtCumm.Rows.Add(ds.Tables(2).Rows(c)(0), ds.Tables(2).Rows(c)(1))
                Next
                'Dim others As Double = 0.0
                'For c As Integer = cummCount To ds.Tables(2).Rows.Count - 1
                '    others += ds.Tables(2).Rows(c)(0)
                'Next
                'dtCumm.Rows.Add(others, "Others")
            Else
                dtCumm = ds.Tables(2)
            End If
            DrawPareto(dtCumm, litSecondCumulativePareto, "Container_CumPareto")

        Catch ex As Exception

        End Try
    End Sub

    Sub DrawPareto_Seconds(ByRef dt As DataTable, ByRef lit As Literal, ByVal containerName As String)
        Try

            Dim totWt As Double = dt.AsEnumerable().Sum(Function(row) Double.Parse(row.Field(Of String)("Wt"))) 'dt.Compute("Sum(Convert([wt],System.Double))", "")
            Dim res As String = "["
            Dim data_yaxis_left As String = "["
            Dim xaxis As String = "["
            Dim temp As Double = 0.0

            For r As Integer = 0 To dt.Rows.Count - 1
                If r > 0 Then
                    res &= ","
                    data_yaxis_left &= ","
                    xaxis &= ","
                End If
                temp += dt.Rows(r)(0)

                res &= Math.Round(temp * 100 / totWt, 2)
                data_yaxis_left &= dt.Rows(r)(0)
                xaxis &= "'" & dt.Rows(r)(1) & "'"
            Next
            res &= "]"
            data_yaxis_left &= "]"
            xaxis &= "]"
            Dim s As String = "<script>var res=" & res & ";var data_yaxis_left=" & data_yaxis_left & ";var xaxis=" & xaxis & ";option" & containerName & "={grid:{bottom:'35%',top:'5%'},tooltip:{trigger:'axis'},xAxis:[{type:'category',data:xaxis,axisLabel:{rotate:45,interval:0,margin:5}},{type:'category',boundaryGap:!0,data:[]}],yAxis:[{type:'value'},{axisLabel:{formatter:function(a){return a+'%'}},type:'value',max:100,min:0,splitLine:{show:false}}],series:[{name:'T',type:'bar',xAxisIndex:0,yAxisIndex:0,data:data_yaxis_left},{name:'%',yAxisIndex:1,data:res,type:'line',smooth:!0}]};"
            s &= containerName & "= echarts.init(document.getElementById('" & containerName & "'));"
            s &= containerName & ".setOption(option" & containerName & ");</script>"
            lit.Text = s

        Catch ex As Exception

        End Try
    End Sub

    Sub EffectiveAlAndFeChart()
        Try
            Dim fromdt As DateTime
            Dim todt As DateTime
            Dim dtt As DateTime
            dtt = CDate(ViewState("lblSamplingDateAL")).ToString("yyyy-MM-dd")
            If CInt(CDate(dtt).ToString("dd")) <= 5 Then
                fromdt = Now.AddMonths(-1).ToString("yyyy-MM-") & "25"
            Else
                fromdt = Now.ToString("yyyy-MM-") & "01"

            End If
            todt = Now.ToString("yyyy-MM-dd")
            litChart.Text = ""
            Dim dt As DataTable = objController.GetZnBathTrendData(fromdt.ToString("yyyy-MM-dd"), todt.ToString("yyyy-MM-dd"))
            Dim query = From val In dt.AsEnumerable() Where val.Field(Of String)("CAMPAIGN") = "GI" Select val Order By val.Field(Of DateTime)("CZT_TIMESTAMP")
            Dim dtGI As DataTable
            If query.Count > 0 Then
                dtGI = query.CopyToDataTable
            Else
                dtGI = dt.Clone
            End If
            query = From val In dt.AsEnumerable() Where val.Field(Of String)("CAMPAIGN") = "GA" Select val Order By val.Field(Of DateTime)("CZT_TIMESTAMP")
            Dim dtGA As DataTable
            If query.Count > 0 Then
                dtGA = query.CopyToDataTable
            Else
                dtGA = dt.Clone
            End If
            'Below are the temporary datatables holding false record in between two rows having time difference of 24 hours or more.
            Dim dtGI_Temp As New DataTable
            dtGI_Temp.Columns.Add("CZT_EFF_AL", GetType(Decimal))
            dtGI_Temp.Columns.Add("CZT_EFF_FE", GetType(Decimal))
            dtGI_Temp.Columns.Add("CZT_TIMESTAMP", GetType(DateTime))
            dtGI_Temp.Columns.Add("CZT_CAMP_AL", GetType(String))
            dtGI_Temp.Columns.Add("CZT_POT_AL", GetType(Decimal))
            dtGI_Temp.Columns.Add("CZT_POT_FE", GetType(Decimal))
            dtGI_Temp.Columns.Add("CAMPAIGN", GetType(String))
            dtGI_Temp.Columns.Add("UCL", GetType(Decimal))
            dtGI_Temp.Columns.Add("LCL", GetType(Decimal))
            For i As Integer = 0 To dtGI.Rows.Count - 1
                Dim row As DataRow = dtGI_Temp.NewRow
                row("CZT_EFF_AL") = dtGI.Rows(i)("CZT_EFF_AL")
                row("CZT_EFF_FE") = dtGI.Rows(i)("CZT_EFF_FE")
                row("CZT_TIMESTAMP") = CDate(dtGI.Rows(i)("CZT_TIMESTAMP"))
                row("CZT_CAMP_AL") = dtGI.Rows(i)("CZT_CAMP_AL")
                row("CZT_POT_AL") = dtGI.Rows(i)("CZT_POT_AL")
                row("CZT_POT_FE") = dtGI.Rows(i)("CZT_POT_FE")
                row("CAMPAIGN") = dtGI.Rows(i)("CAMPAIGN")
                row("UCL") = dtGI.Rows(i)("UCL")
                row("LCL") = dtGI.Rows(i)("LCL")
                dtGI_Temp.Rows.Add(row)
                If i < dtGI.Rows.Count - 1 Then
                    Dim span As TimeSpan = DateTime.Parse(dtGI.Rows(i + 1)("CZT_TIMESTAMP")).Subtract(DateTime.Parse(dtGI.Rows(i)("CZT_TIMESTAMP")))
                    If span.TotalHours >= 24 Then
                        dtGI_Temp.Rows.Add(dtGI.Rows(i)("CZT_EFF_AL"), dtGI.Rows(i)("CZT_EFF_FE"), CDate(dtGI.Rows(i)("CZT_TIMESTAMP")).AddMinutes(10),
                                           dtGI.Rows(i)("CZT_CAMP_AL"), dtGI.Rows(i)("CZT_POT_AL"), dtGI.Rows(i)("CZT_POT_FE"), dtGI.Rows(i)("CAMPAIGN"), 0, 0)
                    End If
                End If
            Next

            Dim dtGA_Temp As New DataTable
            dtGA_Temp.Columns.Add("CZT_EFF_AL", GetType(Decimal))
            dtGA_Temp.Columns.Add("CZT_EFF_FE", GetType(Decimal))
            dtGA_Temp.Columns.Add("CZT_TIMESTAMP", GetType(DateTime))
            dtGA_Temp.Columns.Add("CZT_CAMP_AL", GetType(String))
            dtGA_Temp.Columns.Add("CZT_POT_AL", GetType(Decimal))
            dtGA_Temp.Columns.Add("CZT_POT_FE", GetType(Decimal))
            dtGA_Temp.Columns.Add("CAMPAIGN", GetType(String))
            dtGA_Temp.Columns.Add("UCL", GetType(Decimal))
            dtGA_Temp.Columns.Add("LCL", GetType(Decimal))
            For i As Integer = 0 To dtGA.Rows.Count - 1
                Dim row As DataRow = dtGA_Temp.NewRow
                row("CZT_EFF_AL") = dtGA.Rows(i)("CZT_EFF_AL")
                row("CZT_EFF_FE") = dtGA.Rows(i)("CZT_EFF_FE")
                row("CZT_TIMESTAMP") = CDate(dtGA.Rows(i)("CZT_TIMESTAMP"))
                row("CZT_CAMP_AL") = dtGA.Rows(i)("CZT_CAMP_AL")
                row("CZT_POT_AL") = dtGA.Rows(i)("CZT_POT_AL")
                row("CZT_POT_FE") = dtGA.Rows(i)("CZT_POT_FE")
                row("CAMPAIGN") = dtGA.Rows(i)("CAMPAIGN")
                row("UCL") = dtGA.Rows(i)("UCL")
                row("LCL") = dtGA.Rows(i)("LCL")
                dtGA_Temp.Rows.Add(row)
                If i < dtGA.Rows.Count - 1 Then
                    Dim span As TimeSpan = DateTime.Parse(dtGA.Rows(i + 1)("CZT_TIMESTAMP")).Subtract(DateTime.Parse(dtGA.Rows(i)("CZT_TIMESTAMP")))
                    If span.TotalHours >= 24 Then
                        dtGA_Temp.Rows.Add(dtGA.Rows(i)("CZT_EFF_AL"), dtGA.Rows(i)("CZT_EFF_FE"), CDate(dtGA.Rows(i)("CZT_TIMESTAMP")).AddMinutes(10),
                                           dtGA.Rows(i)("CZT_CAMP_AL"), dtGA.Rows(i)("CZT_POT_AL"), dtGA.Rows(i)("CZT_POT_FE"), dtGA.Rows(i)("CAMPAIGN"), 0, 0)
                    End If
                End If
            Next
            '---------------------------------------END OF TEMPORARY DATATABLES----------------------------------------------

            'Dim giUclDataPoints As String = "var GI_UCL = [['" & CDate(dtGI.Rows(0)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGI.Rows(0)("UCL") & "], ['" & CDate(dtGI.Rows(dtGI.Rows.Count - 1)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGI.Rows(dtGI.Rows.Count - 1)("UCL") & "]];"
            Dim giUclDataPoints As String = "var GI_UCL = [["
            For i As Integer = 0 To dtGI_Temp.Rows.Count - 1
                If i = dtGI_Temp.Rows.Count - 1 Then
                    giUclDataPoints &= "'" & CDate(dtGI_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGI_Temp.Rows(i)("UCL") = 0, "null", dtGI_Temp.Rows(i)("UCL")) & "]];"
                Else
                    giUclDataPoints &= "'" & CDate(dtGI_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGI_Temp.Rows(i)("UCL") = 0, "null", dtGI_Temp.Rows(i)("UCL")) & "], ["
                End If
            Next
            If dtGI_Temp.Rows.Count = 0 Then
                giUclDataPoints &= "]];"
            End If
            'Dim giLclDataPoints As String = "var GI_LCL = [['" & CDate(dtGI_Temp.Rows(0)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGI_Temp.Rows(0)("LCL") & "], ['" & CDate(dtGI_Temp.Rows(dtGI_Temp.Rows.Count - 1)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGI_Temp.Rows(dtGI_Temp.Rows.Count - 1)("LCL") & "]];"
            Dim giLclDataPoints As String = "var GI_LCL = [["
            For i As Integer = 0 To dtGI_Temp.Rows.Count - 1
                If i = dtGI_Temp.Rows.Count - 1 Then
                    giLclDataPoints &= "'" & CDate(dtGI_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGI_Temp.Rows(i)("LCL") = 0, "null", dtGI_Temp.Rows(i)("LCL")) & "]];"
                Else
                    giLclDataPoints &= "'" & CDate(dtGI_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGI_Temp.Rows(i)("LCL") = 0, "null", dtGI_Temp.Rows(i)("LCL")) & "], ["
                End If
            Next
            If dtGI_Temp.Rows.Count = 0 Then
                giLclDataPoints &= "]];"
            End If
            'Dim gaUclDataPoints As String = "var GA_UCL = [['" & CDate(dtGA.Rows(0)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGA.Rows(0)("UCL") & "], ['" & CDate(dtGA.Rows(dtGA.Rows.Count - 1)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGA.Rows(dtGA.Rows.Count - 1)("UCL") & "]];"
            Dim gaUclDataPoints As String = "var GA_UCL = [["
            For i As Integer = 0 To dtGA_Temp.Rows.Count - 1
                If i = dtGA_Temp.Rows.Count - 1 Then
                    gaUclDataPoints &= "'" & CDate(dtGA_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGA_Temp.Rows(i)("UCL") = 0, "null", dtGA_Temp.Rows(i)("UCL")) & "]];"
                Else
                    gaUclDataPoints &= "'" & CDate(dtGA_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGA_Temp.Rows(i)("UCL") = 0, "null", dtGA_Temp.Rows(i)("UCL")) & "], ["
                End If
            Next
            If dtGA_Temp.Rows.Count = 0 Then
                gaUclDataPoints &= "]];"
            End If
            'Dim gaLclDataPoints As String = "var GA_LCL = [['" & CDate(dtGA_Temp.Rows(0)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGA_Temp.Rows(0)("LCL") & "], ['" & CDate(dtGA_Temp.Rows(dtGA_Temp.Rows.Count - 1)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGA_Temp.Rows(dtGA_Temp.Rows.Count - 1)("LCL") & "]];"
            Dim gaLclDataPoints As String = "var GA_LCL = [["
            For i As Integer = 0 To dtGA_Temp.Rows.Count - 1
                If i = dtGA_Temp.Rows.Count - 1 Then
                    gaLclDataPoints &= "'" & CDate(dtGA_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGA_Temp.Rows(i)("LCL") = 0, "null", dtGA_Temp.Rows(i)("LCL")) & "]];"
                Else
                    gaLclDataPoints &= "'" & CDate(dtGA_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGA_Temp.Rows(i)("LCL") = 0, "null", dtGA_Temp.Rows(i)("LCL")) & "], ["
                End If
            Next
            If dtGA_Temp.Rows.Count = 0 Then
                gaLclDataPoints &= "]];"
            End If


            Dim min_time, max_time As String
            min_time = Format(dt.Rows(0)("CZT_TIMESTAMP"), "yyyy-MM-dd HH:mm")
            max_time = Format(dt.Rows(dt.Rows.Count - 1)("CZT_TIMESTAMP"), "yyyy-MM-dd HH:mm")

            Dim xTimestampVal(), y1EffectiveAlVal(), y2EffectiveFe() As String

            xTimestampVal = (From row In dt Select col = row("CZT_TIMESTAMP").ToString).ToArray
            y1EffectiveAlVal = (From row In dt Select col = row("CZT_EFF_AL").ToString).ToArray()
            y2EffectiveFe = (From row In dt Select col = row("CZT_EFF_FE").ToString).ToArray()

            'Dim Al_min As String = 0 'As per the Excel file.
            'Dim Al_max As String = 0.35 'As per the Excel file.
            'Dim Fe_min As String = 0 'As per the Excel file.
            'Dim Fe_max As String = 0.07 'As per the Excel file.
            Dim Al_min As String = 0 'Changed by mamta on 11-Jan-2018
            Dim Al_max As String = 0.3 'Changed by mamta on 11-Jan-2018
            Dim Fe_min As String = 0 'Changed by mamta on 11-Jan-2018
            Dim Fe_max As String = 0.05 'Changed by mamta on 11-Jan-2018

            Dim js = "<script language='javascript' type='text/javascript'>" & vbCrLf & _
                    "$(document).ready(function(){" & vbCrLf & _
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf & _
                    "var series= ['Effective Aluminium', 'Effective Iron', 'GI Limits', 'GA Limits']" & vbCrLf & _
                    "var data1 = [["
            For i = 0 To dt.Rows.Count - 1
                If i = xTimestampVal.Length - 1 Then
                    js &= "'" & DateTime.Parse(xTimestampVal.GetValue(i).ToString().Trim()).ToString("yyyy-MM-dd HH:mm") & "', " & y1EffectiveAlVal.GetValue(i).ToString().Trim() & "]]; " & vbCrLf
                Else
                    js &= "'" & DateTime.Parse(xTimestampVal.GetValue(i).ToString().Trim()).ToString("yyyy-MM-dd HH:mm") & "', " & y1EffectiveAlVal.GetValue(i).ToString().Trim() & "], ["
                End If
            Next


            js &= "var data2 = [["
            For i = 0 To dt.Rows.Count - 1
                If i = xTimestampVal.Length - 1 Then
                    js &= "'" & DateTime.Parse(xTimestampVal.GetValue(i).ToString().Trim()).ToString("yyyy-MM-dd HH:mm") & "', " & y2EffectiveFe.GetValue(i).ToString().Trim() & "]]; " & vbCrLf
                Else
                    js &= "'" & DateTime.Parse(xTimestampVal.GetValue(i).ToString().Trim()).ToString("yyyy-MM-dd HH:mm") & "', " & y2EffectiveFe.GetValue(i).ToString().Trim() & "], ["
                End If
            Next

            js &= vbCrLf & vbCrLf & giLclDataPoints & vbCrLf & vbCrLf & giUclDataPoints & vbCrLf & vbCrLf & gaLclDataPoints & vbCrLf & vbCrLf & gaUclDataPoints & vbCrLf & vbCrLf

            Dim EffAl_Series As String = "{pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:80px; width:180px; background-color:#0D5CA5; font-weight:bold; font-size:x-large; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td><center>%s</center></td></tr></table>'}}"
            Dim EffFe_Series As String = "{pointLabels: { show:false }, showLine: true, yaxis:'y2axis', lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:80px; width:180px; background-color:#BC2318; font-weight:bold; font-size:x-large; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td><center>%s</center></td></tr></table>'}}"
            Dim GI_Limit_Series As String = "{pointLabels:{show:!1},showLine:!0,lineWidth:2,breakOnNull: true,linePattern:'dashed',showMarker:!1,color:'#00FF19',highlighter:{show:!0,showMarker:!1,tooltipAxes:'xy',yvalues:2,formatString:'<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
            Dim GA_Limit_Series As String = "{pointLabels:{show:!1},showLine:!0,lineWidth:2,breakOnNull: true,linePattern:'dashed',showMarker:!1,color:'#000000',highlighter:{show:!0,showMarker:!1,tooltipAxes:'xy',yvalues:2,formatString:'<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"

            js &= "opts = {" & vbCrLf & _
            "title: 'Calculated Effective Al & Fe'," & vbCrLf & _
            "series:[" & EffAl_Series & ", " & EffFe_Series & ", " & GI_Limit_Series & ", " & GI_Limit_Series & ", " & GA_Limit_Series & ", " & GA_Limit_Series & "]," & vbCrLf & _
            "seriesColors: ['#0D5CA5', '#BC2318']," & vbCrLf & _
            "axesDefaults: {" & vbCrLf & _
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf & _
            "tickOptions: {" & vbCrLf & _
            "fontSize:'8pt'" & vbCrLf & _
            "}" & vbCrLf & _
            "}," & vbCrLf & _
            "axes: {" & vbCrLf & _
            "xaxis: {" & vbCrLf & _
            "min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf & _
            "renderer:$.jqplot.DateAxisRenderer," & vbCrLf & _
            "tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," & vbCrLf & _
            "//tickInterval:'1 hour'," & vbCrLf & _
            "pad:0" & vbCrLf & _
            "}," & vbCrLf & _
            "yaxis: { " & vbCrLf & _
            "tickOptions: { formatString: '%.3f' }," & vbCrLf & _
            "min: " & Al_min & "," & vbCrLf & _
            "max: " & Al_max & "," & vbCrLf & _
            "//autoscale:true," & vbCrLf & _
            "label: '% Effective Al'," & vbCrLf & _
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf & _
            "}," & vbCrLf & _
            "y2axis: { " & vbCrLf & _
            "tickOptions: { formatString: '%.3f' }," & vbCrLf & _
            "min: " & Fe_min & "," & vbCrLf & _
            "max: " & Fe_max & "," & vbCrLf & _
            "//autoscale:true," & vbCrLf & _
            "//tickOptions:{showGridline:false}," & vbCrLf & _
            "label: '% Effective Fe'," & vbCrLf & _
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf & _
            "}" & vbCrLf & _
            "}," & vbCrLf & _
            "cursor: {" & vbCrLf & _
            "zoom: true" & vbCrLf & _
            "}," & vbCrLf & _
            "//highlighter: { show: 'true', tooltipFormatString: '%.1f', useAxesFormatters: false }," & vbCrLf & _
            "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf & _
            "legend: {" & vbCrLf & _
            "show: true," & vbCrLf & _
            "location: 's'," & vbCrLf & _
            "labels: series," & vbCrLf & _
            "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf & _
            "placement: 'outsideGrid'," & vbCrLf & _
            "rendererOptions: {" & vbCrLf & _
            "numberRows: 1," & vbCrLf & _
            "numberColumns: 2," & vbCrLf & _
            "marginTop: 10" & vbCrLf & _
            "}" & vbCrLf & _
            "}" & vbCrLf & _
            "};" & vbCrLf & _
            "plot2 = $.jqplot('divContainer1', [data1, data2, GI_UCL, GI_LCL, GA_UCL, GA_LCL], opts);" & vbCrLf & _
            "});" & vbCrLf & _
            "</script>" & vbCrLf

            litChart.Text = js
        Catch ex As Exception

        End Try
    End Sub
    
    Public Sub PlotLineChart(ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal,
                             ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String)
        Try

            LiteralName.Text = ""
            Dim min_time, max_time As String
            min_time = 0.08
            max_time = 0.26

            'Dim yVal() As Decimal
            'yVal = (From row In dt Select col = CDec(row(YAxisColName))).ToArray()

            Dim y_min As String = 0.0
            Dim y_max As String = 0.06

            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf & _
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf & _
                    "  $('#resizable').resizable({delay:20});" & _
                    " $('#resizable').bind('resize', function(event, ui) {test.replot( { resetAxes: false } ); }); "

            'dt.DefaultView.RowFilter = ""
            'Dim dvDefault As DataView = dt.DefaultView
            Dim bottomLineDataForLeftBox As String = "var bottomLineDataForLeftBox = [[0.125, 0.038], [0.135, 0.038]];"
            Dim rightLineDataForLeftBox As String = "var rightLineDataForLeftBox = [[0.135, 0.038], [0.135, 0.048]];"
            Dim topLineDataForLeftBox As String = "var topLineDataForLeftBox = [[0.135, 0.048], [0.125, 0.048]];"
            Dim leftLineDataForLeftBox As String = "var leftLineDataForLeftBox = [[0.125, 0.048], [0.125, 0.038]];"

            Dim bottomLineDataForRightBox As String = "var bottomLineDataForRightBox = [[0.185, 0.016], [0.205, 0.016]];"
            Dim rightLineDataForRightBox As String = "var rightLineDataForRightBox = [[0.205, 0.016], [0.205, 0.020]];"
            Dim topLineDataForRightBox As String = "var topLineDataForRightBox = [[0.205, 0.020], [0.185, 0.020]];"
            Dim leftLineDataForRightBox As String = "var leftLineDataForRightBox = [[0.185, 0.020], [0.185, 0.016]];"

            Dim flag As Boolean = False
            Dim boolCheckData As Boolean = False
            js &= vbCrLf
            For i As Integer = 0 To objEffectiveAlFeCalculation.dict.Count - 1
                boolCheckData = False
                js &= vbCrLf
                js &= "var line" & (i + 1).ToString & " = ["

                Dim arrData() As Double = objEffectiveAlFeCalculation.dict(i)

                Dim left As Object = 0
                For j As Integer = 0 To UBound(objEffectiveAlFeCalculation.dict(i))
                    If arrData(j) <= 0 Then
                        Continue For
                    End If

                    If boolCheckData = True Then
                        js &= ","
                    End If

                    js &= "["

                    If i = 0 Then
                        If j < 10 Then
                            js &= "" & objEffectiveAlFeCalculation.arrAl_Liq(j) & ", " & arrData(j) & ",'a'"
                        Else
                            js &= "" & objEffectiveAlFeCalculation.arrAl_Liq(j) & ", " & arrData(j) & ",'b'"

                        End If
                    ElseIf i = 3 Then
                        If left = 0 Then
                            left = (165 / 0.056) * objEffectiveAlFeCalculation.arrAl_Liq(j) 'To calculate the left position of the label placed in the CONODE area.
                            litLabelPosition.Text = "<script type='text/javascript'>document.getElementById('divLabel3').style.top = '50px'; document.getElementById('divLabel3').style.left = '" & left & "px';</script>"
                        End If
                        js &= "" & objEffectiveAlFeCalculation.arrAl_Liq(j) & ", " & arrData(j) & ",'c'"
                    Else
                        js &= "" & objEffectiveAlFeCalculation.arrAl_Liq(j) & ", " & arrData(j) & ",'c'"
                    End If

                    js &= "]"
                    boolCheckData = True
                Next

                js &= "];" & vbCrLf
                flag = True
            Next
            'Till here four lines are created

            boolCheckData = False
            js &= vbCrLf
            js &= "var line" & (objEffectiveAlFeCalculation.dict.Count + 1).ToString & " = ["
            For j As Integer = 0 To 25
                If boolCheckData = True Then
                    js &= ","
                End If

                js &= "["

                js &= "" & arrSlope(j, 0) & ", " & arrSlope(j, 1)

                js &= "]"
                boolCheckData = True

            Next
            js &= "];" & vbCrLf
            flag = True
            js &= vbCrLf
            js &= "var line" & (objEffectiveAlFeCalculation.dict.Count + 2).ToString & " = ["
            js &= "["
            js &= "" & ViewState("txtTotalAI") & ", " & ViewState("txtTotalFE")
            js &= "]"
            js &= "];" & vbCrLf
            js &= vbCrLf
            js &= "var line" & (objEffectiveAlFeCalculation.dict.Count + 3).ToString & " = ["
            js &= "["
            js &= "" & ViewState("txtAIEffective") & ", " & ViewState("txtFEEffective")
            js &= "]"
            js &= "];" & vbCrLf
            js &= vbCrLf
            js &= "var line" & (objEffectiveAlFeCalculation.dict.Count + 4).ToString & " = ["
            js &= "["
            js &= "" & ViewState("txtTotalAI") & ", " & ViewState("txtTotalFE")
            js &= "],"
            js &= "["
            js &= "" & ViewState("txtTotalAI") & ", " & 0
            js &= "]"
            js &= "];" & vbCrLf
            js &= vbCrLf
            js &= "var line" & (objEffectiveAlFeCalculation.dict.Count + 5).ToString & " = ["
            js &= "["
            js &= "" & ViewState("txtTotalAI") & ", " & ViewState("txtTotalFE")
            js &= "],"
            js &= "["
            js &= "" & 0 & ", " & ViewState("txtTotalFE")
            js &= "]"
            js &= "];" & vbCrLf
            js &= vbCrLf

            '----------------------------------------------------------------------------------------------------------------------------
            js &= bottomLineDataForLeftBox & vbCrLf & rightLineDataForLeftBox & vbCrLf & topLineDataForLeftBox & vbCrLf & leftLineDataForLeftBox & vbCrLf
            js &= bottomLineDataForRightBox & vbCrLf & rightLineDataForRightBox & vbCrLf & topLineDataForRightBox & vbCrLf & leftLineDataForRightBox & vbCrLf

            Dim boxSeries As String = "{pointLabels: { show:false }, showLine:true, lineWidth:2, color: '#0B9126', markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: true,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold; font-size:12px;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
            '----------------------------------------------------------------------------------------------------------------------------

            Dim strg As String = ""
            Dim strseries As String = ""

            If flag Then
                strg = "[line1"
                strseries = " {pointLabels:{ show:false, location:'s'}, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: true,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
                For i As Integer = 1 To objEffectiveAlFeCalculation.dict.Count + 4 '- 1 'dtGrades.Rows.Count - 1
                    strg = strg + ",line" & i + 1

                    If i = 4 Or i = 7 Or i = 8 Then
                        strseries = strseries + ", {pointLabels: { show:false }, showLine:true, lineWidth:1, linePattern: 'dashed',  markerOptions:{ size: 5 }, highlighter: {show: false,showMarker: true,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
                    ElseIf i >= 5 Then
                        strseries = strseries + ", {pointLabels: { show:false }, neighborThreshold: 0, showLine:false, showMarker:true, markerOptions: { style:'X' }}"

                    Else
                        strseries = strseries + ", {pointLabels: { show:false }, showLine:true, lineWidth:3, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: true,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
                    End If

                Next
                strseries = strseries & ", " & boxSeries & ", " & boxSeries & ", " & boxSeries & ", " & boxSeries & ", " & boxSeries & ", " & boxSeries & ", " & boxSeries & ", " & boxSeries
                strg &= ", bottomLineDataForLeftBox, rightLineDataForLeftBox, topLineDataForLeftBox, leftLineDataForLeftBox, bottomLineDataForRightBox, rightLineDataForRightBox, topLineDataForRightBox, leftLineDataForRightBox"
                strg &= "]"
            End If

            js &= "var seriesName = ['"
            Dim str As String = ""
            Dim testarr() As String = {"line1", "line2", "line3", "line4", "line5", "line6", "line7", "line8", "line9"}
            For i As Integer = 0 To objEffectiveAlFeCalculation.dict.Count - 1
                str &= testarr(i) & "', '"
            Next
            str = str.Remove(str.LastIndexOf(", '"))

            str &= "];"
            js &= str

            js &= "opts = {" & vbCrLf & _
            "title: '" & ChartTitle & "'," & vbCrLf & _
            "seriesDefaults: { pointLabels: { show:false }, showMarker:false, rendererOptions: {showDataLabels: true, dataLabels:  'label', diameter: 250, dataLabelPositionFactor: 0.5,sliceMargin: 3,color:'#DCDCDC' } }," & _
            "series:[" & strseries & "]," & vbCrLf & _
            "//seriesColors: ['#FFA500']," & vbCrLf & _
            "axesDefaults: {" & vbCrLf & _
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf & _
            "tickOptions: {" & vbCrLf & _
            "fontSize:'8pt'" & vbCrLf & _
            "}" & vbCrLf & _
            "}," & vbCrLf & _
            "axes: {" & vbCrLf & _
            "xaxis: {" & vbCrLf & _
            "min: 0.0800, max: 0.2600," & vbCrLf & _
            "label: '" & XAxisColName & "'," & vbCrLf & _
            "//labelRenderer: $.jqplot.CanvasAxisLabelRenderer," & vbCrLf & _
            "//renderer:$.jqplot.EnhancedLegendRenderer," & vbCrLf & _
            "tickOptions:{formatString:'', angle: -40}," & vbCrLf & _
            "tickInterval:0.005," & vbCrLf & _
            "//numberTicks: 0.0001," & vbCrLf & _
            "pad:0" & vbCrLf & _
            "}," & vbCrLf & _
            "yaxis: { " & vbCrLf & _
            "//tickOptions: { formatString: '%.3f' }," & vbCrLf & _
            "min: " & y_min & "," & vbCrLf & _
            "max: " & y_max & "," & vbCrLf & _
            "//autoscale:true," & vbCrLf & _
             "tickOptions:{formatString:'', angle: -30}," & vbCrLf & _
            "tickInterval:0.005," & vbCrLf & _
            "label: '" & YAxisColName & "'," & vbCrLf & _
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf & _
            "}" & vbCrLf & _
            "}," & vbCrLf & _
            "cursor: {" & vbCrLf & _
            "showTooltip: false," & vbCrLf & _
            "zoom: true" & vbCrLf & _
            "}," & vbCrLf & _
            "animate: true," & vbCrLf & _
            "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf & _
            "};" & vbCrLf & _
            "" & PlotName & " = $.jqplot('" & ContainerName & "', " & strg & ", opts);" & vbCrLf & _
            "</script>" & vbCrLf

            litLineGraph.Text = js
        Catch ex As Exception

        End Try
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)

    End Sub
    Protected Sub btnDownload_Click(sender As Object, e As System.EventArgs) Handles btnDownload.Click
        Try

            Dim pdfDoc As New Document(PageSize.A4, 10.0F, 10.0F, 10.0F, 0.0F)
            Dim writer As PdfWriter = PdfWriter.GetInstance(pdfDoc, Response.OutputStream)

            pdfDoc.Open()
            Dim base64 As String = hf1.Value.Replace("data:image/png;base64,", "")
            Dim im As Image = Image.GetInstance(Convert.FromBase64String(base64))
            Dim im1 As Image = Image.GetInstance(Convert.FromBase64String(hf2.Value.Replace("data:image/png;base64,", "")))
            Dim im2 As Image = Image.GetInstance(Convert.FromBase64String(hf3.Value.Replace("data:image/png;base64,", "")))
            Dim im3 As Image = Image.GetInstance(Convert.FromBase64String(hf4.Value.Replace("data:image/png;base64,", "")))
            Dim im4 As Image = Image.GetInstance(Convert.FromBase64String(hf5.Value.Replace("data:image/png;base64,", "")))
            Dim im5 As Image = Image.GetInstance(Convert.FromBase64String(hf6.Value.Replace("data:image/png;base64,", "")))
            Dim im6 As Image = Image.GetInstance(Convert.FromBase64String(hf7.Value.Replace("data:image/png;base64,", "")))
            Dim im7 As Image = Image.GetInstance(Convert.FromBase64String(hf8.Value.Replace("data:image/png;base64,", "")))
            Dim im8 As Image = Image.GetInstance(Convert.FromBase64String(hf9.Value.Replace("data:image/png;base64,", "")))
            Dim im9 As Image = Image.GetInstance(Convert.FromBase64String(hf10.Value.Replace("data:image/png;base64,", "")))
            Dim blackHead = New Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.BLACK)
            Dim blackSubHead = New Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.BLACK)
            Dim h1 = New Paragraph(New Chunk("Bath Management Report", blackHead))
            h1.Alignment = 1
            pdfDoc.Add(h1)
            Dim h2 = New Paragraph(New Chunk("Date: " & DateTime.Now.ToString("dd-MMM-yyyy"), blackSubHead))
            h2.Alignment = 1
            pdfDoc.Add(h2)
            Dim c() As Single = {12, 12}
            Dim table As New PdfPTable(c)
            table.WidthPercentage = 100

            Dim cell1 As New PdfPCell(im, True)
            cell1.Border = 0
            cell1.Padding = 20

            Dim cell2 As New PdfPCell(im1, True)
            cell2.Border = 0
            cell2.Padding = 20

            Dim cella3 As New PdfPCell(im9, True)
            cella3.Border = 0
            cella3.Padding = 20

            Dim celld3 As New PdfPCell()
            cella3.Border = 0
            cella3.Padding = 20

            Dim cell3 As New PdfPCell(im2, True)
            cell3.Border = 0
            cell3.Padding = 20

            Dim cell4 As New PdfPCell()
            cell4.Border = 0
            cell4.Padding = 0
            cell4.PaddingTop = 20





            Dim red = New Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL, BaseColor.RED)
            Dim black = New Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL, BaseColor.BLACK)
            Dim blue = New Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.BLUE)
            'If dgv.Rows.Count > 0 OrElse dgv2.Rows.Count > 0 Then
            Dim h = New Paragraph("POT Status")
            h.Alignment = 1
            cell4.AddElement(h)
            Dim l = New Paragraph(New Chunk(lblPotCount.Text & " - " & lblPotCount1.Text, red))
            l.Alignment = 1

            cell4.AddElement(l)
            'End If



            If dgv3.Rows.Count > 0 Then

                Dim table3 As New PdfPTable({1.1, 1.9, 1.0})
                table3.AddCell(New Phrase("Coil ID", blue))
                table3.AddCell(New Phrase("DateTime", blue))
                table3.AddCell(New Phrase("POT Temp", blue))


                For row As Integer = 0 To dgv3.Rows.Count - 1
                    For col As Integer = 0 To dgv3.Columns.Count - 1
                        Dim cell As PdfPCell = New PdfPCell(New Phrase(dgv3.Rows(row).Cells(col).Text, black))
                        cell.PaddingTop = 5
                        cell.PaddingBottom = 5
                        cell.PaddingLeft = 2
                        table3.AddCell(cell)
                    Next
                Next
                table3.SpacingBefore = 10
                cell4.AddElement(table3)

            End If
            table.AddCell(cell3)
            table.AddCell(cell2)
            table.AddCell(cella3)
            table.AddCell(cell1)
            table.AddCell(cell4)
            table.AddCell(celld3)
            table.SpacingBefore = 10
            pdfDoc.Add(table)

            'Dim crej = New Chunk("Diversion + Down gradation (Tonne)", blackSubHead)
            'crej.SetBackground(New BaseColor(241, 245, 249))

            'Dim prej = New Paragraph(crej)
            'pdfDoc.Add(crej)
            Dim crejPer() As Single = {12, 12, 12}

            Dim tablerejS As New PdfPTable(crejPer)
            tablerejS.WidthPercentage = 100
            tablerejS.SpacingBefore = 20
            tablerejS.KeepTogether = True

            Dim c0rejS As New PdfPCell(New Phrase("Rejection-Seconds (Tonne)", blackSubHead))
            c0rejS.Padding = 6
            c0rejS.BackgroundColor = New BaseColor(149, 183, 93)
            c0rejS.HorizontalAlignment = Element.ALIGN_CENTER
            c0rejS.Colspan = 3
            tablerejS.AddCell(c0rejS)


            Dim c1rejS As New PdfPCell(New Phrase("Rejection-Seconds (Tonne)"))
            c1rejS.Border = 0
            c1rejS.Padding = 20
            c1rejS.HorizontalAlignment = Element.ALIGN_CENTER

            Dim c2rejS As New PdfPCell(New Phrase("Daily Pareto"))
            c2rejS.Border = 0
            c2rejS.Padding = 20
            c2rejS.HorizontalAlignment = Element.ALIGN_CENTER

            Dim c3rejS As New PdfPCell(New Phrase("Cummulative Pareto"))
            c3rejS.Border = 0
            c3rejS.Padding = 20
            c3rejS.HorizontalAlignment = Element.ALIGN_CENTER

            Dim c4rejS As New PdfPCell(im6, True)
            c4rejS.Border = 0
            c4rejS.Padding = 20

            Dim c5rejS As New PdfPCell(im7, True)
            c5rejS.Border = 0
            c5rejS.Padding = 20

            Dim c6rejS As New PdfPCell(im8, True)
            c6rejS.Border = 0
            c6rejS.Padding = 20

            tablerejS.AddCell(c1rejS)
            tablerejS.AddCell(c2rejS)
            tablerejS.AddCell(c3rejS)
            tablerejS.AddCell(c4rejS)
            tablerejS.AddCell(c5rejS)
            tablerejS.AddCell(c6rejS)

            pdfDoc.Add(tablerejS)

            Dim tablerej As New PdfPTable(crejPer)
            tablerej.WidthPercentage = 100
            tablerej.SpacingBefore = 20
            tablerej.KeepTogether = True

            Dim c0rej As New PdfPCell(New Phrase("Diversion + Down gradation (Tonne)", blackSubHead))
            c0rej.Padding = 6
            c0rej.BackgroundColor = New BaseColor(149, 183, 93)
            c0rej.HorizontalAlignment = Element.ALIGN_CENTER
            c0rej.Colspan = 3
            tablerej.AddCell(c0rej)


            Dim c1rej As New PdfPCell(New Phrase("Rejection-Tonnage"))
            c1rej.Border = 0
            c1rej.Padding = 20
            c1rej.HorizontalAlignment = Element.ALIGN_CENTER

            Dim c2rej As New PdfPCell(New Phrase("Daily Pareto"))
            c2rej.Border = 0
            c2rej.Padding = 20
            c2rej.HorizontalAlignment = Element.ALIGN_CENTER

            Dim c3rej As New PdfPCell(New Phrase("Cummulative Pareto"))
            c3rej.Border = 0
            c3rej.Padding = 20
            c3rej.HorizontalAlignment = Element.ALIGN_CENTER

            Dim c4rej As New PdfPCell(im3, True)
            c4rej.Border = 0
            c4rej.Padding = 20

            Dim c5rej As New PdfPCell(im4, True)
            c5rej.Border = 0
            c5rej.Padding = 20

            Dim c6rej As New PdfPCell(im5, True)
            c6rej.Border = 0
            c6rej.Padding = 20

            tablerej.AddCell(c1rej)
            tablerej.AddCell(c2rej)
            tablerej.AddCell(c3rej)
            tablerej.AddCell(c4rej)
            tablerej.AddCell(c5rej)
            tablerej.AddCell(c6rej)

            pdfDoc.Add(tablerej)

            pdfDoc.Close()

            Response.ContentType = "application/pdf"
            Response.AddHeader("content-disposition", "attachment;filename=export.pdf")
            Response.Cache.SetCacheability(HttpCacheability.NoCache)
            Response.Write(pdfDoc)
            Response.End()

        Catch ex As Exception

        End Try
    End Sub
    Sub TransitionGraph()
        Try

            Dim fromdt As DateTime
            Dim todt As DateTime
            todt = Now.ToString("yyyy-MM-dd 06:00:00")
            fromdt = Now.AddDays(-1).ToString("yyyy-MM-dd 06:00:00")
            'lblError.Text = ""
            'Al Effective
            '###########################
            ' Dim objEffectiveAlFeCalculation As New EffectiveAlFeCalculation
            Al_tot_old = ViewState("txtTotalAI")
            Fe_Tot_old = ViewState("txtTotalFE")
            T_Bath_C = "460"
            T_Bath_K = "460" + 273.15

            objEffectiveAlFeCalculation.Main(T_Bath_C, T_Bath_K)
            ViewState("txtAITriplePoint") = Math.Round(objEffectiveAlFeCalculation.Al_trip, 4)
            ViewState("txtFETriplePoint") = Math.Round(objEffectiveAlFeCalculation.Fe_trip, 4)

            'objEffectiveAlFeCalculation.mtdEffectivAlFeCal(Al_tot_old, T_Bath_K, objEffectiveAlFeCalculation.Al_trip, objEffectiveAlFeCalculation.Fe_trip)
            objEffectiveAlFeCalculation.Aleffcal(Al_tot_old, Fe_Tot_old)

            ViewState("txtAITriplePoint") = Math.Round(objEffectiveAlFeCalculation.Al_trip, 4)
            ViewState("txtFETriplePoint") = Math.Round(objEffectiveAlFeCalculation.Fe_trip, 4)
            Al_eff = Math.Round(objEffectiveAlFeCalculation.Al_liq, 4)
            If Al_eff = 0 Then
                litLineGraph.Text = ""
                'txtAIEffective.Text = ""
                'txtFEEffective.Text = ""
                'txtAITriplePoint.Text = ""
                'txtFETriplePoint.Text = ""
                'lblError.Text = "Inappropriate values for Total AL or Total FE."
                'UserMsgBox("Inappropriate values for Total AL or Total FE.")
                Exit Sub
            End If
            ViewState("txtAIEffective") = Al_eff

            Fe_eff = Math.Round(objEffectiveAlFeCalculation.Fe_liq, 4)
            ViewState("txtFEEffective") = Fe_eff
            '###########################


            'Dim objEffectiveAlFeCalculation As New EffectiveAlFeCalculation
            Al_tot_old = ViewState("txtTotalAI")

            Dim AL_St_pnt, Fe_St_pnt, AL_End_pnt, Fe_End_pnt, Al_increment As Double
            AL_St_pnt = 0.08
            Fe_St_pnt = 0.0
            AL_End_pnt = 0.26
            Fe_End_pnt = 0.05
            Dim no_iteration As Integer
            no_iteration = (AL_End_pnt - AL_St_pnt) * 10000 + 1
            Al_increment = 0.0001
            ReDim Preserve arrSolCurve_Al(no_iteration - 1)
            ReDim Preserve arrSolCurve_Fe(no_iteration - 1)
            For i As Integer = 0 To no_iteration - 1
                Al_tot_old = Math.Round(AL_St_pnt + i * Al_increment, 4)

                objEffectiveAlFeCalculation.mtdEffectivAlFeCal(Al_tot_old, T_Bath_K, objEffectiveAlFeCalculation.Al_trip, objEffectiveAlFeCalculation.Fe_trip)
                arrSolCurve_Al(i) = Al_tot_old
                arrSolCurve_Fe(i) = Math.Round(objEffectiveAlFeCalculation.Fe_liq, 4)

            Next

            Dim dt As New DataTable
            equation_line()
            PlotLineChart(dt, "% Al", "% Fe", litLineGraph, "divContainer", "plot3", "Fe-Al-Zn* Ternary Phase Diagram at " & ViewState("txtPotTemp") & " ℃", "Y Label", fromdt.ToString("yyyy-MM-dd"), todt.ToString("yyyy-MM-dd"))

            'PlotCurve()
            'equation_line()

        Catch ex As Exception

        End Try

    End Sub
    Public Sub PlotLineChart(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal LiteralName As Literal,
                             ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String,
                             ByVal Trans_From_Date As String, ByVal Trans_To_Date As String)
        Try
            LiteralName.Text = ""

            Dim dtTransitionData As DataTable = objController.GetZnBathTrendData(Trans_From_Date, Trans_To_Date)
            Dim arrEffAl_X() As Decimal = (From row In dtTransitionData Select col = CDec(row("CZT_POT_AL"))).ToArray()
            Dim arrEffFe_Y() As Decimal = (From row In dtTransitionData Select col = CDec(row("CZT_POT_FE"))).ToArray()

            Dim min_time, max_time As String
            min_time = 0.08
            max_time = 0.26

            Dim yVal() As Decimal
            yVal = (From row In dt Select col = CDec(row(YAxisColName))).ToArray()

            Dim y_min As String = 0.0
            Dim y_max As String = 0.06

            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf & _
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf & _
                    "  $('#resizable').resizable({delay:20});" & _
                    " $('#resizable').bind('resize', function(event, ui) {test.replot( { resetAxes: false } ); }); "

            Dim bottomLineDataForLeftBox As String = "var bottomLineDataForLeftBox = [[0.125, 0.038], [0.135, 0.038]];"
            Dim rightLineDataForLeftBox As String = "var rightLineDataForLeftBox = [[0.135, 0.038], [0.135, 0.048]];"
            Dim topLineDataForLeftBox As String = "var topLineDataForLeftBox = [[0.135, 0.048], [0.125, 0.048]];"
            Dim leftLineDataForLeftBox As String = "var leftLineDataForLeftBox = [[0.125, 0.048], [0.125, 0.038]];"

            Dim bottomLineDataForRightBox As String = "var bottomLineDataForRightBox = [[0.185, 0.016], [0.205, 0.016]];"
            Dim rightLineDataForRightBox As String = "var rightLineDataForRightBox = [[0.205, 0.016], [0.205, 0.020]];"
            Dim topLineDataForRightBox As String = "var topLineDataForRightBox = [[0.205, 0.020], [0.185, 0.020]];"
            Dim leftLineDataForRightBox As String = "var leftLineDataForRightBox = [[0.185, 0.020], [0.185, 0.016]];"

            dt.DefaultView.RowFilter = ""
            Dim dvDefault As DataView = dt.DefaultView
            Dim flag As Boolean = False

            Dim boolCheckData As Boolean = False
            js &= vbCrLf
            For i As Integer = 0 To objEffectiveAlFeCalculation.dict.Count - 1
                boolCheckData = False
                js &= vbCrLf
                js &= "var line" & (i + 1).ToString & " = ["

                Dim arrData() As Double = objEffectiveAlFeCalculation.dict(i)

                Dim left As Object = 0
                For j As Integer = 0 To UBound(objEffectiveAlFeCalculation.dict(i))
                    If arrData(j) <= 0 Then
                        Continue For
                    End If

                    If boolCheckData = True Then
                        js &= ","
                    End If

                    js &= "["

                    If i = 0 Then
                        If j < 10 Then
                            js &= "" & objEffectiveAlFeCalculation.arrAl_Liq(j) & ", " & arrData(j) & ",'a'"
                        Else
                            js &= "" & objEffectiveAlFeCalculation.arrAl_Liq(j) & ", " & arrData(j) & ",'b'"

                        End If
                    ElseIf i = 3 Then
                        If left = 0 Then
                            left = (115 / 0.056) * objEffectiveAlFeCalculation.arrAl_Liq(j) 'To calculate the left position of the label placed in the CONODE area.
                            litLabelPosition.Text = "<script type='text/javascript'>document.getElementById('divLabel3').style.top = '50px'; document.getElementById('divLabel3').style.left = '" & left & "px';</script>"
                        End If
                        js &= "" & objEffectiveAlFeCalculation.arrAl_Liq(j) & ", " & arrData(j) & ",'c'"
                    Else
                        js &= "" & objEffectiveAlFeCalculation.arrAl_Liq(j) & ", " & arrData(j) & ",'c'"
                    End If

                    js &= "]"
                    boolCheckData = True
                Next

                js &= "];" & vbCrLf
                flag = True
            Next
            'Till here four lines are created

            boolCheckData = False
            js &= vbCrLf
            js &= "var line" & (objEffectiveAlFeCalculation.dict.Count + 1).ToString & " = ["
            For j As Integer = 0 To 25
                If boolCheckData = True Then
                    js &= ","
                End If

                js &= "["

                js &= "" & arrSlope(j, 0) & ", " & arrSlope(j, 1)

                js &= "]"
                boolCheckData = True

            Next
            js &= "];" & vbCrLf
            flag = True
            js &= vbCrLf
            js &= "var line" & (objEffectiveAlFeCalculation.dict.Count + 2).ToString & " = ["
            js &= "["
            js &= "" & ViewState("txtTotalAI") & ", " & ViewState("txtTotalFE")
            js &= "]"
            js &= "];" & vbCrLf
            js &= vbCrLf
            js &= "var line" & (objEffectiveAlFeCalculation.dict.Count + 3).ToString & " = ["
            js &= "["
            js &= "" & ViewState("txtAIEffective") & ", " & ViewState("txtFEEffective")
            js &= "]"
            js &= "];" & vbCrLf
            js &= vbCrLf
            js &= "var line" & (objEffectiveAlFeCalculation.dict.Count + 4).ToString & " = ["
            js &= "["
            js &= "" & ViewState("txtTotalAI") & ", " & ViewState("txtTotalFE")
            js &= "],"
            js &= "["
            js &= "" & ViewState("txtTotalAI") & ", " & 0
            js &= "]"
            js &= "];" & vbCrLf
            js &= vbCrLf
            js &= "var line" & (objEffectiveAlFeCalculation.dict.Count + 5).ToString & " = ["
            js &= "["
            js &= "" & ViewState("txtTotalAI") & ", " & ViewState("txtTotalFE")
            js &= "],"
            js &= "["
            js &= "" & 0 & ", " & ViewState("txtTotalFE")
            js &= "]"
            js &= "];" & vbCrLf
            js &= vbCrLf

            '----------------------------------------------------------------------------------------------------------------------------
            js &= bottomLineDataForLeftBox & vbCrLf & rightLineDataForLeftBox & vbCrLf & topLineDataForLeftBox & vbCrLf & leftLineDataForLeftBox & vbCrLf
            js &= bottomLineDataForRightBox & vbCrLf & rightLineDataForRightBox & vbCrLf & topLineDataForRightBox & vbCrLf & leftLineDataForRightBox & vbCrLf

            Dim boxSeries As String = "{pointLabels: { show:false }, showLine:true, lineWidth:2, color: '#0B9126', markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: true,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold; font-size:12px;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
            '----------------------------------------------------------------------------------------------------------------------------

            Dim strg As String = ""
            Dim strseries As String = ""

            If flag Then
                strg = "[line1"
                strseries = " {pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: true,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}" & vbCrLf
                For i As Integer = 1 To objEffectiveAlFeCalculation.dict.Count + 4 '- 1 'dtGrades.Rows.Count - 1
                    strg = strg + ",line" & i + 1

                    If i = 4 Or i = 7 Or i = 8 Then
                        strseries = strseries + ", {pointLabels: { show:false }, showLine:true, lineWidth:1, linePattern: 'dashed',  markerOptions:{ size: 5 }, highlighter: {show: false,showMarker: true,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}" & vbCrLf
                    ElseIf i >= 5 Then
                        strseries = strseries + ", {pointLabels: { show:false }, neighborThreshold: 0, showLine:false, showMarker:true, markerOptions: { style:'X' }}"

                    Else
                        strseries = strseries + ", {pointLabels: { show:false }, showLine:true, lineWidth:3, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: true,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}" & vbCrLf
                    End If

                Next
                strseries &= ", {pointLabels: { show:true }, showLine:false, color: '#1D00FF', lineWidth:2, markerOptions:{ show:true, size: 5, style:'circle' }, highlighter: {show: true,showMarker: true,tooltipAxes:'xy',yvalues: 3,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}" & vbCrLf
                strseries = strseries & ", " & boxSeries & ", " & boxSeries & ", " & boxSeries & ", " & boxSeries & ", " & boxSeries & ", " & boxSeries & ", " & boxSeries & ", " & boxSeries
                strg &= ", EffData, bottomLineDataForLeftBox, rightLineDataForLeftBox, topLineDataForLeftBox, leftLineDataForLeftBox, bottomLineDataForRightBox, rightLineDataForRightBox, topLineDataForRightBox, leftLineDataForRightBox]"
            End If

            js &= vbCrLf
            js &= "var EffData = ["
            For i As Integer = 0 To arrEffAl_X.Length - 1
                If i > 0 Then
                    js &= ", "
                End If
                js &= "[" & arrEffAl_X(i) & ", " & arrEffFe_Y(i) & ", '" & (i + 1) & "']"
            Next
            js &= "];"

            js &= vbCrLf
            js &= "var seriesName = ['"
            Dim str As String = ""
            Dim testarr() As String = {"line1", "line2", "line3", "line4", "line5", "line6", "line7", "line8", "line9"}
            For i As Integer = 0 To objEffectiveAlFeCalculation.dict.Count - 1
                str &= testarr(i) & "', '"
            Next
            str = str.Remove(str.LastIndexOf(", '"))
            str &= ", 'EffData'"

            str &= "];"
            js &= str
            js &= vbCrLf
            js &= "opts = {" & vbCrLf & _
            "title: '" & ChartTitle & "'," & vbCrLf & _
            "seriesDefaults: { pointLabels: { show:false }, showMarker:false, rendererOptions: {showDataLabels: true, dataLabels:  'label', diameter: 250, dataLabelPositionFactor: 0.5,sliceMargin: 3,color:'#DCDCDC', smooth:false } }," & vbCrLf & _
            "series:[" & strseries & "]," & vbCrLf & _
            "//seriesColors: ['#FFA500']," & vbCrLf & _
            "axesDefaults: {" & vbCrLf & _
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf & _
            "tickOptions: {" & vbCrLf & _
            "fontSize:'8pt'" & vbCrLf & _
            "}" & vbCrLf & _
            "}," & vbCrLf & _
            "axes: {" & vbCrLf & _
            "xaxis: {" & vbCrLf & _
            "min: 0.0800, max: 0.2600," & vbCrLf & _
            "label: '" & XAxisColName & "'," & vbCrLf & _
            "//labelRenderer: $.jqplot.CanvasAxisLabelRenderer," & vbCrLf & _
            "//renderer:$.jqplot.EnhancedLegendRenderer," & vbCrLf & _
            "tickOptions:{formatString:'', angle: -40}," & vbCrLf & _
            "tickInterval:0.005," & vbCrLf & _
            "//numberTicks: 0.0001," & vbCrLf & _
            "pad:0" & vbCrLf & _
            "}," & vbCrLf & _
            "yaxis: { " & vbCrLf & _
            "//tickOptions: { formatString: '%.3f' }," & vbCrLf & _
            "min: " & y_min & "," & vbCrLf & _
            "max: " & y_max & "," & vbCrLf & _
            "//autoscale:true," & vbCrLf & _
             "tickOptions:{formatString:'', angle: -30}," & vbCrLf & _
            "tickInterval:0.005," & vbCrLf & _
            "label: '" & YAxisColName & "'," & vbCrLf & _
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf & _
            "}" & vbCrLf & _
            "}," & vbCrLf & _
            "cursor: {" & vbCrLf & _
            "showTooltip: false," & vbCrLf & _
            "zoom: true" & vbCrLf & _
            "}," & vbCrLf & _
            "animate: true," & vbCrLf & _
            "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf & _
            "};" & vbCrLf & _
            "" & PlotName & " = $.jqplot('" & ContainerName & "', " & strg & ", opts);" & vbCrLf & _
            "</script>" & vbCrLf

            litLineGraph.Text = js
        Catch ex As Exception

        End Try
    End Sub

   
    Sub DrawChartTop(ByVal Filter As String, ByVal ChartTitle As String, ByVal val As String, ByVal lita As Literal, ByVal litb As Literal, ByVal dtStart As DateTime, ByVal dtEnd As DateTime)
        Try

            lita.Text = ""
            litb.Text = ""
            'ChartTitle = "Trend of Eff. Aluminium & Eff. Iron"
            Dim strfrmDt As String = dtStart.ToString("yyyy-MM-dd HH:mm")
            Dim strToDt As String = dtEnd.ToString("yyyy-MM-dd HH:mm")

            Dim dt As DataTable = objController.GetWetChemicalTestData(Session("TableName"), strfrmDt, strToDt, Session("DateColumn"), Filter, "CLR_PARAM_MIN")
            Dim dv As DataView = dt.DefaultView
            If val = "first" Then
                dv.RowFilter = "CLR_PARAM_TEST" & " IN ('ZAAL','ZAGA','ZAZS')"
            End If
            Dim dtAL As DataTable = dv.ToTable
            ViewState("dtAL") = dtAL

            Dim dtFE As New DataTable
            dt.DefaultView.RowFilter = String.Empty

            dv = dt.DefaultView
            dv.RowFilter = "CLR_PARAM_TEST" & " IN ('ZAFE')"
            dtFE = dv.ToTable
            ViewState("dtFE") = dtFE

            If val = "first" Then
                'If ViewState("HaveY2AxisTop") = True Then
                Dim y1Values(), y2Values() As String
                y1Values = (From row In dtAL Select col = row(Session("YValueColumn")).ToString).ToArray
                y2Values = (From row In dtFE Select col = row(Session("YValueColumn")).ToString).ToArray

                Dim y1_min As String = y1Values.Min() - (10 / 100 * y1Values.Min)
                Dim y1_max As String = y1Values.Max() + (10 / 100 * y1Values.Max)
                Dim y2_min As String = y2Values.Min() - (10 / 100 * y2Values.Min)
                Dim y2_max As String = y2Values.Max() + (10 / 100 * y2Values.Max)
                'If Session("SelectVal") = "CGL2" Then

                objController.PlotLineChartWithSecondaryYAxisCampaignwise(dt, Session("DateColumn"), y1_min, y1_max, y2_min, y2_max, Lit1, "divContainer2", "plot1", ChartTitle, "'ZAAL','ZAGA','ZAZS'", "'ZAFE'", "priData", "secData", "% Al", "% Fe")
                'End If

                'added for pot1 and pot2
                If dt.Rows.Count > 0 Then
                    Dim str As String = objController.getPotString(strfrmDt, strToDt)
                    'Lit5.Text = str
                End If

            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub dgv3_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles dgv3.RowDataBound
        Try
            If e.Row.RowType = DataControlRowType.Header Then
                e.Row.TableSection = TableRowSection.TableHeader
            End If
        Catch ex As Exception

        End Try
       
    End Sub
End Class
