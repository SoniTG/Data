﻿Imports System.Data
Imports System.IO
Imports System.Data.OleDb
Imports System.Drawing

Partial Class cgl2TBM
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim objDataHandler As New DataHandler
    Dim HeaderName() As String = {"POR2_EXP_COL", "POR2_COL_EXP", "W1_IN_OUT", "W1_OUT_IN", "W2_IN_OUT", "W2_OUT_IN", "CCSA_EX_SHEAR_IN_OUT", "CCSA_EX_SHEAR_OUT_IN", "CCSA_TR_EXP_COL", "CCSA_TR_COL_EXP"}
    Dim HeaderDifferential() As String = {"HF1_HGC_MilForFil", "HF1_HGC_POS"}
    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub

    Sub registerDate()
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "register", "register();", True)
    End Sub
    Dim dtTBM As DataTable
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    'txtDate_TextChanged()
                End If
            Catch ex As Exception

            End Try

        End If

        If Not Page.IsPostBack Then
            Try
                'MultiView1.ActiveViewIndex = 0
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-10).ToString("yyyy-MM-dd")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd")
                hfFrom.Value = dtStart
                hfTo.Value = dtEnd

                MultiView1.ActiveViewIndex = 0
                ddlEquipment.Items.Clear()
                objController.LoadEquipmentName(ddlEquipment)
                GetData()
                txtEquipment.Visible = False
                lblLife.Visible = False
                txtLife.Visible = False
                lblReseton.Visible = False
                txtResetOn.Visible = False
                ddlEquipment.Focus()
               
            Catch ex As Exception

            End Try

        End If

    End Sub
    

    'Sub CreateDynamicContainer_Differential(ByVal Header() As String)
    '    Try
    '        Dim appendString = ""
    '        For i As Integer = 0 To Header.Length - 1
    '            appendString &= "<div class='col-md-4'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>" & Header(i).ToString() & "</h3> <span></span></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='c" & i.ToString() & "' style='height: 200px;'></div></div></div></div>"
    '        Next
    '        divDifferential.InnerHtml = appendString
    '    Catch ex As Exception

    '    End Try

    'End Sub

    'Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
    '    Try
    '        Dim dtStart As String = hfFrom.Value
    '        Dim dtEnd As String = hfTo.Value
    '        Dim l As Literal
    '        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select cast(ccsa_datetime as date) as ccsa_datetime, max(CCSA_POR2_EXP_COL) as CCSA_POR2_EXP_COL,max(CCSA_POR2_COL_EXP) as CCSA_POR2_COL_EXP,max(CCSA_W1_IN_OUT) as CCSA_W1_IN_OUT,max(CCSA_W1_OUT_IN) as CCSA_W1_OUT_IN,max(CCSA_W2_IN_OUT) as CCSA_W2_IN_OUT,max(CCSA_W2_OUT_IN) as CCSA_W2_OUT_IN,max(CCSA_EX_SHEAR_IN_OUT) as CCSA_EX_SHEAR_IN_OUT,max(CCSA_EX_SHEAR_OUT_IN) as CCSA_EX_SHEAR_OUT_IN,max(CCSA_TR_EXP_COL) as CCSA_TR_EXP_COL,max(CCSA_TR_COL_EXP) as CCSA_TR_COL_EXP from [CRM_CGL2_STROKETIME_DATA] where ccsa_datetime between '" & dtStart & "' and '" & dtEnd & "' group by cast(ccsa_datetime as date) order by 1").Tables(0)
    '        For i As Integer = 0 To HeaderName.Length - 1
    '            Dim literals = Page.Master.FindControl("content_body").Controls.OfType(Of Literal)()
    '            For Each lit In literals
    '                If (lit.ID = "Lit" & i + 1) Then
    '                    l = lit
    '                    Exit For
    '                End If
    '            Next
    '            objController.PlotLineChartForCGL2Maint(dt, "ccsa_datetime", dt.Columns(i + 1).ColumnName, l, "c" & i, "plot" & i + 1, "", "", i + 1)
    '        Next
    '    Catch ex As Exception

    '    End Try

    'End Sub

    'Private Sub CreateChart(HeaderName As String())
    '    Try
    '        Dim dtStart As String = hfFrom.Value
    '        Dim dtEnd As String = hfTo.Value
    '        Dim l As Literal
    '        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select cast(ccsa_datetime as date) as ccsa_datetime, max(CCSA_POR2_EXP_COL) as CCSA_POR2_EXP_COL,max(CCSA_POR2_COL_EXP) as CCSA_POR2_COL_EXP,max(CCSA_W1_IN_OUT) as CCSA_W1_IN_OUT,max(CCSA_W1_OUT_IN) as CCSA_W1_OUT_IN,max(CCSA_W2_IN_OUT) as CCSA_W2_IN_OUT,max(CCSA_W2_OUT_IN) as CCSA_W2_OUT_IN,max(CCSA_EX_SHEAR_IN_OUT) as CCSA_EX_SHEAR_IN_OUT,max(CCSA_EX_SHEAR_OUT_IN) as CCSA_EX_SHEAR_OUT_IN,max(CCSA_TR_EXP_COL) as CCSA_TR_EXP_COL,max(CCSA_TR_COL_EXP) as CCSA_TR_COL_EXP from [CRM_CGL2_STROKETIME_DATA] where ccsa_datetime between '" & dtStart & "' and '" & dtEnd & "' group by cast(ccsa_datetime as date) order by 1").Tables(0)
    '        For i As Integer = 0 To HeaderName.Length - 1
    '            Dim literals = Page.Master.FindControl("content_body").Controls.OfType(Of Literal)()
    '            For Each lit In literals
    '                If (lit.ID = "Lit" & i + 1) Then
    '                    l = lit
    '                    Exit For
    '                End If
    '            Next
    '            objController.PlotLineChartForCGL2Maint(dt, "ccsa_datetime", dt.Columns(i + 1).ColumnName, l, "c" & i, "plot" & i + 1, "", "", i + 1)
    '        Next
    '    Catch ex As Exception

    '    End Try

    'End Sub

    

    
    Sub GetData()
        Try
            dtTBM = objController.GetCgl2MainTBMData()
            If dtTBM.Rows.Count > 0 Then
                gvData.DataSource = dtTBM
                gvData.DataBind()
                gvData.UseAccessibleHeader = True
                gvData.HeaderRow.TableSection = TableRowSection.TableHeader
                gvData.Columns(0).Visible = False
                gvData.Columns(1).Visible = False
                gvData.Columns(2).Visible = False

            End If
        Catch ex As Exception

        End Try

    End Sub
    Protected Sub ddlEquipment_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlEquipment.SelectedIndexChanged
        Try

            If ddlEquipment.SelectedItem.Text = "Other" Then
                txtEquipment.Text = ""
                txtLife.Text = ""
                txtResetOn.Text = ""
                txtEquipment.Visible = True
                lblLife.Visible = True
                txtLife.Visible = True
                lblReseton.Visible = True
                txtResetOn.Visible = True
                Session("equipment") = "add"
                txtEquipment.Focus()
            ElseIf ddlEquipment.SelectedItem.Text = "Select" Then
                txtEquipment.Visible = False
                lblLife.Visible = False
                txtLife.Visible = False
                lblReseton.Visible = False
                txtResetOn.Visible = False

            Else
                txtEquipment.Text = ""
                txtLife.Text = ""
                txtResetOn.Text = ""
                txtEquipment.Visible = True
                lblLife.Visible = True
                txtLife.Visible = True
                lblReseton.Visible = True
                txtResetOn.Visible = True
                Session("equipment") = "update"
                txtEquipment.Focus()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnSave_Click(sender As Object, e As System.EventArgs) Handles btnSave.Click
        Try

            Dim pass As Boolean = True
            If txtEquipment.Text.Trim() = "" Then
                UserMsgBoxWarning("Please enter equipment name.")
                txtEquipment.Focus()
                pass = False
            ElseIf txtLife.Text.Trim() = "" Then
                UserMsgBoxWarning("Please enter life.")
                txtLife.Focus()
                pass = False
            ElseIf txtResetOn.Text = "" Then
                UserMsgBoxWarning("Please select reset date.")
                txtResetOn.Focus()
                pass = False
            End If
            If pass Then
                Dim count = 0
                If Session("equipment") = "add" Then
                    count = objController.SaveEquipmentDetails(txtEquipment.Text.ToUpper(), txtLife.Text, txtResetOn.Text, "", Controller.FormAction.Insert, -1)
                Else
                    count = objController.SaveEquipmentDetails(txtEquipment.Text.ToUpper(), txtLife.Text, txtResetOn.Text, "", Controller.FormAction.Update, ddlEquipment.SelectedValue)
                End If
                If count > 0 Then
                    UserMsgBoxSuccess("Equipment saved successfully.")
                    txtEquipment.Visible = False
                    lblLife.Visible = False
                    txtLife.Visible = False
                    lblReseton.Visible = False
                    txtResetOn.Visible = False
                    objController.LoadEquipmentName(ddlEquipment)
                    GetData()
                Else
                    UserMsgBoxError("Equipment not saved.")
                End If
            End If

        Catch ex As Exception

        End Try
    End Sub


    Protected Sub gvData_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvData.RowCommand
        Try
            If gvData.Rows.Count > 0 Then
                Dim count = 0, count1 = 0
                Dim index = Convert.ToInt32(e.CommandArgument)
                Dim slno As Integer = CType(gvData.Rows(index).Cells(0).FindControl("lblSlNo"), Label).Text.Trim()
                Dim life As Integer = CType(gvData.Rows(index).Cells(1).FindControl("lblLife"), Label).Text.Trim()
                Dim reseton As String = CType(gvData.Rows(index).Cells(2).FindControl("lblResetOn"), Label).Text.Trim()
                count = objController.UpdateResetDate(slno)
                If count > 0 Then
                    count1 = objController.SaveEquipmentResetDetails(slno, life, reseton)
                    If count1 > 0 Then
                        UserMsgBoxSuccess("Equipment reset successfully.")
                        GetData()
                    End If
                Else
                    UserMsgBoxError("Equipment not reset.")
                End If

            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub gvData_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvData.RowDataBound
        Try
            'If gvData.Rows.Count > 0 Then
            If e.Row.RowType = DataControlRowType.DataRow Then
                Dim life As Integer = DataBinder.Eval(e.Row.DataItem, "CCT_LIFE")
                Dim duedate As DateTime = DataBinder.Eval(e.Row.DataItem, "DueDate")
                Dim diff As Integer
                Dim lifeindays As Integer
                Dim lifediff As Integer
                lifeindays = life * 30
                'diff = DateTime.Now.Subtract(duedate).TotalDays
                diff = (duedate - DateTime.Now).TotalDays
                ' diff = DateDiff(DateInterval.Day, DateTime.Now, duedate)

                If diff <= 0 Then
                    e.Row.Cells(4).BackColor = Color.FromArgb(236, 16, 67)
                Else
                    lifediff = diff * 100 \ lifeindays

                    If lifediff > 67 Then

                        e.Row.Cells(4).BackColor = System.Drawing.Color.Green
                    ElseIf lifediff > 34 Then
                        e.Row.Cells(4).BackColor = Color.FromArgb(222, 181, 16) 'YELLOW
                    Else
                        e.Row.Cells(4).BackColor = Color.FromArgb(236, 16, 67) 'RED
                    End If
                End If

            End If
            'End If
        Catch ex As Exception

        End Try
    End Sub

    'Protected Sub btnDifferential_Click(sender As Object, e As System.EventArgs) Handles btnDifferential.Click
    '    Lit1.Text = ""
    '    Lit2.Text = ""
    '    Lit3.Text = ""
    '    Lit4.Text = ""
    '    Lit5.Text = ""
    '    Lit6.Text = ""
    '    Lit7.Text = ""
    '    Lit8.Text = ""
    '    Lit9.Text = ""
    '    Lit10.Text = ""
    '    Lit11.Text = ""
    '    Lit12.Text = ""
    '    divDifferential.InnerHtml = ""
    '    MultiView1.ActiveViewIndex = 2
    '    CreateDynamicContainer_Differential(HeaderDifferential)
    '    CreateChart_Differential(HeaderDifferential)
    'End Sub

    'Private Sub CreateChart_Differential(HeaderName As String())
    '    Try
    '        Dim dtStart As String = hfFrom.Value
    '        Dim dtEnd As String = hfTo.Value
    '        Dim l As Literal

    '        For i As Integer = 0 To HeaderName.Length - 1
    '            Dim literals = Page.Master.FindControl("content_body").Controls.OfType(Of Literal)()
    '            For Each lit In literals
    '                If (lit.ID = "Lit" & i + 1) Then
    '                    l = lit
    '                    Exit For
    '                End If
    '            Next
    '            Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select fileDatetime,rTrim(ltrim(SignalName)) as SignalName,SignalMaxVal from [CRM_CGL2_DifferentialVal] where fileDatetime between '" & dtStart & "' and '" & dtEnd & "' and rtrim(ltrim(SignalName))='" & HeaderName(i) & "' order by 1").Tables(0)
    '            objController.PlotLineChartForCGL2Maint(dt, "fileDatetime", "SignalMaxVal", l, "c" & i, "plot" & i + 1, "", "", i + 1)
    '        Next
    '    Catch ex As Exception

    '    End Try

    'End Sub
End Class
