﻿Imports System.Data
Imports System.IO
Partial Class cgl2_encoder
    Inherits System.Web.UI.Page

    Dim objController As New Controller
    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))

                DrawCharts()
            Catch ex As Exception

            End Try

        End If

    End Sub

    Sub DrawCharts()
        Try

            Dim ds As DataSet = objController.GetCGL2EncoderData()
            Dim dt As DataTable = ds.Tables(0)
            Dim dt1 As DataTable = ds.Tables(1)

            DrawDynamicContainer(dt1)

            Dim groups As List(Of DataTable) = dt1.AsEnumerable.GroupBy(Function(g) g.Field(Of String)("CL_SIGNAL_CATEGORY")).Select(Function(t) t.CopyToDataTable).ToList

            Dim i As Integer = 1
            Dim j As Integer = 0
            Dim cidx As Integer = 0
            Try
                lblFName.Text = dt.Rows(0)(0)
            Catch ex As Exception

            End Try

            If dt.Rows(0)("CEM_SPD_STDDEV_MAX") = "MILL STOP" Then
                UserMsgBoxWarning("Mill is not running")
                Return
            End If

            If dt.Rows.Count > 0 Then
                Dim s As New StringBuilder("<script>")
                lblFName.Text = dt.Rows(0)(0)

                Dim arrData() As String = dt.Rows(0)(2).ToString.Split(",")

                For Each g In groups
                    Dim results = arrData.Skip(j).Take(g.Rows.Count)
                    j = j + g.Rows.Count
                    Dim xdata As String = ""
                    Dim ydata As String = ""
                    For Each x In results



                        xdata &= ",'" & dt1.Rows(i - 1)("CL_ALIAS") & "'"
                        ' ydata &= "," & item
                        Dim color As String = "#3398DB"
                        If dt1.Rows(i - 1)("CL_MAX_LIMIT") > 0 AndAlso CDbl(x.ToString) >= dt1.Rows(i - 1)("CL_MAX_LIMIT") Then
                            color = "#F05D5E"
                        End If
                        ydata &= ",{value:" & x & ",itemStyle:{normal:{color:'" & color & "'}}}"
                        i = i + 1
                    Next
                    s.Append("option" & cidx & "={")

                    s.Append("grid:{bottom:150,top:20,show:false},tooltip : {trigger: 'axis',axisPointer : {type : 'line'}},xAxis: {type: 'category',axisLabel:{show:true,rotate:90},data: [" & xdata.Substring(1) & "]},yAxis: { type: 'value',name: 'Speed StdDev (RPM)',splitLine:{show:false},nameLocation: 'middle',nameGap: 50}, series: [{ data: [" & ydata.Substring(1) & "],type: 'bar'}]};")
                    s.Append("var chart" & cidx & "=echarts.init(document.getElementById('container" & cidx & "'));chart" & cidx & ".setOption(option" & cidx & ");")
                    s.Append("chart" & cidx & ".on('click',function(params){window.open('cgl2_sub_chart.aspx?subparam=' + escape(params.name) + '', ""_blank"", ""toolbar=no,location=no,directories=no,status=no,scrollbars=yes,resizable=no,top=100,left=200,width=800,height=400"");});")
                    cidx += 1

                Next
                s.Append("</script>")
                Lit1.Text = s.ToString
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub DrawDynamicContainer(ByRef dt1 As DataTable)
        Try
            Dim arr = dt1.AsEnumerable.Select(Function(x) x.Field(Of String)("CL_SIGNAL_CATEGORY")).Distinct().ToArray
            Dim appendString = ""
            For i As Integer = 0 To arr.length - 1
                appendString &= "<div class='col-md-6'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3></h3> <span></span></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='container" & i.ToString() & "' style='height: 300px;'></div></div></div></div>"
            Next
            divHolder.InnerHtml = appendString
        Catch ex As Exception

        End Try
    End Sub


End Class

