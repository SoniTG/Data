﻿
Imports System.Data
Imports System.IO

Partial Class cgl2_slip_live
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim objDataHandler As New DataHandler
    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))

                DrawCharts()

            Catch ex As Exception

            End Try

        End If

    End Sub

    Private Sub DrawCharts()
        Lit1.Text = ""
        Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("select * from [FP_DEFECT_ANALYSIS].[dbo].[T_paramconfigure] order by Idx; select top 600 * from [FP_DEFECT_ANALYSIS].[dbo].[T_Cgl2_slip_live] order by [DateTime] ")
        DrawDynamicContainer(ds.Tables(0), ds.Tables(1))
    End Sub

    Private Sub DrawDynamicContainer(ByRef dt1 As DataTable, ByRef dt2 As DataTable)
        Try
            Dim arr = dt1.AsEnumerable.Select(Function(x) x.Field(Of String)("HeaderName")).Distinct().ToArray
            Dim appendString = ""
            For i As Integer = 0 To arr.Length - 1
                appendString &= "<div class='col-md-4'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>" & arr(i).ToString() & "</h3> <span></span></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='c" & i.ToString() & "' style='height: 300px;'></div></div></div></div>"
                Dim ypara As String = dt1.Rows(i)("YAxisCol").ToString.Replace("]", "").Replace("[", "")
                Dim xpara As String = dt1.Rows(i)("XAxisCol")
                Dim dia As String = dt1.Rows(i)("Diameter").ToString
                Dim gearRatio As String = dt1.Rows(i)("GearRatio").ToString
                Try
                    Lit1.Text &= PlotLineEChart(dt2, "c" & i.ToString(), xpara, ypara, dt1.Rows(i)("lsl"), dt1.Rows(i)("usl"), dt1.Rows(i)("yaxisunit"), dia, gearRatio)
                Catch ex As Exception
                    Dim k As Integer = 1
                End Try

            Next
            divHolder.InnerHtml = appendString
        Catch ex As Exception

        End Try
    End Sub

    Public Function PlotLineEChart(ByVal dt As DataTable, ByVal ContainerName As String, ByVal XAxisColName As String, ByVal YaxisColName As String, ByVal lsl As String, ByVal usl As String, ByVal unit As String, ByVal dia As String, ByVal gearratio As String) As String
        Dim series As String = ""
        Dim xval As String = "["



        series &= "{type: 'line', name:'" & YaxisColName & "',data: ["
        For i As Integer = 0 To dt.Rows.Count - 1

            Dim linespeed As Double = dt.Rows(i)("LineSpeed")

            xval &= "'" & CDate(dt.Rows(i)(XAxisColName)).ToString("yyyy-MM-dd HH:mm:ss.fff") & "',"

            If dia <> "" Then
                series &= Math.Round(((dt.Rows(i)(YaxisColName) * Math.PI * (CDbl(dia) / 1000) / CDbl(gearratio)) - linespeed) * 100 / linespeed, 2) & ","
            Else
                series &= dt.Rows(i)(YaxisColName) & ","
            End If

        Next

        Dim ymax, ymin As Double
        'ymax = dt.Compute("max([" & YaxisColName & "])", "")
        'ymax = dt.Compute("min([" & YaxisColName & "])", "")

        'If ymax < usl Then ymax = usl
        'If ymin > lsl Then ymin = lsl

        ymax = CDbl(usl) + CDbl(usl) * 0.2

        If lsl < 0 Then
            ymin = CDbl(lsl) + CDbl(lsl) * 0.2
        Else
            ymin = CDbl(lsl) - CDbl(lsl) * 0.2
        End If



        xval &= "]"
        series &= "],markLine:{symbol: 'none',data:[{yAxis:" & lsl & ",name:'LSL',label:{formatter:'LSL'},lineStyle: {color:'red',type:'solid'}},{yAxis:" & usl & ",name:'USL',label:{formatter:'USL'},lineStyle: {color:'red',type:'solid'}}]}},"

        Dim s As New StringBuilder("<script>")
        s.Append("echarts.init(document.getElementById('" & ContainerName & "')).setOption(")

        s.Append("{")

        s.Append("title: {")
        s.Append("text: ''")
        s.Append("},grid:{left:'15%',right:'5%'},")
        s.Append("tooltip: {")
        s.Append("trigger: 'axis'")
        s.Append("},")
        s.Append("xAxis: {")
        s.Append("data: " & xval & "")
        s.Append("},")
        s.Append("yAxis: {name : '" & unit & "',")
        If ymax > 0 Then
            s.Append("min:" & Math.Floor(ymin) & ",max:" & Math.Ceiling(ymax) & ",")
        End If
        s.Append("nameLocation: 'middle', nameGap: 50,nameTextStyle:{fontFamily:'Calibri',fontWeight:'bold',fontSize:'14'},")
        s.Append("splitLine: {")
        s.Append("show: false")
        s.Append("}")
        s.Append("},")
        s.Append("toolbox: {")
        s.Append("left: 'right',")
        s.Append("feature: {")
        s.Append("dataZoom: {")
        s.Append("")
        s.Append("},")
        s.Append("restore: {},")
        s.Append("saveAsImage: {}")
        s.Append("}")
        s.Append("},")
        s.Append("series: [" & series)
        s.Append("]")
        s.Append("});")

        s.Append("</script>")

        Return s.ToString
    End Function



End Class
