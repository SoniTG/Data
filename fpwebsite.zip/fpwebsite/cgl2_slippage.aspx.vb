﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO

Partial Class cgl2_slippage
    Inherits System.Web.UI.Page
    Dim objDataHandler As New DataHandler
    Dim objController As New Controller
    Dim connectionString As String = "server=176.0.0.60\LPTGSQLDEV;database=FP_DEFECT_ANALYSIS;uid=153521;pwd=Welcome@135"

    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Dim HeaderName() As String '= {"ACR", "4BR_Loadbalance_Spd_diff", "4BR_Loadbalance_curr_diff", "5BR_Loadbalance_Spd_diff", "5BR_Loadbalance_curr_diff", "6BR_R1_Loadbalance_Spd_diff", "6BR_R1_Loadbalance_Curr_diff", "6BR_R2_Loadbalance_Spd_diff", "6BR_R2_Loadbalance_Curr_diff", "6BR_R3_Loadbalance_Spd_diff", "6BR_R3_Loadbalance_Curr_diff"}
    Dim HeaderAlias() As String
    '  Dim HeaderName() As String = {"CPC 1 Cylinder & Strip Trend", "CPC 2 Cylinder & Strip Trend", "CPC 3 Cylinder & Strip Trend", "CPC 4 Cylinder & Strip Trend", "CPC 5 Cylinder & Strip Trend", "CPC 6 Cylinder & Strip Trend", "CPC 7 Cylinder & Strip Trend"}


    Private Sub defectanalysis_Bridle_Roll_SlipPage_Load(sender As Object, e As EventArgs) Handles Me.Load



        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))

                Dim dtStart As String = DateTime.Now.AddDays(-3).ToString("yyyy-MM-dd HH:mm:ss")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")

                If Not Request.QueryString("frm") Is Nothing Then
                    dtStart = Request.QueryString("frm").ToString.Replace("%20", " ")
                    dtEnd = Request.QueryString("to").ToString.Replace("%20", " ")
                    plottypeDDl.SelectedValue = "Average"
                End If

                txtFrom.Text = dtStart
                txtTo.Text = dtEnd

                GetDataForTrendChart(dtStart, dtEnd)

                Dim query As String = ""
                Dim dtColumns As New DataTable()
                query = "SELECT distinct SubGroup,Sequence FROM [FP_DEFECT_ANALYSIS].[dbo].[T_paramconfigure]  order by Sequence"


                Using connection As New SqlConnection(connectionString)
                    Using command As New SqlCommand(query, connection)
                        connection.Open()
                        dtColumns.Load(command.ExecuteReader())
                        ListBoxParametersGroup.DataSource = dtColumns
                        ListBoxParametersGroup.DataTextField = "SubGroup"
                        ListBoxParametersGroup.DataValueField = "SubGroup"
                        ListBoxParametersGroup.DataBind()
                        ListBoxParametersGroup.Items.Insert(0, "All Group")

                    End Using
                End Using




                'FetchHeaderName()


                'CreateDynamicContainer(HeaderAlias)

                'Lit1.Text = ""

                'For i As Integer = 1 To UBound(HeaderName) + 1

                '    Dim dt As DataTable = objController.Populatecgl2_rollData(dtStart, dtEnd, HeaderName(i - 1))
                '    BoxPlotForPltcmCylinder(dt, Lit1, "c" & i - 1, "plot", "", i, plottypeDDl.SelectedValue.ToString)

                'Next




            Catch ex As Exception
                Throw ex
            End Try

        End If

    End Sub

    Private Sub FetchHeaderName(ByVal GroupName As String, ByVal SubGroup As String)
        Dim q As String = ""
        'Dim q As String = "select * from [FP_PROCESS_DATA].[dbo].[CRM_PLTCM_CRITICAL_PARAMETER_TREND_MASTER]"

        If GroupName = "'All Group'" Then
            q = "select * FROM [FP_DEFECT_ANALYSIS].[dbo].[T_paramconfigure] where HeaderName in (" & SubGroup & ")"
        Else
            q = "select * FROM [FP_DEFECT_ANALYSIS].[dbo].[T_paramconfigure] where SubGroup in (" & GroupName & ") and HeaderName in (" & SubGroup & ")"
        End If

        'Dim dt As DataTable = objDataHandler.Getsql_data(q)
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery(q).Tables(0)

        Dim h() As String = dt.AsEnumerable.Select(Function(r) r.Field(Of String)("HeaderName")).ToArray
        Dim h_a() As String = dt.AsEnumerable.Select(Function(r) r.Field(Of String)("YAxisCol")).ToArray

        HeaderName = h
        HeaderAlias = h_a
    End Sub

    Sub GetData()
        Try
            'Dim dtStart As String = hfFrom.Value
            'Dim dtEnd As String = hfTo.Value
            Dim dtStart As String = txtFrom.Text.Replace("T", " ") 'DateTime.Now.AddDays(-90).ToString("yyyy-MM-dd HH:mm:ss")
            Dim dtEnd As String = txtTo.Text.Replace("T", " ") 'DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")

            Lit1.Text = ""

            'For i As Integer = 1 To UBound(HeaderName) + 1
            For i As Integer = 1 To UBound(HeaderAlias) + 1

                'Dim dt As DataTable = objController.PopulatePltcmCylinderData(dtStart, dtEnd, HeaderName(i - 1))
                Dim dt As DataTable = objController.Populatecgl2_rollData(dtStart, dtEnd, HeaderAlias(i - 1))
                BoxPlotForPltcmCylinder(dt, Lit1, "c" & i - 1, "plot" & (i + 1), "", i, plottypeDDl.SelectedValue.ToString)

            Next


        Catch ex As Exception
            Throw ex
        End Try

    End Sub


    Sub CreateDynamicContainer(ByVal Header() As String)
        Try
            Dim appendString = ""
            For i As Integer = 0 To Header.Length - 1
                appendString &= "<div class='col-md-6'><div class='card'> <div class='card-header'> <h5 style='float:left'>" & Header(i).ToString() & "</h5><div style='display:inline;float: right;margin-right: 30px;'> <input type='text' style='width:60px;' title='yMin' id='ymin" & i & "' class='form-control-success imin' /> <input type='text'  style='width:60px;'  title='yMax' id='ymax" & i & "' class='form-control-success imax' /></div> <div class='card-header-right'> <ul class='list-unstyled card-option'> <li> <i class='fa fa-window-maximize full-card'></i> </li></ul> </div></div><div class='card-block'><div class='chart-holder' id='c" & i.ToString() & "' style='height: 200px;'></div> </div></div></div>"
            Next
            divHolder.InnerHtml = appendString
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub lnkSubmit_Click(sender As Object, e As System.EventArgs) Handles lnkSubmit.Click
        Try
            Dim dtStart As String = txtFrom.Text.Replace("T", " ")
            Dim dtEnd As String = txtTo.Text.Replace("T", " ")
            GetDataForTrendChart(dtStart, dtEnd)
            Dim GroupName As String = ""
            For i As Integer = 0 To ListBoxParametersGroup.Items.Count - 1
                If ListBoxParametersGroup.Items(i).Selected = True Then
                    GroupName &= ",'" & ListBoxParametersGroup.Items(i).Text.Trim & "'"
                    'Response.Write(i)
                End If
            Next
            GroupName = GroupName.Substring(1)

            Dim SubGroup As String = ""
            For i As Integer = 0 To CheckBoxListParametersSubGroup.Items.Count - 1
                If CheckBoxListParametersSubGroup.Items(i).Selected = True Then
                    SubGroup &= ",'" & CheckBoxListParametersSubGroup.Items(i).Text.Trim & "'"
                    'Response.Write(i)
                End If
            Next
            SubGroup = SubGroup.Substring(1)
            FetchHeaderName(GroupName, SubGroup)
            'CreateDynamicContainer(HeaderAlias)
            CreateDynamicContainer(HeaderName)
            GetData()

        Catch ex As Exception

        End Try

    End Sub
    Sub BoxPlotForPltcmCylinder(ByVal dt As DataTable, ByVal lit As Literal, ByVal containerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal VAL As Integer, ByVal plottype As String)



        'lit.Text = ""
        Try
            ChartTitle = ""
            Dim ticks As String = "["
            Dim line1, line2, line3, line4, line5 As String
            line1 &= "["
            line2 &= "["
            line3 &= "["
            line4 &= "["
            line5 &= "["

            Dim multiplier, lsl, usl As String
            If dt.Rows.Count > 0 Then
                multiplier = 1 'dt.Rows(0)("multiplier").ToString
                lsl = dt.Rows(0)("lsl").ToString
                usl = dt.Rows(0)("usl").ToString

            End If
            If multiplier = "" Then multiplier = 1

            Dim mulfactor As Double = CDbl(multiplier)

            For i As Integer = 0 To dt.Rows.Count - 1
                If (dt.Rows(i)(1).ToString <> "") Then

                    Try
                        ticks &= "'" & CDate(dt.Rows(i)("START_TIME")).ToString("yyyy-MM-dd HH:mm:ss") & "'"


                        Dim tmpCyl() As String = dt.Rows(i)(1).ToString.Split(",")

                        Dim lbound As Double = CDbl(tmpCyl(0))
                        Dim ubound As Double = CDbl(tmpCyl(1))
                        Dim min_ As Double = CDbl(tmpCyl(7))
                        Dim max_ As Double = CDbl(tmpCyl(8))

                        If min_ >= lbound Then lbound = min_
                        If max_ <= ubound Then ubound = max_

                        line1 &= "[" & lbound * mulfactor & "," & tmpCyl(4) * mulfactor & "," & tmpCyl(3) * mulfactor & "," & tmpCyl(5) * mulfactor & "," & ubound * mulfactor & "]"

                        line2 &= tmpCyl(2) * mulfactor 'avg
                        line3 &= tmpCyl(7) * mulfactor 'min
                        line4 &= tmpCyl(8) * mulfactor 'max
                        line5 &= tmpCyl(6) * mulfactor 'stdev

                        If (i <> 0 Or i <> dt.Rows.Count - 1) Then
                            ticks &= ","
                            line1 &= ","
                            line2 &= ","
                            line3 &= ","
                            line4 &= ","
                            line5 &= ","
                        End If



                    Catch ex As Exception
                        Continue For
                    End Try
                End If

            Next
            ticks &= "]"
            line1 &= "]"
            line2 &= "]"
            line3 &= "]"
            line4 &= "]"
            line5 &= "]"

            Dim minmax As String = ""
            If lsl <> "" And usl <> "" Then
                minmax = "min:" & lsl & ",max:" & usl
            End If
            Dim markline As String = ""
            If lsl <> "" And usl <> "" Then
                markline = ",markLine: { data: [{  name: 'lsl',yAxis:" & lsl & ",lineStyle:{type:'solid',color:'red'} },{  name: 'usl',yAxis:" & usl & ",lineStyle:{type:'solid',color:'red'} }]}"
            End If
            Dim js = "<script language='javascript' type='text/javascript'>"
            js &= "var ticks=" & ticks & ";"
            js &= "var pl1=" & line1 & ";"
            js &= "var pl2=" & line2 & ";"
            js &= "var pl3=" & line3 & ";"
            js &= "var pl4=" & line4 & ";"
            js &= "var pl5=" & line5 & ";"
            js &= "var lmin = Math.min(Math.min.apply(null,pl2),Math.min.apply(null,pl3),Math.min.apply(null,pl4),Math.min.apply(null,pl5));"
            js &= "var lmax = Math.max(Math.max.apply(null,pl2),Math.max.apply(null,pl3),Math.max.apply(null,pl4),Math.max.apply(null,pl5));"
            js &= "var yMin = (lmin<-300)?lmin-5:-310; var yMax = (lmax>300)?lmax+ 5:310;"
            If (plottype = "Box Plot") Then
                js &= "option = { toolbox:{feature:{dataZoom:{}},right:'10%'},  tooltip: {trigger:    'item',axisPointer: {type:       'shadow'}},grid: {left:       '10%',top:'15%',right:      '10%',bottom: '25%'}, xAxis: {"
                js &= "type:       'category',   data:ticks, boundaryGap: true, nameGap: 30, splitArea: { show: true}, axisLabel: {rotate:45,formatter:  function (value, index) {return value.split(' ')[0];}}, splitLine: {show: false}}, yAxis: {type:'value',name:'Deviation',nameLocation:   'middle',nameGap: 40,splitArea: {show: false}," & minmax & "},"
                js &= " dataZoom: [{type:       'inside',start: 0,end: 100},{show: true,height: 20,type: 'slider',top:'90%',xAxisIndex: [0]}],"
                js &= " series: [{name:       'ACR Output (Count)',type:       'boxplot'" & markline & ", data: pl1,tooltip: {formatter: formatter}}]};"
                js &= "function formatter(param) {return [param.name,'upper: ' + param.data[5],'Q3: ' + param.data[4],'median: ' + param.data[3],'Q1: ' + param.data[2],'lower: ' + param.data[1]].join('<br/>')}"
                js &= "var " & PlotName & " = echarts.init(document.getElementById('" & containerName & "'));" & PlotName & ".setOption(option);"
            ElseIf (plottype = "Average") Then
                js &= "option = {toolbox:{feature:{dataZoom:{}},right:'10%'}, tooltip: {trigger: 'axis'}, legend: { y: '10%', data: ['Avg','Min','Max','StDev']},grid: {left:       '10%',top:'15%',right:      '10%',bottom: '25%'}, xAxis: {"
                js &= "type:       'category',   data:ticks,axisLabel: {rotate:45,formatter:  function (value, index) {return value.split(' ')[0];}}}, yAxis: {type: 'value'," & minmax & "},"
                js &= " dataZoom: [{type:       'inside',start: 0,end: 100},{show: true,height: 20,type: 'slider',top:'90%',xAxisIndex: [0]}],"
                js &= "series: [{name:       'Avg',data: pl2, type:'line'" & markline & "},{name:       'Min',data: pl3, type:'line'},{name:       'Max',data: pl4, type:'line'},{name:       'StDev',data: pl5, type:'line'}]"
                js &= "};var  " & PlotName & " = echarts.init(document.getElementById('" & containerName & "'));" & PlotName & ".setOption(option);"
            End If



            js &= "</script>"

            lit.Text &= js
        Catch ex As Exception
            Throw ex
        End Try



    End Sub

    Sub GetDataForTrendChart(ByVal FromDate As String, ByVal ToDate As String)
        Try
            Dim dtStart As String = FromDate
            Dim dtEnd As String = ToDate

            Lit2.Text = ""

            Dim dt As DataTable
            dt = objDataHandler.GetDataSetFromQuery("SELECT distinct START_TIME  ,Thickness,Width,Speed   FROM [FP_DEFECT_ANALYSIS].[dbo].[T_CRMCGL_Slip_bxplot] where START_TIME between  '" & Convert.ToDateTime(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "'  and speed > 0  order by START_TIME").Tables(0)
            'BoxPlotForPltcmCylinder(dt, Lit1, "c" & i - 1, "plot" & (i + 1), "", i, plottypeDDl.SelectedValue.ToString)
            PlotTrendChart(dt, Lit2, "divHolder1", "Plot1", "", 0, "Trend Plot")




        Catch ex As Exception
            Throw ex
        End Try

    End Sub
    Sub PlotTrendChart(ByVal dt As DataTable, ByVal lit As Literal, ByVal containerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal VAL As Integer, ByVal plottype As String)



        'lit.Text = ""
        Try
            ChartTitle = ""
            Dim ticks As String = "["
            'Dim line1, line2, line3, line4, line5 As String
            Dim line1, line2, line3 As String
            line1 &= "["
            line2 &= "["
            line3 &= "["
            'line4 &= "["
            'line5 &= "["

            'Dim multiplier, lsl, usl As String
            'If dt.Rows.Count > 0 Then
            '    multiplier = 1 'dt.Rows(0)("multiplier").ToString
            '    lsl = 0 'dt.Rows(0)("lsl").ToString
            '    usl = 0 'dt.Rows(0)("usl").ToString

            'End If
            'If multiplier = "" Then multiplier = 1

            'Dim mulfactor As Double = CDbl(multiplier)
            Dim yVal() As Decimal
            Dim min_ As Double
            Dim max_ As Double
            yVal = (From row In dt Select col = CDec(IIf(IsDBNull(row("Width")), 0, row("Width")))).ToArray()
            If yVal.Length > 0 Then
                min_ = yVal.Min() - (yVal.Min * 0.05)
                max_ = yVal.Max() + (yVal.Max * 0.05)
            End If
            For i As Integer = 0 To dt.Rows.Count - 1
                'If (dt.Rows(i)(1).ToString <> "") Then
                If Not IsDBNull(dt.Rows(i)(1)) Or Not IsDBNull(dt.Rows(i)(2)) Or Not IsDBNull(dt.Rows(i)(3)) Then
                    Try
                        ticks &= "'" & CDate(dt.Rows(i)("START_TIME")).ToString("yyyy-MM-dd HH:mm:ss") & "'"



                        'Dim tmpCyl() As String = dt.Rows(i)(1).ToString.Split(",")

                        'Dim lbound As Double = CDbl(tmpCyl(0))
                        'Dim ubound As Double = CDbl(tmpCyl(1))
                        'Dim min_ As Double = 0 'CDbl(tmpCyl(7))
                        'Dim max_ As Double = 1120 'CDbl(tmpCyl(8))

                        'If min_ >= lbound Then lbound = min_
                        'If max_ <= ubound Then ubound = max_

                        'line1 &= "[" & lbound * mulfactor & "," & tmpCyl(4) * mulfactor & "," & tmpCyl(3) * mulfactor & "," & tmpCyl(5) * mulfactor & "," & ubound * mulfactor & "]"

                        'line2 &= tmpCyl(2) * mulfactor 'avg
                        'line3 &= tmpCyl(7) * mulfactor 'min
                        'line4 &= tmpCyl(8) * mulfactor 'max
                        'line5 &= tmpCyl(6) * mulfactor 'stdev
                        line1 &= "" & dt.Rows(i)(1) & ""
                        line2 &= "" & dt.Rows(i)(2) & ""
                        line3 &= "" & dt.Rows(i)(3) & ""

                        If (i <> 0 Or i <> dt.Rows.Count - 1) Then
                            ticks &= ","
                            line1 &= ","
                            line2 &= ","
                            line3 &= ","
                            'line4 &= ","
                            'line5 &= ","
                        End If



                    Catch ex As Exception
                        Continue For
                    End Try
                End If

            Next
            ticks &= "]"
            line1 &= "]"
            line2 &= "]"
            line3 &= "]"
            'line4 &= "]"
            'line5 &= "]"

            Dim minmax As String = ""
            'If lsl <> "" And usl <> "" Then
            '    minmax = "min:" & lsl & ",max:" & usl
            'End If
            'Dim markline As String = ""
            'If lsl <> "" And usl <> "" Then
            '    markline = ",markLine: { data: [{  name: 'lsl',yAxis:" & lsl & ",lineStyle:{type:'solid',color:'red'} },{  name: 'usl',yAxis:" & usl & ",lineStyle:{type:'solid',color:'red'} }]}"
            'End If
            Dim js = "<script language='javascript' type='text/javascript'>"
            js &= "var ticks=" & ticks & ";"
            js &= "var pl1=" & line1 & ";"
            js &= "var pl2=" & line2 & ";"
            js &= "var pl3=" & line3 & ";"
            'js &= "var pl4=" & line4 & ";"
            'js &= "var pl5=" & line5 & ";"

            'js &= "var lmin = Math.min(Math.min.apply(null,pl2),Math.min.apply(null,pl3));"
            'js &= "var lmax = Math.max(Math.max.apply(null,pl2),Math.max.apply(null,pl3));"
            js &= "var lmin = " & min_ & ";"
            js &= "var lmax = " & max_ & ";"
            'js &= "var yMin = (lmin<-300)?lmin-5:-310; var yMax = (lmax>300)?lmax+ 5:310;"
            js &= "var yMin = lmin; var yMax = lmax;"
            'If (plottype = "Box Plot") Then
            '    js &= "option = { toolbox:{feature:{dataZoom:{}},right:'10%'},  tooltip: {trigger:    'item',axisPointer: {type:       'shadow'}},grid: {left:       '10%',top:'15%',right:      '10%',bottom: '25%'}, xAxis: {"
            '    js &= "type:       'category',   data:ticks, boundaryGap: true, nameGap: 30, splitArea: { show: true}, axisLabel: {rotate:45,formatter:  function (value, index) {return value.split(' ')[0];}}, splitLine: {show: false}}, yAxis: {type:'value',name:'Deviation',nameLocation:   'middle',nameGap: 40,splitArea: {show: false}," & minmax & "},"
            '    js &= " dataZoom: [{type:       'inside',start: 0,end: 100},{show: true,height: 20,type: 'slider',top:'90%',xAxisIndex: [0]}],"
            '    js &= " series: [{name:       'ACR Output (Count)',type:       'boxplot'" & markline & ", data: pl1,tooltip: {formatter: formatter}}]};"
            '    js &= "function formatter(param) {return [param.name,'upper: ' + param.data[5],'Q3: ' + param.data[4],'median: ' + param.data[3],'Q1: ' + param.data[2],'lower: ' + param.data[1]].join('<br/>')}"
            '    js &= "var " & PlotName & " = echarts.init(document.getElementById('" & containerName & "'));" & PlotName & ".setOption(option);"
            'ElseIf (plottype = "Average") Then
            js &= "option = {toolbox:{feature:{dataZoom:{}},right:'10%'}, tooltip: {trigger: 'axis'}, legend: { y: '10%', data: ['Thickness','Width','Speed']},grid: {left:       '10%',top:'15%',right:      '10%',bottom: '25%'}, xAxis: {"
            js &= "type:       'category',   data:ticks,axisLabel: {rotate:45,formatter:  function (value, index) {return value.split(' ')[0];}}}, yAxis: {type: 'value',},"
            'js &= " dataZoom: [{type:       'inside',start: 0,end: 100},{show: true,height: 20,type: 'slider',top:'90%',xAxisIndex: [0]}],"
            js &= "series: [{name:       'Thickness',data: pl1, type:'line'},{name:       'Width',data: pl2, type:'line'},{name:       'Speed',data: pl3, type:'line'}]"
            js &= "};var  " & PlotName & " = echarts.init(document.getElementById('" & containerName & "'));" & PlotName & ".setOption(option);"
            'End If



            js &= "</script>"

            lit.Text &= js
        Catch ex As Exception
            Throw ex
        End Try



    End Sub
    Private Sub ListBoxParametersGroup_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBoxParametersGroup.SelectedIndexChanged
        Dim query As String = ""
        Dim dtStart As String = Convert.ToDateTime(txtFrom.Text).ToString("yyyy-MM-dd HH:mm:ss")
        Dim dtEnd As String = Convert.ToDateTime(txtTo.Text).ToString("yyyy-MM-dd HH:mm:ss")
        'Dim connectionString As String = "server=176.0.0.60\LPTGSQLDEV;database=TSM_Process_data;uid=153521;pwd=Welcome@135"
        Dim dtColumns As New DataTable()
        chkSelectAll.Checked = False
        divHolder.InnerHtml = Nothing
        Dim selectedGroupId As String = ListBoxParametersGroup.SelectedItem.Text
        If selectedGroupId = "All Group" Then
            'dtColumns.Columns.Add("ColumnName")
            'query = "  select distinct HeaderName,YAxisCol  FROM [FP_DEFECT_ANALYSIS].[dbo].[T_paramconfigure] order by HeaderName"
            query = "  select distinct HeaderName,YAxisCol,Sequence  FROM [FP_DEFECT_ANALYSIS].[dbo].[T_paramconfigure] order by Sequence"
        Else

            'dtColumns.Columns.Add("ColumnName")

            'If selectedGroupId = "1" Then
            'query = "  select distinct HeaderName,YAxisCol  FROM [FP_DEFECT_ANALYSIS].[dbo].[T_paramconfigure] where  SubGroup like '" & selectedGroupId & "'  order by HeaderName"
            query = "  select distinct HeaderName,YAxisCol,Sequence  FROM [FP_DEFECT_ANALYSIS].[dbo].[T_paramconfigure] where  SubGroup like '" & selectedGroupId & "'  order by Sequence"

            'ElseIf selectedGroupId = "2" Then
            '    query = "select [YAxisCol], [HeaderName],idx From [TSM_Process_data].[dbo].[T_CHART] where isactive=1 and [SubUnit] like 'CCL%' and subgroup like 'PrimeCoater%' order by idx "
            'ElseIf selectedGroupId = "3" Then
            '    query = "select [YAxisCol], [HeaderName],idx From [TSM_Process_data].[dbo].[T_CHART] where isactive=1 and [SubUnit] like 'CCL%' and subgroup like 'FinishCoate%' order by idx "
            'ElseIf selectedGroupId = "4" Then
            '    query = "select [YAxisCol], [HeaderName],idx From [TSM_Process_data].[dbo].[T_CHART] where isactive=1 and [SubUnit] like 'CCL%' and subgroup like 'Incinerato%' order by idx "
            'ElseIf selectedGroupId = "5" Then
            '    query = "select [YAxisCol], [HeaderName],idx From [TSM_Process_data].[dbo].[T_CHART] where isactive=1 and [SubUnit] like 'CCL%' and subgroup like 'PrimeOven%' order by idx "
            'ElseIf selectedGroupId = "6" Then
            '    query = "select [YAxisCol], [HeaderName],idx From [TSM_Process_data].[dbo].[T_CHART] where isactive=1 and [SubUnit] like 'CCL%' and subgroup like 'FinishOve%' order by idx "
            'End If
        End If


        Dim dtSubGroups As New DataTable()

        Using connection As New SqlConnection(connectionString)
            Using command As New SqlCommand(query, connection)
                connection.Open()
                dtSubGroups.Load(command.ExecuteReader())
            End Using
        End Using

        'Dim selectAllRow As DataRow = dtSubGroups.NewRow()
        'selectAllRow("HeaderName") = "Select All"
        'selectAllRow("idx") = 0
        'dtSubGroups.Rows.InsertAt(selectAllRow, 0)

        'For Each column As DataColumn In dtSubGroups.Columns
        '    dtColumns.Rows.Add(column.ColumnName)
        'Next

        CheckBoxListParametersSubGroup.DataSource = dtSubGroups
        CheckBoxListParametersSubGroup.DataTextField = "HeaderName"
        CheckBoxListParametersSubGroup.DataValueField = "YAxisCol"
        CheckBoxListParametersSubGroup.DataBind()
        chkSelectAll.Visible = True
    End Sub

    Private Sub chkSelectAll_CheckedChanged(sender As Object, e As EventArgs) Handles chkSelectAll.CheckedChanged
        If chkSelectAll.Checked Then
            For Each item As ListItem In CheckBoxListParametersSubGroup.Items
                item.Selected = True
            Next
        Else
            For Each item As ListItem In CheckBoxListParametersSubGroup.Items
                item.Selected = False
            Next

        End If
    End Sub
End Class

