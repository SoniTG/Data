﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO

Partial Class cgl2_slippage_summary
    Inherits System.Web.UI.Page
    Dim objDataHandler As New DataHandler
    Dim objController As New Controller
    Dim connectionString As String = "server=176.0.0.60\LPTGSQLDEV;database=FP_DEFECT_ANALYSIS;uid=153521;pwd=Welcome@135"

    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub


    Private Sub Bridle_Roll_SlipPage_Load(sender As Object, e As EventArgs) Handles Me.Load



        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))

                Dim dtStart As String = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd HH:mm:ss")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")

                If Not Request.QueryString("frm") Is Nothing Then
                    dtStart = Request.QueryString("frm").ToString.Replace("%20", " ")
                    dtEnd = Request.QueryString("to").ToString.Replace("%20", " ")

                End If

                txtFrom.Text = dtStart
                txtTo.Text = dtEnd

                GetThicknessWidthSpeed(dtStart, dtEnd)
                For Each item As ListItem In lstThickness.Items
                    item.Selected = True
                Next
                For Each item As ListItem In lstWidth.Items
                    item.Selected = True
                Next
                For Each item As ListItem In lstSpeed.Items
                    item.Selected = True
                Next









            Catch ex As Exception
                Throw ex
            End Try

        End If

    End Sub

    Sub GetThicknessWidthSpeed(ByVal dtStart As String, ByVal dtEnd As String)

        Dim query As String = ""
        Dim dtColumns As New DataTable()
        query = "SELECT distinct Thickness,Width,Speed FROM [FP_DEFECT_ANALYSIS].[dbo].[T_CRMCGL_Slip_bxplot] where START_TIME between '" & Convert.ToDateTime(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "' and speed > 0 order by Thickness"


        Using connection As New SqlConnection(connectionString)
            Using command As New SqlCommand(query, connection)
                connection.Open()
                dtColumns.Load(command.ExecuteReader())
                Dim distinctView As New DataView(dtColumns)
                distinctView.Sort = "Thickness ASC"
                Dim distinctTable As DataTable = distinctView.ToTable(True, "Thickness")
                lstThickness.DataSource = distinctTable
                lstThickness.DataTextField = "Thickness"
                lstThickness.DataValueField = "Thickness"
                lstThickness.DataBind()
                'lstThickness.Items.Insert(0, "All Group")

                Dim distinctViewWidth As New DataView(dtColumns)
                distinctViewWidth.Sort = "Width ASC"
                Dim distinctTableWidth As DataTable = distinctViewWidth.ToTable(True, "Width")
                lstWidth.DataSource = distinctTableWidth
                lstWidth.DataTextField = "Width"
                lstWidth.DataValueField = "Width"
                lstWidth.DataBind()

                Dim distinctViewSpeed As New DataView(dtColumns)
                distinctViewSpeed.Sort = "Speed ASC"
                Dim distinctTableSpeed As DataTable = distinctViewSpeed.ToTable(True, "Speed")
                lstSpeed.DataSource = distinctTableSpeed
                lstSpeed.DataTextField = "Speed"
                lstSpeed.DataValueField = "Speed"
                lstSpeed.DataBind()

            End Using
        End Using
    End Sub






    Protected Sub lnkSubmit_Click(sender As Object, e As System.EventArgs) Handles lnkSubmit.Click
        Try
            Dim dtStart As String = txtFrom.Text.Replace("T", " ")
            Dim dtEnd As String = txtTo.Text.Replace("T", " ")

            GetDataForTrendChart(dtStart, dtEnd)

            Dim strThickness As String = getSelectedData(lstThickness)
            If strThickness.Length > 0 Then
                strThickness = "" & strThickness.Replace(",", "','") & ""
            End If

            Dim strWidth As String = getSelectedData(lstWidth)
            If strWidth.Length > 0 Then
                strWidth = "" & strWidth.Replace(",", "','") & ""
            End If

            Dim strSpeed As String = getSelectedData(lstSpeed)
            If strSpeed.Length > 0 Then
                strSpeed = "" & strSpeed.Replace(",", "','") & ""
            End If


            Dim filter As String = " and 1=1"
            'If ddlGrade1.SelectedItem.Text.ToLower <> "all" Then
            '    filter1 &= " and GRADE = '" & ddlGrade1.SelectedItem.Text & "'"
            'End If
            If strThickness <> "" Then
                filter &= " and Thickness in ('" & strThickness & "')"
            End If

            If strWidth <> "" Then
                filter &= " and Width in ('" & strWidth & "')"
            End If

            If strSpeed <> "" Then
                filter &= " and Speed in ('" & strSpeed & "')"
            End If

            DrawAllChart(dtStart, dtEnd, filter)
            'GetDataForTrendChart(dtStart, dtEnd)
            'Dim GroupName As String = ""
            'For i As Integer = 0 To ListBoxParametersGroup.Items.Count - 1
            '    If ListBoxParametersGroup.Items(i).Selected = True Then
            '        GroupName &= ",'" & ListBoxParametersGroup.Items(i).Text.Trim & "'"
            '        'Response.Write(i)
            '    End If
            'Next
            'GroupName = GroupName.Substring(1)

            'Dim SubGroup As String = ""
            'For i As Integer = 0 To CheckBoxListParametersSubGroup.Items.Count - 1
            '    If CheckBoxListParametersSubGroup.Items(i).Selected = True Then
            '        SubGroup &= ",'" & CheckBoxListParametersSubGroup.Items(i).Text.Trim & "'"
            '        'Response.Write(i)
            '    End If
            'Next
            'SubGroup = SubGroup.Substring(1)
            'FetchHeaderName(GroupName, SubGroup)
            ''CreateDynamicContainer(HeaderAlias)
            'CreateDynamicContainer(HeaderName)
            'GetData()

        Catch ex As Exception
            ex.ToString()
        End Try

    End Sub

    Function getSelectedData(ByRef lst As ListBox) As String
        Dim retVal As String = ""
        For Each lstItem As ListItem In lst.Items
            If lstItem.Selected = True Then
                retVal &= "," & lstItem.Text & ""
            End If
        Next

        If (retVal.Length > 0) Then
            Return retVal.Substring(1)
        Else
            Return retVal
        End If

    End Function
    Sub DrawAllChart(ByVal dtStart As String, ByVal dtEnd As String, ByVal Filter As String)
        'Dim str As String = ""
        'Dim arrstr() As String
        'Dim i As Integer = 0
        'If listbxHeatNo.Items.Count > 0 Then
        '    For ir As Integer = 0 To listbxHeatNo.Items.Count - 1
        '        If listbxHeatNo.Items(ir).Selected = True Then
        '            ReDim Preserve arrstr(i)
        '            arrstr(i) = listbxHeatNo.Items(ir).Text
        '            i += 1
        '        Else
        '            'Exit For
        '        End If
        '    Next
        'Else
        '    Exit Sub
        'End If
        ''Array.Sort(arrstr)
        'If arrstr.Count = 1 Then
        '    str = "'" & arrstr(0) & "'"
        'Else
        '    str = "'" & arrstr(0) & "'" & ","
        '    For ir As Integer = 1 To arrstr.Count - 1
        '        If ir = arrstr.Count - 1 Then
        '            str = str & "'" & arrstr(ir) & "'"
        '        Else
        '            str = str & "'" & arrstr(ir) & "'" & ","
        '        End If

        '    Next
        'End If

        Dim qrygrid As String = String.Empty
        Dim qrygrid1 As String = String.Empty
        Dim qrygrid2 As String = String.Empty

        If Filter <> "" Then
            qrygrid = "  SELECT A.START_TIME,B.HeaderName,A.BOXPLOT_Val,A.Parameter FROM [FP_DEFECT_ANALYSIS].[dbo].[T_CRMCGL_Slip_bxplot] A inner join [FP_DEFECT_ANALYSIS].[dbo].[T_paramconfigure] B on A.Parameter = B.YAxisCol where START_TIME between '" & Convert.ToDateTime(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "' " & Filter & " and A.Parameter like '%spd%'  AND b.HeaderName NOT LIKE 'TOPROLL2%' AND b.HeaderName NOT LIKE 'TPRSNBR1%' order by B.Idx desc"
        Else
            qrygrid = "  SELECT A.START_TIME,B.HeaderName,A.BOXPLOT_Val,A.Parameter FROM [FP_DEFECT_ANALYSIS].[dbo].[T_CRMCGL_Slip_bxplot] A inner join [FP_DEFECT_ANALYSIS].[dbo].[T_paramconfigure] B on A.Parameter = B.YAxisCol where START_TIME between '" & Convert.ToDateTime(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "' and A.Parameter like '%spd%'  AND b.HeaderName NOT LIKE 'TOPROLL2%' AND b.HeaderName NOT LIKE 'TPRSNBR1%' order by B.Idx  desc"
        End If

        If Filter <> "" Then
            qrygrid1 = "  SELECT A.START_TIME,B.HeaderName,A.BOXPLOT_Val,A.Parameter FROM [FP_DEFECT_ANALYSIS].[dbo].[T_CRMCGL_Slip_bxplot] A inner join [FP_DEFECT_ANALYSIS].[dbo].[T_paramconfigure] B on A.Parameter = B.YAxisCol where START_TIME between '" & Convert.ToDateTime(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "' " & Filter & " and A.Parameter like '%curr%'  order by B.Idx desc"
        Else
            qrygrid1 = "  SELECT A.START_TIME,B.HeaderName,A.BOXPLOT_Val,A.Parameter FROM [FP_DEFECT_ANALYSIS].[dbo].[T_CRMCGL_Slip_bxplot] A inner join [FP_DEFECT_ANALYSIS].[dbo].[T_paramconfigure] B on A.Parameter = B.YAxisCol where START_TIME between '" & Convert.ToDateTime(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "' and A.Parameter like '%curr%'  order by B.Idx desc"
        End If

        If Filter <> "" Then
            qrygrid2 = "  SELECT A.START_TIME,B.HeaderName,A.BOXPLOT_Val,A.Parameter FROM [FP_DEFECT_ANALYSIS].[dbo].[T_CRMCGL_Slip_bxplot] A inner join [FP_DEFECT_ANALYSIS].[dbo].[T_paramconfigure] B on A.Parameter = B.YAxisCol where START_TIME between '" & Convert.ToDateTime(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "' " & Filter & " and A.Parameter like '%TM_%'  order by B.Idx desc"
        Else
            qrygrid2 = "  SELECT A.START_TIME,B.HeaderName,A.BOXPLOT_Val,A.Parameter FROM [FP_DEFECT_ANALYSIS].[dbo].[T_CRMCGL_Slip_bxplot] A inner join [FP_DEFECT_ANALYSIS].[dbo].[T_paramconfigure] B on A.Parameter = B.YAxisCol where START_TIME between '" & Convert.ToDateTime(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "' and A.Parameter like '%TM_%'  order by B.Idx desc"
        End If



        Dim dt, dt1, dt2 As DataTable
        dt = objDataHandler.GetDataSetFromQuery(qrygrid).Tables(0)
        dt1 = objDataHandler.GetDataSetFromQuery(qrygrid1).Tables(0)
        dt2 = objDataHandler.GetDataSetFromQuery(qrygrid2).Tables(0)





        BoxPlotEChartsWithOutliers(dt, "BOXPLOT_Val", Lit1, "container1", "plot1", "HeaderName", 2, 2, 1)
        BoxPlotEChartsWithOutliers(dt1, "BOXPLOT_Val", Lit2, "container2", "plot2", "HeaderName", 2, 2, 2)
        BoxPlotEChartsWithOutliers(dt, "BOXPLOT_Val", Lit4, "container4", "plot4", "HeaderName", 2, 6, 3)
        BoxPlotEChartsWithOutliers(dt1, "BOXPLOT_Val", Lit5, "container5", "plot5", "HeaderName", 2, 6, 4)
        BoxPlotEChartsWithOutliers(dt2, "BOXPLOT_Val", Lit6, "container6", "plot6", "HeaderName", 2, 2, 5)



    End Sub
    Sub BoxPlotEChartsWithOutliers(ByVal ds As DataTable, ByVal yValue As String, ByVal lit As Literal, ByVal containerName As String, ByVal PlotName As String, ByVal seriesOf As String, ByVal ColumnIndex As Integer, ByVal ValueIndex As Integer, ByVal idx As Integer)
        Dim js As String = "<script language='javascript' type='text/javascript'>"

        Dim Series() As String = (From row In ds Select col = row.Field(Of String)(seriesOf) Distinct).ToArray

        Dim xData As String = "["
        Dim arrData As String = "["
        Dim y_min As String = ""
        Dim y_max As String = ""
        'If ds.Rows.Count > 0 Then
        Dim tmpCyl() As String '= ds.Columns(2).ToString.Split(",")

        'Dim columnIndex As Integer = 2
        ReDim tmpCyl(ds.Rows.Count - 1)

        For i As Integer = 0 To ds.Rows.Count - 1
            tmpCyl(i) = ds.Rows(i)(ColumnIndex).ToString().Split(",")(ValueIndex)
        Next

        'Dim minValue As Double = CDbl(tmpCyl.Min) 'CDbl(ds.Compute("MIN([" & yValue & "])", ""))
        'Dim maxValue As Double = CDbl(tmpCyl.Max) 'CDbl(ds.Compute("MAX([" & yValue & "])", ""))
        Dim minValue As Double
        Dim maxValue As Double

        For Each stringValue As String In tmpCyl
            If Double.TryParse(stringValue, Nothing) Then
                Dim value As Double = CDbl(stringValue)

                If value < minValue Then
                    minValue = value
                End If

                If value > maxValue Then
                    maxValue = value
                End If
            End If
        Next
        y_min = minValue - (1 / 100 * minValue)
        y_max = maxValue + (1 / 100 * maxValue)
        'End If
        'Dim tmpCyl1() As String
        For i As Integer = 0 To Series.Length - 1 'MAIN LOOP
            'Dim tmpCyl(i) As String = ds.Rows(i)(2).ToString.Split(",")(2)
            'Dim tmpCyl() As String = ds.Rows(i)(1).ToString.Split(",")
            Dim x As Integer = i
            Dim query = From val In ds.AsEnumerable() Where val.Field(Of String)(seriesOf) = Series(x) Select val
            Dim dtValue As DataTable = query.CopyToDataTable()
            Dim arrYValues(dtValue.Rows.Count) As Decimal
            'arrYValues = (From row In dtValue Select col = Decimal.Parse(row(Trim(yValue)).ToString())).ToArray
            'arrYValues = (From row In tmpCyl Select col = Decimal.Parse(row(Trim(tmpCyl(2))).ToString())).ToArray()
            'arrYValues = (From row In dtValue Select col = Decimal.Parse(row(Trim(yValue).Split(",")(2)).ToString())).ToArray
            'arrYValues = dtValue.AsEnumerable() _
            '.Select(Function(row) Decimal.Parse(row(Trim(yValue).Split(","c)(2)).ToString())) _
            '.ToArray()

            arrYValues = dtValue.AsEnumerable() _
    .Select(Function(row) ParseDecimal(row.Field(Of String)(yValue), ValueIndex)) _
    .Where(Function(parsedValue) parsedValue.HasValue) _
    .Select(Function(parsedValue) parsedValue.Value) _
    .ToArray()

            'arrYValues = dtValue.AsEnumerable() _
            '.Select(Function(row) Decimal.Parse(row.Field(Of String)(yValue).Split(",")(ValueIndex))) _
            '.ToArray()

            'If arrYValues.Count > 0 Then
            '    y_min = arrYValues.Min() - (1 / 100 * arrYValues.Min)
            '    y_max = arrYValues.Max() + (1 / 100 * arrYValues.Max)
            'End If

            xData &= "'" & Series(x) & "',"
            If i > 0 Then arrData &= ","
            arrData &= "[" & String.Join(",", arrYValues) & "]"

        Next 'MAIN LOOP ENDS

        xData &= "]"
        arrData &= "]"

        js &= "var xdata" & idx & "=" & xData & ";"
        js &= "var data" & idx & " = echarts.dataTool.prepareBoxplotData(" & arrData & ");"
        js &= "var " & PlotName & "=echarts.init(document.getElementById('" & containerName & "'));" & PlotName & ".setOption("
        js &= "{ title:{text: 'Box',left: 'center'},tooltip: {trigger: 'item',},grid: {left: '25%',right: '5%',bottom: '5%'},xAxis: {type: 'value',"
        js &= "}, yAxis: {type: 'category',data: data" & idx & ".axisData,axisLabel:{formatter: function(value, index){ return xdata" & idx & "[index];}}}, toolbox: {left: 'right',feature: {dataZoom: {type: 'slider',show: true,start: 0,end: 100},restore: {},saveAsImage: {}}},series: [{name: 'boxplot',type: 'boxplot',data: data" & idx & ".boxData,"
        js &= "tooltip: {formatter: function (param) {return [xdata" & idx & "[param.dataIndex] + ': ','upper: ' + param.data[5],'Q3: ' + param.data[4],'median: ' + param.data[3], 'Q1: ' + param.data[2],'lower: ' + param.data[1] ].join('<br/>');}}},"
        'js &= "{name: 'outlier',type: 'scatter',data: data" & idx & ".outliers}]});"
        js &= "]});"

        ',max:" & Math.Round(Convert.ToDouble(y_max), 3) & ",min:" & Math.Round(Convert.ToDouble(y_min), 3) & "

        js &= "</script>"
        lit.Text = js
    End Sub

    Function ParseDecimal(input As String, index As Integer) As Decimal?
        Dim values As String() = input.Split(",")
        If index >= 0 AndAlso index < values.Length Then
            Dim value As String = values(index)
            Dim result As Decimal
            If Decimal.TryParse(value, result) Then
                Return result
            End If
        End If
        Return Nothing ' Parsing failed
    End Function


    Sub GetDataForTrendChart(ByVal FromDate As String, ByVal ToDate As String)
        Try
            Dim dtStart As String = FromDate
            Dim dtEnd As String = ToDate

            Lit2.Text = ""

            Dim dt As DataTable
            dt = objDataHandler.GetDataSetFromQuery("Select distinct START_TIME  ,Thickness,Width,Speed   FROM [FP_DEFECT_ANALYSIS].[dbo].[T_CRMCGL_Slip_bxplot] where START_TIME between  '" & Convert.ToDateTime(dtStart).ToString("yyyy-MM-dd HH:mm:ss") & "' and '" & Convert.ToDateTime(dtEnd).ToString("yyyy-MM-dd HH:mm:ss") & "' and Thickness > 0 and Width > 0 and Speed > 0 order by START_TIME").Tables(0)
            'BoxPlotForPltcmCylinder(dt, Lit1, "c" & i - 1, "plot" & (i + 1), "", i, plottypeDDl.SelectedValue.ToString)
            PlotTrendChart(dt, Lit3, "container3", "Plot3", "", 0, "Trend Plot")




        Catch ex As Exception
            Throw ex
        End Try

    End Sub
    Sub PlotTrendChart(ByVal dt As DataTable, ByVal lit As Literal, ByVal containerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal VAL As Integer, ByVal plottype As String)



        'lit.Text = ""
        Try
            ChartTitle = ""
            Dim ticks As String = "["
            'Dim line1, line2, line3, line4, line5 As String
            Dim line1, line2, line3 As String
            line1 &= "["
            line2 &= "["
            line3 &= "["
            'line4 &= "["
            'line5 &= "["

            'Dim multiplier, lsl, usl As String
            'If dt.Rows.Count > 0 Then
            '    multiplier = 1 'dt.Rows(0)("multiplier").ToString
            '    lsl = 0 'dt.Rows(0)("lsl").ToString
            '    usl = 0 'dt.Rows(0)("usl").ToString

            'End If
            'If multiplier = "" Then multiplier = 1

            'Dim mulfactor As Double = CDbl(multiplier)
            Dim yVal() As Decimal
            Dim min_ As Double
            Dim max_ As Double
            yVal = (From row In dt Select col = CDec(IIf(IsDBNull(row("Width")), 0, row("Width")))).ToArray()
            If yVal.Length > 0 Then
                min_ = yVal.Min() - (yVal.Min * 0.05)
                max_ = yVal.Max() + (yVal.Max * 0.05)
            End If
            For i As Integer = 0 To dt.Rows.Count - 1
                'If (dt.Rows(i)(1).ToString <> "") Then
                If Not IsDBNull(dt.Rows(i)(1)) Or Not IsDBNull(dt.Rows(i)(2)) Or Not IsDBNull(dt.Rows(i)(3)) Then
                    Try
                        ticks &= "'" & CDate(dt.Rows(i)("START_TIME")).ToString("dd-MMM HH:mm:ss") & "'"



                        'Dim tmpCyl() As String = dt.Rows(i)(1).ToString.Split(",")

                        'Dim lbound As Double = CDbl(tmpCyl(0))
                        'Dim ubound As Double = CDbl(tmpCyl(1))
                        'Dim min_ As Double = 0 'CDbl(tmpCyl(7))
                        'Dim max_ As Double = 1120 'CDbl(tmpCyl(8))

                        'If min_ >= lbound Then lbound = min_
                        'If max_ <= ubound Then ubound = max_

                        'line1 &= "[" & lbound * mulfactor & "," & tmpCyl(4) * mulfactor & "," & tmpCyl(3) * mulfactor & "," & tmpCyl(5) * mulfactor & "," & ubound * mulfactor & "]"

                        'line2 &= tmpCyl(2) * mulfactor 'avg
                        'line3 &= tmpCyl(7) * mulfactor 'min
                        'line4 &= tmpCyl(8) * mulfactor 'max
                        'line5 &= tmpCyl(6) * mulfactor 'stdev
                        line1 &= "" & dt.Rows(i)(1) & ""
                        line2 &= "" & dt.Rows(i)(2) & ""
                        line3 &= "" & dt.Rows(i)(3) & ""

                        If (i <> 0 Or i <> dt.Rows.Count - 1) Then
                            ticks &= ","
                            line1 &= ","
                            line2 &= ","
                            line3 &= ","
                            'line4 &= ","
                            'line5 &= ","
                        End If



                    Catch ex As Exception
                        Continue For
                    End Try
                End If

            Next
            ticks &= "]"
            line1 &= "]"
            line2 &= "]"
            line3 &= "]"
            'line4 &= "]"
            'line5 &= "]"

            Dim minmax As String = ""
            'If lsl <> "" And usl <> "" Then
            '    minmax = "min:" & lsl & ",max:" & usl
            'End If
            'Dim markline As String = ""
            'If lsl <> "" And usl <> "" Then
            '    markline = ",markLine: { data: [{  name: 'lsl',yAxis:" & lsl & ",lineStyle:{type:'solid',color:'red'} },{  name: 'usl',yAxis:" & usl & ",lineStyle:{type:'solid',color:'red'} }]}"
            'End If
            Dim js = "<script language='javascript' type='text/javascript'>"
            js &= "var ticks=" & ticks & ";"
            js &= "var pl1=" & line1 & ";"
            js &= "var pl2=" & line2 & ";"
            js &= "var pl3=" & line3 & ";"
            'js &= "var pl4=" & line4 & ";"
            'js &= "var pl5=" & line5 & ";"

            'js &= "var lmin = Math.min(Math.min.apply(null,pl2),Math.min.apply(null,pl3));"
            'js &= "var lmax = Math.max(Math.max.apply(null,pl2),Math.max.apply(null,pl3));"
            js &= "var lmin = " & min_ & ";"
            js &= "var lmax = " & max_ & ";"
            'js &= "var yMin = (lmin<-300)?lmin-5:-310; var yMax = (lmax>300)?lmax+ 5:310;"
            js &= "var yMin = lmin; var yMax = lmax;"
            'If (plottype = "Box Plot") Then
            '    js &= "option = { toolbox:{feature:{dataZoom:{}},right:'10%'},  tooltip: {trigger:    'item',axisPointer: {type:       'shadow'}},grid: {left:       '10%',top:'15%',right:      '10%',bottom: '25%'}, xAxis: {"
            '    js &= "type:       'category',   data:ticks, boundaryGap: true, nameGap: 30, splitArea: { show: true}, axisLabel: {rotate:45,formatter:  function (value, index) {return value.split(' ')[0];}}, splitLine: {show: false}}, yAxis: {type:'value',name:'Deviation',nameLocation:   'middle',nameGap: 40,splitArea: {show: false}," & minmax & "},"
            '    js &= " dataZoom: [{type:       'inside',start: 0,end: 100},{show: true,height: 20,type: 'slider',top:'90%',xAxisIndex: [0]}],"
            '    js &= " series: [{name:       'ACR Output (Count)',type:       'boxplot'" & markline & ", data: pl1,tooltip: {formatter: formatter}}]};"
            '    js &= "function formatter(param) {return [param.name,'upper: ' + param.data[5],'Q3: ' + param.data[4],'median: ' + param.data[3],'Q1: ' + param.data[2],'lower: ' + param.data[1]].join('<br/>')}"
            '    js &= "var " & PlotName & " = echarts.init(document.getElementById('" & containerName & "'));" & PlotName & ".setOption(option);"
            'ElseIf (plottype = "Average") Then
            js &= "option = {toolbox:{feature:{dataZoom:{},restore: {}},right:'10%'}, tooltip: {trigger: 'axis'}, legend: { y: '10%', data: ['Thickness','Width','Speed']},grid: {left:       '10%',top:'15%',right:      '10%',bottom: '12%'}, xAxis: {"
            js &= "type:       'category',   data:ticks,axisLabel: {rotate:45,formatter:  function (value, index) {return value.split(' ')[0];}}}, yAxis: {type: 'value',},"
            'js &= " dataZoom: [{type:       'inside',start: 0,end: 100},{show: true,height: 20,type: 'slider',top:'90%',xAxisIndex: [0]}],"
            js &= "series: [{name:       'Thickness',data: pl1, type:'line'},{name:       'Width',data: pl2, type:'line'},{name:       'Speed',data: pl3, type:'line'}]"
            js &= "};var  " & PlotName & " = echarts.init(document.getElementById('" & containerName & "'));" & PlotName & ".setOption(option);"
            'End If



            js &= "</script>"

            lit.Text &= js
        Catch ex As Exception
            Throw ex
        End Try



    End Sub



End Class

