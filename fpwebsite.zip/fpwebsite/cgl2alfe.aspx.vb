﻿Imports System.Data
Imports System.IO

Partial Class cgl2alfe
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
            txtFrom.Text = Now.AddDays(-30).ToString("yyyy-MM-dd HH:mm:ss")
            'txtFrom.Text = Now.AddMonths(-4).ToString("yyyy-MM-dd HH:mm:ss")
            txtTo.Text = Now.ToString("yyyy-MM-dd HH:mm:ss")

            If Session("SelectVal") = "CGL" Then

            ElseIf Session("SelectVal") = "CGL1" Then

            ElseIf Session("SelectVal") = "CGL2" Then
                btnOK_Click(sender, e)
            ElseIf Session("SelectVal") = "PLTCM" Then

            ElseIf Session("SelectVal") = "ECL" Then

            End If
        End If
    End Sub

    Sub DrawChartForCGL2(ByVal ChartTitle As String)
        Try
            ''ChartTitle = "Trend of Eff. Aluminium & Eff. Iron"
            Dim strfrmDt As String = txtFrom.Text.Trim
            Dim strToDt As String = txtTo.Text.Trim

            'Dim dt As DataTable = objController.GetWetChemicalTestData("CGL2_ZNBATH_TREND", strfrmDt, strToDt, "CZT_TIMESTAMP")

            'Dim dt1 As New DataTable
            'dt1.Columns.Add("CLR_DT_SAMPLING_DATE", GetType(DateTime))
            'dt1.Columns.Add("CLR_PARAM_MIN", GetType(Decimal))
            'dt1.Columns.Add("CLR_PARAM_TEST", GetType(String))
            'dt1.Columns.Add("CLR_TEST_VALUE", GetType(Decimal))

            'Dim dt2 As DataTable = dt.DefaultView.ToTable(True, "CLR_PARAM_TEST")
            'Dim dv As DataView = dt.DefaultView


            'For row As Integer = 0 To dt2.Rows.Count - 1
            '    dv.RowFilter = "CLR_PARAM_TEST='" & dt2.Rows(row)(0) & "' and CZT_POT_AL < 1 and CZT_POT_FE < 1"
            '    For j As Integer = 0 To dv.Count - 1
            '        If dt2.Rows(row)(0) = "ZAAL" Then
            '            dt1.Rows.Add(dv(j)(0), 1.0, "ZAAL", dv.Item(j)(1))
            '            dt1.Rows.Add(dv(j)(0), 2.0, "ZAFE_AL", dv.Item(j)(2))
            '        ElseIf dt2.Rows(row)(0) = "ZAZS" Then
            '            dt1.Rows.Add(dv(j)(0), 3.0, "ZAZS", dv.Item(j)(1))
            '            dt1.Rows.Add(dv(j)(0), 4.0, "ZAFE_ZS", dv.Item(j)(2))
            '        ElseIf dt2.Rows(row)(0) = "ZAGA" Then
            '            dt1.Rows.Add(dv(j)(0), 5.0, "ZAGA", dv.Item(j)(1))
            '            dt1.Rows.Add(dv(j)(0), 6.0, "ZAFE_GA", dv.Item(j)(2))
            '        End If
            '    Next
            '    dv.RowFilter = ""
            'Next

            'objController.PlotBoxPlotChartForCGL2(dt1, "CLR_TEST_VALUE", Lit3, "container1", "plot11", "dataA", "CLR_PARAM_MIN", "outlierDataA", ChartTitle, "", "Avg_A")
            '----------------------------Top Right Chart-----------------------------------------------------------------------------------------------------------------
            Dim dt As DataTable = objController.GetWetChemicalTestData("CGL2_ZNBATH_TREND", strfrmDt, strToDt, "CZT_TIMESTAMP", "CZT_POT_AL", "CZT_POT_FE", "CZT_CAMP_AL")


            Dim dt1 As New DataTable
            dt1.Columns.Add("CLR_DT_SAMPLING_DATE", GetType(DateTime))
            dt1.Columns.Add("CLR_PARAM_MIN", GetType(Decimal))
            dt1.Columns.Add("CLR_PARAM_TEST", GetType(String))
            dt1.Columns.Add("CLR_TEST_VALUE", GetType(Decimal))

            Dim dt2 As DataTable = dt.DefaultView.ToTable(True, "CLR_PARAM_TEST")
            Dim dv As DataView = dt.DefaultView


            For row As Integer = 0 To dt2.Rows.Count - 1
                dv.RowFilter = "CLR_PARAM_TEST='" & dt2.Rows(row)(0) & "' and CZT_POT_AL < 1 and CZT_POT_FE < 1"
                For j As Integer = 0 To dv.Count - 1
                    'If dt2.Rows(row)(0) = "ZAAL" Then
                    '    dt1.Rows.Add(dv(j)(0), 1.0, "ZAAL", dv.Item(j)(1))
                    '    dt1.Rows.Add(dv(j)(0), 2.0, "ZAFE_AL", dv.Item(j)(2))
                    'ElseIf dt2.Rows(row)(0) = "ZAZS" Then
                    '    dt1.Rows.Add(dv(j)(0), 3.0, "ZAZS", dv.Item(j)(1))
                    '    dt1.Rows.Add(dv(j)(0), 4.0, "ZAFE_ZS", dv.Item(j)(2))
                    'ElseIf dt2.Rows(row)(0) = "ZAGA" Then
                    '    dt1.Rows.Add(dv(j)(0), 5.0, "ZAGA", dv.Item(j)(1))
                    '    dt1.Rows.Add(dv(j)(0), 6.0, "ZAFE_GA", dv.Item(j)(2))
                    'End If
                    If dv(j)(1) >= 0.1 And dv(j)(1) <= 0.15 Then
                        dt1.Rows.Add(dv(j)(0), 1.0, "GA_AL", dv.Item(j)(1))
                        dt1.Rows.Add(dv(j)(0), 2.0, "GA_FE", dv.Item(j)(2))
                    ElseIf dv(j)(1) > 0.15 And dv(j)(1) <= 0.4 Then
                        dt1.Rows.Add(dv(j)(0), 3.0, "GI_AL", dv.Item(j)(1))
                        dt1.Rows.Add(dv(j)(0), 4.0, "GI_FE", dv.Item(j)(2))

                    End If
                Next
                dv.RowFilter = ""
            Next

            objController.PlotBoxPlotChartForCGL2(dt1, "CLR_TEST_VALUE", Lit3, "container1", "plot11", "dataA", "CLR_PARAM_MIN", "outlierDataA", ChartTitle, "", "Avg_A", "Pot", 0, 0.4)
            '-----------------Top Right Chart End-------------------------------------------------------------------------------------------------------------------------

            '-----------------Bottom Right Chart--------------------------------------------------------------------------------------------------------------------------
            Dim dt3 As DataTable = objController.GetWetChemicalTestData("CGL2_ZNBATH_TREND", strfrmDt, strToDt, "CZT_TIMESTAMP", "CZT_EFF_AL", "CZT_EFF_FE", "CZT_CAMP_AL")


            Dim dt4 As New DataTable
            dt4.Columns.Add("CLR_DT_SAMPLING_DATE", GetType(DateTime))
            dt4.Columns.Add("CLR_PARAM_MIN", GetType(Decimal))
            dt4.Columns.Add("CLR_PARAM_TEST", GetType(String))
            dt4.Columns.Add("CLR_TEST_VALUE", GetType(Decimal))

            Dim dt5 As DataTable = dt3.DefaultView.ToTable(True, "CLR_PARAM_TEST")
            Dim dv1 As DataView = dt3.DefaultView


            For row As Integer = 0 To dt5.Rows.Count - 1
                dv1.RowFilter = "CLR_PARAM_TEST='" & dt5.Rows(row)(0) & "' and CZT_EFF_AL < 1 and CZT_EFF_FE < 1"
                For j As Integer = 0 To dv1.Count - 1
                    'If dt5.Rows(row)(0) = "ZAAL" Then
                    '    dt4.Rows.Add(dv1(j)(0), 1.0, "ZAAL", dv1.Item(j)(1))
                    '    dt4.Rows.Add(dv1(j)(0), 2.0, "ZAFE_AL", dv1.Item(j)(2))
                    'ElseIf dt5.Rows(row)(0) = "ZAZS" Then
                    '    dt4.Rows.Add(dv1(j)(0), 3.0, "ZAZS", dv1.Item(j)(1))
                    '    dt4.Rows.Add(dv1(j)(0), 4.0, "ZAFE_ZS", dv1.Item(j)(2))
                    'ElseIf dt5.Rows(row)(0) = "ZAGA" Then
                    '    dt4.Rows.Add(dv1(j)(0), 5.0, "ZAGA", dv1.Item(j)(1))
                    '    dt4.Rows.Add(dv1(j)(0), 6.0, "ZAFE_GA", dv1.Item(j)(2))
                    'End If
                    If dv1(j)(1) >= 0.1 And dv1(j)(1) <= 0.15 Then
                        dt4.Rows.Add(dv(j)(0), 1.0, "GA_AL", dv.Item(j)(1))
                        dt4.Rows.Add(dv(j)(0), 2.0, "GA_FE", dv.Item(j)(2))
                    ElseIf dv1(j)(1) > 0.15 And dv1(j)(1) <= 0.4 Then
                        dt4.Rows.Add(dv(j)(0), 3.0, "GI_AL", dv.Item(j)(1))
                        dt4.Rows.Add(dv(j)(0), 4.0, "GI_FE", dv.Item(j)(2))

                    End If
                Next
                dv1.RowFilter = ""
            Next

            objController.PlotBoxPlotChartForCGL2(dt4, "CLR_TEST_VALUE", Lit4, "container3", "plot22", "dataB", "CLR_PARAM_MIN", "outlierDataB", ChartTitle, "", "Avg_B", "Eff", 0, 0.4)
            '-----------------Bottom Right Chart End----------------------------------------------------------------------------------------------------------------------
            '--------------TOP LEFT CHART----------------------------------------------------------------------
            '--------------TOP LEFT CHART END----------------------------------------------------------------------
            '--------------TOP RIGHT CHART----------------------------------------------------------------------
            '--------------TOP RIGHT CHART END----------------------------------------------------------------------
        Catch ex As Exception

        End Try
    End Sub

    Sub DrawActualTrendline(ByVal ChartTitle As String)
        Try
            'ChartTitle = "Trend of Eff. Aluminium & Eff. Iron"
            Dim strfrmDt As String = txtFrom.Text.Trim
            Dim strToDt As String = txtTo.Text.Trim

            Dim dt As DataTable = objController.GetWetChemicalTestData(Session("TableName"), strfrmDt, strToDt, Session("DateColumn"), "CLR_PROCESS_LINE = 'L' AND (CLR_PARAM_TEST in ('ZAZS','ZAAL','ZAGA') or CLR_PARAM_TEST in ('ZAFE'))", "CLR_PARAM_MIN")
            Dim dv As DataView = dt.DefaultView

            dv.RowFilter = "CLR_PARAM_TEST IN ('ZAAL','ZAZS','ZAGA')"

            Dim dtAL As DataTable = dv.ToTable
            ViewState("dtAL") = dtAL

            Dim dtFE As New DataTable
            dt.DefaultView.RowFilter = String.Empty
            dv = dt.DefaultView
            dv.RowFilter = "CLR_PARAM_TEST IN ('ZAFE')"
            dtFE = dv.ToTable
            ViewState("dtFE") = dtFE

            Dim y1Values(), y2Values() As String
            y1Values = (From row In dtAL Select col = row(Session("YValueColumn")).ToString).ToArray
            y2Values = (From row In dtFE Select col = row(Session("YValueColumn")).ToString).ToArray

            Dim y1_min As String = y1Values.Min() - (10 / 100 * y1Values.Min)
            Dim y1_max As String = y1Values.Max() + (10 / 100 * y1Values.Max)
            Dim y2_min As String = y2Values.Min() - (10 / 100 * y2Values.Min)
            Dim y2_max As String = y2Values.Max() + (10 / 100 * y2Values.Max)
            'objController.PlotLineChartWithSecondaryYAxisCampaignwise(dt, Session("DateColumn"), y1_min, y1_max, y2_min, y2_max, Lit1, "container", "plot1", ChartTitle, "'ZAZS','ZAAL','ZAGA'", "'ZAFE'", "priData", "secData", "Aluminium", "Iron")
            objController.PlotLineChartWithSecondaryYAxisCampaignwise(dt, Session("DateColumn"), y1_min, y1_max, y2_min, y2_max, Lit1, "container", "plot1", ChartTitle, "'ZAZS','ZAAL','ZAGA'", "'ZAFE'", "priData", "secData", "% Al", "% Fe")
        Catch ex As Exception

        End Try
    End Sub

    Sub DrawEffectiveTrendline(ByVal ChartTitle As String)
        'ChartTitle = "Trend of Eff. Aluminium & Eff. Iron"
        Dim strfrmDt As String = txtFrom.Text.Trim
        Dim strToDt As String = txtTo.Text.Trim

        Dim dt As DataTable = objController.GetEffectiveAlFeData(strfrmDt, strToDt)

        'Dim dt As DataTable = objController.GetWetChemicalTestData(Session("TableName"), strfrmDt, strToDt, Session("DateColumn"), "CLR_PROCESS_LINE = 'L' AND (CLR_PARAM_TEST in ('ZAZS','ZAAL','ZAGA') or CLR_PARAM_TEST in ('ZAFE'))", "CLR_PARAM_MIN")
        'Dim dv As DataView = dt.DefaultView

        'dv.RowFilter = "CLR_PARAM_TEST IN ('ZAAL','ZAZS','ZAGA')"

        'Dim dtAL As DataTable = dv.ToTable
        'ViewState("dtAL") = dtAL

        'Dim dtFE As New DataTable
        'dt.DefaultView.RowFilter = String.Empty
        'dv = dt.DefaultView
        'dv.RowFilter = "CLR_PARAM_TEST IN ('ZAFE')"
        'dtFE = dv.ToTable
        'ViewState("dtFE") = dtFE

        Dim y1Values() As Decimal = (From row In dt Select col = CDec(row("CZT_EFF_AL"))).ToArray
        Dim y2Values() As Decimal = (From row In dt Select col = CDec(row("CZT_EFF_FE"))).ToArray

        Dim y1_min As String = y1Values.Min() - (10 / 100 * y1Values.Min)
        Dim y1_max As String = y1Values.Max() + (10 / 100 * y1Values.Max)
        Dim y2_min As String = y2Values.Min() - (10 / 100 * y2Values.Min)
        Dim y2_max As String = y2Values.Max() + (10 / 100 * y2Values.Max)
        objController.PlotLineChartWithSecondaryYAxisCampaignwiseEff(dt, "CZT_TIMESTAMP", y1_min, y1_max, y2_min, y2_max, Lit2, "container2", "plot2", ChartTitle, "", "", "Aluminium", "Iron")
    End Sub

    Protected Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        If objController.IsValidDateRange(txtFrom, txtTo) Then
            DrawChartForCGL2("")
            DrawActualTrendline("Trend of Pot Aluminium & Pot Iron")
            DrawEffectiveTrendline("Trend of Eff. Aluminium & Eff. Iron")
        Else
            UserMsgBoxError("Date range incorrect.")
        End If

    End Sub
End Class