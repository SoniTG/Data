﻿Imports System.Data
Imports System.IO
Partial Class cgl2alfemonitoring
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                'Dim dtStart As Date = Date.Today.AddDays(-29)
                Dim dtStart As DateTime = DateTime.Now.AddDays(-29).ToString("yyyy-MM-dd HH:mm")
                'Dim dtStart As DateTime = DateTime.Now.AddMonths(-4).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As DateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                DrawChartTop("CLR_PROCESS_LINE = 'L' AND (CLR_PARAM_TEST in ('ZAAL','ZAGA','ZAZS') or CLR_PARAM_TEST in ('ZAFE'))", "", "first", Lit1, Lit3, dtStart, dtEnd)
                'DrawChartForCGL2("", "", "first", dtStart, dtEnd)
                EffectiveAlAndFeChart(dtStart, dtEnd)
                DrawPotTempChart(dtStart.ToString("yyyy-MM-dd HH:mm"), dtEnd.ToString("yyyy-MM-dd HH:mm"))
                mview.ActiveViewIndex = 0
                Dim dt As DataTable = objController.getLastPotData()
                If dt.Rows.Count > 0 Then
                    Dim runningPot As String = dt.Rows(0)(0)
                    Dim potStart As DateTime = dt.Rows(0)(1)
                    If IsDBNull(dt.Rows(0)(2)) Then
                        If runningPot = "POT1" Then
                            txtPOT1From.Text = potStart.ToString("dd-MMM-yyyy HH:mm:ss")
                            txtPOT1From.Enabled = False
                            btnPOT1Start.Enabled = False
                            txtPOT2From.Enabled = False
                            txtPOT2To.Enabled = False
                            btnPOT2Start.Enabled = False
                            btnPOT2End.Enabled = False
                            txtPOT1To.Enabled = True
                            btnPOT1End.Enabled = True
                        Else
                            txtPOT2From.Text = potStart.ToString("dd-MMM-yyyy HH:mm:ss")
                            txtPOT2From.Enabled = False
                            btnPOT2Start.Enabled = False
                            txtPOT1From.Enabled = False
                            txtPOT1To.Enabled = False
                            btnPOT1Start.Enabled = False
                            btnPOT1End.Enabled = False
                            txtPOT2To.Enabled = True
                            btnPOT2End.Enabled = True
                        End If
                    Else
                        If runningPot = "POT1" Then
                            txtPOT1From.Enabled = False
                            btnPOT1Start.Enabled = False
                            txtPOT2From.Enabled = True
                            txtPOT2To.Enabled = False
                            btnPOT2Start.Enabled = True
                            btnPOT2End.Enabled = False
                            txtPOT1To.Enabled = False
                            btnPOT1End.Enabled = False
                        Else
                            txtPOT2From.Enabled = False
                            btnPOT2Start.Enabled = False
                            txtPOT1From.Enabled = True
                            txtPOT1To.Enabled = False
                            btnPOT1Start.Enabled = True
                            btnPOT1End.Enabled = False
                            txtPOT2To.Enabled = False
                            btnPOT2End.Enabled = False
                        End If
                    End If
                End If

            Catch ex As Exception

            End Try
        End If

    End Sub

    Sub DrawPotTempChart(ByVal stDate As String, ByVal toDate As String)
        Try
            'Dim ds As DataTable = objController.GetPotTempData(stDate, toDate)
            Dim ds As DataTable = objController.GetPotTempData_Modified(stDate, toDate)
            ' objController.PlotLineChartForBathManagement(ds, "prm_ts_end", "PRM_ZINC_POT_TMP", Lit6, "divControl", "plot5", "", "", 11)
            objController.PlotLineChartForBathManagement_Modified(ds, "prm_ts_end", "PRM_ZINC_POT_TMP", Lit6, "divControl", "plot5", "", "", "PRM_SEC1_COIL")
            objController.PlotLineChartCGL2DiffTmp(ds, "prm_ts_end", "tmpdiff", Lit7, "divDiff", "plot7", "", "", "prm_sec1_coil")
        Catch ex As Exception

        End Try

    End Sub

    Sub DrawChartTop(ByVal Filter As String, ByVal ChartTitle As String, ByVal val As String, ByVal lita As Literal, ByVal litb As Literal, ByVal dtStart As DateTime, ByVal dtEnd As DateTime)
        Try

            lita.Text = ""
            litb.Text = ""
            'ChartTitle = "Trend of Eff. Aluminium & Eff. Iron"
            Dim strfrmDt As String = dtStart.ToString("yyyy-MM-dd HH:mm")
            Dim strToDt As String = dtEnd.ToString("yyyy-MM-dd HH:mm")

            Dim dt As DataTable = objController.GetWetChemicalTestData(Session("TableName"), strfrmDt, strToDt, Session("DateColumn"), Filter, "CLR_PARAM_MIN")
            Dim dv As DataView = dt.DefaultView
            If val = "first" Then
                dv.RowFilter = "CLR_PARAM_TEST" & " IN ('ZAAL','ZAGA','ZAZS')"
            End If
            Dim dtAL As DataTable = dv.ToTable
            ViewState("dtAL") = dtAL

            Dim dtFE As New DataTable
            dt.DefaultView.RowFilter = String.Empty

            dv = dt.DefaultView
            dv.RowFilter = "CLR_PARAM_TEST" & " IN ('ZAFE')"
            dtFE = dv.ToTable
            ViewState("dtFE") = dtFE

            If val = "first" Then
                'If ViewState("HaveY2AxisTop") = True Then
                Dim y1Values(), y2Values() As String
                y1Values = (From row In dtAL Select col = row(Session("YValueColumn")).ToString).ToArray
                y2Values = (From row In dtFE Select col = row(Session("YValueColumn")).ToString).ToArray

                Dim y1_min As String = y1Values.Min() - (10 / 100 * y1Values.Min)
                Dim y1_max As String = y1Values.Max() + (10 / 100 * y1Values.Max)
                Dim y2_min As String = y2Values.Min() - (10 / 100 * y2Values.Min)
                Dim y2_max As String = y2Values.Max() + (10 / 100 * y2Values.Max)
                'If Session("SelectVal") = "CGL2" Then

                objController.PlotLineChartWithSecondaryYAxisCampaignwise(dt, Session("DateColumn"), y1_min, y1_max, y2_min, y2_max, Lit1, "container", "plot1", ChartTitle, "'ZAAL','ZAGA','ZAZS'", "'ZAFE'", "priData", "secData", "% Al", "% Fe")
                'End If

                'added for pot1 and pot2
                If dt.Rows.Count > 0 Then
                    Dim str As String = objController.getPotString(strfrmDt, strToDt)
                    Lit5.Text = str
                End If

            End If
        Catch ex As Exception

        End Try
    End Sub

    Sub EffectiveAlAndFeChart(ByVal dtStart As DateTime, ByVal dtEnd As DateTime)
        Try
            Dim fromdt As DateTime = dtStart
            Dim todt As DateTime = dtEnd
            
            Lit3.Text = ""
            Dim dt As DataTable = objController.GetZnBathTrendData(fromdt.ToString("yyyy-MM-dd HH:mm:ss"), todt.ToString("yyyy-MM-dd HH:mm:ss"))
            Dim query = From val In dt.AsEnumerable() Where val.Field(Of String)("CAMPAIGN") = "GI" Select val Order By val.Field(Of DateTime)("CZT_TIMESTAMP")
            Dim dtGI As DataTable
            Try
                dtGI = query.CopyToDataTable
            Catch ex As Exception
                dtGI = New DataTable
            End Try

            query = From val In dt.AsEnumerable() Where val.Field(Of String)("CAMPAIGN") = "GA" Select val Order By val.Field(Of DateTime)("CZT_TIMESTAMP")
            Dim dtGA As DataTable
            Try
                dtGA = query.CopyToDataTable
            Catch ex As Exception
                dtGA = New DataTable
            End Try


            'Below are the temporary datatables holding false record in between two rows having time difference of 24 hours or more.
            Dim dtGI_Temp As New DataTable
            dtGI_Temp.Columns.Add("CZT_EFF_AL", GetType(Decimal))
            dtGI_Temp.Columns.Add("CZT_EFF_FE", GetType(Decimal))
            dtGI_Temp.Columns.Add("CZT_TIMESTAMP", GetType(DateTime))
            dtGI_Temp.Columns.Add("CZT_CAMP_AL", GetType(String))
            dtGI_Temp.Columns.Add("CZT_POT_AL", GetType(Decimal))
            dtGI_Temp.Columns.Add("CZT_POT_FE", GetType(Decimal))
            dtGI_Temp.Columns.Add("CAMPAIGN", GetType(String))
            dtGI_Temp.Columns.Add("UCL", GetType(Decimal))
            dtGI_Temp.Columns.Add("LCL", GetType(Decimal))
            For i As Integer = 0 To dtGI.Rows.Count - 1
                Dim row As DataRow = dtGI_Temp.NewRow
                row("CZT_EFF_AL") = dtGI.Rows(i)("CZT_EFF_AL")
                row("CZT_EFF_FE") = dtGI.Rows(i)("CZT_EFF_FE")
                row("CZT_TIMESTAMP") = CDate(dtGI.Rows(i)("CZT_TIMESTAMP"))
                row("CZT_CAMP_AL") = dtGI.Rows(i)("CZT_CAMP_AL")
                row("CZT_POT_AL") = dtGI.Rows(i)("CZT_POT_AL")
                row("CZT_POT_FE") = dtGI.Rows(i)("CZT_POT_FE")
                row("CAMPAIGN") = dtGI.Rows(i)("CAMPAIGN")
                row("UCL") = dtGI.Rows(i)("UCL")
                row("LCL") = dtGI.Rows(i)("LCL")
                dtGI_Temp.Rows.Add(row)
                If i < dtGI.Rows.Count - 1 Then
                    Dim span As TimeSpan = DateTime.Parse(dtGI.Rows(i + 1)("CZT_TIMESTAMP")).Subtract(DateTime.Parse(dtGI.Rows(i)("CZT_TIMESTAMP")))
                    If span.TotalHours >= 24 Then
                        dtGI_Temp.Rows.Add(dtGI.Rows(i)("CZT_EFF_AL"), dtGI.Rows(i)("CZT_EFF_FE"), CDate(dtGI.Rows(i)("CZT_TIMESTAMP")).AddMinutes(10),
                                           dtGI.Rows(i)("CZT_CAMP_AL"), dtGI.Rows(i)("CZT_POT_AL"), dtGI.Rows(i)("CZT_POT_FE"), dtGI.Rows(i)("CAMPAIGN"), 0, 0)
                    End If
                End If
            Next

            Dim dtGA_Temp As New DataTable
            dtGA_Temp.Columns.Add("CZT_EFF_AL", GetType(Decimal))
            dtGA_Temp.Columns.Add("CZT_EFF_FE", GetType(Decimal))
            dtGA_Temp.Columns.Add("CZT_TIMESTAMP", GetType(DateTime))
            dtGA_Temp.Columns.Add("CZT_CAMP_AL", GetType(String))
            dtGA_Temp.Columns.Add("CZT_POT_AL", GetType(Decimal))
            dtGA_Temp.Columns.Add("CZT_POT_FE", GetType(Decimal))
            dtGA_Temp.Columns.Add("CAMPAIGN", GetType(String))
            dtGA_Temp.Columns.Add("UCL", GetType(Decimal))
            dtGA_Temp.Columns.Add("LCL", GetType(Decimal))
            For i As Integer = 0 To dtGA.Rows.Count - 1
                Dim row As DataRow = dtGA_Temp.NewRow
                row("CZT_EFF_AL") = dtGA.Rows(i)("CZT_EFF_AL")
                row("CZT_EFF_FE") = dtGA.Rows(i)("CZT_EFF_FE")
                row("CZT_TIMESTAMP") = CDate(dtGA.Rows(i)("CZT_TIMESTAMP"))
                row("CZT_CAMP_AL") = dtGA.Rows(i)("CZT_CAMP_AL")
                row("CZT_POT_AL") = dtGA.Rows(i)("CZT_POT_AL")
                row("CZT_POT_FE") = dtGA.Rows(i)("CZT_POT_FE")
                row("CAMPAIGN") = dtGA.Rows(i)("CAMPAIGN")
                row("UCL") = dtGA.Rows(i)("UCL")
                row("LCL") = dtGA.Rows(i)("LCL")
                dtGA_Temp.Rows.Add(row)
                If i < dtGA.Rows.Count - 1 Then
                    Dim span As TimeSpan = DateTime.Parse(dtGA.Rows(i + 1)("CZT_TIMESTAMP")).Subtract(DateTime.Parse(dtGA.Rows(i)("CZT_TIMESTAMP")))
                    If span.TotalHours >= 24 Then
                        dtGA_Temp.Rows.Add(dtGA.Rows(i)("CZT_EFF_AL"), dtGA.Rows(i)("CZT_EFF_FE"), CDate(dtGA.Rows(i)("CZT_TIMESTAMP")).AddMinutes(10),
                                           dtGA.Rows(i)("CZT_CAMP_AL"), dtGA.Rows(i)("CZT_POT_AL"), dtGA.Rows(i)("CZT_POT_FE"), dtGA.Rows(i)("CAMPAIGN"), 0, 0)
                    End If
                End If
            Next
            '---------------------------------------END OF TEMPORARY DATATABLES----------------------------------------------

            'Dim giUclDataPoints As String = "var GI_UCL = [['" & CDate(dtGI.Rows(0)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGI.Rows(0)("UCL") & "], ['" & CDate(dtGI.Rows(dtGI.Rows.Count - 1)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGI.Rows(dtGI.Rows.Count - 1)("UCL") & "]];"
            Dim giUclDataPoints As String = "var GI_UCL = [["
            For i As Integer = 0 To dtGI_Temp.Rows.Count - 1
                If i = dtGI_Temp.Rows.Count - 1 Then
                    giUclDataPoints &= "'" & CDate(dtGI_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGI_Temp.Rows(i)("UCL") = 0, "null", dtGI_Temp.Rows(i)("UCL")) & "]];"
                Else
                    giUclDataPoints &= "'" & CDate(dtGI_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGI_Temp.Rows(i)("UCL") = 0, "null", dtGI_Temp.Rows(i)("UCL")) & "], ["
                End If
            Next
            If dtGI_Temp.Rows.Count = 0 Then
                giUclDataPoints &= "]];"
            End If
            'Dim giLclDataPoints As String = "var GI_LCL = [['" & CDate(dtGI_Temp.Rows(0)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGI_Temp.Rows(0)("LCL") & "], ['" & CDate(dtGI_Temp.Rows(dtGI_Temp.Rows.Count - 1)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGI_Temp.Rows(dtGI_Temp.Rows.Count - 1)("LCL") & "]];"
            Dim giLclDataPoints As String = "var GI_LCL = [["
            For i As Integer = 0 To dtGI_Temp.Rows.Count - 1
                If i = dtGI_Temp.Rows.Count - 1 Then
                    giLclDataPoints &= "'" & CDate(dtGI_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGI_Temp.Rows(i)("LCL") = 0, "null", dtGI_Temp.Rows(i)("LCL")) & "]];"
                Else
                    giLclDataPoints &= "'" & CDate(dtGI_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGI_Temp.Rows(i)("LCL") = 0, "null", dtGI_Temp.Rows(i)("LCL")) & "], ["
                End If
            Next
            If dtGI_Temp.Rows.Count = 0 Then
                giLclDataPoints &= "]];"
            End If
            'Dim gaUclDataPoints As String = "var GA_UCL = [['" & CDate(dtGA.Rows(0)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGA.Rows(0)("UCL") & "], ['" & CDate(dtGA.Rows(dtGA.Rows.Count - 1)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGA.Rows(dtGA.Rows.Count - 1)("UCL") & "]];"
            Dim gaUclDataPoints As String = "var GA_UCL = [["
            For i As Integer = 0 To dtGA_Temp.Rows.Count - 1
                If i = dtGA_Temp.Rows.Count - 1 Then
                    gaUclDataPoints &= "'" & CDate(dtGA_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGA_Temp.Rows(i)("UCL") = 0, "null", dtGA_Temp.Rows(i)("UCL")) & "]];"
                Else
                    gaUclDataPoints &= "'" & CDate(dtGA_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGA_Temp.Rows(i)("UCL") = 0, "null", dtGA_Temp.Rows(i)("UCL")) & "], ["
                End If
            Next
            If dtGA_Temp.Rows.Count = 0 Then
                gaUclDataPoints &= "]];"
            End If
            'Dim gaLclDataPoints As String = "var GA_LCL = [['" & CDate(dtGA_Temp.Rows(0)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGA_Temp.Rows(0)("LCL") & "], ['" & CDate(dtGA_Temp.Rows(dtGA_Temp.Rows.Count - 1)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & dtGA_Temp.Rows(dtGA_Temp.Rows.Count - 1)("LCL") & "]];"
            Dim gaLclDataPoints As String = "var GA_LCL = [["
            For i As Integer = 0 To dtGA_Temp.Rows.Count - 1
                If i = dtGA_Temp.Rows.Count - 1 Then
                    gaLclDataPoints &= "'" & CDate(dtGA_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGA_Temp.Rows(i)("LCL") = 0, "null", dtGA_Temp.Rows(i)("LCL")) & "]];"
                Else
                    gaLclDataPoints &= "'" & CDate(dtGA_Temp.Rows(i)("CZT_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm") & "', " & IIf(dtGA_Temp.Rows(i)("LCL") = 0, "null", dtGA_Temp.Rows(i)("LCL")) & "], ["
                End If
            Next
            If dtGA_Temp.Rows.Count = 0 Then
                gaLclDataPoints &= "]];"
            End If
            Dim min_time, max_time As String
            min_time = Format(dt.Rows(0)("CZT_TIMESTAMP"), "yyyy-MM-dd HH:mm")
            max_time = Format(dt.Rows(dt.Rows.Count - 1)("CZT_TIMESTAMP"), "yyyy-MM-dd HH:mm")

            Dim xTimestampVal(), y1EffectiveAlVal(), y2EffectiveFe() As String

            xTimestampVal = (From row In dt Select col = row("CZT_TIMESTAMP").ToString).ToArray
            y1EffectiveAlVal = (From row In dt Select col = row("CZT_EFF_AL").ToString).ToArray()
            y2EffectiveFe = (From row In dt Select col = row("CZT_EFF_FE").ToString).ToArray()

            'Dim Al_min As String = 0 'As per the Excel file.
            'Dim Al_max As String = 0.35 'As per the Excel file.
            'Dim Fe_min As String = 0 'As per the Excel file.
            'Dim Fe_max As String = 0.07 'As per the Excel file.
            Dim Al_min As String = 0 'Changed by mamta on 11-Jan-2018
            Dim Al_max As String = 0.3 'Changed by mamta on 11-Jan-2018
            Dim Fe_min As String = 0 'Changed by mamta on 11-Jan-2018
            Dim Fe_max As String = 0.05 'Changed by mamta on 11-Jan-2018

            Dim js = "<script language='javascript' type='text/javascript'>" & vbCrLf & _
                    "$(document).ready(function(){" & vbCrLf & _
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf & _
                    "var series= ['Effective Aluminium', 'Effective Iron', 'GI Limits', 'GA Limits']" & vbCrLf & _
                    "var data1 = [["
            For i = 0 To dt.Rows.Count - 1
                If i = xTimestampVal.Length - 1 Then
                    js &= "'" & DateTime.Parse(xTimestampVal.GetValue(i).ToString().Trim()).ToString("yyyy-MM-dd HH:mm") & "', " & y1EffectiveAlVal.GetValue(i).ToString().Trim() & "]]; " & vbCrLf
                Else
                    js &= "'" & DateTime.Parse(xTimestampVal.GetValue(i).ToString().Trim()).ToString("yyyy-MM-dd HH:mm") & "', " & y1EffectiveAlVal.GetValue(i).ToString().Trim() & "], ["
                End If
            Next


            js &= "var data2 = [["
            For i = 0 To dt.Rows.Count - 1
                If i = xTimestampVal.Length - 1 Then
                    js &= "'" & DateTime.Parse(xTimestampVal.GetValue(i).ToString().Trim()).ToString("yyyy-MM-dd HH:mm") & "', " & y2EffectiveFe.GetValue(i).ToString().Trim() & "]]; " & vbCrLf
                Else
                    js &= "'" & DateTime.Parse(xTimestampVal.GetValue(i).ToString().Trim()).ToString("yyyy-MM-dd HH:mm") & "', " & y2EffectiveFe.GetValue(i).ToString().Trim() & "], ["
                End If
            Next


            js &= vbCrLf & vbCrLf & giLclDataPoints & vbCrLf & vbCrLf & giUclDataPoints & vbCrLf & vbCrLf & gaLclDataPoints & vbCrLf & vbCrLf & gaUclDataPoints & vbCrLf & vbCrLf

            Dim EffAl_Series As String = "{pointLabels: { show:false }, showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:80px; width:180px; background-color:#0D5CA5; font-weight:bold; font-size:x-large; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td><center>%s</center></td></tr></table>'}}"
            Dim EffFe_Series As String = "{pointLabels: { show:false }, showLine: true, yaxis:'y2axis', lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""height:80px; width:180px; background-color:#BC2318; font-weight:bold; font-size:x-large; color:White; border-radius: 10px"" class=""jqplot-highlighter""> \ <tr><td><center>%s</center></td></tr>\ <tr><td><center>%s</center></td></tr></table>'}}"
            Dim GI_Limit_Series As String = "{pointLabels:{show:!1},showLine:!0,lineWidth:2,breakOnNull: true,linePattern:'dashed',showMarker:!1,color:'#00FF19',highlighter:{show:!0,showMarker:!1,tooltipAxes:'xy',yvalues:2,formatString:'<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"
            Dim GA_Limit_Series As String = "{pointLabels:{show:!1},showLine:!0,lineWidth:2,breakOnNull: true,linePattern:'dashed',showMarker:!1,color:'#000000',highlighter:{show:!0,showMarker:!1,tooltipAxes:'xy',yvalues:2,formatString:'<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"

'"title: 'Calculated Effective Al & Fe'," & vbCrLf & _
            js &= "opts = {" & vbCrLf & _
            "series:[" & EffAl_Series & ", " & EffFe_Series & ", " & GI_Limit_Series & ", " & GI_Limit_Series & ", " & GA_Limit_Series & ", " & GA_Limit_Series & "]," & vbCrLf & _
            "seriesColors: ['#0D5CA5', '#BC2318']," & vbCrLf & _
            "axesDefaults: {" & vbCrLf & _
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf & _
            "tickOptions: {" & vbCrLf & _
            "fontSize:'8pt'" & vbCrLf & _
            "}" & vbCrLf & _
            "}," & vbCrLf & _
            "axes: {" & vbCrLf & _
            "xaxis: {" & vbCrLf & _
            "min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf & _
            "renderer:$.jqplot.DateAxisRenderer," & vbCrLf & _
            "tickOptions:{formatString:'%d-%b %H:%M', angle: -30}," & vbCrLf & _
            "//tickInterval:'1 hour'," & vbCrLf & _
            "pad:0" & vbCrLf & _
            "}," & vbCrLf & _
            "yaxis: { " & vbCrLf & _
            "tickOptions: { formatString: '%.3f' }," & vbCrLf & _
            "min: " & Al_min & "," & vbCrLf & _
            "max: " & Al_max & "," & vbCrLf & _
            "//autoscale:true," & vbCrLf & _
            "label: '% Effective Al'," & vbCrLf & _
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf & _
            "}," & vbCrLf & _
            "y2axis: { " & vbCrLf & _
            "tickOptions: { formatString: '%.3f' }," & vbCrLf & _
            "min: " & Fe_min & "," & vbCrLf & _
            "max: " & Fe_max & "," & vbCrLf & _
            "//autoscale:true," & vbCrLf & _
            "//tickOptions:{showGridline:false}," & vbCrLf & _
            "label: '% Effective Fe'," & vbCrLf & _
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf & _
            "}" & vbCrLf & _
            "}," & vbCrLf & _
            "cursor: {" & vbCrLf & _
            "zoom: true" & vbCrLf & _
            "}," & vbCrLf & _
            "//highlighter: { show: 'true', tooltipFormatString: '%.1f', useAxesFormatters: false }," & vbCrLf & _
            "grid: {backgroundColor:  'rgb(255,255,255)'}," & vbCrLf & _
            "legend: {" & vbCrLf & _
            "show: true," & vbCrLf & _
            "location: 's'," & vbCrLf & _
            "labels: series," & vbCrLf & _
            "renderer: $.jqplot.EnhancedLegendRenderer," & vbCrLf & _
            "placement: 'outsideGrid'," & vbCrLf & _
            "rendererOptions: {" & vbCrLf & _
            "numberRows: 1," & vbCrLf & _
            "numberColumns: 2," & vbCrLf & _
            "marginTop: 10" & vbCrLf & _
            "}" & vbCrLf & _
            "}" & vbCrLf & _
            "};" & vbCrLf & _
            "plot2 = $.jqplot('container1', [data1, data2, GI_UCL, GI_LCL, GA_UCL, GA_LCL], opts);" & vbCrLf & _
            "});" & vbCrLf & _
            "</script>" & vbCrLf

            Lit3.Text = js
        Catch ex As Exception

        End Try
    End Sub

    Sub DrawChartForCGL2(ByVal Filter As String, ByVal ChartTitle As String, ByVal val As String, ByVal dtStart As DateTime, ByVal dtEnd As DateTime)
        Try
            'lita.Text = ""
            'litb.Text = ""
            ''ChartTitle = "Trend of Eff. Aluminium & Eff. Iron"
            Dim strfrmDt As String = dtStart.ToString("yyyy-MM-dd HH:mm")
            Dim strToDt As String = dtEnd.ToString("yyyy-MM-dd HH:mm")

            'Dim dt As DataTable = objController.GetWetChemicalTestData("CGL2_ZNBATH_TREND", strfrmDt, strToDt, "CZT_TIMESTAMP")

            'Dim dt1 As New DataTable
            'dt1.Columns.Add("CLR_DT_SAMPLING_DATE", GetType(DateTime))
            'dt1.Columns.Add("CLR_PARAM_MIN", GetType(Decimal))
            'dt1.Columns.Add("CLR_PARAM_TEST", GetType(String))
            'dt1.Columns.Add("CLR_TEST_VALUE", GetType(Decimal))

            'Dim dt2 As DataTable = dt.DefaultView.ToTable(True, "CLR_PARAM_TEST")
            'Dim dv As DataView = dt.DefaultView


            'For row As Integer = 0 To dt2.Rows.Count - 1
            '    dv.RowFilter = "CLR_PARAM_TEST='" & dt2.Rows(row)(0) & "' and CZT_POT_AL < 1 and CZT_POT_FE < 1"
            '    For j As Integer = 0 To dv.Count - 1
            '        If dt2.Rows(row)(0) = "ZAAL" Then
            '            dt1.Rows.Add(dv(j)(0), 1.0, "ZAAL", dv.Item(j)(1))
            '            dt1.Rows.Add(dv(j)(0), 2.0, "ZAFE_AL", dv.Item(j)(2))
            '        ElseIf dt2.Rows(row)(0) = "ZAZS" Then
            '            dt1.Rows.Add(dv(j)(0), 3.0, "ZAZS", dv.Item(j)(1))
            '            dt1.Rows.Add(dv(j)(0), 4.0, "ZAFE_ZS", dv.Item(j)(2))
            '        ElseIf dt2.Rows(row)(0) = "ZAGA" Then
            '            dt1.Rows.Add(dv(j)(0), 5.0, "ZAGA", dv.Item(j)(1))
            '            dt1.Rows.Add(dv(j)(0), 6.0, "ZAFE_GA", dv.Item(j)(2))
            '        End If
            '    Next
            '    dv.RowFilter = ""
            'Next

            'objController.PlotBoxPlotChartForCGL2(dt1, "CLR_TEST_VALUE", Lit3, "container1", "plot11", "dataA", "CLR_PARAM_MIN", "outlierDataA", ChartTitle, "", "Avg_A")
            '----------------------------Top Right Chart-----------------------------------------------------------------------------------------------------------------
            Dim dt As DataTable = objController.GetWetChemicalTestData("CGL2_ZNBATH_TREND", strfrmDt, strToDt, "CZT_TIMESTAMP", "CZT_POT_AL", "CZT_POT_FE", "CZT_CAMP_AL")


            Dim dt1 As New DataTable
            dt1.Columns.Add("CLR_DT_SAMPLING_DATE", GetType(DateTime))
            dt1.Columns.Add("CLR_PARAM_MIN", GetType(Decimal))
            dt1.Columns.Add("CLR_PARAM_TEST", GetType(String))
            dt1.Columns.Add("CLR_TEST_VALUE", GetType(Decimal))

            Dim dt2 As DataTable = dt.DefaultView.ToTable(True, "CLR_PARAM_TEST")
            Dim dv As DataView = dt.DefaultView


            'For row As Integer = 0 To dt2.Rows.Count - 1
            '    dv.RowFilter = "CLR_PARAM_TEST='" & dt2.Rows(row)(0) & "' and CZT_POT_AL < 1 and CZT_POT_FE < 1"
            '    For j As Integer = 0 To dv.Count - 1
            '        If dt2.Rows(row)(0) = "ZAAL" Then
            '            dt1.Rows.Add(dv(j)(0), 1.0, "ZAAL", dv.Item(j)(1))
            '            dt1.Rows.Add(dv(j)(0), 2.0, "ZAFE_AL", dv.Item(j)(2))
            '        ElseIf dt2.Rows(row)(0) = "ZAZS" Then
            '            dt1.Rows.Add(dv(j)(0), 3.0, "ZAZS", dv.Item(j)(1))
            '            dt1.Rows.Add(dv(j)(0), 4.0, "ZAFE_ZS", dv.Item(j)(2))
            '        ElseIf dt2.Rows(row)(0) = "ZAGA" Then
            '            dt1.Rows.Add(dv(j)(0), 5.0, "ZAGA", dv.Item(j)(1))
            '            dt1.Rows.Add(dv(j)(0), 6.0, "ZAFE_GA", dv.Item(j)(2))
            '        End If
            '    Next
            '    dv.RowFilter = ""
            'Next
            For row As Integer = 0 To dt2.Rows.Count - 1
                dv.RowFilter = "CLR_PARAM_TEST='" & dt2.Rows(row)(0) & "' and CZT_POT_AL < 1 and CZT_POT_FE < 1"
                For j As Integer = 0 To dv.Count - 1
                    'If dt2.Rows(row)(0) = "ZAAL" Then
                    '    dt1.Rows.Add(dv(j)(0), 1.0, "ZAAL", dv.Item(j)(1))
                    '    dt1.Rows.Add(dv(j)(0), 2.0, "ZAFE_AL", dv.Item(j)(2))
                    'ElseIf dt2.Rows(row)(0) = "ZAZS" Then
                    '    dt1.Rows.Add(dv(j)(0), 3.0, "ZAZS", dv.Item(j)(1))
                    '    dt1.Rows.Add(dv(j)(0), 4.0, "ZAFE_ZS", dv.Item(j)(2))
                    'ElseIf dt2.Rows(row)(0) = "ZAGA" Then
                    '    dt1.Rows.Add(dv(j)(0), 5.0, "ZAGA", dv.Item(j)(1))
                    '    dt1.Rows.Add(dv(j)(0), 6.0, "ZAFE_GA", dv.Item(j)(2))
                    'End If
                    If dv(j)(1) >= 0.1 And dv(j)(1) <= 0.15 Then
                        dt1.Rows.Add(dv(j)(0), 1.0, "GA_AL", dv.Item(j)(1))
                        dt1.Rows.Add(dv(j)(0), 2.0, "GA_FE", dv.Item(j)(2))
                    ElseIf dv(j)(1) > 0.15 And dv(j)(1) <= 0.4 Then
                        dt1.Rows.Add(dv(j)(0), 3.0, "GI_AL", dv.Item(j)(1))
                        dt1.Rows.Add(dv(j)(0), 4.0, "GI_FE", dv.Item(j)(2))

                    End If
                Next
                dv.RowFilter = ""
            Next

            objController.PlotBoxPlotChartForCGL2(dt1, "CLR_TEST_VALUE", Lit3, "container1", "plot11", "dataA", "CLR_PARAM_MIN", "outlierDataA", ChartTitle, "", "Avg_A", "Pot", 0, 0.4)
            '-----------------Top Right Chart End-------------------------------------------------------------------------------------------------------------------------

            ''-----------------Bottom Right Chart--------------------------------------------------------------------------------------------------------------------------
            'Dim dt3 As DataTable = objController.GetWetChemicalTestData("CGL2_ZNBATH_TREND", strfrmDt, strToDt, "CZT_TIMESTAMP", "CZT_EFF_AL", "CZT_EFF_FE", "CZT_CAMP_AL")


            'Dim dt4 As New DataTable
            'dt4.Columns.Add("CLR_DT_SAMPLING_DATE", GetType(DateTime))
            'dt4.Columns.Add("CLR_PARAM_MIN", GetType(Decimal))
            'dt4.Columns.Add("CLR_PARAM_TEST", GetType(String))
            'dt4.Columns.Add("CLR_TEST_VALUE", GetType(Decimal))

            'Dim dt5 As DataTable = dt3.DefaultView.ToTable(True, "CLR_PARAM_TEST")
            'Dim dv1 As DataView = dt3.DefaultView


            'For row As Integer = 0 To dt5.Rows.Count - 1
            '    dv1.RowFilter = "CLR_PARAM_TEST='" & dt5.Rows(row)(0) & "' and CZT_EFF_AL < 1 and CZT_EFF_FE < 1"
            '    For j As Integer = 0 To dv1.Count - 1
            '        If dt5.Rows(row)(0) = "ZAAL" Then
            '            dt4.Rows.Add(dv1(j)(0), 1.0, "ZAAL", dv1.Item(j)(1))
            '            dt4.Rows.Add(dv1(j)(0), 2.0, "ZAFE_AL", dv1.Item(j)(2))
            '        ElseIf dt5.Rows(row)(0) = "ZAZS" Then
            '            dt4.Rows.Add(dv1(j)(0), 3.0, "ZAZS", dv1.Item(j)(1))
            '            dt4.Rows.Add(dv1(j)(0), 4.0, "ZAFE_ZS", dv1.Item(j)(2))
            '        ElseIf dt5.Rows(row)(0) = "ZAGA" Then
            '            dt4.Rows.Add(dv1(j)(0), 5.0, "ZAGA", dv1.Item(j)(1))
            '            dt4.Rows.Add(dv1(j)(0), 6.0, "ZAFE_GA", dv1.Item(j)(2))
            '        End If
            '    Next
            '    dv1.RowFilter = ""
            'Next

            'objController.PlotBoxPlotChartForCGL2(dt4, "CLR_TEST_VALUE", Lit4, "container3", "plot22", "dataB", "CLR_PARAM_MIN", "outlierDataB", ChartTitle, "", "Avg_B", "Eff")
            ''-----------------Bottom Right Chart End----------------------------------------------------------------------------------------------------------------------
            ''--------------TOP LEFT CHART----------------------------------------------------------------------
            ''--------------TOP LEFT CHART END----------------------------------------------------------------------
            ''--------------TOP RIGHT CHART----------------------------------------------------------------------
            ''--------------TOP RIGHT CHART END----------------------------------------------------------------------
        Catch ex As Exception

        End Try
    End Sub


    Protected Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click
        Try
            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            DrawChartTop("CLR_PROCESS_LINE = 'L' AND (CLR_PARAM_TEST in ('ZAAL','ZAGA','ZAZS') or CLR_PARAM_TEST in ('ZAFE'))", "", "first", Lit1, Lit3, fromDt, toDt)
            'DrawChartForCGL2("", "", "first", fromDt, toDt)
            EffectiveAlAndFeChart(fromDt, toDt)
            DrawPotTempChart(fromDt, toDt)
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Try

            If txtUsername.Text.Trim() = "" Then
                UserMsgBoxWarning("Enter username.")
                txtUsername.Focus()
            ElseIf txtPassword.Text.Trim() = "" Then
                UserMsgBoxWarning("Enter password.")
                txtPassword.Focus()
            Else
                If objController.IsAValidUser(txtUsername.Text.Trim(), txtPassword.Text.Trim()) Then
                    Session("username") = txtUsername.Text.Trim()
                    'Session("password") = New EncryptDecrypt.EncryptDecryptCls().EncryptWithMD5(txtPassword.Text.Trim())
                    Session("password") = txtPassword.Text.Trim()
                    'closeModal("LoginModal")
                    'openModal("PotModel")
                    mview.ActiveViewIndex = 1
                    txtUsername.Text = ""
                    txtPassword.Text = ""
                Else
                    txtUsername.Text = ""
                    txtPassword.Text = ""
                    UserMsgBoxWarning("Incorrect login details.")

                End If
            End If

        Catch ex As Exception

        End Try
    End Sub

    'Protected Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
    '    Dim count = 0
    '    Dim pageName As String = Path.GetFileName(Request.PhysicalPath)
    '    count = objController.SavePotDetails(ddlPot.SelectedValue, txtFrom.Text, txtTo.Text, Session("username"))

    '    If count > 0 Then
    '        UserMsgBoxSuccess("POT saved successfully.")
    '        txtTo.Text = ""
    '        txtFrom.Text = ""
    '        ddlPot.SelectedIndex = 0
    '    Else
    '        UserMsgBoxError("POT not saved.")
    '    End If
    'End Sub

    Sub openModal(ByVal DivId As String)
        Try

            Dim sb As New StringBuilder()
            sb.Append("<script type='text/javascript'>")
            sb.Append("$('#" & DivId & "').modal('show');")
            sb.Append("</script>")
            ScriptManager.RegisterClientScriptBlock(Me, Me.GetType(), "ShowModal", sb.ToString(), False)

        Catch ex As Exception

        End Try
    End Sub

    Sub closeModal(ByVal DivId As String)
        Try

            Dim sb As New StringBuilder()
            sb.Append("<script type='text/javascript'>")
            sb.Append("$('#" & DivId & "').modal('hide');")
            sb.Append("</script>")
            ScriptManager.RegisterClientScriptBlock(Me, Me.GetType(), "HideModal", sb.ToString(), False)

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnOpenPotChange_Click(sender As Object, e As EventArgs) Handles btnOpenPotChange.Click
        Try
            'closeModal("LoginModal")
            'openModal("LoginModal")
            closeModal("PotModel")
            openModal("PotModel")
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub btnPOT1Start_Click(sender As Object, e As EventArgs) Handles btnPOT1Start.Click
        Try

            If txtPOT1From.Text = "" Then
                UserMsgBoxWarning("Select datetime")
            Else
                Dim count = 0
                Dim pageName As String = Path.GetFileName(Request.PhysicalPath)
                count = objController.SavePotDetails("POT1", txtPOT1From.Text, Nothing, Session("username"))
                If count > 0 Then
                    txtPOT1From.Enabled = False
                    btnPOT1Start.Enabled = False
                    txtPOT2From.Enabled = False
                    txtPOT2To.Enabled = False
                    btnPOT2Start.Enabled = False
                    btnPOT2End.Enabled = False
                    txtPOT1To.Enabled = True
                    btnPOT1End.Enabled = True
                    UserMsgBoxSuccess("POT saved successfully.")
                Else
                    UserMsgBoxError("POT not saved.")
                End If
            End If

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnPOT1End_Click(sender As Object, e As EventArgs) Handles btnPOT1End.Click
        Try


            If txtPOT1To.Text = "" Then
                UserMsgBoxWarning("Select datetime")
            Else
                Dim count = 0
                Dim pageName As String = Path.GetFileName(Request.PhysicalPath)
                count = objController.SavePotDetails("POT1", Nothing, txtPOT1To.Text, Session("username"))
                If count > 0 Then
                    txtPOT1From.Enabled = False
                    btnPOT1Start.Enabled = False
                    txtPOT2From.Enabled = True
                    txtPOT2To.Enabled = False
                    btnPOT2Start.Enabled = True
                    btnPOT2End.Enabled = False
                    txtPOT1To.Enabled = False
                    btnPOT1End.Enabled = False
                    UserMsgBoxSuccess("POT saved successfully.")
                Else
                    UserMsgBoxError("POT not saved.")
                End If
            End If

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnPOT2Start_Click(sender As Object, e As EventArgs) Handles btnPOT2Start.Click
        Try

            If txtPOT2From.Text = "" Then
                UserMsgBoxWarning("Select datetime")
            Else
                Dim count = 0
                Dim pageName As String = Path.GetFileName(Request.PhysicalPath)
                count = objController.SavePotDetails("POT2", txtPOT2From.Text, Nothing, Session("username"))
                If count > 0 Then
                    txtPOT1From.Enabled = False
                    btnPOT1Start.Enabled = False
                    txtPOT2From.Enabled = False
                    txtPOT2To.Enabled = True
                    btnPOT2Start.Enabled = False
                    btnPOT2End.Enabled = True
                    txtPOT1To.Enabled = False
                    btnPOT1End.Enabled = False
                    UserMsgBoxSuccess("POT saved successfully.")
                Else
                    UserMsgBoxError("POT not saved.")
                End If
            End If

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnPOT2End_Click(sender As Object, e As EventArgs) Handles btnPOT2End.Click
        Try

            If txtPOT2To.Text = "" Then
                UserMsgBoxWarning("Select datetime")
            Else
                Dim count = 0
                Dim pageName As String = Path.GetFileName(Request.PhysicalPath)
                count = objController.SavePotDetails("POT2", Nothing, txtPOT2To.Text, Session("username"))
                If count > 0 Then
                    txtPOT1From.Enabled = True
                    btnPOT1Start.Enabled = True
                    txtPOT2From.Enabled = False
                    txtPOT2To.Enabled = False
                    btnPOT2Start.Enabled = False
                    btnPOT2End.Enabled = False
                    txtPOT1To.Enabled = False
                    btnPOT1End.Enabled = False
                    UserMsgBoxSuccess("POT saved successfully.")
                Else
                    UserMsgBoxError("POT not saved.")
                End If
            End If

        Catch ex As Exception

        End Try
    End Sub
End Class
