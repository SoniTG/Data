﻿Imports System.Data
Imports System.IO

Partial Class cgl2quality
    Inherits System.Web.UI.Page
    Shared objController As New Controller
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim ds As DataSet = objController.LoadQuality()
                Dim s As New StringBuilder("")
                s.Append("<script>")
                If ds.Tables(0).Rows.Count > 0 Then
                    Dim dtDisG As DataTable = ds.Tables(0)
                    Dim dtDisHC As DataTable = ds.Tables(1).DefaultView.ToTable(True, "CHC_HOLD_DESC", "CHC_HOLD_ID")
                    ddlHoldDesc.DataSource = dtDisHC
                    ddlHoldDesc.DataTextField = "CHC_HOLD_DESC"
                    ddlHoldDesc.DataValueField = "CHC_HOLD_ID"
                    ddlHoldDesc.DataBind()
                    ddlHoldDesc.Items.Insert(0, New ListItem("All", "All"))
                    's.Append("var holdT=[];")
                    Dim holdT As String = "["
                    s.Append("option = {")
                    's.Append("title :{text:'Coil Hold Gradewise',subtext:'',x:'center'},")
                    s.Append("angleAxis:{},radiusAxis:{type:'category',data:[")
                    For r As Integer = 0 To dtDisG.Rows.Count - 1
                        If r > 0 Then
                            s.Append(",")
                        End If
                        s.Append("'" & dtDisG.Rows(r)(0) & "'")
                    Next
                    s.Append("],z:10},polar: {},tooltip:{trigger:'item',formatter:function(params){return params.seriesName + '<br/>' + 'Tonnage: ' + tonnage[params.seriesIndex][params.dataIndex] + '<br/>' + 'Nos: ' + params.data;}},series:[")
                    For c As Integer = 0 To dtDisHC.Rows.Count - 1
                        If c > 0 Then
                            s.Append(",")
                            holdT &= ","
                        End If
                        Dim sd As String = "["
                        Dim st As String = "["
                        For g As Integer = 0 To dtDisG.Rows.Count - 1
                            If g > 0 Then
                                sd &= ","
                                st &= ","
                            End If
                            Dim dv As DataView = ds.Tables(1).DefaultView
                            dv.RowFilter = "prm_cd_grade='" & dtDisG.Rows(g)(0) & "' and chc_hold_desc='" & dtDisHC.Rows(c)(0) & "'"
                            If dv.Count > 0 Then
                                sd &= dv.Item(0)("totcount")
                                st &= dv.Item(0)("wt")
                            Else
                                sd &= "0"
                                st &= "0"
                            End If


                            dv.RowFilter = ""
                        Next
                        sd &= "]"
                        st &= "]"
                        holdT &= st
                        s.Append("{type:'bar',data:" & sd & ",coordinateSystem:'polar',name:'" & dtDisHC.Rows(c)(0) & "',stack:'a'}")


                    Next
                    holdT &= "]"
                    s.Append("]")
                    s.Append("};")
                    s.Append("tonnage=" & holdT & ";")
                    s.Append("chartHold = echarts.init(document.getElementById('chartHold'));")
                    s.Append("chartHold.setOption(option);")

                    Dim bdataYS As String = "["
                    Dim bdataUTS As String = "["
                    Dim bgradeYS As String = "["
                    Dim bdataTTC As String = "["
                    Dim bdataBTC As String = "["
                    Dim dtBGrade As DataTable = ds.Tables(2).DefaultView.ToTable(True, "PRM_CD_GRADE")
                    For r As Integer = 0 To dtBGrade.Rows.Count - 1

                        If r > 0 Then
                            bdataYS &= ","
                            bgradeYS &= ","
                            bdataUTS &= ","
                            bdataTTC &= ","
                            bdataBTC &= ","
                        End If
                        bgradeYS &= "'" & dtBGrade.Rows(r)(0) & "'"
                        Dim dv As DataView = ds.Tables(2).DefaultView
                        dv.RowFilter = "PRM_CD_GRADE='" & dtBGrade.Rows(r)(0) & "'"
                        bdataYS &= "["
                        bdataUTS &= "["
                        For t As Integer = 0 To dv.Count - 1
                            If t > 0 Then
                                bdataYS &= ","
                                bdataUTS &= ","
                            End If
                            bdataYS &= dv.Item(t)(1)
                            bdataUTS &= dv.Item(t)(2)
                        Next
                        bdataYS &= "]"
                        bdataUTS &= "]"

                        Dim dv1 As DataView = ds.Tables(3).DefaultView
                        dv1.RowFilter = "PRM_CD_GRADE='" & dtBGrade.Rows(r)(0) & "'"
                        bdataTTC &= "["
                        bdataBTC &= "["
                        For t As Integer = 0 To dv1.Count - 1
                            If t > 0 Then
                                bdataTTC &= ","
                                bdataBTC &= ","
                            End If
                            bdataTTC &= dv1.Item(t)(0)
                            bdataBTC &= dv1.Item(t)(1)
                        Next
                        bdataTTC &= "]"
                        bdataBTC &= "]"
                        dv.RowFilter = ""
                    Next
                    bdataYS &= "]"
                    bgradeYS &= "]"
                    bdataUTS &= "]"
                    bdataTTC &= "]"
                    bdataBTC &= "]"

                    s.Append("var data = echarts.dataTool.prepareBoxplotData(" & bdataYS & ");")
                    s.Append("var utsdata = echarts.dataTool.prepareBoxplotData(" & bdataUTS & ");")
                    s.Append("tcdata = [];")
                    s.Append(" ttcdata = echarts.dataTool.prepareBoxplotData(" & bdataTTC & ");")
                    s.Append(" btcdata = echarts.dataTool.prepareBoxplotData(" & bdataBTC & ");")
                    s.Append("tcdata.push(ttcdata);tcdata.push(btcdata);")
                    s.Append("sname = " & bgradeYS & ";")
                    s.Append("optionYS = {tooltip: {trigger: 'item',axisPointer: {type: 'shadow'}},xAxis: {type: 'category',data: data.axisData,axisLabel: {formatter: function (value, index) {return sname[index];}}}, yAxis: {type: 'value'},series: [{name: 'boxplot',type: 'boxplot',data: data.boxData,tooltip: {formatter: function (param) {return [sname[param.name] + ': ','upper: ' + param.data[5],'Q3: ' + param.data[4], 'median: ' + param.data[3],'Q1: ' + param.data[2],'lower: ' + param.data[1]].join('<br/>')}}},{name: 'outlier',type: 'scatter',data: data.outliers}]};")
                    s.Append("optionUTS = {tooltip: {trigger: 'item',axisPointer: {type: 'shadow'}},xAxis: {type: 'category',data: utsdata.axisData,axisLabel: {formatter: function (value, index) {return sname[index];}}}, yAxis: {type: 'value'},series: [{name: 'boxplot',type: 'boxplot',data: utsdata.boxData,tooltip: {formatter: function (param) {return [sname[param.name] + ': ','upper: ' + param.data[5],'Q3: ' + param.data[4], 'median: ' + param.data[3],'Q1: ' + param.data[2],'lower: ' + param.data[1]].join('<br/>')}}},{name: 'outlier',type: 'scatter',data: utsdata.outliers}]};")
                    s.Append("optiontc = {legend: {y: '1%',data: ['TTC', 'BTC']},tooltip: {trigger: 'item',axisPointer: {type: 'shadow'}},xAxis: {type: 'category',data: tcdata[0].axisData,axisLabel: {formatter: function (value, index) {return sname[index];}}}, yAxis: {type: 'value'},series: [{name: 'TTC',type: 'boxplot',data: tcdata[0].boxData,tooltip: {formatter: function (param) {return [sname[param.name] + ': ','upper: ' + param.data[5],'Q3: ' + param.data[4], 'median: ' + param.data[3],'Q1: ' + param.data[2],'lower: ' + param.data[1]].join('<br/>')}}},{name: 'BTC',type: 'boxplot',data: tcdata[1].boxData,tooltip: {formatter: function (param) {return [sname[param.name] + ': ','upper: ' + param.data[5],'Q3: ' + param.data[4], 'median: ' + param.data[3],'Q1: ' + param.data[2],'lower: ' + param.data[1]].join('<br/>')}}}]};")
                    s.Append("chartYS = echarts.init(document.getElementById('chartYS'));")
                    s.Append("chartYS.setOption(optionYS);")
                    s.Append("chartUTS = echarts.init(document.getElementById('chartUTS'));")
                    s.Append("chartUTS.setOption(optionUTS);")
                    s.Append("chartTC = echarts.init(document.getElementById('chartTC'));")
                    s.Append("chartTC.setOption(optiontc);")
                    s.Append("</script>")
                    litHold.Text = s.ToString
                End If

            Catch ex As Exception

            End Try
        End If
    End Sub

    <System.Web.Services.WebMethod()>
    Public Shared Function GetData(ByVal dtFrom As String, ByVal dtTo As String, holdID As String, ByVal refreshHold As Boolean) As String
        Try
            Dim ds As DataSet = objController.LoadQuality(dtFrom, Date.Parse(dtTo), holdID)
            Return getChartString(ds, refreshHold)

        Catch ex As Exception

        End Try
    End Function

    Private Shared Function getChartString(ds As DataSet, ByVal refreshHold As Boolean) As String
        Try

            ' Return "[]"

            Dim s As New StringBuilder("")
            Dim gr As String = "["
            Dim data As String = "["
            Dim holdT As String = "["
            Dim holdID As String = "['All'"
            Dim holdDesc As String = "['All'"
            If ds.Tables(0).Rows.Count > 0 Then
                Dim dtDisG As DataTable = ds.Tables(0)
                Dim dtDisHC As DataTable = ds.Tables(1).DefaultView.ToTable(True, "CHC_HOLD_DESC", "CHC_HOLD_ID")

                For r As Integer = 0 To dtDisG.Rows.Count - 1
                    If r > 0 Then
                        gr &= ","
                    End If
                    gr &= "'" & dtDisG.Rows(r)(0) & "'"
                Next
                For c As Integer = 0 To dtDisHC.Rows.Count - 1
                    holdID &= ","
                    holdDesc &= ","
                    If c > 0 Then
                        holdT &= ","
                        data &= ","

                    End If
                    holdID &= "'" & dtDisHC.Rows(c)(1) & "'"
                    holdDesc &= "'" & dtDisHC.Rows(c)(0) & "'"
                    Dim sd As String = "["
                    Dim st As String = "["
                    For g As Integer = 0 To dtDisG.Rows.Count - 1

                        If g > 0 Then
                            sd &= ","
                            st &= ","
                        End If
                        Dim dv As DataView = ds.Tables(1).DefaultView
                        dv.RowFilter = "prm_cd_grade='" & dtDisG.Rows(g)(0) & "' and chc_hold_desc='" & dtDisHC.Rows(c)(0) & "'"
                        If dv.Count > 0 Then
                            sd &= dv.Item(0)("totcount")
                            st &= dv.Item(0)("wt")
                        Else
                            sd &= "0"
                            st &= "0"
                        End If
                        dv.RowFilter = ""
                    Next
                    sd &= "]"
                    st &= "]"
                    holdT &= st
                    data &= "{type:'bar',data:" & sd & ",coordinateSystem:'polar',name:'" & dtDisHC.Rows(c)(0) & "',stack:'a'}"


                Next
                gr &= "]"
                holdT &= "]"
                data &= "]"
                holdID &= "]"
                holdDesc &= "]"

                Dim bdataYS As String = "["
                Dim bdataUTS As String = "["
                Dim bgradeYS As String = "["
                Dim bdataTTC As String = "["
                Dim bdataBTC As String = "["
                If refreshHold Then
                    Dim dtBGrade As DataTable = ds.Tables(2).DefaultView.ToTable(True, "PRM_CD_GRADE")
                    For r As Integer = 0 To dtBGrade.Rows.Count - 1

                        If r > 0 Then
                            bdataYS &= ","
                            bgradeYS &= ","
                            bdataUTS &= ","
                            bdataTTC &= ","
                            bdataBTC &= ","
                        End If
                        bgradeYS &= "'" & dtBGrade.Rows(r)(0) & "'"
                        Dim dv As DataView = ds.Tables(2).DefaultView
                        dv.RowFilter = "PRM_CD_GRADE='" & dtBGrade.Rows(r)(0) & "'"
                        bdataYS &= "["
                        bdataUTS &= "["
                        For t As Integer = 0 To dv.Count - 1
                            If t > 0 Then
                                bdataYS &= ","
                                bdataUTS &= ","
                            End If
                            bdataYS &= dv.Item(t)(1)
                            bdataUTS &= dv.Item(t)(2)
                        Next
                        bdataYS &= "]"
                        bdataUTS &= "]"

                        Dim dv1 As DataView = ds.Tables(3).DefaultView
                        dv1.RowFilter = "PRM_CD_GRADE='" & dtBGrade.Rows(r)(0) & "'"
                        bdataTTC &= "["
                        bdataBTC &= "["
                        For t As Integer = 0 To dv1.Count - 1
                            If t > 0 Then
                                bdataTTC &= ","
                                bdataBTC &= ","
                            End If
                            bdataTTC &= dv1.Item(t)(0)
                            bdataBTC &= dv1.Item(t)(1)
                        Next
                        bdataTTC &= "]"
                        bdataBTC &= "]"
                        dv.RowFilter = ""
                    Next
                End If
                bdataYS &= "]"
                bgradeYS &= "]"
                bdataUTS &= "]"
                bdataTTC &= "]"
                bdataBTC &= "]"

                If refreshHold Then
                    Return (gr & "~" & data & "~" & holdT & "~" & holdID & "~" & holdDesc & "~" & bgradeYS & "~" & bdataYS & "~" & bdataUTS & "~" & bdataTTC & "~" & bdataBTC)
                Else
                    Return (gr & "~" & data & "~" & holdT)
                End If

            Else
                Return ("[]~[]~[]~[]~[]~[]~[]")
            End If

        Catch ex As Exception

        End Try
    End Function

End Class
