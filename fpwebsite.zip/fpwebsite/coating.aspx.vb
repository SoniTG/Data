﻿Imports System.Data
Imports System.IO

Partial Class coating
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
            txtFrom.Text = Now.AddDays(-20).ToString("yyyy-MM-dd HH:mm:ss")
            txtTo.Text = Now.ToString("yyyy-MM-dd HH:mm:ss")
            DrawChart()
        End If
    End Sub

    Sub DrawChart()
        Try
            Dim strfrmDt As String = txtFrom.Text.Trim
            Dim strToDt As String = txtTo.Text.Trim

            Dim dtAllCoatingData As DataTable = objController.GetCoatingData(strfrmDt, strToDt)
            If dtAllCoatingData.Rows.Count > 0 Then
                Dim dvAllCoatingData As DataView = dtAllCoatingData.DefaultView
                dvAllCoatingData.RowFilter = "CLR_PARAM_TEST = 'CST' OR CLR_PARAM_TEST = 'OST' OR CLR_PARAM_TEST = 'DST'"
                Dim dtTop As DataTable = dvAllCoatingData.ToTable 'Top Data
                ViewState("dtTop") = dtTop
                dtAllCoatingData.DefaultView.RowFilter = String.Empty
                dvAllCoatingData = dtAllCoatingData.DefaultView
                dvAllCoatingData.RowFilter = "CLR_PARAM_TEST = 'CSB' OR CLR_PARAM_TEST = 'OSB' OR CLR_PARAM_TEST = 'DSB'"
                Dim dtBottom As DataTable = dvAllCoatingData.ToTable 'Bottom Data
                ViewState("dtBottom") = dtBottom
                objController.PlotLineChart(dtTop, "CLR_DT_SAMPLING_DATE", "CLR_TEST_VALUE", Lit1, "containerTop", "plotTop", "Coating Thickness (Top)", "Thickness Values", "CLR_PARAM_TEST")
                objController.PlotLineChart(dtBottom, "CLR_DT_SAMPLING_DATE", "CLR_TEST_VALUE", Lit2, "containerBottom", "plotBottom", "Coating Thickness (Bottom)", "Thickness Values", "CLR_PARAM_TEST")
            End If
        Catch ex As Exception
            'objController.LogIssue(Session("username"), ex.ToString(), System.IO.Path.GetFileName(Request.Path))
            'UserMsgBoxError("Error has been logged. Please contact solution provider.")
        End Try
    End Sub

    Protected Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        DrawChart()
    End Sub
End Class