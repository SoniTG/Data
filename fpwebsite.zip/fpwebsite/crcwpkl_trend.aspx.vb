﻿Imports System.Data
Imports System.IO
Partial Class crcwpkl_trend
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim objDataHandler As New DataHandler
    Dim db_name As String = "FP_Process_data"
    Dim table_name As String = "T_CRCW_Pickling_process_data"
    Dim coil_count As Integer = 0
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try

                'Dim p As String = Request("__EVENTARGUMENT")
                'If p = "date" Then
                '    'txtDate_TextChanged()
                'End If
                Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                ok1(dtStart, dtEnd)
            Catch ex As Exception

            End Try


        End If
        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
                'Dim dtStart As DateTime = DateTime.Now.AddMonths(-6).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

                'Dim filter As String = " 1=1"
                PopulateCoilID(dtStart, dtEnd)
                PopulateParameters()
                If clbcoilid.Items.Count > 0 And clbParamTest.Items.Count > 0 Then
                    ok(dtStart, dtEnd)
                End If

            Catch ex As Exception

            End Try

        End If

    End Sub
    Sub PopulateCoilID(ByVal FromDate As String, ByVal ToDate As String)
        Dim dt As New DataTable
        'Dim dtStart As String = hfFrom.Value
        'Dim dtEnd As String = hfTo.Value
        dt = objDataHandler.GetDataSetFromQuery("select  [Coil_ID] from (select [Coil_ID], [DateTime]  FROM [" & db_name & "].[dbo].[" & table_name & "]  where [DateTime] between   '" & FromDate & "' and '" & ToDate & "'  and Coil_ID is not null and Coil_ID  <> 0 ) T group by coil_id order by max(datetime) desc").Tables(0)
        clbcoilid.DataSource = dt
        clbcoilid.DataTextField = "Coil_ID"
        clbcoilid.DataValueField = "Coil_ID"
        clbcoilid.DataBind()
        coil_count = dt.Rows.Count
        'For Each l As ListItem In clbcoilid.Items
        '    l.Selected = True
        'Next
    End Sub

    Sub PopulateParameters()
        Dim dt As New DataTable

        dt = objDataHandler.GetDataSetFromQuery("SELECT [YAxisCol],idx FROM [" & db_name & "].[dbo].[T_Generalised_trendchart] where [IsActive] = 1 and pagename like 'crcwpkl_trend.%'").Tables(0)
        clbParamTest.DataSource = dt
        clbParamTest.DataTextField = "YAxisCol"
        clbParamTest.DataValueField = "idx"
        clbParamTest.DataBind()
        For Each l As ListItem In clbParamTest.Items
            l.Selected = True
        Next


    End Sub

    Protected Sub ok(ByVal FromDate As String, ByVal ToDate As String)
        Try

            Dim fromDt As String = FromDate
            Dim toDt As String = ToDate
            'Dim str1 As String = ""
            'If clbcoilid.Items.Count > 0 Then
            '    Dim count As Integer = 0
            '    Dim appendString = ""
            '    For i As Integer = 0 To clbParamTest.Items.Count - 1
            '        'If clbParamTest.Items(i).Selected Then
            '        count += 1
            '        str1 &= "," & clbParamTest.Items(i).Value
            '        Dim ChartTitle As String = ""
            '        Dim spanClass As String = ""
            '        'If clbParamTest.Items(i).Text = "Rollforce" Then
            '        '    'ChartTitle = "Rollforce (SKU past data (Yellow- Minimum, Red- Maximum, Green- Average))"
            '        '    ChartTitle = "Rollforce"
            '        'Else
            '        ChartTitle = clbParamTest.Items(i).Text
            '        'End If
            '        spanClass = "crmis_span"
            '        appendString &= "<div class='col-md-12'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>" & ChartTitle & ", <span class='" & spanClass & "'; style='font-weight: bold;color:black;font-size: 14px;'></span></h3></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='" & clbParamTest.Items(i).Value & "' style='height: 300px;'></div></div></div></div>"

            '        'End If
            '    Next
            '    divHolder.InnerHtml = appendString
            '    If str1 = "" Then

            '    Else
            '        str1 = str1.Substring(1)

            'Dim filter As String = ""

            If clbcoilid.Items(0).Selected = False Then
                'filter &= "," & clbcoilid.Items(0).Value
                'filter = filter.Substring(1)

                'DrawChartTop(str1, fromDt, toDt, filter)
                GetData(fromDt, toDt)

            End If

            'End If


            'End If



        Catch ex As Exception

        End Try

    End Sub
    Protected Sub ok1(ByVal FromDate As String, ByVal ToDate As String)
        Try

            Dim fromDt As String = FromDate
            Dim toDt As String = ToDate
            'Dim str1 As String = ""
            'If clbcoilid.Items.Count > 0 Then
            '    Dim count As Integer = 0
            '    Dim appendString = ""
            '    For i As Integer = 0 To clbParamTest.Items.Count - 1
            '        'If clbParamTest.Items(i).Selected Then
            '        count += 1
            '        str1 &= "," & clbParamTest.Items(i).Value
            '        Dim ChartTitle As String = ""
            '        Dim spanClass As String = ""
            '        'If clbParamTest.Items(i).Text = "Rollforce" Then
            '        '    'ChartTitle = "Rollforce (SKU past data (Yellow- Minimum, Red- Maximum, Green- Average))"
            '        '    ChartTitle = "Rollforce"
            '        'Else
            '        ChartTitle = clbParamTest.Items(i).Text
            '        'End If
            '        spanClass = "crmis_span"
            '        appendString &= "<div class='col-md-12'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>" & ChartTitle & ", <span class='" & spanClass & "'; style='font-weight: bold;color:black;font-size: 14px;'></span></h3></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='" & clbParamTest.Items(i).Value & "' style='height: 300px;'></div></div></div></div>"

            '        'End If
            '    Next
            '    divHolder.InnerHtml = appendString
            '    If str1 = "" Then

            '    Else
            '        str1 = str1.Substring(1)

            'Dim filter As String = ""

            'If clbcoilid.Items(0).Selected = False Then
            'filter &= "," & clbcoilid.Items(0).Value
            'filter = filter.Substring(1)

            'DrawChartTop(str1, fromDt, toDt, filter)
            GetData(fromDt, toDt)

            'End If

            'End If


            'End If



        Catch ex As Exception

        End Try

    End Sub
    Sub CreateDynamicContainer(ByVal dt As DataTable)


        Try
            Dim appendString = ""
            For i As Integer = 0 To dt.Rows.Count - 1
                appendString &= "<div class='col-md-12'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3 class='header1'>" & dt.Rows(i)("HeaderName") & "</h3> <span></span></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='c" & dt.Rows(i)("idx") & "' style='height: 200px;'></div></div></div></div>"

            Next
            divHolder.InnerHtml = appendString
        Catch ex As Exception

        End Try


    End Sub

    Function getDataForChart(ByVal idx As Integer, ByVal select_coilid As String) As DataTable
        Dim queries(40) As String
        queries(0) = ""

        'queries(1) = "Select [Length_DTR], [Length_ETR], Coil_ID,ThicknessDeviation, Datetime,FinalPassThicknessSET from [" & db_name & "].[dbo].[" & table_name & "] where ThicknessDeviation is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(2) = "Select [Length_DTR], [Length_ETR], Coil_ID,ActualThickness , Datetime,FinalPassThicknessSET from [" & db_name & "].[dbo].[" & table_name & "] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(3) = "Select [Length_DTR], [Length_ETR],Coil_ID,RollForce , Datetime,FinalPassThicknessSET from [" & db_name & "].[dbo].[" & table_name & "] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(4) = "Select [Length_DTR], [Length_ETR],Coil_ID,Differential_RF , Datetime,FinalPassThicknessSET from [" & db_name & "].[dbo].[" & table_name & "] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(5) = "Select [Length_DTR], [Length_ETR],Coil_ID,RollGap , Datetime,FinalPassThicknessSET from [" & db_name & "].[dbo].[" & table_name & "] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(6) = "Select [Length_DTR], [Length_ETR],Coil_ID,Differential_RollGap , Datetime,FinalPassThicknessSET from [" & db_name & "].[dbo].[" & table_name & "] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(7) = "Select [Length_DTR], [Length_ETR],Coil_ID,Speed , Datetime,FinalPassThicknessSET from [" & db_name & "].[dbo].[" & table_name & "] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(8) = "Select [Length_DTR], [Length_ETR],Coil_ID,Tension_Entry , Datetime,FinalPassThicknessSET from [" & db_name & "].[dbo].[" & table_name & "] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(9) = "Select [Length_DTR], [Length_ETR],Coil_ID,Tension_Exit , Datetime,FinalPassThicknessSET from [" & db_name & "].[dbo].[" & table_name & "] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(10) = "Select [Length_DTR], [Length_ETR],Coil_ID,Bending_Pos , Datetime,FinalPassThicknessSET from [" & db_name & "].[dbo].[" & table_name & "] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"
        'queries(11) = "Select [Length_DTR], [Length_ETR],Coil_ID,Bending_Neg , Datetime,FinalPassThicknessSET from [" & db_name & "].[dbo].[" & table_name & "] where ActualThickness is not null and Datetime between '" & hfFrom.Value & "' and '" & hfTo.Value & "' and (abs([Length_DTR]) > 20 and abs([Length_ETR]) > 20 and ltrim(rtrim(Coil_ID)) in (" & select_coilid & ")) order by Datetime"

        queries(1) = "Select [Coil_ID], [LINE_SPEED], Datetime from [" & db_name & "].[dbo].[" & table_name & "] where  ltrim(rtrim(Coil_ID)) in (" & select_coilid & ") order by Datetime"
        queries(2) = "Select [Coil_ID],[RC1_TEMP], Datetime from [" & db_name & "].[dbo].[" & table_name & "] where  ltrim(rtrim(Coil_ID)) in (" & select_coilid & ") order by Datetime"
        queries(3) = "Select [Coil_ID], [RC2_TEMP], Datetime from [" & db_name & "].[dbo].[" & table_name & "] where  ltrim(rtrim(Coil_ID)) in (" & select_coilid & ") order by Datetime"
        queries(4) = "Select [Coil_ID],[RC3_TEMP], Datetime from [" & db_name & "].[dbo].[" & table_name & "] where ltrim(rtrim(Coil_ID)) in (" & select_coilid & ") order by Datetime"
        queries(5) = "Select [Coil_ID],[RT4_TEMP], Datetime from [" & db_name & "].[dbo].[" & table_name & "] where  ltrim(rtrim(Coil_ID)) in (" & select_coilid & ") order by Datetime"
        queries(6) = "Select [Coil_ID],[Drier_TEMP], Datetime from [" & db_name & "].[dbo].[" & table_name & "] where ltrim(rtrim(Coil_ID)) in (" & select_coilid & ") order by Datetime"


        Return objDataHandler.GetDataSetFromQuery(queries(idx)).Tables(0)
    End Function

    Function stdDev(ByVal MyArray As Object) As Object
        Dim Result, n, a, m As Double 'returning array
        Dim dSumX2, dsumX, sum As Double
        sum = 0
        dsumX = 0
        dSumX2 = 0
        n = 0
        For i As Integer = LBound(MyArray) To UBound(MyArray)
            sum = sum + MyArray(i)
            n += 1
        Next i
        a = sum / n
        n = 0
        For i As Integer = LBound(MyArray) To UBound(MyArray)

            dSumX2 = Math.Pow(a - MyArray(i), 2)

            dsumX = dsumX + dSumX2
            n += 1
        Next i
        If (n < 2) Then
            m = 0
        Else
            m = dsumX / (n - 1)
        End If

        Result = Math.Sqrt(m)
        stdDev = Result
    End Function
    Public Function PlotLineChart(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal ContainerName As String, ByVal PlotName As String, ByVal YAxisLabelName As String, ByVal index As String, ByVal lsl As String, ByVal usl As String, ByVal min As String, ByVal max As String, ByVal ij As Integer) As String
        Try

            Dim yVal() As Decimal
            Dim data_coilid As String = ""

            yVal = (From row In dt Select col = CDec(IIf(IsDBNull(row(YAxisColName)), 0, row(YAxisColName)))).ToArray()
            If yVal.Length = 0 Then Return ""
            Dim stdev_val As Double = stdDev(yVal)
            Dim y_min As String = ""
            If min <> "" Then
                y_min = min
            Else
                If stdev_val < 0.00001 Or stdev_val = 0 Then
                    y_min = yVal.Min() - (1 / 100 * yVal.Min)
                Else
                    y_min = yVal.Min() - (1 / 100 * yVal.Min) 'Math.Max(yVal.Min() - (1 / 100 * yVal.Min), yVal.Average - 6 * stdev_val)
                End If

            End If

            Dim y_max As String = ""
            If max <> "" Then
                y_max = max
            Else
                If stdev_val < 0.00001 Or stdev_val = 0 Then
                    y_max = yVal.Max() + (1 / 100 * yVal.Max)
                Else
                    y_max = yVal.Max() + (1 / 100 * yVal.Max) 'Math.Min(yVal.Max() + (1 / 100 * yVal.Max), yVal.Average + 6 * stdev_val)
                End If

            End If

            If lsl = "" Then
                lsl = Math.Max(yVal.Average - 3 * stdev_val, Convert.ToDouble(y_min))
            End If
            If usl = "" Then
                usl = yVal.Average + 3 * stdev_val
            End If

            Dim data As String = Nothing

            Dim data1 As String = Nothing
            Dim date_val As String = Nothing
            Dim selected_col As String = Nothing
            Dim label_position As Double
            selected_col = ""
            'FinalPassThicknessSET
            'upto 1 mm     +-0.02mm                 
            '1.1 to 2      +-0.03
            '2.01  3       +-0.04
            '>3.01         +-0.05

            For I As Integer = 0 To dt.Rows.Count - 2
                data &= dt.Rows(I)(YAxisColName) & ","
                date_val &= "'" & CDate(dt.Rows(I)(XAxisColName)).ToString("dd-MMM HH:mm") & "',"

                If I = 0 Then
                    data_coilid &= "'" & dt.Rows(I)("Coil_ID") & "', "
                ElseIf dt.Rows(I)("Coil_ID") = dt.Rows(I + 1)("Coil_ID") Then

                    'If selected_col = "" Then
                    '    For coil_len_int As Integer = 0 To dt_length.Rows.Count - 1
                    '        If dt.Rows(I)("Coil_ID") = dt_length.Rows(coil_len_int)("coil_id") Then
                    '            selected_col = dt_length.Rows(coil_len_int)("colu_name")
                    '            Exit For
                    '        End If
                    '    Next coil_len_int
                    'End If
                    data_coilid &= "'" & dt.Rows(I)("Coil_ID") & "', "
                Else
                    data_coilid &= "'" & dt.Rows(I + 1)("Coil_ID") & "', "
                    selected_col = ""
                End If
            Next

            Dim s As New StringBuilder("<script>")
            s.Append("var coilid" & ij & "=[" & data_coilid & "];")
            s.Append(" var " & PlotName & "= echarts.init(document.getElementById('" & ContainerName & "'));")

            s.Append("option" & index & " = {")
            s.Append("title: {")
            s.Append("text: ''")
            s.Append("},grid:{left:'10%',right:'5%',bottom:'10%'},")
            s.Append("tooltip: {")
            s.Append("trigger: 'axis' ")
            s.Append(",formatter:function(params){return params[0].marker + ' ' + params[0].name + '<br/>Value:' + params[0].value + '<br/>CoilID:' + coilid" & ij & "[params[0].dataIndex]}")
            s.Append("},")
            s.Append("xAxis: {")
            s.Append("data: [" & date_val & "] ")
            s.Append(",   axisLine: {lineStyle: { color: '#050505',width:1,} }")
            s.Append("},")
            s.Append("yAxis: {name : '" & YAxisLabelName & "', nameLocation: 'middle',max:" & Math.Round(Convert.ToDouble(y_max), 3) & ",min:" & Math.Round(Convert.ToDouble(y_min), 3) & ", nameGap: 50,nameTextStyle:{fontFamily:'Calibri',fontWeight:'bold',fontSize:'14'},")
            s.Append("splitLine: {")
            s.Append("show: false")
            s.Append("}")
            s.Append(",   axisLine: {lineStyle: { color: '#050505',width:1,} }")
            s.Append("},")
            s.Append("toolbox: {")
            s.Append("left: 'right',")
            s.Append("feature: {")
            s.Append("dataZoom: {")
            s.Append("")
            s.Append("},")
            s.Append("restore: {},")
            s.Append("saveAsImage: {}")
            s.Append("}")
            s.Append("},")
            s.Append("series: [")
            s.Append("{")
            s.Append("type: 'scatter',")
            s.Append("data: [" & data & "]")
            's.Append(",markLine:{symbol: 'none',data:[{yAxis:" & lsl & ",name:'LSL',label:{formatter:'LSL'},lineStyle: {color:'black',type:'dashed',width:3}},{yAxis:" & usl & ",name:'USL',label:{formatter:'USL'},lineStyle: {color:'black',type:'dashed',width:3}}]}")
            s.Append(", itemStyle: {       shadowBlur: 5,       shadowColor: 'rgba(120, 36, 50, 0.5)',      shadowOffsetY: 5,      borderWidth: 1,      borderColor: '#212020',      color: 'yellow'}") 'EE6666
            s.Append(", symbolSize: 5,")
            s.Append("},")
            s.Append("{")
            s.Append("type: 'line',")
            s.Append("data: [" & data & "]")
            s.Append(", itemStyle: {borderWidth: 2, borderColor: '#3d3d3d', color: '#ff9f63'}")
            's.Append(", symbolSize: 4,")
            s.Append("}")

            s.Append("]")
            s.Append("};")

            s.Append(" " & PlotName & ".setOption(option" & index & ");")

            s.Append("</script>")

            Return s.ToString


        Catch ex As Exception
            Return ""
        End Try
    End Function
    Sub GetData(ByVal FromDate As String, ByVal ToDate As String)
        Try

            Dim select_coilid As String = ""
            For i As Integer = 0 To clbcoilid.Items.Count - 1
                If clbcoilid.Items(i).Selected = True Then
                    select_coilid &= ",'" & LTrim(RTrim(clbcoilid.Items(i).Value)) & "'"
                    'Response.Write(i)

                End If

            Next
            'If select_coilid <> "" Then
            '    select_coilid = select_coilid.Substring(1)
            'End If
            If select_coilid = "" Then
                select_coilid &= "," & LTrim(RTrim(clbcoilid.Items(0).Value))
                select_coilid = select_coilid.Substring(1)
            Else
                select_coilid = select_coilid.Substring(1)
            End If

            'Dim GetData As DataTable = objDataHandler.GetDataSetFromQuery_Crcw("SELECT  [COIL_STARTDATETIME],[DAUGHTER_COILID_TEXT],[GRADE],cast(round([THICKNESS],2) as float) as THICKNESS,cast(round([WIDTH],0)as float) as WIDTH,cast(ROUND([ENLONGATION_ACT],2)as float) AS ENLONGATION_ACT,cast(ROUND([ROLLFORCE],2)as float) AS ROLLFORCE,cast(ROUND([TENSION_POR_ENTRY_REF],2)as float) AS TENSION_POR_ENTRY_REF FROM [FP_PROCESS_DATA].[dbo].[CRCW_SPM_PROCESS_DATA_COILWISE_BODY] where [DAUGHTER_COILID_TEXT] in('" & select_coilid & "') order by [COIL_STARTDATETIME] desc ").Tables(0)
            Dim GetData As DataTable = objDataHandler.GetDataSetFromQuery_Crcw("Select distinct a.coil_no Coil_NO,dbprod.crcpkg003.FUNC_GRADE_DESC(b.pln_cr_grade) Grade,a.in_thick Thickenss,a.in_width Width From dbprod.prod_wip a, dbprod.prod_cr_plan b, dbprod.sap_hsm_data d Where a.coil_no = b.coil_no And a.plan_id = b.plan_id And a.coil_no = d.crcw_coil_no And a.cur_stage = '02' And a.coil_no in(" & select_coilid & ") UNION Select distinct a.coil_no Coil_NO,dbprod.crcpkg003.FUNC_GRADE_DESC(b.pln_cr_grade) Grade,a.in_thick Thickenss,a.in_width Width From dbprod.prod_wip a, dbprod.prod_cr_plan b, dbprod.sap_hsm_data d Where a.coil_no = b.coil_no And A.PLAN_ID = 0 And B.PLN_WEIGHT = (SELECT MAX(C.PLN_WEIGHT) from DBPROD.PROD_CR_PLAN C WHERE C.COIL_NO = A.COIL_NO) And a.coil_no = d.crcw_coil_no And a.cur_stage = '02' And a.coil_no in(" & select_coilid & ")").Tables(0)
            Dim dttime As New DataTable
            dttime = objDataHandler.GetDataSetFromQuery("select  max([DateTime]) as datetime,AVG([LINE_SPEED]) as spd,avg([RC1_TEMP]) as rc1temp,avg([RC2_TEMP]) as rc2temp,avg([RC3_TEMP]) as rc3temp,avg([Drier_TEMP]) as drtemp   FROM [FP_Process_data].[dbo].[T_CRCW_Pickling_process_data] where Coil_ID =  " & select_coilid & "").Tables(0)

            txtDate.Text = dttime.Rows(0)("datetime")
			txtAvg_SPD.Text = Math.Round(Convert.ToInt32(dttime.Rows(0)("spd")))
            txtAvg_RC1.Text = Math.Round(Convert.ToInt32(dttime.Rows(0)("rc1temp")))
            txtAVG_RC2.Text = Math.Round(Convert.ToInt32(dttime.Rows(0)("rc2temp")))
			txtAvg_RC3.Text = Math.Round(Convert.ToInt32(dttime.Rows(0)("rc3temp")))
            txtAVG_dr.Text = Math.Round(Convert.ToInt32(dttime.Rows(0)("drtemp")))
			if getdata.rows.count > 0 then
			txtCoil_ID.Text = GetData.Rows(0)("Coil_NO")
			
            txtGrade.Text = GetData.Rows(0)("Grade")
            txtThickness.Text = GetData.Rows(0)("Thickenss")
            txtWidth.Text = GetData.Rows(0)("Width")

			end if

            Dim dtStart As String = FromDate
            Dim dtEnd As String = ToDate


            'loop for selected coilid


            'loop for selected parameter
            Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select * From [" & db_name & "].[dbo]. [T_Generalised_trendchart] where [IsActive] = 1 and pagename like 'crcwpkl_trend.%' order by idx").Tables(0)

            For i As Integer = 0 To clbParamTest.Items.Count - 1
                If clbParamTest.Items(i).Selected = False Then
                    dt.Rows.Remove(dt.Select("idx=" & clbParamTest.Items(i).Value)(0))
                    'dt.Rows.Add(cblParameters.Items(i).Text, cblParameters.Items(i).Value)
                End If
            Next
            dt.AcceptChanges()

            CreateDynamicContainer(dt)
            Dim l As Literal
            l = Page.Master.FindControl("content_body").FindControl("Lit1")
            l.Text = ""
            For i As Integer = 0 To dt.Rows.Count - 1

                Dim dtval As DataTable = getDataForChart(dt.Rows(i)("idx"), select_coilid)

                l.Text &= PlotLineChart(dtval, dt.Rows(i)("XAxisCol"), Trim(dt.Rows(i)("YAxisCol")), "c" & dt.Rows(i)("Idx"), "plot" & dt.Rows(i)("Idx"), dt.Rows(i)("YAxisUnit").ToString, dt.Rows(i)("Idx"), dt.Rows(i)("LSL").ToString, dt.Rows(i)("USL").ToString, dt.Rows(i)("MIN").ToString, dt.Rows(i)("MAX").ToString, dt.Rows(i)("idx"))
                'l.Text &= PlotLineChart(dtval, dt.Rows(i)("XAxisCol"), Trim(dt.Rows(i)("YAxisCol")), "c" & dt.Rows(i)("Idx"), "plot" & dt.Rows(i)("Idx"), dt.Rows(i)("YAxisUnit").ToString, dt.Rows(i)("Idx"), dt.Rows(i)("LSL").ToString, dt.Rows(i)("USL").ToString, dt.Rows(i)("MIN").ToString, dt.Rows(i)("MAX").ToString, dt.Rows(i)("idx"))

            Next


        Catch ex As Exception
            Throw ex
        End Try

    End Sub



End Class
