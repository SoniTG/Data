﻿Imports System.Data
Imports System.IO
Partial Class crcwspmdetailanalysis
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try

                Dim p As String = Request("__EVENTARGUMENT")
                If (p = "thickness") Then
                    'processThickness()
                ElseIf p = "width" Then
                    'processWidth()
                ElseIf p = "date" Then
                    txtDate_TextChanged()
                End If

            Catch ex As Exception

            End Try
        End If
        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-7).ToString("yyyy-MM-dd HH:mm")
                'Dim dtStart As DateTime = DateTime.Now.AddMonths(-6).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                objController.PopulateGradeForCRCWSPM(ddlGrade, dtStart, dtEnd)
                objController.PopulateTdcForCRCWSPM(ddlTdc, dtStart, dtEnd, "")
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForCRCWSPMDetailAnalysis(dtStart, dtEnd, "", "")
                If dt.Rows.Count > 0 AndAlso Not IsDBNull(dt.Rows(0)(0)) Then
                    txtFromThickness.Text = dt.Rows(0)(0)
                    txtToThickness.Text = dt.Rows(0)(1)

                    If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                        dt1 = objController.PopulateWidthForCRCWSPMDetailAnalysis(dtStart, dtEnd, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                        'Commented by pratik
                        'txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0) * 1000, 0)
                        'txtWidthTo.Text = Math.Round(dt1.Rows(0)(1) * 1000, 0)
                        txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0), 0)
                        txtWidthTo.Text = Math.Round(dt1.Rows(0)(1), 0)
                    End If
                End If




                Dim filter As String = " 1=1"
                'If objController.PopulateCoilIdForCRCWSPMDetailAnalysis(clbcoilid, dtStart, dtEnd, filter) Then
                objController.PopulateCoilIdForCRCWSPMDetailAnalysis(clbcoilid, dtStart, dtEnd, filter)
                objController.LoadColumnNameForCRCWSPMProcessDataCoilWiseNew(clbParamTest, "")
                'Else
                '    'objController.PopulateCoilIdForCRCWSPMDetailAnalysis(clbcoilid, dtStart, dtEnd, filter)
                '    objController.LoadColumnNameForCRCWSPMProcessDataCoilWiseNew(clbParamTest, "")
                '    Dim first As String = clbcoilid.Items(0).Value.Substring(7)
                '    Dim last As String = clbcoilid.Items(clbcoilid.Items.Count - 1).Value.Substring(7)
                '    hfFrom.Value = first
                '    hfTo.Value = last
                'End If




                'objController.LoadColumnNameForSPMDetailAnalysis(clbParamTest, "")

            Catch ex As Exception

            End Try
        End If
    End Sub


    Protected Sub btnOk_Click(sender As Object, e As EventArgs) Handles btnOk.Click
        Try

            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            Dim str1 As String = ""
            If clbcoilid.Items.Count > 0 Then
                Dim count As Integer = 0
                Dim appendString = ""
                For i As Integer = 0 To clbParamTest.Items.Count - 1
                    If clbParamTest.Items(i).Selected Then
                        count += 1
                        str1 &= "," & clbParamTest.Items(i).Value
                        Dim ChartTitle As String = ""
                        Dim spanClass As String = ""
                        If clbParamTest.Items(i).Text = "Rollforce" Then
                            'ChartTitle = "Rollforce (SKU past data (Yellow- Minimum, Red- Maximum, Green- Average))"
                            ChartTitle = "Rollforce"
                        Else
                            ChartTitle = clbParamTest.Items(i).Text
                        End If
                        spanClass = "crmis_span"
                        appendString &= "<div class='col-md-12'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>" & ChartTitle & ", <span class='" & spanClass & "'; style='font-weight: bold;color:black;font-size: 14px;'></span></h3></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='" & clbParamTest.Items(i).Value & "' style='height: 200px;'></div></div></div></div>"

                    End If
                Next
                divHolder.InnerHtml = appendString
                If str1 = "" Then

                Else
                    str1 = str1.Substring(1)

                    Dim filter As String = ""
                    For j As Integer = 0 To clbcoilid.Items.Count - 1
                        If clbcoilid.Items(j).Selected Then
                            filter &= "," & clbcoilid.Items(j).Value
                        End If

                    Next
                    If filter.Length > 0 Then
                        filter = filter.Substring(1)
                        'If rdbtnDatewise.Checked = True Then
                        DrawChartTop(str1, fromDt, toDt, filter)
                        'Else
                        'DrawChartTop1(str1, fromDt, toDt, filter)
                        'End If

                    End If

                End If
            End If


        Catch ex As Exception

        End Try

    End Sub

    Sub DrawChartTop(ByVal ColumnName As String, ByVal FromDt As String, ByVal ToDt As String, ByVal Filter As String)
        Try

            Dim strfrmDt As String = FromDt
            Dim strToDt As String = ToDt
            Dim al() As String = Filter.Split(",")
            Dim dt As New DataTable
            For j As Integer = 0 To al.Length - 1
                dt.Merge(objController.GetCRCWSPMProcessDataDetailAnalysis("CRCW_SPM_PROCESS_DATA_COILWISE_BODY", al(j)))
            Next
            For c As Integer = 0 To dt.Columns.Count - 1
                If dt.Columns(c).ColumnName = "Coil Thickness" Then
                    dt.Columns(c).ColumnName = "Thickness"
                End If
                If dt.Columns(c).ColumnName = "Coil Width" Then
                    dt.Columns(c).ColumnName = "Width"
                End If
            Next
            Dim coilid = dt.Rows(0)("Coil_Id")
            For k As Integer = 0 To dt.Rows.Count - 1

                If k > 0 Then
                    If IsDBNull(dt.Rows(k)("Coil_Id")) Then
                        dt.Rows(k)("Coil_Id") = coilid
                    Else
                        coilid = dt.Rows(k)("Coil_Id")
                    End If
                End If

            Next
            Dim dtUnit As DataTable = objController.GetUnitForSPM("UNIT_DETAILS_CRCW", ColumnName)
            Dim a() As String = ColumnName.Split(",")
            Dim l As Literal
            Dim unit(a.Length) As String
            'Dim multiplier As String = "1.0"
            For i As Integer = 0 To UBound(a)
                Dim literals = Page.Master.FindControl("content_body").Controls.OfType(Of Literal)()
                For Each lit In literals
                    If (lit.ID = "Lit" & i + 1) Then
                        l = lit
                        Exit For
                    End If
                Next

                Dim c As String = a(i)

                Dim row() As DataRow = dtUnit.Select("PARAMETER_NAME='" & c & "'")
                If row.Length > 0 Then
                    'Commented by pratik
                    'multiplier = row(0)(1)
                    unit(i) = row(0)(2)
                    ' multiplier.Replace("THICKNESS", "Convert(Thickness,System.Double)").Replace("WIDTH", "Convert(Width,System.Double)")
                    'Else
                    '    multiplier = "1.0"
                End If
                Dim index As Integer = 0

                Dim isDerived As Boolean = False
                Dim containerName As String = a(i)
                If a(i).StartsWith("UNIT_") Then
                    isDerived = True
                    a(i) = a(i).Replace("UNIT_", "")
                End If

                If a(i) = "C00_COILER_SPEED_ACT" Then
                    index = 5
                ElseIf a(i) = "S11_SPEED_ACT" Then
                    index = 6
                ElseIf a(i) = "C90_COILER_SPEED_ACT" Then
                    index = 7
                    'ElseIf a(i) = "ENLONGATION_SET" Then
                    '    index = 8
                ElseIf a(i) = "ENLONGATION_ACT" Then
                    index = 9
                ElseIf a(i) = "ROLLFORCE" Then
                    index = 10
                ElseIf a(i) = "ROLLFORCE_DS" Then
                    index = 11
                ElseIf a(i) = "ROLLFORCE_OS" Then
                    index = 12
                ElseIf a(i) = "WORK_ROLL_BEND_POS_SET" Then
                    index = 13
                ElseIf a(i) = "WORK_ROLL_BEND_POS_ACT" Then
                    index = 14
                ElseIf a(i) = "WORK_ROLL_BEND_NEG_SET" Then
                    index = 15
                ElseIf a(i) = "WORK_ROLL_BEND_NEG_ACT" Then
                    index = 16
                ElseIf a(i) = "ROLL_GAP_DS" Then
                    index = 17
                ElseIf a(i) = "ROLL_GAP_OS" Then
                    index = 18
                ElseIf a(i) = "TENSION_POR_ENTRY_REF" Then
                    index = 19
                ElseIf a(i) = "TENSION_POR_ENTRY" Then
                    index = 20
                ElseIf a(i) = "TENSION_TR_REF" Then
                    index = 21
                ElseIf a(i) = "TENSION_TR" Then
                    index = 22


                End If

                hfUnit.Value = unit(i)

                Dim cname = dt.Columns(index - 1).ColumnName
                Dim newcname = cname
                If isDerived Then
                    newcname = "UNIT_" & cname
                End If
                dt.Columns.Add("[" & newcname & "_C]", GetType(Double), " Convert([" & cname & "],System.Double)" & "*" & 1)
                'If newcname = "Work_Roll_bend_Neg_Set" Then
                '    objController.PlotLineChartForSPMDetailAnalysis1(dt, "[" & newcname & "_C]", l, containerName, "plot" & i + 1, "", unit(i), "Coil_Id")
                'Else
                ' objController.PlotLineChartForSPMDetailAnalysis(dt, "[" & newcname & "_C]", l, containerName, "plot" & i + 1, "", unit(i), "Coil_Id", a(i))
                'objController.PlotLineChart(dt, "", "[" & newcname & "_C]", l, containerName, "plot" & i + 1, "")
                objController.PlotLineChartForSPMCoilWiseCRCW(dt, "[" & newcname & "_C]", l, containerName, "plot" & i + 1, "", unit(i), "0", "Coil_Id", a(i))
                'objController.PlotLineChartForCRCW(dt, "[" & newcname & "_C]", l, containerName, "plot" & i + 1, "", unit(i), "Coil_Id", a(i))
                'End If

                divHolder.Attributes.Add("style", "display:block")

            Next




        Catch ex As Exception

        End Try
    End Sub

    'Sub DrawChartTop1(ByVal ColumnName As String, ByVal FromDt As String, ByVal ToDt As String, ByVal Filter As String)
    '    Try

    '        Dim strfrmDt As String = FromDt
    '        Dim strToDt As String = ToDt
    '        Dim al() As String = Filter.Split(",")
    '        Dim dt As New DataTable
    '        For j As Integer = 0 To al.Length - 1
    '            dt.Merge(objController.GetSPMProcessDataDetailAnalysisCoilwise("CRM_SPM_PROCESS_DATA_COILWISE_BODY", al(j)))
    '        Next
    '        For c As Integer = 0 To dt.Columns.Count - 1
    '            If dt.Columns(c).ColumnName = "Coil Thickness" Then
    '                dt.Columns(c).ColumnName = "Thickness"
    '            End If
    '            If dt.Columns(c).ColumnName = "Coil Width" Then
    '                dt.Columns(c).ColumnName = "Width"
    '            End If
    '        Next
    '        Dim coilid = dt.Rows(0)("Coil_Id")
    '        For k As Integer = 0 To dt.Rows.Count - 1

    '            If k > 0 Then
    '                If IsDBNull(dt.Rows(k)("Coil_Id")) Then
    '                    dt.Rows(k)("Coil_Id") = coilid
    '                Else
    '                    coilid = dt.Rows(k)("Coil_Id")
    '                End If
    '            End If

    '        Next
    '        Dim dtUnit As DataTable = objController.GetUnitForSPM("UNIT_DETAILS", ColumnName)
    '        Dim a() As String = ColumnName.Split(",")
    '        Dim l As Literal
    '        Dim unit(a.Length) As String
    '        Dim multiplier As String = "1.0"
    '        For i As Integer = 0 To UBound(a)
    '            Dim literals = Page.Master.FindControl("content_body").Controls.OfType(Of Literal)()
    '            For Each lit In literals
    '                If (lit.ID = "Lit" & i + 1) Then
    '                    l = lit
    '                    Exit For
    '                End If
    '            Next

    '            Dim c As String = a(i)

    '            Dim row() As DataRow = dtUnit.Select("PARAMETER_NAME='" & c & "'")
    '            If row.Length > 0 Then
    '                multiplier = row(0)(1)
    '                unit(i) = row(0)(2)
    '                ' multiplier.Replace("THICKNESS", "Convert(Thickness,System.Double)").Replace("WIDTH", "Convert(Width,System.Double)")
    '            Else
    '                multiplier = "1.0"
    '            End If

    '            Dim index As Integer = 0

    '            Dim isDerived As Boolean = False
    '            Dim containerName As String = a(i)
    '            If a(i).StartsWith("UNIT_") Then
    '                isDerived = True
    '                a(i) = a(i).Replace("UNIT_", "")
    '            End If

    '            If a(i) = "C00_COILER_SPEED_ACT" Then
    '                index = 5
    '            ElseIf a(i) = "S11_SPEED_ACT" Then
    '                index = 6
    '            ElseIf a(i) = "C90_COILER_SPEED_ACT" Then
    '                index = 7
    '                'ElseIf a(i) = "ENLONGATION_SET" Then
    '                '    index = 8
    '            ElseIf a(i) = "ENLONGATION_ACT" Then
    '                index = 9
    '            ElseIf a(i) = "ROLLFORCE" Then
    '                index = 10
    '            ElseIf a(i) = "ROLLFORCE_DS" Then
    '                index = 11
    '            ElseIf a(i) = "ROLLFORCE_OS" Then
    '                index = 12
    '            ElseIf a(i) = "WORK_ROLL_BEND_POS_SET" Then
    '                index = 13
    '            ElseIf a(i) = "WORK_ROLL_BEND_POS_ACT" Then
    '                index = 14
    '            ElseIf a(i) = "WORK_ROLL_BEND_NEG_SET" Then
    '                index = 15
    '            ElseIf a(i) = "WORK_ROLL_BEND_NEG_ACT" Then
    '                index = 16
    '            ElseIf a(i) = "ROLL_GAP_DS" Then
    '                index = 17
    '            ElseIf a(i) = "ROLL_GAP_OS" Then
    '                index = 18
    '            ElseIf a(i) = "TENSION_POR_ENTRY_REF" Then
    '                index = 19
    '            ElseIf a(i) = "TENSION_POR_ENTRY" Then
    '                index = 20
    '            ElseIf a(i) = "TENSION_TR_REF" Then
    '                index = 21
    '            ElseIf a(i) = "TENSION_TR" Then
    '                index = 22


    '            End If
    '            Dim cname = dt.Columns(index - 1).ColumnName
    '            Dim newcname = cname
    '            If isDerived Then
    '                newcname = "UNIT_" & cname
    '            End If
    '            dt.Columns.Add("[" & newcname & "_C]", GetType(Double), " Convert([" & cname & "],System.Double)" & "*" & multiplier)

    '            objController.PlotLineChartForSPMDetailAnalysis(dt, "[" & newcname & "_C]", l, containerName, "plot" & i + 1, "", unit(i), "Coil_Id")
    '            divHolder.Attributes.Add("style", "display:block")

    '        Next




    '    Catch ex As Exception

    '    End Try
    'End Sub
    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try

            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            If (hfIsButton.Value = "false") Then

                objController.PopulateGradeForCRCWSPM(ddlGrade, dtStart, dtEnd)
                objController.PopulateTdcForCRCWSPM(ddlTdc, dtStart, dtEnd, "")
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForCRCWSPMDetailAnalysis(dtStart, dtEnd, "", "")
                If dt.Rows.Count > 0 AndAlso Not IsDBNull(dt.Rows(0)(0)) Then
                    txtFromThickness.Text = dt.Rows(0)(0)
                    txtToThickness.Text = dt.Rows(0)(1)
                    If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                        dt1 = objController.PopulateWidthForCRCWSPMDetailAnalysis(dtStart, dtEnd, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                        'Commented by pratik
                        'txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0) * 1000, 0)
                        'txtWidthTo.Text = Math.Round(dt1.Rows(0)(1) * 1000, 0)
                        txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0), 0)
                        txtWidthTo.Text = Math.Round(dt1.Rows(0)(1), 0)
                    End If
                End If
                Dim filter As String = " 1=1"
                If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
                    filter &= " and GRADE = '" & ddlGrade.SelectedItem.Text & "'"
                End If
                If ddlTdc.SelectedItem.Text.ToLower <> "all" Then
                    filter &= " and TDC_No = '" & ddlTdc.SelectedItem.Text & "'"
                End If
                If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                    filter &= " and THICKNESS between " & txtFromThickness.Text & " and " & txtToThickness.Text & ""
                    'divHolder.Attributes.Add("style", "display:none")
                End If
                If txtWidthFrom.Text <> "" And txtWidthTo.Text <> "" Then
                    'Commented by pratik
                    'filter &= " and WIDTH between " & txtWidthFrom.Text / 1000 & " and " & txtWidthTo.Text / 1000 & ""
                    filter &= " and WIDTH between " & txtWidthFrom.Text & " and " & txtWidthTo.Text & ""

                End If
                objController.PopulateCoilIdForCRCWSPMDetailAnalysis(clbcoilid, dtStart, dtEnd, filter)
                objController.LoadColumnNameForCRCWSPMProcessDataCoilWiseNew(clbParamTest, "")

                divHolder.Attributes.Add("style", "display:none")
            End If

        Catch ex As Exception

        End Try

    End Sub


    Protected Sub ddlGrade_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlGrade.SelectedIndexChanged
        Try

            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value

            If ddlGrade.SelectedItem.Text.ToLower = "all" Then
                'hfThickness.Value = ""
                'hfWidth.Value = ""
                'hfCoil.Value = ""
                objController.PopulateTdcForCRCWSPM(ddlTdc, fromDt, toDt, "")
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForCRCWSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
                txtFromThickness.Text = dt.Rows(0)(0)
                txtToThickness.Text = dt.Rows(0)(1)
                If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                    dt1 = objController.PopulateWidthForCRCWSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                    'Commented by pratik
                    'txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0) * 1000, 0)
                    'txtWidthTo.Text = Math.Round(dt1.Rows(0)(1) * 1000, 0)
                    txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0), 0)
                    txtWidthTo.Text = Math.Round(dt1.Rows(0)(1), 0)

                End If

            Else
                objController.PopulateTdcForCRCWSPM(ddlTdc, fromDt, toDt, ddlGrade.SelectedItem.Text)
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForCRCWSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
                txtFromThickness.Text = dt.Rows(0)(0)
                txtToThickness.Text = dt.Rows(0)(1)
                If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                    dt1 = objController.PopulateWidthForCRCWSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                    'Commented by pratik
                    'txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0) * 1000, 0)
                    'txtWidthTo.Text = Math.Round(dt1.Rows(0)(1) * 1000, 0)
                    txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0), 0)
                    txtWidthTo.Text = Math.Round(dt1.Rows(0)(1), 0)

                End If
            End If
            'processThickness()
            btnGo_Click(sender, e)
            divHolder.Attributes.Add("style", "display:none")

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click
        Try

            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            Dim filter As String = " 1=1"
            If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
                filter &= " and GRADE = '" & ddlGrade.SelectedItem.Text & "'"
            End If
            If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                filter &= " and THICKNESS between " & txtFromThickness.Text & " and " & txtToThickness.Text & ""
                'divHolder.Attributes.Add("style", "display:none")
            End If
            If txtWidthFrom.Text <> "" And txtWidthTo.Text <> "" Then
                'Commented by pratik
                'filter &= " and WIDTH between " & txtWidthFrom.Text / 1000 & " and " & txtWidthTo.Text / 1000 & ""
                filter &= " and WIDTH between " & txtWidthFrom.Text & " and " & txtWidthTo.Text & ""
            End If
            objController.PopulateCoilIdForCRCWSPMDetailAnalysis(clbcoilid, dtStart, dtEnd, filter)
            objController.LoadColumnNameForCRCWSPMProcessDataCoilWiseNew(clbParamTest, "")

        Catch ex As Exception

        End Try

    End Sub

    Protected Sub txtFromThickness_TextChanged(sender As Object, e As EventArgs) Handles txtFromThickness.TextChanged
        Try
            btnGo_Click(Nothing, Nothing)
            divHolder.Attributes.Add("style", "display:none")
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub txtToThickness_TextChanged(sender As Object, e As EventArgs) Handles txtToThickness.TextChanged
        Try
            btnGo_Click(Nothing, Nothing)
            divHolder.Attributes.Add("style", "display:none")
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub txtWidthFrom_TextChanged(sender As Object, e As EventArgs) Handles txtWidthFrom.TextChanged
        Try
            btnGo_Click(Nothing, Nothing)
            divHolder.Attributes.Add("style", "display:none")
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub txtWidthTo_TextChanged(sender As Object, e As EventArgs) Handles txtWidthTo.TextChanged
        Try
            btnGo_Click(Nothing, Nothing)
            divHolder.Attributes.Add("style", "display:none")
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub ddlTdc_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlTdc.SelectedIndexChanged
        Try

            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value


            If ddlTdc.SelectedItem.Text.ToLower = "all" Then
                hfThickness.Value = ""
                hfWidth.Value = ""
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForCRCWSPMDetailAnalysis(fromDt, toDt, "", "")
                If dt.Rows.Count > 0 AndAlso Not IsDBNull(dt.Rows(0)(0)) Then
                    txtFromThickness.Text = dt.Rows(0)(0)
                    txtToThickness.Text = dt.Rows(0)(1)
                    If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                        dt1 = objController.PopulateWidthForCRCWSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                        'Commented by pratik
                        'txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0) * 1000, 0)
                        'txtWidthTo.Text = Math.Round(dt1.Rows(0)(1) * 1000, 0)
                        txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0), 0)
                        txtWidthTo.Text = Math.Round(dt1.Rows(0)(1), 0)
                    End If
                End If
                objController.PopulateCoilIdForCRCWSPMDetailAnalysis(clbcoilid, fromDt, toDt, " 1=1")

                divHolder.Attributes.Add("style", "display:none")
                objController.LoadColumnNameForCRCWSPMProcessDataCoilWiseNew(clbParamTest, "")
                'txtFromThickness.Text = ""
                'txtToThickness.Text = ""
                'txtWidthFrom.Text = ""
                'txtWidthTo.Text = ""
                Return
            Else
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForCRCWSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
                If dt.Rows.Count > 0 AndAlso Not IsDBNull(dt.Rows(0)(0)) Then
                    txtFromThickness.Text = dt.Rows(0)(0)
                    txtToThickness.Text = dt.Rows(0)(1)
                    If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                        dt1 = objController.PopulateWidthForCRCWSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                        'Commented by pratik
                        'txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0) * 1000, 0)
                        'txtWidthTo.Text = Math.Round(dt1.Rows(0)(1) * 1000, 0)
                        txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0), 0)
                        txtWidthTo.Text = Math.Round(dt1.Rows(0)(1), 0)
                    End If
                End If

            End If
            btnGo_Click(Nothing, Nothing)
            divHolder.Attributes.Add("style", "display:none")

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub rdbtnCoilwise_CheckedChanged(sender As Object, e As EventArgs) Handles rdbtnCoilwise.CheckedChanged
        Try

            txtCoilwise.Enabled = True
            Panel1.Enabled = False
            ddlGrade.Enabled = False
            ddlTdc.Enabled = False
            txtFromThickness.Enabled = False
            txtToThickness.Enabled = False
            txtWidthFrom.Enabled = False
            txtWidthTo.Enabled = False
            clbcoilid.Items.Clear()
            objController.LoadColumnNameForCRCWSPMProcessDataCoilWiseNew(clbParamTest, "")
            divHolder.Attributes.Add("style", "display:none")

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub rdbtnDatewise_CheckedChanged(sender As Object, e As EventArgs) Handles rdbtnDatewise.CheckedChanged
        Try

            txtCoilwise.Text = ""
            txtCoilwise.Enabled = False
            Panel1.Enabled = True
            ddlGrade.Enabled = True
            ddlTdc.Enabled = True
            txtFromThickness.Enabled = True
            txtToThickness.Enabled = True
            txtWidthFrom.Enabled = True
            txtWidthTo.Enabled = True
            divHolder.Attributes.Add("style", "display:none")
            hfIsButton.Value = "false"
            txtDate_TextChanged()

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub txtCoilwise_TextChanged(sender As Object, e As EventArgs) Handles txtCoilwise.TextChanged
        Try

            'objController.PopulateCoilIdForSPMDetailAnalysisCoilwise(clbcoilid, txtCoilwise.Text)
            objController.PopulateCoilIdForCRCWSPMDetailAnalysisCoilwise(clbcoilid, txtCoilwise.Text.Substring(0, 5))
            objController.LoadColumnNameForCRCWSPMProcessDataCoilWiseNew(clbParamTest, "")
            divHolder.Attributes.Add("style", "display:none")

        Catch ex As Exception

        End Try

    End Sub
End Class
