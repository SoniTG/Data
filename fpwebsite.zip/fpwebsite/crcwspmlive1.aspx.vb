﻿Imports System.Data
Imports System.IO
Partial Class crcwspmlive1
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try

                'Dim p As String = Request("__EVENTARGUMENT")
                'If p = "date" Then
                '    'txtDate_TextChanged()
                'End If
                ok1()
            Catch ex As Exception

            End Try


        End If
        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
                'Dim dtStart As DateTime = DateTime.Now.AddMonths(-6).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")

                Dim filter As String = " 1=1"
                objController.PopulateCoilIdForCRCWSPMDetailAnalysis(clbcoilid, dtStart, dtEnd, filter)
                objController.LoadColumnNameForCRCWSPMProcesslive(clbParamTest, "")
            Catch ex As Exception

            End Try
            ok()
        End If

    End Sub


    Protected Sub ok()
        Try

            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            Dim str1 As String = ""
            If clbcoilid.Items.Count > 0 Then
                Dim count As Integer = 0
                Dim appendString = ""
                For i As Integer = 0 To clbParamTest.Items.Count - 1
                    'If clbParamTest.Items(i).Selected Then
                    count += 1
                    str1 &= "," & clbParamTest.Items(i).Value
                    Dim ChartTitle As String = ""
                    Dim spanClass As String = ""
                    If clbParamTest.Items(i).Text = "Rollforce" Then
                        'ChartTitle = "Rollforce (SKU past data (Yellow- Minimum, Red- Maximum, Green- Average))"
                        ChartTitle = "Rollforce"
                    Else
                        ChartTitle = clbParamTest.Items(i).Text
                    End If
                    spanClass = "crmis_span"
                    appendString &= "<div class='col-md-12'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>" & ChartTitle & ", <span class='" & spanClass & "'; style='font-weight: bold;color:black;font-size: 14px;'></span></h3></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='" & clbParamTest.Items(i).Value & "' style='height: 300px;'></div></div></div></div>"

                    'End If
                Next
                divHolder.InnerHtml = appendString
                If str1 = "" Then

                Else
                    str1 = str1.Substring(1)

                    Dim filter As String = ""

                    If clbcoilid.Items(0).Selected = False Then
                        filter &= "," & clbcoilid.Items(0).Value
                        filter = filter.Substring(1)
                        'If rdbtnDatewise.Checked = True Then
                        DrawChartTop(str1, fromDt, toDt, filter)


                    End If

                End If


            End If



        Catch ex As Exception

        End Try

    End Sub

    Protected Sub ok1()
        Try

            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            Dim str1 As String = ""
            If clbcoilid.Items.Count > 0 Then
                Dim count As Integer = 0
                Dim appendString = ""
                For i As Integer = 0 To clbParamTest.Items.Count - 1
                    'If clbParamTest.Items(i).Selected Then
                    count += 1
                    str1 &= "," & clbParamTest.Items(i).Value
                    Dim ChartTitle As String = ""
                    Dim spanClass As String = ""
                    If clbParamTest.Items(i).Text = "Rollforce" Then
                        'ChartTitle = "Rollforce (SKU past data (Yellow- Minimum, Red- Maximum, Green- Average))"
                        ChartTitle = "Rollforce"
                    Else
                        ChartTitle = clbParamTest.Items(i).Text
                    End If
                    spanClass = "crmis_span"
                    appendString &= "<div class='col-md-12'><div class='panel panel-default'><div class='panel-heading'  style='height:15px'><div class='panel-title-box'><h3>" & ChartTitle & ", <span class='" & spanClass & "'; style='font-weight: bold;color:black;font-size: 14px;'></span></h3></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='" & clbParamTest.Items(i).Value & "' style='height: 300px;'></div></div></div></div>"

                    'End If
                Next
                divHolder.InnerHtml = appendString
                If str1 = "" Then

                Else
                    str1 = str1.Substring(1)

                    Dim filter As String = ""
                    For j As Integer = 0 To clbcoilid.Items.Count - 1
                        If clbcoilid.Items(j).Selected Then
                            filter &= "," & clbcoilid.Items(j).Value
                        End If

                    Next
                    If filter.Length > 0 Then
                        filter = filter.Substring(1)
                        'If rdbtnDatewise.Checked = True Then
                        DrawChartTop(str1, fromDt, toDt, filter)
                        'Else
                        'DrawChartTop1(str1, fromDt, toDt, filter)
                        'End If

                    End If

                End If
            End If


        Catch ex As Exception

        End Try
    End Sub

    Sub DrawChartTop(ByVal ColumnName As String, ByVal FromDt As String, ByVal ToDt As String, ByVal Filter As String)
        Try

            Dim strfrmDt As String = FromDt
            Dim strToDt As String = ToDt
            Dim al() As String = Filter.Split(",")
            Dim Cutoff_min As Double
            Dim Cutoff_max As Double
            Dim dt As New DataTable
            For j As Integer = 0 To al.Length - 1
                dt.Merge(objController.GetCRCWSPMProcessDataDetailAnalysis("CRCW_SPM_PROCESS_DATA_COILWISE_BODY", al(j)))
            Next
            'For c As Integer = 0 To dt.Columns.Count - 1
            '    If dt.Columns(c).ColumnName = "Coil Thickness" Then
            '        dt.Columns(c).ColumnName = "Thickness"
            '    End If
            '    If dt.Columns(c).ColumnName = "Coil Width" Then
            '        dt.Columns(c).ColumnName = "Width"
            '    End If
            'Next
            Dim coilid = dt.Rows(0)("Coil_Id")
            For k As Integer = 0 To dt.Rows.Count - 1

                If k > 0 Then
                    If IsDBNull(dt.Rows(k)("Coil_Id")) Then
                        dt.Rows(k)("Coil_Id") = coilid
                    Else
                        coilid = dt.Rows(k)("Coil_Id")
                    End If
                End If

            Next

            Dim GetData As DataTable = objController.GetDataCRCWSPMDetailAnalysis(coilid)

            If GetData.Rows.Count > 0 Then
                txtCoil_ID.Text = GetData.Rows(0)("DAUGHTER_COILID_TEXT")
                txtDate.Text = GetData.Rows(0)("COIL_STARTDATETIME")
                Dim coildate As String = txtDate.Text
                ''Dim coildate1 As String = coildate.Substring(0, 4)
                ''Dim coilTime1 As String = coildate.Substring(10)
                ''Dim coilTime() As String = coilTime1.Split("-")
                ''coilTime(2) = coilTime(2).Substring(3)
                ''txtDate.Text = coildate1 + " " + coilTime(0) + ":" + coilTime(1) + " " + coilTime(2)

                txtGrade.Text = GetData.Rows(0)("GRADE")
                txtThickness.Text = GetData.Rows(0)("THICKNESS")
                txtWidth.Text = GetData.Rows(0)("WIDTH")
                txtAvg_EI.Text = GetData.Rows(0)("ENLONGATION_ACT")
                txtAvg_RF.Text = GetData.Rows(0)("ROLLFORCE")
                txtPorEntryTension.Text = GetData.Rows(0)("TENSION_POR_ENTRY_REF")
            End If

            Dim dtUnit As DataTable = objController.GetUnitForSPM("UNIT_DETAILS_CRCW", ColumnName)
            Dim a() As String = ColumnName.Split(",")
            Dim l As Literal
            Dim unit(a.Length) As String
            'Dim multiplier As String = "1.0"
            For i As Integer = 0 To UBound(a)
                Dim literals = Page.Master.FindControl("content_body").Controls.OfType(Of Literal)()
                For Each lit In literals
                    If (lit.ID = "Lit" & i + 1) Then
                        l = lit
                        Exit For
                    End If
                Next

                Dim c As String = a(i)

                Dim row() As DataRow = dtUnit.Select("PARAMETER_NAME='" & c & "'")
                If row.Length > 0 Then
                    'Commented by pratik
                    'multiplier = row(0)(1)
                    unit(i) = row(0)(2)
                    ' multiplier.Replace("THICKNESS", "Convert(Thickness,System.Double)").Replace("WIDTH", "Convert(Width,System.Double)")
                    'Else
                    '    multiplier = "1.0"
                End If
                Dim index As Integer = 0

                Dim isDerived As Boolean = False
                Dim containerName As String = a(i)
                If a(i).StartsWith("UNIT_") Then
                    isDerived = True
                    a(i) = a(i).Replace("UNIT_", "")
                End If

                If a(i) = "ENLONGATION_ACT" Then
                    index = 9

                    Dim Limit_EL As DataTable = objController.GetDataCRCWSPMLimits(txtGrade.Text, "EL%")
                    If Limit_EL.Rows.Count > 0 Then
                        Cutoff_min = Limit_EL.Rows(0)("Cutoff_min")
                        Cutoff_max = Limit_EL.Rows(0)("Cutoff_max")
                    End If
                ElseIf a(i) = "ROLLFORCE" Then
                    index = 10
                    Dim Limit_EL As DataTable = objController.GetDataCRCWSPMLimits(txtGrade.Text, "RF%")
                    If Limit_EL.Rows.Count > 0 Then
                        Cutoff_min = Limit_EL.Rows(0)("Cutoff_min")
                        Cutoff_max = Limit_EL.Rows(0)("Cutoff_max")
                    End If
                ElseIf a(i) = "TENSION_POR_ENTRY_REF" Then
                    index = 19
                    Dim Limit_EL As DataTable = objController.GetDataCRCWSPMLimits(txtGrade.Text, "PORTEN%")
                    If Limit_EL.Rows.Count > 0 Then
                        Cutoff_min = Limit_EL.Rows(0)("Cutoff_min")
                        Cutoff_max = Limit_EL.Rows(0)("Cutoff_max")
                    End If

                End If

                hfUnit.Value = unit(i)

                Dim cname = dt.Columns(index - 1).ColumnName
                Dim newcname = cname
                If isDerived Then
                    newcname = "UNIT_" & cname
                End If
                dt.Columns.Add("[" & newcname & "_C]", GetType(Double), " Convert([" & cname & "],System.Double)" & "*" & 1)
                'If newcname = "Work_Roll_bend_Neg_Set" Then
                '    objController.PlotLineChartForSPMDetailAnalysis1(dt, "[" & newcname & "_C]", l, containerName, "plot" & i + 1, "", unit(i), "Coil_Id")
                'Else
                ' objController.PlotLineChartForSPMDetailAnalysis(dt, "[" & newcname & "_C]", l, containerName, "plot" & i + 1, "", unit(i), "Coil_Id", a(i))
                'objController.PlotLineChart(dt, "", "[" & newcname & "_C]", l, containerName, "plot" & i + 1, "")

                'objController.PlotLineChartForCRCW(dt, "[" & newcname & "_C]", l, containerName, "plot" & i + 1, "", unit(i), "Coil_Id", a(i))
                'End If

                objController.PlotLineChartForSPMCoilWiseCRCW_live(dt, "[" & newcname & "_C]", l, containerName, "plot" & i + 1, "", unit(i), "0", "Coil_Id", a(i), Cutoff_min, Cutoff_max)

                divHolder.Attributes.Add("style", "display:block")

            Next




        Catch ex As Exception

        End Try
    End Sub


End Class
