﻿Imports System.Data
Imports System.IO

Partial Class criticalmotorcurrent
    Inherits System.Web.UI.Page


    Dim objDataHandler As New DataHandler
    Dim objController As New Controller_E_Main

    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Protected Sub txtDate_TextChanged() Handles btngo.Click
        Try

            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value

            Dim dt As DataTable = objDataHandler.GetDataSetFromQuery_CRM_EUIP("select CLS_DATETIME as CCS_DATETIME ,CLS_PARAM_STDEV as CCSA_PARAM_VAL,CLS_PARAM_NAME from [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_CGL2_LOAD_STDEV] where CLS_DATETIME between '" & dtStart & "' and '" & dtEnd & "' order by CLS_DATETIME").Tables(0)
            Dim dtDist As DataTable = objDataHandler.GetDataSetFromQuery_CRM_EUIP("select distinct CLS_PARAM_NAME from [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_CGL2_LOAD_STDEV] order by 1").Tables(0)
            CreateDynamicContainer(dtDist)
            GetData(dt, dtDist)

        Catch ex As Exception

        End Try
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            'Try
            '    Dim dtStart As String = DateTime.Now.AddDays(-30).ToString("yyyy-MM-dd HH:mm:ss")
            '    Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            'Catch ex As Exception

            'End Try
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd HH:mm:ss")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")


                Dim dt As DataTable = objDataHandler.GetDataSetFromQuery_CRM_EUIP("select CLS_DATETIME as CCS_DATETIME ,CLS_PARAM_STDEV as CCSA_PARAM_VAL,CLS_PARAM_NAME from [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_CGL2_LOAD_STDEV] where CLS_DATETIME between '" & dtStart & "' and '" & dtEnd & "' order by CLS_DATETIME").Tables(0)
                Dim dtDist As DataTable = objDataHandler.GetDataSetFromQuery_CRM_EUIP("select distinct CLS_PARAM_NAME from [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_CGL2_LOAD_STDEV] order by 1").Tables(0)
                CreateDynamicContainer(dtDist)
                GetData(dt, dtDist)
            Catch ex As Exception

            End Try
            If Page.IsPostBack Then
                Try

                Catch ex As Exception

                End Try
            End If
        End If
    End Sub

    Sub GetData(ByVal dt As DataTable, ByVal distinct As DataTable)
        Try

            Dim dv As DataView = dt.DefaultView
            Dim l As Literal
            Dim COUNT As Integer = 1
            ' Dim literals = Page.Controls.OfType(Of Literal)()
            Dim literals = form1.Controls.OfType(Of Literal)() '("LiteralID")
            Dim dtStart As String = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd HH:mm:ss")
            For dis As Integer = 0 To distinct.Rows.Count - 1
                dv.RowFilter = "CLS_PARAM_NAME='" & distinct.Rows(dis)(0) & "' "
                Dim tempdt As DataTable = dv.ToTable
                For Each lit In literals
                    Dim i As Integer = dis + 1
                    If (lit.ID = "Lit" & i) Then
                        l = lit
                        lit.Text = ""
                        If tempdt.Rows.Count > 0 Then
                            objController.PlotLineEChart(tempdt, l, "cy" & i, "plot" & dis & "", dtStart)
                            Exit For
                            'PlotLineEChart
                        End If
                    Else
                        Continue For
                    End If
                Next
            Next
        Catch ex As Exception

        End Try

    End Sub

    Sub CreateDynamicContainer(ByVal dt As DataTable)
        divHolder.InnerHtml = ""

        Try
            Dim appendString = ""
            For i As Integer = 0 To dt.Rows.Count - 1
                appendString &= "<div class='col-md-6'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>" & dt.Rows(i)("CLS_PARAM_NAME") & "</h3> <span></span></div><ul class='panel-controls' style='margin-top: 2px;'></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='cy" & i + 1 & "' style='height: 300px;'></div></div></div></div>"
            Next
            divHolder.InnerHtml = appendString
        Catch ex As Exception

        End Try

    End Sub
End Class
