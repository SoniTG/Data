﻿Imports System.Data
Imports System.IO
Imports System.Web.Services
Imports System.Data.SqlClient

Partial Class crm_mech_prop
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Protected Sub txtDate_TextChanged()
        radioButtonChanged()
        divHolder.InnerHtml = ""



    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try

                Dim p As String = Request("__EVENTARGUMENT")
                If (p = "thickness") Then

                    DrawChart()
                ElseIf p = "width" Then
                    DrawChart()

                ElseIf p = "date" Then
                    txtDate_TextChanged()
                End If

            Catch ex As Exception

            End Try
        End If
        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-5).ToString("yyyy-MM-dd HH:mm:ss")
                'Dim dtStart As DateTime = DateTime.Now.AddMonths(-6).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                objController.PopulateGradeForCRMMechProp(ddlGrade, dtStart, dtEnd)
                objController.PopulateTdcForCRMMechProp(ddlTdc, dtStart, dtEnd, "")
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForCRMMechProp(dtStart, dtEnd, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
                If dt.Rows.Count > 0 AndAlso Not IsDBNull(dt.Rows(0)(0)) Then
                    txtFromThickness.Text = dt.Rows(0)(0)
                    txtToThickness.Text = dt.Rows(0)(1)

                    If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                        dt1 = objController.PopulateWidthForCRMMechProp(dtStart, dtEnd, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                        txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0), 0)
                        txtWidthTo.Text = Math.Round(dt1.Rows(0)(1), 0)
                    End If
                End If




                Dim filter As String = " 1=1"

                objController.LoadColumnNameForCRMMechProp(clbParamTest, "")

            Catch ex As Exception

            End Try
        End If
    End Sub

    Protected Sub btnOk_Click(sender As Object, e As System.EventArgs) Handles btnOk.Click
        DrawDynamicContainer()
        DrawChart()
    End Sub

    Private Sub DrawDynamicContainer()
        Dim appendString = ""
        If clbParamTest.Items.Count > 0 Then

            For i As Integer = 0 To clbParamTest.Items.Count - 1
                If clbParamTest.Items(i).Selected Then
                    appendString &= "<div class='col-md-12'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>" & clbParamTest.Items(i).Text & "</h3></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='" & clbParamTest.Items(i).Value & "' style='height: 200px;'></div></div></div></div>"
                End If

            Next
        End If

        divHolder.InnerHtml = appendString
    End Sub

    Protected Sub ddlGrade_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlGrade.SelectedIndexChanged
        DrawChart()
    End Sub

    Protected Sub ddlTdc_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlTdc.SelectedIndexChanged
        DrawChart()
    End Sub

    Private Sub DrawChart()
        Dim dtStart As String = hfFrom.Value
        Dim dtEnd As String = hfTo.Value

        If rbCoated.Checked = True Then
            Dim filter As String = " lgc_ts_coil_create between to_date('" & dtStart & "','YYYY-MM-DD HH24:MI:SS') and TO_DATE('" & dtEnd & "','YYYY-MM-DD HH24:MI:SS')"
            Dim FrmToDate As String = " between to_date('" & dtStart & "','YYYY-MM-DD HH24:MI:SS') and TO_DATE('" & dtEnd & "','YYYY-MM-DD HH24:MI:SS')"
            If ddlGAGI.SelectedIndex > 0 Then
                filter &= " and lgc_cd_prod='" & ddlGAGI.SelectedItem.Value & "'"
            End If
            If ddlGrade.SelectedIndex > 0 Then
                filter &= " and lgc_cd_grade='" & ddlGrade.SelectedItem.Value & "'"
            End If
            If ddlTdc.SelectedIndex > 0 Then
                filter &= " and lgc_tdc_no='" & ddlTdc.SelectedItem.Value & "'"
            End If
            If txtFromThickness.Text <> "" Then
                filter &= " and lgc_sec1_coil>=" & txtFromThickness.Text & ""
            End If
            If txtToThickness.Text <> "" Then
                filter &= " and lgc_sec1_coil<=" & txtToThickness.Text & ""
            End If
            If txtWidthFrom.Text <> "" Then
                filter &= " and lgc_sec2_coil>=" & txtWidthFrom.Text & ""
            End If
            If txtWidthTo.Text <> "" Then
                filter &= " and lgc_sec2_coil<=" & txtWidthTo.Text & ""
            End If

            Lit1.Text = ""
            Dim j As Integer = 1
            For i As Integer = 0 To clbParamTest.Items.Count - 1
                If clbParamTest.Items(i).Selected Then


                    If ddlChartType.SelectedItem.Text.Trim = "Trend Chart" Then
                        objController.PlotChartForMechanicalProp(filter, clbParamTest.Items(i).Value, "plot" & (j), Lit1, clbParamTest.Items(i).Value, j, ddlTdc.SelectedItem.Value)
                    ElseIf ddlChartType.SelectedItem.Text.Trim = "Box Plot(Monthwise)" Then
                        objController.BoxPlotForMechPropMonthwise(filter, "LTR_TEST_VALUE", Lit1, clbParamTest.Items(i).Value, "plot" & (j), "dataRT" & (j), "STDATE1", "outRT" & (j), "", "avgRT" & (j), "", clbParamTest.Items(i).Value, j, ddlTdc.SelectedItem.Value, FrmToDate)
                        'objController.BoxPlotForDescAnalSPM_Month(dt, "ROLLFORCE", Lit4, "container4", "plot4", "dataRT", "STDATE1", "outRT", "Rollforce", "", "avgRT", "", "", "")
                    ElseIf ddlChartType.SelectedItem.Text.Trim = "Histogram" Then
                        objController.PlotHistogramForMechanicalProp(filter, clbParamTest.Items(i).Value, "plot" & (j), Lit1, clbParamTest.Items(i).Value, j, ddlTdc.SelectedItem.Value)
                    End If
                    j += 1
                End If
            Next
        End If
        If rbCRCA.Checked = True Then
            Dim filter As String = " ltr_ts_test between to_date('" & dtStart & "','YYYY-MM-DD HH24:MI:SS') and TO_DATE('" & dtEnd & "','YYYY-MM-DD HH24:MI:SS')"
            If ddlGrade.SelectedIndex > 0 Then
                filter &= " and iql_grade='" & ddlGrade.SelectedItem.Value & "'"
            End If
            If ddlTdc.SelectedIndex > 0 Then
                filter &= " and ccl_tdc_aim='" & ddlTdc.SelectedItem.Value & "'"
            End If
            If txtFromThickness.Text <> "" Then
                filter &= " and ccl_sec1 >=" & txtFromThickness.Text & ""
            End If
            If txtToThickness.Text <> "" Then
                filter &= " and ccl_sec1 <=" & txtToThickness.Text & ""
            End If
            If txtWidthFrom.Text <> "" Then
                filter &= " and ccl_sec2 >=" & txtWidthFrom.Text & ""
            End If
            If txtWidthTo.Text <> "" Then
                filter &= " and ccl_sec2 <=" & txtWidthTo.Text & ""
            End If

            Lit1.Text = ""
            Dim j As Integer = 1
            For i As Integer = 0 To clbParamTest.Items.Count - 1
                If clbParamTest.Items(i).Selected Then


                    If ddlChartType.SelectedItem.Text.Trim = "Trend Chart" Then
                        objController.PlotChartForMechanicalPropCRCA(filter, clbParamTest.Items(i).Value, "plot" & (j), Lit1, clbParamTest.Items(i).Value, j, ddlTdc.SelectedItem.Text)
                    ElseIf ddlChartType.SelectedItem.Text.Trim = "Box Plot(Monthwise)" Then

                        objController.BoxPlotForMechPropMonthwiseCRCA(filter, "LTR_TEST_VALUE", Lit1, clbParamTest.Items(i).Value, "plot" & (j), "dataRT" & (j), "STDATE1", "outRT" & (j), "", "avgRT" & (j), "", clbParamTest.Items(i).Value, j, ddlTdc.SelectedItem.Value)
                    ElseIf ddlChartType.SelectedItem.Text.Trim = "Histogram" Then
                        objController.PlotHistogramForMechanicalPropCRCA(filter, clbParamTest.Items(i).Value, "plot" & (j), Lit1, clbParamTest.Items(i).Value, j, ddlTdc.SelectedItem.Value)
                    End If
                    j += 1
                End If
            Next
        End If
        
    End Sub

    Protected Sub ddlGAGI_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlGAGI.SelectedIndexChanged
        DrawChart()
    End Sub


    Sub radioButtonChanged()
        If rbCRCA.Checked = True Then
            'ddlTdc.Enabled = False
            ddlGAGI.Enabled = False
            divHolder.InnerHtml = ""
            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            objController.PopulateGradeForCRMMechPropCRCA(ddlGrade, dtStart, dtEnd)
            objController.PopulateTdcForCRMMechPropCRCA(ddlTdc, dtStart, dtEnd, "")
            Dim dt, dt1 As DataTable
            dt = objController.PopulateThicknessForCRMMechPropCRCA(dtStart, dtEnd, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
            If dt.Rows.Count > 0 AndAlso Not IsDBNull(dt.Rows(0)(0)) Then
                txtFromThickness.Text = dt.Rows(0)(0)
                txtToThickness.Text = dt.Rows(0)(1)

                If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                    dt1 = objController.PopulateWidthForCRMMechPropCRCA(dtStart, dtEnd, ddlGrade.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text, ddlTdc.SelectedItem.Text)
                    txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0), 0)
                    txtWidthTo.Text = Math.Round(dt1.Rows(0)(1), 0)
                End If
            End If




            Dim filter As String = " 1=1"

            objController.LoadColumnNameForCRMMechPropCRCA(clbParamTest, "")

            Lit1.Text = ""

        End If
        If rbCoated.Checked = True Then
            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            divHolder.InnerHtml = ""
            objController.PopulateGradeForCRMMechProp(ddlGrade, dtStart, dtEnd)
            ddlTdc.Enabled = True
            ddlGAGI.Enabled = True
            objController.PopulateTdcForCRMMechProp(ddlTdc, dtStart, dtEnd, "")

            Dim dt, dt1 As DataTable
            dt = objController.PopulateThicknessForCRMMechProp(dtStart, dtEnd, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
            If dt.Rows.Count > 0 AndAlso Not IsDBNull(dt.Rows(0)(0)) Then
                txtFromThickness.Text = dt.Rows(0)(0)
                txtToThickness.Text = dt.Rows(0)(1)

                If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                    dt1 = objController.PopulateWidthForCRMMechProp(dtStart, dtEnd, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                    txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0), 0)
                    txtWidthTo.Text = Math.Round(dt1.Rows(0)(1), 0)
                End If
            End If




            Dim filter As String = " 1=1"

            objController.LoadColumnNameForCRMMechProp(clbParamTest, "")

            Lit1.Text = ""
        End If
    End Sub

    Protected Sub rbCRCA_CheckedChanged(sender As Object, e As System.EventArgs) Handles rbCRCA.CheckedChanged
        radioButtonChanged()
    End Sub

    Protected Sub rbCoated_CheckedChanged(sender As Object, e As System.EventArgs) Handles rbCoated.CheckedChanged
        radioButtonChanged()
    End Sub
    Private Sub btnLoginSave_Click(sender As Object, e As EventArgs) Handles btnLoginSave.Click
        Try

            If txtUsername.Text.Trim() IsNot "" Then

                If txtPassword.Text.Trim() = "" Then
                    ' UserMsgBoxWarning("Enter password.")
                    UserMsgBoxError("Enter password.")
                    txtPassword.Focus()
                Else
                    If (txtUsername.Text = "152815" And txtPassword.Text = "152815") Or (txtUsername.Text.ToLower.Trim = "crmqa" And txtPassword.Text.ToLower.Trim = "crmqa") Then
                        hfLogin.Value = "Yes"
                        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "Pop", "$('#LoginModal').modal('hide');", True)
                        txtUsername.Text = ""
                        txtPassword.Text = ""
                    Else
                        hfLogin.Value = "No"
                        txtUsername.Text = ""
                        txtPassword.Text = ""
                        ' UserMsgBoxWarning("Incorrect login details.")
                        UserMsgBoxError("Incorrect login details.")
                        Exit Sub
                    End If
                End If
            Else
                '  UserMsgBoxWarning("Enter username.")
                UserMsgBoxError("Enter username.")
                txtUsername.Focus()
            End If

        Catch ex As Exception

        End Try
    End Sub
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Response.Redirect("index.aspx")
    End Sub
   
End Class
