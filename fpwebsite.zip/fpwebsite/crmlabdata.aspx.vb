﻿Imports System.Data
Imports System.IO
Partial Class crmlabdata
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                'Dim dtStart As Date = Date.Today.AddDays(-29)
                'Dim dtStart As DateTime = DateTime.Now.AddDays(-29).ToString("yyyy-MM-dd HH:mm")
                Dim dtStart As DateTime = DateTime.Now.AddMonths(-4).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As DateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                'DrawChartTop("CLR_PROCESS_LINE = 'L' AND (CLR_PARAM_TEST in ('ZAAL','ZAGA','ZAZS') or CLR_PARAM_TEST in ('ZAFE'))", "", "first", Lit1, Lit3, dtStart, dtEnd)
                'DrawChartForCGL2("", "", "first", dtStart, dtEnd)irct
                'objController.LoadColumnsData(ddlFilterColVal2, Session("TableName"), ddlFilterCol2.SelectedItem.Text, Session("DateColumn"), txtFrom.Text, txtTo.Text, ddlFilterColVal1.SelectedItem.Text)
                objController.LoadColumnsDataForAll(ddlProcessLine, Session("TableName"), "CLR_PROCESS_LINE", Session("DateColumn"), dtStart, dtEnd, "")
                If Session("SelectVal") = "CGL1" Then
                    ddlProcessLine.SelectedIndex = ddlProcessLine.Items.IndexOf(ddlProcessLine.Items.FindByText("G"))
                    ddlProcessLine.Enabled = False
                    ddlProcessLine_SelectedIndexChanged(sender, e)
                ElseIf Session("SelectVal") = "CGL2" Then
                    ddlProcessLine.SelectedIndex = ddlProcessLine.Items.IndexOf(ddlProcessLine.Items.FindByText("L"))
                    ddlProcessLine.Enabled = False
                    ddlProcessLine_SelectedIndexChanged(sender, e)
                ElseIf Session("SelectVal") = "PLTCM" Then
                    ddlProcessLine.SelectedIndex = ddlProcessLine.Items.IndexOf(ddlProcessLine.Items.FindByText("P"))
                    ddlProcessLine.Enabled = False
                    ddlProcessLine_SelectedIndexChanged(sender, e)
                End If

            Catch ex As Exception

            End Try
        End If
    End Sub

    Protected Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click
        'Dim fromDt As String = hfFrom.Value
        'Dim toDt As String = hfTo.Value
        'DrawChartTop("CLR_PROCESS_LINE = 'L' AND (CLR_PARAM_TEST in ('ZAAL','ZAGA','ZAZS') or CLR_PARAM_TEST in ('ZAFE'))", "", "first", Lit1, Lit3, fromDt, toDt)
        'DrawChartForCGL2("", "", "first", fromDt, toDt)
    End Sub

    Protected Sub btnOk_Click(sender As Object, e As EventArgs) Handles btnOk.Click
        Try

            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            Dim str1 As String = ""
            If ddlProcessLine.Items.Count > 0 And ddlProcessLine.SelectedItem.Text <> "Select" Then

                If clbParamTest.Items.Count > 0 Then
                    For i As Integer = 0 To clbParamTest.Items.Count - 1
                        If clbParamTest.Items(i).Selected Then
                            str1 &= "," & clbParamTest.Items(i).Value
                        End If
                    Next
                    If str1 = "" Then
                        clbParamTest.Items.Clear()
                    Else
                        str1 = str1.Substring(1)
                        DrawChartTop(ddlProcessLine.SelectedItem.Text, str1, "", "first", fromDt, toDt)

                    End If
                End If


            End If

        Catch ex As Exception

        End Try
    End Sub
    Sub DrawChartTop(ByVal Filter As String, ByVal Filter1 As String, ByVal ChartTitle As String, ByVal val As String, ByVal FromDt As String, ByVal StartDt As String)
        Try

            'ChartTitle = "Trend of Eff. Aluminium & Eff. Iron"
            'Dim strfrmDt As String = DateTime.Now.AddMonths(-4).ToString("yyyy-MM-dd HH:mm") 'FromDt 
            Dim strfrmDt As String = FromDt
            Dim strToDt As String = StartDt

            Dim dt As DataTable = objController.GetWetChemicalTestDataForAll(Session("TableName"), strfrmDt, strToDt, Session("DateColumn"), Filter, Filter1)
            Dim yVal As String = ""
            'yVal = ddlFilterColVal2.SelectedValue.Replace("'", "") & " " & ddlFilterColVal3.SelectedValue.Replace("'", "")
            'objController.PlotLineChartForCGL(dt, Session("DateColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, yVal, "CLR_PARAM_TEST")
            objController.PlotLineChartForCGL(dt, Session("DateColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, yVal, "CLR_PARAM_TEST_NEW")
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub ddlProcessLine_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlProcessLine.SelectedIndexChanged
        Try

            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            If ddlProcessLine.Items.Count > 0 And ddlProcessLine.SelectedItem.Text <> "Select" Then
                Lit1.Text = ""
                objController.LoadColumnsDataForAllVal(clbParamTest, Session("TableName"), "CLR_PARAM_TEST", Session("DateColumn"), fromDt, toDt, ddlProcessLine.SelectedItem.Text)
            ElseIf ddlProcessLine.SelectedItem.Text = "Select" Then
                clbParamTest.Items.Clear()
                Lit1.Text = ""
            End If

        Catch ex As Exception

        End Try
    End Sub

   
End Class
