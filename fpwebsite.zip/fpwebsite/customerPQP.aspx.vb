﻿Imports System.Data
Imports System.IO
Imports iTextSharp.text
Imports iTextSharp.text.html.simpleparser
Imports iTextSharp.text.pdf
Imports iTextSharp.tool.xml
Imports System.Net


Partial Class customerPQP
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    ' Dim objdata As New DpcrData
    Dim FileName As String = ""
    Dim width As Integer

    'Dim dtSheets As New System.Data.DataTable
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not Request.UrlReferrer Is Nothing Then
            Dim url As String = Request.UrlReferrer.ToString()
            'Response.Write(url)
            If url.ToUpper.Contains("PTG") Then
                Session("homeurl") = url
                Session("SubDivId") = "19"
                Session("CustomMenu") = "yes"
                Session("Department") = "DPCR"
            End If

        Else

        End If
        If Not Page.IsPostBack Then
            'Response.Write(hfFrom.Value)
            Session("pagehit") = objController.SaveAndRetrievePageHits(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), Path.GetFileName(Request.Path))
            Dim dtStart As String = DateTime.Now.AddDays(-175).AddDays(IIf(DateTime.Now.DayOfWeek = 0, -7, DateTime.Now.DayOfWeek * -1) + 1).ToString("yyyy-MM-dd")
            'Dim dtStart As DateTime = DateTime.Now.AddMonths(-4).ToString("yyyy-MM-dd HH:mm")
            Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd")


            objController.PopulateZone(ddl1, dtStart, dtEnd)
            objController.PopulateMarketSegment(ddl2, dtStart, dtEnd)
            objController.PopulateDPCRCustomer(ddlCustomer)
            LoadPriority()

            LoadData(dtStart, dtEnd)

            'Dim bmap As New System.Drawing.Bitmap(100, 15)
            'Dim g As System.Drawing.Graphics = System.Drawing.Graphics.FromImage(bmap)

            'Dim bcolor As System.Drawing.Color = System.Drawing.Color.Green
            'Dim gbrush As New System.Drawing.SolidBrush(bcolor)
            'Dim rbrush As New System.Drawing.SolidBrush(System.Drawing.Color.Red)
            'Dim ybrush As New System.Drawing.SolidBrush(System.Drawing.Color.Yellow)

            'g.FillRectangle(gbrush, 0, 0, 80, 15)
            'g.FillRectangle(ybrush, 80, 0, 10, 15)
            'g.FillRectangle(rbrush, 90, 0, 10, 15)

            'bmap.Save("D:\abc.jpg", System.Drawing.Imaging.ImageFormat.Jpeg)

        End If
        If tblData.Rows.Count > 0 Then
            tblData.UseAccessibleHeader = True
            tblData.HeaderRow.TableSection = TableRowSection.TableHeader
        End If
    End Sub

    Sub LoadPriority()
        If ddl2.Items.Count = 0 Then
            Return
        End If
        Dim dt As DataTable = objController.GetDPCRPriority(ddl2.SelectedItem.Text)
        Dim min As Integer = dt.Rows(0)(0)
        Dim max As Integer = dt.Rows(0)(1)

        Dim dt1 As New DataTable
        dt1.Columns.Add("c1", GetType(Integer))

        For i As Integer = min To max
            dt1.Rows.Add(i)
        Next

        ddlFromP.DataSource = dt1
        ddlFromP.DataTextField = "c1"
        ddlFromP.DataValueField = "c1"
        ddlFromP.DataBind()
        ddlToP.DataSource = dt1
        ddlToP.DataTextField = "c1"
        ddlToP.DataValueField = "c1"
        ddlToP.DataBind()

        ddlFromP.SelectedIndex = 0
        ddlToP.SelectedIndex = ddlToP.Items.IndexOf(ddlToP.Items.FindByText(IIf(max > 20, "20", max)))
    End Sub


    Private Sub LoadData(dtStart As String, dtEnd As String)
        If Not ddl2.SelectedItem Is Nothing And Not ddlFromP.SelectedItem Is Nothing And Not ddlToP.SelectedItem Is Nothing Then
            Dim dt As DataTable = objController.GetDPCRData(dtStart, dtEnd, ddl1.SelectedItem.Text, ddl2.SelectedItem.Text, ddlFromP.SelectedItem.Text, ddlToP.SelectedItem.Text, ddlCustomer.SelectedItem.Text).Tables(0)
            If dt.Rows.Count > 0 Then
                '''for chart
                Dim yellow As Integer = 0 ' dt.Select("freq<=2").Length
                Dim red As Integer = 0 'dt.Select("freq>2").Length
                Dim purple As Integer = 0
                Dim cnt As Integer = 0
                ''' 
                ''' 

                Dim dt1 As New DataTable
                dt1.Columns.Add("Market")
                dt1.Columns.Add("Zone")
                dt1.Columns.Add("Customer")

                Dim wk1 As Integer = Microsoft.VisualBasic.DateAndTime.DatePart(DateInterval.WeekOfYear, CDate(dtStart))
                Dim wk2 As Integer

                Dim lastdate As DateTime = New DateTime(CDate(dtStart).Year, 12, 31)
                If CDate(dtEnd) > lastdate Then
                    Dim lastwk1 As Integer = Microsoft.VisualBasic.DateAndTime.DatePart(DateInterval.WeekOfYear, New DateTime(CDate(dtStart).Year, 12, 31))
                    If lastwk1 > 52 Then
                        lastwk1 = 52
                    End If
                    wk2 = lastwk1 + Microsoft.VisualBasic.DateAndTime.DatePart(DateInterval.WeekOfYear, CDate(dtEnd))
                Else
                    wk2 = Microsoft.VisualBasic.DateAndTime.DatePart(DateInterval.WeekOfYear, CDate(dtEnd))
                End If

                Dim rankA(wk2) As Integer
                Dim xlabels As String = ""
                For i As Integer = wk1 To wk2
                    If i > 52 Then
                        dt1.Columns.Add("W" & i - 52, GetType(Integer))
                        xlabels &= "'W" & i - 52 & "'"
                        If i < wk2 Then
                            xlabels &= ","
                        End If
                    Else
                        dt1.Columns.Add("W" & i, GetType(Integer))
                        xlabels &= "'W" & i & "'"
                        If i < wk2 Then
                            xlabels &= ","
                        End If
                    End If

                    cnt += 1
                Next
                width = 104 + 45 + 150 + (wk2 - wk1 + 1) * 40
                dt1.Columns.Add("Remarks")
                dt1.Columns.Add("Chart", GetType(String))

                Dim maxR As Integer = 1
                Dim dtU As DataTable = dt.DefaultView.ToTable(True, "tdd_market_vertical", "tdd_zone", "TDc_CUSTOMER_ALIAS")

                For i As Integer = 0 To dtU.Rows.Count - 1

                    Dim dv As DataView = dt.DefaultView
                    dv.RowFilter = "tdd_market_vertical='" & dtU.Rows(i)(0) & "' and tdd_zone='" & dtU.Rows(i)(1) & "' and tdd_customer='" & dtU.Rows(i)(2) & "'"
                    dt1.Rows.Add()
                    dt1.Rows(i)("Market") = ddl2.SelectedItem.Text 'dtU.Rows(i)(0)
                    dt1.Rows(i)("Zone") = dtU.Rows(i)(1)
                    dt1.Rows(i)("Customer") = dtU.Rows(i)(2)
                    Dim remarks As String = ""
                    Dim yw, rd As Integer
                    yw = 0
                    rd = 0
                    Dim gr As Integer = wk2 - wk1 + 1
                    For j As Integer = 0 To dv.Count - 1
                        Dim wk As String = dv.Item(j)("dbwk")
                        Try
                            Dim tmpVal As Integer = 0
                            If Not IsDBNull(dt1.Rows(i)("W" & wk)) Then
                                Integer.TryParse(dt1.Rows(i)("W" & wk), tmpVal)
                            End If


                            If tmpVal < dv.Item(j)("freq") Then
                                dt1.Rows(i)("W" & wk) = dv.Item(j)("freq")
                            End If


                            ''for red color freq>2
                            If dv.Item(j)("tdd_complaint").ToString.Contains("Rank A") Then

                                remarks &= ", <span style='color:purple;font-size:14px'><b>W" & wk & ": " & dv.Item(j)("tdd_complaint") & "</b></span>"
                                rankA(wk) += 1
                                'dt1.Rows(i)("W" & wk) = -1
                            Else
                                If dv.Item(j)("freq") > 2 Then
                                    rd += 1
                                    remarks &= ", <span style='color:red'><b>W" & wk & "</b>: " & dv.Item(j)("tdd_complaint") & "</span>"
                                Else
                                    yw += 1
                                    remarks &= ", <b>W" & wk & "</b>: " & dv.Item(j)("tdd_complaint") & ""
                                End If
                            End If


                        Catch ex As Exception
                            'dt1.Rows(i)("W" & wk) = dv.Item(j)("freq")
                        End Try
                    Next
                    maxR = IIf(dv.Count > maxR, dv.Count, maxR)
                    If remarks.Length > 0 Then
                        dt1.Rows(i)("Remarks") = remarks.Substring(2)
                    Else
                        dt1.Rows(i)("Remarks") = ""
                    End If
                    'dt1.Rows(i)("Remarks") = IIf(remarks.Length > 0, remarks.Substring(2), remarks)

                    gr = gr - yw - rd
                    dt1.Rows(i)("Chart") = "gr=" & gr.ToString & "-" & yw.ToString & "-" & rd.ToString
                    dv.RowFilter = ""

                Next

                width += maxR * 125 / 2 '2 line remarks
                Console.WriteLine(width)
                Dim ylabels As String = ""
                Dim gA, yA, rA, pA As String

                Dim tt As Integer = dt1.Rows.Count
                For i As Integer = wk1 To wk2
                    If i > 52 Then
                        Dim yw As Integer = dt1.Select("W" & i - 52 & "<=2 and W" & i - 52 & ">0").Length
                        yellow += yw
                        Dim rd As Integer = dt1.Select("W" & i - 52 & ">2").Length
                        red += red
                        Dim pp As Integer = dt1.Select("W" & i - 52 & "=-1").Length
                        purple += pp
                        Dim gn As Integer = tt - yw - rd - pp
                        Dim ywP As Double = Math.Round(yw * 100 / tt, 2)
                        Dim rdP As Double = Math.Round(rd * 100 / tt, 2)
                        Dim ppP As Double = Math.Round(pp * 100 / tt, 2)
                        Dim gnP As Double = Math.Round(gn * 100 / tt, 2)
                        gA &= "," & gnP
                        yA &= "," & ywP
                        rA &= "," & rdP
                        pA &= "," & ppP
                        'ylabels &= "{y:'W" & i & "',Green:" & gnP & ",Amber:" & ywP & ",Red:" & rdP & ",Purple:" & ppP & "}"
                        ylabels &= "{y:'W" & i - 52 & "',Green:" & gnP & ",Amber:" & ywP & ",Red:" & rdP & "}"
                        If i < wk2 Then
                            ylabels &= ","
                        End If
                    Else
                        Dim yw As Integer = dt1.Select("W" & i & "<=2 and W" & i & ">0").Length
                        yellow += yw
                        Dim rd As Integer = dt1.Select("W" & i & ">2").Length
                        red += red
                        Dim pp As Integer = dt1.Select("W" & i & "=-1").Length
                        purple += pp
                        Dim gn As Integer = tt - yw - rd - pp
                        Dim ywP As Double = Math.Round(yw * 100 / tt, 2)
                        Dim rdP As Double = Math.Round(rd * 100 / tt, 2)
                        Dim ppP As Double = Math.Round(pp * 100 / tt, 2)
                        Dim gnP As Double = Math.Round(gn * 100 / tt, 2)
                        gA &= "," & gnP
                        yA &= "," & ywP
                        rA &= "," & rdP
                        pA &= "," & ppP
                        'ylabels &= "{y:'W" & i & "',Green:" & gnP & ",Amber:" & ywP & ",Red:" & rdP & ",Purple:" & ppP & "}"
                        ylabels &= "{y:'W" & i & "',Green:" & gnP & ",Amber:" & ywP & ",Red:" & rdP & "}"
                        If i < wk2 Then
                            ylabels &= ","
                        End If
                    End If

                Next
                tblData.DataSource = dt1
                tblData.DataBind()
                If tblData.Rows.Count > 0 Then
                    tblData.UseAccessibleHeader = True
                    tblData.HeaderRow.TableSection = TableRowSection.TableHeader
                End If


                tblData.Width = width
                If dt1.Rows.Count > 0 Then
                    Try
                        tblData.Rows(0).Cells(0).Width = New Unit(105, UnitType.Pixel)
                        tblData.Rows(0).Cells(1).Width = New Unit(45, UnitType.Pixel)
                        tblData.Rows(0).Cells(2).Width = New Unit(150, UnitType.Pixel)
                        For c As Integer = 0 To wk2 - wk1
                            tblData.Rows(0).Cells(3 + c).Width = New Unit(40, UnitType.Pixel)
                        Next
                        tblData.Rows(0).Cells(3 + wk2 - wk1 + 1).Width = New Unit(maxR * 125 / 2, UnitType.Pixel)
                        tblData.Rows(0).Cells(3 + wk2 - wk1 + 2).Width = New Unit(104, UnitType.Pixel)
                    Catch ex As Exception

                    End Try

                End If


                Dim tot As Integer = cnt * dt1.Rows.Count
                Dim green As Integer = tot - yellow - red - purple
                Dim greenP As Double = Math.Round(green * 100 / tot, 2)
                Dim yellowP As Double = Math.Round(yellow * 100 / tot, 2)
                Dim redP As Double = Math.Round(red * 100 / tot, 2)
                Dim purpleP As Double = Math.Round(purple * 100 / tot, 2)
                Dim s As New StringBuilder("")
                s.Append("<script>dashboard_bar_1 = Morris.Bar({element: 'dashboard-bar-1',data: [{y:'Summ',Green:" & greenP & ",Amber:" & yellowP & ",Red:" & redP & "}],xkey: 'y',ykeys: ['Green','Amber','Red'],labels: ['Green','Amber','Red'],ymin:0,ymax:100,barColors:['#92D050','#FFC000','#FF0000'],yLabelFormat:function(u){return u.toString() + '%';},axes:'y',gridTextSize: '10px',hideHover: true,resize: true,stacked: true,gridLineColor: '#E5E5E5'});</script>")
                s.Append("<script>dashboard_bar_2 = Morris.Bar({element: 'dashboard-bar-2',data: [" & ylabels & "],xkey: 'y',ykeys: ['Green','Amber','Red'],labels: ['Green','Amber','Red'],xLabelMargin: 8,ymin:0,ymax:100,barColors:['#92D050','#FFC000','#FF0000'],yLabelFormat:function(u){return u.toString() + '%';},gridTextSize: '10px',hideHover: true,resize: true,stacked: true,gridLineColor: '#E5E5E5'});</script>")
                s.Append("<script>var barChartData = {labels: ['Summ'],datasets: [{label: 'Green',backgroundColor: '#92D050',data: [" & greenP & "]},{label: 'Amber',backgroundColor: '#FFC000',data: [" & yellowP & "]},{label: 'Red',backgroundColor: '#ff0000',data: [" & redP & "]}]};var ctx = document.getElementById('c1').getContext('2d');window.myBar = new Chart(ctx, {type: 'bar',data: barChartData,options: {legend: {display: false},responsive: true,scales: {xAxes: [{stacked: true,}],yAxes: [{ticks:{min:0,max:100,stepSize:20,callback:function(value){return value.toString() + '%';}},stacked: true}]}}});</script>")
                s.Append("<script>var barChartData1 = {labels: [" & xlabels & "],datasets: [{label: 'Green',backgroundColor: '#92D050',data: [" & gA.Substring(1) & "]},{label: 'Amber',backgroundColor: '#FFC000',data: [" & yA.Substring(1) & "]},{label: 'Red',backgroundColor: '#ff0000',data: [" & rA.Substring(1) & "]}]};var ctx1 = document.getElementById('c2').getContext('2d');window.myBar1 = new Chart(ctx1, {type: 'bar',data: barChartData1,options: {maintainAspectRatio: false,legend: {display: false},responsive: true,scales: {xAxes: [{stacked: true,}],yAxes: [{ticks:{min:0,max:100,stepSize:20,callback:function(value){return value.toString() + '%';}},stacked: true}]}}});</script>")
                's.Append("<script>dashboard_bar_1 = Morris.Bar({element: 'dashboard-bar-1',data: [{y:'Summ',Green:" & greenP & ",Amber:" & yellowP & ",Red:" & redP & ",Purple:" & purpleP & "}],xkey: 'y',ykeys: ['Green','Amber','Red','Purple'],labels: ['Green','Amber','Red','Purple'],ymin:0,ymax:100,barColors:['#92D050','#FFC000','#FF0000','#800080'],yLabelFormat:function(u){return u.toString() + '%';},axes:'y',gridTextSize: '10px',hideHover: true,resize: true,stacked: true,gridLineColor: '#E5E5E5'});</script>")
                's.Append("<script>dashboard_bar_2 = Morris.Bar({element: 'dashboard-bar-2',data: [" & ylabels & "],xkey: 'y',ykeys: ['Green','Amber','Red','Purple'],labels: ['Green','Amber','Red','Purple'],xLabelMargin: 8,ymin:0,ymax:100,barColors:['#92D050','#FFC000','#FF0000','#800080'],yLabelFormat:function(u){return u.toString() + '%';},gridTextSize: '10px',hideHover: true,resize: true,stacked: true,gridLineColor: '#E5E5E5'});</script>")
                's.Append("<script>var barChartData = {labels: ['Summ'],datasets: [{label: 'Green',backgroundColor: '#92D050',data: [" & greenP & "]},{label: 'Amber',backgroundColor: '#FFC000',data: [" & yellowP & "]},{label: 'Red',backgroundColor: '#ff0000',data: [" & redP & "]},{label: 'Purple',backgroundColor: '#800080',data: [" & purpleP & "]}]};var ctx = document.getElementById('c1').getContext('2d');window.myBar = new Chart(ctx, {type: 'bar',data: barChartData,options: {legend: {display: false},responsive: true,scales: {xAxes: [{stacked: true,}],yAxes: [{ticks:{min:0,max:100,stepSize:20,callback:function(value){return value.toString() + '%';}},stacked: true}]}}});</script>")
                's.Append("<script>var barChartData1 = {labels: [" & xlabels & "],datasets: [{label: 'Green',backgroundColor: '#92D050',data: [" & gA.Substring(1) & "]},{label: 'Amber',backgroundColor: '#FFC000',data: [" & yA.Substring(1) & "]},{label: 'Red',backgroundColor: '#ff0000',data: [" & rA.Substring(1) & "]},{label: 'Purple',backgroundColor: '#800080',data: [" & pA.Substring(1) & "]}]};var ctx1 = document.getElementById('c2').getContext('2d');window.myBar1 = new Chart(ctx1, {type: 'bar',data: barChartData1,options: {maintainAspectRatio: false,legend: {display: false},responsive: true,scales: {xAxes: [{stacked: true,}],yAxes: [{ticks:{min:0,max:100,stepSize:20,callback:function(value){return value.toString() + '%';}},stacked: true}]}}});</script>")
                s.Append("")
                Literal1.Text = s.ToString
            Else
                Literal1.Text = ""
                tblData.DataSource = Nothing
                tblData.DataBind()

                UserMsgBoxError("No data available.")
            End If
        Else
            Literal1.Text = ""
            tblData.DataSource = Nothing
            tblData.DataBind()
            UserMsgBoxError("No data available.")
        End If
    End Sub

    Protected Sub btnGo_Click(sender As Object, e As System.EventArgs) Handles btnGo.Click
        LoadData(hfFrom.Value, hfTo.Value)
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)

    End Sub

    Private Function CreateSimpleHtmlParagraph(ByVal text As String) As Paragraph
        Dim p As Paragraph = New Paragraph()
        Dim black = New Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL, BaseColor.BLACK)
        Using sr As StringReader = New StringReader(text)
            Dim elements As List(Of IElement) = iTextSharp.text.html.simpleparser.HTMLWorker.ParseToList(sr, Nothing)

            For Each e As IElement In elements
                p.Add(e)
            Next
            p.Font = black
        End Using

        Return p
    End Function

    Protected Sub btnDownload_Click(sender As Object, e As System.EventArgs) Handles btnDownload.Click
        Dim pdfDoc As New Document(PageSize.A2, 10.0F, 10.0F, 10.0F, 0.0F)
        Dim writer As PdfWriter = PdfWriter.GetInstance(pdfDoc, Response.OutputStream)
        pdfDoc.Open()
        Dim heading As String = "<h2>Customer Product Quality Perception [Market Segment - " & ddl2.SelectedItem.Text & "]</h2><h4>" & hfFrom.Value & " to " & hfTo.Value & "</h4><br/>"
        pdfDoc.Add(CreateSimpleHtmlParagraph(heading))
        Dim sw As New StringWriter()
        Dim hw As New HtmlTextWriter(sw)
        divData.RenderControl(hw)
        Dim sss() As Single = {2, 8}
        Dim tablee1 As New PdfPTable(sss)
        tablee1.WidthPercentage = 30
        tablee1.HorizontalAlignment = Element.ALIGN_CENTER

        Dim cellll1 As New PdfPCell()
        cellll1.BackgroundColor = New BaseColor(146, 208, 80)
        cellll1.Padding = 5
        Dim cellll2 As New PdfPCell(New Phrase(" No issue at Customer"))
        cellll2.Padding = 5
        tablee1.AddCell(cellll1)
        tablee1.AddCell(cellll2)

        Dim cellll3 As New PdfPCell()
        cellll3.BackgroundColor = New BaseColor(255, 192, 0)
        cellll3.Padding = 5
        Dim cellll4 As New PdfPCell(New Phrase(" One time, Sporadic issues"))
        cellll4.Padding = 5
        tablee1.AddCell(cellll3)
        tablee1.AddCell(cellll4)

        Dim cellll5 As New PdfPCell()
        cellll5.BackgroundColor = New BaseColor(255, 0, 0)
        cellll5.Padding = 5
        Dim cellll6 As New PdfPCell(New Phrase(" Chronic, Unresolved issues"))
        cellll6.Padding = 5
        tablee1.AddCell(cellll5)
        tablee1.AddCell(cellll6)

        Dim cellll7 As New PdfPCell()
        cellll7.BackgroundColor = New BaseColor(128, 0, 128)
        cellll7.Padding = 5
        Dim cellll8 As New PdfPCell(New Phrase(" Rank A"))
        cellll8.Padding = 5
        tablee1.AddCell(cellll7)
        tablee1.AddCell(cellll8)

        tablee1.SpacingAfter = 20
        pdfDoc.Add(tablee1)



        Dim w As String = tblData.Rows(0).Cells(0).Width.ToString()
        Dim cw(tblData.Rows(0).Cells.Count - 2) As Single 'tochange back to 1
        Dim blue = New Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, New BaseColor(146, 56, 105))

        For l As Integer = 1 To tblData.Rows(0).Cells.Count - 1 'tochange back to 1
            cw(l - 1) = tblData.Rows(0).Cells(l).Width.ToString.Replace("px", "")
        Next

        Dim tablee As New PdfPTable(cw)
        tablee.WidthPercentage = 100

        For n As Integer = 1 To tblData.HeaderRow.Cells.Count - 1 'tochange back to 1
            Dim celll2 As New PdfPCell((New Phrase(tblData.HeaderRow.Cells(n).Text, blue)))
            celll2.Padding = 5
            celll2.BackgroundColor = New BaseColor(241, 245, 249)
            tablee.AddCell(celll2)
        Next

        For m As Integer = 1 To tblData.Rows.Count - 1 'tochange back to 1
            For l As Integer = 1 To tblData.Rows(0).Cells.Count - 1 'tochange back to 1
                If l < 3 Or l = tblData.Rows(0).Cells.Count - 2 Then 'tochange back to 1
                    Dim text As String = IIf(tblData.Rows(m).Cells(l).Text = "&nbsp;", "", tblData.Rows(m).Cells(l).Text)
                    Dim celll1 As New PdfPCell(CreateSimpleHtmlParagraph(text))
                    celll1.Padding = 5
                    tablee.AddCell(celll1)
                Else
                    Dim celll1 As New PdfPCell()
                    If l = tblData.Rows(0).Cells.Count - 1 Then
                        celll1.Padding = 3
                        Dim img As System.Web.UI.WebControls.Image = CType(tblData.Rows(m).Cells(l).Controls(0), System.Web.UI.WebControls.Image)
                        Dim url As String = img.ImageUrl.Split("=")(1)
                        'Dim im1 As Image = Image.GetInstance(Convert.FromBase64String(hf2.Value.Replace("data:image/png;base64,", "")))
                        celll1.AddElement(Image.GetInstance(Convert.FromBase64String(GetBase64String(url).Replace("data:image/png;base64,", ""))))
                    Else
                        celll1.BackgroundColor = New BaseColor(tblData.Rows(m).Cells(l).BackColor.ToArgb)
                    End If

                    tablee.AddCell(celll1)
                End If

            Next
        Next
        pdfDoc.Add(tablee)



        'Dim elts = HTMLWorker.ParseToList(New StringReader(sw.ToString()), Nothing)


        'Dim worker As New HTMLWorker(pdfDoc)
        'Dim sr As New StringReader(sw.ToString())
        'Dim css2 = "h1{font-size:24px;font-weight:bold}h3{font-size:18px;font-weight:bold}th,td{padding:6px;font-size:14px;}th{background-color:#f1f5f9;font-weight:bold;color:#56688a}"
        ''Dim css = System.IO.File.ReadAllText(Server.MapPath("~/css/bootstrap.css"))
        ''Dim css1 = System.IO.File.ReadAllText(Server.MapPath("~/css/theme-default.css"))
        ''css = css '& css1
        ''Dim heading As String = "<h1>Customer Product Quality Perception</h1><h3>" & hfFrom.Value & " to " & hfTo.Value & "</h3><br/>"
        ''Dim img As String = "<br/><div id='idiv'></div>"
        'Dim cssMS As New MemoryStream(System.Text.Encoding.UTF8.GetBytes(css2))
        'Dim htmlMS As New MemoryStream(System.Text.Encoding.UTF8.GetBytes(heading & sw.ToString() & "<br/>"))

        ''Dim x As XMLWorkerHelper
        ''XMLWorkerHelper.GetInstance().ParseXHtml(writer, pdfDoc, sr)
        'XMLWorkerHelper.GetInstance().ParseXHtml(writer, pdfDoc, htmlMS, cssMS)
        Dim base64 As String = hf1.Value.Replace("data:image/png;base64,", "")
        Dim im As Image = Image.GetInstance(Convert.FromBase64String(base64))
        Dim im1 As Image = Image.GetInstance(Convert.FromBase64String(hf2.Value.Replace("data:image/png;base64,", "")))
        Dim c() As Single = {2, 26, 20}
        Dim table As New PdfPTable(c)
        table.WidthPercentage = 100

        ' Dim cell1 As New PdfPCell(im, True)
        Dim cell1 As New PdfPCell()
        cell1.Border = 0
        cell1.Padding = 20

        Dim cell2 As New PdfPCell(im1, True)
        cell2.Border = 0
        cell2.Padding = 20
        cell1.FixedHeight = 200
        cell2.FixedHeight = 200
        cell1.MinimumHeight = 200
        cell2.MinimumHeight = 200
        'cell1.Image.ScaleToFitHeight = False
        'cell1.Image.ScaleAbsoluteHeight(200)
        cell2.Image.ScaleToFitHeight = False

        Dim cell3 As New PdfPCell()
        cell3.Border = 0
        cell3.Padding = 20

        table.AddCell(cell1)
        table.AddCell(cell2)
        table.AddCell(cell3)
        pdfDoc.Add(table)
        'pdfDoc.Add(im)
        pdfDoc.Close()

        Response.ContentType = "application/pdf"
        Response.AddHeader("content-disposition", "attachment;filename=export.pdf")
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Write(pdfDoc)
        Response.End()
    End Sub

    Function GetBase64String(ByVal qsp As String) As String
        Dim col() As String = qsp.Split("-")
        Dim gr As Integer = col(0)
        Dim yw As Integer = col(1)
        Dim rd As Integer = col(2)

        Try

            Dim tot As Integer = gr + yw + rd
            Dim ywp As Integer = yw * 100 \ tot
            Dim rdp As Integer = rd * 100 \ tot
            Dim grp As Integer = 100 - ywp - rdp

            Dim bmap As New System.Drawing.Bitmap(100, 15)
            Dim g As System.Drawing.Graphics = System.Drawing.Graphics.FromImage(bmap)

            Dim bcolor As System.Drawing.Color = System.Drawing.Color.FromArgb(146, 208, 80)
            Dim gbrush As New System.Drawing.SolidBrush(bcolor)
            Dim rbrush As New System.Drawing.SolidBrush(System.Drawing.Color.Red)
            Dim ybrush As New System.Drawing.SolidBrush(System.Drawing.Color.FromArgb(255, 192, 0))

            g.FillRectangle(gbrush, 0, 0, grp, 15)
            g.FillRectangle(ybrush, grp, 0, ywp, 15)
            g.FillRectangle(rbrush, grp + ywp, 0, rdp, 15)
            Dim m As New MemoryStream
            bmap.Save(m, System.Drawing.Imaging.ImageFormat.Png)
            Dim b As Byte() = m.ToArray
            Return Convert.ToBase64String(b)
        Catch ex As Exception

        End Try
    End Function

    Protected Sub tblData_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles tblData.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            For i As Integer = 3 To e.Row.Cells.Count - 3
                If e.Row.Cells(i).Text = "&nbsp;" Then
                    e.Row.Cells(i).BackColor = Drawing.Color.FromArgb(146, 208, 80)
                ElseIf e.Row.Cells(i).Text = "-1" Then
                    e.Row.Cells(i).BackColor = Drawing.Color.FromArgb(128, 0, 128)
                    e.Row.Cells(i).Text = "&nbsp;"
                ElseIf e.Row.Cells(i).Text <= 2 Then
                    e.Row.Cells(i).BackColor = Drawing.Color.FromArgb(255, 192, 0)
                    e.Row.Cells(i).Text = "&nbsp;"
                Else
                    e.Row.Cells(i).BackColor = Drawing.Color.Red
                    e.Row.Cells(i).Text = "&nbsp;"
                End If
            Next
            Dim remarks As String = e.Row.Cells(e.Row.Cells.Count - 2).Text
            e.Row.Cells(e.Row.Cells.Count - 2).Text = Context.Server.HtmlDecode(remarks)

            Dim chartData As String = e.Row.Cells(e.Row.Cells.Count - 1).Text
            Dim img As System.Web.UI.WebControls.Image = New System.Web.UI.WebControls.Image
            img.Width = 100
            img.Height = 15
            img.ImageUrl = "image_handler.ashx?" & chartData
            Dim ttip As String() = chartData.Substring(3).Split("-")
            Dim tooltip As String = "Green:" & ttip(0) & ", Amber:" & ttip(1) & ", Red:" & ttip(2)
            img.ToolTip = tooltip
            e.Row.Cells(e.Row.Cells.Count - 1).Text = ""
            e.Row.Cells(e.Row.Cells.Count - 1).Controls.Add(img)

        End If
    End Sub

    Protected Sub ddl2_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddl2.SelectedIndexChanged
        LoadPriority()
        LoadData(hfFrom.Value, hfTo.Value)
    End Sub

    Protected Sub txtDate_TextChanged(sender As Object, e As System.EventArgs) Handles txtDate.TextChanged

        objController.PopulateMarketSegment(ddl2, hfFrom.Value, hfTo.Value)
        LoadData(hfFrom.Value, hfTo.Value)
    End Sub

    Protected Sub ddlCustomer_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlCustomer.SelectedIndexChanged
        LoadData(hfFrom.Value, hfTo.Value)
    End Sub
End Class
