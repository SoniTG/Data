﻿Imports System.Data
Imports System.IO

Partial Class dashboard
    Inherits System.Web.UI.Page
    Shared objController As New Controller
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As Date = Date.Today.AddDays(-29)
                Dim dtEnd As Date = Date.Today
                dtEnd = New Date(dtEnd.Year, dtEnd.Month, DateTime.DaysInMonth(dtEnd.Year, dtEnd.Month))

                Dim dtTemp As Date = dtStart

                Dim dtMonth As New DataTable
                dtMonth.Columns.Add("Month", GetType(String))

                While dtEnd >= dtTemp
                    dtMonth.Rows.Add(dtTemp.ToString("MMM-yy"))
                    dtTemp = dtTemp.AddMonths(1)
                End While

                Dim mStart As Integer = Integer.Parse(dtStart.ToString("MM"))
                Dim mEnd As Integer = Integer.Parse(dtEnd.ToString("MM"))
                Dim ds As DataSet = objController.LoadDashboard()

                Dim dt1_distinct_grade As DataTable = ds.Tables(0).DefaultView.ToTable(True, "PRM_CD_GRADE")
                Dim dt2_distinct_grade As DataTable = ds.Tables(1).DefaultView.ToTable(True, "PRM_CD_GRADE")
                Dim dt2_distinct_rough As DataTable = ds.Tables(3).DefaultView.ToTable(True, "PRM_CD_SURF_ROUGH")

                Dim s As New StringBuilder("")
                Dim sgrade As String = ""
                Dim sx As String = ""

                s.Append("<script>")
                s.Append("dashboard_bar_1 = Morris.Bar({element: 'dashboard-bar-1',data: [")
                For k As Integer = 0 To dtMonth.Rows.Count - 1
                    'For j As Integer = 0 To dt1_distinct_grade.Rows.Count - 1
                    If k > 0 Then
                        s.Append(",")
                    End If
                    Dim dv As DataView = ds.Tables(0).DefaultView
                    dv.RowFilter = "MY='" & dtMonth.Rows(k)(0) & "'"
                    s.Append("{y:'" & dtMonth.Rows(k)(0) & "'")
                    For i As Integer = 0 To dv.Count - 1
                        s.Append("," & dv.Item(i)(1) & ":" & dv.Item(i)(2))
                    Next
                    s.Append("}")
                    dv.RowFilter = ""
                    'Next
                Next
                s.Append("],xkey: 'y',ykeys: [")
                Dim skeys As String = ""
                'Dim skeys_name As String = ""
                For i As Integer = 0 To dt1_distinct_grade.Rows.Count - 1
                    skeys &= ",'" & dt1_distinct_grade.Rows(i)(0) & "'"
                    'skeys_name &= "," & dt1_distinct_grade.Rows(i)(0) & ""
                Next
                If skeys.Length = 0 Then skeys = ","
                s.Append(skeys.Substring(1))
                s.Append("],labels: [")
                s.Append(skeys.Substring(1))
                s.Append("],gridTextSize: '10px',hideHover: true,resize: true,stacked: true,gridLineColor: '#E5E5E5'});")
                's.Append("dashboard_bar_1.options.labels.forEach(function(label, i){")
                's.Append("var legendlabel=$('<span style=""display: inline-block;"">'+label+'</span>');")
                's.Append("var legendItem = $('<div class=""mbox""></div>').css('background-color', dashboard_bar_1.options.barColors[i]).append(legendlabel);")
                's.Append("$('#legend').append(legendItem)});")

                'ymax:2000,
                s.Append("dashboard_bar_2 = Morris.Bar({element: 'dashboard-bar-2',data: [")
                For k As Integer = 0 To dtMonth.Rows.Count - 1
                    'For j As Integer = 0 To dt2_distinct_grade.Rows.Count - 1
                    If k > 0 Then
                        s.Append(",")
                    End If
                    Dim dv As DataView = ds.Tables(1).DefaultView
                    dv.RowFilter = "MY='" & dtMonth.Rows(k)(0) & "'"
                    s.Append("{y:'" & dtMonth.Rows(k)(0) & "'")
                    For i As Integer = 0 To dv.Count - 1
                        s.Append("," & dv.Item(i)(1) & ":" & dv.Item(i)(2))
                    Next
                    s.Append("}")
                    dv.RowFilter = ""
                    'Next
                Next
                s.Append("],xkey: 'y',ykeys: [")
                skeys = ""
                For i As Integer = 0 To dt2_distinct_grade.Rows.Count - 1
                    skeys &= ",'" & dt2_distinct_grade.Rows(i)(0) & "'"
                Next
                s.Append(skeys.Substring(1))
                s.Append("],labels: [")
                s.Append(skeys.Substring(1))
                s.Append("],gridTextSize: '10px',hideHover: true,resize: true,stacked: true,gridLineColor: '#E5E5E5'});")

                'Donut Chart
                s.Append("dashboard_donut_1 = Morris.Donut({element: 'dashboard-donut-1',data: [")
                For i As Integer = 0 To ds.Tables(2).Rows.Count - 1
                    If (i > 0) Then
                        s.Append(",")
                    End If
                    s.Append("{label:""" & ds.Tables(2).Rows(i)(0) & """,value:" & ds.Tables(2).Rows(i)(2) & "}")
                Next
                s.Append("],colors:['#0b62a4','#33414E'],resize: true,formatter: function (y) { return y + ""T"" }});")

                'bar3
                s.Append("dashboard_bar_4 = Morris.Bar({element: 'dashboard-bar-4',data: [")
                For k As Integer = 0 To dtMonth.Rows.Count - 1
                    'For j As Integer = 0 To dt2_distinct_grade.Rows.Count - 1
                    If k > 0 Then
                        s.Append(",")
                    End If
                    Dim dv As DataView = ds.Tables(3).DefaultView
                    dv.RowFilter = "MY='" & dtMonth.Rows(k)(0) & "'"
                    s.Append("{y:'" & dtMonth.Rows(k)(0) & "'")
                    For i As Integer = 0 To dv.Count - 1
                        s.Append("," & dv.Item(i)(1) & ":" & dv.Item(i)(3))
                    Next
                    s.Append("}")
                    dv.RowFilter = ""
                    'Next
                Next
                s.Append("],xkey: 'y',ykeys: [")
                skeys = ""
                For i As Integer = 0 To dt2_distinct_rough.Rows.Count - 1
                    skeys &= ",'" & dt2_distinct_rough.Rows(i)(0) & "'"
                Next
                s.Append(skeys.Substring(1))
                s.Append("],labels: [")
                s.Append(skeys.Substring(1))
                s.Append("],gridTextSize: '10px',hideHover: true,resize: true,stacked: true,gridLineColor: '#E5E5E5'});")
                'Plant Production
                Dim running_campaign As String = ""
                Dim cSt, cEnd As String
                cSt = "" : cEnd = ""
                Dim cTonn As Double = 0.0
                Dim data As String = ""
                Dim color As String = ""
                If ds.Tables(4).Rows.Count > 0 Then
                    For i As Integer = 0 To ds.Tables(4).Rows.Count - 1
                        If i = 0 Then
                            running_campaign = ds.Tables(4).Rows(i)(1)
                            cSt = CDate(ds.Tables(4).Rows(i)(0)).ToString("yyyy-MM-dd HH:mm:ss")
                            cTonn += ds.Tables(4).Rows(i)(2)
                            Continue For
                        End If
                        If i = ds.Tables(4).Rows.Count - 1 Then
                            cTonn += ds.Tables(4).Rows(i)(2)
                            data &= ",['" & cSt & "','" & CDate(ds.Tables(4).Rows(i)(0)).ToString("yyyy-MM-dd HH:mm:ss") & "'," & Math.Round(cTonn, 0) & ",'" & IIf(running_campaign = "A", "GA", "GI") & "']"
                            If running_campaign = "A" Then
                                color &= ",'#4f81bd'"
                            Else
                                color &= ",'#604a7b'"
                            End If
                            Exit For
                        End If
                        If running_campaign = ds.Tables(4).Rows(i)(1) Then
                            cTonn += ds.Tables(4).Rows(i)(2)
                            cEnd = CDate(ds.Tables(4).Rows(i)(0)).ToString("yyyy-MM-dd HH:mm:ss")
                        End If
                        If running_campaign <> ds.Tables(4).Rows(i)(1) Then
                            data &= ",['" & cSt & "','" & cEnd & "'," & Math.Round(cTonn, 0) & ",'" & IIf(running_campaign = "A", "GA", "GI") & "']"
                            If running_campaign = "A" Then
                                color &= ",'#4f81bd'"
                            Else
                                color &= ",'#604a7b'"
                            End If
                            running_campaign = ds.Tables(4).Rows(i)(1)
                            cTonn = 0.0
                            cSt = CDate(ds.Tables(4).Rows(i)(0)).ToString("yyyy-MM-dd HH:mm:ss")
                            cEnd = ""
                        End If
                    Next
                    s.Append("var dub_data=[" & data.Substring(1) & "];var dub_color=[" & color.Substring(1) & "];")
                    s.Append("dub_data = echarts.util.map(dub_data, function (item, index) {return {value: item,itemStyle: {normal: {color: dub_color[index]}}};});")
                    's.Append("function renderItem(params, api) {var yValue = api.value(2);var start = api.coord([api.value(0), yValue]);var size = api.size([api.value(1) - api.value(0), yValue]);var style = api.style();")
                    's.Append("return {type: 'rect',shape: {x: start[0],y: start[1],width: size[0],height: size[1]},style: style};}")
                    s.Append("option = {tooltip: {},xAxis: [{type:'time',scale: true,axisLabel:{show: true,interval: 'auto'}}],")
                    s.Append("yAxis: {},series: [{type: 'custom',renderItem: renderItem,label: {normal: {show: true,position: 'top'}},dimensions: ['from', 'to', 'tonnage'],")
                    s.Append(" encode: {x: [0, 1],y: 2,tooltip: [0, 1, 2],itemName: 3},data: dub_data}]};")
                    s.Append("dashboard_unequal_bar = echarts.init(document.getElementById('dashboard-unequal-bar'));")
                    s.Append("dashboard_unequal_bar.setOption(option);")
                End If

                s.Append("</script>")
                litChart.Text = s.ToString & LoadCustomerChart()

            Catch ex As Exception

            End Try
        End If
    End Sub

    <System.Web.Services.WebMethod()>
    Public Shared Function GetCustomerData(ByVal dtFrom As String, ByVal dtTo As String) As String
        Try

            Dim dtStart As Date = Date.Parse(dtFrom)
            Dim dtEnd As Date = Date.Parse(dtTo)

            Dim dtTemp As Date = dtStart

            Dim dtMonth As New DataTable
            dtMonth.Columns.Add("Month", GetType(String))

            While dtEnd >= dtTemp
                dtMonth.Rows.Add(dtTemp.ToString("MMM-yy"))
                dtTemp = dtTemp.AddMonths(1)
            End While

            Dim ds As DataSet = objController.LoadCustomer(dtFrom, dtEnd)
            If ds.Tables(0).Rows.Count = 0 Then
                Return ""
            End If
            Dim dGrade As String = "["
            Dim s As New StringBuilder("")
            Dim dtGrade As DataTable = ds.Tables(1).DefaultView.ToTable(True, "PRM_CD_GRADE")
            Dim dtCustomer As DataTable = ds.Tables(1).DefaultView.ToTable(True, "PRM_MK_CUSTOMER")
            Dim lstLabels As New List(Of String)
            For i As Integer = 0 To dtGrade.Rows.Count - 1

                If i > 0 Then
                    s.Append("#")
                    dGrade &= ","
                End If

                dGrade &= "'" & dtGrade.Rows(i)(0) & "'"
                s.Append("[")
                For j As Integer = 0 To dtMonth.Rows.Count - 1
                    If j > 0 Then
                        s.Append(",")
                    End If
                    s.Append("{y:'" & dtMonth.Rows(j)(0) & "'")

                    Dim dv As DataView = ds.Tables(1).DefaultView
                    dv.RowFilter = "MY='" & dtMonth.Rows(j)(0) & "' and PRM_CD_GRADE='" & dtGrade.Rows(i)(0) & "'"
                    dv.Sort = "WT desc"
                    If dv.Count > 0 Then
                        Dim totWt As Double = ds.Tables(1).Compute("Sum(Wt)", "MY='" & dtMonth.Rows(j)(0) & "' and PRM_CD_GRADE='" & dtGrade.Rows(i)(0) & "'")
                        Dim top4Wt As Double = 0.0
                        For l As Integer = 0 To (IIf(dv.Count > 3, 3, dv.Count - 1)) '3 'dv.Count - 1
                            s.Append(",'" & dv.Item(l)("PRM_MK_CUSTOMER") & "':" & dv.Item(l)("wt"))
                            top4Wt += dv.Item(l)("wt")
                            If Not lstLabels.Contains(dv.Item(l)("PRM_MK_CUSTOMER")) Then
                                lstLabels.Add(dv.Item(l)("PRM_MK_CUSTOMER"))
                            End If
                        Next
                        If top4Wt < totWt Then
                            s.Append(",'OTHERS':" & (totWt - top4Wt))
                        End If
                        dv.RowFilter = ""
                    End If

                    s.Append("}")
                Next
                s.Append("]#")
                lstLabels.Add("OTHERS")
                s.Append("[" & "'" & String.Join("','", lstLabels.ToArray) & "']")
                lstLabels.Clear()
            Next
            dGrade &= "]"
            Return dGrade & "#" & s.ToString

        Catch ex As Exception

        End Try
    End Function

    <System.Web.Services.WebMethod()>
    Public Shared Function GetData(ByVal dtFrom As String, ByVal dtTo As String) As String
        Try

            Dim dtStart As Date = Date.Parse(dtFrom)
            Dim dtEnd As Date = Date.Parse(dtTo)
            dtEnd = New Date(dtEnd.Year, dtEnd.Month, DateTime.DaysInMonth(dtEnd.Year, dtEnd.Month))

            Dim dtTemp As Date = dtStart

            Dim dtMonth As New DataTable
            dtMonth.Columns.Add("Month", GetType(String))

            While dtEnd >= dtTemp
                dtMonth.Rows.Add(dtTemp.ToString("MMM-yy"))
                dtTemp = dtTemp.AddMonths(1)
            End While

            Dim ds As DataSet = objController.LoadDashboard(dtFrom, Date.Parse(dtTo))
            'If ds.Tables(0).Rows.Count = 0 Then
            '    Return ""
            'End If
            Return getChartString(ds, dtMonth)

        Catch ex As Exception

        End Try
    End Function

    Function LoadCustomerChart() As String
        Try

            Dim s As New StringBuilder("<script>")
            Dim ds As DataSet = objController.LoadCustomer()
            ddlGrade.DataSource = ds.Tables(0)
            ddlGrade.DataTextField = "PRM_CD_GRADE"
            ddlGrade.DataValueField = "PRM_CD_GRADE"
            ddlGrade.DataBind()

            Dim dtGrade As DataTable = ds.Tables(1).DefaultView.ToTable(True, "PRM_CD_GRADE")
            'Dim dtMonth As DataTable = ds.Tables(1).DefaultView.ToTable(True, "MY")
            Dim dtStart As Date = Date.Today.AddDays(-29)
            Dim dtEnd As Date = Date.Today
            dtEnd = New Date(dtEnd.Year, dtEnd.Month, DateTime.DaysInMonth(dtEnd.Year, dtEnd.Month))

            Dim dtTemp As Date = dtStart

            Dim dtMonth As New DataTable
            dtMonth.Columns.Add("Month", GetType(String))

            While dtEnd >= dtTemp
                dtMonth.Rows.Add(dtTemp.ToString("MMM-yy"))
                dtTemp = dtTemp.AddMonths(1)
            End While

            Dim dtCustomer As DataTable = ds.Tables(1).DefaultView.ToTable(True, "PRM_MK_CUSTOMER")

            Dim ykeys As String = ""
            Dim lstLabels As New List(Of String)
            For i As Integer = 0 To dtGrade.Rows.Count - 1
                s.Append("var " & dtGrade.Rows(i)(0) & "=[")
                lstLabels.Clear()
                For j As Integer = 0 To dtMonth.Rows.Count - 1
                    If j > 0 Then
                        s.Append(",")
                    End If
                    s.Append("{y:'" & dtMonth.Rows(j)(0) & "'")

                    Dim dv As DataView = ds.Tables(1).DefaultView
                    dv.RowFilter = "MY='" & dtMonth.Rows(j)(0) & "' and PRM_CD_GRADE='" & dtGrade.Rows(i)(0) & "'"
                    dv.Sort = "WT desc"
                    If dv.Count > 0 Then
                        Dim totWt As Double = ds.Tables(1).Compute("Sum(Wt)", "MY='" & dtMonth.Rows(j)(0) & "' and PRM_CD_GRADE='" & dtGrade.Rows(i)(0) & "'")
                        Dim top4Wt As Double = 0.0
                        For l As Integer = 0 To (IIf(dv.Count > 3, 3, dv.Count - 1)) '3 'dv.Count - 1
                            s.Append(",'" & dv.Item(l)("PRM_MK_CUSTOMER") & "':" & dv.Item(l)("wt"))
                            top4Wt += dv.Item(l)("wt")
                            If Not lstLabels.Contains(dv.Item(l)("PRM_MK_CUSTOMER")) Then
                                lstLabels.Add(dv.Item(l)("PRM_MK_CUSTOMER"))
                            End If
                        Next
                        If top4Wt < totWt Then
                            s.Append(",'OTHERS':" & (totWt - top4Wt))
                        End If
                        dv.RowFilter = ""
                    End If

                    'For l As Integer = 0 To dtCustomer.Rows.Count - 1
                    '    If l > 0 Then
                    '        's.Append(",")
                    '    End If
                    '    dv.RowFilter = "MY='" & dtMonth.Rows(j)(0) & "' and PRM_CD_GRADE='" & dtGrade.Rows(i)(0) & "' and PRM_MK_CUSTOMER='" & dtCustomer.Rows(l)(0) & "'"
                    '    If dv.Count > 0 Then

                    '        s.Append(",'" & dv.Item(0)("PRM_MK_CUSTOMER") & "':" & dv.Item(0)("wt"))
                    '    Else

                    '        's.Append("'" & dtCustomer.Rows(l)(0) & "':0")
                    '    End If

                    '    dv.RowFilter = ""
                    'Next
                    s.Append("}")
                Next
                s.Append("];")
                lstLabels.Add("OTHERS")
                s.Append("var ykeys" & dtGrade.Rows(i)(0) & "=[" & "'" & String.Join("','", lstLabels.ToArray) & "'];")
            Next

            If dtCustomer.Rows.Count > 0 Then

                Dim sLabels As String = "'" & String.Join("','", lstLabels.ToArray) & "'"
                s.Append("dashboard_bar_5 = Morris.Bar({element: 'dashboard-bar-5',data:" & dtGrade.Rows(0)(0))
                ddlGrade.SelectedIndex = ddlGrade.Items.IndexOf(ddlGrade.Items.FindByText(dtGrade.Rows(0)(0)))
                s.Append(",xkey: 'y',ykeys: " & "ykeys" & dtGrade.Rows(0)(0) & ",labels: " & "ykeys" & dtGrade.Rows(0)(0) & ",gridTextSize: '10px',hideHover: true,resize: true,stacked: true,gridLineColor: '#E5E5E5'});")
            End If
            s.Append("</script>")
            Return s.ToString

        Catch ex As Exception

        End Try
    End Function

    Shared Function LoadTrendChart() As String
        Try

            Dim s As New StringBuilder("<script>")
            Dim ds As DataSet = objController.LoadDashboard_Trend()

            'trend1
            s.Append("dashboard_trend_1 = Morris.Line({element: 'dashboard-trend-1',data: [")
            For k As Integer = 0 To ds.Tables(0).Rows.Count - 1
                'For j As Integer = 0 To dt1_distinct_grade.Rows.Count - 1
                If k > 0 Then
                    s.Append(",")
                End If
                s.Append("{y:'" & CDate(ds.Tables(0).Rows(k)(0)).ToString("yyyy-MM-dd HH:mm:ss") & "'")
                If ds.Tables(0).Rows(k)("PRM_CD_SURF_ROUGH") = "A" Then
                    s.Append(",'a':" & ds.Tables(0).Rows(k)("PRM_HS_STRP_TMP"))
                Else
                    s.Append(",'a':null")
                End If
                If ds.Tables(0).Rows(k)("PRM_CD_SURF_ROUGH") = "Z" Then
                    s.Append(",'b':" & ds.Tables(0).Rows(k)("PRM_HS_STRP_TMP"))
                Else
                    s.Append(",'b':null")
                End If
                s.Append("}")
                s.Append(vbCrLf)
                'Next
            Next
            s.Append("],xkey:   'y',ykeys: ['a', 'b'],labels: ['A','Z'],ymin:0,ymax:800,resize: true,hideHover: true,pointSize:'0px',resize: true,")
            s.Append("gridTextSize:  '10px',gridLineColor:  '#E5E5E5'});")
            'trend2
            s.Append("dashboard_trend_2 = Morris.Line({element: 'dashboard-trend-2',data: [")
            For k As Integer = 0 To ds.Tables(0).Rows.Count - 1
                'For j As Integer = 0 To dt1_distinct_grade.Rows.Count - 1
                If k > 0 Then
                    s.Append(",")
                End If
                s.Append("{y:'" & CDate(ds.Tables(0).Rows(k)(0)).ToString("yyyy-MM-dd HH:mm:ss") & "'")
                If ds.Tables(0).Rows(k)("PRM_CD_SURF_ROUGH") = "A" Then
                    s.Append(",'a':" & ds.Tables(0).Rows(k)("PRM_SNT_STRP_TMP"))
                Else
                    s.Append(",'a':null")
                End If
                If ds.Tables(0).Rows(k)("PRM_CD_SURF_ROUGH") = "Z" Then
                    s.Append(",'b':" & ds.Tables(0).Rows(k)("PRM_SNT_STRP_TMP"))
                Else
                    s.Append(",'b':null")
                End If
                s.Append("}")
                s.Append(vbCrLf)
                'Next
            Next
            s.Append("],xkey:   'y',ykeys: ['a', 'b'],labels: ['A','Z'],ymin:0,ymax:800,resize: true,hideHover: true,pointSize:'0px',resize: true,")
            s.Append("gridTextSize:  '10px',gridLineColor:  '#E5E5E5'});")
            'trend3
            s.Append("dashboard_trend_3= Morris.Line({element: 'dashboard-trend-3',data: [")
            For k As Integer = 0 To ds.Tables(0).Rows.Count - 1
                'For j As Integer = 0 To dt1_distinct_grade.Rows.Count - 1
                If k > 0 Then
                    s.Append(",")
                End If
                s.Append("{y:'" & CDate(ds.Tables(0).Rows(k)(0)).ToString("yyyy-MM-dd HH:mm:ss") & "'")
                If ds.Tables(0).Rows(k)("PRM_CD_SURF_ROUGH") = "A" Then
                    s.Append(",'a':" & ds.Tables(0).Rows(k)("PRM_RCF_STRP_TMP"))
                Else
                    s.Append(",'a':null")
                End If
                If ds.Tables(0).Rows(k)("PRM_CD_SURF_ROUGH") = "Z" Then
                    s.Append(",'b':" & ds.Tables(0).Rows(k)("PRM_RCF_STRP_TMP"))
                Else
                    s.Append(",'b':null")
                End If
                s.Append("}")
                s.Append(vbCrLf)
                'Next
            Next
            s.Append("],xkey:   'y',ykeys: ['a', 'b'],labels: ['A','Z'],ymin:0,ymax:800,resize: true,hideHover: true,pointSize:'0px',resize: true,")
            s.Append("gridTextSize:  '10px',gridLineColor:  '#E5E5E5'});")
            'trend4
            s.Append("dashboard_trend_4 = Morris.Line({element: 'dashboard-trend-4',data: [")
            For k As Integer = 0 To ds.Tables(0).Rows.Count - 1
                'For j As Integer = 0 To dt1_distinct_grade.Rows.Count - 1
                If k > 0 Then
                    s.Append(",")
                End If
                s.Append("{y:'" & CDate(ds.Tables(0).Rows(k)(0)).ToString("yyyy-MM-dd HH:mm:ss") & "'")
                If ds.Tables(0).Rows(k)("PRM_CD_SURF_ROUGH") = "A" Then
                    s.Append(",'a':" & ds.Tables(0).Rows(k)("PRM_SNT_STRP_TMP"))
                Else
                    s.Append(",'a':null")
                End If
                If ds.Tables(0).Rows(k)("PRM_CD_SURF_ROUGH") = "Z" Then
                    s.Append(",'b':" & ds.Tables(0).Rows(k)("PRM_SNT_STRP_TMP"))
                Else
                    s.Append(",'b':null")
                End If
                s.Append("}")
                s.Append(vbCrLf)
                'Next
            Next
            s.Append("],xkey:   'y',ykeys: ['a', 'b'],labels: ['A','Z'],ymin:0,ymax:800,resize: true,hideHover: true,pointSize:'0px',resize: true,")
            s.Append("gridTextSize:  '10px',gridLineColor:  '#E5E5E5'});")
            'trend force
            s.Append("dashboard_trend_6= Morris.Line({element: 'dashboard-trend-6',data: [")
            For k As Integer = 0 To ds.Tables(1).Rows.Count - 1
                'For j As Integer = 0 To dt1_distinct_grade.Rows.Count - 1
                If k > 0 Then
                    s.Append(",")
                End If
                s.Append("{y:'" & CDate(ds.Tables(1).Rows(k)("PRM_TS_END")).ToString("yyyy-MM-dd HH:mm:ss") & "'")
                If ds.Tables(1).Rows(k)("PRM_CD_SURF_ROUGH") = "A" Then
                    s.Append(",'a':" & ds.Tables(1).Rows(k)("prm_force"))
                Else
                    s.Append(",'a':null")
                End If
                If ds.Tables(1).Rows(k)("PRM_CD_SURF_ROUGH") = "Z" Then
                    s.Append(",'b':" & ds.Tables(1).Rows(k)("prm_force"))
                Else
                    s.Append(",'b':null")
                End If
                s.Append("}")
                's.Append(vbCrLf)
                'Next
            Next
            s.Append("],xkey:   'y',ykeys: ['a', 'b'],labels: ['A','Z'],resize: true,hideHover: true,pointSize:'0px',resize: true,")
            s.Append("gridTextSize:  '10px',gridLineColor:  '#E5E5E5'});")
            'End of trend force
            'trend Line Speed
            s.Append("dashboard_trend_5= Morris.Line({element: 'dashboard-trend-5',data: [")
            For k As Integer = 0 To ds.Tables(1).Rows.Count - 1
                'For j As Integer = 0 To dt1_distinct_grade.Rows.Count - 1
                If k > 0 Then
                    s.Append(",")
                End If
                s.Append("{y:'" & CDate(ds.Tables(1).Rows(k)("PRM_TS_END")).ToString("yyyy-MM-dd HH:mm:ss") & "'")
                If ds.Tables(1).Rows(k)("PRM_CD_SURF_ROUGH") = "A" Then
                    s.Append(",'a':" & ds.Tables(1).Rows(k)("prm_line_speed"))
                Else
                    s.Append(",'a':null")
                End If
                If ds.Tables(1).Rows(k)("PRM_CD_SURF_ROUGH") = "Z" Then
                    s.Append(",'b':" & ds.Tables(1).Rows(k)("prm_line_speed"))
                Else
                    s.Append(",'b':null")
                End If
                s.Append("}")
                's.Append(vbCrLf)
                'Next
            Next
            s.Append("],xkey:   'y',ykeys: ['a', 'b'],labels: ['A','Z'],resize: true,hideHover: true,pointSize:'0px',resize: true,")
            s.Append("gridTextSize:  '10px',gridLineColor:  '#E5E5E5'});")
            'End of trend Line Speed
            'elong box plot
            s.Append("var A_E=[];var Z_E=[];var D1_E=[];var D2_E=[];var data_E=[];")
            s.Append("var A=[];var Z=[];var D1=[];var D2=[];var data=[];")
            Dim sx As String = ""
            Dim intC As Integer = 1
            Dim stC As String = ""
            Dim stR As String = ""
            Dim dtDistint As DataTable = ds.Tables(1).DefaultView.ToTable(True, "MY")
            For j As Integer = 0 To dtDistint.Rows.Count - 1
                sx &= ",'" & dtDistint.Rows(j)(0) & "'"
                Dim dv As DataView = ds.Tables(1).DefaultView
                dv.RowFilter = "MY='" & dtDistint.Rows(j)(0) & "'"
                For i As Integer = 0 To dv.Count - 1
                    If dv.Item(i)("PRM_CD_SURF_ROUGH") = "A" Then
                        s.Append("A.push(" & dv.Item(i)("prm_zinc_pot_tmp") & ");")
                        s.Append("A_E.push(" & dv.Item(i)("prm_elong") & ");")
                    Else
                        s.Append("Z.push(" & dv.Item(i)("prm_zinc_pot_tmp") & ");")
                        s.Append("Z_E.push(" & dv.Item(i)("prm_elong") & ");")
                    End If
                Next
                dv.RowFilter = ""
                s.Append("D1.push(A);D2.push(Z);A=[];Z=[];")
                s.Append("D1_E.push(A_E);D2_E.push(Z_E);A_E=[];Z_E=[];")

            Next
            s.Append("data_E.push(echarts.dataTool.prepareBoxplotData(D1_E));data_E.push(echarts.dataTool.prepareBoxplotData(D2_E));")
            s.Append("option_E = {title:{show:false},tooltip: {trigger: 'item',axisPointer: {type: 'shadow'}},grid: {left: '15%',right: '5%',bottom: '15%',top:'20%'},xAxis: {type: 'category',data: [")
            s.Append(sx.Substring(1))
            s.Append("],boundaryGap: true,nameGap: 30,splitArea: {show: false},axisLabel: {formatter: '{value}'},splitLine: {show: false}},legend: {y: '6%',data: ['A', 'Z']},yAxis: {type: 'value',name: '',splitArea: {show: true}},series: [")
            s.Append("{name: 'A',type: 'boxplot',data: data_E[0].boxData,tooltip: {formatter: function (param) {return ['' + param.name + ': ','upper: ' + param.data_E[5],'Q3: ' + param.data_E[4],'median: ' + param.data_E[3],'Q1: ' + param.data_E[2],'lower: ' + param.data_E[1]].join('<br/>')}}},{name: 'Z',type: 'boxplot',data: data_E[1].boxData,tooltip: {formatter: function (param) {return ['' + param.name + ': ','upper: ' + param.data_E[5],'Q3: ' + param.data_E[4],'median: ' + param.data_E[3],'Q1: ' + param.data_E[2],'lower: ' + param.data_E[1]].join('<br/>')}}},{name: 'outlier',type: 'scatter',data: data_E.outliers}")
            s.Append("]};")
            s.Append("dashboard_boxplot_1 = echarts.init(document.getElementById('dashboard-boxplot-1'));")
            s.Append("dashboard_boxplot_1.setOption(option_E);")
            'end of elong box plot
            'Zinc Pot temp box plot
            s.Append("var A=[];var Z=[];var D1=[];var D2=[];var data=[];")
            sx = ""
            intC = 1
            stC = ""
            stR = ""

            For j As Integer = 0 To dtDistint.Rows.Count - 1
                sx &= ",'" & dtDistint.Rows(j)(0) & "'"
                Dim dv As DataView = ds.Tables(1).DefaultView
                dv.RowFilter = "MY='" & dtDistint.Rows(j)(0) & "'"
                For i As Integer = 0 To dv.Count - 1
                    If dv.Item(i)("PRM_CD_SURF_ROUGH") = "A" Then
                        s.Append("A.push(" & dv.Item(i)("prm_zinc_pot_tmp") & ");")
                    Else
                        s.Append("Z.push(" & dv.Item(i)("prm_zinc_pot_tmp") & ");")
                    End If
                Next
                dv.RowFilter = ""
                s.Append("D1.push(A);D2.push(Z);A=[];Z=[];")

            Next
            s.Append("data.push(echarts.dataTool.prepareBoxplotData(D1));data.push(echarts.dataTool.prepareBoxplotData(D2));")
            s.Append("option = {title:{show:false},tooltip: {trigger: 'item',axisPointer: {type: 'shadow'}},grid: {left: '15%',right: '5%',bottom: '15%',top:'20%'},xAxis: {type: 'category',data: [")
            s.Append(sx.Substring(1))
            s.Append("],boundaryGap: true,nameGap: 30,splitArea: {show: false},axisLabel: {formatter: '{value}'},splitLine: {show: false}},legend: {y: '6%',data: ['A', 'Z']},yAxis: {type: 'value',name: '',splitArea: {show: true}},series: [")
            s.Append("{name: 'A',type: 'boxplot',data: data[0].boxData,tooltip: {formatter: function (param) {return ['' + param.name + ': ','upper: ' + param.data[5],'Q3: ' + param.data[4],'median: ' + param.data[3],'Q1: ' + param.data[2],'lower: ' + param.data[1]].join('<br/>')}}},{name: 'Z',type: 'boxplot',data: data[1].boxData,tooltip: {formatter: function (param) {return ['' + param.name + ': ','upper: ' + param.data[5],'Q3: ' + param.data[4],'median: ' + param.data[3],'Q1: ' + param.data[2],'lower: ' + param.data[1]].join('<br/>')}}},{name: 'outlier',type: 'scatter',data: data.outliers}")
            s.Append("]};")
            s.Append("dashboard_boxplot_2 = echarts.init(document.getElementById('dashboard-boxplot-2'));")
            s.Append("dashboard_boxplot_2.setOption(option);")
            'End of zinc pot temp box plot
            s.Append("</script>")
            Return s.ToString

        Catch ex As Exception

        End Try
    End Function

    Shared Function getChartString(ByRef ds As DataSet, ByRef dtMonth As DataTable) As String
        Try

            Dim retVal As String = ""
            Dim dt1_distinct_grade As DataTable = ds.Tables(0).DefaultView.ToTable(True, "PRM_CD_GRADE")
            Dim dt2_distinct_grade As DataTable = ds.Tables(1).DefaultView.ToTable(True, "PRM_CD_GRADE")
            Dim dt2_distinct_rough As DataTable = ds.Tables(3).DefaultView.ToTable(True, "PRM_CD_SURF_ROUGH")
            Dim s As New StringBuilder("")
            Dim sgrade As String = ""
            Dim sx As String = ""
            If ds.Tables(0).Rows.Count > 0 Then
                s.Append("[")
                For k As Integer = 0 To dtMonth.Rows.Count - 1
                    'For j As Integer = 0 To dt1_distinct_grade.Rows.Count - 1
                    If k > 0 Then
                        s.Append(",")
                    End If
                    Dim dv As DataView = ds.Tables(0).DefaultView
                    dv.RowFilter = "MY='" & dtMonth.Rows(k)(0) & "'"
                    s.Append("{y:'" & dtMonth.Rows(k)(0) & "'")
                    For i As Integer = 0 To dv.Count - 1
                        s.Append("," & dv.Item(i)(1) & ":" & dv.Item(i)(2))
                    Next
                    s.Append("}")
                    dv.RowFilter = ""
                    'Next
                Next
                s.Append("]")
            Else
                s.Append("[]")
            End If

            retVal = s.ToString()

            s.Clear()

            Dim skeys As String = ""
            'Dim skeys_name As String = ""
            For i As Integer = 0 To dt1_distinct_grade.Rows.Count - 1
                skeys &= ",'" & dt1_distinct_grade.Rows(i)(0) & "'"
                'skeys_name &= "," & dt1_distinct_grade.Rows(i)(0) & ""
            Next
            If skeys = "" Then
                retVal = retVal & "#''"
            Else
                retVal = retVal & "#" & skeys.Substring(1)
            End If


            'ymax:2000,
            If ds.Tables(1).Rows.Count > 0 Then
                s.Append("[")
                For k As Integer = 0 To dtMonth.Rows.Count - 1
                    'For j As Integer = 0 To dt2_distinct_grade.Rows.Count - 1
                    If k > 0 Then
                        s.Append(",")
                    End If
                    Dim dv As DataView = ds.Tables(1).DefaultView
                    dv.RowFilter = "MY='" & dtMonth.Rows(k)(0) & "'"
                    s.Append("{y:'" & dtMonth.Rows(k)(0) & "'")
                    For i As Integer = 0 To dv.Count - 1
                        s.Append("," & dv.Item(i)(1) & ":" & dv.Item(i)(2))
                    Next
                    s.Append("}")
                    dv.RowFilter = ""
                    'Next
                Next
                s.Append("]")

            Else
                s.Append("[]")
            End If
            retVal = retVal & "#" & s.ToString()
            skeys = ""
            For i As Integer = 0 To dt2_distinct_grade.Rows.Count - 1
                skeys &= ",'" & dt2_distinct_grade.Rows(i)(0) & "'"
            Next
            If skeys = "" Then
                retVal = retVal & "#''"
            Else
                retVal = retVal & "#" & skeys.Substring(1)
            End If


            'Donut Chart
            s.Clear()
            If ds.Tables(2).Rows.Count > 0 Then
                s.Append("[")
                For i As Integer = 0 To ds.Tables(2).Rows.Count - 1
                    If (i > 0) Then
                        s.Append(",")
                    End If
                    s.Append("{label:""" & ds.Tables(2).Rows(i)(0) & """,value:" & ds.Tables(2).Rows(i)(2) & "}")
                Next
                s.Append("]")
            Else
                s.Append("[]")
            End If

            retVal = retVal & "#" & s.ToString()

            s.Clear()

            skeys = ""
            'Dim skeys_name As String = ""
            'For i As Integer = 0 To dt2_distinct_rough.Rows.Count - 1
            '    skeys &= ",'" & dt2_distinct_rough.Rows(i)(0) & "'"
            '    'skeys_name &= "," & dt1_distinct_grade.Rows(i)(0) & ""
            'Next
            'retVal = retVal & "#" & skeys.Substring(1)

            'ymax:2000,
            If ds.Tables(3).Rows.Count > 0 Then
                s.Append("[")
                For k As Integer = 0 To dtMonth.Rows.Count - 1
                    'For j As Integer = 0 To dt2_distinct_grade.Rows.Count - 1
                    If k > 0 Then
                        s.Append(",")
                    End If
                    Dim dv As DataView = ds.Tables(3).DefaultView
                    dv.RowFilter = "MY='" & dtMonth.Rows(k)(0) & "'"
                    s.Append("{y:'" & dtMonth.Rows(k)(0) & "'")
                    For i As Integer = 0 To dv.Count - 1
                        s.Append("," & dv.Item(i)(1) & ":" & dv.Item(i)(3))
                    Next
                    s.Append("}")
                    dv.RowFilter = ""
                    'Next
                Next
                s.Append("]")
            Else
                s.Append("[]")
            End If

            retVal = retVal & "#" & s.ToString()
            skeys = ""
            For i As Integer = 0 To dt2_distinct_rough.Rows.Count - 1
                skeys &= ",'" & dt2_distinct_rough.Rows(i)(0) & "'"
            Next
            If skeys = "" Then
                retVal = retVal & "#''"
            Else
                retVal = retVal & "#" & skeys.Substring(1)
            End If

            'Plant Production
            Dim running_campaign As String = ""
            Dim cSt, cEnd As String
            cSt = "" : cEnd = ""
            Dim cTonn As Double = 0.0
            Dim data As String = ""
            Dim color As String = ""
            If ds.Tables(4).Rows.Count > 0 Then
                For i As Integer = 0 To ds.Tables(4).Rows.Count - 1
                    If i = 0 Then
                        running_campaign = ds.Tables(4).Rows(i)(1)
                        cSt = CDate(ds.Tables(4).Rows(i)(0)).ToString("yyyy-MM-dd HH:mm:ss")
                        cTonn += ds.Tables(4).Rows(i)(2)
                        Continue For
                    End If
                    If i = ds.Tables(4).Rows.Count - 1 Then
                        cTonn += ds.Tables(4).Rows(i)(2)
                        data &= ",['" & cSt & "','" & CDate(ds.Tables(4).Rows(i)(0)).ToString("yyyy-MM-dd HH:mm:ss") & "'," & Math.Round(cTonn, 0) & ",'" & IIf(running_campaign = "A", "GA", "GI") & "']"
                        If running_campaign = "A" Then
                            color &= ",'#4f81bd'"
                        Else
                            color &= ",'#604a7b'"
                        End If
                        Exit For
                    End If
                    If running_campaign = ds.Tables(4).Rows(i)(1) Then
                        cTonn += ds.Tables(4).Rows(i)(2)
                        cEnd = CDate(ds.Tables(4).Rows(i)(0)).ToString("yyyy-MM-dd HH:mm:ss")
                    End If
                    If running_campaign <> ds.Tables(4).Rows(i)(1) Then
                        data &= ",['" & cSt & "','" & cEnd & "'," & Math.Round(cTonn, 0) & ",'" & IIf(running_campaign = "A", "GA", "GI") & "']"
                        If running_campaign = "A" Then
                            color &= ",'#4f81bd'"
                        Else
                            color &= ",'#604a7b'"
                        End If
                        running_campaign = ds.Tables(4).Rows(i)(1)
                        cTonn = 0.0
                        cSt = CDate(ds.Tables(4).Rows(i)(0)).ToString("yyyy-MM-dd HH:mm:ss")
                        cEnd = ""
                    End If
                Next
                retVal = retVal & "#[" & data.Substring(1) & "]~[" & color.Substring(1) & "]"
            Else
                retVal = retVal & "#[]~[]"
            End If
            Return retVal.ToString

        Catch ex As Exception

        End Try
    End Function
End Class
