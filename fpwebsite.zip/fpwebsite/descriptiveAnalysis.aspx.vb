﻿Imports System.Data
Imports System.IO
Partial Class descriptiveAnalysis
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
            Dim dtStart As String = DateTime.Now.AddDays(-29).ToString("yyyy-MM-dd HH:mm")
            'Dim dtStart As DateTime = DateTime.Now.AddMonths(-4).ToString("yyyy-MM-dd HH:mm")
            Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
            objController.PopulateGrade(ddlGrade, dtStart, dtEnd)
            objController.PopulateTdc(ddlTdc, dtStart, dtEnd, ddlGrade.SelectedItem.Text)
            objController.PopulateRough(ddlThickness, dtStart, dtEnd, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
            'objController.LoadColumnName(clbParamTest)
            Dim filter As String = " 1=1"
                DrawChartTop(dtStart, dtEnd, filter)
            Catch ex As Exception

            End Try
        End If
    End Sub


   

    Sub DrawChartTop(ByVal FromDt As String, ByVal ToDt As String, ByVal Filter As String)
        Try

            Dim strfrmDt As String = FromDt
            Dim strToDt As String = ToDt


            Dim dt As DataTable = objController.GetDataForDescriptiveAnalysis("T_CGL_FUR_PARAM", strfrmDt, strToDt, "PRM_TS_END", Filter)
           
            objController.PlotScatterChartForDescAnalysisYS(dt, "PRM_TEST_VALUE_YS", "PRM_TEST_VALUE_UTS", Lit1, "container1", "plot1", "YS", "UTS")
            objController.PlotScatterChartForDescAnalysisForce(dt, "PRM_ELONG", "PRM_FORCE", Lit2, "container2", "plot2", "Elongation", "Force")
            objController.PlotScatterChartForDescAnalysisCarbon(dt, "PRM_TEST_PARA_VAL_C", "PRM_TEST_VALUE_YS", Lit3, "container3", "plot3", "%C", "YS")
            objController.PlotScatterChartForDescAnalysisCarbon(dt, "PRM_TEST_PARA_VAL_C", "PRM_TEST_VALUE_UTS", Lit4, "container4", "plot4", "%C", "UTS")
            objController.PlotScatterChartForDescAnalysisCarbon(dt, "PRM_TEST_PARA_VAL_C", "PRM_ELONG", Lit5, "container5", "plot5", "%C", "EL")
            objController.PlotScatterChartForDescAnalysisCarbon(dt, "PRM_TEST_PARA_VAL_C", "PRM_TEST_VALUE_RBAR", Lit6, "container6", "plot6", "%C", "R BAR")

        Catch ex As Exception

        End Try
    End Sub
    Protected Sub ddlGrade_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlGrade.SelectedIndexChanged
        Try
            Dim fromDt As String = hfFrom.Value
        Dim toDt As String = hfTo.Value
        objController.PopulateTdc(ddlTdc, fromDt, toDt, ddlGrade.SelectedItem.Text)
        objController.PopulateRough(ddlThickness, fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
            txtDate_TextChanged(sender, e)
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub ddlTdc_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlTdc.SelectedIndexChanged
        Try
            Dim fromDt As String = hfFrom.Value
        Dim toDt As String = hfTo.Value
        objController.PopulateRough(ddlThickness, fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
            txtDate_TextChanged(sender, e)
        Catch ex As Exception

        End Try
    End Sub


    Protected Sub ddlThickness_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlThickness.SelectedIndexChanged
        Try

      
        Dim fromDt As String = hfFrom.Value
        Dim toDt As String = hfTo.Value

        Dim filter As String = " 1=1"
        If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
            filter &= " and PRM_CD_GRADE = '" & ddlGrade.SelectedItem.Text & "'"
        End If
        If ddlTdc.SelectedItem.Text.ToLower <> "all" Then
            filter &= " and PRM_TDC_NO = '" & ddlTdc.SelectedItem.Text & "'"
        End If
        If ddlThickness.SelectedItem.Text.ToLower <> "all" Then
            filter &= " and PRM_CD_SURF_ROUGH = '" & ddlThickness.SelectedItem.Value & "'"
        End If
            DrawChartTop(fromDt, toDt, filter)
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub txtDate_TextChanged(sender As Object, e As System.EventArgs) Handles txtDate.TextChanged
        Try

      
        Dim fromDt As String = hfFrom.Value
        Dim toDt As String = hfTo.Value
        If ddlGrade.SelectedIndex > 0 And ddlTdc.SelectedIndex > 0 And ddlThickness.SelectedIndex > 0 Then
            objController.PopulateGrade(ddlGrade, fromDt, toDt)
            objController.PopulateTdc(ddlTdc, fromDt, toDt, ddlGrade.SelectedItem.Text)
            objController.PopulateRough(ddlThickness, fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
        End If
        Dim filter As String = " 1=1"
        If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
            filter &= " and PRM_CD_GRADE = '" & ddlGrade.SelectedItem.Text & "'"
        End If
        If ddlTdc.SelectedItem.Text.ToLower <> "all" Then
            filter &= " and PRM_TDC_NO = '" & ddlTdc.SelectedItem.Text & "'"
        End If
        If ddlThickness.SelectedItem.Text.ToLower <> "all" Then
            filter &= " and PRM_CD_SURF_ROUGH = '" & ddlThickness.SelectedItem.Value & "'"
        End If
            DrawChartTop(fromDt, toDt, filter)
        Catch ex As Exception

        End Try
    End Sub
End Class
