﻿Imports System.Data
Imports System.IO
Partial Class descriptiveAnalysisCRCW
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try

                Dim p As String = Request("__EVENTARGUMENT")
                If (p = "thickness") Then
                    'processThickness()
                ElseIf p = "coil" Then
                    'processCoil()
                ElseIf p = "width" Then
                    'processWidth()
                ElseIf p = "date" Then
                    txtDate_TextChanged()
                ElseIf p = "date1" Then
                    txtDate1_TextChanged()
                End If
            Catch ex As Exception

            End Try
        End If

        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))

                Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
                'Dim dtStart As DateTime = DateTime.Now.AddMonths(-6).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                objController.PopulateGradeForCRCW(ddlGrade, dtStart, dtEnd)
                objController.PopulateTdcForCRCW(ddlTdc, dtStart, dtEnd, "")
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForCRCWDetailAnalysis(dtStart, dtEnd, "", "")
                If dt.Rows.Count > 0 AndAlso Not IsDBNull(dt.Rows(0)(0)) Then
                    txtFromThickness.Text = dt.Rows(0)(0)
                    txtToThickness.Text = dt.Rows(0)(1)
                    If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                        dt1 = objController.PopulateWidthForCRCWDetailAnalysis(dtStart, dtEnd, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                        'txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0) * 1000, 0)
                        'txtWidthTo.Text = Math.Round(dt1.Rows(0)(1) * 1000, 0)
                        txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0), 0)
                        txtWidthTo.Text = Math.Round(dt1.Rows(0)(1), 0)
                    End If
                End If
                Dim filter As String = " 1=1"
                If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
                    filter &= " and GRADE = '" & ddlGrade.SelectedItem.Text & "'"
                End If
                If ddlTdc.SelectedItem.Text.ToLower <> "all" Then
                    filter &= " and TDC_No = '" & ddlTdc.SelectedItem.Text & "'"
                End If
                If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                    filter &= " and THICKNESS between " & txtFromThickness.Text & " and " & txtToThickness.Text & ""
                    'divHolder.Attributes.Add("style", "display:none")
                End If
                If txtWidthFrom.Text <> "" And txtWidthTo.Text <> "" Then
                    'filter &= " and WIDTH between " & txtWidthFrom.Text / 1000 & " and " & txtWidthTo.Text / 1000 & ""
                    filter &= " and WIDTH between " & txtWidthFrom.Text & " and " & txtWidthTo.Text & ""
                End If
                DrawChartTop(dtStart, dtEnd, filter)


                Dim dtStart1 As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
                'Dim dtStart As DateTime = DateTime.Now.AddMonths(-6).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd1 As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                objController.PopulateGradeForCRCW(ddlGrade1, dtStart1, dtEnd1)
                objController.PopulateTdcForCRCW(ddlTdc1, dtStart1, dtEnd1, "")
                Dim dt11, dt12 As DataTable
                dt11 = objController.PopulateThicknessForCRCWDetailAnalysis(dtStart1, dtEnd1, "", "")
                If dt11.Rows.Count > 0 AndAlso Not IsDBNull(dt11.Rows(0)(0)) Then
                    txtFromThickness1.Text = dt11.Rows(0)(0)
                    txtToThickness1.Text = dt11.Rows(0)(1)
                    If txtFromThickness1.Text <> "" And txtToThickness1.Text <> "" Then
                        dt12 = objController.PopulateWidthForCRCWDetailAnalysis(dtStart1, dtEnd1, ddlGrade1.SelectedItem.Text, ddlTdc1.SelectedItem.Text, txtFromThickness1.Text, txtToThickness1.Text)
                        'txtWidthFrom1.Text = Math.Round(dt12.Rows(0)(0) * 1000, 0)
                        'txtWidthTo1.Text = Math.Round(dt12.Rows(0)(1) * 1000, 0)
                        txtWidthFrom1.Text = Math.Round(dt12.Rows(0)(0), 0)
                        txtWidthTo1.Text = Math.Round(dt12.Rows(0)(1), 0)
                    End If
                End If
                Dim filter1 As String = " 1=1"
                If ddlGrade1.SelectedItem.Text.ToLower <> "all" Then
                    filter1 &= " and GRADE = '" & ddlGrade1.SelectedItem.Text & "'"
                End If
                If ddlTdc1.SelectedItem.Text.ToLower <> "all" Then
                    filter1 &= " and TDC_No = '" & ddlTdc1.SelectedItem.Text & "'"
                End If
                If txtFromThickness1.Text <> "" And txtToThickness1.Text <> "" Then
                    filter1 &= " and THICKNESS between " & txtFromThickness1.Text & " and " & txtToThickness1.Text & ""
                    'divHolder.Attributes.Add("style", "display:none")
                End If
                If txtWidthFrom1.Text <> "" And txtWidthTo1.Text <> "" Then
                    'filter1 &= " and WIDTH between " & txtWidthFrom1.Text / 1000 & " and " & txtWidthTo1.Text / 1000 & ""
                    filter1 &= " and WIDTH between " & txtWidthFrom1.Text & " and " & txtWidthTo1.Text & ""
                End If
                DrawChartTop1(dtStart1, dtEnd1, filter1)
            Catch ex As Exception

            End Try



        End If
    End Sub

    'Sub processThickness()
    '    Dim hv As String = hfThickness.Value
    '    If hv.Length <> 0 Then
    '        Dim fromDt As String = hfFrom.Value
    '        Dim toDt As String = hfTo.Value
    '        objController.PopulateWidthForSPM(ddlWidth, fromDt, toDt, ddlGrade.SelectedItem.Text, hv)

    '        Dim filter As String = " 1=1"
    '        If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
    '            filter &= " and GRADE = '" & ddlGrade.SelectedItem.Text & "'"
    '        End If
    '        If hfThickness.Value <> "" Then
    '            filter &= " and THICKNESS in (" & hfThickness.Value & ")"
    '        End If
    '        If hfWidth.Value <> "" Then
    '            filter &= " and WIDTH in (" & hfWidth.Value & ")"
    '        End If
    '        If hfCoil.Value <> "" Then
    '            filter &= " and DAUGHTER_COILID_NUM in ('" & hfCoil.Value.Replace(",", "','") & "')"
    '        End If
    '        DrawChartTop(fromDt, toDt, filter)
    '    End If

    'End Sub
    'Sub processWidth()
    '    Dim hv As String = hfWidth.Value
    '    If hv.Length <> 0 Then
    '        Dim fromDt As String = hfFrom.Value
    '        Dim toDt As String = hfTo.Value

    '        objController.PopulateCoilIdForSPM(ddlCoilId, fromDt, toDt, ddlGrade.SelectedItem.Text, hfThickness.Value, hv)
    '        FilterCheck()
    '    End If

    'End Sub
    'Sub processCoil()
    '    Dim fromDt As String = hfFrom.Value
    '    Dim toDt As String = hfTo.Value
    '    Dim hv As String = hfCoil.Value
    '    FilterCheck()
    'End Sub
    Sub FilterCheck()
        Try

            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            Dim filter As String = " 1=1"
            If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
                filter &= " and GRADE = '" & ddlGrade.SelectedItem.Text & "'"
            End If
            If ddlTdc.SelectedItem.Text.ToLower <> "all" Then
                filter &= " and TDC_No = '" & ddlTdc.SelectedItem.Text & "'"
            End If
            If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                filter &= " and THICKNESS between " & txtFromThickness.Text & " and " & txtToThickness.Text & ""
                'divHolder.Attributes.Add("style", "display:none")
            End If
            If txtWidthFrom.Text <> "" And txtWidthTo.Text <> "" Then
                'filter &= " and WIDTH between " & txtWidthFrom.Text / 1000 & " and " & txtWidthTo.Text / 1000 & ""
                filter &= " and WIDTH between " & txtWidthFrom.Text & " and " & txtWidthTo.Text & ""
            End If
            DrawChartTop(fromDt, toDt, filter)
        Catch ex As Exception

        End Try
    End Sub


    Sub DrawChartTop(ByVal FromDt As String, ByVal ToDt As String, ByVal Filter As String)
        Try

            Dim strfrmDt As String = FromDt
            Dim strToDt As String = ToDt


            Dim dt As DataTable = objController.GetDataForDescriptiveAnalysisCRCW("CRCW_SPM_PROCESS_DATA_COILWISE_BODY", strfrmDt, strToDt, "COIL_STARTDATETIME", Filter)
            If dt.Rows.Count > 0 Then
                'objController.PlotScatterChartForDescAnalysisSPMDSOS(dt, "UTS", "YS", Lit1, "container", "plot1", "UTS", "YS")
                objController.PlotScatterChartForDescAnalysisCRCWDSOS(dt, "ENLONGATION", "YS", Lit2, "container1", "plot2", "ELONGATION", "YS")
                objController.PlotScatterChartForDescAnalysisCRCWDSOS(dt, "ROLLFORCE", "YS", Lit3, "container2", "plot3", "ROLLFORCE", "YS")
                'objController.PlotScatterChartForDescAnalysisSPMOS(dt, "PRM_ELONG", "PRM_FORCE", Lit2, "container2", "plot2", "Elongation", "Force")
            Else
                ' Lit1.Text = ""
                Lit2.Text = ""
                Lit3.Text = ""

            End If



        Catch ex As Exception

        End Try
    End Sub

    Sub FilterCheck1()
        Try

            Dim fromDt As String = hfFrom1.Value
            Dim toDt As String = hfTo1.Value
            Dim filter As String = " 1=1"
            If ddlGrade1.SelectedItem.Text.ToLower <> "all" Then
                filter &= " and GRADE = '" & ddlGrade1.SelectedItem.Text & "'"
            End If
            If ddlTdc1.SelectedItem.Text.ToLower <> "all" Then
                filter &= " and TDC_No = '" & ddlTdc1.SelectedItem.Text & "'"
            End If
            If txtFromThickness1.Text <> "" And txtToThickness1.Text <> "" Then
                filter &= " and THICKNESS between " & txtFromThickness1.Text & " and " & txtToThickness1.Text & ""
                'divHolder.Attributes.Add("style", "display:none")
            End If
            If txtWidthFrom1.Text <> "" And txtWidthTo1.Text <> "" Then
                'filter &= " and WIDTH between " & txtWidthFrom1.Text / 1000 & " and " & txtWidthTo1.Text / 1000 & ""
                filter &= " and WIDTH between " & txtWidthFrom1.Text & " and " & txtWidthTo1.Text & ""
            End If
            DrawChartTop1(fromDt, toDt, filter)
        Catch ex As Exception

        End Try
    End Sub
    Sub DrawChartTop1(ByVal FromDt As String, ByVal ToDt As String, ByVal Filter As String)
        Try

            Dim strfrmDt As String = FromDt
            Dim strToDt As String = ToDt


            Dim dt As DataTable = objController.GetDataForDescriptiveAnalysisCRCW("CRCW_SPM_PROCESS_DATA_COILWISE_BODY", strfrmDt, strToDt, "COIL_STARTDATETIME", Filter)
            If dt.Rows.Count > 0 Then
                If ddlChartType.SelectedItem.Text = "Daywise" Then
                    objController.BoxPlotForDescAnalCRCW(dt, "ROLLFORCE", Lit4, "container4", "plot4", "dataRT", "STDATE", "outRT", "Rollforce", "", "avgRT", "", "", "")
                    objController.BoxPlotForDescAnalCRCW(dt, "ENLONGATION", Lit5, "container5", "plot5", "dataRT5", "STDATE", "outRT5", "Elongation", "", "avgRT5", "", "", "")
                ElseIf ddlChartType.SelectedItem.Text = "Weekwise" Then

                    objController.BoxPlotForDescAnalCRCW_Week(dt, "ROLLFORCE", Lit4, "container4", "plot4", "dataRT", "STDATE2", "outRT", "Rollforce", "", "avgRT", "", "", "")
                    objController.BoxPlotForDescAnalCRCW_Week(dt, "ENLONGATION", Lit5, "container5", "plot5", "dataRT5", "STDATE2", "outRT5", "Elongation", "", "avgRT5", "", "", "")
                Else
                    objController.BoxPlotForDescAnalCRCW_Month(dt, "ROLLFORCE", Lit4, "container4", "plot4", "dataRT", "STDATE1", "outRT", "Rollforce", "", "avgRT", "", "", "")
                    objController.BoxPlotForDescAnalCRCW_Month(dt, "ENLONGATION", Lit5, "container5", "plot5", "dataRT5", "STDATE1", "outRT5", "Elongation", "", "avgRT5", "", "", "")

                End If

                'objController.PlotBoxPlotChartForCGL2(dt1, "CLR_TEST_VALUE", Lit3, "container1", "plot11", "dataA", "CLR_PARAM_MIN", "outlierDataA", ChartTitle, "", "Avg_A", "Pot", 0, 0.4)
                'objController.PlotScatterChartForDescAnalysisSPMDSOS(dt, "UTS", "YS", Lit1, "container", "plot1", "UTS", "YS")
                'objController.PlotScatterChartForDescAnalysisSPMDSOS(dt, "ENLONGATION", "YS", Lit2, "container1", "plot2", "ELONGATION", "YS")
                'objController.PlotScatterChartForDescAnalysisSPMDSOS(dt, "ROLLFORCE", "YS", Lit3, "container2", "plot3", "ROLLFORCE", "YS")
                ''objController.PlotScatterChartForDescAnalysisSPMOS(dt, "PRM_ELONG", "PRM_FORCE", Lit2, "container2", "plot2", "Elongation", "Force")
            Else
                Lit4.Text = ""
                Lit5.Text = ""
                'Lit6.Text = ""

            End If



        Catch ex As Exception

        End Try
    End Sub
    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try

            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            If (hfIsButton.Value = "false") Then
                'If ddlGrade.SelectedIndex > 0 And ddlTdc.SelectedIndex > 0 And ddlThickness.SelectedIndex > 0 Then
                objController.PopulateGradeForCRCW(ddlGrade, dtStart, dtEnd)
                objController.PopulateTdcForCRCW(ddlTdc, dtStart, dtEnd, "")
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForCRCWDetailAnalysis(dtStart, dtEnd, "", "")
                If dt.Rows.Count > 0 AndAlso Not IsDBNull(dt.Rows(0)(0)) Then
                    txtFromThickness.Text = dt.Rows(0)(0)
                    txtToThickness.Text = dt.Rows(0)(1)
                    If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                        dt1 = objController.PopulateWidthForCRCWDetailAnalysis(dtStart, dtEnd, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                        'txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0) * 1000, 0)
                        'txtWidthTo.Text = Math.Round(dt1.Rows(0)(1) * 1000, 0)
                        txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0), 0)
                        txtWidthTo.Text = Math.Round(dt1.Rows(0)(1), 0)
                    End If
                End If
                FilterCheck()
                'End If
            End If
        Catch ex As Exception

        End Try


    End Sub

    
    Protected Sub txtDate1_TextChanged() 'Handles txtDate.TextChanged
        Try

            Dim dtStart As String = hfFrom1.Value
            Dim dtEnd As String = hfTo1.Value
            If (hfIsButton1.Value = "false") Then
                'If ddlGrade.SelectedIndex > 0 And ddlTdc.SelectedIndex > 0 And ddlThickness.SelectedIndex > 0 Then
                objController.PopulateGradeForCRCW(ddlGrade1, dtStart, dtEnd)
                objController.PopulateTdcForCRCW(ddlTdc1, dtStart, dtEnd, "")
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForCRCWDetailAnalysis(dtStart, dtEnd, "", "")
                If dt.Rows.Count > 0 AndAlso Not IsDBNull(dt.Rows(0)(0)) Then
                    txtFromThickness1.Text = dt.Rows(0)(0)
                    txtToThickness1.Text = dt.Rows(0)(1)
                    If txtFromThickness1.Text <> "" And txtToThickness1.Text <> "" Then
                        dt1 = objController.PopulateWidthForCRCWDetailAnalysis(dtStart, dtEnd, ddlGrade1.SelectedItem.Text, ddlTdc1.SelectedItem.Text, txtFromThickness1.Text, txtToThickness1.Text)
                        'txtWidthFrom1.Text = Math.Round(dt1.Rows(0)(0) * 1000, 0)
                        'txtWidthTo1.Text = Math.Round(dt1.Rows(0)(1) * 1000, 0)
                        txtWidthFrom1.Text = Math.Round(dt1.Rows(0)(0), 0)
                        txtWidthTo1.Text = Math.Round(dt1.Rows(0)(1), 0)
                    End If
                End If
                FilterCheck1()
                'End If
            End If
        Catch ex As Exception

        End Try


    End Sub
    Protected Sub ddlGrade_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlGrade.SelectedIndexChanged
        Try

            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value

            If ddlGrade.SelectedItem.Text.ToLower = "all" Then
                hfThickness.Value = ""
                hfWidth.Value = ""
                hfCoil.Value = ""
                objController.PopulateTdcForCRCW(ddlTdc, fromDt, toDt, "")
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForCRCWDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
                txtFromThickness.Text = dt.Rows(0)(0)
                txtToThickness.Text = dt.Rows(0)(1)
                If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                    dt1 = objController.PopulateWidthForCRCWDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                    'txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0) * 1000, 0)
                    'txtWidthTo.Text = Math.Round(dt1.Rows(0)(1) * 1000, 0)
                    txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0), 0)
                    txtWidthTo.Text = Math.Round(dt1.Rows(0)(1), 0)
                End If
            Else
                objController.PopulateTdcForCRCW(ddlTdc, fromDt, toDt, ddlGrade.SelectedItem.Text)
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForCRCWDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
                txtFromThickness.Text = dt.Rows(0)(0)
                txtToThickness.Text = dt.Rows(0)(1)
                If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                    dt1 = objController.PopulateWidthForCRCWDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                    'txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0) * 1000, 0)
                    'txtWidthTo.Text = Math.Round(dt1.Rows(0)(1) * 1000, 0)
                    txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0), 0)
                    txtWidthTo.Text = Math.Round(dt1.Rows(0)(1), 0)
                End If
            End If
            FilterCheck()
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub ddlGrade1_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlGrade1.SelectedIndexChanged
        Try

            Dim fromDt As String = hfFrom1.Value
            Dim toDt As String = hfTo1.Value

            If ddlGrade1.SelectedItem.Text.ToLower = "all" Then
                hfThickness1.Value = ""
                hfWidth1.Value = ""
                hfCoil1.Value = ""
                objController.PopulateTdcForCRCW(ddlTdc1, fromDt, toDt, "")
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForCRCWDetailAnalysis(fromDt, toDt, ddlGrade1.SelectedItem.Text, ddlTdc1.SelectedItem.Text)
                txtFromThickness1.Text = dt.Rows(0)(0)
                txtToThickness1.Text = dt.Rows(0)(1)
                If txtFromThickness1.Text <> "" And txtToThickness1.Text <> "" Then
                    dt1 = objController.PopulateWidthForCRCWDetailAnalysis(fromDt, toDt, ddlGrade1.SelectedItem.Text, ddlTdc1.SelectedItem.Text, txtFromThickness1.Text, txtToThickness1.Text)
                    'txtWidthFrom1.Text = Math.Round(dt1.Rows(0)(0) * 1000, 0)
                    'txtWidthTo1.Text = Math.Round(dt1.Rows(0)(1) * 1000, 0)
                    txtWidthFrom1.Text = Math.Round(dt1.Rows(0)(0), 0)
                    txtWidthTo1.Text = Math.Round(dt1.Rows(0)(1), 0)
                End If
            Else
                objController.PopulateTdcForCRCW(ddlTdc1, fromDt, toDt, ddlGrade1.SelectedItem.Text)
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForCRCWDetailAnalysis(fromDt, toDt, ddlGrade1.SelectedItem.Text, ddlTdc1.SelectedItem.Text)
                txtFromThickness1.Text = dt.Rows(0)(0)
                txtToThickness1.Text = dt.Rows(0)(1)
                If txtFromThickness1.Text <> "" And txtToThickness1.Text <> "" Then
                    dt1 = objController.PopulateWidthForCRCWDetailAnalysis(fromDt, toDt, ddlGrade1.SelectedItem.Text, ddlTdc1.SelectedItem.Text, txtFromThickness1.Text, txtToThickness1.Text)
                    'txtWidthFrom1.Text = Math.Round(dt1.Rows(0)(0) * 1000, 0)
                    'txtWidthTo1.Text = Math.Round(dt1.Rows(0)(1) * 1000, 0)
                    txtWidthFrom1.Text = Math.Round(dt1.Rows(0)(0), 0)
                    txtWidthTo1.Text = Math.Round(dt1.Rows(0)(1), 0)
                End If
            End If
            FilterCheck1()
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub ddlTdc_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlTdc.SelectedIndexChanged
        Try

            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value

            If ddlTdc.SelectedItem.Text.ToLower = "all" Then
                hfThickness.Value = ""
                hfWidth.Value = ""
                hfCoil.Value = ""

                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForCRCWDetailAnalysis(fromDt, toDt, "", "")
                If dt.Rows.Count > 0 AndAlso Not IsDBNull(dt.Rows(0)(0)) Then
                    txtFromThickness.Text = dt.Rows(0)(0)
                    txtToThickness.Text = dt.Rows(0)(1)
                    If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                        dt1 = objController.PopulateWidthForCRCWDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                        'txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0) * 1000, 0)
                        'txtWidthTo.Text = Math.Round(dt1.Rows(0)(1) * 1000, 0)
                        txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0), 0)
                        txtWidthTo.Text = Math.Round(dt1.Rows(0)(1), 0)
                    End If
                End If
                'objController.LoadColumnNameForSPMCoilDetail(clbParamTest, Session("ColumnName"))
                Return
            Else
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForCRCWDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
                txtFromThickness.Text = dt.Rows(0)(0)
                txtToThickness.Text = dt.Rows(0)(1)
                If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                    dt1 = objController.PopulateWidthForCRCWDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                    'txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0) * 1000, 0)
                    'txtWidthTo.Text = Math.Round(dt1.Rows(0)(1) * 1000, 0)
                    txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0), 0)
                    txtWidthTo.Text = Math.Round(dt1.Rows(0)(1), 0)
                End If

            End If
            FilterCheck()
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub ddlTdc1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlTdc1.SelectedIndexChanged
        Try

            Dim fromDt As String = hfFrom1.Value
            Dim toDt As String = hfTo1.Value

            If ddlTdc1.SelectedItem.Text.ToLower = "all" Then
                hfThickness1.Value = ""
                hfWidth1.Value = ""
                hfCoil1.Value = ""

                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForCRCWDetailAnalysis(fromDt, toDt, "", "")
                If dt.Rows.Count > 0 AndAlso Not IsDBNull(dt.Rows(0)(0)) Then
                    txtFromThickness1.Text = dt.Rows(0)(0)
                    txtToThickness1.Text = dt.Rows(0)(1)
                    If txtFromThickness1.Text <> "" And txtToThickness1.Text <> "" Then
                        dt1 = objController.PopulateWidthForCRCWDetailAnalysis(fromDt, toDt, ddlGrade1.SelectedItem.Text, ddlTdc1.SelectedItem.Text, txtFromThickness1.Text, txtToThickness1.Text)
                        'txtWidthFrom1.Text = Math.Round(dt1.Rows(0)(0) * 1000, 0)
                        'txtWidthTo1.Text = Math.Round(dt1.Rows(0)(1) * 1000, 0)
                        txtWidthFrom1.Text = Math.Round(dt1.Rows(0)(0), 0)
                        txtWidthTo1.Text = Math.Round(dt1.Rows(0)(1), 0)
                    End If
                End If
                'objController.LoadColumnNameForSPMCoilDetail(clbParamTest, Session("ColumnName"))
                Return
            Else
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForCRCWDetailAnalysis(fromDt, toDt, ddlGrade1.SelectedItem.Text, ddlTdc1.SelectedItem.Text)
                txtFromThickness1.Text = dt.Rows(0)(0)
                txtToThickness1.Text = dt.Rows(0)(1)
                If txtFromThickness1.Text <> "" And txtToThickness1.Text <> "" Then
                    dt1 = objController.PopulateWidthForCRCWDetailAnalysis(fromDt, toDt, ddlGrade1.SelectedItem.Text, ddlTdc1.SelectedItem.Text, txtFromThickness1.Text, txtToThickness1.Text)
                    'txtWidthFrom1.Text = Math.Round(dt1.Rows(0)(0) * 1000, 0)
                    'txtWidthTo1.Text = Math.Round(dt1.Rows(0)(1) * 1000, 0)
                    txtWidthFrom1.Text = Math.Round(dt1.Rows(0)(0), 0)
                    txtWidthTo1.Text = Math.Round(dt1.Rows(0)(1), 0)
                End If

            End If
            FilterCheck1()
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub txtFromThickness_TextChanged(sender As Object, e As EventArgs) Handles txtFromThickness.TextChanged
        Try
            FilterCheck()
        Catch ex As Exception

        End Try

    End Sub
    Protected Sub txtFromThickness1_TextChanged(sender As Object, e As EventArgs) Handles txtFromThickness1.TextChanged
        Try
            FilterCheck1()
        Catch ex As Exception

        End Try

    End Sub
    Protected Sub txtToThickness_TextChanged(sender As Object, e As EventArgs) Handles txtToThickness.TextChanged
        Try
            FilterCheck()
        Catch ex As Exception

        End Try

    End Sub
    Protected Sub txtToThickness1_TextChanged(sender As Object, e As EventArgs) Handles txtToThickness1.TextChanged
        Try
            FilterCheck1()
        Catch ex As Exception

        End Try

    End Sub
    Protected Sub txtWidthFrom_TextChanged(sender As Object, e As EventArgs) Handles txtWidthFrom.TextChanged
        Try
            FilterCheck()
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub txtWidthFrom1_TextChanged(sender As Object, e As EventArgs) Handles txtWidthFrom1.TextChanged
        Try
            FilterCheck1()
        Catch ex As Exception

        End Try

    End Sub
    Protected Sub txtWidthTo_TextChanged(sender As Object, e As EventArgs) Handles txtWidthTo.TextChanged
        Try
            FilterCheck()
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub txtWidthTo1_TextChanged(sender As Object, e As EventArgs) Handles txtWidthTo1.TextChanged
        Try
            FilterCheck1()
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub ddlChartType_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlChartType.SelectedIndexChanged
        Try
            FilterCheck1()
        Catch ex As Exception

        End Try

    End Sub
End Class
