﻿Imports System.Data
Imports System.IO
Partial Class descriptiveAnalysisSPM_Old
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Dim p As String = Request("__EVENTARGUMENT")
            If (p = "thickness") Then
                processThickness()
            ElseIf p = "coil" Then
                processCoil()
            ElseIf p = "width" Then
                processWidth()

            End If
        End If
        If Not Page.IsPostBack Then
            Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
            Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
            'Dim dtStart As DateTime = DateTime.Now.AddMonths(-6).ToString("yyyy-MM-dd HH:mm")
            Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
            objController.PopulateGradeForSPM(ddlGrade, dtStart, dtEnd)
            objController.PopulateThicknessForSPM(ddlThickness, dtStart, dtEnd, "")
            objController.PopulateWidthForSPM(ddlWidth, dtStart, dtEnd, "", "")
            objController.PopulateCoilIdForSPM(ddlCoilId, dtStart, dtEnd, "", "", "")

            DrawChartTop(dtStart, dtEnd, "")
        End If
    End Sub

    Sub processThickness()
        Dim hv As String = hfThickness.Value
        If hv.Length <> 0 Then
            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            objController.PopulateWidthForSPM(ddlWidth, fromDt, toDt, ddlGrade.SelectedItem.Text, hv)

            Dim filter As String = " 1=1"
            If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
                filter &= " and GRADE = '" & ddlGrade.SelectedItem.Text & "'"
            End If
            If hfThickness.Value <> "" Then
                filter &= " and THICKNESS in (" & hfThickness.Value & ")"
            End If
            If hfWidth.Value <> "" Then
                filter &= " and WIDTH in (" & hfWidth.Value & ")"
            End If
            If hfCoil.Value <> "" Then
                filter &= " and DAUGHTER_COILID_NUM in ('" & hfCoil.Value.Replace(",", "','") & "')"
            End If
            DrawChartTop(fromDt, toDt, filter)
        End If

    End Sub
    Sub processWidth()
        Dim hv As String = hfWidth.Value
        If hv.Length <> 0 Then
            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value

            objController.PopulateCoilIdForSPM(ddlCoilId, fromDt, toDt, ddlGrade.SelectedItem.Text, hfThickness.Value, hv)
            FilterCheck()
        End If

    End Sub
    Sub processCoil()
        Dim fromDt As String = hfFrom.Value
        Dim toDt As String = hfTo.Value
        Dim hv As String = hfCoil.Value
        FilterCheck()
    End Sub
    Sub FilterCheck()
        Dim fromDt As String = hfFrom.Value
        Dim toDt As String = hfTo.Value
        Dim filter As String = " 1=1"
        If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
            filter &= " and GRADE = '" & ddlGrade.SelectedItem.Text & "'"
        End If
        If hfThickness.Value <> "" Then
            filter &= " and THICKNESS in (" & hfThickness.Value & ")"
        End If
        If hfWidth.Value <> "" Then
            filter &= " and WIDTH in (" & hfWidth.Value & ")"
        End If
        If hfCoil.Value <> "" Then
            filter &= " and DAUGHTER_COILID_NUM in ('" & hfCoil.Value.Replace(",", "','") & "')"
        End If
        DrawChartTop(fromDt, toDt, filter)
    End Sub


    Sub DrawChartTop(ByVal FromDt As String, ByVal ToDt As String, ByVal Filter As String)
        Try

            Dim strfrmDt As String = FromDt
            Dim strToDt As String = ToDt


            Dim dt As DataTable = objController.GetDataForDescriptiveAnalysisSPM("CRM_SPM_PROCESS_DATA_COILWISE_BODY", strfrmDt, strToDt, "COIL_STARTDATETIME", Filter)
            If dt.Rows.Count > 0 Then
                objController.PlotScatterChartForDescAnalysisSPMDSOS(dt, "UTS", "YS", Lit1, "container", "plot1", "UTS", "YS")
                objController.PlotScatterChartForDescAnalysisSPMDSOS(dt, "ROLLFORCE_OS", "ROLLFORCE_DS", Lit2, "container1", "plot2", "OS", "DS")
                objController.PlotScatterChartForDescAnalysisSPMDSOS(dt, "TENSION_TR", "TENSION_POS_ENTRY", Lit3, "container2", "plot3", "EXIT", "ENRTY")
                'objController.PlotScatterChartForDescAnalysisSPMOS(dt, "PRM_ELONG", "PRM_FORCE", Lit2, "container2", "plot2", "Elongation", "Force")
            Else
                Lit1.Text = ""
                Lit2.Text = ""
                Lit3.Text = ""

            End If



        Catch ex As Exception

        End Try
    End Sub




    Protected Sub txtDate_TextChanged(sender As Object, e As System.EventArgs) Handles txtDate.TextChanged
        Dim dtStart As String = hfFrom.Value
        Dim dtEnd As String = hfTo.Value
        'If ddlGrade.SelectedIndex > 0 And ddlTdc.SelectedIndex > 0 And ddlThickness.SelectedIndex > 0 Then
        objController.PopulateGradeForSPM(ddlGrade, dtStart, dtEnd)
        objController.PopulateThicknessForSPM(ddlThickness, dtStart, dtEnd, "")
        objController.PopulateWidthForSPM(ddlWidth, dtStart, dtEnd, "", "")
        objController.PopulateCoilIdForSPM(ddlCoilId, dtStart, dtEnd, "", "", "")
        FilterCheck()
        'End If


    End Sub

    Protected Sub ddlGrade_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlGrade.SelectedIndexChanged
        Dim fromDt As String = hfFrom.Value
        Dim toDt As String = hfTo.Value

        If ddlGrade.SelectedItem.Text.ToLower = "all" Then
            hfThickness.Value = ""
            hfWidth.Value = ""
            hfCoil.Value = ""
            objController.PopulateThicknessForSPM(ddlThickness, fromDt, toDt, "")
            objController.PopulateWidthForSPM(ddlWidth, fromDt, toDt, "", "")
            objController.PopulateCoilIdForSPM(ddlCoilId, fromDt, toDt, "", "", "")
        Else
            objController.PopulateThicknessForSPM(ddlThickness, fromDt, toDt, ddlGrade.SelectedItem.Text)
        End If
        FilterCheck()

    End Sub


End Class
