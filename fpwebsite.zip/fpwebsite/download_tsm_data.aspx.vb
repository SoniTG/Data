﻿
Imports System.Data
Imports System.IO

Partial Class download_tsm_data
    Inherits System.Web.UI.Page
    Dim objDataHandler As New DataHandler
    Dim objController As New Controller
    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Private Sub btnDownload_Click(sender As Object, e As EventArgs) Handles btnDownload.Click
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select * from [TSM_SMS].[dbo].[V_SLAB_C2] where [CUT_TIME] between '" & hfFrom.Value & "' and '" & hfTo.Value & "' order by [CUT_TIME]").Tables(0)

        If dt.Rows.Count > 0 Then
            Dim filename = "data_" + DateTime.Now.ToString("yyyy-MM-dd") + ".xlsx"
            Response.Clear()
            Response.ClearContent()
            Response.ClearHeaders()
            Response.Buffer = True
            Response.ContentEncoding = System.Text.Encoding.UTF8
            Response.Cache.SetCacheability(HttpCacheability.NoCache)
            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            Response.AddHeader("content-disposition", "attachment;filename=" + filename)

            Using pck As New OfficeOpenXml.ExcelPackage()
                Dim ws As OfficeOpenXml.ExcelWorksheet = pck.Workbook.Worksheets.Add("Data")
                ws.Cells("A1").LoadFromDataTable(dt, True)
                ws.Cells.AutoFitColumns()
                Dim ms = New System.IO.MemoryStream()
                pck.SaveAs(ms)
                ms.WriteTo(Response.OutputStream)
            End Using


            Response.Flush()
            Response.End()

        Else
            UserMsgBoxWarning("No data for the selected period")

        End If
    End Sub

    Private Sub download_tsm_data_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Session("pagehit") = objController.SaveAndRetrievePageHits("", Path.GetFileName(Request.Path))
            hfFrom.Value = DateTime.Now.AddDays(-6).ToString("yyyy-MM-dd HH:mm:ss")
            hfTo.Value = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End If
    End Sub
End Class
