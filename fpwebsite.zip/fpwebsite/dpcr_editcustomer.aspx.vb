﻿Imports System.IO

Partial Class dpcr_editcustomer
    Inherits System.Web.UI.Page
    Dim objController As New Controller

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Session("pagehit") = objController.SaveAndRetrievePageHits(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), Path.GetFileName(Request.Path))
            objController.PopulateMarketSegment(ddl2, "", "", True)
            objController.PopulateZone(ddl1, "", "")
            objController.LoadData(dgv, ddl2.SelectedItem.Text, ddl1.SelectedItem.Text, txtCustomer.Text)
        End If
        If dgv.Rows.Count > 0 Then
            dgv.UseAccessibleHeader = True
            dgv.HeaderRow.TableSection = TableRowSection.TableHeader
        End If
    End Sub

    Protected Sub btnGo_Click(sender As Object, e As System.EventArgs) Handles btnGo.Click
        objController.LoadData(dgv, ddl2.SelectedItem.Text, ddl1.SelectedItem.Text, txtCustomer.Text)
    End Sub

    Protected Sub dgv_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles dgv.RowCommand
        Dim buttontxt As String = CType(e.CommandSource, LinkButton).CommandArgument

        If buttontxt.ToLower = "delete" Then

            Dim row As GridViewRow = CType(e.CommandSource, LinkButton).NamingContainer
            Dim idx2 = row.RowIndex
            Dim n2 As String = CType(dgv.Rows(idx2).Cells(2).FindControl("txtZone"), TextBox).Text
            ' ((TextBox)(Gridview1.rows[idx].cells[3].controls[0])).Text;
            Dim cname2 As String = dgv.Rows(idx2).Cells(0).Text.Replace("&amp;", "&")
            Dim calias2 As String = dgv.Rows(idx2).Cells(1).Text.Replace("&amp;", "&")
            Dim priority1 As String = CType(dgv.Rows(idx2).Cells(3).FindControl("txtPriority"), TextBox).Text
            Dim market2 As String = ddl2.SelectedItem.Text


            'delete query
            Dim query2 As String = "  delete from [T_DPCR_CUST_PRIORITY] where TDC_ZONE='" & n2 & "'and  TDC_MARKET_SEGMENT='" & market2 & "'  AND TDC_CUSTOMER='" & cname2 & "' AND TDC_CUSTOMER_ALIAS='" & calias2 & "' AND TDC_PRIORITY_NUM ='" & priority1 & "' "

            objController.deleteZone(query2)
        ElseIf buttontxt.ToLower = "priority" Then
            Dim row As GridViewRow = CType(e.CommandSource, LinkButton).NamingContainer
            Dim idx2 = row.RowIndex
            Dim n2 As String = CType(dgv.Rows(idx2).Cells(2).FindControl("txtZone"), TextBox).Text
            ' ((TextBox)(Gridview1.rows[idx].cells[3].controls[0])).Text;
            Dim cname2 As String = dgv.Rows(idx2).Cells(0).Text.Replace("&amp;", "&")
            Dim calias2 As String = dgv.Rows(idx2).Cells(1).Text.Replace("&amp;", "&")
            Dim priority1 As String = CType(dgv.Rows(idx2).Cells(3).FindControl("txtPriority"), TextBox).Text
            Dim market2 As String = ddl2.SelectedItem.Text
            'Update query
            Dim query1 As String = "  UPDATE [T_DPCR_CUST_PRIORITY] SET TDC_PRIORITY_NUM='" & priority1 & "' WHERE TDC_MARKET_SEGMENT='" & market2 & "'  AND TDC_CUSTOMER='" & cname2 & "' AND TDC_CUSTOMER_ALIAS='" & calias2 & "' AND TDC_ZONE ='" & n2 & "' "

            objController.UpdateZone(query1)
        ElseIf buttontxt.ToLower = "zone" Then
            Dim row As GridViewRow = CType(e.CommandSource, LinkButton).NamingContainer
            Dim idx1 = row.RowIndex
            Dim n1 As String = CType(dgv.Rows(idx1).Cells(2).FindControl("txtZone"), TextBox).Text
            ' ((TextBox)(Gridview1.rows[idx].cells[3].controls[0])).Text;
            Dim cname1 As String = dgv.Rows(idx1).Cells(0).Text
            Dim calias1 As String = dgv.Rows(idx1).Cells(1).Text
            Dim priority As String = CType(dgv.Rows(idx1).Cells(3).FindControl("txtPriority"), TextBox).Text
            Dim market1 As String = ddl2.SelectedItem.Text


            'Update query
            Dim query1 As String = "  UPDATE [T_DPCR_CUST_PRIORITY] SET TDC_ZONE='" & n1 & "' WHERE TDC_MARKET_SEGMENT='" & market1 & "'  AND TDC_CUSTOMER='" & cname1 & "' AND TDC_CUSTOMER_ALIAS='" & calias1 & "' AND TDC_PRIORITY_NUM ='" & priority & "' "

            objController.UpdateZone(query1)

        End If



        objController.LoadData(dgv, ddl2.SelectedItem.Text, ddl1.SelectedItem.Text, txtCustomer.Text)
    End Sub

    Protected Sub btncancle_Click(sender As Object, e As System.EventArgs) Handles btncancle.Click
        tblData.Style("Display") = "block"
        Panel1.Style("Display") = "none"
    End Sub

    Protected Sub btnsave_Click(sender As Object, e As System.EventArgs) Handles btnsave.Click
        Dim ms As String = ddlMarket.SelectedItem.Text
        Dim zn As String = ddlZone.SelectedItem.Text
        Dim cname As String = txtCustomerName.Text

        Dim calias As String = txtCustomerAlias.Text
        Dim pr As String = txtpriority.Text




        objController.InsertCustomer(ms, zn, cname, calias, pr)


        tblData.Style("Display") = "block"
        Panel1.Style("Display") = "none"


        objController.LoadData(dgv, ddl2.SelectedItem.Text, ddl1.SelectedItem.Text, txtCustomer.Text)
    End Sub

    Protected Sub btnAdd_Click(sender As Object, e As System.EventArgs) Handles btnAdd.Click
        tblData.Style("Display") = "none"
        Panel1.Style("Display") = "block"
        objController.PopulateMarketSegment(ddlMarket, "", "", True)
        objController.PopulateZone(ddlZone, "", "")
        ddlZone.Items.RemoveAt(0)
    End Sub
End Class
