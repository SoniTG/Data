﻿Imports System.Data
Imports System.IO
Imports iTextSharp.text
Imports iTextSharp.text.html.simpleparser
Imports iTextSharp.text.pdf
Imports iTextSharp.tool.xml
Imports System.Net
Partial Class dpcr_viz
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Session("pagehit") = objController.SaveAndRetrievePageHits(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), Path.GetFileName(Request.Path))
            objController.PopulateZone(ddlv1, "", "")
            
            objController.PopulateMarketSegment(ddlv2, "", "", True)
            objController.PopulateDetectionPlant(ddlv4, "", "", True)
            If ddlv4.Items.Count > 0 Then
                ddlv4.Items.Insert(0, "All")
                ddlv4.SelectedIndex = 0
            End If
            objController.PopulateOriginPlant(ddlv3, "", "", True)
            If ddlv3.Items.Count > 0 Then
                ddlv3.Items.Insert(0, "All")
                ddlv3.SelectedIndex = 0
            End If
            objController.PopulateProductSegment(ddl1v1, "", "", True)
            objController.PopulateProductSegment(ddl1v4, "", "", True)
            objController.PopulateProductSegment(ddl1v3, "", "", True)
            If ddl1v4.Items.Count > 0 Then
                ddl1v4.Items.Insert(0, "All")
                ddl1v4.SelectedIndex = 0
                ddl1v3.Items.Insert(0, "All")
                ddl1v3.SelectedIndex = 0
                ddl1v1.Items.Insert(0, "All")
                ddl1v1.SelectedIndex = 0
            End If
        End If
        If tblData4.Rows.Count > 0 Then
            tblData4.UseAccessibleHeader = True
            tblData4.HeaderRow.TableSection = TableRowSection.TableHeader
        End If
        If tblData1.Rows.Count > 0 Then
            tblData1.UseAccessibleHeader = True
            tblData1.HeaderRow.TableSection = TableRowSection.TableHeader
        End If
        If tblData2.Rows.Count > 0 Then
            tblData2.UseAccessibleHeader = True
            tblData2.HeaderRow.TableSection = TableRowSection.TableHeader
        End If
        If tblData3.Rows.Count > 0 Then
            tblData3.UseAccessibleHeader = True
            tblData3.HeaderRow.TableSection = TableRowSection.TableHeader
        End If
    End Sub

    Protected Sub btnGo1_Click(sender As Object, e As EventArgs) Handles btnGo1.Click
        Dim dt As DataTable = objController.DPCRViz1(hfFrom1.Value, hfTo1.Value, ddlv1.SelectedItem.Text, ddl1v1.SelectedItem.Text)
        tblData1.DataSource = dt
        tblData1.DataBind()
        tblData1.ShowHeaderWhenEmpty = True
        If tblData1.Rows.Count > 0 Then
            tblData1.UseAccessibleHeader = True
            tblData1.HeaderRow.TableSection = TableRowSection.TableHeader
        End If

    End Sub
    Protected Sub btnGo2_Click(sender As Object, e As EventArgs) Handles btnGo2.Click
        Dim dt As DataTable = objController.DPCRViz2(hfFrom2.Value, hfTo2.Value, ddlv2.SelectedItem.Text)
        tblData2.DataSource = dt
        tblData2.DataBind()
        tblData2.ShowHeaderWhenEmpty = True
        If tblData2.Rows.Count > 0 Then
            tblData2.UseAccessibleHeader = True
            tblData2.HeaderRow.TableSection = TableRowSection.TableHeader
        End If

    End Sub
    Protected Sub btnGo3_Click(sender As Object, e As EventArgs) Handles btnGo3.Click
        Dim dt As DataTable = objController.DPCRViz3(hfFrom3.Value, hfTo3.Value, ddlv3.SelectedItem.Text, ddl1v3.SelectedItem.Text)
        tblData3.DataSource = dt
        tblData3.DataBind()
        tblData3.ShowHeaderWhenEmpty = True
        If tblData3.Rows.Count > 0 Then
            tblData3.UseAccessibleHeader = True
            tblData3.HeaderRow.TableSection = TableRowSection.TableHeader
        End If
       
    End Sub
    Protected Sub btnGo4_Click(sender As Object, e As EventArgs) Handles btnGo4.Click
        Dim dt As DataTable = objController.DPCRViz4(hfFrom4.Value, hfTo4.Value, ddlv4.SelectedItem.Text, ddl1v4.SelectedItem.Text)
        tblData4.DataSource = dt
        tblData4.DataBind()
        tblData4.ShowHeaderWhenEmpty = True
        If tblData4.Rows.Count > 0 Then
            tblData4.UseAccessibleHeader = True
            tblData4.HeaderRow.TableSection = TableRowSection.TableHeader
        End If
       
    End Sub

    Protected Sub tblData4_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles tblData4.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim delim As String() = New String(0) {"Sev."}
            Dim str As String = ""
            Dim issue As String = e.Row.Cells(e.Row.Cells.Count - 1).Text
            Dim arr() As String = issue.Split(delim, StringSplitOptions.None)
            If arr.Length > 1 Then
                str = "Sev. " & arr(1)
            End If
            e.Row.Cells(e.Row.Cells.Count - 1).Text = str
        End If
    End Sub

    Protected Sub tblData3_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles tblData3.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim delim As String() = New String(0) {"Sev."}
            Dim str As String = ""
            Dim issue As String = e.Row.Cells(e.Row.Cells.Count - 1).Text
            Dim arr() As String = issue.Split(delim, StringSplitOptions.None)
            If arr.Length > 1 Then
                str = "Sev. " & arr(1)
            End If
            e.Row.Cells(e.Row.Cells.Count - 1).Text = str
        End If
    End Sub

End Class
