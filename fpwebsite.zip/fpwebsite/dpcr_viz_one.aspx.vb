﻿Imports System.Data
Imports System.IO

Partial Class dpcr_viz_one
    Inherits System.Web.UI.Page
    Dim objController As New Controller

    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        'Response.Write(Session("LoginTime"))
        ' Response.Write(Path.GetFileName(Request.Path))
        If Not Page.IsPostBack Then
            Session("pagehit") = objController.SaveAndRetrievePageHits(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), Path.GetFileName(Request.Path))
            objController.PopulateZone(ddl1, "", "")
            objController.PopulateMarketSegment(ddl2, "", "", True)
            If ddl2.Items.Count > 0 Then
                ddl2.Items.Insert(0, "All")
                ddl2.SelectedIndex = 0
            End If
            objController.PopulateDPCRCustomer(ddl3)

            objController.PopulateProductSegment(ddl4, "", "", True)
            ddl4.Items.Insert(0, "All")
            ddl4.SelectedIndex = 0

            objController.PopulateOriginPlant(ddl5, "", "", True)
            ddl5.Items.Insert(0, "All")
            ddl5.SelectedIndex = 0

            objController.PopulateDetectionPlant(ddl6, "", "", True)
            ddl6.Items.Insert(0, "All")
            ddl6.SelectedIndex = 0

            objController.PopulateDPCRDefect(ddl7)

            objController.PopulateDPCR_Customer_Status(ddl8, "", "", True)
            ddl8.Items.Insert(0, "ALL")
            ddl8.SelectedIndex = 0

            objController.PopulateInvestigator_Name(ddl9, "", "", True)
            ddl9.Items.Insert(0, "ALL")
            ddl9.SelectedIndex = 0


            objController.PopulateRequester_Name(ddl10, "", "", True)
            ddl10.Items.Insert(0, "ALL")
            ddl10.SelectedIndex = 0


            loadData()


        End If
        If dgv.Rows.Count > 0 Then
            dgv.UseAccessibleHeader = True
            dgv.HeaderRow.TableSection = TableRowSection.TableHeader
        End If
    End Sub

    Sub loadData()
        Dim stDate As String = hfFrom.Value
        Dim enDate As String = hfTo.Value
        If stDate = "" Then
            stDate = DateTime.Now.AddDays(-10).ToString("yyyy-MM-dd")
            enDate = DateTime.Now.ToString("yyy-MM-dd")
        End If
        Dim filter As String = ""
        filter = " and tdd_posting_date between '" & stDate & "' and '" & enDate & "'"
        If ddl1.SelectedIndex > 0 Then
            filter &= " and tdd_zone='" & ddl1.SelectedItem.Text & "'"
        End If
        If ddl2.SelectedIndex > 0 Then
            filter &= " and tdd_market_segment='" & ddl2.SelectedItem.Text & "'"
        End If
        If ddl3.SelectedIndex > 0 Then
            filter &= " and tdc_customer_alias='" & ddl3.SelectedItem.Text & "'"
        End If
        If ddl4.SelectedIndex > 0 Then
            filter &= " and tdd_product_segment='" & ddl4.SelectedItem.Text & "'"
        End If
        If ddl5.SelectedIndex > 0 Then
            filter &= " and tdd_plant_name='" & ddl5.SelectedItem.Text & "'"
        End If
        If ddl6.SelectedIndex > 0 Then
            filter &= " and tdd_detection_plant='" & ddl6.SelectedItem.Text & "'"
        End If
        If ddl7.SelectedIndex > 0 Then
            'filter &= " and tdd_defect='" & ddl7.SelectedItem.Text & "'"
            filter &= " and tdd_defect in (SELECT DDC_DEFECT FROM T_DPCR_DEFECT_CLUBBING WHERE DDC_DEFECT_CLUB='" & ddl7.SelectedItem.Text & "')"
            'filter &= " and ddc_defect_club ='" & ddl7.SelectedItem.Text & "'"
        End If
        If ddl8.SelectedIndex > 0 Then
            filter &= " and TDD_PRIORITY_NUM='" & ddl8.SelectedItem.Text & "'"
        End If
        If ddl9.SelectedIndex > 0 Then
            filter &= " and TDD_WEEK_NO='" & ddl9.SelectedItem.Text & "'"
        End If
        If ddl10.SelectedIndex > 0 Then
            filter &= " and TDD_REMARKS='" & ddl10.SelectedItem.Text & "'"
        End If
        Dim dt As DataTable = objController.GetDPCRVizOne(filter).Tables(0)

        Dim flippedTable As New DataTable
        flippedTable.Columns.Add("#DPCR", GetType(String))

        For r As Integer = 0 To dt.Rows.Count - 1
            flippedTable.Columns.Add(dt.Rows(r)(0), GetType(String))
        Next
        'While CDate(stDate) <= CDate(enDate)
        '    flippedTable.Columns.Add(CDate(stDate), GetType(String))
        '    stDate = CDate(stDate).AddDays(1)
        'End While

        For c As Integer = 1 To dt.Columns.Count - 1
            Dim dr As DataRow = flippedTable.NewRow
            dr(0) = dt.Columns(c).ColumnName
            flippedTable.Rows.Add(dr)
        Next

        For r As Integer = 0 To dt.Rows.Count - 1
            Dim k As Integer = 0
            For c As Integer = 1 To dt.Columns.Count - 1
                flippedTable.Rows(k)(dt.Rows(r)(0)) = dt.Rows(r)(c)
                k += 1
            Next

        Next


        'Dim dr1 As DataRow = flippedTable.NewRow
        'dr1.Item(0) = "Severity"
        'flippedTable.Rows.Add(dr1)
        'Dim dr2 As DataRow = flippedTable.NewRow
        'dr2.Item(0) = "Severity"
        'flippedTable.Rows.InsertAt(dr2, 10)
        'Dim dr3 As DataRow = flippedTable.NewRow
        'dr3.Item(0) = "Severity"
        'flippedTable.Rows.InsertAt(dr3, 5)


        dgv.DataSource = flippedTable
        dgv.DataBind()
        dgv.ShowHeaderWhenEmpty = True
        If dgv.Rows.Count > 0 Then
            dgv.UseAccessibleHeader = True
            dgv.HeaderRow.TableSection = TableRowSection.TableHeader
        End If


        If flippedTable.Rows.Count > 0 Then
            Try
                dgv.Width = New Unit(Convert.ToDouble(flippedTable.Columns.Count) * 180.0)
            Catch ex As Exception
                dgv.Width = 180 'New Unit(Double.NaN) '350 'flippedTable.Columns.Count * 180
            End Try

            For c As Integer = 0 To flippedTable.Columns.Count - 1
                dgv.Rows(0).Cells(c).Width = New Unit(180, UnitType.Pixel)
            Next
            'dgv.Rows(0).Cells(0).Width = 350
        End If



    End Sub

   

    Protected Sub btnGo_Click(sender As Object, e As System.EventArgs) Handles btnGo.Click
        loadData()
    End Sub

    Protected Sub dgv_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles dgv.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            If e.Row.Cells(0).Text = "Severity" Then
                e.Row.Cells(0).ForeColor = Drawing.Color.Red
            End If
            For c = 1 To e.Row.Cells.Count - 1
                Dim txt As String = ""
                Dim t() As String = e.Row.Cells(c).Text.Split(";")
                For j As Integer = 0 To UBound(t)
                    If t(j).Replace("&nbsp;", "").Trim.Length > 0 Then
                        txt &= ";" & t(j).Trim
                    End If
                Next
                ' txt = txt.Replace("&nbsp;", "")
                If txt.Length = 0 Then
                    txt = ";"
                End If
                If txt.Substring(1) = "&nbsp" Then
                    e.Row.Cells(c).Text = ""
                Else
                    If e.Row.RowIndex >= 1 Then
                        e.Row.Cells(c).Text = "-" & txt.Substring(1).Replace(";", "<br/>-")
                    Else
                        e.Row.Cells(c).Text = "" & txt.Substring(1).Replace(";", "")
                    End If

                    'If e.Row.Cells(c).Text.Contains("; Sev.") Then
                    '    e.Row.Cells(c).BackColor = Drawing.Color.Azure
                    'End If
                End If



            Next

        End If
    End Sub

    Protected Sub ddl1_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddl1.SelectedIndexChanged
        objController.PopulateDPCRCustomer(ddl3, ddl1.SelectedItem.Text, ddl2.SelectedItem.Text)
    End Sub

    Protected Sub ddl2_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddl2.SelectedIndexChanged
        objController.PopulateDPCRCustomer(ddl3, ddl1.SelectedItem.Text, ddl2.SelectedItem.Text)
    End Sub
End Class
