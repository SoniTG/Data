﻿Imports System.Data
Imports System.IO

Partial Class entryscreen
    Inherits System.Web.UI.Page

    Dim objdatahandler As New DataHandler
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Sub UserMsgBox(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub

    Private Sub btnLoginSave_Click(sender As Object, e As EventArgs) Handles btnLoginSave.Click
        Try

            If txtUsername.Text.Trim() IsNot "" Then

                If txtPassword.Text.Trim() = "" Then
                    ' UserMsgBoxWarning("Enter password.")
                    UserMsgBoxError("Enter password.")
                    txtPassword.Focus()
                Else
                    If (txtUsername.Text = "152815" And txtPassword.Text = "152815") Or (txtUsername.Text.ToLower.Trim = "crmqa" And txtPassword.Text.ToLower.Trim = "crmqa") Then
                        btnSave_Click()
                        txtUsername.Text = ""
                        txtPassword.Text = ""
                        ClearFields()
                        PopulateGrid()
                        UserMsgBox("Saved successfully")
                    Else

                        txtUsername.Text = ""
                        txtPassword.Text = ""
                        ' UserMsgBoxWarning("Incorrect login details.")
                        UserMsgBoxError("Incorrect login details.")
                        Exit Sub
                    End If
                End If
            Else
                '  UserMsgBoxWarning("Enter username.")
                UserMsgBoxError("Enter username.")
                txtUsername.Focus()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnSave_Click()
        Dim eDate As String = txtDate.Text
        Dim ym As String = CDate(eDate).ToString("yyyy-MM")
        Dim d As Integer = CDate(eDate).ToString("dd")
        Dim shift As String
        Dim area As String
        If rbCGL1.Checked Then
            area = "CGL1"
        ElseIf rbCGL2.Checked Then
            area = "CGL2"
        End If
        Dim dblDrossGen, dblAshGen, dblRecRecy, dblSentRecy, dblZnSap As Double
        dblAshGen = 0.0 : dblDrossGen = 0.0 : dblSentRecy = 0.0 : dblRecRecy = 0.0 : dblZnSap = 0.0
        If IsNumeric(txtash.Text) Then dblAshGen = txtash.Text
        If IsNumeric(txtdross.Text) Then dblDrossGen = txtdross.Text
        If IsNumeric(txtrecdpost.Text) Then dblRecRecy = txtrecdpost.Text
        If IsNumeric(txtsent.Text) Then dblSentRecy = txtsent.Text
        If IsNumeric(txtznsap.Text) Then dblZnSap = txtznsap.Text
        If rbDay.Checked = True Then
            objdatahandler.RunSimpleQuery("insert into [FP_PROCESS_DATA].[dbo].[Zinc_Details] values('" & ym & "'," & d & ",NULL,'" & txtash.ToolTip.ToString & "','" & area & "'," & dblAshGen & ",getdate())")
            objdatahandler.RunSimpleQuery("insert into [FP_PROCESS_DATA].[dbo].[Zinc_Details] values('" & ym & "'," & d & ",NULL,'" & txtdross.ToolTip.ToString & "','" & area & "'," & dblDrossGen & ",getdate())")
            objdatahandler.RunSimpleQuery("insert into [FP_PROCESS_DATA].[dbo].[Zinc_Details] values('" & ym & "'," & d & ",NULL,'" & txtrecdpost.ToolTip.ToString & "','" & area & "'," & dblRecRecy & ",getdate())")
            objdatahandler.RunSimpleQuery("insert into [FP_PROCESS_DATA].[dbo].[Zinc_Details] values('" & ym & "'," & d & ",NULL,'" & txtsent.ToolTip.ToString & "','" & area & "'," & dblSentRecy & ",getdate())")
            objdatahandler.RunSimpleQuery("insert into [FP_PROCESS_DATA].[dbo].[Zinc_Details] values('" & ym & "'," & d & ",NULL,'" & txtznsap.ToolTip.ToString & "','" & area & "'," & dblZnSap & ",getdate())")
        ElseIf rbMonth.Checked = True Then
            d = 1
            objdatahandler.RunSimpleQuery("insert into [FP_PROCESS_DATA].[dbo].[Zinc_Details] values('" & ym & "'," & d & ",NULL,'" & txtash.ToolTip.ToString & "','" & area & "'," & dblAshGen & ",getdate())")
            objdatahandler.RunSimpleQuery("insert into [FP_PROCESS_DATA].[dbo].[Zinc_Details] values('" & ym & "'," & d & ",NULL,'" & txtdross.ToolTip.ToString & "','" & area & "'," & dblDrossGen & ",getdate())")
            objdatahandler.RunSimpleQuery("insert into [FP_PROCESS_DATA].[dbo].[Zinc_Details] values('" & ym & "'," & d & ",NULL,'" & txtrecdpost.ToolTip.ToString & "','" & area & "'," & dblRecRecy & ",getdate())")
            objdatahandler.RunSimpleQuery("insert into [FP_PROCESS_DATA].[dbo].[Zinc_Details] values('" & ym & "'," & d & ",NULL,'" & txtsent.ToolTip.ToString & "','" & area & "'," & dblSentRecy & ",getdate())")
            objdatahandler.RunSimpleQuery("insert into [FP_PROCESS_DATA].[dbo].[Zinc_Details] values('" & ym & "'," & d & ",NULL,'" & txtznsap.ToolTip.ToString & "','" & area & "'," & dblZnSap & ",getdate())")
        ElseIf rbShift.Checked = True Then
            shift = cbShift.Value
            objdatahandler.RunSimpleQuery("insert into [FP_PROCESS_DATA].[dbo].[Zinc_Details] values('" & ym & "'," & d & ",'" & shift & "','" & txtash.ToolTip.ToString & "','" & area & "'," & dblAshGen & ",getdate())")
            objdatahandler.RunSimpleQuery("insert into [FP_PROCESS_DATA].[dbo].[Zinc_Details] values('" & ym & "'," & d & ",'" & shift & "','" & txtdross.ToolTip.ToString & "','" & area & "'," & dblDrossGen & ",getdate())")
            objdatahandler.RunSimpleQuery("insert into [FP_PROCESS_DATA].[dbo].[Zinc_Details] values('" & ym & "'," & d & ",'" & shift & "','" & txtrecdpost.ToolTip.ToString & "','" & area & "'," & dblRecRecy & ",getdate())")
            objdatahandler.RunSimpleQuery("insert into [FP_PROCESS_DATA].[dbo].[Zinc_Details] values('" & ym & "'," & d & ",'" & shift & "','" & txtsent.ToolTip.ToString & "','" & area & "'," & dblSentRecy & ",getdate())")
            objdatahandler.RunSimpleQuery("insert into [FP_PROCESS_DATA].[dbo].[Zinc_Details] values('" & ym & "'," & d & ",'" & shift & "','" & txtznsap.ToolTip.ToString & "','" & area & "'," & dblZnSap & ",getdate())")
        End If
    End Sub


    Sub PopulateGrid()
        Dim dt As DataTable = objdatahandler.GetDataSetFromQuery("select * from  (select Year_Month,Date,Shift,Parameter,Area,Value from [FP_PROCESS_DATA].[dbo].[Zinc_Details] where Year_month >= '" & DateTime.Now.AddMonths(-3).ToString("yyyy-MM") & "' ) t1 pivot (sum(Value) for Parameter in ([Ash Generated (Tons)],[Dross Generated (Tons)],[Sent for Recycling (Tons)],[Received post Recycling (Tons)],[Zn-SAP(tons)])) as PT").Tables(0)
        gvCoilData1.DataSource = dt
        gvCoilData1.DataBind()
    End Sub

    Sub ClearFields()
        txtash.Text = ""
        txtdross.Text = ""
        txtrecdpost.Text = ""
        txtsent.Text = ""
        txtznsap.Text = ""
    End Sub

    Protected Sub rbDay_CheckedChanged(sender As Object, e As System.EventArgs) Handles rbDay.CheckedChanged, rbMonth.CheckedChanged, rbShift.CheckedChanged
        If rbDay.Checked = True Then
            cbShift.Disabled = True
        ElseIf rbMonth.Checked = True Then
            cbShift.Disabled = True
        ElseIf rbShift.Checked = True Then
            cbShift.Disabled = False
        End If
    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
            PopulateGrid()
        End If
    End Sub
End Class
