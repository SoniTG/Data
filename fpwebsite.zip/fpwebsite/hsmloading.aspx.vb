﻿Imports System.Data
Imports System.IO
Partial Class hsmloading
    Inherits System.Web.UI.Page
    Dim objcontroller As New Controller
    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub

    Private Sub hsmloading_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Session("pagehit") = New Controller().SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
            Dim dtStart As String = DateTime.Now.AddMinutes(-30).ToString("yyyy-MM-dd HH:mm:ss") ' "2018-11-06 16:15:18"
            Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") ' "2018-11-06 16:45:13"   

            DrawChart(dtStart, dtEnd)
           
        End If
    End Sub

    Sub DrawChart(ByVal startdate As String, ByVal endate As String)
        Dim dt1 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F1DT_M22")
        If dt1.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt1, "Logdatetime", "MaxValue", Lit1, "container1", "plot1", "Max Value")
            Label1.Visible = True
        Else
            Lit1.Text = ""
        End If
        Dim dt2 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F1DT_M23")
        If dt2.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt2, "Logdatetime", "MaxValue", Lit2, "container2", "plot2", "Max Value")
            Label2.Visible = True
        Else
            Lit2.Text = ""
        End If
        Dim dt3 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F1DT_M24")
        If dt3.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt3, "Logdatetime", "MaxValue", Lit3, "container3", "plot3", "Max Value")
            Label3.Visible = True
        Else
            Lit3.Text = ""
        End If
        Dim dt4 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F1DT_M25")
        If dt4.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt4, "Logdatetime", "MaxValue", Lit4, "container4", "plot4", "Max Value")
            Label4.Visible = True
        Else
            Lit4.Text = ""
        End If
        Dim dt5 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F1DT_M26")
        If dt5.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt5, "Logdatetime", "MaxValue", Lit5, "container5", "plot5", "Max Value")
            Label5.Visible = True
        Else
            Lit5.Text = ""
        End If
        Dim dt6 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F1DT_M27")
        If dt6.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt6, "Logdatetime", "MaxValue", Lit6, "container6", "plot6", "Max Value")
            Label6.Visible = True
        Else
            Lit6.Text = ""
        End If
        Dim dt7 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F1DT_M28")
        If dt7.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt7, "Logdatetime", "MaxValue", Lit7, "container7", "plot7", "Max Value")
            Label7.Visible = True
        Else
            Lit7.Text = ""
        End If
        Dim dt8 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F1DT_M29")
        If dt8.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt8, "Logdatetime", "MaxValue", Lit8, "container8", "plot8", "Max Value")
            Label8.Visible = True
        Else
            Lit8.Text = ""
        End If
        Dim dt9 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F1DT_M30")
        If dt9.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt9, "Logdatetime", "MaxValue", Lit9, "container9", "plot9", "Max Value")
            Label9.Visible = True
        Else
            Lit9.Text = ""
        End If
        Dim dt10 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F1DT_M31")
        If dt10.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt10, "Logdatetime", "MaxValue", Lit10, "container10", "plot10", "Max Value")
            Label10.Visible = True
        Else
            Lit10.Text = ""
        End If
        Dim dt11 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F1DT_M32")
        If dt11.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt11, "Logdatetime", "MaxValue", Lit11, "container11", "plot11", "Max Value")
            Label11.Visible = True
        Else
            Lit11.Text = ""
        End If
        Dim dt12 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F1DT_M33")
        If dt12.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt12, "Logdatetime", "MaxValue", Lit12, "container12", "plot12", "Max Value")
            Label12.Visible = True
        Else
            Lit12.Text = ""
        End If
        Dim dt13 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F1DT_M34")
        If dt13.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt13, "Logdatetime", "MaxValue", Lit13, "container13", "plot13", "Max Value")
            Label13.Visible = True
        Else
            Lit13.Text = ""
        End If
        Dim dt14 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F1DT_M35")
        If dt14.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt14, "Logdatetime", "MaxValue", Lit14, "container14", "plot14", "Max Value")
            Label14.Visible = True
        Else
            Lit14.Text = ""
        End If
        Dim dt15 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F1DT_M36")
        If dt15.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt15, "Logdatetime", "MaxValue", Lit15, "container15", "plot15", "Max Value")
            Label15.Visible = True
        Else
            Lit15.Text = ""
        End If
        Dim dt16 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F1DT_M37")
        If dt16.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt16, "Logdatetime", "MaxValue", Lit16, "container16", "plot16", "Max Value")
            Label16.Visible = True
        Else
            Lit16.Text = ""
        End If
        Dim dt17 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F2DT_55A")
        If dt17.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt17, "Logdatetime", "MaxValue", Lit17, "container17", "plot17", "Max Value")
            Label17.Visible = True
        Else
            Lit17.Text = ""
        End If
        Dim dt18 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F2DT_56A")
        If dt18.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt18, "Logdatetime", "MaxValue", Lit18, "container18", "plot18", "Max Value")
            Label18.Visible = True
        Else
            Lit18.Text = ""
        End If
        Dim dt19 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F2DT_57A")
        If dt19.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt19, "Logdatetime", "MaxValue", Lit19, "container19", "plot19", "Max Value")
            Label19.Visible = True
        Else
            Lit19.Text = ""
        End If
        Dim dt20 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F2DT_58A")
        If dt20.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt20, "Logdatetime", "MaxValue", Lit20, "container20", "plot20", "Max Value")
            Label20.Visible = True
        Else
            Lit20.Text = ""
        End If
        Dim dt21 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F2DT_59A")
        If dt21.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt21, "Logdatetime", "MaxValue", Lit21, "container21", "plot21", "Max Value")
            Label21.Visible = True
        Else
            Lit21.Text = ""
        End If
        Dim dt22 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F2DT_60A")
        If dt22.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt22, "Logdatetime", "MaxValue", Lit22, "container22", "plot22", "Max Value")
            Label22.Visible = True
        Else
            Lit22.Text = ""
        End If
        Dim dt23 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F2DT_M1")
        If dt23.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt23, "Logdatetime", "MaxValue", Lit23, "container23", "plot23", "Max Value")
            Label23.Visible = True
        Else
            Lit23.Text = ""
        End If
        Dim dt24 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F2DT_M10")
        If dt24.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt24, "Logdatetime", "MaxValue", Lit24, "container24", "plot24", "Max Value")
            Label24.Visible = True
        Else
            Lit24.Text = ""
        End If
        Dim dt25 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F2DT_M11")
        If dt25.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt25, "Logdatetime", "MaxValue", Lit25, "container25", "plot25", "Max Value")
            Label25.Visible = True
        Else
            Lit25.Text = ""
        End If
        Dim dt26 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F2DT_M12")
        If dt26.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt26, "Logdatetime", "MaxValue", Lit26, "container26", "plot26", "Max Value")
            Label26.Visible = True
        Else
            Lit26.Text = ""
        End If
        Dim dt27 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F2DT_M13")
        If dt27.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt27, "Logdatetime", "MaxValue", Lit27, "container27", "plot27", "Max Value")
            Label27.Visible = True
        Else
            Lit27.Text = ""
        End If
        Dim dt28 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F2DT_M14")
        If dt28.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt28, "Logdatetime", "MaxValue", Lit28, "container28", "plot28", "Max Value")
            Label28.Visible = True
        Else
            Lit28.Text = ""
        End If
        Dim dt29 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F2DT_M15")
        If dt29.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt29, "Logdatetime", "MaxValue", Lit29, "container29", "plot29", "Max Value")
            Label29.Visible = True
        Else
            Lit29.Text = ""
        End If
        Dim dt30 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F2DT_M16")
        If dt30.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt30, "Logdatetime", "MaxValue", Lit30, "container30", "plot30", "Max Value")
            Labe30.Visible = True
        Else
            Lit30.Text = ""
        End If
        Dim dt31 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F2DT_M17")
        If dt31.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt31, "Logdatetime", "MaxValue", Lit31, "container31", "plot31", "Max Value")
            Labe31.Visible = True
        Else
            Lit31.Text = ""
        End If
        Dim dt32 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F2DT_M18")
        If dt32.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt32, "Logdatetime", "MaxValue", Lit32, "container32", "plot32", "Max Value")
            Label32.Visible = True
        Else
            Lit32.Text = ""
        End If
        Dim dt33 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F2DT_M19")
        If dt33.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt33, "Logdatetime", "MaxValue", Lit33, "container33", "plot33", "Max Value")
            Label33.Visible = True
        Else

            Lit33.Text = ""
        End If
        Dim dt34 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F2DT_M2")
        If dt34.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt34, "Logdatetime", "MaxValue", Lit34, "container34", "plot34", "Max Value")
            Label34.Visible = True
        Else
            Lit34.Text = ""
        End If
        Dim dt35 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F2DT_M20")
        If dt35.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt35, "Logdatetime", "MaxValue", Lit35, "container35", "plot35", "Max Value")
            Label35.Visible = True
        Else
            Lit35.Text = ""
        End If
        Dim dt36 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F2DT_M21")
        If dt36.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt36, "Logdatetime", "MaxValue", Lit36, "container36", "plot36", "Max Value")
            Label36.Visible = True
        Else
            Lit36.Text = ""
        End If
        Dim dt37 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F2DT_M3")
        If dt37.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt37, "Logdatetime", "MaxValue", Lit37, "container37", "plot37", "Max Value")
            Label37.Visible = True
        Else
            Lit37.Text = ""
        End If
        Dim dt38 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F2DT_M4")
        If dt38.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt38, "Logdatetime", "MaxValue", Lit38, "container38", "plot38", "Max Value")
            Label38.Visible = True
        Else
            Lit38.Text = ""
        End If
        Dim dt39 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F2DT_M5")
        If dt39.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt39, "Logdatetime", "MaxValue", Lit39, "container39", "plot39", "Max Value")
            Label39.Visible = True
        Else
            Lit39.Text = ""
        End If
        Dim dt40 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F2DT_M6")
        If dt40.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt40, "Logdatetime", "MaxValue", Lit40, "container40", "plot40", "Max Value")
            Label40.Visible = True
        Else
            Lit40.Text = ""
        End If
        Dim dt41 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F2DT_M7")
        If dt41.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt41, "Logdatetime", "MaxValue", Lit41, "container41", "plot41", "Max Value")
            Label41.Visible = True
        Else
            Lit41.Text = ""
        End If
        Dim dt42 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F2DT_M8")
        If dt42.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt42, "Logdatetime", "MaxValue", Lit42, "container42", "plot42", "Max Value")
            Label42.Visible = True
        Else
            Lit42.Text = ""
        End If
        Dim dt43 As DataTable = objcontroller.GetHsmdata(startdate, endate, "F2DT_M9")
        If dt43.Rows.Count > 0 Then
            objcontroller.PlotLineChart(dt43, "Logdatetime", "MaxValue", Lit43, "container43", "plot43", "Max Value")
            Label43.Visible = True
        Else
            Lit43.Text = ""
        End If
    End Sub

    Protected Sub txtDate_TextChanged(sender As Object, e As System.EventArgs) Handles txtDate.TextChanged
        Dim startdate As String = hfFrom.Value
        Dim enddate As String = hfTo.Value
        DrawChart(startdate, enddate)
    End Sub
End Class
