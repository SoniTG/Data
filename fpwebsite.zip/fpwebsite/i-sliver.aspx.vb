﻿Imports System.Data
Partial Class i_sliver_test
    Inherits System.Web.UI.Page

    Dim objDataHandler As New DataHandler
    Dim objController As New Controller
    Dim flag As Boolean = True
    Dim dataunavailflag As Boolean = False
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Private Sub i_sliver_new_Load(sender As Object, e As EventArgs) Handles Me.Load
        flag = True
        If Page.IsPostBack Then
            Try

                Dim p As String = Request("__EVENTARGUMENT")
                If (p = "txtdate") Then
                    PopulateSlabID()
                    clearFields()
                ElseIf (p = "s1") Then
                    btnS1_Click(Nothing, Nothing)
                ElseIf (p = "s2") Then
                    btnS2_Click(Nothing, Nothing)
                End If

            Catch ex As Exception

            End Try
        End If

        If Not Page.IsPostBack Then
            Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), IO.Path.GetFileName(Request.Path))
            flag = False
            Dim dtStart As String = DateTime.Now.AddDays(-7).ToString("yyyy-MM-dd HH:mm")
            Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
            hfFrom.Value = dtStart
            hfTo.Value = dtEnd

            Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select distinct GRADE_CODE from [FP_PROCESS_DATA].[dbo].[T_SLABCUT_INFO] where grade_code is not null order by 1").Tables(0)
            ddlGrade.DataSource = dt
            ddlGrade.DataTextField = "GRADE_CODE"
            ddlGrade.DataValueField = "GRADE_CODE"
            ddlGrade.DataBind()
            ddlGrade.Items.Insert(0, New ListItem("All", "All"))

            Dim dt1 As DataTable = objDataHandler.GetDataSetFromQuery("select slab_id from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB_DEVIATIONS] where l2_slab_cut_time between '" & hfFrom.Value & "' and '" & hfTo.Value & "' " & " order by l2_slab_cut_time desc").Tables(0)
            ddlSlabID.DataSource = dt1

            ddlSlabID.DataTextField = "slab_id"
            ddlSlabID.DataValueField = "slab_id"
            ddlSlabID.DataBind()

            ddlSlabID.Items.Insert(0, New ListItem("Select", "select"))


            hfStrand.Value = "0"
            divfilter.Style.Add("display", "visible")
            'btnDisplay_Click()

        End If
    End Sub

    Sub PopulateDDL()
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select distinct GRADE_CODE from [FP_PROCESS_DATA].[dbo].[T_SLABCUT_INFO] where grade_code is not null order by 1").Tables(0)
        ddlGrade.DataSource = dt
        ddlGrade.DataTextField = "GRADE_CODE"
        ddlGrade.DataValueField = "GRADE_CODE"
        ddlGrade.DataBind()
        ddlGrade.Items.Insert(0, New ListItem("All", "All"))

        Dim dt1 As DataTable = objDataHandler.GetDataSetFromQuery("select slab_id from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB_DEVIATIONS] where l2_slab_cut_time between '" & hfFrom.Value & "' and '" & hfTo.Value & "' " & " order by l2_slab_cut_time desc").Tables(0)
        ddlSlabID.DataSource = dt1

        ddlSlabID.DataTextField = "slab_id"
        ddlSlabID.DataValueField = "slab_id"
        ddlSlabID.DataBind()

        ddlSlabID.Items.Insert(0, New ListItem("Select", "select"))

    End Sub
    Sub PopulateSlabID()
        Dim filter As String = ""
        If ddlGrade.SelectedIndex > 0 Then
            filter = " and grade='" & ddlGrade.SelectedItem.Value & "'"
        End If
        If ddlStrand.SelectedItem.Value = "1" Then
            filter &= " and slab_id like '%C__'"
        ElseIf ddlStrand.SelectedItem.Value = "2" Then
            filter &= " and slab_id like '%D__'"
        End If
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select slab_id from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB_DEVIATIONS] where l2_slab_cut_time between '" & hfFrom.Value & "' and '" & hfTo.Value & "' " & filter & " order by l2_slab_cut_time desc").Tables(0)
        ddlSlabID.DataSource = dt

        ddlSlabID.DataTextField = "slab_id"
        ddlSlabID.DataValueField = "slab_id"
        ddlSlabID.DataBind()

        ddlSlabID.Items.Insert(0, New ListItem("Select", "select"))

    End Sub

    Private Sub ddlGrade_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlGrade.SelectedIndexChanged
        If flag Then
            PopulateSlabID()
            clearFields()
        End If

    End Sub

    Private Sub clearFields()


        Dim idx() As Integer = {0, 1, 2, 10, 13, 16, 19, 22, 25}


        For row As Integer = 0 To UBound(idx)
            For column As Integer = 1 To 10
                tbldata.Rows(idx(row)).Cells(column).InnerHtml = ""
                tbldata.Rows(idx(row)).Cells(column).BgColor = "#ffffff"
            Next
        Next

        For r As Integer = 3 To 8
            For column As Integer = 1 To 10
                tbldata.Rows(r).Cells(column).InnerHtml = ""
                tbldata.Rows(r).Cells(column).BgColor = "#ffffff"
            Next

        Next

        lit1.Text = ""
        lit2.Text = ""
    End Sub

    Sub LoadDataInS12(ByRef tbl As HtmlTable, ByVal strandno As Integer, ByRef lit As Literal, ByVal suffix As String)
        'If strandno = 1 Then clearFields()

        Dim slabIDCols() As Integer = {10, 13, 16, 19, 22, 25}

        Dim slabid As String = ""


        Dim ymin As String = ""
        Dim ymax As String = ""

        Dim filter As String = ""
        If strandno = "1" Then
            filter &= " and slab_id like '%C__'"
        ElseIf strandno = "2" Then
            filter &= " and slab_id like '%D__'"
        End If


        Dim q As String

        q = " select top 10 slab_id,grade, convert(varchar,l2_slab_cut_time,120) as slab_cut_time from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB_DEVIATIONS] where 1=1 " & filter & "  order by l2_slab_cut_time desc"


        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery(q).Tables(0)

        Dim listSlabId = dt.AsEnumerable.Select(Function(r) r.Field(Of String)("slab_id"))
        Dim csvSlabID As String = "'" & String.Join("','", listSlabId) & "'"
        Dim arrMinMax(8, 1) As String
        GetLimitsForMold("mold_level_mm_5sec_diff_q0", "mold_level_mm_5sec_diff_q4", "mold_level_mm_5sec_diff_out", csvSlabID, ymin, ymax)
        arrMinMax(0, 0) = ymin : arrMinMax(0, 1) = ymax

        GetLimits("casting_speed_q0", "casting_speed_q4", "casting_speed_out", csvSlabID, ymin, ymax)
        arrMinMax(1, 0) = ymin : arrMinMax(1, 1) = ymax

        Dim toCheckTC2 As Boolean = False
        ymin = 10000 : ymax = -1
        toCheckTC2 = GetLimits("tc1_stopper_pos_q0", "tc1_stopper_pos_q4", "tc1_stopper_pos_out", csvSlabID, ymin, ymax, 1)
        arrMinMax(2, 0) = ymin : arrMinMax(2, 1) = ymax
        If toCheckTC2 = True Then
            GetLimits("tc2_stopper_pos_q0", "tc2_stopper_pos_q4", "tc2_stopper_pos_out", csvSlabID, ymin, ymax, 2)
            If CDbl(arrMinMax(2, 0)) > CDbl(ymin) Then
                arrMinMax(2, 0) = ymin
            End If
            If CDbl(arrMinMax(2, 1)) < CDbl(ymax) Then
                arrMinMax(2, 1) = ymax
            End If
        End If

        ymin = 10000 : ymax = -1
        toCheckTC2 = GetLimits("tc1_stopper_ar_flow_q0", "tc1_stopper_ar_flow_q4", "tc1_stopper_ar_flow_out", csvSlabID, ymin, ymax, 3)
        arrMinMax(3, 0) = ymin : arrMinMax(3, 1) = ymax
        If toCheckTC2 = True Then
            GetLimits("tc2_stopper_ar_flow_q0", "tc2_stopper_ar_flow_q4", "tc2_stopper_ar_flow_out", csvSlabID, ymin, ymax, 4)
            If CDbl(arrMinMax(3, 0)) > CDbl(ymin) Then
                arrMinMax(3, 0) = ymin
            End If
            If CDbl(arrMinMax(3, 1)) < CDbl(ymax) Then
                arrMinMax(3, 1) = ymax
            End If
        End If

        ymin = 10000 : ymax = -1
        toCheckTC2 = GetLimits("tc1_stopper_ar_pressure_q0", "tc1_stopper_ar_pressure_q4", "tc1_stopper_ar_pressure_out", csvSlabID, ymin, ymax, 5)
        arrMinMax(4, 0) = ymin : arrMinMax(4, 1) = ymax
        If toCheckTC2 = True Then
            GetLimits("tc2_stopper_ar_pressure_q0", "tc2_stopper_ar_pressure_q4", "tc2_stopper_ar_pressure_out", csvSlabID, ymin, ymax, 6)
            If CDbl(arrMinMax(4, 0)) > CDbl(ymin) Then
                arrMinMax(4, 0) = ymin
            End If
            If CDbl(arrMinMax(4, 1)) < CDbl(ymax) Then
                arrMinMax(4, 1) = ymax
            End If
        End If


        GetLimits("tundish_weight_q0", "tundish_weight_q4", "tundish_weight_out", csvSlabID, ymin, ymax)
        ymin = ymin / 1000 : ymax = ymax / 1000
        arrMinMax(5, 0) = ymin : arrMinMax(5, 1) = ymax



        If dt.Rows.Count > 0 Then
            dataunavailflag = False
            For cnt As Integer = 0 To dt.Rows.Count - 1

                'Make all cells green
                For r As Integer = 3 To 8
                    tbl.Rows(r).Cells(cnt + 1).BgColor = "#92D050"
                    tbl.Rows(r).Cells(cnt + 1).InnerText = ""
                Next

                Dim tempslabid As String = dt.Rows(cnt)(0)
                tbl.Rows(0).Cells(cnt + 1).InnerHtml = tempslabid
                tbl.Rows(1).Cells(cnt + 1).InnerHtml = dt.Rows(cnt)(1)
                tbl.Rows(2).Cells(cnt + 1).InnerHtml = dt.Rows(cnt)(2)

                tbl.Rows(10).Cells(cnt + 1).InnerHtml = tempslabid
                tbl.Rows(13).Cells(cnt + 1).InnerHtml = tempslabid
                tbl.Rows(16).Cells(cnt + 1).InnerHtml = tempslabid
                tbl.Rows(19).Cells(cnt + 1).InnerHtml = tempslabid
                tbl.Rows(22).Cells(cnt + 1).InnerHtml = tempslabid
                tbl.Rows(25).Cells(cnt + 1).InnerHtml = tempslabid

                tbl.Rows(0).Cells(cnt + 1).BgColor = "#92D050"
                tbl.Rows(10).Cells(cnt + 1).BgColor = "#92D050"
                tbl.Rows(13).Cells(cnt + 1).BgColor = "#92D050"
                tbl.Rows(16).Cells(cnt + 1).BgColor = "#92D050"
                tbl.Rows(19).Cells(cnt + 1).BgColor = "#92D050"
                tbl.Rows(22).Cells(cnt + 1).BgColor = "#92D050"
                tbl.Rows(25).Cells(cnt + 1).BgColor = "#92D050"



                'Mold Level %
                'ymin = "50"
                'ymax = "100"

                ymin = arrMinMax(0, 0)
                ymax = arrMinMax(0, 1)

                q = "select mold_level_mm_5sec_diff_q0,mold_level_mm_5sec_diff_q1,mold_level_mm_5sec_diff_q2,mold_level_mm_5sec_diff_q3,mold_level_mm_5sec_diff_q4,mold_level_mm_5sec_diff_out,mold_level_mm_5sec_diff_mean,mold_level_mm_5sec_4mm_deviations,C from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB_EXT] t1 inner join [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB] t2 on t1.slab_id=t2.slab_id inner join T_TSK_SMS_SLAB_DEVIATIONS t3 on t1.slab_id=t3.slab_id inner join T_SLABCUT_INFO t4 on t1.slab_id=t4.slab_id where ltrim(rtrim(t1.slab_id))='" & tempslabid & "'"
                Dim ds1 As DataSet = objDataHandler.GetDataSetFromQuery(q)

                If ds1.Tables(0).Rows.Count > 0 AndAlso Not IsDBNull(ds1.Tables(0).Rows(0)(0)) Then
                    lit.Text &= getBoxPlotString(ds1.Tables(0), ds1.Tables(0).Rows(0)(6), "a" & cnt & suffix, "a" & cnt & suffix, ymin, ymax)
                    ''*********Previous condition for RED/GREEN *********************
                    ''If Not IsDBNull(ds1.Tables(0).Rows(0)("mold_level_mm_deviations")) AndAlso ds1.Tables(0).Rows(0)("mold_level_mm_deviations") > 0 Then
                    ''    tbl.Rows(3).Cells(cnt + 1).BgColor = "#FF0000" 'red background

                    ''    tbl.Rows(10).Cells(cnt + 1).BgColor = "#FF0000"
                    ''    tbl.Rows(0).Cells(cnt + 1).BgColor = "#FF0000"

                    ''End If
                    ''***************************************************************
                    Dim greater_than_cond_value = 6
                    Dim m_q0 As Double = Math.Abs(ds1.Tables(0).Rows(0)("mold_level_mm_5sec_diff_q0"))
                    Dim m_q4 As Double = Math.Abs(ds1.Tables(0).Rows(0)("mold_level_mm_5sec_diff_q4"))
                    Dim m_out As String = ds1.Tables(0).Rows(0)("mold_level_mm_5sec_diff_out").ToString.Replace("NA", "").Replace("-", "")
                    Dim m_arr() As Double = {m_q0, m_q4}
                    If m_out.Length > 0 Then
                        Dim m_a() As Double = Array.ConvertAll(m_out.Split(","), New Converter(Of String, Double)(AddressOf Double.Parse))
                        ReDim Preserve m_arr(2)
                        m_arr(2) = m_a.Max
                    End If
                    Dim m_max = m_arr.Max


                    If Not IsDBNull(ds1.Tables(0).Rows(0)("C")) AndAlso ds1.Tables(0).Rows(0)("C") < 0.07 Then
                        greater_than_cond_value = 4
                    End If

                    If m_max > greater_than_cond_value Then
                        tbl.Rows(3).Cells(cnt + 1).BgColor = "#FF0000" 'red background

                        tbl.Rows(10).Cells(cnt + 1).BgColor = "#FF0000"
                        tbl.Rows(0).Cells(cnt + 1).BgColor = "#FF0000"
                    End If
                    dataunavailflag = True
                Else

                    tbl.Rows(3).Cells(cnt + 1).InnerText = "Data unavailable / awaited"

                    tbl.Rows(3).Cells(cnt + 1).BgColor = "#FFFFFF"
                    tbl.Rows(10).Cells(cnt + 1).BgColor = "#FFFFFF"
                End If

                'Casting Speed m/min
                ymin = "0"
                ymax = "2"

                ymin = arrMinMax(1, 0)
                ymax = arrMinMax(1, 1)

                q = "select casting_speed_q0, casting_speed_q1, casting_speed_q2, casting_speed_q3, casting_speed_q4, casting_speed_out, casting_speed_mean, casting_speed_deviations from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB_EXT] t1 inner join [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB] t2 On t1.slab_id=t2.slab_id inner join T_TSK_SMS_SLAB_DEVIATIONS t3 On t1.slab_id=t3.slab_id where ltrim(rtrim(t1.slab_id))='" & tempslabid & "'"
                Dim ds2 As DataSet = objDataHandler.GetDataSetFromQuery(q)

                If ds2.Tables(0).Rows.Count > 0 AndAlso Not IsDBNull(ds2.Tables(0).Rows(0)(0)) Then
                    lit.Text &= getBoxPlotString(ds2.Tables(0), ds2.Tables(0).Rows(0)(6), "b" & cnt & suffix, "b" & cnt & suffix, ymin, ymax)
                    If Not IsDBNull(ds2.Tables(0).Rows(0)("casting_speed_deviations")) AndAlso ds2.Tables(0).Rows(0)("casting_speed_deviations") >= 0.2 Then
                        tbl.Rows(4).Cells(cnt + 1).BgColor = "#FF0000" 'red background

                        tbl.Rows(13).Cells(cnt + 1).BgColor = "#FF0000"
                        tbl.Rows(0).Cells(cnt + 1).BgColor = "#FF0000"
                    End If
                    dataunavailflag = True
                Else
                    tbl.Rows(4).Cells(cnt + 1).InnerText = "Data unavailable / awaited"

                    tbl.Rows(4).Cells(cnt + 1).BgColor = "#FFFFFF"
                    tbl.Rows(13).Cells(cnt + 1).BgColor = "#FFFFFF"
                End If

                'Stopper Position mm
                ymin = "0"
                ymax = "100"
                ymin = arrMinMax(2, 0)
                ymax = arrMinMax(2, 1)
                q = "select tc1_stopper_pos_q0,tc1_stopper_pos_q1,tc1_stopper_pos_q2,tc1_stopper_pos_q3,tc1_stopper_pos_q4,tc1_stopper_pos_out,tc1_stopper_pos_mean,tc1_cast_pos_mean,tc1_stopper_pos_deviations from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB_EXT] t1  inner join T_TSK_SMS_SLAB_DEVIATIONS t3 on t1.slab_id=t3.slab_id where ltrim(rtrim(t1.slab_id))='" & tempslabid & "';select tc2_stopper_pos_q0,tc2_stopper_pos_q1,tc2_stopper_pos_q2,tc2_stopper_pos_q3,tc2_stopper_pos_q4,tc2_stopper_pos_out,tc2_stopper_pos_mean,tc1_cast_pos_mean,tc2_stopper_pos_deviations from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB_EXT] t1  inner join T_TSK_SMS_SLAB_DEVIATIONS t3 on t1.slab_id=t3.slab_id where ltrim(rtrim(t1.slab_id))='" & tempslabid & "'"
                Dim ds3 As DataSet = objDataHandler.GetDataSetFromQuery(q)

                If ds3.Tables(0).Rows.Count > 0 AndAlso Not IsDBNull(ds3.Tables(0).Rows(0)(0)) Then
                    If ds3.Tables(0).Rows(0)("tc1_cast_pos_mean") > 0.5 Then
                        lit.Text &= getBoxPlotString(ds3.Tables(0), ds3.Tables(0).Rows(0)(6), "c" & cnt & suffix, "c" & cnt & suffix, ymin, ymax)
                        If Not IsDBNull(ds3.Tables(0).Rows(0)("tc1_stopper_pos_deviations")) AndAlso ds3.Tables(0).Rows(0)("tc1_stopper_pos_deviations") > 0 Then
                            tbl.Rows(5).Cells(cnt + 1).BgColor = "#FF0000" 'red background

                            tbl.Rows(16).Cells(cnt + 1).BgColor = "#FF0000"
                            tbl.Rows(0).Cells(cnt + 1).BgColor = "#FF0000"
                        End If
                    Else
                        lit.Text &= getBoxPlotString(ds3.Tables(1), ds3.Tables(1).Rows(0)(6), "c" & cnt & suffix, "c" & cnt & suffix, ymin, ymax)
                        If Not IsDBNull(ds3.Tables(1).Rows(0)("tc2_stopper_pos_deviations")) AndAlso ds3.Tables(1).Rows(0)("tc2_stopper_pos_deviations") > 0 Then
                            tbl.Rows(5).Cells(cnt + 1).BgColor = "#FF0000" 'red background

                            tbl.Rows(16).Cells(cnt + 1).BgColor = "#FF0000"
                            tbl.Rows(0).Cells(cnt + 1).BgColor = "#FF0000"
                        End If
                    End If
                    dataunavailflag = True
                Else

                    tbl.Rows(5).Cells(cnt + 1).InnerText = "Data unavailable / awaited"

                    tbl.Rows(5).Cells(cnt + 1).BgColor = "#FFFFFF"
                    tbl.Rows(16).Cells(cnt + 1).BgColor = "#FFFFFF"
                End If

                'Stopper Argon Flow litre/min
                ymin = "3"
                ymax = "12"
                ymin = arrMinMax(3, 0)
                ymax = arrMinMax(3, 1)

                q = "Select tc1_stopper_ar_flow_q0, tc1_stopper_ar_flow_q1, tc1_stopper_ar_flow_q2, tc1_stopper_ar_flow_q3, tc1_stopper_ar_flow_q4, tc1_stopper_ar_flow_out, tc1_stopper_ar_flow_mean, tc1_cast_pos_mean, tc1_stopper_ar_flow_deviations from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB_EXT] t1 inner join T_TSK_SMS_SLAB_DEVIATIONS t3 On t1.slab_id=t3.slab_id where ltrim(rtrim(t1.slab_id))='" & tempslabid & "';select tc2_stopper_ar_flow_q0,tc2_stopper_ar_flow_q1,tc2_stopper_ar_flow_q2,tc2_stopper_ar_flow_q3,tc2_stopper_ar_flow_q4,tc2_stopper_ar_flow_out,tc2_stopper_ar_flow_mean,tc1_cast_pos_mean,tc2_stopper_ar_flow_deviations from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB_EXT] t1 inner join T_TSK_SMS_SLAB_DEVIATIONS t3 on t1.slab_id=t3.slab_id where ltrim(rtrim(t1.slab_id))='" & tempslabid & "'"
                Dim ds4 As DataSet = objDataHandler.GetDataSetFromQuery(q)

                If ds4.Tables(0).Rows.Count > 0 AndAlso Not IsDBNull(ds4.Tables(0).Rows(0)(0)) Then
                    If ds4.Tables(0).Rows(0)("tc1_cast_pos_mean") > 0.5 Then
                        lit.Text &= getBoxPlotString(ds4.Tables(0), ds4.Tables(0).Rows(0)(6), "d" & cnt & suffix, "d" & cnt & suffix, ymin, ymax)
                        If Not IsDBNull(ds4.Tables(0).Rows(0)("tc1_stopper_ar_flow_deviations")) AndAlso ds4.Tables(0).Rows(0)("tc1_stopper_ar_flow_deviations") > 0 Then
                            tbl.Rows(6).Cells(cnt + 1).BgColor = "#FF0000" 'red background

                            tbl.Rows(19).Cells(cnt + 1).BgColor = "#FF0000"
                            tbl.Rows(0).Cells(cnt + 1).BgColor = "#FF0000"
                        End If
                    Else
                        lit.Text &= getBoxPlotString(ds4.Tables(1), ds4.Tables(1).Rows(0)(6), "d" & cnt & suffix, "d" & cnt & suffix, ymin, ymax)
                        If Not IsDBNull(ds4.Tables(1).Rows(0)("tc2_stopper_ar_flow_deviations")) AndAlso ds4.Tables(1).Rows(0)("tc2_stopper_ar_flow_deviations") > 0 Then
                            tbl.Rows(6).Cells(cnt + 1).BgColor = "#FF0000" 'red background

                            tbl.Rows(19).Cells(cnt + 1).BgColor = "#FF0000"
                            tbl.Rows(0).Cells(cnt + 1).BgColor = "#FF0000"
                        End If
                    End If
                    dataunavailflag = True
                Else

                    tbl.Rows(6).Cells(cnt + 1).InnerText = "Data unavailable / awaited"

                    tbl.Rows(6).Cells(cnt + 1).BgColor = "#FFFFFF"
                    tbl.Rows(19).Cells(cnt + 1).BgColor = "#FFFFFF"
                End If

                'Stopper Argon Back Pressure bar
                ymin = "0"
                ymax = "2"

                ymin = arrMinMax(4, 0)
                ymax = arrMinMax(4, 1)

                q = "Select tc1_stopper_ar_pressure_q0,tc1_stopper_ar_pressure_q1,tc1_stopper_ar_pressure_q2,tc1_stopper_ar_pressure_q3,tc1_stopper_ar_pressure_q4,tc1_stopper_ar_pressure_out,tc1_stopper_ar_pressure_mean,tc1_cast_pos_mean,tc1_stopper_ar_pressure_deviations from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB_EXT] t1 inner join T_TSK_SMS_SLAB_DEVIATIONS t3 On t1.slab_id=t3.slab_id where ltrim(rtrim(t1.slab_id))='" & tempslabid & "';select tc2_stopper_ar_pressure_q0,tc2_stopper_ar_pressure_q1,tc2_stopper_ar_pressure_q2,tc2_stopper_ar_pressure_q3,tc2_stopper_ar_pressure_q4,tc2_stopper_ar_pressure_out,tc2_stopper_ar_pressure_mean,tc1_cast_pos_mean,tc2_stopper_ar_pressure_deviations from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB_EXT] t1  inner join T_TSK_SMS_SLAB_DEVIATIONS t3 on t1.slab_id=t3.slab_id where ltrim(rtrim(t1.slab_id))='" & tempslabid & "'"
                Dim ds5 As DataSet = objDataHandler.GetDataSetFromQuery(q)

                If ds5.Tables(0).Rows.Count > 0 AndAlso Not IsDBNull(ds5.Tables(0).Rows(0)(0)) Then
                    If ds5.Tables(0).Rows(0)("tc1_cast_pos_mean") > 0.5 Then
                        lit.Text &= getBoxPlotString(ds5.Tables(0), ds5.Tables(0).Rows(0)(6), "e" & cnt & suffix, "e" & cnt & suffix, ymin, ymax)
                        If Not IsDBNull(ds5.Tables(0).Rows(0)("tc1_stopper_ar_pressure_deviations")) AndAlso ds5.Tables(0).Rows(0)("tc1_stopper_ar_pressure_deviations") > 0 Then
                            tbl.Rows(7).Cells(cnt + 1).BgColor = "#FF0000" 'red background

                            tbl.Rows(22).Cells(cnt + 1).BgColor = "#FF0000"
                            tbl.Rows(0).Cells(cnt + 1).BgColor = "#FF0000"
                        End If
                    Else
                        lit.Text &= getBoxPlotString(ds5.Tables(1), ds5.Tables(1).Rows(0)(6), "e" & cnt & suffix, "e" & cnt & suffix, ymin, ymax)
                        If Not IsDBNull(ds5.Tables(1).Rows(0)("tc2_stopper_ar_pressure_deviations")) AndAlso ds5.Tables(1).Rows(0)("tc2_stopper_ar_pressure_deviations") > 0 Then
                            tbl.Rows(7).Cells(cnt + 1).BgColor = "#FF0000" 'red background

                            tbl.Rows(22).Cells(cnt + 1).BgColor = "#FF0000"
                            tbl.Rows(0).Cells(cnt + 1).BgColor = "#FF0000"
                        End If
                    End If

                    dataunavailflag = True
                Else

                    tbl.Rows(7).Cells(cnt + 1).InnerText = "Data unavailable / awaited"

                    tbl.Rows(7).Cells(cnt + 1).BgColor = "#FFFFFF"
                    tbl.Rows(22).Cells(cnt + 1).BgColor = "#FFFFFF"
                End If

                'Tundish Weight tons
                ymin = "20"
                ymax = "75"

                ymin = arrMinMax(5, 0)
                ymax = arrMinMax(5, 1)

                q = "Select tundish_weight_q0/1000,tundish_weight_q1/1000,tundish_weight_q2/1000,tundish_weight_q3/1000,tundish_weight_q4/1000,tundish_weight_out,tundish_weight_mean/1000,tundish_weight_deviations from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB_EXT] t1 inner join T_TSK_SMS_SLAB_DEVIATIONS t3 On t1.slab_id=t3.slab_id where ltrim(rtrim(t1.slab_id))='" & tempslabid & "'"
                Dim ds6 As DataSet = objDataHandler.GetDataSetFromQuery(q)

                If ds6.Tables(0).Rows.Count > 0 AndAlso Not IsDBNull(ds6.Tables(0).Rows(0)(0)) Then
                    lit.Text &= getBoxPlotString(ds6.Tables(0), ds6.Tables(0).Rows(0)(6), "f" & cnt & suffix, "f" & cnt & suffix, ymin, ymax)
                    If Not IsDBNull(ds6.Tables(0).Rows(0)("tundish_weight_deviations")) AndAlso ds6.Tables(0).Rows(0)("tundish_weight_deviations") > 0 Then
                        tbl.Rows(8).Cells(cnt + 1).BgColor = "#FF0000" 'red background

                        tbl.Rows(25).Cells(cnt + 1).BgColor = "#FF0000"
                        tbl.Rows(0).Cells(cnt + 1).BgColor = "#FF0000"
                    End If
                    dataunavailflag = True
                Else
                    tbl.Rows(8).Cells(cnt + 1).InnerText = "Data unavailable / awaited"

                    tbl.Rows(8).Cells(cnt + 1).BgColor = "#FFFFFF"
                    tbl.Rows(25).Cells(cnt + 1).BgColor = "#FFFFFF"
                End If

                'changeTextDataUnavailable(cnt + 1)
            Next

            For cnt As Integer = 0 To dt.Rows.Count - 1
                If tbl.Rows(3).Cells(cnt + 1).InnerText = "Data unavailable / awaited" Then
                    tbl.Rows(0).Cells(cnt + 1).BgColor = "#FFFFFF"
                End If

            Next

        End If
    End Sub
    Private Sub btnDisplay_Click()
        clearFields()

        Dim slabIDCols() As Integer = {10, 13, 16, 19, 22, 25}

        Dim slabid As String = ""

        If hfStrand.Value = 0 Then

            If ddlSlabID.SelectedIndex > 0 Then
                slabid = ddlSlabID.SelectedItem.Value
            End If
            If txtSlabId.Text.Trim.Length > 0 Then
                slabid = txtSlabId.Text.Trim
                Dim dtcheck As DataTable = objDataHandler.GetDataSetFromQuery("select slab_id from [FP_PROCESS_DATA].[dbo].[T_SLABCUT_INFO]  where ltrim(rtrim(slab_id))='" & slabid & "' and deviation_status>=1").Tables(0)
                If dtcheck.Rows.Count = 0 Then
                    UserMsgBoxError("No data found")
                    Return
                End If
            End If

            If slabid = "" Then
                UserMsgBoxError("No SlabID Selected")
                Return
            End If
        End If


        Dim ymin As String = ""
        Dim ymax As String = ""

        Dim filter As String = ""
        If hfStrand.Value = "1" Then
            filter &= " and slab_id like '%C__'"
        ElseIf hfStrand.Value = "2" Then
            filter &= " and slab_id like '%D__'"
        ElseIf hfStrand.Value = "0" Then
            If ddlStrand.SelectedItem.Value = "1" Then
                filter &= " and slab_id like '%C__'"
            ElseIf ddlStrand.SelectedItem.Value = "2" Then
                filter &= " and slab_id like '%D__'"
            End If
        End If


        Dim q As String

        If hfStrand.Value = "0" Then
            q = " select top 10 slab_id,grade, convert(varchar,l2_slab_cut_time,120) as slab_cut_time from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB_DEVIATIONS] where l2_slab_cut_time<=(select l2_slab_cut_time from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB_DEVIATIONS] where ltrim(rtrim(slab_id))='" & slabid & "') " & filter & "  order by l2_slab_cut_time desc"
        Else

            q = " select top 10 slab_id,grade, convert(varchar,l2_slab_cut_time,120) as slab_cut_time from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB_DEVIATIONS] where 1=1 " & filter & "  order by l2_slab_cut_time desc"
        End If

        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery(q).Tables(0)

        Dim listSlabId = dt.AsEnumerable.Select(Function(r) r.Field(Of String)("slab_id"))
        Dim csvSlabID As String = "'" & String.Join("','", listSlabId) & "'"
        Dim arrMinMax(8, 1) As String
        GetLimitsForMold("mold_level_mm_5sec_diff_q0", "mold_level_mm_5sec_diff_q4", "mold_level_mm_5sec_diff_out", csvSlabID, ymin, ymax)
        arrMinMax(0, 0) = ymin : arrMinMax(0, 1) = ymax

        GetLimits("casting_speed_q0", "casting_speed_q4", "casting_speed_out", csvSlabID, ymin, ymax)
        arrMinMax(1, 0) = ymin : arrMinMax(1, 1) = ymax

        Dim toCheckTC2 As Boolean = False
        ymin = 10000 : ymax = -1
        toCheckTC2 = GetLimits("tc1_stopper_pos_q0", "tc1_stopper_pos_q4", "tc1_stopper_pos_out", csvSlabID, ymin, ymax, 1)
        arrMinMax(2, 0) = ymin : arrMinMax(2, 1) = ymax
        If toCheckTC2 = True Then
            GetLimits("tc2_stopper_pos_q0", "tc2_stopper_pos_q4", "tc2_stopper_pos_out", csvSlabID, ymin, ymax, 2)
            If CDbl(arrMinMax(2, 0)) > CDbl(ymin) Then
                arrMinMax(2, 0) = ymin
            End If
            If CDbl(arrMinMax(2, 1)) < CDbl(ymax) Then
                arrMinMax(2, 1) = ymax
            End If
        End If

        ymin = 10000 : ymax = -1
        toCheckTC2 = GetLimits("tc1_stopper_ar_flow_q0", "tc1_stopper_ar_flow_q4", "tc1_stopper_ar_flow_out", csvSlabID, ymin, ymax, 3)
        arrMinMax(3, 0) = ymin : arrMinMax(3, 1) = ymax
        If toCheckTC2 = True Then
            GetLimits("tc2_stopper_ar_flow_q0", "tc2_stopper_ar_flow_q4", "tc2_stopper_ar_flow_out", csvSlabID, ymin, ymax, 4)
            If CDbl(arrMinMax(3, 0)) > CDbl(ymin) Then
                arrMinMax(3, 0) = ymin
            End If
            If CDbl(arrMinMax(3, 1)) < CDbl(ymax) Then
                arrMinMax(3, 1) = ymax
            End If
        End If

        ymin = 10000 : ymax = -1
        toCheckTC2 = GetLimits("tc1_stopper_ar_pressure_q0", "tc1_stopper_ar_pressure_q4", "tc1_stopper_ar_pressure_out", csvSlabID, ymin, ymax, 5)
        arrMinMax(4, 0) = ymin : arrMinMax(4, 1) = ymax
        If toCheckTC2 = True Then
            GetLimits("tc2_stopper_ar_pressure_q0", "tc2_stopper_ar_pressure_q4", "tc2_stopper_ar_pressure_out", csvSlabID, ymin, ymax, 6)
            If CDbl(arrMinMax(4, 0)) > CDbl(ymin) Then
                arrMinMax(4, 0) = ymin
            End If
            If CDbl(arrMinMax(4, 1)) < CDbl(ymax) Then
                arrMinMax(4, 1) = ymax
            End If
        End If


        GetLimits("tundish_weight_q0", "tundish_weight_q4", "tundish_weight_out", csvSlabID, ymin, ymax)
        ymin = ymin / 1000 : ymax = ymax / 1000
        arrMinMax(5, 0) = ymin : arrMinMax(5, 1) = ymax



        If dt.Rows.Count > 0 Then
            dataunavailflag = False
            For cnt As Integer = 0 To dt.Rows.Count - 1

                'Make all cells green
                For r As Integer = 3 To 8
                    tbldata.Rows(r).Cells(cnt + 1).BgColor = "#92D050"
                    tbldata.Rows(r).Cells(cnt + 1).InnerText = ""
                Next

                Dim tempslabid As String = dt.Rows(cnt)(0)
                tbldata.Rows(0).Cells(cnt + 1).InnerHtml = tempslabid
                tbldata.Rows(1).Cells(cnt + 1).InnerHtml = dt.Rows(cnt)(1)
                tbldata.Rows(2).Cells(cnt + 1).InnerHtml = dt.Rows(cnt)(2)

                tbldata.Rows(10).Cells(cnt + 1).InnerHtml = tempslabid
                tbldata.Rows(13).Cells(cnt + 1).InnerHtml = tempslabid
                tbldata.Rows(16).Cells(cnt + 1).InnerHtml = tempslabid
                tbldata.Rows(19).Cells(cnt + 1).InnerHtml = tempslabid
                tbldata.Rows(22).Cells(cnt + 1).InnerHtml = tempslabid
                tbldata.Rows(25).Cells(cnt + 1).InnerHtml = tempslabid

                tbldata.Rows(0).Cells(cnt + 1).BgColor = "#92D050"
                tbldata.Rows(10).Cells(cnt + 1).BgColor = "#92D050"
                tbldata.Rows(13).Cells(cnt + 1).BgColor = "#92D050"
                tbldata.Rows(16).Cells(cnt + 1).BgColor = "#92D050"
                tbldata.Rows(19).Cells(cnt + 1).BgColor = "#92D050"
                tbldata.Rows(22).Cells(cnt + 1).BgColor = "#92D050"
                tbldata.Rows(25).Cells(cnt + 1).BgColor = "#92D050"



                'Mold Level %
                'ymin = "50"
                'ymax = "100"

                ymin = arrMinMax(0, 0)
                ymax = arrMinMax(0, 1)

                q = "select mold_level_mm_5sec_diff_q0,mold_level_mm_5sec_diff_q1,mold_level_mm_5sec_diff_q2,mold_level_mm_5sec_diff_q3,mold_level_mm_5sec_diff_q4,mold_level_mm_5sec_diff_out,mold_level_mm_5sec_diff_mean,mold_level_mm_5sec_4mm_deviations,C from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB_EXT] t1 inner join [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB] t2 on t1.slab_id=t2.slab_id inner join T_TSK_SMS_SLAB_DEVIATIONS t3 on t1.slab_id=t3.slab_id inner join T_SLABCUT_INFO t4 on t1.slab_id=t4.slab_id where ltrim(rtrim(t1.slab_id))='" & tempslabid & "'"
                Dim ds1 As DataSet = objDataHandler.GetDataSetFromQuery(q)

                If ds1.Tables(0).Rows.Count > 0 AndAlso Not IsDBNull(ds1.Tables(0).Rows(0)(0)) Then
                    lit1.Text &= getBoxPlotString(ds1.Tables(0), ds1.Tables(0).Rows(0)(6), "a" & cnt, "a" & cnt, ymin, ymax)
                    ''*********Previous condition for RED/GREEN *********************
                    ''If Not IsDBNull(ds1.Tables(0).Rows(0)("mold_level_mm_deviations")) AndAlso ds1.Tables(0).Rows(0)("mold_level_mm_deviations") > 0 Then
                    ''    tbldata.Rows(3).Cells(cnt + 1).BgColor = "#FF0000" 'red background

                    ''    tbldata.Rows(10).Cells(cnt + 1).BgColor = "#FF0000"
                    ''    tbldata.Rows(0).Cells(cnt + 1).BgColor = "#FF0000"

                    ''End If
                    ''***************************************************************
                    Dim greater_than_cond_value = 6
                    Dim m_q0 As Double = Math.Abs(ds1.Tables(0).Rows(0)("mold_level_mm_5sec_diff_q0"))
                    Dim m_q4 As Double = Math.Abs(ds1.Tables(0).Rows(0)("mold_level_mm_5sec_diff_q4"))
                    Dim m_out As String = ds1.Tables(0).Rows(0)("mold_level_mm_5sec_diff_out").ToString.Replace("NA", "").Replace("-", "")
                    Dim m_arr() As Double = {m_q0, m_q4}
                    If m_out.Length > 0 Then
                        Dim m_a() As Double = Array.ConvertAll(m_out.Split(","), New Converter(Of String, Double)(AddressOf Double.Parse))
                        ReDim Preserve m_arr(2)
                        m_arr(2) = m_a.Max
                    End If
                    Dim m_max = m_arr.Max


                    If Not IsDBNull(ds1.Tables(0).Rows(0)("C")) AndAlso ds1.Tables(0).Rows(0)("C") < 0.07 Then
                        greater_than_cond_value = 4
                    End If

                    If m_max > greater_than_cond_value Then
                        tbldata.Rows(3).Cells(cnt + 1).BgColor = "#FF0000" 'red background

                        tbldata.Rows(10).Cells(cnt + 1).BgColor = "#FF0000"
                        tbldata.Rows(0).Cells(cnt + 1).BgColor = "#FF0000"
                    End If
                    dataunavailflag = True
                Else

                    tbldata.Rows(3).Cells(cnt + 1).InnerText = "Data unavailable / awaited"

                    tbldata.Rows(3).Cells(cnt + 1).BgColor = "#FFFFFF"
                    tbldata.Rows(10).Cells(cnt + 1).BgColor = "#FFFFFF"
                End If

                'Casting Speed m/min
                ymin = "0"
                ymax = "2"

                ymin = arrMinMax(1, 0)
                ymax = arrMinMax(1, 1)

                q = "select casting_speed_q0, casting_speed_q1, casting_speed_q2, casting_speed_q3, casting_speed_q4, casting_speed_out, casting_speed_mean, casting_speed_deviations from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB_EXT] t1 inner join [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB] t2 On t1.slab_id=t2.slab_id inner join T_TSK_SMS_SLAB_DEVIATIONS t3 On t1.slab_id=t3.slab_id where ltrim(rtrim(t1.slab_id))='" & tempslabid & "'"
                Dim ds2 As DataSet = objDataHandler.GetDataSetFromQuery(q)

                If ds2.Tables(0).Rows.Count > 0 AndAlso Not IsDBNull(ds2.Tables(0).Rows(0)(0)) Then
                    lit1.Text &= getBoxPlotString(ds2.Tables(0), ds2.Tables(0).Rows(0)(6), "b" & cnt, "b" & cnt, ymin, ymax)
                    If Not IsDBNull(ds2.Tables(0).Rows(0)("casting_speed_deviations")) AndAlso ds2.Tables(0).Rows(0)("casting_speed_deviations") >= 0.2 Then
                        tbldata.Rows(4).Cells(cnt + 1).BgColor = "#FF0000" 'red background

                        tbldata.Rows(13).Cells(cnt + 1).BgColor = "#FF0000"
                        tbldata.Rows(0).Cells(cnt + 1).BgColor = "#FF0000"
                    End If
                    dataunavailflag = True
                Else
                    tbldata.Rows(4).Cells(cnt + 1).InnerText = "Data unavailable / awaited"

                    tbldata.Rows(4).Cells(cnt + 1).BgColor = "#FFFFFF"
                    tbldata.Rows(13).Cells(cnt + 1).BgColor = "#FFFFFF"
                End If

                'Stopper Position mm
                ymin = "0"
                ymax = "100"
                ymin = arrMinMax(2, 0)
                ymax = arrMinMax(2, 1)
                q = "select tc1_stopper_pos_q0,tc1_stopper_pos_q1,tc1_stopper_pos_q2,tc1_stopper_pos_q3,tc1_stopper_pos_q4,tc1_stopper_pos_out,tc1_stopper_pos_mean,tc1_cast_pos_mean,tc1_stopper_pos_deviations from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB_EXT] t1  inner join T_TSK_SMS_SLAB_DEVIATIONS t3 on t1.slab_id=t3.slab_id where ltrim(rtrim(t1.slab_id))='" & tempslabid & "';select tc2_stopper_pos_q0,tc2_stopper_pos_q1,tc2_stopper_pos_q2,tc2_stopper_pos_q3,tc2_stopper_pos_q4,tc2_stopper_pos_out,tc2_stopper_pos_mean,tc1_cast_pos_mean,tc2_stopper_pos_deviations from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB_EXT] t1  inner join T_TSK_SMS_SLAB_DEVIATIONS t3 on t1.slab_id=t3.slab_id where ltrim(rtrim(t1.slab_id))='" & tempslabid & "'"
                Dim ds3 As DataSet = objDataHandler.GetDataSetFromQuery(q)

                If ds3.Tables(0).Rows.Count > 0 AndAlso Not IsDBNull(ds3.Tables(0).Rows(0)(0)) Then
                    If ds3.Tables(0).Rows(0)("tc1_cast_pos_mean") > 0.5 Then
                        lit1.Text &= getBoxPlotString(ds3.Tables(0), ds3.Tables(0).Rows(0)(6), "c" & cnt, "c" & cnt, ymin, ymax)
                        If Not IsDBNull(ds3.Tables(0).Rows(0)("tc1_stopper_pos_deviations")) AndAlso ds3.Tables(0).Rows(0)("tc1_stopper_pos_deviations") > 0 Then
                            tbldata.Rows(5).Cells(cnt + 1).BgColor = "#FF0000" 'red background

                            tbldata.Rows(16).Cells(cnt + 1).BgColor = "#FF0000"
                            tbldata.Rows(0).Cells(cnt + 1).BgColor = "#FF0000"
                        End If
                    Else
                        lit1.Text &= getBoxPlotString(ds3.Tables(1), ds3.Tables(1).Rows(0)(6), "c" & cnt, "c" & cnt, ymin, ymax)
                        If Not IsDBNull(ds3.Tables(1).Rows(0)("tc2_stopper_pos_deviations")) AndAlso ds3.Tables(1).Rows(0)("tc2_stopper_pos_deviations") > 0 Then
                            tbldata.Rows(5).Cells(cnt + 1).BgColor = "#FF0000" 'red background

                            tbldata.Rows(16).Cells(cnt + 1).BgColor = "#FF0000"
                            tbldata.Rows(0).Cells(cnt + 1).BgColor = "#FF0000"
                        End If
                    End If
                    dataunavailflag = True
                Else

                    tbldata.Rows(5).Cells(cnt + 1).InnerText = "Data unavailable / awaited"

                    tbldata.Rows(5).Cells(cnt + 1).BgColor = "#FFFFFF"
                    tbldata.Rows(16).Cells(cnt + 1).BgColor = "#FFFFFF"
                End If

                'Stopper Argon Flow litre/min
                ymin = "3"
                ymax = "12"
                ymin = arrMinMax(3, 0)
                ymax = arrMinMax(3, 1)

                q = "Select tc1_stopper_ar_flow_q0, tc1_stopper_ar_flow_q1, tc1_stopper_ar_flow_q2, tc1_stopper_ar_flow_q3, tc1_stopper_ar_flow_q4, tc1_stopper_ar_flow_out, tc1_stopper_ar_flow_mean, tc1_cast_pos_mean, tc1_stopper_ar_flow_deviations from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB_EXT] t1 inner join T_TSK_SMS_SLAB_DEVIATIONS t3 On t1.slab_id=t3.slab_id where ltrim(rtrim(t1.slab_id))='" & tempslabid & "';select tc2_stopper_ar_flow_q0,tc2_stopper_ar_flow_q1,tc2_stopper_ar_flow_q2,tc2_stopper_ar_flow_q3,tc2_stopper_ar_flow_q4,tc2_stopper_ar_flow_out,tc2_stopper_ar_flow_mean,tc1_cast_pos_mean,tc2_stopper_ar_flow_deviations from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB_EXT] t1 inner join T_TSK_SMS_SLAB_DEVIATIONS t3 on t1.slab_id=t3.slab_id where ltrim(rtrim(t1.slab_id))='" & tempslabid & "'"
                Dim ds4 As DataSet = objDataHandler.GetDataSetFromQuery(q)

                If ds4.Tables(0).Rows.Count > 0 AndAlso Not IsDBNull(ds4.Tables(0).Rows(0)(0)) Then
                    If ds4.Tables(0).Rows(0)("tc1_cast_pos_mean") > 0.5 Then
                        lit1.Text &= getBoxPlotString(ds4.Tables(0), ds4.Tables(0).Rows(0)(6), "d" & cnt, "d" & cnt, ymin, ymax)
                        If Not IsDBNull(ds4.Tables(0).Rows(0)("tc1_stopper_ar_flow_deviations")) AndAlso ds4.Tables(0).Rows(0)("tc1_stopper_ar_flow_deviations") > 0 Then
                            tbldata.Rows(6).Cells(cnt + 1).BgColor = "#FF0000" 'red background

                            tbldata.Rows(19).Cells(cnt + 1).BgColor = "#FF0000"
                            tbldata.Rows(0).Cells(cnt + 1).BgColor = "#FF0000"
                        End If
                    Else
                        lit1.Text &= getBoxPlotString(ds4.Tables(1), ds4.Tables(1).Rows(0)(6), "d" & cnt, "d" & cnt, ymin, ymax)
                        If Not IsDBNull(ds4.Tables(1).Rows(0)("tc2_stopper_ar_flow_deviations")) AndAlso ds4.Tables(1).Rows(0)("tc2_stopper_ar_flow_deviations") > 0 Then
                            tbldata.Rows(6).Cells(cnt + 1).BgColor = "#FF0000" 'red background

                            tbldata.Rows(19).Cells(cnt + 1).BgColor = "#FF0000"
                            tbldata.Rows(0).Cells(cnt + 1).BgColor = "#FF0000"
                        End If
                    End If
                    dataunavailflag = True
                Else

                    tbldata.Rows(6).Cells(cnt + 1).InnerText = "Data unavailable / awaited"

                    tbldata.Rows(6).Cells(cnt + 1).BgColor = "#FFFFFF"
                    tbldata.Rows(19).Cells(cnt + 1).BgColor = "#FFFFFF"
                End If

                'Stopper Argon Back Pressure bar
                ymin = "0"
                ymax = "2"

                ymin = arrMinMax(4, 0)
                ymax = arrMinMax(4, 1)

                q = "Select tc1_stopper_ar_pressure_q0,tc1_stopper_ar_pressure_q1,tc1_stopper_ar_pressure_q2,tc1_stopper_ar_pressure_q3,tc1_stopper_ar_pressure_q4,tc1_stopper_ar_pressure_out,tc1_stopper_ar_pressure_mean,tc1_cast_pos_mean,tc1_stopper_ar_pressure_deviations from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB_EXT] t1 inner join T_TSK_SMS_SLAB_DEVIATIONS t3 On t1.slab_id=t3.slab_id where ltrim(rtrim(t1.slab_id))='" & tempslabid & "';select tc2_stopper_ar_pressure_q0,tc2_stopper_ar_pressure_q1,tc2_stopper_ar_pressure_q2,tc2_stopper_ar_pressure_q3,tc2_stopper_ar_pressure_q4,tc2_stopper_ar_pressure_out,tc2_stopper_ar_pressure_mean,tc1_cast_pos_mean,tc2_stopper_ar_pressure_deviations from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB_EXT] t1  inner join T_TSK_SMS_SLAB_DEVIATIONS t3 on t1.slab_id=t3.slab_id where ltrim(rtrim(t1.slab_id))='" & tempslabid & "'"
                Dim ds5 As DataSet = objDataHandler.GetDataSetFromQuery(q)

                If ds5.Tables(0).Rows.Count > 0 AndAlso Not IsDBNull(ds5.Tables(0).Rows(0)(0)) Then
                    If ds5.Tables(0).Rows(0)("tc1_cast_pos_mean") > 0.5 Then
                        lit1.Text &= getBoxPlotString(ds5.Tables(0), ds5.Tables(0).Rows(0)(6), "e" & cnt, "e" & cnt, ymin, ymax)
                        If Not IsDBNull(ds5.Tables(0).Rows(0)("tc1_stopper_ar_pressure_deviations")) AndAlso ds5.Tables(0).Rows(0)("tc1_stopper_ar_pressure_deviations") > 0 Then
                            tbldata.Rows(7).Cells(cnt + 1).BgColor = "#FF0000" 'red background

                            tbldata.Rows(22).Cells(cnt + 1).BgColor = "#FF0000"
                            tbldata.Rows(0).Cells(cnt + 1).BgColor = "#FF0000"
                        End If
                    Else
                        lit1.Text &= getBoxPlotString(ds5.Tables(1), ds5.Tables(1).Rows(0)(6), "e" & cnt, "e" & cnt, ymin, ymax)
                        If Not IsDBNull(ds5.Tables(1).Rows(0)("tc2_stopper_ar_pressure_deviations")) AndAlso ds5.Tables(1).Rows(0)("tc2_stopper_ar_pressure_deviations") > 0 Then
                            tbldata.Rows(7).Cells(cnt + 1).BgColor = "#FF0000" 'red background

                            tbldata.Rows(22).Cells(cnt + 1).BgColor = "#FF0000"
                            tbldata.Rows(0).Cells(cnt + 1).BgColor = "#FF0000"
                        End If
                    End If

                    dataunavailflag = True
                Else

                    tbldata.Rows(7).Cells(cnt + 1).InnerText = "Data unavailable / awaited"

                    tbldata.Rows(7).Cells(cnt + 1).BgColor = "#FFFFFF"
                    tbldata.Rows(22).Cells(cnt + 1).BgColor = "#FFFFFF"
                End If

                'Tundish Weight tons
                ymin = "20"
                ymax = "75"

                ymin = arrMinMax(5, 0)
                ymax = arrMinMax(5, 1)

                q = "Select tundish_weight_q0/1000,tundish_weight_q1/1000,tundish_weight_q2/1000,tundish_weight_q3/1000,tundish_weight_q4/1000,tundish_weight_out,tundish_weight_mean/1000,tundish_weight_deviations from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB_EXT] t1 inner join T_TSK_SMS_SLAB_DEVIATIONS t3 On t1.slab_id=t3.slab_id where ltrim(rtrim(t1.slab_id))='" & tempslabid & "'"
                Dim ds6 As DataSet = objDataHandler.GetDataSetFromQuery(q)

                If ds6.Tables(0).Rows.Count > 0 AndAlso Not IsDBNull(ds6.Tables(0).Rows(0)(0)) Then
                    lit1.Text &= getBoxPlotString(ds6.Tables(0), ds6.Tables(0).Rows(0)(6), "f" & cnt, "f" & cnt, ymin, ymax)
                    If Not IsDBNull(ds6.Tables(0).Rows(0)("tundish_weight_deviations")) AndAlso ds6.Tables(0).Rows(0)("tundish_weight_deviations") > 0 Then
                        tbldata.Rows(8).Cells(cnt + 1).BgColor = "#FF0000" 'red background

                        tbldata.Rows(25).Cells(cnt + 1).BgColor = "#FF0000"
                        tbldata.Rows(0).Cells(cnt + 1).BgColor = "#FF0000"
                    End If
                    dataunavailflag = True
                Else
                    tbldata.Rows(8).Cells(cnt + 1).InnerText = "Data unavailable / awaited"

                    tbldata.Rows(8).Cells(cnt + 1).BgColor = "#FFFFFF"
                    tbldata.Rows(25).Cells(cnt + 1).BgColor = "#FFFFFF"
                End If

                'changeTextDataUnavailable(cnt + 1)
            Next

            For cnt As Integer = 0 To dt.Rows.Count - 1
                If tbldata.Rows(3).Cells(cnt + 1).InnerText = "Data unavailable / awaited" Then
                    tbldata.Rows(0).Cells(cnt + 1).BgColor = "#FFFFFF"
                End If

            Next

        End If
    End Sub

    'Sub changeTextDataUnavailable(ByVal col As Integer)
    '    If dataunavailflag = True Then
    '        For r As Integer = 3 To 8
    '            If tbldata.Rows(r).Cells(col).InnerText = "Data awaited" Then
    '                tbldata.Rows(r).Cells(col).InnerText = "Data unavailable"
    '            End If
    '        Next
    '    End If
    'End Sub
    Private Function GetLimits(ByVal c1 As String, ByVal c2 As String, ByVal outliers As String, ByVal slabids As String, ByRef ymin As String, ByRef ymax As String, Optional ByVal idx As Integer = -1) As Boolean
        Dim q As String = "Select min(" & c1 & "),max(" & c2 & ") from T_TSK_SMS_SLAB_EXT where slab_id In (" & slabids & ");Select " & outliers & ",tc1_cast_pos_mean from T_TSK_SMS_SLAB_EXT where slab_id In (" & slabids & ") And " & outliers & " <> 'NA';select tc1_cast_pos_mean  from T_TSK_SMS_SLAB_EXT where slab_id in (" & slabids & ")"
        Dim ds As DataSet = objDataHandler.GetDataSetFromQuery(q)

        If IsDBNull(ds.Tables(0).Rows(0)(0)) Then
            ds.Tables(0).Rows(0)(0) = 0
        End If
        If IsDBNull(ds.Tables(0).Rows(0)(1)) Then
            ds.Tables(0).Rows(0)(1) = 0
        End If

        If idx > -1 Then
            If idx Mod 2 > 0 Then
                If ds.Tables(2).Select("tc1_cast_pos_mean > 0.5").Count > 0 Then
                    ymin = ds.Tables(0).Rows(0)(0)
                    ymax = ds.Tables(0).Rows(0)(1)
                    Dim dv As DataView = ds.Tables(1).DefaultView
                    dv.RowFilter = "tc1_cast_pos_mean>0.5"
                    For r As Integer = 0 To dv.Count - 1
                        Dim outl() As String = dv(r)(0).ToString.Split(",")
                        For Each s As String In outl
                            If CDbl(s) < CDbl(ymin) Then
                                ymin = s
                            End If
                            If CDbl(s) > CDbl(ymax) Then
                                ymax = s
                            End If
                        Next
                    Next
                End If
            ElseIf idx Mod 2 = 0 Then
                If ds.Tables(2).Select("tc1_cast_pos_mean <= 0.5").Count > 0 Then
                    ymin = ds.Tables(0).Rows(0)(0)
                    ymax = ds.Tables(0).Rows(0)(1)
                    Dim dv As DataView = ds.Tables(1).DefaultView
                    dv.RowFilter = "tc1_cast_pos_mean<=0.5"
                    For r As Integer = 0 To dv.Count - 1
                        Dim outl() As String = dv(r)(0).ToString.Split(",")
                        For Each s As String In outl
                            If CDbl(s) < CDbl(ymin) Then
                                ymin = s
                            End If
                            If CDbl(s) > CDbl(ymax) Then
                                ymax = s
                            End If
                        Next
                    Next
                End If
            End If

        Else
            ymin = ds.Tables(0).Rows(0)(0)
            ymax = ds.Tables(0).Rows(0)(1)
            For r As Integer = 0 To ds.Tables(1).Rows.Count - 1
                Dim outl() As String = ds.Tables(1).Rows(r)(0).ToString.Split(",")
                For Each s As String In outl
                    If CDbl(s) < CDbl(ymin) Then
                        ymin = s
                    End If
                    If CDbl(s) > CDbl(ymax) Then
                        ymax = s
                    End If
                Next
            Next
        End If





        'condition to check tc2_### parameters
        Dim dr() As DataRow = ds.Tables(2).Select("tc1_cast_pos_mean <= 0.5")


        If dr.Count > 0 Then

            Return True
        End If

        Return False
        'ymin = (CDbl(ymin) \ 10) * 10
        'ymax = ((CDbl(ymax) \ 10) + 1) * 10
    End Function
    Private Function GetLimitsForMold(ByVal c1 As String, ByVal c2 As String, ByVal outliers As String, ByVal slabids As String, ByRef ymin As String, ByRef ymax As String, Optional ByVal idx As Integer = -1) As Boolean
        Dim q As String = "select min(" & c1 & "),max(" & c2 & ") from T_TSK_SMS_SLAB_DEVIATIONS where slab_id in (" & slabids & ");select " & outliers & ",tc1_cast_pos_mean from T_TSK_SMS_SLAB_EXT t1 inner join T_TSK_SMS_SLAB_DEVIATIONS t2 on t1.slab_id=t2.slab_id where t2.slab_id in (" & slabids & ") and " & outliers & " <> 'NA';"
        Dim ds As DataSet = objDataHandler.GetDataSetFromQuery(q)

        Try
            ymin = ds.Tables(0).Rows(0)(0)

        Catch ex As Exception
            ymin = "0"
        End Try
        Try
            ymax = ds.Tables(0).Rows(0)(1)
        Catch ex As Exception
            ymax = "0"
        End Try

        For r As Integer = 0 To ds.Tables(1).Rows.Count - 1
            Dim outl() As String = ds.Tables(1).Rows(r)(0).ToString.Split(",")
            For Each s As String In outl
                If CDbl(s) < CDbl(ymin) Then
                    ymin = s
                End If
                If CDbl(s) > CDbl(ymax) Then
                    ymax = s
                End If
            Next
        Next

        Return False
        'ymin = (CDbl(ymin) \ 10) * 10
        'ymax = ((CDbl(ymax) \ 10) + 1) * 10
    End Function

    Function getBoxPlotString(ByVal dt As DataTable, ByVal meanval As String, ByVal container As String, ByVal idx As String, ByVal ymin As String, ByVal ymax As String) As String
        Dim retval As String = ""
        'meanval = 0.5
        Try
            Dim data As String = "[" & dt.Rows(0)(0) & "," & dt.Rows(0)(1) & "," & dt.Rows(0)(2) & "," & dt.Rows(0)(3) & "," & dt.Rows(0)(4) & "]"
            Dim csvoutlier As String = dt.Rows(0)(5).ToString().Replace("NA", "")
            Dim outliers As String = ""
            If csvoutlier.Length > 0 Then
                For Each s As String In csvoutlier.Split(",")
                    If container.StartsWith("f") Then
                        outliers &= ",[0," & s / 1000 & "]" 'Outliers conversion of Tundish from Kg to Ton
                    Else
                        outliers &= ",[0," & s & "]"
                    End If

                Next
                outliers = "[" & outliers.Substring(1) & "]"
            Else
                outliers = "[]"
            End If


            ' retval &= "<script>var option" & idx & "={backgroundColor:'#FFF9CA',tooltip:{trigger:'item',position:'right',axisPointer:{type:'shadow'}},grid: {top:'10%',bottom:'10%',left: '10%',right: '10%',},xAxis:{type:'category',data:['0'],boundaryGap:true,show:!1},yAxis:{type:'value',show:!1},series:[{name:'boxplot',type:'boxplot',itemStyle:{borderColor:'#007ACC'},data:[" & data & "],tooltip:{formatter:function(a){console.log(a);return['upper: '+a.data[5],'Q3: '+a.data[4],'median: '+a.data[3],'Q1: '+a.data[2],'lower: '+a.data[1]].join('<br/>')}},markPoint:{symbol:'diamond',silent:true,label:{show:false},symbolSize:10,data:[{name:'mean',coord:[0," & meanval & "]}]}},{name:'outlier',type:'scatter',data:" & outliers & "}]}; var crt" & idx & "=document.getElementById('" & container & "');var mycrt" & idx & "=echarts.init(crt" & idx & ");mycrt" & idx & ".setOption(option" & idx & ");</script>"
            retval &= "<script>var option" & idx & "={toolbox: {show: true, itemSize: 8, top: -8, right: -7, feature: {dataZoom: {}}}, backgroundColor:'#FFF9CA',tooltip:{trigger:'item',position:'right',axisPointer:{type:'shadow'}},grid: {top:'5%',bottom:'5%',left: '27%',right: 0,},xAxis:{type:'category',data:['0'],boundaryGap:true,show:!1},yAxis:{type:'value', min:" & ymin & ", max:" & ymax & "},series:[{name:'boxplot',type:'boxplot',itemStyle:{borderColor:'#007ACC'},data:[" & data & "],tooltip:{formatter:function(a){return['upper: '+a.data[5],'Q3: '+a.data[4],'median: '+a.data[3],'Q1: '+a.data[2],'lower: '+a.data[1]].join('<br/>')}},markPoint:{symbol:'diamond',silent:true,label:{show:false},symbolSize:10,data:[{name:'mean',coord:[0," & meanval & "]}]}},{name:'outlier',type:'scatter',data:" & outliers & ", color: '#007ACC', symbolSize: 5}]}; var crt" & idx & "=document.getElementById('" & container & "');var mycrt" & idx & "=echarts.init(crt" & idx & ");mycrt" & idx & ".setOption(option" & idx & ");</script>"
            Return retval
        Catch ex As Exception
            Return ""
        End Try
    End Function

    Private Sub btnS1_Click(sender As Object, e As EventArgs) Handles btnS1.Click
        hfDataLoaded.Value = 1
        clearFields()
        divfilter.Style.Add("display", "none")
        hfStrand.Value = "1"
        btnS1.CssClass = "btn btn-primary"
        btnS2.CssClass = "btn btn-secondary"
        btnAnalysis.CssClass = "btn btn-secondary"
        'btnDisplay_Click()
        LoadDataInS12(tbldata, 1, lit1, "")
        LoadDataInS12(tbldatastrand2, 2, lit2, "_2")
        tbldatastrand2.Style.Add("display", "none")
        tbldata.Style.Add("display", "block")
    End Sub

    Private Sub btnS2_Click(sender As Object, e As EventArgs) Handles btnS2.Click
        hfDataLoaded.Value = 1
        clearFields()
        divfilter.Style.Add("display", "none")
        hfStrand.Value = "2"
        btnS2.CssClass = "btn btn-primary"
        btnS1.CssClass = "btn btn-secondary"
        btnAnalysis.CssClass = "btn btn-secondary"
        LoadDataInS12(tbldata, 1, lit1, "")
        LoadDataInS12(tbldatastrand2, 2, lit2, "_2")
        tbldatastrand2.Style.Add("display", "block")
        tbldata.Style.Add("display", "none")
    End Sub

    Private Sub btnAnalysis_Click(sender As Object, e As EventArgs) Handles btnAnalysis.Click
        clearFields()
        divfilter.Style.Add("display", "visible")
        hfStrand.Value = "0"
        PopulateDDL()
        btnS2.CssClass = "btn btn-secondary"
        btnS1.CssClass = "btn btn-secondary"
        btnAnalysis.CssClass = "btn btn-primary"
        hfDataLoaded.Value = "0"
        'btnDisplay_Click()
    End Sub

    Private Sub btnDisplay1_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        btnDisplay_Click()
    End Sub

    Private Sub ddlStrand_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlStrand.SelectedIndexChanged
        If flag Then
            PopulateSlabID()
            clearFields()
        End If
    End Sub
End Class
