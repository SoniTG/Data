﻿Imports System.Data
Imports System.IO
Imports System.Web.Services

Partial Class index
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Try
                Dim LD2_TABLE As DataTable = objController.mater_page("LD2")
                index_page(LD2_TABLE, LD2_lit, "c1")

                Dim LD_TABLE As DataTable = objController.mater_page("LD3")
                index_page(LD_TABLE, LD3_lit, "c1")

                Dim HSM_TABLE As DataTable = objController.mater_page("HSM")
                index_page(HSM_TABLE, hsm_lit, "c2")

                Dim CRM_TABLE As DataTable = objController.mater_page("CRM")
                index_page(CRM_TABLE, CRM_lit, "c3")

                Dim CRC_WEST_TABLE As DataTable = objController.mater_page("CRC WEST")
                index_page(CRC_WEST_TABLE, CRC_WEST, "c4")

                Dim TSK_TABLE As DataTable = objController.mater_page("TSK")
                index_page(TSK_TABLE, Tsk, "c4")

                Dim TSM_TABLE As DataTable = objController.mater_page("TSM")
                index_page(TSM_TABLE, TSM, "c4")

            Catch ex As Exception

            End Try
        End If
    End Sub

    'Sub index_page(ByVal data As DataTable, ByVal divid As Literal, ByVal colorclass As String)
    '    If divid.Equals(CRM_lit) Then
    '        Try
    '            Dim FMD_MAIN_DIV As DataTable = data.DefaultView.ToTable(True, "FMD_MAIN_DIV")
    '            Dim FMD_SUB_DIV As DataTable = data.DefaultView.ToTable(True, "FMD_SUB_DIV")
    '            Dim FMC_MAIN_HEADER As DataTable = data.DefaultView.ToTable(True, "FMC_MAIN_HEADER")
    '            Dim formation = Nothing
    '            Dim dv As DataView = data.DefaultView
    '            Dim temp1 As New DataTable
    '            Dim temp2 As New DataTable
    '            Dim temp3 As New DataTable
    '            Dim liclass = "list-group-item " & colorclass
    '            For FMD_MAIN As Integer = 0 To FMD_MAIN_DIV.Rows.Count - 1

    '                formation &= " <h4>" & FMD_MAIN_DIV.Rows(FMD_MAIN)(0) & "</h4><ul class=""list-group"">"

    '                For FMD_SUB As Integer = 0 To FMD_SUB_DIV.Rows.Count - 1
    '                    dv.RowFilter = "FMD_MAIN_DIV = '" & FMD_MAIN_DIV.Rows(FMD_MAIN)(0) & "' and FMD_SUB_DIV = '" & FMD_SUB_DIV.Rows(FMD_SUB)(0) & "'  "

    '                    formation &= "<li class='" & liclass & "'>" & FMD_SUB_DIV.Rows(FMD_SUB)(0) & ""
    '                    For FMC_head As Integer = 0 To FMC_MAIN_HEADER.Rows.Count - 1

    '                        dv.RowFilter = "FMD_MAIN_DIV = '" & FMD_MAIN_DIV.Rows(FMD_MAIN)(0) & "' and FMD_SUB_DIV = '" & FMD_SUB_DIV.Rows(FMD_SUB)(0) & "' and FMC_MAIN_HEADER = '" & FMC_MAIN_HEADER.Rows(FMC_head)(0) & "' "
    '                        If dv.Count <> 0 Then
    '                            formation &= "<ul class=""list-group""><li class=""list-group-item""><a id= '" & dv.Item(0)("FMD_DEFAULT_PAGE") & "," & dv.Item(0)("FMD_SUB_DIV") & "'  href='#'>" & dv.Item(0)("FMC_MAIN_HEADER") & "</a>"
    '                            formation &= "<ul class=""list-group"">"
    '                            For tem As Integer = 0 To dv.Count - 1
    '                                formation &= "<li class=""list-group-item""> <a id= '" & dv.Item(tem)("FMC_PAGENAME") & "," & dv.Item(0)("FMD_SUB_DIV") & "' href='#' '  >" & dv.Item(tem)("FMC_CHILD_HEADER") & "</a></li>"
    '                            Next
    '                            formation &= "  </ul>"
    '                            formation &= "</li> </ul>"
    '                            dv.RowFilter = ""
    '                        End If
    '                    Next
    '                    formation &= "</li>"
    '                Next

    '            Next
    '            formation &= "</ul> "
    '            divid.Text = formation

    '            Dim stri As String = formation
    '        Catch ex As Exception
    '            Throw ex
    '        End Try

    '    Else
    '        Try
    '            Dim liclass = "list-group-item " & colorclass
    '            Dim FMD_MAIN_DIV As DataTable = data.DefaultView.ToTable(True, "FMD_MAIN_DIV")
    '            Dim FMD_SUB_DIV As DataTable = data.DefaultView.ToTable(True, "FMD_SUB_DIV")
    '            Dim FMC_MAIN_HEADER As DataTable = data.DefaultView.ToTable(True, "FMC_MAIN_HEADER")
    '            Dim formation = Nothing
    '            Dim dv As DataView = data.DefaultView
    '            Dim temp1 As New DataTable
    '            Dim temp2 As New DataTable
    '            Dim temp3 As New DataTable

    '            For FMD_MAIN As Integer = 0 To FMD_MAIN_DIV.Rows.Count - 1

    '                formation &= " <h4>" & FMD_MAIN_DIV.Rows(FMD_MAIN)(0) & "</h4><ul class=""list-group"">"

    '                For FMD_SUB As Integer = 0 To FMD_SUB_DIV.Rows.Count - 1
    '                    dv.RowFilter = "FMD_MAIN_DIV = '" & FMD_MAIN_DIV.Rows(FMD_MAIN)(0) & "' and FMD_SUB_DIV = '" & FMD_SUB_DIV.Rows(FMD_SUB)(0) & "'  "

    '                    formation &= "<li class='" & liclass & "'>" & FMD_SUB_DIV.Rows(FMD_SUB)(0) & ""
    '                    For FMC_head As Integer = 0 To FMC_MAIN_HEADER.Rows.Count - 1

    '                        dv.RowFilter = "FMD_MAIN_DIV = '" & FMD_MAIN_DIV.Rows(FMD_MAIN)(0) & "' and FMD_SUB_DIV = '" & FMD_SUB_DIV.Rows(FMD_SUB)(0) & "' and FMC_MAIN_HEADER = '" & FMC_MAIN_HEADER.Rows(FMC_head)(0) & "' "
    '                        If dv.Count <> 0 Then
    '                            formation &= "<ul class=""list-group""><li class=""list-group-item""><a id= '" & dv.Item(0)("FMD_DEFAULT_PAGE") & "," & dv.Item(0)("FMD_SUB_DIV") & "'  href='#'>" & dv.Item(0)("FMC_MAIN_HEADER") & "</a>"
    '                            formation &= "<ul class=""list-group"">"
    '                            For tem As Integer = 0 To dv.Count - 1
    '                                formation &= "<li class=""list-group-item""> <a id= '" & dv.Item(tem)("FMC_PAGENAME") & "," & dv.Item(0)("FMD_SUB_DIV") & "' href='#' '  >" & dv.Item(tem)("FMC_CHILD_HEADER") & "</a></li>"
    '                            Next
    '                            formation &= "  </ul>"
    '                            formation &= "</li> </ul>"
    '                            dv.RowFilter = ""
    '                        End If
    '                    Next
    '                    formation &= "</li>"
    '                Next

    '            Next
    '            formation &= "</ul> "
    '            divid.Text = formation

    '            Dim stri As String = formation
    '        Catch ex As Exception
    '            Throw ex
    '        End Try
    '    End If

    'End Sub

    Sub index_page(ByVal data As DataTable, ByVal divid As Literal, ByVal colorclass As String)
        'If divid.Equals(CRM_lit) Then
        Try
            Dim FMD_MAIN_DIV As DataTable = data.DefaultView.ToTable(True, "FMD_MAIN_DIV", "FMD_SUB_DIV", "FMD_DEFAULT_PAGE")
            Dim FMD_SUB_DIV As DataTable = data.DefaultView.ToTable(True, "FMD_SUB_DIV")
                Dim FMC_MAIN_HEADER As DataTable = data.DefaultView.ToTable(True, "FMC_MAIN_HEADER")
                Dim formation = Nothing
                Dim dv As DataView = data.DefaultView
                Dim temp1 As New DataTable
                Dim temp2 As New DataTable
                Dim temp3 As New DataTable
                Dim liclass = "list-group-item " & colorclass
            If FMD_MAIN_DIV.Rows.Count > 0 Then

                formation &= " <h4>" & FMD_MAIN_DIV.Rows(0)(0) & "</h4><ul class=""list-group"">"

                'For FMD_SUB As Integer = 0 To FMD_SUB_DIV.Rows.Count - 1
                'dv.RowFilter = "FMD_MAIN_DIV = '" & FMD_MAIN_DIV.Rows(0)(0) & "'  "

                For i As Integer = 0 To FMD_MAIN_DIV.Rows.Count - 1
                    formation &= "<li class='" & liclass & "'><a id= '" & FMD_MAIN_DIV.Rows(i)("FMD_DEFAULT_PAGE") & "," & FMD_MAIN_DIV.Rows(i)("FMD_SUB_DIV") & "'  href='javascript:void(0)'>" & FMD_MAIN_DIV.Rows(i)("FMD_SUB_DIV") & "</a></li>"
                Next

                dv.RowFilter = ""
                formation &= "</ul> "
            End If

            divid.Text = formation

                Dim stri As String = formation
            Catch ex As Exception
                Throw ex
            End Try

        'Else
        '    Try
        '        Dim liclass = "list-group-item " & colorclass
        '        Dim FMD_MAIN_DIV As DataTable = data.DefaultView.ToTable(True, "FMD_MAIN_DIV")
        '        Dim FMD_SUB_DIV As DataTable = data.DefaultView.ToTable(True, "FMD_SUB_DIV")
        '        Dim FMC_MAIN_HEADER As DataTable = data.DefaultView.ToTable(True, "FMC_MAIN_HEADER")
        '        Dim formation = Nothing
        '        Dim dv As DataView = data.DefaultView
        '        Dim temp1 As New DataTable
        '        Dim temp2 As New DataTable
        '        Dim temp3 As New DataTable

        '        For FMD_MAIN As Integer = 0 To FMD_MAIN_DIV.Rows.Count - 1

        '            formation &= " <h4>" & FMD_MAIN_DIV.Rows(FMD_MAIN)(0) & "</h4><ul class=""list-group"">"

        '            For FMD_SUB As Integer = 0 To FMD_SUB_DIV.Rows.Count - 1
        '                dv.RowFilter = "FMD_MAIN_DIV = '" & FMD_MAIN_DIV.Rows(FMD_MAIN)(0) & "' and FMD_SUB_DIV = '" & FMD_SUB_DIV.Rows(FMD_SUB)(0) & "'  "

        '                For FMC_head As Integer = 0 To FMC_MAIN_HEADER.Rows.Count - 1

        '                    dv.RowFilter = "FMD_MAIN_DIV = '" & FMD_MAIN_DIV.Rows(FMD_MAIN)(0) & "' and FMD_SUB_DIV = '" & FMD_SUB_DIV.Rows(FMD_SUB)(0) & "' and FMC_MAIN_HEADER = '" & FMC_MAIN_HEADER.Rows(FMC_head)(0) & "' "
        '                    If dv.Count <> 0 Then
        '                        formation &= "<li class=""" & liclass & """><a id= '" & dv.Item(0)("FMD_DEFAULT_PAGE") & "," & dv.Item(0)("FMD_SUB_DIV") & "'  href='#'>" & dv.Item(0)("FMC_MAIN_HEADER") & "</a>"

        '                        formation &= "</li>"
        '                        dv.RowFilter = ""
        '                    End If
        '                Next

        '            Next

        '        Next
        '        formation &= "</ul> "
        '        divid.Text = formation

        '        Dim stri As String = formation
        '    Catch ex As Exception
        '        Throw ex
        '    End Try
        'End If

    End Sub

End Class
