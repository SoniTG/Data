﻿Imports System.Data
Imports System.IO

Imports System.Web.Services
Imports System.Data.SqlClient
Imports System.Drawing
Partial Class inspectionwidth_locationwise
    Inherits System.Web.UI.Page

    Dim objController As New Controller
    Dim objDataHandler As New DataHandler
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    txtDate_TextChanged()
                End If


            Catch ex As Exception

            End Try

        End If

        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                LoadDefectList(dtStart, dtEnd)
                LoadGradeTDC(dtStart, dtEnd)

                hfFrom.Value = dtStart
                hfTo.Value = dtEnd
                ''''''''''''''''''''''''''''''''''''

                ''''''''''''''''''''''''''''''''''''
                'DrawChart(dtStart, dtEnd, ddlDefName.SelectedItem.Text, ddlSurface.SelectedValue.ToString())
                Dim strDefect As String = getSelectedData(lstDefName)
                Dim strSeverity As String = getSelectedData(lstSeverity)
                Dim strGrade As String = getSelectedData(lstGrade)
                Dim strTDC As String = getSelectedData(lstTDC)
                Try
                    If strDefect.Length > 0 Then
                        strDefect = "'" & strDefect.Replace(",", "','") & "'"
                    End If

                    If strGrade.Length > 0 Then
                        strGrade = "'" & strGrade.Replace(",", "','") & "'"
                    End If

                    If strTDC.Length > 0 Then
                        strTDC = "'" & strTDC.Replace(",", "','") & "'"
                    End If

                Catch ex As Exception

                End Try
                'DrawChart(dtStart, dtEnd, ddlDefName.SelectedItem.Text, ddlSurface.SelectedValue.ToString())
                DrawChart(dtStart, dtEnd, strDefect, strSeverity, strGrade, strTDC)
            Catch ex As Exception

            End Try

        End If

    End Sub

    Sub LoadGradeTDC(ByVal fromDt As String, ByVal toDt As String)
        'Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("SELECT DISTINCT GRADE FROM RCL_JCAP_SURFACE_INSPECTION where date_create between '" & fromDt & "' and '" & toDt & "'   ORDER BY GRADE;SELECT DISTINCT TDC_NO FROM RCL_JCAP_SURFACE_INSPECTION where date_create between '" & fromDt & "' and '" & toDt & "' and  TDC_NO != '' ORDER BY TDC_NO")
        Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("SELECT DISTINCT GRADE FROM RCL_JCAP_SURFACE_INSPECTION  ORDER BY GRADE;SELECT DISTINCT TDC_NO FROM RCL_JCAP_SURFACE_INSPECTION where  TDC_NO != '' ORDER BY TDC_NO")
        Dim dt As DataTable = ds.Tables(0)
        Dim dt1 As DataTable = ds.Tables(1)
        lstGrade.DataSource = dt
        lstGrade.DataTextField = "GRADE"
        lstGrade.DataValueField = "GRADE"
        lstGrade.DataBind()

        lstTDC.DataSource = dt1
        lstTDC.DataTextField = "TDC_NO"
        lstTDC.DataValueField = "TDC_NO"
        lstTDC.DataBind()

        For Each lst As ListItem In lstGrade.Items
            lst.Selected = True
        Next

        For Each lst As ListItem In lstTDC.Items
            lst.Selected = True
        Next

    End Sub


    Sub LoadDefectList(ByVal fromDt As String, ByVal toDt As String)
        ' Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT DISTINCT Defect_Name FROM RCL_JCAP_SURFACE_INSPECTION where date_create between '" & fromDt & "' and '" & toDt & "' AND Defect_Name != '' ORDER BY DEFECT_NAME").Tables(0)
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("SELECT DISTINCT Defect_Name FROM RCL_JCAP_SURFACE_INSPECTION where  Defect_Name != '' ORDER BY DEFECT_NAME").Tables(0)
        lstDefName.DataSource = dt
        lstDefName.DataTextField = "Defect_Name"
        lstDefName.DataValueField = "Defect_Name"
        lstDefName.DataBind()

        If dt.Rows.Count > 0 Then
		try
            lstDefName.Items.FindByText("SCUMD").Selected = True
Catch ex As Exception

            End Try
        End If
    End Sub

    Sub DrawChart(ByVal FromDate As String, ByVal ToDate As String, ByVal DefectName As String, ByVal Severity As String, ByVal Grade As String, ByVal TDC As String)
        Try
            Labelheader.Text = "Width_wise Defect Data w.r.t " & lstProcessingline.SelectedItem.ToString
            Dim strFromDate As String = FromDate
            Dim strToDate As String = ToDate

            'If ymin.Text = Nothing Then
            '    ymin.Text = 0
            '    ymax.Text = 10
            'End If
            Dim process_a As String = Nothing
            Dim process_b As String = Nothing
            Dim slab_rev As String = objController.slab_reversal(lstProcessingline.SelectedItem.Text)
            Dim s As String() = slab_rev.Split(New Char() {","c})
            ''BOTTOM_PLOT
            process_a = s(0)
            ''TOP_PLOT
            process_b = s(1)
            Dim dt As DataTable = objController.GetDataForInspectionByWidth_coilwise(0, strFromDate, strToDate, DefectName, process_a.Substring(0, 1), mesrlist.SelectedItem.ToString, lstProcessingline.SelectedValue.ToString, groupby:=lstgroupby.SelectedItem.Text, Severity:=Severity, grade:=Grade, tdcno:=TDC)
            'Dim yVal1() As Decimal
            'yVal1 = (From row In dt Select col = CDec(row("TotalDefect"))).ToArray()
            'Dim y_min1 As String = yVal1.Min() - (10 / 100 * yVal1.Min)
            'Dim y_max1 As String = yVal1.Max() + (10 / 100 * yVal1.Max)

            Dim dt1 As DataTable = objController.GetDataForInspectionByWidth_coilwise(0, strFromDate, strToDate, DefectName, process_b.Substring(0, 1), mesrlist.SelectedItem.ToString, lstProcessingline.SelectedValue.ToString, groupby:=lstgroupby.SelectedItem.Text, Severity:=Severity, grade:=Grade, tdcno:=TDC)
            'Dim yVal2() As Decimal
            'yVal2 = (From row In dt Select col = CDec(row("TotalDefect"))).ToArray()
            'Dim y_min2 As String = yVal2.Min() - (10 / 100 * yVal2.Min)
            'Dim y_max2 As String = yVal2.Max() + (10 / 100 * yVal2.Max)
            'If y_min1 < y_min2 Then
            '    ymin.Text = y_min1
            'Else
            '    ymin.Text = y_min2
            'End If
            'If y_max1 < y_max2 Then
            '    ymax.Text = y_max2
            'Else
            '    ymax.Text = y_max1
            'End If
            Dim distinct_date As DataTable = objController.GetDataForInspectionByWidth_coilwise(1, strFromDate, strToDate, DefectName, "", mesrlist.SelectedItem.ToString, lstProcessingline.SelectedValue.ToString, groupby:=lstgroupby.SelectedItem.Text, Severity:=Severity, grade:=Grade, tdcno:=TDC, dist_date:="dist_date")
            If dt.Rows.Count > 0 Then
                objController.stackgraph_inspviz(lstProcessingline.SelectedItem.Text, distinct_date, dt, Lit1, "container", mesrlist.SelectedItem.ToString, lstgroupby.SelectedItem.Text, "BOTTOM", defectName:=DefectName.Replace("'", ""), grade:=Grade, tdcno:=TDC, indx:=1, min_value:=ymin.Text, max_value:=ymax.Text)
                objController.stackgraph_inspviz(lstProcessingline.SelectedItem.Text, distinct_date, dt1, Lit2, "container1", mesrlist.SelectedItem.ToString, lstgroupby.SelectedItem.Text, "TOP", defectName:=DefectName.Replace("'", ""), grade:=Grade, tdcno:=TDC, indx:=2, min_value:=ymin.Text, max_value:=ymax.Text)

            Else
                Lit1.Text = ""
                Lit2.Text = ""
            End If



        Catch ex As Exception

        End Try
    End Sub
    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try
            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            'LoadDefectList(dtStart, dtEnd)
            'LoadGradeTDC(dtStart, dtEnd)
            'DrawChart(dtStart, dtEnd, ddlDefName.SelectedItem.Text, ddlSurface.SelectedValue.ToString())
            Dim strDefect As String = getSelectedData(lstDefName)
            Dim strSeverity As String = getSelectedData(lstSeverity)
            Dim strGrade As String = getSelectedData(lstGrade)
            Dim strTDC As String = getSelectedData(lstTDC)

            If strDefect.Length > 0 Then
                strDefect = "'" & strDefect.Replace(",", "','") & "'"
            End If

            If strGrade.Length > 0 Then
                strGrade = "'" & strGrade.Replace(",", "','") & "'"
            End If

            If strTDC.Length > 0 Then
                strTDC = "'" & strTDC.Replace(",", "','") & "'"
            End If

            'DrawChart(dtStart, dtEnd, ddlDefName.SelectedItem.Text, ddlSurface.SelectedValue.ToString())
            DrawChart(dtStart, dtEnd, strDefect, strSeverity, strGrade, strTDC)
        Catch ex As Exception

        End Try

    End Sub

    Function getSelectedData(ByRef lst As ListBox) As String
        Dim retVal As String = ""
        Try
            For Each lstItem As ListItem In lst.Items
                If lstItem.Selected = True Then
                    retVal &= "," & lstItem.Text & ""
                End If
            Next

        Catch ex As Exception

        End Try

        If retVal.Length > 0 Then
            Return retVal.Substring(1)
        Else
            Return retVal
        End If


        'Return (retVal)
    End Function

    Protected Sub btnGo_Click(sender As Object, e As System.EventArgs) Handles btnGo.Click
        Dim dtStart As String = hfFrom.Value
        Dim dtEnd As String = hfTo.Value
        'LoadDefectList(dtStart, dtEnd)

        Dim strDefect As String = getSelectedData(lstDefName)
        Dim strSeverity As String = getSelectedData(lstSeverity)
        Dim strGrade As String = getSelectedData(lstGrade)
        Dim strTDC As String = getSelectedData(lstTDC)

        If strDefect.Length > 0 Then
            strDefect = "'" & strDefect.Replace(",", "','") & "'"
        End If

        If strGrade.Length > 0 Then
            strGrade = "'" & strGrade.Replace(",", "','") & "'"
        End If

        If strTDC.Length > 0 Then
            strTDC = "'" & strTDC.Replace(",", "','") & "'"
        End If

        'DrawChart(dtStart, dtEnd, ddlDefName.SelectedItem.Text, ddlSurface.SelectedValue.ToString())
        DrawChart(dtStart, dtEnd, strDefect, strSeverity, strGrade, strTDC)
    End Sub
    <WebMethod()>
    Public Shared Function GetAutoCompleteData(ByVal username As String) As List(Of String)
        Dim result As List(Of String) = New List(Of String)()

        Using con As SqlConnection = New SqlConnection("server=176.0.0.60\LPTGSQLDEV;database=FP_PROCESS_DATA;uid=153521;pwd=Welcome@135")

            Using cmd As SqlCommand = New SqlCommand("select distinct top 10 Mother_Coil from RCL_JCAP_SURFACE_INSPECTION  inner join CRM_HR_CR_RLN on Mother_Coil = CR_COIL_ID where Mother_Coil  LIKE '%'+@SearchText+'%'", con)
                con.Open()
                cmd.Parameters.AddWithValue("@SearchText", username)
                Dim dr As SqlDataReader = cmd.ExecuteReader()

                While dr.Read()
                    result.Add(String.Format("{0}", dr("Mother_Coil")))
                End While

                Return result
            End Using
        End Using
    End Function

    

    Protected Sub Axis_btn_Click(sender As Object, e As System.EventArgs) Handles Axis_btn.Click
        Dim dtStart As String = hfFrom.Value
        Dim dtEnd As String = hfTo.Value
        'LoadDefectList(dtStart, dtEnd)

        Dim strDefect As String = getSelectedData(lstDefName)
        Dim strSeverity As String = getSelectedData(lstSeverity)
        Dim strGrade As String = getSelectedData(lstGrade)
        Dim strTDC As String = getSelectedData(lstTDC)

        If strDefect.Length > 0 Then
            strDefect = "'" & strDefect.Replace(",", "','") & "'"
        End If

        If strGrade.Length > 0 Then
            strGrade = "'" & strGrade.Replace(",", "','") & "'"
        End If

        If strTDC.Length > 0 Then
            strTDC = "'" & strTDC.Replace(",", "','") & "'"
        End If

        'DrawChart(dtStart, dtEnd, ddlDefName.SelectedItem.Text, ddlSurface.SelectedValue.ToString())
        DrawChart(dtStart, dtEnd, strDefect, strSeverity, strGrade, strTDC)
    End Sub
End Class
