﻿Imports System.Data
Imports System.IO

Partial Class labdataview
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
            txtFrom.Text = Now.AddDays(-30).ToString("yyyy-MM-dd HH:mm:ss")
            'txtFrom.Text = Now.AddMonths(-4).ToString("yyyy-MM-dd HH:mm:ss")
            txtTo.Text = Now.ToString("yyyy-MM-dd HH:mm:ss")
            Dim arrFilters() As String = objController.GetFilterColumnArray("FP_MASTER_DATA", Session("SubDivId"))
            LoadFilterColumns(ddlFilterCol1, arrFilters)
            LoadFilterColumns(ddlFilterCol2, arrFilters)
            LoadFilterColumns(ddlFilterCol3, arrFilters)
            LoadFilterColumns(ddlFilterCol4, arrFilters)
            LoadFilterColumns(ddlFilterCol5, arrFilters)
            LoadFilterColumns(ddlFilterCol6, arrFilters)
            'LoadColourColumn(ddlColour1)
            'LoadColourColumn(ddlSecColour)

            lblChartTitle.Visible = False
            txtChartTitle.Visible = False
            ddlColour1.Visible = False
            Label2.Visible = False
            lblSecChartTitle.Visible = False
            txtSecChartTitle.Visible = False
            ddlSecColour.Visible = False
            lblSecColour.Visible = False

            If Session("SelectVal") = "CGL" Then
               
                
            ElseIf Session("SelectVal") = "CGL1" Then
                ddlFilterCol1.SelectedIndex = 1
                ddlFilterCol1_SelectedIndexChanged(sender, e)
                ddlFilterColVal1.Items.FindByText("G").Selected = True
                ddlFilterCol1.Enabled = False
                ddlFilterColVal1.Enabled = False

                ddlFilterCol4.SelectedIndex = 1
                ddlFilterCol4_SelectedIndexChanged(sender, e)
                ddlFilterColVal4.Items.FindByText("G").Selected = True
                ddlFilterCol4.Enabled = False
                ddlFilterColVal4.Enabled = False


                ddlFilterCol1.Visible = False
                ddlFilterColVal1.Visible = False
                ddlFilterCol4.Visible = False
                ddlFilterColVal4.Visible = False

                ddlFilterCol2.Items.Remove("CLR_PROCESS_LINE")
                ddlFilterCol3.Items.Remove("CLR_PROCESS_LINE")
                ddlFilterCol5.Items.Remove("CLR_PROCESS_LINE")
                ddlFilterCol6.Items.Remove("CLR_PROCESS_LINE")

            ElseIf Session("SelectVal") = "CGL2" Then
                ddlFilterCol1.SelectedIndex = 1
                ddlFilterCol1_SelectedIndexChanged(sender, e)
                ddlFilterColVal1.Items.FindByText("L").Selected = True
                ddlFilterCol1.Enabled = False
                ddlFilterColVal1.Enabled = False

                ddlFilterCol4.SelectedIndex = 1
                ddlFilterCol4_SelectedIndexChanged(sender, e)
                ddlFilterColVal4.Items.FindByText("L").Selected = True
                ddlFilterCol4.Enabled = False
                ddlFilterColVal4.Enabled = False

                ddlFilterCol1.Visible = False
                ddlFilterColVal1.Visible = False
                ddlFilterCol4.Visible = False
                ddlFilterColVal4.Visible = False

                ddlFilterCol2.Items.Remove("CLR_PROCESS_LINE")
                ddlFilterCol3.Items.Remove("CLR_PROCESS_LINE")
                ddlFilterCol5.Items.Remove("CLR_PROCESS_LINE")
                ddlFilterCol6.Items.Remove("CLR_PROCESS_LINE")
                
            ElseIf Session("SelectVal") = "PLTCM" Then
                ddlFilterCol1.SelectedIndex = 1
                ddlFilterCol1_SelectedIndexChanged(sender, e)
                ddlFilterColVal1.Items.FindByText("P").Selected = True
                ddlFilterCol1.Enabled = False
                ddlFilterColVal1.Enabled = False

                ddlFilterCol4.SelectedIndex = 1
                ddlFilterCol4_SelectedIndexChanged(sender, e)
                ddlFilterColVal4.Items.FindByText("P").Selected = True
                ddlFilterCol4.Enabled = False
                ddlFilterColVal4.Enabled = False

                ddlFilterCol1.Visible = False
                ddlFilterColVal1.Visible = False
                ddlFilterCol4.Visible = False
                ddlFilterColVal4.Visible = False

                ddlFilterCol2.Items.Remove("CLR_PROCESS_LINE")
                ddlFilterCol3.Items.Remove("CLR_PROCESS_LINE")
                ddlFilterCol5.Items.Remove("CLR_PROCESS_LINE")
                ddlFilterCol6.Items.Remove("CLR_PROCESS_LINE")
               
            ElseIf Session("SelectVal") = "ECL" Then

            End If
        End If
    End Sub

    Sub LoadColourColumn(ByVal Dropdown As DropDownList)
        Dim dt As DataTable = objController.LoadColourColumns(Session("TableName"))
        Dropdown.DataSource = dt
        Dropdown.DataTextField = "column_name"
        Dropdown.DataValueField = "data_type"
        Dropdown.DataBind()
        'ddl_Colour.Items.Insert(0, "Select")
        Dropdown.Items.FindByText(Session("DefaultColourCol")).Selected = True
    End Sub

    Sub LoadFilterColumns(ByVal Dropdown As DropDownList, ByVal arr() As String)
        Dropdown.DataSource = arr
        Dropdown.DataBind()
        Dropdown.Items.Insert(0, "Select")
        Dropdown.SelectedIndex = 0
    End Sub

    'Sub DrawChart(ByVal Filter As String, ByVal ChartTitle As String, ByVal val As String, ByVal lita As Literal, ByVal litb As Literal)
    '    Try
    '        'Lit1.Text = ""
    '        'Lit2.Text = ""
    '        'Lit3.Text = ""
    '        'Lit4.Text = ""
    '        lita.Text = ""
    '        litb.Text = ""
    '        Dim strfrmDt As String = txtFrom.Text.Trim
    '        Dim strToDt As String = txtTo.Text.Trim

    '        Dim dt As DataTable = objController.GetWetChemicalTestData(Session("TableName"), strfrmDt, strToDt, Session("DateColumn"), Filter, "CLR_PARAM_MIN")
    '        Dim dv As DataView = dt.DefaultView
    '        If val = "first" Then
    '            dv.RowFilter = ddlFilterCol2.Text & " IN (" & ddlFilterColVal2.Text & ")"
    '        ElseIf val = "second" Then
    '            dv.RowFilter = ddlFilterCol5.Text & " IN (" & ddlFilterColVal5.Text & ")"
    '        End If
    '        Dim dtAL As DataTable = dv.ToTable
    '        ViewState("dtAL") = dtAL

    '        Dim dtFE As New DataTable
    '        dt.DefaultView.RowFilter = String.Empty
    '        If ddlFilterCol3.SelectedIndex > 0 Then
    '            dv = dt.DefaultView
    '            dv.RowFilter = ddlFilterCol3.Text & " IN (" & ddlFilterColVal3.Text & ")"
    '            dtFE = dv.ToTable
    '            ViewState("dtFE") = dtFE
    '        End If
    '        If val = "first" Then
    '            If ViewState("HaveY2AxisTop") = True Then
    '                Dim y1Values(), y2Values() As String
    '                y1Values = (From row In dtAL Select col = row(Session("YValueColumn")).ToString).ToArray
    '                y2Values = (From row In dtFE Select col = row(Session("YValueColumn")).ToString).ToArray

    '                Dim y1_min As String = y1Values.Min() - (10 / 100 * y1Values.Min)
    '                Dim y1_max As String = y1Values.Max() + (10 / 100 * y1Values.Max)
    '                Dim y2_min As String = y2Values.Min() - (10 / 100 * y2Values.Min)
    '                Dim y2_max As String = y2Values.Max() + (10 / 100 * y2Values.Max)
    '                objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), y1_min, y1_max, y2_min, y2_max, Lit1, "container", "plot1", ChartTitle, ddlFilterColVal2.Text, ddlFilterColVal3.Text, "priData", "secData", ddlFilterColVal2.SelectedItem.Text, ddlFilterColVal3.SelectedItem.Text)
    '                'objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), Session("YValueColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, ddlFilterColVal2.Text, ddlFilterColVal3.Text, "dataPri", "dataSec")
    '            Else
    '                objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
    '            End If
    '            objController.PlotBoxPlotChart(dt, Session("YValueColumn"), Lit3, "container1", "plot11", "dataA", "CLR_PARAM_MIN", "outlierDataA", ChartTitle, "", "Avg_A")
    '        ElseIf val = "second" Then
    '            If ViewState("HaveY2AxisTop") = True Then
    '                Dim y1Values(), y2Values() As String
    '                y1Values = (From row In dtAL Select col = row(Session("YValueColumn")).ToString).ToArray
    '                y2Values = (From row In dtFE Select col = row(Session("YValueColumn")).ToString).ToArray

    '                Dim y1_min As String = y1Values.Min() - (10 / 100 * y1Values.Min)
    '                Dim y1_max As String = y1Values.Max() + (10 / 100 * y1Values.Max)
    '                Dim y2_min As String = y2Values.Min() - (10 / 100 * y2Values.Min)
    '                Dim y2_max As String = y2Values.Max() + (10 / 100 * y2Values.Max)
    '                objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), y1_min, y1_max, y2_min, y2_max, Lit2, "container2", "plot2", ChartTitle, ddlFilterColVal5.Text, ddlFilterColVal6.Text, "priData1", "secData1", ddlFilterColVal5.SelectedItem.Text, ddlFilterColVal6.SelectedItem.Text)
    '                'objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), Session("YValueColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, ddlFilterColVal2.Text, ddlFilterColVal3.Text, "dataPri", "dataSec")
    '            Else
    '                objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit2, "container2", "plot2", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
    '            End If
    '            objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit4, "container3", "plot22", "dataB", "CLR_PARAM_MIN", "outlierDataB", ChartTitle, "", "Avg_B")
    '            '--------------

    '            'objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit2, "container2", "plot2", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
    '            'objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit4, "container3", "plot22", "dataB", "CLR_PARAM_MIN", "outlierDataB", ChartTitle, "", "Avg_B")
    '        ElseIf val = "" Then
    '            objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
    '            objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit3, "container1", "plot11", "dataA", "CLR_PARAM_MIN", "outlierDataA", ChartTitle, "", "Avg_A")

    '            objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit2, "container2", "plot2", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
    '            objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit4, "container3", "plot22", "dataB", "CLR_PARAM_MIN", "outlierDataB", ChartTitle, "", "Avg_B")
    '        End If
    '        'PlotLineChart(dtAL, dtFE, ChartTitle)
    '        'PlotBoxPlot(dtAL, dtFE, ChartTitle)
    '    Catch ex As Exception

    '    End Try
    'End Sub

    Sub DrawChartTop(ByVal Filter As String, ByVal ChartTitle As String, ByVal val As String, ByVal lita As Literal, ByVal litb As Literal)
        Try
            'Lit1.Text = ""
            'Lit2.Text = ""
            'Lit3.Text = ""
            'Lit4.Text = ""
            lita.Text = ""
            litb.Text = ""
            'ChartTitle = "Trend of pot Al & Fe"
            'ChartTitle = "Trend of Eff. Aluminium & Eff. Iron"
            Dim strfrmDt As String = txtFrom.Text.Trim
            Dim strToDt As String = txtTo.Text.Trim

            Dim dt As DataTable = objController.GetWetChemicalTestData(Session("TableName"), strfrmDt, strToDt, Session("DateColumn"), Filter, "CLR_PARAM_MIN")
            Dim dv As DataView = dt.DefaultView
            If val = "first" Then
                dv.RowFilter = ddlFilterCol2.Text & " IN (" & ddlFilterColVal2.Text & ")"
            End If
            Dim dtAL As DataTable = dv.ToTable
            ViewState("dtAL") = dtAL

            Dim dtFE As New DataTable
            dt.DefaultView.RowFilter = String.Empty
            If ddlFilterColVal3.SelectedIndex >= 0 And ddlFilterCol3.SelectedItem.Text <> "Select" Then
                dv = dt.DefaultView
                dv.RowFilter = ddlFilterCol3.Text & " IN (" & ddlFilterColVal3.Text & ")"
                dtFE = dv.ToTable
                ViewState("dtFE") = dtFE
            End If
            If val = "first" Then
                If ViewState("HaveY2AxisTop") = True Then
                    Dim y1Values(), y2Values() As String
                    y1Values = (From row In dtAL Select col = row(Session("YValueColumn")).ToString).ToArray
                    y2Values = (From row In dtFE Select col = row(Session("YValueColumn")).ToString).ToArray

                    Dim y1_min As String = y1Values.Min() - (10 / 100 * y1Values.Min)
                    Dim y1_max As String = y1Values.Max() + (10 / 100 * y1Values.Max)
                    Dim y2_min As String = y2Values.Min() - (10 / 100 * y2Values.Min)
                    Dim y2_max As String = y2Values.Max() + (10 / 100 * y2Values.Max)
                    If Session("SelectVal") = "CGL1" Or Session("SelectVal") = "CGL" Or Session("SelectVal") = "PLTCM" Then
                        'objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), y1_min, y1_max, y2_min, y2_max, Lit1, "container", "plot1", ChartTitle, ddlFilterColVal2.Text, ddlFilterColVal3.Text, "priData", "secData", ddlFilterColVal2.SelectedItem.Text, ddlFilterColVal3.SelectedItem.Text)
                        objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), y1_min, y1_max, y2_min, y2_max, Lit1, "container", "plot1", ChartTitle, ddlFilterColVal2.Text, ddlFilterColVal3.Text, "priData", "secData", "% Al", "% Fe")
                    ElseIf Session("SelectVal") = "CGL2" Then
                        'objController.PlotLineChartWithSecondaryYAxisCampaignwise(dt, Session("DateColumn"), y1_min, y1_max, y2_min, y2_max, Lit1, "container", "plot1", ChartTitle, ddlFilterColVal2.Text, ddlFilterColVal3.Text, "priData", "secData", ddlFilterColVal2.SelectedItem.Text, ddlFilterColVal3.SelectedItem.Text)
                        objController.PlotLineChartWithSecondaryYAxisCampaignwise(dt, Session("DateColumn"), y1_min, y1_max, y2_min, y2_max, Lit1, "container", "plot1", ChartTitle, ddlFilterColVal2.Text, ddlFilterColVal3.Text, "priData", "secData", "% Al", "% Fe")
                    End If
                    'objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), y1_min, y1_max, y2_min, y2_max, Lit1, "container", "plot1", ChartTitle, ddlFilterColVal2.Text, ddlFilterColVal3.Text, "priData", "secData", ddlFilterColVal2.SelectedItem.Text, ddlFilterColVal3.SelectedItem.Text)
                    'objController.PlotLineChartWithSecondaryYAxisCampaignwise(dt, Session("DateColumn"), y1_min, y1_max, y2_min, y2_max, Lit1, "container", "plot1", ChartTitle, ddlFilterColVal2.Text, ddlFilterColVal3.Text, "priData", "secData", ddlFilterColVal2.SelectedItem.Text, ddlFilterColVal3.SelectedItem.Text)
                    'objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), Session("YValueColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, ddlFilterColVal2.Text, ddlFilterColVal3.Text, "dataPri", "dataSec")
                Else
                    objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
                End If
                'Commented by pratik
                'objController.PlotBoxPlotChart(dt, Session("YValueColumn"), Lit3, "container1", "plot11", "dataA", "CLR_PARAM_MIN", "outlierDataA", ChartTitle, "", "Avg_A")
                Dim Campaign As String = ""
                If ddlFilterColVal2.SelectedIndex >= 0 And ddlFilterCol2.SelectedItem.Text <> "Select" Then
                    Campaign = ddlFilterColVal2.SelectedItem.Text
                End If
                If ddlFilterColVal3.SelectedIndex >= 0 And ddlFilterCol3.SelectedItem.Text <> "Select" Then
                    Campaign &= "," & ddlFilterColVal3.SelectedItem.Text
                End If
                objController.PlotBoxPlotChart1(dt, Session("YValueColumn"), Lit3, "container1", "plot11", "dataA", "CLR_PARAM_MIN", "outlierDataA", ChartTitle, "", "Avg_A", Campaign)

                'ElseIf val = "second" Then
                'If ViewState("HaveY2AxisTop") = True Then
                '    Dim y1Values(), y2Values() As String
                '    y1Values = (From row In dtAL Select col = row(Session("YValueColumn")).ToString).ToArray
                '    y2Values = (From row In dtFE Select col = row(Session("YValueColumn")).ToString).ToArray

                '    Dim y1_min As String = y1Values.Min() - (10 / 100 * y1Values.Min)
                '    Dim y1_max As String = y1Values.Max() + (10 / 100 * y1Values.Max)
                '    Dim y2_min As String = y2Values.Min() - (10 / 100 * y2Values.Min)
                '    Dim y2_max As String = y2Values.Max() + (10 / 100 * y2Values.Max)
                '    objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), y1_min, y1_max, y2_min, y2_max, Lit2, "container2", "plot2", ChartTitle, ddlFilterColVal5.Text, ddlFilterColVal6.Text, "priData1", "secData1", ddlFilterColVal5.SelectedItem.Text, ddlFilterColVal6.SelectedItem.Text)
                '    'objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), Session("YValueColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, ddlFilterColVal2.Text, ddlFilterColVal3.Text, "dataPri", "dataSec")
                'Else
                '    objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit2, "container2", "plot2", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
                'End If
                'objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit4, "container3", "plot22", "dataB", "CLR_PARAM_MIN", "outlierDataB", ChartTitle, "", "Avg_B")
                '--------------

                'objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit2, "container2", "plot2", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
                'objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit4, "container3", "plot22", "dataB", "CLR_PARAM_MIN", "outlierDataB", ChartTitle, "", "Avg_B")
                'ElseIf val = "" Then
                '    objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
                '    objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit3, "container1", "plot11", "dataA", "CLR_PARAM_MIN", "outlierDataA", ChartTitle, "", "Avg_A")

                '    objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit2, "container2", "plot2", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
                '    objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit4, "container3", "plot22", "dataB", "CLR_PARAM_MIN", "outlierDataB", ChartTitle, "", "Avg_B")
            End If
        Catch ex As Exception

        End Try
    End Sub

    Sub DrawChartBottom(ByVal Filter As String, ByVal ChartTitle As String, ByVal val As String, ByVal lita As Literal, ByVal litb As Literal)
        Try
            'Lit1.Text = ""
            'Lit2.Text = ""
            'Lit3.Text = ""
            'Lit4.Text = ""
            lita.Text = ""
            litb.Text = ""
            Dim strfrmDt As String = txtFrom.Text.Trim
            Dim strToDt As String = txtTo.Text.Trim

            Dim dt As DataTable = objController.GetWetChemicalTestData(Session("TableName"), strfrmDt, strToDt, Session("DateColumn"), Filter, "CLR_PARAM_MIN")
            Dim dv As DataView = dt.DefaultView
            If val = "second" Then
                dv.RowFilter = ddlFilterCol5.Text & " IN (" & ddlFilterColVal5.Text & ")"
            End If
            Dim dtAL As DataTable = dv.ToTable
            ViewState("dtAL") = dtAL

            Dim dtFE As New DataTable
            dt.DefaultView.RowFilter = String.Empty
            If ddlFilterColVal6.SelectedIndex >= 0 And ddlFilterCol6.SelectedItem.Text <> "Select" Then
                dv = dt.DefaultView
                dv.RowFilter = ddlFilterCol6.Text & " IN (" & ddlFilterColVal6.Text & ")"
                dtFE = dv.ToTable
                ViewState("dtFE") = dtFE
            End If
            'If val = "first" Then
            '    If ViewState("HaveY2AxisTop") = True Then
            '        Dim y1Values(), y2Values() As String
            '        y1Values = (From row In dtAL Select col = row(Session("YValueColumn")).ToString).ToArray
            '        y2Values = (From row In dtFE Select col = row(Session("YValueColumn")).ToString).ToArray

            '        Dim y1_min As String = y1Values.Min() - (10 / 100 * y1Values.Min)
            '        Dim y1_max As String = y1Values.Max() + (10 / 100 * y1Values.Max)
            '        Dim y2_min As String = y2Values.Min() - (10 / 100 * y2Values.Min)
            '        Dim y2_max As String = y2Values.Max() + (10 / 100 * y2Values.Max)
            '        objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), y1_min, y1_max, y2_min, y2_max, Lit1, "container", "plot1", ChartTitle, ddlFilterColVal2.Text, ddlFilterColVal3.Text, "priData", "secData", ddlFilterColVal2.SelectedItem.Text, ddlFilterColVal3.SelectedItem.Text)
            '        'objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), Session("YValueColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, ddlFilterColVal2.Text, ddlFilterColVal3.Text, "dataPri", "dataSec")
            '    Else
            '        objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
            '    End If
            '    objController.PlotBoxPlotChart(dt, Session("YValueColumn"), Lit3, "container1", "plot11", "dataA", "CLR_PARAM_MIN", "outlierDataA", ChartTitle, "", "Avg_A")
            'ElseIf val = "second" Then
            If val = "second" Then
                If ViewState("HaveY2AxisBottom") = True Then
                    Dim y1Values(), y2Values() As String
                    y1Values = (From row In dtAL Select col = row(Session("YValueColumn")).ToString).ToArray
                    y2Values = (From row In dtFE Select col = row(Session("YValueColumn")).ToString).ToArray

                    Dim y1_min As String = y1Values.Min() - (10 / 100 * y1Values.Min)
                    Dim y1_max As String = y1Values.Max() + (10 / 100 * y1Values.Max)
                    Dim y2_min As String = y2Values.Min() - (10 / 100 * y2Values.Min)
                    Dim y2_max As String = y2Values.Max() + (10 / 100 * y2Values.Max)
                    'objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), y1_min, y1_max, y2_min, y2_max, Lit2, "container2", "plot2", ChartTitle, ddlFilterColVal5.Text, ddlFilterColVal6.Text, "priData1", "secData1", ddlFilterColVal5.SelectedItem.Text, ddlFilterColVal6.SelectedItem.Text)
                    objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), y1_min, y1_max, y2_min, y2_max, Lit2, "container2", "plot2", ChartTitle, ddlFilterColVal5.Text, ddlFilterColVal6.Text, "priData1", "secData1", "% Al", "% Fe")
                    'objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), Session("YValueColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, ddlFilterColVal2.Text, ddlFilterColVal3.Text, "dataPri", "dataSec")
                Else
                    objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit2, "container2", "plot2", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
                End If
                Dim Campaign As String = ""
                If ddlFilterColVal5.SelectedIndex >= 0 And ddlFilterCol5.SelectedItem.Text <> "Select" Then
                    Campaign = ddlFilterColVal5.SelectedItem.Text
                End If
                If ddlFilterColVal6.SelectedIndex >= 0 And ddlFilterCol6.SelectedItem.Text <> "Select" Then
                    Campaign &= "," & ddlFilterColVal6.SelectedItem.Text
                End If
                objController.PlotBoxPlotChart1(dt, Session("YValueColumn"), Lit4, "container3", "plot22", "dataB", "CLR_PARAM_MIN", "outlierDataB", ChartTitle, "", "Avg_B", Campaign)
                '--------------

                'objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit2, "container2", "plot2", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
                'objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit4, "container3", "plot22", "dataB", "CLR_PARAM_MIN", "outlierDataB", ChartTitle, "", "Avg_B")
                'ElseIf val = "" Then
                '    objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
                '    objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit3, "container1", "plot11", "dataA", "CLR_PARAM_MIN", "outlierDataA", ChartTitle, "", "Avg_A")

                '    objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit2, "container2", "plot2", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
                '    objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit4, "container3", "plot22", "dataB", "CLR_PARAM_MIN", "outlierDataB", ChartTitle, "", "Avg_B")
            End If
            'PlotLineChart(dtAL, dtFE, ChartTitle)
            'PlotBoxPlot(dtAL, dtFE, ChartTitle)
        Catch ex As Exception

        End Try
    End Sub

    'Sub PlotLineChart(ByVal LineChartData1 As DataTable, ByVal LineChartData2 As DataTable, ByVal ChartTitle As String)
    '    objController.PlotLineChart(LineChartData1, Session("DateColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, "Test Value (%)", ddl_Colour.SelectedItem.Text)
    '    objController.PlotLineChart(LineChartData2, Session("DateColumn"), Session("YValueColumn"), Lit2, "container2", "plot2", "%FE Analysis", "Test Value (%)", ddl_Colour.SelectedItem.Text)
    'End Sub

    'Sub PlotBoxPlot(ByVal LineChartData1 As DataTable, ByVal LineChartData2 As DataTable, ByVal ChartTitle As String)
    '    objController.PlotBoxPlotChart(LineChartData1, Session("YValueColumn"), Lit3, "container1", "plot11", "dataA", ddl_Colour.SelectedItem.Text, "outlierDataA", ChartTitle, "", "Avg_A")
    '    objController.PlotBoxPlotChart(LineChartData2, Session("YValueColumn"), Lit4, "container3", "plot22", "dataB", ddl_Colour.SelectedItem.Text, "outlierDataB", "FE Test Value (%)", "", "Avg_B")
    'End Sub

    'Protected Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
    '    'DrawChart("", "", "")
    'End Sub

    Protected Sub ddlFilterCol1_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddlFilterCol1.SelectedIndexChanged
        If ddlFilterCol1.Text <> "Select" Then
            If objController.IsValidDateRange(txtFrom, txtTo) Then
                objController.LoadColumnsData(ddlFilterColVal1, Session("TableName"), ddlFilterCol1.Text, Session("DateColumn"), txtFrom.Text, txtTo.Text)
            Else
                UserMsgBoxError("Date range incorrect.")
            End If

        Else
            ddlFilterColVal1.DataSource = ""
            ddlFilterColVal1.DataBind()
        End If
        'ddl_Colour.Items.FindByText(Session("DefaultColourCol")).Selected = True
    End Sub

    Protected Sub btnGo_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnGo.Click
        If objController.IsValidDateRange(txtFrom, txtTo) Then
            'Try
        Dim filter As String = ""
        If ddlFilterCol1.SelectedItem.Text <> "Select" Then
            filter = ddlFilterCol1.SelectedItem.Text & " = '" & ddlFilterColVal1.SelectedItem.Text & "'"
        End If
        filter &= " AND ("
        If ddlFilterCol2.SelectedItem.Text <> "Select" Then
            If ddlFilterCol2.Text = ddlFilterCol1.Text Then
                'filter &= " or " & ddlFilterCol2.SelectedItem.Text & " = '" & ddlFilterColVal2.SelectedItem.Value & "'"
                filter &= "" & ddlFilterCol2.SelectedItem.Text & " in (" & ddlFilterColVal2.SelectedItem.Value & ")"
            Else
                filter &= "" & ddlFilterCol2.SelectedItem.Text & " in (" & ddlFilterColVal2.SelectedItem.Value & ")"
            End If

        End If
        If ddlFilterCol3.Text <> "" Then
            If ddlFilterCol3.SelectedItem.Text <> "Select" Then
                If ddlFilterCol3.Text = ddlFilterCol2.Text Then
                    filter &= " or " & ddlFilterCol3.SelectedItem.Text & " in (" & ddlFilterColVal3.SelectedItem.Value & ")"
                ElseIf ddlFilterCol3.Text = ddlFilterCol1.Text Then
                    filter &= " or " & ddlFilterCol3.SelectedItem.Text & " in (" & ddlFilterColVal3.SelectedItem.Value & ")"
                Else
                    filter &= " and " & ddlFilterCol3.SelectedItem.Text & " in (" & ddlFilterColVal3.SelectedItem.Value & ")"
                End If
                ViewState("HaveY2AxisTop") = True
            Else
                'filter = filter.Replace(" and (", " and ")
                ViewState("HaveY2AxisTop") = False
            End If
            filter = filter.Replace(" and (", " and ")
            filter &= ")"
        End If

        'If ddlFilterColVal3.Text <> "" Then
        '    txtChartTitle.Text = ddlFilterColVal1.Text & " " & ddlFilterColVal2.SelectedItem.Text & " " & ddlFilterColVal3.SelectedItem.Text
        'Else
        '    txtChartTitle.Text = ddlFilterColVal1.Text & " " & ddlFilterColVal2.SelectedItem.Text
            'End If
            If ddlFilterColVal1.Text <> "" Then
                txtChartTitle.Text = ddlFilterColVal1.Text
            End If
            If ddlFilterColVal2.Text <> "" Then
                txtChartTitle.Text &= " " & ddlFilterColVal2.SelectedItem.Text
            End If
            If ddlFilterColVal3.Text <> "" Then
                txtChartTitle.Text &= " " & ddlFilterColVal3.SelectedItem.Text
            End If
        If Session("SelectVal") = "CGL" Or Session("SelectVal") = "CGL1" Or Session("SelectVal") = "PLTCM" Or Session("SelectVal") = "CGL2" Then
            DrawChartTop(filter, txtChartTitle.Text, "first", Lit1, Lit3)

            'ElseIf Session("SelectVal") = "CGL2" Then
            '    DrawChartTop(filter, txtChartTitle.Text, "first", Lit1, Lit3)
            '    DrawChartForCGL2(filter, txtChartTitle.Text, "first")
        End If


        'ddl_Colour.Items.FindByText(Session("DefaultColourCol")).Selected = True
        'Catch ex As Exception

            'End Try
        Else
            UserMsgBoxError("Date range incorrect.")
        End If
    End Sub
    Sub DrawChartForCGL2(ByVal Filter As String, ByVal ChartTitle As String, ByVal val As String)
        Try
            'lita.Text = ""
            'litb.Text = ""
            ''ChartTitle = "Trend of Eff. Aluminium & Eff. Iron"
            Dim strfrmDt As String = txtFrom.Text.Trim
            Dim strToDt As String = txtTo.Text.Trim

            'Dim dt As DataTable = objController.GetWetChemicalTestData("CGL2_ZNBATH_TREND", strfrmDt, strToDt, "CZT_TIMESTAMP")

            'Dim dt1 As New DataTable
            'dt1.Columns.Add("CLR_DT_SAMPLING_DATE", GetType(DateTime))
            'dt1.Columns.Add("CLR_PARAM_MIN", GetType(Decimal))
            'dt1.Columns.Add("CLR_PARAM_TEST", GetType(String))
            'dt1.Columns.Add("CLR_TEST_VALUE", GetType(Decimal))

            'Dim dt2 As DataTable = dt.DefaultView.ToTable(True, "CLR_PARAM_TEST")
            'Dim dv As DataView = dt.DefaultView


            'For row As Integer = 0 To dt2.Rows.Count - 1
            '    dv.RowFilter = "CLR_PARAM_TEST='" & dt2.Rows(row)(0) & "' and CZT_POT_AL < 1 and CZT_POT_FE < 1"
            '    For j As Integer = 0 To dv.Count - 1
            '        If dt2.Rows(row)(0) = "ZAAL" Then
            '            dt1.Rows.Add(dv(j)(0), 1.0, "ZAAL", dv.Item(j)(1))
            '            dt1.Rows.Add(dv(j)(0), 2.0, "ZAFE_AL", dv.Item(j)(2))
            '        ElseIf dt2.Rows(row)(0) = "ZAZS" Then
            '            dt1.Rows.Add(dv(j)(0), 3.0, "ZAZS", dv.Item(j)(1))
            '            dt1.Rows.Add(dv(j)(0), 4.0, "ZAFE_ZS", dv.Item(j)(2))
            '        ElseIf dt2.Rows(row)(0) = "ZAGA" Then
            '            dt1.Rows.Add(dv(j)(0), 5.0, "ZAGA", dv.Item(j)(1))
            '            dt1.Rows.Add(dv(j)(0), 6.0, "ZAFE_GA", dv.Item(j)(2))
            '        End If
            '    Next
            '    dv.RowFilter = ""
            'Next

            'objController.PlotBoxPlotChartForCGL2(dt1, "CLR_TEST_VALUE", Lit3, "container1", "plot11", "dataA", "CLR_PARAM_MIN", "outlierDataA", ChartTitle, "", "Avg_A")
            '----------------------------Top Right Chart-----------------------------------------------------------------------------------------------------------------
            Dim dt As DataTable = objController.GetWetChemicalTestData("CGL2_ZNBATH_TREND", strfrmDt, strToDt, "CZT_TIMESTAMP", "CZT_POT_AL", "CZT_POT_FE", "CZT_CAMP_AL")


            Dim dt1 As New DataTable
            dt1.Columns.Add("CLR_DT_SAMPLING_DATE", GetType(DateTime))
            dt1.Columns.Add("CLR_PARAM_MIN", GetType(Decimal))
            dt1.Columns.Add("CLR_PARAM_TEST", GetType(String))
            dt1.Columns.Add("CLR_TEST_VALUE", GetType(Decimal))

            Dim dt2 As DataTable = dt.DefaultView.ToTable(True, "CLR_PARAM_TEST")
            Dim dv As DataView = dt.DefaultView


            'For row As Integer = 0 To dt2.Rows.Count - 1
            '    dv.RowFilter = "CLR_PARAM_TEST='" & dt2.Rows(row)(0) & "' and CZT_POT_AL < 1 and CZT_POT_FE < 1"
            '    For j As Integer = 0 To dv.Count - 1
            '        If dt2.Rows(row)(0) = "ZAAL" Then
            '            dt1.Rows.Add(dv(j)(0), 1.0, "ZAAL", dv.Item(j)(1))
            '            dt1.Rows.Add(dv(j)(0), 2.0, "ZAFE_AL", dv.Item(j)(2))
            '        ElseIf dt2.Rows(row)(0) = "ZAZS" Then
            '            dt1.Rows.Add(dv(j)(0), 3.0, "ZAZS", dv.Item(j)(1))
            '            dt1.Rows.Add(dv(j)(0), 4.0, "ZAFE_ZS", dv.Item(j)(2))
            '        ElseIf dt2.Rows(row)(0) = "ZAGA" Then
            '            dt1.Rows.Add(dv(j)(0), 5.0, "ZAGA", dv.Item(j)(1))
            '            dt1.Rows.Add(dv(j)(0), 6.0, "ZAFE_GA", dv.Item(j)(2))
            '        End If
            '    Next
            '    dv.RowFilter = ""
            'Next
            For row As Integer = 0 To dt2.Rows.Count - 1
                dv.RowFilter = "CLR_PARAM_TEST='" & dt2.Rows(row)(0) & "' and CZT_POT_AL < 1 and CZT_POT_FE < 1"
                For j As Integer = 0 To dv.Count - 1
                    'If dt2.Rows(row)(0) = "ZAAL" Then
                    '    dt1.Rows.Add(dv(j)(0), 1.0, "ZAAL", dv.Item(j)(1))
                    '    dt1.Rows.Add(dv(j)(0), 2.0, "ZAFE_AL", dv.Item(j)(2))
                    'ElseIf dt2.Rows(row)(0) = "ZAZS" Then
                    '    dt1.Rows.Add(dv(j)(0), 3.0, "ZAZS", dv.Item(j)(1))
                    '    dt1.Rows.Add(dv(j)(0), 4.0, "ZAFE_ZS", dv.Item(j)(2))
                    'ElseIf dt2.Rows(row)(0) = "ZAGA" Then
                    '    dt1.Rows.Add(dv(j)(0), 5.0, "ZAGA", dv.Item(j)(1))
                    '    dt1.Rows.Add(dv(j)(0), 6.0, "ZAFE_GA", dv.Item(j)(2))
                    'End If
                    If dv(j)(1) >= 0.1 And dv(j)(1) <= 0.15 Then
                        dt1.Rows.Add(dv(j)(0), 1.0, "GA_AL", dv.Item(j)(1))
                        dt1.Rows.Add(dv(j)(0), 2.0, "GA_FE", dv.Item(j)(2))
                    ElseIf dv(j)(1) > 0.15 And dv(j)(1) <= 0.4 Then
                        dt1.Rows.Add(dv(j)(0), 3.0, "GI_AL", dv.Item(j)(1))
                        dt1.Rows.Add(dv(j)(0), 4.0, "GI_FE", dv.Item(j)(2))

                    End If
                Next
                dv.RowFilter = ""
            Next

            objController.PlotBoxPlotChartForCGL2(dt1, "CLR_TEST_VALUE", Lit3, "container1", "plot11", "dataA", "CLR_PARAM_MIN", "outlierDataA", ChartTitle, "", "Avg_A", "Pot", 0, 0.4)
            '-----------------Top Right Chart End-------------------------------------------------------------------------------------------------------------------------

            ''-----------------Bottom Right Chart--------------------------------------------------------------------------------------------------------------------------
            'Dim dt3 As DataTable = objController.GetWetChemicalTestData("CGL2_ZNBATH_TREND", strfrmDt, strToDt, "CZT_TIMESTAMP", "CZT_EFF_AL", "CZT_EFF_FE", "CZT_CAMP_AL")


            'Dim dt4 As New DataTable
            'dt4.Columns.Add("CLR_DT_SAMPLING_DATE", GetType(DateTime))
            'dt4.Columns.Add("CLR_PARAM_MIN", GetType(Decimal))
            'dt4.Columns.Add("CLR_PARAM_TEST", GetType(String))
            'dt4.Columns.Add("CLR_TEST_VALUE", GetType(Decimal))

            'Dim dt5 As DataTable = dt3.DefaultView.ToTable(True, "CLR_PARAM_TEST")
            'Dim dv1 As DataView = dt3.DefaultView


            'For row As Integer = 0 To dt5.Rows.Count - 1
            '    dv1.RowFilter = "CLR_PARAM_TEST='" & dt5.Rows(row)(0) & "' and CZT_EFF_AL < 1 and CZT_EFF_FE < 1"
            '    For j As Integer = 0 To dv1.Count - 1
            '        If dt5.Rows(row)(0) = "ZAAL" Then
            '            dt4.Rows.Add(dv1(j)(0), 1.0, "ZAAL", dv1.Item(j)(1))
            '            dt4.Rows.Add(dv1(j)(0), 2.0, "ZAFE_AL", dv1.Item(j)(2))
            '        ElseIf dt5.Rows(row)(0) = "ZAZS" Then
            '            dt4.Rows.Add(dv1(j)(0), 3.0, "ZAZS", dv1.Item(j)(1))
            '            dt4.Rows.Add(dv1(j)(0), 4.0, "ZAFE_ZS", dv1.Item(j)(2))
            '        ElseIf dt5.Rows(row)(0) = "ZAGA" Then
            '            dt4.Rows.Add(dv1(j)(0), 5.0, "ZAGA", dv1.Item(j)(1))
            '            dt4.Rows.Add(dv1(j)(0), 6.0, "ZAFE_GA", dv1.Item(j)(2))
            '        End If
            '    Next
            '    dv1.RowFilter = ""
            'Next

            'objController.PlotBoxPlotChartForCGL2(dt4, "CLR_TEST_VALUE", Lit4, "container3", "plot22", "dataB", "CLR_PARAM_MIN", "outlierDataB", ChartTitle, "", "Avg_B", "Eff")
            ''-----------------Bottom Right Chart End----------------------------------------------------------------------------------------------------------------------
            ''--------------TOP LEFT CHART----------------------------------------------------------------------
            ''--------------TOP LEFT CHART END----------------------------------------------------------------------
            ''--------------TOP RIGHT CHART----------------------------------------------------------------------
            ''--------------TOP RIGHT CHART END----------------------------------------------------------------------
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub btnSecGo_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSecGo.Click
        If objController.IsValidDateRange(txtFrom, txtTo) Then

      
        Dim filter As String = ""
        If ddlFilterCol4.SelectedItem.Text <> "Select" Then
            Filter = ddlFilterCol4.SelectedItem.Text & " = '" & ddlFilterColVal4.SelectedItem.Text & "'"
        End If
        filter &= " AND ("
        If ddlFilterCol5.SelectedItem.Text <> "Select" Then
            If ddlFilterCol5.Text = ddlFilterCol4.Text Then
                'filter &= " or " & ddlFilterCol2.SelectedItem.Text & " = '" & ddlFilterColVal2.SelectedItem.Value & "'"
                filter &= "" & ddlFilterCol5.SelectedItem.Text & " in (" & ddlFilterColVal5.SelectedItem.Value & ")"
            Else
                filter &= "" & ddlFilterCol5.SelectedItem.Text & " in (" & ddlFilterColVal5.SelectedItem.Value & ")"
            End If

        End If
        If ddlFilterCol6.Text <> "" Then
            If ddlFilterCol6.SelectedItem.Text <> "Select" Then
                If ddlFilterCol6.Text = ddlFilterCol5.Text Then
                    filter &= " or " & ddlFilterCol6.SelectedItem.Text & " in (" & ddlFilterColVal6.SelectedItem.Value & ")"
                ElseIf ddlFilterCol6.Text = ddlFilterCol4.Text Then
                    filter &= " or " & ddlFilterCol6.SelectedItem.Text & " in (" & ddlFilterColVal6.SelectedItem.Value & ")"
                Else
                    filter &= " and " & ddlFilterCol6.SelectedItem.Text & " in (" & ddlFilterColVal6.SelectedItem.Value & ")"
                End If
                ViewState("HaveY2AxisBottom") = True
            Else
                'filter = filter.Replace(" and (", " and ")
                ViewState("HaveY2AxisBottom") = False
            End If
            filter = filter.Replace(" and (", " and ")
            filter &= ")"
        End If
        'If ddlFilterColVal6.Text <> "" Then
        '    txtSecChartTitle.Text = ddlFilterColVal4.Text & " " & ddlFilterColVal5.SelectedItem.Text & " " & ddlFilterColVal6.SelectedItem.Text
        'Else
        '    txtSecChartTitle.Text = ddlFilterColVal4.Text & " " & ddlFilterColVal5.SelectedItem.Text
        'End If

        'txtSecChartTitle.Text = ddlFilterColVal4.Text & " " & ddlFilterColVal5.SelectedItem.Text & " " & ddlFilterColVal6.SelectedItem.Text

            If ddlFilterColVal4.Text <> "" Then
                txtSecChartTitle.Text = ddlFilterColVal4.Text
            End If
            If ddlFilterColVal5.Text <> "" Then
                txtSecChartTitle.Text &= " " & ddlFilterColVal5.SelectedItem.Text
            End If
            If ddlFilterColVal6.Text <> "" Then
                txtSecChartTitle.Text &= " " & ddlFilterColVal6.SelectedItem.Text
            End If

        If Session("SelectVal") = "CGL" Or Session("SelectVal") = "CGL1" Or Session("SelectVal") = "PLTCM" Or Session("SelectVal") = "CGL2" Then
            DrawChartBottom(filter, txtSecChartTitle.Text, "second", Lit2, Lit4)

            'ElseIf Session("SelectVal") = "CGL2" Then
            '    DrawChartBottom(filter, txtSecChartTitle.Text, "second", Lit2, Lit4)
            '    DrawChartForCGL2(filter, txtChartTitle.Text, "first")
        End If
        Else
            UserMsgBoxError("Date range incorrect.")
        End If
    End Sub

    Protected Sub ddlFilterCol2_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddlFilterCol2.SelectedIndexChanged
        If ddlFilterCol2.SelectedItem.Text <> "Select" Then

            If objController.IsValidDateRange(txtFrom, txtTo) Then
                objController.LoadColumnsData(ddlFilterColVal2, Session("TableName"), ddlFilterCol2.SelectedItem.Text, Session("DateColumn"), txtFrom.Text, txtTo.Text, ddlFilterColVal1.SelectedItem.Text)
            Else
                UserMsgBoxError("Date range incorrect.")
            End If
        Else
            ddlFilterColVal2.DataSource = ""
            ddlFilterColVal2.DataBind()
        End If
    End Sub

    Protected Sub ddlFilterCol3_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddlFilterCol3.SelectedIndexChanged
        If ddlFilterCol3.SelectedItem.Text <> "Select" Then
            If objController.IsValidDateRange(txtFrom, txtTo) Then
                objController.LoadColumnsData(ddlFilterColVal3, Session("TableName"), ddlFilterCol3.SelectedItem.Text, Session("DateColumn"), txtFrom.Text, txtTo.Text, ddlFilterColVal1.SelectedItem.Text)
            Else
                UserMsgBoxError("Date range incorrect.")
            End If

        Else
            ddlFilterColVal3.DataSource = ""
            ddlFilterColVal3.DataBind()
        End If
    End Sub

    Protected Sub ddlFilterCol4_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddlFilterCol4.SelectedIndexChanged
        If ddlFilterCol4.SelectedItem.Text <> "Select" Then
            If objController.IsValidDateRange(txtFrom, txtTo) Then
                objController.LoadColumnsData(ddlFilterColVal4, Session("TableName"), ddlFilterCol4.SelectedItem.Text, Session("DateColumn"), txtFrom.Text, txtTo.Text)
            Else
                UserMsgBoxError("Date range incorrect.")
            End If

        Else
            ddlFilterColVal4.DataSource = ""
            ddlFilterColVal4.DataBind()
        End If
    End Sub

    Protected Sub ddlFilterCol5_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddlFilterCol5.SelectedIndexChanged
        If ddlFilterCol5.SelectedItem.Text <> "Select" Then
            If objController.IsValidDateRange(txtFrom, txtTo) Then
                objController.LoadColumnsData(ddlFilterColVal5, Session("TableName"), ddlFilterCol5.SelectedItem.Text, Session("DateColumn"), txtFrom.Text, txtTo.Text, ddlFilterColVal4.SelectedItem.Text)
            Else
                UserMsgBoxError("Date range incorrect.")
            End If

        Else
            ddlFilterColVal5.DataSource = ""
            ddlFilterColVal5.DataBind()
        End If
    End Sub

    Protected Sub ddlFilterCol6_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddlFilterCol6.SelectedIndexChanged
        If ddlFilterCol6.SelectedItem.Text <> "Select" Then
            If objController.IsValidDateRange(txtFrom, txtTo) Then
                objController.LoadColumnsData(ddlFilterColVal6, Session("TableName"), ddlFilterCol6.SelectedItem.Text, Session("DateColumn"), txtFrom.Text, txtTo.Text, ddlFilterColVal4.SelectedItem.Text)
            Else
                UserMsgBoxError("Date range incorrect.")
            End If

        Else
            ddlFilterColVal6.DataSource = ""
            ddlFilterColVal6.DataBind()
        End If
    End Sub

    Protected Sub txtChartTitle_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtChartTitle.TextChanged
        Dim dtAL As DataTable = ViewState("dtAL")
        Dim dtFE As DataTable = ViewState("dtFE")
        'PlotLineChart(dtAL, dtFE, txtChartTitle.Text)
        'PlotBoxPlot(dtAL, dtFE, txtChartTitle.Text)
        objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit1, "container", "plot1", txtChartTitle.Text, "Test Value (%)", "CLR_PARAM_MIN")
        objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit3, "container1", "plot11", "dataA", "CLR_PARAM_MIN", "outlierDataA", txtChartTitle.Text, "", "Avg_A")
    End Sub

    Protected Sub txtSecChartTitle_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtSecChartTitle.TextChanged
        Dim dtAL As DataTable = ViewState("dtAL")
        Dim dtFE As DataTable = ViewState("dtFE")
        'PlotLineChart(dtAL, dtFE, txtChartTitle.Text)
        'PlotBoxPlot(dtAL, dtFE, txtChartTitle.Text)
        objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit2, "container2", "plot2", txtSecChartTitle.Text, "Test Value (%)", "CLR_PARAM_MIN")
        objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit4, "container3", "plot22", "dataB", "CLR_PARAM_MIN", "outlierDataB", txtSecChartTitle.Text, "", "Avg_B")
    End Sub

    Protected Sub ddlColour1_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddlColour1.SelectedIndexChanged
        Dim dtAL As DataTable = ViewState("dtAL")
        Dim dtFE As DataTable = ViewState("dtFE")
        'PlotLineChart(dtAL, dtFE, txtChartTitle.Text)
        'PlotBoxPlot(dtAL, dtFE, txtChartTitle.Text)
        objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit1, "container", "plot1", txtChartTitle.Text, "Test Value (%)", "CLR_PARAM_MIN")
        objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit3, "container1", "plot11", "dataA", "CLR_PARAM_MIN", "outlierDataA", txtChartTitle.Text, "", "Avg_A")

    End Sub

    Protected Sub ddlSecColour_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddlSecColour.SelectedIndexChanged
        Dim dtAL As DataTable = ViewState("dtAL")
        Dim dtFE As DataTable = ViewState("dtFE")
        'PlotLineChart(dtAL, dtFE, txtSecChartTitle.Text)
        'PlotBoxPlot(dtAL, dtFE, txtSecChartTitle.Text)
        objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit2, "container2", "plot2", txtSecChartTitle.Text, "Test Value (%)", "CLR_PARAM_MIN")
        objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit4, "container3", "plot22", "dataB", "CLR_PARAM_MIN", "outlierDataB", txtSecChartTitle.Text, "", "Avg_B")
    End Sub

    Function GetParamTestAliasName(ByVal DropDownName As DropDownList) As String
        Dim alias_name As String = ""
        If DropDownName.Text = "ZAAL" Or DropDownName.Text = "ZAGA" Or DropDownName.Text = "ZAZS" Then
            alias_name = "Aluminium"
        ElseIf DropDownName.Text = "ZAEAL" Then
            alias_name = "Eff Aluminium"
        ElseIf DropDownName.Text = "ZAFE" Then
            alias_name = "Iron"
        ElseIf DropDownName.Text = "ZASN" Then
            alias_name = "Tin"
        ElseIf DropDownName.Text = "ZASB" Then
            alias_name = "Antimony"
        ElseIf DropDownName.Text = "ZAPB" Then
            alias_name = "Lead"
        ElseIf DropDownName.Text = "ZAZN" Then
            alias_name = "Zinc"
        ElseIf DropDownName.Text = "ZIAL" Then
            alias_name = "Aluminium"
        ElseIf DropDownName.Text = "ZIEAL" Then
            alias_name = "Eff Aluminium"
        ElseIf DropDownName.Text = "ZIFE" Then
            alias_name = "Iron"
        ElseIf DropDownName.Text = "ZISN" Then
            alias_name = "Tin"
        ElseIf DropDownName.Text = "ZISB" Then
            alias_name = "Anitmony"
        ElseIf DropDownName.Text = "ZIPB" Then
            alias_name = "Lead"
        ElseIf DropDownName.Text = "ZIZN" Then
            alias_name = "Zinc"
        ElseIf DropDownName.Text = "ZIAL" Then
            alias_name = "Aluminium"
        ElseIf DropDownName.Text = "ZIEAL" Then
            alias_name = "Eff Aluminium"
        ElseIf DropDownName.Text = "ZIFE" Then
            alias_name = "Iron"
        ElseIf DropDownName.Text = "ZISN" Then
            alias_name = "Tin"
        ElseIf DropDownName.Text = "ZISB" Then
            alias_name = "Antimony"
        ElseIf DropDownName.Text = "ZIPB" Then
            alias_name = "Lead"
        ElseIf DropDownName.Text = "ZIZN" Then
            alias_name = "Zinc"
        ElseIf DropDownName.Text = "ZRAL" Then
            alias_name = "Aluminium"
        ElseIf DropDownName.Text = "ZREAL" Then
            alias_name = "Eff Aluminium"
        ElseIf DropDownName.Text = "ZRFE" Then
            alias_name = "Iron"
        ElseIf DropDownName.Text = "ZRSN" Then
            alias_name = "Tin"
        ElseIf DropDownName.Text = "ZRSB" Then
            alias_name = "Antimony"
        ElseIf DropDownName.Text = "ZRPB" Then
            alias_name = "Lead"
        ElseIf DropDownName.Text = "ZRZN" Then
            alias_name = "Zinc"
        ElseIf DropDownName.Text = "ZZAL" Then
            alias_name = "Aluminium"
        ElseIf DropDownName.Text = "ZZEAL" Then
            alias_name = "Eff Aluminium"
        ElseIf DropDownName.Text = "ZZFE" Then
            alias_name = "Iron"
        ElseIf DropDownName.Text = "ZZSN" Then
            alias_name = "Tin"
        ElseIf DropDownName.Text = "ZZSB" Then
            alias_name = "Antimony"
        ElseIf DropDownName.Text = "ZZPB" Then
            alias_name = "Lead"
        ElseIf DropDownName.Text = "ZZZN" Then
            alias_name = "Zinc"
        ElseIf DropDownName.Text = "ALPT" Then
            alias_name = "Predeg.tank"
        ElseIf DropDownName.Text = "ALET" Then
            alias_name = "ECL tank"
        ElseIf DropDownName.Text = "ALPTO" Then
            alias_name = "Predeg.tank(oil%)"
        ElseIf DropDownName.Text = "ALPTF" Then
            alias_name = "Predeg.tank(Fe%)"
        ElseIf DropDownName.Text = "ALTK" Then
            alias_name = "Alkali tank"
        ElseIf DropDownName.Text = "ALHW" Then
            alias_name = "Hot Rinse Water"
        ElseIf DropDownName.Text = "CRPT" Then
            alias_name = "Chromate Preperation Tank"
        ElseIf DropDownName.Text = "CRWT" Then
            alias_name = "Working tank"
        ElseIf DropDownName.Text = "CRTK" Then
            alias_name = "Chromate Tank"
        ElseIf DropDownName.Text = "ACIDT1" Then
            alias_name = "HCL Acid T1"
        ElseIf DropDownName.Text = "ACIDT2" Then
            alias_name = "HCL Acid T2"
        ElseIf DropDownName.Text = "ACIDT3" Then
            alias_name = "HCL Acid T3"
        ElseIf DropDownName.Text = "ACIDT4" Then
            alias_name = "HCL Acid T4"
        ElseIf DropDownName.Text = "PLCL" Then
            alias_name = "Chloride ppm"
        ElseIf DropDownName.Text = "PLSL" Then
            alias_name = "Suplhate ppm"
        ElseIf DropDownName.Text = "HCLWT1" Then
            alias_name = "HCL T1"
        ElseIf DropDownName.Text = "HCLWT2" Then
            alias_name = "HCL T2"
        ElseIf DropDownName.Text = "HCLWT3" Then
            alias_name = "HCL T3"
        ElseIf DropDownName.Text = "HCLWT4" Then
            alias_name = "HCL T4"
        ElseIf DropDownName.Text = "CNT1" Then
            alias_name = "Cndctvty T1"
        ElseIf DropDownName.Text = "CNT2" Then
            alias_name = "Cndctvty T2"
        ElseIf DropDownName.Text = "CNT3" Then
            alias_name = "Cndctvty T3"
        ElseIf DropDownName.Text = "CNT4" Then
            alias_name = "Cndctvty T4"
        ElseIf DropDownName.Text = "FET1" Then
            alias_name = "Iron T1"
        ElseIf DropDownName.Text = "FET2" Then
            alias_name = "Iron T2"
        ElseIf DropDownName.Text = "FET3" Then
            alias_name = "Iron T3"
        ElseIf DropDownName.Text = "FET4" Then
            alias_name = "Iron T4"
        ElseIf DropDownName.Text = "FEWT1" Then
            alias_name = "Iron T1"
        ElseIf DropDownName.Text = "FEWT2" Then
            alias_name = "Iron T2"
        ElseIf DropDownName.Text = "FEWT3" Then
            alias_name = "Iron T3"
        ElseIf DropDownName.Text = "FEWT4" Then
            alias_name = "Iron T4"
        ElseIf DropDownName.Text = "SGT1" Then
            alias_name = "Sp Gravity T1"
        ElseIf DropDownName.Text = "SGT2" Then
            alias_name = "Sp Gravity T2"
        ElseIf DropDownName.Text = "SGT3" Then
            alias_name = "Sp Gravity T3"
        ElseIf DropDownName.Text = "SGT4" Then
            alias_name = "Sp Gravity T4"
        ElseIf DropDownName.Text = "SO" Then
            alias_name = "Surface Oil"
        ElseIf DropDownName.Text = "SC" Then
            alias_name = "Surface Carbon"
        ElseIf DropDownName.Text = "SF" Then
            alias_name = "Surface Iron"
        ElseIf DropDownName.Text = "ZLPT" Then
            alias_name = "Zinc Load Prep. Tank"
        ElseIf DropDownName.Text = "ZLWT" Then
            alias_name = "Zinc Load Working Tank"
        ElseIf DropDownName.Text = "PHPT" Then
            alias_name = "PH Prep. Tank"
        ElseIf DropDownName.Text = "PHWT" Then
            alias_name = "PH Working Tank"
        ElseIf DropDownName.Text = "TCRPT" Then
            alias_name = "Total Chromate Prep. Tank"
        ElseIf DropDownName.Text = "TCRWT" Then
            alias_name = "Total Chromate Working Tank"
        ElseIf DropDownName.Text = "CR6PT" Then
            alias_name = "CR6 Prep. Tank"
        ElseIf DropDownName.Text = "CR6WT" Then
            alias_name = "CR6 Working Tank"
        ElseIf DropDownName.Text = "CR63PT" Then
            alias_name = "CR63 Prep. Tank"
        ElseIf DropDownName.Text = "CR63WT" Then
            alias_name = "CR63 Working Tank"
        ElseIf DropDownName.Text = "ALETO" Then
            alias_name = "ECL Tank (Fe %)"
        ElseIf DropDownName.Text = "ALETF" Then
            alias_name = "ECL Tank (Oil %)"
        ElseIf DropDownName.Text = "ARBD" Then
            alias_name = "Bulk Density"
        ElseIf DropDownName.Text = "ARPS" Then
            alias_name = "Avg. Particle Size"
        ElseIf DropDownName.Text = "ARMO" Then
            alias_name = "Moisture"
        ElseIf DropDownName.Text = "ARP" Then
            alias_name = "P"
        ElseIf DropDownName.Text = "ARV" Then
            alias_name = "V"
        ElseIf DropDownName.Text = "ARCU" Then
            alias_name = "Cu"
        ElseIf DropDownName.Text = "ARMGO" Then
            alias_name = "MgO"
        ElseIf DropDownName.Text = "ARALO" Then
            alias_name = "Al2O3"
        ElseIf DropDownName.Text = "ARSIO" Then
            alias_name = "SiO2"
        ElseIf DropDownName.Text = "ARCAO" Then
            alias_name = "CaO"
        ElseIf DropDownName.Text = "ARMNO" Then
            alias_name = "MnO"
        ElseIf DropDownName.Text = "ARFEO" Then
            alias_name = "Fe2O3"
        ElseIf DropDownName.Text = "ARCL" Then
            alias_name = "Chloride"
        ElseIf DropDownName.Text = "SHCR" Then
            alias_name = "Sheet Chromium"
        ElseIf DropDownName.Text = "WL" Then
            alias_name = "WL"
        ElseIf DropDownName.Text = "FE" Then
            alias_name = "FE"
        End If
        Return alias_name
    End Function
End Class