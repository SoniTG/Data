﻿Imports System.Data
Imports System.IO
Imports iTextSharp.text
Imports iTextSharp.text.html.simpleparser
Imports iTextSharp.text.pdf
Imports iTextSharp.tool.xml
Imports System.Net
Imports iTextSharp.text.html
Imports System.Data.SqlClient
Partial Class lfc_PredictionModel_New
    Inherits System.Web.UI.Page

    Dim objController As New Controller
    Private _getBase64String As Object
    Dim maindt As New DataTable
    Function getdatatable(ByVal query As String) As DataTable
        Dim fndatatable As New DataTable
        Dim connection As String = "Password=Welcome@135;Persist Security Info=True;User ID=153521;Initial Catalog=FP_PROCESS_DATA;Data Source=176.0.0.60\lptgsqldev"
        Using con As New SqlConnection(connection)
            Using cmd As New SqlCommand(query, con)
                cmd.CommandType = CommandType.Text
                Using sda As New SqlDataAdapter(cmd)
                    'Using dt As New DataTable()
                    sda.Fill(fndatatable)
                    'End Using
                End Using
            End Using
        End Using
        Return fndatatable
    End Function
    Private Property GetBase64String(url As String) As Object
        Get
            Return _getBase64String
        End Get
        Set(value As Object)
            _getBase64String = value
        End Set
    End Property

    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
        End If
    End Sub

    Protected Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click
        If ddl1.SelectedIndex = 0 Then
            UserMsgBoxError("Select caster")
            Return
        End If

        Dim stDate As String = hfFrom.Value
        Dim enDate As String = hfTo.Value

        

        Dim lfcdec_query As String = "Select decision,SLAB_ID from TSCR_LFC_DECISION where SLAB_START >'" & stDate & "' and SLAB_END <'" & enDate & "'"
        Dim decisiondt As DataTable = getdatatable(lfcdec_query)
        If decisiondt.Rows.Count > 0 Then


            '' Dim q As String = "SELECT * FROM [TSCR_HEAT_DETAILS] where HEAT_START_TIME>'" & stDate & "' and HEAT_END_TIME<'" & enDate & "' and CASTER=" & ddl1.SelectedItem.Value & ""
            ' Dim ds As DataSet = objController.GetLFCData(stDate, enDate, ddl1.SelectedItem.Value)



            Dim q As String = "SELECT distinct(concat( 'T', SUBSTRING(SLAB_ID,3,5))),HEAT_ID FROM TSCR_LFC_DECISION inner join [TSCR_HEAT_DETAILS] on HEAT_ID = concat( 'T', SUBSTRING(SLAB_ID,3,5))   where  SLAB_START >'" & stDate & "' and SLAB_END <'" & enDate & "' and CASTER=" & ddl1.SelectedItem.Value & ""

            Dim dt As DataTable = getdatatable(q)
            ddl2.DataSource = dt
            ddl2.DataTextField = "HEAT_ID"
            ddl2.DataValueField = "HEAT_ID"
            ddl2.DataBind()

        End If
        If decisiondt.Rows.Count = 0 Then
            UserMsgBoxError("NO DATA FOUND")
            Return
        End If
        ' Next
        ' End If
        If ddl1.SelectedItem.Value = 2 Then
            rptGRID.Visible = False
        End If
        If ddl1.SelectedItem.Value = 1 Then
            rptGRID.Visible = False
        End If

        ddl2.Items.Insert(0, "Select")
        Literal1.Text = "<script>$('#main1').empty();</script>"
        Literal2.Text = "<script>$('#main2').empty();</script>"
    End Sub

    Protected Sub ddl2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddl2.SelectedIndexChanged
        Label1.Visible = False
        Label1.Text = ""
        Label2.Visible = False
        Label2.Text = ""
        Literal1.Text = ""
        Literal2.Text = ""
        If ddl2.SelectedIndex = 0 Then
            Literal1.Text = "<script>$('#main1').empty();</script>"
            Literal2.Text = "<script>$('#main2').empty();</script>"
            Return
        End If
        rptGRID.Visible = True
        chartdiv.Visible = True

        maindt.Columns.Add("Slab_ID")
        maindt.Columns.Add("LFC_DS_T")
        maindt.Columns.Add("LFC_Tail_T")
        maindt.Columns.Add("LFC_time_T")
        maindt.Columns.Add("LFC_DS_B")
        maindt.Columns.Add("LFC_Tail_B")
        maindt.Columns.Add("LFC_time_B")
        maindt.Columns.Add("Grade")
        maindt.Columns.Add("Slab_width")
        maindt.Columns.Add("RESULT")
        maindt.Columns.Add("REMARKS")
        maindt.Columns.Add("LFC_TIMESTAMP")
        Dim count As Short = 0
        Dim line1 As String = "" '"var line1=["
        Dim line2 As String = "" '"var line2=["
        Dim flag1 As Integer = 0
        Dim flag2 As Integer = 0
        Dim heat As String = ddl2.SelectedItem.Value
        'Dim hid() As String = ddl2.SelectedItem.Value.Split("#")
        'Dim heatno As String = hid(0)
        'Dim stDate As String = hid(1)
        'Dim enDate As String = hid(2)
        Dim DEVICE_KEY As String = IIf(ddl1.SelectedItem.Value = 1, "13", "14")
        'Dim query As String = "select distinct TSM_SLAB_ID from TSCR_SLAB_MASTER where TSM_SLAB_ID like '%" & hid(0).Substring(1) & "%' order by TSM_SLAB_ID asc"
        Dim query As String = "SELECT TSM_SLAB_ID, TSM_PROD_START,TSM_PROD_END,TSM_DEVICE_KEY,TSR_SLAB_WIDTH,TSR_SLAB_GRADE "
        query &= "FROM TSCR_SLAB_MASTER inner join TSCR_SLAB_RAW On TSCR_SLAB_MASTER.TSM_SLAB_ID=TSCR_SLAB_RAW.TSR_SLAB_ID "
        query &= "WHERE [TSM_DEVICE_KEY]='" & DEVICE_KEY & "' "
        'query &= " And TSM_PROD_START >='" & CDate(stDate).AddMinutes(-10).ToString("yyyy-MM-dd HH:mm:ss") & "' "
        'query &= "AND TSM_PROD_END<='" & CDate(enDate).AddMinutes(10).ToString("yyyy-MM-dd HH:mm:ss") & "'  "
        query &= "And TSM_SLAB_ID Like '%" & heat.Substring(1) & "%' order by TSM_PROD_START asc"
        Dim slabdt As DataTable = getdatatable(query)
        Dim slabid As New DataTable
        Dim min As String = ""
        Dim max As String = ""
        If slabdt.Rows.Count > 0 Then
            min = CDate(slabdt.Rows(0)("TSM_PROD_START")).ToString("yyyy-MM-dd HH:mm:ss")
            max = CDate(slabdt.Rows(slabdt.Rows.Count - 1)("TSM_PROD_END")).ToString("yyyy-MM-dd HH:mm:ss")
            For i As Integer = 0 To slabdt.Rows.Count - 1
                Dim lfcdec_query As String = "Select decision,SLAB_ID from TSCR_LFC_DECISION where SLAB_ID='" & slabdt.Rows.Item(i)(0) & "'"
                Dim decisiondt As DataTable = getdatatable(lfcdec_query)
                If decisiondt.Rows.Count > 0 Then
                    If i = 0 Then
                        slabid = decisiondt.Copy()
                    Else
                        slabid.Merge(decisiondt)
                    End If
                    If decisiondt.Rows(0)(0) = "LFC Predicted" Then
                        Dim location_query As String = "SELECT LFC_TIMESTAMP,REMARKS, "
                        location_query &= "SUBSTRING(REMARKS,PATINDEX('%[0-9]%', REMARKS),(CASE WHEN PATINDEX('%[^0-9]%', STUFF(REMARKS, 1, (PATINDEX('%[0-9]%', REMARKS) - 1), '')) = 0 THEN LEN(REMARKS) ELSE (PATINDEX('%[^0-9]%', STUFF(REMARKS, 1, (PATINDEX('%[0-9]%', REMARKS) - 1), ''))) - 1 END )) AS RESULT,"
                        location_query &= "[LFC_FROM_TAIL] As LFC_TAIL,PROD_START_DATETIME,PROD_END_DATETIME,LFC_FROM_TAIL FROM TSCR_LFC_CAL_DATA2 WHERE SLAB_ID='" & slabdt.Rows.Item(i)(0) & "'"
                        Dim locationdt As DataTable = getdatatable(location_query)
                        If locationdt.Rows.Count > 0 Then
                            For j As Integer = 0 To locationdt.Rows.Count - 1
                                If locationdt.Rows.Item(j)(2) < 10 Then
                                    maindt.Rows.Add()
                                    maindt(count)("Slab_ID") = slabdt.Rows.Item(i)(0)
                                    maindt(count)("LFC_Tail_T") = locationdt.Rows.Item(j)(3)
                                    maindt(count)("LFC_time_T") = locationdt.Rows.Item(j)(0)
                                    maindt(count)("Slab_width") = slabdt.Rows.Item(i)(4)
                                    maindt(count)("GRADE") = slabdt.Rows.Item(i)(5)

                                    maindt(count)("RESULT") = locationdt.Rows.Item(j)(2)
                                    maindt(count)("REMARKS") = locationdt.Rows.Item(j)(1)
                                    maindt(count)("LFC_TIMESTAMP") = locationdt.Rows.Item(j)(0)

                                    If locationdt.Rows.Item(j)(2) = 4 Then
                                        maindt(count)("LFC_DS_T") = ((slabdt.Rows.Item(i)(4) / 2) - 500) / 1000
                                    ElseIf locationdt.Rows.Item(j)(2) = 5 Then
                                        maindt(count)("LFC_DS_T") = ((slabdt.Rows.Item(i)(4) / 2) - 300) / 1000
                                    ElseIf locationdt.Rows.Item(j)(2) = 6 Then
                                        maindt(count)("LFC_DS_T") = ((slabdt.Rows.Item(i)(4) / 2) - 100) / 1000
                                    ElseIf locationdt.Rows.Item(j)(2) = 7 Then
                                        maindt(count)("LFC_DS_T") = ((slabdt.Rows.Item(i)(4) / 2) + 100) / 1000
                                    ElseIf locationdt.Rows.Item(j)(2) = 8 Then
                                        maindt(count)("LFC_DS_T") = ((slabdt.Rows.Item(i)(4) / 2) + 300) / 1000
                                    ElseIf locationdt.Rows.Item(j)(2) = 9 Then
                                        maindt(count)("LFC_DS_T") = ((slabdt.Rows.Item(i)(4) / 2) + 500) / 1000
                                    End If
                                    count += 1
                                    line1 &= "['" & CDate(locationdt.Rows(j)("LFC_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm:ss") & "'," & locationdt.Rows(j)("RESULT") & "],"
                                    If CDate(locationdt.Rows(j)("LFC_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm:ss") > max Then
                                        max = CDate(locationdt.Rows(j)("LFC_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm:ss")
                                    End If
                                    flag1 = 1
                                ElseIf locationdt.Rows.Item(j)(2) > 10 Then
                                    maindt.Rows.Add()
                                    maindt(count)("Slab_ID") = slabdt.Rows.Item(i)(0)
                                    maindt(count)("LFC_Tail_B") = locationdt.Rows.Item(j)(3)
                                    maindt(count)("LFC_time_B") = locationdt.Rows.Item(j)(0)
                                    maindt(count)("Grade") = slabdt.Rows.Item(i)(5)
                                    maindt(count)("Slab_width") = slabdt.Rows.Item(i)(4)

                                    maindt(count)("RESULT") = locationdt.Rows.Item(j)(2)
                                    maindt(count)("REMARKS") = locationdt.Rows.Item(j)(1)
                                    maindt(count)("LFC_TIMESTAMP") = locationdt.Rows.Item(j)(0)

                                    If locationdt.Rows.Item(j)(2) = 19 Then
                                        maindt(count)("LFC_DS_B") = ((slabdt.Rows.Item(i)(4) / 2) - 500) / 1000
                                    ElseIf locationdt.Rows.Item(j)(2) = 18 Then
                                        maindt(count)("LFC_DS_B") = ((slabdt.Rows.Item(i)(4) / 2) - 300) / 1000
                                    ElseIf locationdt.Rows.Item(j)(2) = 17 Then
                                        maindt(count)("LFC_DS_B") = ((slabdt.Rows.Item(i)(4) / 2) - 100) / 1000
                                    ElseIf locationdt.Rows.Item(j)(2) = 16 Then
                                        maindt(count)("LFC_DS_B") = ((slabdt.Rows.Item(i)(4) / 2) + 100) / 1000
                                    ElseIf locationdt.Rows.Item(j)(2) = 15 Then
                                        maindt(count)("LFC_DS_B") = ((slabdt.Rows.Item(i)(4) / 2) + 300) / 1000
                                    ElseIf locationdt.Rows.Item(j)(2) = 14 Then
                                        maindt(count)("LFC_DS_B") = ((slabdt.Rows.Item(i)(4) / 2) + 500) / 1000
                                    End If
                                    count += 1
                                    line2 &= "['" & CDate(locationdt.Rows(j)("LFC_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm:ss") & "'," & locationdt.Rows(j)("RESULT") & "],"
                                    If CDate(locationdt.Rows(j)("LFC_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm:ss") > max Then
                                        max = CDate(locationdt.Rows(j)("LFC_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm:ss")
                                    End If
                                    flag2 = 1
                                End If
                            Next
                        End If
                    End If
                End If
            Next

        End If
        rptGRID.DataSource = maindt
        rptGRID.DataBind()
        Try
            line1 = line1.Remove(line1.LastIndexOf(","))
            line2 = line2.Remove(line2.LastIndexOf(","))
        Catch ex As Exception
        End Try

        Dim strLine1 As String = ""
        Dim strLine2 As String = ""

        Dim strColour1 As String = ""
        Dim strColour2 As String = ""

        Dim strLegend1 As String = ""
        Dim strLegend2 As String = ""


        If flag1 = 1 Then
            strLine1 &= "line1,"
            strColour1 &= "'#FF0000',"
            strLegend1 &= "'LFC',"
        End If
        If flag2 = 1 Then
            strLine2 &= "line2,"
            strColour2 &= "'#FF0000',"
            strLegend2 &= "'LFC',"
        End If
        If Trim(strLine1) <> "" Then
            strLine1 = strLine1.Remove(strLine1.LastIndexOf(","))
        End If
        If Trim(strLine2) <> "" Then
            strLine2 = strLine2.Remove(strLine2.LastIndexOf(","))
        End If
        If Trim(strColour1) <> "" Then
            strColour1 = strColour1.Remove(strColour1.LastIndexOf(","))
        End If
        If Trim(strColour2) <> "" Then
            strColour2 = strColour2.Remove(strColour2.LastIndexOf(","))
        End If
        If Trim(strLegend1) <> "" Then
            strLegend1 = strLegend1.Remove(strLegend1.LastIndexOf(","))
        End If
        If Trim(strLegend2) <> "" Then
            strLegend2 = strLegend2.Remove(strLegend2.LastIndexOf(","))
        End If

        Dim slab As String = ""
        For row As Integer = 0 To slabdt.Rows.Count - 1
            Dim fl As Integer = 0
            For slabs As Integer = 0 To slabid.Rows.Count - 1
                If slabdt.Rows(row)(0) = slabid.Rows(slabs)(1) Then
                    fl = 1
                    If slabid.Rows(slabs)(0) = "LFC Predicted" Then
                        's.Append("var o = {                dashedVerticalLine: {                    name: '" & slabdt.Rows(row)(0) & "',                    x: new $.jsDate('" & CDate(slabdt.Rows(row)(1)).ToString("yyyy-MM-dd HH:mm:ss") & "').getTime(),        color: 'rgb(255,0,0)',           lineWidth: 4,                    showTooltip: true,                    tooltipFormatString: '<table style=""background-color:#77F486; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>Slab Id</td><td>:</td><td>&nbsp;</td><td>" & slabdt.Rows(row)(0) & "</td></tr></table>' }            };")
                        ''  s.Append("var o = {                dashedVerticalLine: {                    name: '" & slabdt.Rows(row)(0) & "',                    x: new $.jsDate('" & CDate(slabdt.Rows(row)(1)).ToString("yyyy-MM-dd HH:mm:ss") & "').getTime(),                    lineWidth: 2,                    showTooltip: true,                   tooltipFormatString:'" & slabdt.Rows(row)(0) & "',                    color: 'rgb(153, 120, 24)',                    shadow: false       }            };")
                        's.Append("vline1.push(o);")
                        slab &= " {name :  '" & slabdt.Rows(row)(0) & "',type: 'line',color: 'red',markLine : {lineStyle:{type: 'solid',width:10},label: {normal: {show: false}},data :[{xAxis:'" & CDate(slabdt.Rows(row)("TSM_PROD_START")).ToString("yyyy-MM-dd HH:mm:ss") & "'}]}},"
                    Else
                        's.Append("var o = {                dashedVerticalLine: {                    name: '" & slabdt.Rows(row)(0) & "',                    x: new $.jsDate('" & CDate(slabdt.Rows(row)(1)).ToString("yyyy-MM-dd HH:mm:ss") & "').getTime(),                   lineWidth: 2,                    showTooltip: true,                    tooltipFormatString: '<table style=""background-color:#77F486; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>Slab Id</td><td>:</td><td>&nbsp;</td><td>" & slabdt.Rows(row)(0) & "</td></tr></table>' }            };")
                        ''  s.Append("var o = {                dashedVerticalLine: {                    name: '" & slabdt.Rows(row)(0) & "',                    x: new $.jsDate('" & CDate(slabdt.Rows(row)(1)).ToString("yyyy-MM-dd HH:mm:ss") & "').getTime(),                    lineWidth: 2,                    showTooltip: true,                   tooltipFormatString:'" & slabdt.Rows(row)(0) & "',                    color: 'rgb(153, 120, 24)',                    shadow: false       }            };")
                        's.Append("vline1.push(o);")
                        slab &= " {name  : '" & slabdt.Rows(row)(0) & "',type: 'line',color: 'green',markLine : {lineStyle:{type: 'solid',width:10},label: {normal: {show: false}},data :[{xAxis:'" & CDate(slabdt.Rows(row)("TSM_PROD_START")).ToString("yyyy-MM-dd HH:mm:ss") & "'}]}},"
                    End If
                End If
            Next
            If fl = 0 Then
                slab &= " {name :  '" & slabdt.Rows(row)(0) & "',type: 'line',color: 'yellow',markLine : {lineStyle:{type: 'solid',width:10},label: {normal: {show: false}},data :[{xAxis:'" & CDate(slabdt.Rows(row)("TSM_PROD_START")).ToString("yyyy-MM-dd HH:mm:ss") & "'}]}},"
            End If
        Next
        If Trim(strLine1) <> "" Then
            's.Append("plot1 = $.jqplot('chart3', [" & strLine1 & "],  {title: 'LFC POSITION TOP SIDE IN CASTER',seriesColors: [" & strColour1 & "], grid: { backgroundColor: ['#ecf0f1'] },axes: {")
            's.Append("xaxis: {renderer: $.jqplot.DateAxisRenderer,tickRenderer: $.jqplot.CanvasAxisTickRenderer,tickOptions:{formatString: '%H:%M:%S',fontSize: '10pt',angle: -40},")
            's.Append("min:stDt,max: endDt,}, yaxis: {label: 'Thermocouple Number',labelRenderer: $.jqplot.CanvasAxisLabelRenderer,labelOptions: {fontFamily: 'Helvetica',fontSize: '12pt'")
            's.Append(" },tickOptions: {fontSize: '10pt',labelPosition: 'middle'},min: 3,max: 10,tickInterval: '1'},},seriesDefaults: {showLine: false,showMarkers: true,seriesColors: true},legend:{show:true,placement: 'outsideGrid',rendererOptions: {numberRows: 1, marginTop: 10 }, location: 's', labels: [" & strLegend1 & "],renderer: $.jqplot.EnhancedLegendRenderer }, ")
            's.Append("grid: true,highlighter: {show: true,sizeAdjust: 5.0,},cursor: {show: true,zoom: true}});")
            PlotLinegraph_all(line1, slab, Literal1, "main1", "plot1", "Time", "Thermocouple Number", "LFC POSITION TOP SIDE IN CASTER", min, max, 3, 10)
            lblgraph1.Text = "LFC POSITION TOP SIDE IN CASTER"
        Else
            lblgraph1.Text = "LFC POSITION TOP SIDE IN CASTER"
            Label1.Visible = True
            Label1.Text = "No LFC Found"
        End If
        ' line2
        If Trim(strLine2) <> "" Then
            's.Append("plot2 = $.jqplot('chart1', [" & strLine2 & "], {title: 'LFC POSITION BOTTOM SIDE IN CASTER',seriesColors: [" & strColour2 & "], grid: { backgroundColor: ['#ecf0f1'] },axes: {xaxis: {renderer: $.jqplot.DateAxisRenderer,tickRenderer: $.jqplot.CanvasAxisTickRenderer,tickOptions:")
            's.Append("{formatString: '%H:%M:%S',fontSize: '10pt',angle: -40},min:stDt,max: endDt,},yaxis: {label: 'Thermocouple Number',labelRenderer: $.jqplot.CanvasAxisLabelRenderer,labelOptions: {fontFamily: 'Helvetica',fontSize: '12pt'},")
            's.Append("tickOptions: {fontSize: '10pt',labelPosition: 'middle'},min: 13,max: 20,tickInterval: '1'},},seriesDefaults: {showLine: false,showMarkers: true,seriesColors: true},legend:{show:true,placement: 'outsideGrid',rendererOptions: {numberRows: 1, marginTop: 10 }, location: 's', labels: [" & strLegend2 & "], renderer: $.jqplot.EnhancedLegendRenderer }, ")
            's.Append("grid: true,highlighter: {show: true,sizeAdjust: 5.0,},cursor: {show: true,zoom: true}});")
            PlotLinegraph_all(line2, slab, Literal2, "main2", "plot2", "Time", "Thermocouple Number", "LFC POSITION BOTTOM SIDE IN CASTER", min, max, 13, 20)
            lblgraph2.Text = "LFC POSITION BOTTOM SIDE IN CASTER"
        Else
            Label2.Visible = True
            Label2.Text = "No LFC Found"
            lblgraph2.Text = "LFC POSITION BOTTOM SIDE IN CASTER"
        End If
    End Sub

    Public Sub PlotLinegraph_all(ByVal line As String, ByVal slab As String, ByVal LiteralName As Literal, ByVal ContainerName As String, ByVal PlotName As String, ByVal XAxisLabelName As String, ByVal YAxisLabelName As String, ByVal title As String, ByVal min As String, ByVal max As String, ByVal ymin As Integer, ByVal ymax As Integer)
        Try
            LiteralName.Text = ""

            ContainerName = ContainerName.Replace(" ", "_")
            Dim js As String = ""
            js &= " <script type='text/javascript'> var " & ContainerName & " = echarts.init(document.getElementById('" & ContainerName & "'));"
            js &= "option = {tooltip: {trigger: 'item'},"
            js &= "legend: {},"
            js &= "grid: {bottom:  '10%',top:'30%',containLabel: true},"
            js &= "toolbox: {show: true,feature: {saveAsImage: {}}},"
            js &= "xAxis: {type: 'time',max:'" & max & "',min:'" & min & "',axisLabel : { formatter: '{value}',fontWeight:'bold',rotate: 45},name: '" & XAxisLabelName & "',nameLocation: 'middle',nameGap: 50,nameTextStyle: {fontWeight:'bold'},"
            js &= "splitLine: {show:true,lineStyle: {color: 'grey'}}},"
            js &= " yAxis : [{type : 'value',max:" & ymax & ",min:" & ymin & ",axisLabel : {formatter: '{value}',fontWeight:'bold'},name: '" & YAxisLabelName & "',nameLocation: 'middle',nameGap: 50,nameTextStyle: {fontWeight:'bold'} }],"
            'js &= "dataZoom: [{type: 'slider',xAxisIndex: 0,filterMode: 'empty',bottom:40},{type: 'slider',yAxisIndex: 0,filterMode: 'empty'},{type: 'inside',xAxisIndex: 0,filterMode: 'empty'},{type: 'inside',yAxisIndex: 0,filterMode: 'empty'}],"
            js &= "series: [{name: 'Approx LFC Location',type: 'scatter',color: '#3e86f0' ,"
            js &= "data: [" & line & "] },"
            js &= slab
            js &= "{name: 'Awaiting for Data update',type: 'line',color: 'yellow'} ,{name: 'LFC Predicted',type: 'line',color: 'red'},{name: 'No LFC Predicted',type: 'line',color: 'green'}"
            js &= "]};"
            js &= "" & ContainerName & ".setOption(option);"
            js &= "window.onresize = function() { " & ContainerName & ".resize();};"
            js &= "</script>"
            LiteralName.Text = js
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Protected Sub btnDownload_Click(sender As Object, e As System.EventArgs) Handles btnDownload.Click
        Dim pdfDoc As New Document(PageSize.A4, 10.0F, 10.0F, 10.0F, 0.0F)

        Dim writer As PdfWriter = PdfWriter.GetInstance(pdfDoc, Response.OutputStream)

        pdfDoc.Open()

        Dim base64 As String = hf1.Value.Replace("data:image/png;base64,", "")
        Dim im As Image = Image.GetInstance(Convert.FromBase64String(base64))
        Dim im1 As Image = Image.GetInstance(Convert.FromBase64String(hf2.Value.Replace("data:image/png;base64,", "")))
        'Dim im2 As Image = Image.GetInstance(Convert.FromBase64String(hf3.Value.Replace("data:image/png;base64,", "")))
        'Dim im3 As Image = Image.GetInstance(Convert.FromBase64String(hf4.Value.Replace("data:image/png;base64,", "")))

        Dim blackHead = New Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.BLACK)
        Dim blackSubHead = New Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.BLACK)
        Dim h1 = New Paragraph(New Chunk("LFC  Report", blackHead))
        h1.Alignment = 1
        pdfDoc.Add(h1)
        Dim h2 = New Paragraph(New Chunk("Date: " & DateTime.Now.ToString("dd-MMM-yyyy"), blackSubHead))
        h2.Alignment = 1
        pdfDoc.Add(h2)

        Dim crejPer() As Single = {12, 12, 12}
        Dim c() As Single = {12, 12}
        Dim table As New PdfPTable(c)
        table.WidthPercentage = 100

        Dim table1 As New PdfPTable(c)
        table1.WidthPercentage = 100

        Dim tablerejS As New PdfPTable(crejPer)
        tablerejS.WidthPercentage = 100
        tablerejS.SpacingBefore = 20
        tablerejS.KeepTogether = True


        Dim cell1 As New PdfPCell(im, True)
        cell1.Border = 0
        cell1.Padding = 10

        Dim c0rejS As New PdfPCell(New Phrase("LFC Position Top Side In Caster", blackSubHead))
        c0rejS.Padding = 2
        c0rejS.Border = 0

        c0rejS.HorizontalAlignment = Element.ALIGN_CENTER
        tablerejS.AddCell(c0rejS)


        Dim cell2 As New PdfPCell(im1, True)
        cell2.Border = 0
        cell2.Padding = 10


        table.AddCell(c0rejS)

        Dim c0rejS1 As New PdfPCell(New Phrase("LFC Position Bottom Side In Caster", blackSubHead))
        c0rejS1.Padding = 2
        c0rejS1.Border = 0
        'c0rejS.BackgroundColor = New BaseColor(149, 183, 93)
        c0rejS1.HorizontalAlignment = Element.ALIGN_CENTER
        'c0rejS.Colspan = 3
        table.AddCell(c0rejS1)


        table.AddCell(cell1)
        table.AddCell(cell2)




        table.SpacingBefore = 10
        table1.SpacingBefore = 20
        pdfDoc.Add(table)
        table1.KeepTogether = True
        pdfDoc.Add(table1)

        Dim sw As New StringWriter()
        Dim hw As New HtmlTextWriter(sw)
        Panel1.RenderControl(hw)

        Dim ss As New iTextSharp.text.html.simpleparser.StyleSheet
        ss.LoadTagStyle(HtmlTags.TD, HtmlTags.FONTSIZE, "2pt")
        Dim sr As New StringReader(sw.ToString())
        Dim htmlparser As New HTMLWorker(pdfDoc)
        htmlparser.SetStyleSheet(ss)
        htmlparser.Parse(sr)
        XMLWorkerHelper.GetInstance().ParseXHtml(writer, pdfDoc, sr)
        pdfDoc.Close()




        Response.ContentType = "application/pdf"
        Response.AddHeader("content-disposition", "attachment;filename=LFC_REPORT.pdf")
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Write(pdfDoc)
        Response.End()
    End Sub

    Private Function CreateSimpleHtmlParagraph(ByVal text As String) As Paragraph
        Dim p As Paragraph = New Paragraph()
        Dim black = New Font(Font.FontFamily.HELVETICA, 8, Font.NORMAL, BaseColor.BLACK)
        Using sr As StringReader = New StringReader(text)
            Dim elements As List(Of IElement) = iTextSharp.text.html.simpleparser.HTMLWorker.ParseToList(sr, Nothing)

            For Each e As IElement In elements
                p.Add(e)
            Next
            p.Font = black
        End Using

        Return p
    End Function
End Class
