﻿Imports System.Data
Imports System.IO
Imports iTextSharp.text
Imports iTextSharp.text.html.simpleparser
Imports iTextSharp.text.pdf
Imports iTextSharp.tool.xml
Imports System.Net
Imports System.Data.SqlClient
Partial Class lfc_SummaryReport
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Private _getBase64String As Object

    Private Property GetBase64String(url As String) As Object
        Get
            Return _getBase64String
        End Get
        Set(value As Object)
            _getBase64String = value
        End Set
    End Property

    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
        End If
    End Sub

    Dim maindt As New DataTable

    Function getdatatable(ByVal query As String) As DataTable
        Dim fndatatable As New DataTable
        Dim connection As String = "Password=Welcome@135;Persist Security Info=True;User ID=153521;Initial Catalog=FP_PROCESS_DATA;Data Source=176.0.0.60\lptgsqldev"
        Using con As New SqlConnection(connection)
            Using cmd As New SqlCommand(query, con)
                cmd.CommandType = CommandType.Text
                Using sda As New SqlDataAdapter(cmd)
                    'Using dt As New DataTable()
                    sda.Fill(fndatatable)
                    'End Using
                End Using
            End Using
        End Using
        Return fndatatable
    End Function

    Protected Sub btnDownload_Click(sender As Object, e As System.EventArgs) Handles btnDownload.Click
        Response.Clear()
        Response.Buffer = True
        Response.ClearContent()
        Response.ClearHeaders()
        Response.Charset = ""
        Dim FileName = "Summary Lfc" + DateTime.Now + ".xls"
        Dim strwritter As New StringWriter()
        Dim htmltextwrtter As New HtmlTextWriter(strwritter)
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.ContentType = "application/vnd.ms-excel"
        Response.AddHeader("Content-Disposition", "attachment;filename=" + FileName)
        tblData.GridLines = GridLines.Both
        tblData.HeaderStyle.Font.Bold = True
        tblData.RenderControl(htmltextwrtter)
        Response.Write(strwritter.ToString())
        Response.End()

    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)
        ' Verifies that the control is rendered 
    End Sub

    Protected Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click
        If ddl1.SelectedIndex = 0 Then
            UserMsgBoxError("Select caster")
            Return
        End If

        Dim stDate As String = hfFrom.Value
        Dim enDate As String = hfTo.Value
        ''pnlChart1.Visible = True
        '  pnchart2.Visible = True
        Dim DEVICE_KEY As String = IIf(ddl1.SelectedItem.Value = 1, "13", "14")
        Dim query As String = "SELECT TSM_SLAB_ID, TSM_PROD_START,TSM_PROD_END,TSM_DEVICE_KEY,TSR_SLAB_WIDTH,TSR_SLAB_GRADE "
        query &= "FROM TSCR_SLAB_MASTER inner join TSCR_SLAB_RAW On TSCR_SLAB_MASTER.TSM_SLAB_ID=TSCR_SLAB_RAW.TSR_SLAB_ID "
        query &= "WHERE [TSM_DEVICE_KEY]='" & DEVICE_KEY & "' "
        query &= " And TSM_PROD_START >='" & CDate(stDate).AddMinutes(-10).ToString("yyyy-MM-dd HH:mm:ss") & "' "
        query &= "AND TSM_PROD_END<='" & CDate(enDate).AddMinutes(10).ToString("yyyy-MM-dd HH:mm:ss") & "' order by TSM_PROD_START asc "
        'query &= "And TSM_SLAB_ID Like '%" & heat.Substring(1) & "%' order by TSM_PROD_START asc"
        Dim slabdt As DataTable = getdatatable(query)


        maindt.Columns.Add("Slab_ID")
        maindt.Columns.Add("Top")
        maindt.Columns.Add("Bot")
        maindt.Columns.Add("Grade")
        maindt.Columns.Add("Slab_width")
        Dim count As Short = 0
        For i As Short = 0 To slabdt.Rows.Count - 1
            Dim slbstart = CDate(slabdt(i)("TSM_PROD_START"))
            Dim slabend = CDate(slabdt(i)("TSM_PROD_END"))
            Dim query1 As String = "select decision,SLAB_ID from TSCR_LFC_DECISION where SLAB_ID='" & slabdt.Rows.Item(i)("TSM_Slab_ID") & "'"
            Dim decisiondt As DataTable = getdatatable(query1)
            Dim lfccount_top As Short = 0
            Dim lfccount_bot As Short = 0
            If decisiondt.Rows.Count > 0 Then
                If decisiondt.Rows(0)(0) = "LFC Predicted" Then
                    Dim location_query As String = "SELECT LFC_TIMESTAMP,REMARKS, "
                    location_query &= "SUBSTRING(REMARKS,PATINDEX('%[0-9]%', REMARKS),(CASE WHEN PATINDEX('%[^0-9]%', STUFF(REMARKS, 1, (PATINDEX('%[0-9]%', REMARKS) - 1), '')) = 0 THEN LEN(REMARKS) ELSE (PATINDEX('%[^0-9]%', STUFF(REMARKS, 1, (PATINDEX('%[0-9]%', REMARKS) - 1), ''))) - 1 END )) AS RESULT,"
                    location_query &= "[LFC_FROM_TAIL] As LFC_TAIL,PROD_START_DATETIME,PROD_END_DATETIME,LFC_FROM_TAIL,SLAB_ID FROM TSCR_LFC_CAL_DATA2 WHERE SLAB_ID='" & slabdt.Rows.Item(i)(0) & "'"
                    Dim dt As DataTable = getdatatable(location_query)
                    For j As Short = 0 To dt.Rows.Count - 1
                        If Not IsDBNull(dt.Rows(j)(2)) Then
                            If (dt.Rows(j)(2)) < 10 Then
                                lfccount_top += 1

                            ElseIf (dt.Rows(j)(2)) > 10 Then
                                lfccount_bot += 1
                            End If
                        End If
                    Next
                End If
            End If


            maindt.Rows.Add()
            maindt(count)("Slab_ID") = slabdt.Rows.Item(i)(0)
            maindt(count)("Top") = lfccount_top
            maindt(count)("Bot") = lfccount_bot
            maindt(count)("Grade") = slabdt.Rows.Item(i)(5)
            maindt(count)("Slab_width") = slabdt.Rows.Item(i)(4)
            count += 1
        Next
        tblData.DataSource = maindt
        tblData.DataBind()

        maindt.Columns.Add("chart", GetType(Integer))
        maindt.Columns.Add("SLAB", GetType(Integer))

        For i As Short = 0 To maindt.Rows.Count - 1
            maindt.Rows(i)("chart") = Math.Max(Integer.Parse(maindt.Rows(i)("Top")), Integer.Parse(maindt.Rows(i)("Bot")))
        Next

        'For i As Short = 0 To maindt.Rows.Count - 1
        '    maindt.Rows(i)("SLAB") = (maindt.Rows(i)("Slab_ID"))
        'Next



        Dim zeroCount As Integer = maindt.Compute("count(chart)", "chart=0")
        Dim onethree As Integer = maindt.Compute("count(chart)", "chart>=1 and chart<=3")
        Dim foursix As Integer = maindt.Compute("count(chart)", "chart>=4 and chart<=6")
        Dim others As Integer = maindt.Compute("count(chart)", "chart>=7")
        Literal1.Text = ""
        Dim s As New StringBuilder("<script>$(document).ready(function(){$.jqplot.config.enablePlugins=!0;plot1=$.jqplot('lfcgraph',[[" & zeroCount & "," & onethree & "," & foursix & "," & others & "]],{animate:!$.jqplot.use_excanvas,seriesDefaults:{renderer:$.jqplot.BarRenderer,rendererOptions:{ varyBarColor : true,barMargin: 50 },pointLabels:{show:true}},axesDefaults: { tickOptions: { fontSize:'10pt' } },axes:{xaxis:{label:'LFC Data Count Range',renderer:$.jqplot.CategoryAxisRenderer,ticks:['0','1-3','4-6','>6']}, yaxis: { label:  'Number of SLAB ',labelRenderer: $.jqplot.CanvasAxisLabelRenderer}}, seriesColors: ['#008000','#ffc4c4','#e84545','#990909'],highlighter:{show:!0}})});</script>")

        Literal1.Text = s.ToString
        If maindt.Rows.Count > 0 Then
            tblData.UseAccessibleHeader = True
            tblData.HeaderRow.TableSection = TableRowSection.TableHeader
        End If


        slabdt.Clear()
        maindt.Clear()
        ' ddl2.Items.Insert(0, "Select")
        ' Literal1.Text = "<script>$('#chart3').empty();</script>"

    End Sub
    Private Function CreateSimpleHtmlParagraph(ByVal text As String) As Paragraph
        Dim p As Paragraph = New Paragraph()
        Dim black = New Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL, BaseColor.BLACK)
        Using sr As StringReader = New StringReader(text)
            Dim elements As List(Of IElement) = iTextSharp.text.html.simpleparser.HTMLWorker.ParseToList(sr, Nothing)

            For Each e As IElement In elements
                p.Add(e)
            Next
            p.Font = black
        End Using

        Return p
    End Function
End Class
