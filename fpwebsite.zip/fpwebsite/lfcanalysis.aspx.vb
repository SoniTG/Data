﻿Imports System.Data
Imports System.IO
Partial Class lfcanalysis
    Inherits System.Web.UI.Page
End Class
