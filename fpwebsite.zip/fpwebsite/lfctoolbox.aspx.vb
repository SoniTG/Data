﻿Imports System.Data
Imports System.IO
Imports iTextSharp.text
Imports iTextSharp.text.html.simpleparser
Imports iTextSharp.text.pdf
Imports iTextSharp.tool.xml
Imports System.Net
Imports iTextSharp.text.html
Imports System.Data.SqlClient

Partial Class lfctoolbox
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Private _getBase64String As Object

    Private Property GetBase64String(url As String) As Object
        Get
            Return _getBase64String
        End Get
        Set(value As Object)
            _getBase64String = value
        End Set
    End Property

    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then

            Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))



        End If
    End Sub

    Dim maindt As New DataTable




    Protected Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click
        If ddl1.SelectedIndex = 0 Then
            UserMsgBoxError("Select caster")
            Return
        End If

        Dim stDate As String = hfFrom.Value
        Dim enDate As String = hfTo.Value

        Dim ds As DataSet = objController.GetLFCData(stDate, enDate, ddl1.SelectedItem.Value)
        ddl2.DataSource = ds.Tables(0)
        ddl2.DataTextField = "HEAT_ID"
        ddl2.DataValueField = "VALCOL"
        ddl2.DataBind()
        If ddl1.SelectedItem.Value = 2 Then
            rptGRID.Visible = False
        End If
        If ddl1.SelectedItem.Value = 1 Then
            rptGRID.Visible = False
        End If

        ddl2.Items.Insert(0, "Select")
        Literal1.Text = "<script>$('#chart3').empty();</script>"

    End Sub
    Function getdatatable(ByVal query As String) As DataTable
        Dim fndatatable As New DataTable
        Dim connection As String = "Password=Welcome@135;Persist Security Info=True;User ID=153521;Initial Catalog=FP_PROCESS_DATA;Data Source=176.0.0.60\lptgsqldev"
        Using con As New SqlConnection(connection)
            Using cmd As New SqlCommand(query, con)
                cmd.CommandType = CommandType.Text
                Using sda As New SqlDataAdapter(cmd)
                    'Using dt As New DataTable()
                    sda.Fill(fndatatable)
                    'End Using
                End Using
            End Using
        End Using
        Return fndatatable
    End Function
    Protected Sub ddl2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddl2.SelectedIndexChanged
        Label1.Visible = False
        Label1.Text = ""
        Label2.Visible = False
        Label2.Text = ""
        If ddl2.SelectedIndex = 0 Then
            Literal1.Text = "<script>$('#chart3').empty();</script>"
            Return
        End If
        rptGRID.Visible = True
        chartdiv.Visible = True
        Dim hid() As String = ddl2.SelectedItem.Value.Split("#")
        Dim heatno As String = hid(0)
        Dim stDate As String = hid(1)
        Dim enDate As String = hid(2)

        Dim ds As DataSet = objController.GetLFCChartData(stDate, enDate, heatno, ddl1.SelectedItem.Text)
        Dim dt As DataTable = ds.Tables(0)
        Dim dt1 As DataTable = ds.Tables(1)

        Dim noDataIndicator As String = ""
        dt.DefaultView.Sort = "LFC_TIMESTAMP ASC"
        dt = dt.DefaultView.ToTable
        dt1.DefaultView.Sort = "TSM_PROD_START ASC"
        dt1 = dt1.DefaultView.ToTable

        maindt.Columns.Add("Slab_ID")
        maindt.Columns.Add("LFC_DS_T")
        maindt.Columns.Add("LFC_Tail_T")
        maindt.Columns.Add("LFC_time_T")
        maindt.Columns.Add("LFC_DS_B")
        maindt.Columns.Add("LFC_Tail_B")
        maindt.Columns.Add("LFC_time_B")
        maindt.Columns.Add("Grade")
        maindt.Columns.Add("Slab_width")
        maindt.Columns.Add("RESULT")
        maindt.Columns.Add("REMARKS")
        maindt.Columns.Add("LFC_TIMESTAMP")
        Dim count As Short = 0

        Dim nulldt As New DataTable
        nulldt.Columns.Add("Datetime")
        nulldt.Columns.Add("Remarks")
        Dim count2 As Short = 0
        Dim slabid As New DataTable
        For i As Integer = 0 To dt.Rows.Count - 1
            'Dim nullarry As New ArrayList
            If IsDBNull(dt.Rows.Item(i)(2)) Then
                nulldt.Rows.Add()
                nulldt(count2)("Datetime") = dt.Rows.Item(i)(0)
                nulldt(count2)("Remarks") = dt.Rows.Item(i)(1)
                count2 += 1
                Continue For
            End If

            For j As Integer = 0 To dt1.Rows.Count - 1

                Dim query As String = "select decision,SLAB_ID from TSCR_LFC_DECISION where SLAB_ID='" & dt1.Rows.Item(j)(0) & "'"
                Dim decisiondt As DataTable = getdatatable(query)
                If decisiondt.Rows.Count > 0 Then
                    If j = 0 Then
                        slabid = decisiondt.Copy()
                    Else
                        slabid.Merge(decisiondt)
                    End If
                    If decisiondt.Rows(0)(0) = "LFC Predicted" Then
                        If dt.Rows.Item(i)(0) >= dt1.Rows.Item(j)(1) And dt.Rows.Item(i)(0) <= dt1.Rows.Item(j)(2) And dt.Rows.Item(i)(2) < 10 Then
                            maindt.Rows.Add()
                            maindt(count)("Slab_ID") = dt1.Rows.Item(j)(0)
                            maindt(count)("LFC_Tail_T") = dt.Rows.Item(i)(3)
                            maindt(count)("LFC_time_T") = dt.Rows.Item(i)(0)
                            maindt(count)("Slab_width") = dt1.Rows.Item(j)(4)
                            maindt(count)("GRADE") = dt1.Rows.Item(j)(5)

                            maindt(count)("RESULT") = dt.Rows.Item(i)(2)
                            maindt(count)("REMARKS") = dt.Rows.Item(i)(1)
                            maindt(count)("LFC_TIMESTAMP") = dt.Rows.Item(i)(0)

                            If dt.Rows.Item(i)(2) = 4 Then
                                maindt(count)("LFC_DS_T") = ((dt1.Rows.Item(j)(4) / 2) - 500) / 1000
                            ElseIf dt.Rows.Item(i)(2) = 5 Then
                                maindt(count)("LFC_DS_T") = ((dt1.Rows.Item(j)(4) / 2) - 300) / 1000
                            ElseIf dt.Rows.Item(i)(2) = 6 Then
                                maindt(count)("LFC_DS_T") = ((dt1.Rows.Item(j)(4) / 2) - 100) / 1000
                            ElseIf dt.Rows.Item(i)(2) = 7 Then
                                maindt(count)("LFC_DS_T") = ((dt1.Rows.Item(j)(4) / 2) + 100) / 1000
                            ElseIf dt.Rows.Item(i)(2) = 8 Then
                                maindt(count)("LFC_DS_T") = ((dt1.Rows.Item(j)(4) / 2) + 300) / 1000
                            ElseIf dt.Rows.Item(i)(2) = 9 Then
                                maindt(count)("LFC_DS_T") = ((dt1.Rows.Item(j)(4) / 2) + 500) / 1000
                            End If
                            count += 1
                        ElseIf dt.Rows.Item(i)(0) >= dt1.Rows.Item(j)(1) And dt.Rows.Item(i)(0) <= dt1.Rows.Item(j)(2) And dt.Rows.Item(i)(2) > 10 Then
                            maindt.Rows.Add()
                            maindt(count)("Slab_ID") = dt1.Rows.Item(j)(0)
                            maindt(count)("LFC_Tail_B") = dt.Rows.Item(i)(3)
                            maindt(count)("LFC_time_B") = dt.Rows.Item(i)(0)
                            maindt(count)("Grade") = dt1.Rows.Item(j)(5)
                            maindt(count)("Slab_width") = dt1.Rows.Item(j)(4)

                            maindt(count)("RESULT") = dt.Rows.Item(i)(2)
                            maindt(count)("REMARKS") = dt.Rows.Item(i)(1)
                            maindt(count)("LFC_TIMESTAMP") = dt.Rows.Item(i)(0)

                            If dt.Rows.Item(i)(2) = 19 Then
                                maindt(count)("LFC_DS_B") = ((dt1.Rows.Item(j)(4) / 2) - 500) / 1000
                            ElseIf dt.Rows.Item(i)(2) = 18 Then
                                maindt(count)("LFC_DS_B") = ((dt1.Rows.Item(j)(4) / 2) - 300) / 1000
                            ElseIf dt.Rows.Item(i)(2) = 17 Then
                                maindt(count)("LFC_DS_B") = ((dt1.Rows.Item(j)(4) / 2) - 100) / 1000
                            ElseIf dt.Rows.Item(i)(2) = 16 Then
                                maindt(count)("LFC_DS_B") = ((dt1.Rows.Item(j)(4) / 2) + 100) / 1000
                            ElseIf dt.Rows.Item(i)(2) = 15 Then
                                maindt(count)("LFC_DS_B") = ((dt1.Rows.Item(j)(4) / 2) + 300) / 1000
                            ElseIf dt.Rows.Item(i)(2) = 14 Then
                                maindt(count)("LFC_DS_B") = ((dt1.Rows.Item(j)(4) / 2) + 500) / 1000
                            End If
                            count += 1
                        End If
                    End If
                End If
            Next
        Next

        Dim dt_summary As New DataTable
        dt_summary.Columns.Add("SLAB_ID")
        dt_summary.Columns.Add("TOP_SIDE")
        dt_summary.Columns.Add("BOT_SIDE")
        dt_summary.Columns.Add("Grade")
        dt_summary.Columns.Add("Slab_width")
        Dim count1 As Short = 0

        Dim maindt_view As DataView = maindt.DefaultView

        For i As Short = 0 To dt1.Rows.Count - 1
            dt_summary.Rows.Add()
            dt_summary(count1)("TOP_SIDE") = maindt.Compute("count(LFC_DS_T)", "Convert(LFC_DS_T,'System.Double')>0 and Slab_ID='" & dt1.Rows.Item(i)(0) & "'")
            dt_summary(count1)("BOT_SIDE") = maindt.Compute("count(LFC_DS_B)", "Convert(LFC_DS_B,'System.Double')>0 and Slab_ID='" & dt1.Rows.Item(i)(0) & "'")
            dt_summary(count1)("SLAB_ID") = dt1.Rows.Item(i)(0)
            dt_summary(count1)("Grade") = dt1.Rows.Item(i)(5)
            dt_summary(count1)("Slab_width") = dt1.Rows.Item(i)(4)
            count1 += 1

        Next

        rptGRID.DataSource = maindt
        rptGRID.DataBind()
        'If maindt.Rows.Count > 0 Then

        'Else
        '    DescTxt.Visible = True
        '    DescTxt.Text = "No Data"

        'End If

        'If maindt.Rows.Count = 0 Then
        '    Dim FooterTemplate As Control = rptGRID.Controls(rptGRID.Controls.Count - 1).Controls(0)
        '    FooterTemplate.FindControl("trEmpty").Visible = False
        'End If




        'Dim dv As DataView = dt.DefaultView
        'dv.RowFilter = "LEN(RESULT) = 1"
        'Dim dtSingle As DataTable = dv.ToTable
        'dv.RowFilter = ""

        'dv = dt.DefaultView
        'dv.RowFilter = "LEN(RESULT) = 2"
        'Dim dtDouble As DataTable = dv.ToTable
        'dv.RowFilter = ""


        'dv = dtSingle.DefaultView
        'dv.RowFilter = "SUBSTRING(REMARKS,1,3)='LFC'"
        'Dim dtSingle_LFC As DataTable = dv.ToTable
        'dv.RowFilter = ""

        'dv = dtSingle.DefaultView
        'dv.RowFilter = "SUBSTRING(REMARKS,1,3)='Ori'"
        'Dim dtSingle_Orig As DataTable = dv.ToTable
        'dv.RowFilter = ""

        'dv = dt.DefaultView
        'dv.RowFilter = "SUBSTRING(REMARKS,1,3)='LFC'"
        'Dim dtDouble_LFC As DataTable = dv.ToTable
        'dv.RowFilter = ""

        'dv = dt.DefaultView
        'dv.RowFilter = "SUBSTRING(REMARKS,1,3)='Ori'"
        'Dim dtDouble_Orig As DataTable = dv.ToTable

        'dv = dt.DefaultView
        'dv.RowFilter = "SUBSTRING(REMARKS,1,3)='TC'"
        'Dim TCSingleDt As DataTable = dv.ToTable
        'dv.RowFilter = ""



        'dv = dt.DefaultView
        'dv.RowFilter = "SUBSTRING(REMARKS,1,3)='TC'"
        'Dim dtdouble_TC As DataTable = dv.ToTable
        'dv.RowFilter = ""



        'dv = dt.DefaultView
        'dv.RowFilter = "SUBSTRING(REMARKS,1,10)='Incomplete'"
        'Dim dtSingleIncompete As DataTable = dv.ToTable
        'dv.RowFilter = ""

        'dv = dt.DefaultView
        'dv.RowFilter = "SUBSTRING(REMARKS,1,10)='Incomplete'"
        'Dim dtDoubleIncompete As DataTable = dv.ToTable
        'dv.RowFilter = ""


        Dim dv As DataView = maindt.DefaultView
        dv.RowFilter = "LEN(RESULT) = 1"
        Dim dtSingle As DataTable = dv.ToTable
        dv.RowFilter = ""

        dv = maindt.DefaultView
        dv.RowFilter = "LEN(RESULT) = 2"
        Dim dtDouble As DataTable = dv.ToTable
        dv.RowFilter = ""


        dv = dtSingle.DefaultView
        dv.RowFilter = "SUBSTRING(REMARKS,1,3)='LFC'"
        Dim dtSingle_LFC As DataTable = dv.ToTable
        dv.RowFilter = ""

        dv = dtSingle.DefaultView
        dv.RowFilter = "SUBSTRING(REMARKS,1,3)='Ori'"
        Dim dtSingle_Orig As DataTable = dv.ToTable
        dv.RowFilter = ""

        dv = maindt.DefaultView
        dv.RowFilter = "SUBSTRING(REMARKS,1,3)='LFC'"
        Dim dtDouble_LFC As DataTable = dv.ToTable
        dv.RowFilter = ""

        dv = maindt.DefaultView
        dv.RowFilter = "SUBSTRING(REMARKS,1,3)='Ori'"
        Dim dtDouble_Orig As DataTable = dv.ToTable

        dv = maindt.DefaultView
        dv.RowFilter = "SUBSTRING(REMARKS,1,3)='TC'"
        Dim TCSingleDt As DataTable = dv.ToTable
        dv.RowFilter = ""



        dv = maindt.DefaultView
        dv.RowFilter = "SUBSTRING(REMARKS,1,3)='TC'"
        Dim dtdouble_TC As DataTable = dv.ToTable
        dv.RowFilter = ""



        dv = maindt.DefaultView
        dv.RowFilter = "SUBSTRING(REMARKS,1,10)='Incomplete'"
        Dim dtSingleIncompete As DataTable = dv.ToTable
        dv.RowFilter = ""

        dv = maindt.DefaultView
        dv.RowFilter = "SUBSTRING(REMARKS,1,10)='Incomplete'"
        Dim dtDoubleIncompete As DataTable = dv.ToTable
        dv.RowFilter = ""

        Dim line1 As String = "var line1=["
        Dim line2 As String = "var line2=["
        Dim line3 As String = "var line3=["
        Dim line4 As String = "var line4=["
        Dim line5 As String = "var line5=["
        Dim line6 As String = "var line6=["
        Dim line7 As String = "var line7=["
        Dim line8 As String = "var line8=["


        For i As Short = 0 To dtSingle_LFC.Rows.Count - 1
            If i > 0 Then
                line1 &= ", "
            End If
            line1 &= "['" & CDate(dtSingle_LFC.Rows(i)("LFC_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm:ss") & "'," & dtSingle_LFC.Rows(i)("RESULT") & "]"
        Next
        line1 &= "]; "

        For i As Short = 0 To dtSingle_Orig.Rows.Count - 1
            If i > 0 Then
                line2 &= ", "
            End If
            line2 &= "['" & CDate(dtSingle_Orig.Rows(i)("LFC_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm:ss") & "'," & dtSingle_Orig.Rows(i)("RESULT") & "]"
        Next

        line2 &= "]; "

        For i As Short = 0 To dtDouble_LFC.Rows.Count - 1
            If i > 0 Then
                line3 &= ", "
            End If
            line3 &= "['" & CDate(dtDouble_LFC.Rows(i)("LFC_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm:ss") & "'," & dtDouble_LFC.Rows(i)("RESULT") & "]"
        Next
        line3 &= "]; "
        For i As Short = 0 To dtDouble_Orig.Rows.Count - 1
            If i > 0 Then
                line4 &= ", "
            End If
            line4 &= "['" & CDate(dtDouble_Orig.Rows(i)("LFC_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm:ss") & "'," & dtDouble_Orig.Rows(i)("RESULT") & "]"
        Next
        line4 &= "]; "

        For i As Short = 0 To TCSingleDt.Rows.Count - 1
            If i > 0 Then
                line5 &= ", "
            End If

            line5 &= "['" & CDate(TCSingleDt.Rows(i)("LFC_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm:ss") & "',null]"
        Next
        line5 &= "]; "

        For i As Short = 0 To dtSingleIncompete.Rows.Count - 1
            If i > 0 Then
                line6 &= ", "
            End If
            line6 &= "['" & CDate(dtSingleIncompete.Rows(i)("LFC_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm:ss") & "',null]"
        Next
        line6 &= "]; "



        For i As Short = 0 To dtDoubleIncompete.Rows.Count - 1
            If i > 0 Then
                line7 &= ", "
            End If

            line7 &= "['" & CDate(dtDoubleIncompete.Rows(i)("LFC_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm:ss") & "',null]"
        Next
        line7 &= "]; "

        For i As Short = 0 To dtdouble_TC.Rows.Count - 1
            If i > 0 Then
                line8 &= ", "
            End If
            line8 &= "['" & CDate(dtdouble_TC.Rows(i)("LFC_TIMESTAMP")).ToString("yyyy-MM-dd HH:mm:ss") & "',null]"
        Next
        line8 &= "]; "




        Dim strLine1 As String = ""
        Dim strLine2 As String = ""
        Dim strLine3 As String = ""
        Dim strLine4 As String = ""
        Dim strLine5 As String = ""
        Dim strLine6 As String = ""


        Dim strColour1 As String = ""
        Dim strColour2 As String = ""
        Dim strColour3 As String = ""
        Dim strColour4 As String = ""
        Dim strColour5 As String = ""
        Dim strColour6 As String = ""


        Dim strLegend1 As String = ""
        Dim strLegend2 As String = ""
        Dim strLegend3 As String = ""
        Dim strLegend4 As String = ""
        Dim strLegend5 As String = ""
        Dim strLegend6 As String = ""


        If dtSingle_LFC.Rows.Count > 0 Then
            strLine1 &= "line1,"
            strColour1 &= "'#EDC938',"
            strLegend1 &= "'Speed Change',"
        End If
        If dtSingle_Orig.Rows.Count > 0 Then
            strLine1 &= "line2,"
            strColour1 &= "'#FF0000',"
            strLegend1 &= "'LFC',"
        End If
        If dtDouble_LFC.Rows.Count > 0 Then
            strLine2 &= "line3,"
            strColour2 &= "'#EDC938',"
            strLegend2 &= "'Speed Change',"
        End If
        If dtDouble_Orig.Rows.Count > 0 Then
            strLine2 &= "line4,"
            strColour2 &= "'#FF0000',"
            strLegend2 &= "'LFC',"
        End If

        If TCSingleDt.Rows.Count > 0 Then
            strLine3 &= "line5,"
            strColour3 &= "'#FFFF00',"
            'strLegend3 &= "'TC Data Not Available',"
        End If

        If dtSingleIncompete.Rows.Count > 0 Then
            strLine4 &= "line6,"
            strColour4 &= "'#F9AA0C',"
            'strLegend4 &= "'Incomplete TC Data',"
        End If




        If dtDoubleIncompete.Rows.Count > 0 Then
            strLine5 &= "line7,"
            strColour5 &= "'#F9AA0C',"
            'strLegend5 &= "'Incomplete TC Data',"
        End If

        If dtdouble_TC.Rows.Count > 0 Then
            strLine6 &= "line8,"
            strColour6 &= "'#FFFF00',"
            'strLegend6 &= "'TC Data Not Available',"
        End If


        If Trim(strLine1) <> "" Then
            strLine1 = strLine1.Remove(strLine1.LastIndexOf(","))
        End If
        If Trim(strLine2) <> "" Then
            strLine2 = strLine2.Remove(strLine2.LastIndexOf(","))
        End If
        If Trim(strLine3) <> "" Then
            strLine3 = strLine3.Remove(strLine3.LastIndexOf(","))
        End If

        If Trim(strLine4) <> "" Then
            strLine4 = strLine4.Remove(strLine4.LastIndexOf(","))
        End If
        If Trim(strLine5) <> "" Then
            strLine5 = strLine5.Remove(strLine5.LastIndexOf(","))
        End If


        If Trim(strLine6) <> "" Then
            strLine6 = strLine6.Remove(strLine6.LastIndexOf(","))
        End If

        If Trim(strColour1) <> "" Then
            strColour1 = strColour1.Remove(strColour1.LastIndexOf(","))
        End If
        If Trim(strColour2) <> "" Then
            strColour2 = strColour2.Remove(strColour2.LastIndexOf(","))
        End If

        If Trim(strColour3) <> "" Then
            strColour3 = strColour3.Remove(strColour3.LastIndexOf(","))
        End If


        If Trim(strColour4) <> "" Then
            strColour4 = strColour4.Remove(strColour4.LastIndexOf(","))
        End If
        If Trim(strColour5) <> "" Then
            strColour5 = strColour5.Remove(strColour5.LastIndexOf(","))
        End If
        If Trim(strColour6) <> "" Then
            strColour6 = strColour6.Remove(strColour6.LastIndexOf(","))
        End If

        If Trim(strLegend1) <> "" Then
            strLegend1 = strLegend1.Remove(strLegend1.LastIndexOf(","))
        End If
        If Trim(strLegend2) <> "" Then
            strLegend2 = strLegend2.Remove(strLegend2.LastIndexOf(","))
        End If

        If Trim(strLegend3) <> "" Then
            strLegend3 = strLegend3.Remove(strLegend3.LastIndexOf(","))
        End If

        If Trim(strLegend4) <> "" Then
            strLegend4 = strLegend4.Remove(strLegend4.LastIndexOf(","))
        End If

        If Trim(strLegend5) <> "" Then
            strLegend5 = strLegend5.Remove(strLegend5.LastIndexOf(","))
        End If


        If Trim(strLegend6) <> "" Then
            strLegend6 = strLegend6.Remove(strLegend6.LastIndexOf(","))
        End If




        dt.Clear()
        dtSingle.Clear()
        dtSingle_LFC.Clear()
        dtSingle_Orig.Clear()
        dtDouble.Clear()
        dtDouble_LFC.Clear()
        dtDouble_Orig.Clear()
        dtSingleIncompete.Clear()

        TCSingleDt.Clear()
        maindt.Clear()
        If maindt.Rows.Count = 0 Then
            noDataIndicator = "noDataIndicator: { show: true, indicator: 'No LFC Found.' },"
        End If


        Dim s As New StringBuilder("")
        s.Append("<script>$(document).ready(function () {var plot1,plot2;")
        s.Append(line1)
        s.Append(line2)
        s.Append(line3)
        s.Append(line4)
        s.Append(line5)
        s.Append(line6)
        s.Append(line7)
        s.Append(line8)

        s.Append("var endDt = moment('" & enDate & "').add(10, 'minutes').format('YYYY-MM-DD hh:mm:ss a');")
        s.Append("var stDt = moment('" & stDate & "').add(-10, 'minutes').format('YYYY-MM-DD hh:mm:ss a');")
        If Trim(strLine1) <> "" Then
            s.Append("plot1 = $.jqplot('chart3', [" & strLine1 & "],  {title: 'LFC POSITION TOP SIDE IN CASTER',seriesColors: [" & strColour1 & "], grid: { backgroundColor: ['#ecf0f1'] },axes: {")
            s.Append("xaxis: {renderer: $.jqplot.DateAxisRenderer,tickRenderer: $.jqplot.CanvasAxisTickRenderer,tickOptions:{formatString: '%H:%M:%S',fontSize: '10pt',angle: -40},")
            s.Append("min:stDt,max: endDt,}, yaxis: {label: 'Thermocouple Number',labelRenderer: $.jqplot.CanvasAxisLabelRenderer,labelOptions: {fontFamily: 'Helvetica',fontSize: '12pt'")
            s.Append(" },tickOptions: {fontSize: '10pt',labelPosition: 'middle'},min: 3,max: 10,tickInterval: '1'},},seriesDefaults: {showLine: false,showMarkers: true,seriesColors: true},legend:{show:true,placement: 'outsideGrid',rendererOptions: {numberRows: 1, marginTop: 10 }, location: 's', labels: [" & strLegend1 & "],renderer: $.jqplot.EnhancedLegendRenderer }, ")
            s.Append("grid: true,highlighter: {show: true,sizeAdjust: 5.0,},cursor: {show: true,zoom: true}});")
        Else
            Label1.Visible = True
            Label1.Text = "No LFC Found"
        End If
        ' line2
        If Trim(strLine2) <> "" Then
            s.Append("plot2 = $.jqplot('chart1', [" & strLine2 & "], {title: 'LFC POSITION BOTTOM SIDE IN CASTER',seriesColors: [" & strColour2 & "], grid: { backgroundColor: ['#ecf0f1'] },axes: {xaxis: {renderer: $.jqplot.DateAxisRenderer,tickRenderer: $.jqplot.CanvasAxisTickRenderer,tickOptions:")
            s.Append("{formatString: '%H:%M:%S',fontSize: '10pt',angle: -40},min:stDt,max: endDt,},yaxis: {label: 'Thermocouple Number',labelRenderer: $.jqplot.CanvasAxisLabelRenderer,labelOptions: {fontFamily: 'Helvetica',fontSize: '12pt'},")
            s.Append("tickOptions: {fontSize: '10pt',labelPosition: 'middle'},min: 13,max: 20,tickInterval: '1'},},seriesDefaults: {showLine: false,showMarkers: true,seriesColors: true},legend:{show:true,placement: 'outsideGrid',rendererOptions: {numberRows: 1, marginTop: 10 }, location: 's', labels: [" & strLegend2 & "], renderer: $.jqplot.EnhancedLegendRenderer }, ")
            s.Append("grid: true,highlighter: {show: true,sizeAdjust: 5.0,},cursor: {show: true,zoom: true}});")
        Else
            Label2.Visible = True
            Label2.Text = "No LFC Found"
        End If
        s.Append("var vline1=[];")




        Dim dtime As DateTime
        For row As Integer = 0 To ds.Tables(1).Rows.Count - 1
            For slabs As Integer = 0 To slabid.Rows.Count - 1
                If ds.Tables(1).Rows(row)(0) = slabid.Rows(slabs)(1) Then
                    If slabid.Rows(slabs)(0) = "LFC Predicted" Then
                        s.Append("var o = {                dashedVerticalLine: {                    name: '" & ds.Tables(1).Rows(row)(0) & "',                    x: new $.jsDate('" & CDate(ds.Tables(1).Rows(row)(1)).ToString("yyyy-MM-dd HH:mm:ss") & "').getTime(),        color: 'rgb(255,0,0)',           lineWidth: 4,                    showTooltip: true,                    tooltipFormatString: '<table style=""background-color:#77F486; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>Slab Id</td><td>:</td><td>&nbsp;</td><td>" & ds.Tables(1).Rows(row)(0) & "</td></tr></table>' }            };")
                        '  s.Append("var o = {                dashedVerticalLine: {                    name: '" & ds.Tables(1).Rows(row)(0) & "',                    x: new $.jsDate('" & CDate(ds.Tables(1).Rows(row)(1)).ToString("yyyy-MM-dd HH:mm:ss") & "').getTime(),                    lineWidth: 2,                    showTooltip: true,                   tooltipFormatString:'" & ds.Tables(1).Rows(row)(0) & "',                    color: 'rgb(153, 120, 24)',                    shadow: false       }            };")
                        s.Append("vline1.push(o);")
                    Else
                        s.Append("var o = {                dashedVerticalLine: {                    name: '" & ds.Tables(1).Rows(row)(0) & "',                    x: new $.jsDate('" & CDate(ds.Tables(1).Rows(row)(1)).ToString("yyyy-MM-dd HH:mm:ss") & "').getTime(),                   lineWidth: 2,                    showTooltip: true,                    tooltipFormatString: '<table style=""background-color:#77F486; font-weight:bold; font-size:10pt"" class=""jqplot-highlighter""> \ <tr><td>Slab Id</td><td>:</td><td>&nbsp;</td><td>" & ds.Tables(1).Rows(row)(0) & "</td></tr></table>' }            };")
                        '  s.Append("var o = {                dashedVerticalLine: {                    name: '" & ds.Tables(1).Rows(row)(0) & "',                    x: new $.jsDate('" & CDate(ds.Tables(1).Rows(row)(1)).ToString("yyyy-MM-dd HH:mm:ss") & "').getTime(),                    lineWidth: 2,                    showTooltip: true,                   tooltipFormatString:'" & ds.Tables(1).Rows(row)(0) & "',                    color: 'rgb(153, 120, 24)',                    shadow: false       }            };")
                        s.Append("vline1.push(o);")
                    End If
                End If
            Next


            If row = 0 Then
                dtime = CDate(ds.Tables(1).Rows(row)(2))
            Else
                If dtime < CDate(ds.Tables(1).Rows(row)(2)) Then
                    dtime = CDate(ds.Tables(1).Rows(row)(2))
                End If
            End If



            If row = ds.Tables(1).Rows.Count - 1 Then
                s.Append("var o = {                verticalLine: {                    name: '" & ds.Tables(1).Rows(row)(0) & "',                    x: new $.jsDate('" & dtime.ToString("yyyy-MM-dd HH:mm:ss") & "').getTime(),                    lineWidth: 4,                    showTooltip: true,                    tooltipFormatString:'" & ds.Tables(1).Rows(row)(0) & "',                    color: 'rgb(255, 0, 0)',                    shadow: false                }            };")
                s.Append("vline1.push(o);")

            End If

        Next


        For k As Integer = 0 To ds.Tables(0).Rows.Count - 1

            If IsDBNull(ds.Tables(0).Rows.Item(k)(2)) OrElse String.IsNullOrEmpty(ds.Tables(0).Rows.Item(k)(2)) Then
                s.Append("var o = {                verticalLine: {                    name: '',                     x: new $.jsDate('" & CDate(ds.Tables(0).Rows(k)(0)).ToString("yyyy-MM-dd HH:mm:ss") & "').getTime(),                    lineWidth: 5,                    showTooltip: true,  legend:{show:true,placement: 'outsideGrid',rendererOptions: {numberRows: 1,numberCols:2, marginTop: 10 }, location: 's', labels: ['TC Data'], renderer: $.jqplot.EnhancedLegendRenderer },                  tooltipFormatString:'" & ds.Tables(0).Rows(k)(0) & "',                   ")
                If ds.Tables(0).Rows(k)(1).ToString.ToLower.Contains("not available") Then
                    s.Append("color:          '#FFFF00', ")
                ElseIf ds.Tables(0).Rows(k)(1).ToString.ToLower.StartsWith("incomplete") Then
                    s.Append("color:          '#F9AA0C', ")
                End If

                s.Append("                   shadow: false                }            };")
                s.Append("vline1.push(o);")
            End If



        Next
        s.Append("if (vline1.length > 0) {  try{              plot1.plugins.canvasOverlay = new $.jqplot.CanvasOverlay({                    show: true,                    objects: vline1                });                plot1.replot(); } catch(err){}         try{  plot2.plugins.canvasOverlay = new $.jqplot.CanvasOverlay({                    show: true,                    objects: vline1                });                plot2.replot();            } catch(err){}}")
        s.Append("});$(function(){")
        If strLine3.Length > 0 Then
            s.Append("$('tr.jqplot-table-legend').append('<td class=""jqplot-table-legend jqplot-table-legend-swatch "" style=""text-align: center; padding-top: 0px;""><div class=""jqplot-table-legend-swatch-outline""><div class=""jqplot-table-legend-swatch"" style=""background-color: #FFFF00; border-color: #FFFF00;""></div></div></td><td>TC Data Not Available</td>');")
        End If
        If strLine4.Length > 0 Then
            s.Append("$('tr.jqplot-table-legend').append('<td class=""jqplot-table-legend jqplot-table-legend-swatch "" style=""text-align: center; padding-top: 0px;""><div class=""jqplot-table-legend-swatch-outline""><div class=""jqplot-table-legend-swatch"" style=""background-color: #F9AA0C; border-color: #F9AA0C;""></div></div></td><td>Incomplete TC Data</td>');")
        End If
        s.Append("});</script>")
        Literal1.Text = s.ToString




    End Sub

    Protected Sub btnDownload_Click(sender As Object, e As System.EventArgs) Handles btnDownload.Click
        Dim pdfDoc As New Document(PageSize.A4, 10.0F, 10.0F, 10.0F, 0.0F)

        Dim writer As PdfWriter = PdfWriter.GetInstance(pdfDoc, Response.OutputStream)

        pdfDoc.Open()

        Dim base64 As String = hf1.Value.Replace("data:image/png;base64,", "")
        Dim im As Image = Image.GetInstance(Convert.FromBase64String(base64))
        Dim im1 As Image = Image.GetInstance(Convert.FromBase64String(hf2.Value.Replace("data:image/png;base64,", "")))
        Dim im2 As Image = Image.GetInstance(Convert.FromBase64String(hf3.Value.Replace("data:image/png;base64,", "")))
        'Dim im3 As Image = Image.GetInstance(Convert.FromBase64String(hf4.Value.Replace("data:image/png;base64,", "")))

        Dim blackHead = New Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.BLACK)
        Dim blackSubHead = New Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.BLACK)
        Dim h1 = New Paragraph(New Chunk("LFC  Report", blackHead))
        h1.Alignment = 1
        pdfDoc.Add(h1)
        Dim h2 = New Paragraph(New Chunk("Date: " & DateTime.Now.ToString("dd-MMM-yyyy"), blackSubHead))
        h2.Alignment = 1
        pdfDoc.Add(h2)

        Dim crejPer() As Single = {12, 12, 12}
        Dim c() As Single = {12, 12}
        Dim table As New PdfPTable(c)
        table.WidthPercentage = 100

        Dim table1 As New PdfPTable(c)
        table1.WidthPercentage = 100

        Dim tablerejS As New PdfPTable(crejPer)
        tablerejS.WidthPercentage = 100
        tablerejS.SpacingBefore = 20
        tablerejS.KeepTogether = True


        Dim cell1 As New PdfPCell(im, True)
        cell1.Border = 0
        cell1.Padding = 10

        Dim c0rejS As New PdfPCell(New Phrase("LFC Position Top Side In Caster", blackSubHead))
        c0rejS.Padding = 2
        c0rejS.Border = 0

        c0rejS.HorizontalAlignment = Element.ALIGN_CENTER
        tablerejS.AddCell(c0rejS)


        Dim cell2 As New PdfPCell(im1, True)
        cell2.Border = 0
        cell2.Padding = 10


        Dim cell3 As New PdfPCell(im2, True)
        cell3.Border = 0
        cell3.Padding = 10

        table.AddCell(c0rejS)

        Dim c0rejS1 As New PdfPCell(New Phrase("LFC Position Bottom Side In Caster", blackSubHead))
        c0rejS1.Padding = 2
        c0rejS1.Border = 0
        'c0rejS.BackgroundColor = New BaseColor(149, 183, 93)
        c0rejS1.HorizontalAlignment = Element.ALIGN_CENTER
        'c0rejS.Colspan = 3
        table.AddCell(c0rejS1)


        table.AddCell(cell1)
        table.AddCell(cell2)




        table.SpacingBefore = 10
        table1.SpacingBefore = 20
        pdfDoc.Add(table)
        table1.KeepTogether = True
        pdfDoc.Add(table1)

        Dim sw As New StringWriter()
        Dim hw As New HtmlTextWriter(sw)
        Panel1.RenderControl(hw)

        Dim ss As New iTextSharp.text.html.simpleparser.StyleSheet
        ss.LoadTagStyle(HtmlTags.TD, HtmlTags.FONTSIZE, "2pt")
        Dim sr As New StringReader(sw.ToString())
        Dim htmlparser As New HTMLWorker(pdfDoc)
        htmlparser.SetStyleSheet(ss)
        htmlparser.Parse(sr)
        XMLWorkerHelper.GetInstance().ParseXHtml(writer, pdfDoc, sr)
        pdfDoc.Close()




        Response.ContentType = "application/pdf"
        Response.AddHeader("content-disposition", "attachment;filename=LFC_REPORT.pdf")
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Write(pdfDoc)
        Response.End()
    End Sub



    Private Function CreateSimpleHtmlParagraph(ByVal text As String) As Paragraph
        Dim p As Paragraph = New Paragraph()
        Dim black = New Font(Font.FontFamily.HELVETICA, 8, Font.NORMAL, BaseColor.BLACK)
        Using sr As StringReader = New StringReader(text)
            Dim elements As List(Of IElement) = iTextSharp.text.html.simpleparser.HTMLWorker.ParseToList(sr, Nothing)

            For Each e As IElement In elements
                p.Add(e)
            Next
            p.Font = black
        End Using

        Return p
    End Function


End Class
