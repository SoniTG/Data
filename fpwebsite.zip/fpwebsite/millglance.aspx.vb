﻿Imports System.Data
Imports System.IO

Partial Class millglance
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim objDataHandler As New DataHandler
    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim timeperiodInHrs = 8
                hfTo.Value = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                hfFrom.Value = DateTime.Now.AddHours(-1 * timeperiodInHrs).ToString("yyyy-MM-dd HH:mm:ss")
                DrawCharts()
            Catch ex As Exception

            End Try

        End If

    End Sub

    Sub DrawCharts()
        Lit1.Text = ""
        DrawChart_Encoder()

        DrawChart_BR("4BR_Loadbalance_curr_diff", "c2", s2)
        DrawChart_BR("5BR_Loadbalance_curr_diff", "c3", s3)
        DrawChart_BR("6BR_R1_Loadbalance_Curr_diff", "c4", s4)
        DrawChart_BR("6BR_R2_Loadbalance_Curr_diff", "c5", s5)
        DrawChart_BR("6BR_R3_Loadbalance_Curr_diff", "c10", s10)

        DrawChart_PL("ACIDT1", "d1", 3, s6)
        DrawChart_PL("ACIDT2", "d2", 4, s7)
        DrawChart_PL("ACIDT3", "d3", 6, s8)
        DrawChart_PL("ACIDT4", "d4", 9, s9)
    End Sub
    Private Sub DrawChart_PL(ByVal param As String, ByVal container As String, ByVal threshold As Double, ByVal span As HtmlGenericControl)

        Dim en As String = hfTo.Value 'DateTime.Now.ToString("yyyy-MM-dd HH: mm:ss")
        Dim frm As String = hfFrom.Value 'DateTime.Now.AddHours(-1 * timeperiodInHrs).ToString("yyyy-MM-dd HH:mm:ss")
        Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("select  * from Openquery(CRM_ORACLE,'Select  CSE_TS_SAMPLING,CSR_TS_TEST,CSR_TEST_PARA,CSR_TEST_VAL,CSE_TS_TST_OVR FROM CRMDBA.t_CONS_RESULT  INNER JOIN CRMDBA.t_CONS_SAMPLE ON CSR_CD_CONSUMABLE = CSE_CD_CONSUMABLE  AND CSR_ID_SAMPLE = CSE_ID_SAMPLE AND CSR_CD_PROCESS= CSE_CD_PROCESS WHERE CSR_CD_PROCESS=''P''  AND CSR_TEST_PARA in (''" & param & "'') and CSR_TS_TEST between ''" & frm & "'' and ''" & en & "'' ORDER BY CSE_TS_TST_OVR DESC')")
        Dim thresholdLimit As Double = threshold
        Dim dtData As DataTable = ds.Tables(0)
        If dtData.Rows.Count > 0 Then
            Dim vals = dtData.AsEnumerable.Select(Function(f) f.Field(Of Decimal)(3)).ToList

            Dim totalRows = vals.Count

            Dim thresholdRows = vals.Where(Function(f) f < thresholdLimit).Count

            Dim percentage As Double = thresholdRows * 100 / (totalRows)

            Lit1.Text &= GetChartString(container, percentage)
        Else
            Lit1.Text &= GetNoData(container)
        End If

        If Not IsDBNull(ds.Tables(0).Rows(0)("CSR_TS_TEST")) Then
            span.InnerHtml = "Last Data: <b>" & CDate(ds.Tables(0).Rows(0)("CSR_TS_TEST")).ToString("dd-MMM-yy HH:mm") & "</b>"
        End If

    End Sub
    Private Sub DrawChart_BR(ByVal param As String, ByVal container As String, ByVal span As HtmlGenericControl)

        Dim en As String = hfTo.Value 'DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        Dim frm As String = hfFrom.Value 'DateTime.Now.AddHours(-1 * timeperiodInHrs).ToString("yyyy-MM-dd HH:mm:ss")
        Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("SELECT CPAT_VAR_VAL_BOXPLOT,CPAT_START_TIME FROM [FP_PROCESS_DATA].[dbo].[CRM_PLTCM_CRITICAL_PARAMETER_TREND_NEW] WHERE CPAT_START_TIME BETWEEN '" & frm & "' AND '" & en & "' AND LOWER(CPAT_VAR_NAME)='" & param.ToLower & "' ORDER BY CPAT_START_TIME desc;SELECT MAX(CPAT_START_TIME) as CPAT_START_TIME FROM [FP_PROCESS_DATA].[dbo].[CRM_PLTCM_CRITICAL_PARAMETER_TREND] where LOWER(CPAT_VAR_NAME)='" & param.ToLower & "'")
        Dim thresholdLimit As Double = 1.5 'Changed from 1.0 to 1.5 on 06-Nov-2023
        Dim dtData As DataTable = ds.Tables(0)
        If dtData.Rows.Count > 0 Then
            Dim vals = dtData.AsEnumerable.Select(Function(f) f.Field(Of String)(0).Split(",")(BoxPlotValues.StdDev)).ToList

            Dim vals_double = dtData.AsEnumerable.Select(Function(f) Convert.ToDouble(f.Field(Of String)(0).Split(",")(BoxPlotValues.StdDev))).ToArray
            Dim mv_group = 10

            Dim movingaverages = Enumerable.Range(0, vals_double.Count).Select(Function(x) _
                                               If(x >= mv_group - 1,
                                                CDec(vals_double.Skip(x - (mv_group - 1)).Take(mv_group).Average),
                                                Nothing)).ToList

            'Dim totalRows = vals.Count

            'Dim thresholdRows = vals.Where(Function(f) Convert.ToDouble(f) >= thresholdLimit).Count

            'Dim percentage As Double = thresholdRows * 100 / (totalRows)

            Dim totalRows = movingaverages.Count - (mv_group - 1)

            Dim thresholdRows = movingaverages.Where(Function(f) f >= thresholdLimit).Count

            Dim percentage As Double = thresholdRows * 100 / (totalRows)

            Lit1.Text &= GetChartString(container, percentage)
        Else
            Lit1.Text &= GetNoData(container)
        End If

        If Not IsDBNull(ds.Tables(1).Rows(0)("CPAT_START_TIME")) Then
            span.InnerHtml = "Last Data: <b>" & CDate(ds.Tables(1).Rows(0)("CPAT_START_TIME")).ToString("dd-MMM-yy HH:mm") & "</b>"
        End If

    End Sub
    Private Sub DrawChart_Encoder()
        Dim en As String = hfTo.Value 'DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        Dim frm As String = hfFrom.Value 'DateTime.Now.AddHours(-1 * timeperiodInHrs).ToString("yyyy-MM-dd HH:mm:ss")
        Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("SELECT [PL_SL_NO],[PL_PARAM_NAME],[PL_MAX_LIMIT],[PL_MIN_LIMIT] FROM [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_PLTCM_LIMITS] WHERE [PL_CRITICAL]=1 ORDER BY 1;SELECT PEM_SPD_STDDEV_MAX,PEM_STARTTIME FROM [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_PLTCM_ENCODER_MAX] WHERE PEM_STARTTIME BETWEEN '" & frm & "' AND '" & en & "' ORDER BY PEM_STARTTIME;SELECT MAX(PEM_STARTTIME) as PEM_STARTTIME FROM [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_PLTCM_ENCODER_MAX]")
        Dim dtLimit As DataTable = ds.Tables(0)
        Dim dtData As DataTable = ds.Tables(1)

        If dtData.Rows.Count > 0 Then
            Dim totAlerts(dtLimit.Rows.Count - 1) As Integer
            For i As Integer = 0 To dtData.Rows.Count - 1
                Dim temp() As String = dtData.Rows(i)(0).ToString.Split(",")
                For j As Integer = 0 To dtLimit.Rows.Count - 1
                    Try
                        If (CDbl(temp(dtLimit.Rows(j)(0) - 1)) > dtLimit.Rows(j)(2)) Then
                            totAlerts(j) = 1
                        End If
                    Catch ex As Exception

                    End Try

                Next
            Next

            Dim percentage As Double = totAlerts.Sum * 100 / (dtLimit.Rows.Count)

            Lit1.Text &= GetChartString("c1", percentage)


        Else
            Lit1.Text &= GetNoData("c1")

        End If

        If Not IsDBNull(ds.Tables(2).Rows(0)(0)) Then
            s1.InnerHtml = "Last Data: <b>" & CDate(ds.Tables(2).Rows(0)(0)).ToString("dd-MMM-yy HH:mm") & "</b>"
        End If

    End Sub

    Public Function GetNoData(ByVal containername As String) As String
        Dim s As New StringBuilder("<script>")
        s.Append("var myc=echarts.init(document.getElementById('" & containername & "'));myc.setOption({")
        s.Append("title: {show: true, textStyle:{ color:'#ff0000'},text: 'No Data',left: 'center',  top: 'center'  }")
        s.Append("});")
        ' s.Append("myc.on('click', function (params) {alert('');});")
        s.Append("</script>")
        Return s.ToString

    End Function

    Public Function GetChartString(ByVal containerName As String, ByVal gaugeValue As Double) As String
        Dim s As New StringBuilder("<script>")
        s.Append("var myc=echarts.init(document.getElementById('" & containerName & "'));myc.setOption({")
        s.Append("series:[{type:'gauge',startAngle: 180,endAngle: 0,axisLine:{lineStyle:{width:30,color:[[" & Math.Round(gaugeValue / 100, 3) & ",'#fd666d'],[1,'#69B578']]}},pointer:{itemStyle:{color:'inherit'}},axisTick:{distance:-30,length:8,lineStyle:{color:'#fff',width:2}},splitLine:{distance:-30,length:30,lineStyle:{color:'#fff',width:4}},axisLabel:{show:false},detail:{valueAnimation:!0,formatter:'{value} %',color:'#fd666d'},data:[{value:" & Math.Round(gaugeValue, 1) & "}]}]")
        s.Append("});")
        ' s.Append("myc.on('click', function (params) {alert('');});")
        s.Append("</script>")
        Return s.ToString
    End Function

    Private Sub btngo_Click(sender As Object, e As EventArgs) Handles btngo.Click
        spanMsg.InnerText = ""
        spanMsg.Visible = False
        DrawCharts()
    End Sub

    Enum BoxPlotValues
        LowerBound
        UpperBound
        Avg
        Median
        L_Q
        U_Q
        StdDev
        Min
        Max
    End Enum
End Class
