﻿
Partial Class newCglpage
    Inherits System.Web.UI.Page

End Class
