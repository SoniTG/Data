﻿
Partial Class newDashboard
    Inherits System.Web.UI.Page

End Class
