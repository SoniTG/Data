﻿Imports System.Data
Imports System.IO
Partial Class pltank
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim objDataHandler As New DataHandler

    Dim header() As String = {"ACIDT1", "ACIDT2", "ACIDT3", "ACIDT4"}
    Dim headername() As String = {"PL Tank1", "PL Tank3", "PL Tank3", "PL Tank4"}
    Dim red() As Integer = {3, 4, 6, 9}
    Dim green() As Integer = {5, 6, 9, 12}
    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))

                hfTo.Value = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                hfFrom.Value = DateTime.Now.AddHours(-1 * 8).ToString("yyyy-MM-dd HH:mm:ss")
                If Not Request.QueryString("frm") Is Nothing Then
                    Dim frm As String = Request.QueryString("frm").ToString.Replace("%20", " ")
                    Dim en As String = Request.QueryString("to").ToString.Replace("%20", " ")
                    DrawCharts(frm, en)
                Else
                    DrawCharts()
                End If
            Catch ex As Exception

            End Try

        End If

    End Sub

    Private Sub DrawCharts()
        
        Dim frmdt As String = hfFrom.Value
        Dim todt As String = hfTo.Value
        DrawCharts(frmdt, todt)
    End Sub

    Private Sub DrawCharts(frm As String, en As String)
        Lit1.Text = ""
        DrawDynamicContainer(headername)
        For i As Integer = 0 To UBound(header)
            Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select  * from Openquery(CRM_ORACLE,'Select  CSE_TS_SAMPLING,CSR_TS_TEST,CSR_TEST_PARA,CSR_TEST_VAL,CSE_TS_TST_OVR FROM CRMDBA.t_CONS_RESULT  INNER JOIN CRMDBA.t_CONS_SAMPLE ON CSR_CD_CONSUMABLE = CSE_CD_CONSUMABLE  AND CSR_ID_SAMPLE = CSE_ID_SAMPLE AND CSR_CD_PROCESS= CSE_CD_PROCESS WHERE CSR_CD_PROCESS=''P''  AND CSR_TEST_PARA in (''" & header(i) & "'') and CSR_TS_TEST between ''" & frm & "'' and ''" & en & "'' ORDER BY CSE_TS_TST_OVR')").Tables(0)

            Lit1.Text &= PlotLineEChart(dt, "CSR_TS_TEST", "CSR_TEST_VAL", "container" & i, i)
        Next

    End Sub

    Private Sub DrawDynamicContainer(arr As String())
        Try

            Dim appendString = ""
            For i As Integer = 0 To arr.Length - 1
                appendString &= "<div class='col-md-6'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>" & arr(i).ToString() & "</h3> <span></span></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='container" & i.ToString() & "' style='height: 300px;'></div></div></div></div>"
            Next
            divHolder.InnerHtml = appendString
        Catch ex As Exception

        End Try
    End Sub

    Public Function PlotLineEChart(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal ContainerName As String, ByVal idx As Integer) As String
        Try

            Dim data As String = Nothing
            Dim date_val As String = Nothing


            For I As Integer = 0 To dt.Rows.Count - 1

                Dim temp As String = dt.Rows(I)(YAxisColName)
                data &= temp & ","
                date_val &= "'" & CDate(dt.Rows(I)(XAxisColName)).ToString("yyyy-MM-dd HH:mm:ss") & "',"
            Next




            '' dv.Item(0)("lenseverity")
            Dim s As New StringBuilder("<script>")

            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            s.Append(" echarts.init(document.getElementById('" & ContainerName & "')).setOption(")

            s.Append("{")

            s.Append("title: {")
            s.Append("text: ''")
            s.Append("},grid:{left:'10%',right:'5%'},")
            s.Append("tooltip: {")
            s.Append("trigger: 'item',formatter: '{b}<br/>{c}'")
            s.Append("},")
            s.Append("xAxis: {")
            s.Append("data: [" & date_val & "]")
            s.Append("},")
            s.Append("yAxis: {name : '',nameLocation: 'middle', nameGap: 50,nameTextStyle:{fontFamily:'Calibri',fontWeight:'bold',fontSize:'14'},")
            s.Append("splitLine: {")
            s.Append("show: false")
            s.Append("}")
            s.Append("},")
            s.Append("toolbox: {")
            s.Append("left: 'right',")
            s.Append("feature: {")
            s.Append("dataZoom: {")
            s.Append("")
            s.Append("},")
            s.Append("restore: {},")
            s.Append("saveAsImage: {}")
            s.Append("}")
            s.Append("},")


            s.Append("series: [")
            s.Append("{")
            s.Append("type: 'line',")
            's.Append("stack: 'temp',")
            s.Append("data: [" & data & "]")
            s.Append(",markArea: {silent:true, data: [ [{itemStyle: {color: 'rgba(255, 173, 177, 0.4)'}},{yAxis: " & red(idx) & "}],[{yAxis: " & green(idx) & ",itemStyle: {color: 'rgba(173, 255, 177, 0.4)'}},{yAxis: " & red(idx) & "}]]}")
            s.Append("},")

            s.Append("]")

            s.Append(",visualMap:{show:false,pieces:[{gte:" & red(idx) & ",lte:" & green(idx) & ",color:'green'},{lt:" & red(idx) & ",color:'red'}],outOfRange: {color: '#000'}}")

            s.Append("}")

            s.Append(");")

            s.Append("</script>")
            Return s.ToString
        Catch ex As Exception
            Return ("")
        End Try
    End Function

    Private Sub btngo_Click(sender As Object, e As EventArgs) Handles btngo.Click
        DrawCharts()
    End Sub
End Class
