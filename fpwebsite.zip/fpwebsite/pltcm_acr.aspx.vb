﻿Imports System.Data
Imports System.IO


Partial Class pltcm_acr
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim objDataHandler As New DataHandler
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    txtDate_TextChanged()
                End If
            Catch ex As Exception

            End Try

        End If

        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd HH:mm:ss")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                hfFrom.Value = dtStart
                hfTo.Value = dtEnd
                PopulateParameters()
                Try
                    ddlParameter.SelectedIndex = ddlParameter.Items.IndexOf(ddlParameter.Items.FindByValue("ACR"))
                Catch ex As Exception

                End Try
                GetData()
            Catch ex As Exception

            End Try

        End If
        If Page.IsPostBack Then
            Try

                GetData()
            Catch ex As Exception

            End Try
        End If
    End Sub


    Sub PopulateParameters()
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select distinct CPAT_VAR_NAME from [FP_PROCESS_DATA].[dbo].[CRM_PLTCM_CRITICAL_PARAMETER_TREND] order by 1").Tables(0)
        ddlParameter.DataSource = dt
        ddlParameter.DataTextField = "CPAT_VAR_NAME"
        ddlParameter.DataValueField = "CPAT_VAR_NAME"
        ddlParameter.DataBind()
    End Sub
    Sub GetData()
        Try
            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            'Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select * From fp_process_data.dbo.CRM_PLTCM_ACR_TREND where cpat_start_time between '" & dtStart & "' and '" & dtEnd & "'").Tables(0)
            Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select * From fp_process_data.dbo.CRM_PLTCM_CRITICAL_PARAMETER_TREND where cpat_start_time between '" & dtStart & "' and '" & dtEnd & "' and upper(CPAT_VAR_NAME)='" & ddlParameter.SelectedItem.Value & "'").Tables(0)
            Dim l As Literal
            Dim COUNT As Integer = 1
            Dim literals = Page.Master.FindControl("content_body").Controls.OfType(Of Literal)()
            For Each lit In literals
                Dim i As Integer = i + COUNT
                If (lit.ID = "Lit" & i) Then
                    l = lit
                    If dt.Rows.Count > 0 Then
                        BoxPlotForPltcmCylinder(dt, l, "c1", "plot", "", i, plottypeDDl.SelectedValue.ToString)
                        Exit For
                    End If
                Else
                    Exit For
                End If
            Next

        Catch ex As Exception

        End Try

    End Sub


    Sub BoxPlotForPltcmCylinder(ByVal dt As DataTable, ByVal lit As Literal, ByVal containerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal VAL As Integer, ByVal plottype As String)

        If (plottype = "Box Plot") Then

            lit.Text = ""
            litHead.Text = ddlParameter.SelectedItem.Value
            litHead1.Text = ddlParameter.SelectedItem.Value

            Try
                ChartTitle = ""
                Dim ticks As String = "["
                Dim line1, line2, line3, line4 As String
                line1 &= "["
                line2 &= "["
                line3 &= "["
                line4 &= "["

                For i As Integer = 0 To dt.Rows.Count - 1
                    If (dt.Rows(i)(2).ToString <> "") Then

                        Try
                            ticks &= "'" & CDate(dt.Rows(i)("CPAT_START_TIME")).ToString("yyyy-MM-dd HH:mm:ss") & "'"

                            Dim tmpCyl() As String = dt.Rows(i)("CPAT_VAR_VAL_BOXPLOT").ToString.Split(",")
                            line1 &= "[" & tmpCyl(0) & "," & tmpCyl(4) & "," & tmpCyl(3) & "," & tmpCyl(5) & "," & tmpCyl(1) & "]"

                            line2 &= tmpCyl(2) 'avg
                            line3 &= tmpCyl(7) 'min
                            line4 &= tmpCyl(8) 'max


                            If (i <> 0 Or i <> dt.Rows.Count - 1) Then
                                ticks &= ","
                                line1 &= ","
                                line2 &= ","
                                line3 &= ","
                                line4 &= ","
                            End If



                        Catch ex As Exception
                            Continue For
                        End Try
                    End If

                Next
                ticks &= "]"
                line1 &= "]"
                line2 &= "]"
                line3 &= "]"
                line4 &= "]"
                Dim js = "<script language='javascript' type='text/javascript'>"
                js &= "var ticks=" & ticks & ";"
                js &= "var pl1=" & line1 & ";"
                js &= "var pl2=" & line2 & ";"
                js &= "var pl3=" & line3 & ";"
                js &= "var pl4=" & line4 & ";"
                js &= "var lmin = Math.min(Math.min.apply(null,pl2),Math.min.apply(null,pl3),Math.min.apply(null,pl4));"
                js &= "var lmax = Math.max(Math.max.apply(null,pl2),Math.max.apply(null,pl3),Math.max.apply(null,pl4));"
                'js &= "var yMin = (lmin<-300)?lmin-5:-310; var yMax = (lmax>300)?lmax+ 5:310;"

                js &= "option = { title: {text:'" & ChartTitle & "',left: 'center',},toolbox:{feature:{dataZoom:{}}}, legend: { y: '10%', data: ['Output (Count)']}, tooltip: {trigger:    'item',axisPointer: {type:       'shadow'}},grid: {left:       '10%',top:'20%',right:      '10%',bottom: '15%'}, xAxis: {"
                js &= "type:       'category',   data:ticks, boundaryGap: true, nameGap: 30, splitArea: { show: true}, axisLabel: {formatter:  ' {value}'}, splitLine: {show: false}}, yAxis: {type:'value',name:'Deviation',nameLocation:   'middle',nameGap: 40,splitArea: {show: false},}," ',min:-140,max:140},"
                js &= " dataZoom: [{type:       'inside',start: 0,end: 100},{show: true,height: 20,type: 'slider',top:'90%',xAxisIndex: [0]}],"
                'js &= " series: [{name:       'Output (Count)',type:       'boxplot', data: pl1,markLine:{data:[{yAxis:300,name:'UCL'},{yAxis:-300,name:'LCL'}]},tooltip: {formatter: formatter}}]};"
                js &= " series: [{name:       'Output (Count)',type:       'boxplot', data: pl1,tooltip: {formatter: formatter}}]};"
                js &= "function formatter(param) {return ['upper: ' + param.data[5],'Q3: ' + param.data[4],'median: ' + param.data[3],'Q1: ' + param.data[2],'lower: ' + param.data[1]].join('<br/>')}"
                js &= "var " & PlotName & " = echarts.init(document.getElementById('" & containerName & "'));" & PlotName & ".setOption(option);"

                js &= "option1 = { tooltip: {trigger: 'axis'},toolbox:{feature:{dataZoom:{}}}, legend: { y: '10%', data: ['Avg','Min','Max']},grid: {left:       '10%',top:'20%',right:      '10%',bottom: '15%'}, xAxis: {"
                'js &= "type:       'category',   data:ticks}, yAxis: {type: 'value',min:yMin,max:yMax},"
                js &= "type:       'category',   data:ticks}, yAxis: {type: 'value'},"
                js &= " dataZoom: [{type:       'inside',start: 0,end: 100},{show: true,height: 20,type: 'slider',top:'90%',xAxisIndex: [0]}],"
                'js &= "series: [{name:       'Avg',data: pl2, type:'line',markLine:{data:[{yAxis:300,name:'UCL'},{yAxis:-300,name:'LCL'}]}},{name:       'Min',data: pl3, type:'line'},{name:       'Max',data: pl4, type:'line'}]"
                js &= "series: [{name:       'Avg',data: pl2, type:'line'},{name:       'Min',data: pl3, type:'line'},{name:       'Max',data: pl4, type:'line'}]"
                js &= "};var plot2 = echarts.init(document.getElementById('c2'));plot2.setOption(option1);"
                js &= "</script>"

                lit.Text = js
            Catch ex As Exception

            End Try
        End If
        If (plottype = "Average" Or plottype = "Std Deviation") Then
            lit.Text = ""
            Try
                ChartTitle = ""
                Dim ticks As String = "["
                Dim line1, line2 As String
                line1 &= "["
                line2 &= "["
                Dim Cylinder As String = ""
                Cylinder = String.Format("{0}{1}", "Cylinder", VAL)
                Dim Strip As String = ""
                Strip = String.Format("{0}{1}", "Strip", VAL)
                For i As Integer = 0 To dt.Rows.Count - 1
                    If (dt.Rows(i)(Cylinder).ToString <> "") Then

                        Try
                            ticks &= "'" & dt.Rows(i)("CPCT_START_TIME") & "'"

                            Dim tmpCyl() As String = dt.Rows(i)(Cylinder).ToString.Split(",")
                            If (plottype = "Average") Then
                                line1 &= tmpCyl(2)
                            Else
                                line1 &= tmpCyl(6)
                            End If


                            Dim tmpStrip() As String = dt.Rows(i)(Strip).ToString.Split(",")
                            If (plottype = "Average") Then
                                line2 &= tmpStrip(2)
                            Else
                                line2 &= tmpStrip(6)
                            End If


                            If (i <> 0 Or i <> dt.Rows.Count - 1) Then
                                ticks &= ","
                                line1 &= ","
                                line2 &= ","
                            End If



                        Catch ex As Exception
                            Continue For
                        End Try
                    End If

                Next
                ticks &= "]"
                line1 &= "]"
                line2 &= "]"
                Dim js = "<script language='javascript' type='text/javascript'>"
                js &= "var ticks=" & ticks & ";"
                js &= "var pl1=" & line1 & ";"
                js &= "var pl2=" & line2 & ";"
                js &= "  option = { tooltip: {trigger:'axis' }, legend: { data:['Cylinder','Strip']},toolbox: { show: true, feature: { "
                js &= " magicType: {type: ['line', 'bar']},} },dataZoom: [{show: true,start:1, end: 100},{type:'inside',start: 0,end: 20 }, ], xAxis:  {type:'category', boundaryGap: false, data: ticks },"
                js &= "  yAxis: {type: 'value', axisLabel: {formatter:  '{value}'  } }, series: [ {name: 'Cylinder',type: 'line',data:pl1, },"
                js &= " {name: 'Strip',type: 'line',data:pl2, } ]};"
                js &= "var " & PlotName & " = echarts.init(document.getElementById('" & containerName & "'));" & PlotName & ".setOption(option);"
                js &= "</script>"
                lit.Text = js
            Catch ex As Exception

            End Try



        End If

    End Sub
    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try

            GetData()
            'CreateDynamicContainer()
        Catch ex As Exception

        End Try


    End Sub

    Private Sub ddlParameter_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlParameter.SelectedIndexChanged
        Try

            GetData()
            'CreateDynamicContainer()
        Catch ex As Exception

        End Try
    End Sub
End Class
