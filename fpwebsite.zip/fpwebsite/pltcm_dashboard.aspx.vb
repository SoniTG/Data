﻿Imports System.Data
Imports System.IO
Imports System.Data.OleDb
Partial Class pltcm_dashboard
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("ACPM_Ora").ConnectionString
    Dim Oleconnection_ora As New OleDbConnection(strConnectionString)
    Dim OleAdap As New OleDbDataAdapter
    Dim ds As New DataSet
    Dim dt As New DataTable
    Dim OleCom As New OleDbCommand

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    txtDate_TextChanged()
                End If
            Catch ex As Exception

            End Try

        End If

        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-3).ToString("yyyy-MM-dd")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd")
                Dim FilterCRCoil As String = " where T.HRP_TS_REC_CREATE between to_date('" & CDate(dtStart).ToString("dd-MM-yyyy") & " 06:00:00','DD-MM-YYYY HH24:MI:SS') and TO_date('" & CDate(dtEnd).AddDays(1).ToString("dd-MM-yyyy") & " 06:00:00' ,'DD-MM-YYYY HH24:MI:SS')  group by TO_CHAR(t.HRP_TS_REC_CREATE - 6/24,'YYYY-MM-DD')  order by TO_CHAR(t.HRP_TS_REC_CREATE - 6/24,'YYYY-MM-DD')"
                Dim FilterHRCoil As String = " where HRC_DT_ARRIVAL between to_date('" & CDate(dtStart).ToString("dd-MM-yyyy") & " 06:00:00','DD-MM-YYYY HH24:MI:SS') and TO_date('" & CDate(dtEnd).AddDays(1).ToString("dd-MM-yyyy") & " 06:00:00' ,'DD-MM-YYYY HH24:MI:SS')  group by TO_CHAR(HRC_DT_ARRIVAL - 6/24,'YYYY-MM-DD')  order by TO_CHAR(HRC_DT_ARRIVAL - 6/24,'YYYY-MM-DD')"
                If GetDataForCRCoil(FilterCRCoil).Rows.Count > 0 Then
                    objController.PlotChartForPLTCMDashboardBar(dt, "HRP_TS_REC_CREATE", "CR_COIL_WT", Lit1, "container", "plot1")
                    objController.PlotChartForPLTCMDashboardLine(dt, "HRP_TS_REC_CREATE", "CR_COIL_ID", Lit2, "container1", "plot2")
                End If
                If GetDataForHRCoil(FilterHRCoil).Rows.Count - 1 Then
                    objController.PlotChartForPLTCMDashboardStack(dt, Lit3, "container2", "plot3")
                End If

            Catch ex As Exception

            End Try
        End If

    End Sub
    Sub CloseConnection()
        Try
            If Oleconnection_ora.State <> ConnectionState.Closed Then
                Oleconnection_ora.Close()
            End If
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
    End Sub
    Public Function Ora_selectquery(ByVal strselect As String) As OleDbDataAdapter
        Try
            OleCom.Connection = Oleconnection_ora
            OleCom.CommandText = strselect
            OleAdap.SelectCommand = OleCom
            Return OleAdap
        Catch ex As Exception

        End Try

    End Function
    Public Function GetDataForCRCoil(ByVal Filter As String) As DataTable
        Try

            CloseConnection()
            Oleconnection_ora.Open()
            ds.Clear()
            dt.Clear()
            Dim OraQuery As String = "select TO_CHAR(t.HRP_TS_REC_CREATE - 6/24,'YYYY-MM-DD') as COIL_DATE,COUNT(*) as CR_COIL_ID,sum(t1.CCL_MS_PIECE_ACTL) AS CR_COIL_WT from crmdba.t_HR_COIL_PROCESS " & vbCrLf &
            "t inner join crmdba.t_cold_coil t1 on t1.CCL_ID_COIL= t.HRP_ID_CR_COIL " & vbCrLf &
             "" & Filter & ""
            Ora_selectquery(OraQuery)
            OleAdap.Fill(ds)
            dt = ds.Tables(0)
            Return dt

        Catch ex As Exception

        End Try
    End Function
    Public Function GetDataForHRCoil(ByVal Filter As String) As DataTable
        Try

            CloseConnection()
            Oleconnection_ora.Open()
            ds.Clear()
            dt.Clear()
            'Dim OraQuery As String = "select TO_CHAR(HRC_DT_ARRIVAL - 6/24,'YYYY-MM-DD') as COIL_DATE,COUNT(HRC_ID_PC_USRKEY) as COIL_ID,HRC_SR_PLANT AS PLANT from crmdba.T_HR_COIL" & vbCrLf &
            ' "" & Filter & ""
            Dim OraQuery As String = "SELECT TO_CHAR(HRC_DT_ARRIVAL - 6/24,'YYYY-MM-DD') AS ARRDATE,COUNT(DECODE(HRC_SR_PLANT,'062',(HRC_ID_PC_USRKEY))) AS plt1,COUNT(DECODE(HRC_SR_PLANT,'067',(HRC_ID_PC_USRKEY))) AS plt2,COUNT(DECODE(HRC_SR_PLANT,'117',(HRC_ID_PC_USRKEY))) AS plt3  from crmdba.T_HR_COIL" & vbCrLf &
           "" & Filter & ""
            Ora_selectquery(OraQuery)
            OleAdap.Fill(ds)
            dt = ds.Tables(0)
            Return dt

        Catch ex As Exception

        End Try
    End Function

    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try

            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            Dim FilterCRCoil As String = " where T.HRP_TS_REC_CREATE between to_date('" & CDate(dtStart).ToString("dd-MM-yyyy") & " 06:00:00','DD-MM-YYYY HH24:MI:SS') and TO_date('" & CDate(dtEnd).AddDays(1).ToString("dd-MM-yyyy") & " 06:00:00' ,'DD-MM-YYYY HH24:MI:SS')  group by TO_CHAR(t.HRP_TS_REC_CREATE - 6/24,'YYYY-MM-DD')  order by TO_CHAR(t.HRP_TS_REC_CREATE - 6/24,'YYYY-MM-DD')"
            Dim FilterHRCoil As String = " where HRC_DT_ARRIVAL between to_date('" & CDate(dtStart).ToString("dd-MM-yyyy") & " 06:00:00','DD-MM-YYYY HH24:MI:SS') and TO_date('" & CDate(dtEnd).AddDays(1).ToString("dd-MM-yyyy") & " 06:00:00' ,'DD-MM-YYYY HH24:MI:SS')  group by TO_CHAR(HRC_DT_ARRIVAL - 6/24,'YYYY-MM-DD')  order by TO_CHAR(HRC_DT_ARRIVAL - 6/24,'YYYY-MM-DD')"
            If GetDataForCRCoil(FilterCRCoil).Rows.Count > 0 Then
                objController.PlotChartForPLTCMDashboardBar(dt, "HRP_TS_REC_CREATE", "CR_COIL_WT", Lit1, "container", "plot1")
                objController.PlotChartForPLTCMDashboardLine(dt, "HRP_TS_REC_CREATE", "CR_COIL_ID", Lit2, "container1", "plot2")
            End If
            If GetDataForHRCoil(FilterHRCoil).Rows.Count - 1 Then
                objController.PlotChartForPLTCMDashboardStack(dt, Lit3, "container2", "plot3")
            End If

        Catch ex As Exception

        End Try
    End Sub













End Class
