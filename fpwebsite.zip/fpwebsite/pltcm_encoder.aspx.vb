﻿Imports System.Data
Imports System.IO
Partial Class pltcm_encoder
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))

                If Not Request.QueryString("frm") Is Nothing Then
                    Dim frm As String = Request.QueryString("frm").ToString.Replace("%20", " ")
                    Dim en As String = Request.QueryString("to").ToString.Replace("%20", " ")
                    DrawCharts(frm, en)
                Else
                    DrawCharts()
                End If

            Catch ex As Exception

            End Try

        End If

    End Sub

    Sub DrawCharts()
        Try

            Dim ds As DataSet = objController.GetPLTCMEncoderData()
            Dim dt As DataTable = ds.Tables(0)
            Dim dt1 As DataTable = ds.Tables(1)

            DrawDynamicContainer(dt1)

            Dim groups As List(Of DataTable) = dt1.AsEnumerable.GroupBy(Function(g) g.Field(Of Integer)("PL_SEQ_NO")).Select(Function(t) t.CopyToDataTable).ToList

            Dim i As Integer = 1
            Dim j As Integer = 0
            Dim cidx As Integer = 0
            If dt.Rows.Count > 0 Then
                Dim s As New StringBuilder("<script>")
                lblFName.Text = dt.Rows(0)(0)

                Dim arrData() As String = dt.Rows(0)(2).ToString.Split(",")

                For Each g In groups
                    Dim results = arrData.Skip(j).Take(g.Rows.Count)
                    j = j + g.Rows.Count
                    Dim xdata As String = ""
                    Dim ydata As String = ""
                    For Each x In results



                        xdata &= ",'" & dt1.Rows(i - 1)("PL_ALIAS") & "'"
                        ' ydata &= "," & item
                        Dim color As String = "#3398DB"
                        If dt1.Rows(i - 1)("PL_MAX_LIMIT") > 0 AndAlso CDbl(arrData(dt1.Rows(i - 1)("PL_SL_NO") - 1)) >= dt1.Rows(i - 1)("PL_MAX_LIMIT") Then
                            color = "#F05D5E"
                        End If
                        ydata &= ",{value:" & arrData(dt1.Rows(i - 1)("PL_SL_NO") - 1) & ",itemStyle:{normal:{color:'" & color & "'}}}"
                        i = i + 1
                    Next
                    s.Append("option" & cidx & "={grid:{bottom:150,top:20,show:false},tooltip : {trigger: 'axis',axisPointer : {type : 'line'}},xAxis: {type: 'category',axisLabel:{show:true,rotate:90},data: [" & xdata.Substring(1) & "]},yAxis: { type: 'value',name: 'Speed StdDev (MPM)',splitLine:{show:false},nameLocation: 'middle',nameGap: 50}, series: [{ data: [" & ydata.Substring(1) & "],type: 'bar'}]};")
                    s.Append("var chart" & cidx & "=echarts.init(document.getElementById('container" & cidx & "'));chart" & cidx & ".setOption(option" & cidx & ");")
                    s.Append("chart" & cidx & ".on('click',function(params){window.open('pltcm_sub_chart.aspx?subparam=' + escape(params.name) + '', ""_blank"", ""toolbar=no,location=no,directories=no,status=no,scrollbars=yes,resizable=no,top=100,left=200,width=800,height=400"");});")
                    cidx += 1

                Next
                s.Append("</script>")
                Lit1.Text = s.ToString
            End If

            'If dt.Rows.Count > 0 Then
            '    lblFName.Text = dt.Rows(0)(0)

            '    Dim arrData() As String = dt.Rows(0)(2).ToString.Split(",")

            '    'Dim results = arrData.Select(Function(v, ix) New With {.value = v, .index = ix}).GroupBy(Function(x) x.index \ 15).Select(Function(x) x.Select(Function(z) z.value))

            '    Dim results = arrData.Select(Function(v, ix) New With {.value = v, .index = ix}).GroupBy(Function(x) x.index \ 15).Select(Function(x) x.Select(Function(z) z.value))

            '    Dim i As Integer = 1
            '    Dim cidx As Integer = 0
            '    Dim s As New StringBuilder("<script>")
            '    For Each x In results
            '        Dim xdata As String = ""
            '        Dim ydata As String = ""

            '        For Each item In x
            '            xdata &= ",'" & dt1.Rows(i - 1)("PL_ALIAS") & "'"
            '            ' ydata &= "," & item
            '            Dim color As String = "#3398DB"
            '            If dt1.Rows(i - 1)("PL_MAX_LIMIT") > 0 AndAlso item >= dt1.Rows(i - 1)("PL_MAX_LIMIT") Then
            '                color = "#F05D5E"
            '            End If
            '            ydata &= ",{value:" & item & ",itemStyle:{normal:{color:'" & color & "'}}}"
            '            i = i + 1
            '        Next
            '        s.Append("option" & cidx & "={grid:{bottom:100,top:20},tooltip : {trigger: 'axis',axisPointer : {type : 'line'}},xAxis: {type: 'category',axisLabel:{show:true,rotate:30},data: [" & xdata.Substring(1) & "]},yAxis: { type: 'value',name: 'StdDev. Max',nameLocation: 'middle',nameGap: 50}, series: [{ data: [" & ydata.Substring(1) & "],type: 'bar'}]};")
            '        s.Append("var chart" & cidx & "=echarts.init(document.getElementById('container" & cidx & "'));chart" & cidx & ".setOption(option" & cidx & ");")
            '        s.Append("chart" & cidx & ".on('click',function(params){window.open('pltcm_sub_chart.aspx?subparam=' + escape(params.name) + '', ""_blank"", ""toolbar=no,location=no,directories=no,status=no,scrollbars=yes,resizable=no,top=100,left=200,width=800,height=400"");});")
            '        cidx += 1
            '    Next
            '    s.Append("</script>")
            '    Lit1.Text = s.ToString

            'End If

        Catch ex As Exception

        End Try
    End Sub

    Sub DrawCharts(ByVal frm As String, ByVal en As String)
        Try
            Dim da As New DataHandler
            Dim q As String = "select  * from [FP_CRM_EQUIP_MAINTENANCE].[dbo].CRM_PLTCM_ENCODER_MAX where PEM_STARTTIME between '" & frm & "' and '" & en & "' order by PEM_STARTTIME desc;select * from [FP_CRM_EQUIP_MAINTENANCE].[dbo].CRM_PLTCM_LIMITS WHERE PL_ACTIVE=1 order by PL_SEQ_NO "
            Dim ds As DataSet = da.GetDataSetFromQuery(q)
            Dim dt As DataTable = ds.Tables(0)
            Dim dt1 As DataTable = ds.Tables(1)

            DrawDynamicContainer(dt1)

            Dim groups As List(Of DataTable) = dt1.AsEnumerable.GroupBy(Function(g) g.Field(Of Integer)("PL_SEQ_NO")).Select(Function(t) t.CopyToDataTable).ToList

            Dim i As Integer = 1
            Dim j As Integer = 0
            Dim cidx As Integer = 0
            If dt.Rows.Count > 0 Then

                Dim temp() As String = dt.Rows(0)(2).ToString.Split(",")
                Dim valarr(UBound(temp)) As String
                For l As Integer = 0 To UBound(temp)
                    Dim idx As Integer = l
                    valarr(l) = dt.AsEnumerable.Select(Function(f) Convert.ToDouble(f.Field(Of String)(2).Split(",")(idx))).ToArray.Max
                Next



                Dim s As New StringBuilder("<script>")
                lblFName.Text = "DateRange: " & frm & " - " & en

                Dim arrData() As String = valarr 'dt.Rows(0)(2).ToString.Split(",")

                For Each g In groups
                    Dim results = arrData.Skip(j).Take(g.Rows.Count)
                    j = j + g.Rows.Count
                    Dim xdata As String = ""
                    Dim ydata As String = ""
                    For Each x In results



                        xdata &= ",'" & dt1.Rows(i - 1)("PL_ALIAS") & "'"
                        ' ydata &= "," & item
                        Dim color As String = "#3398DB"
                        ' If dt1.Rows(i - 1)("PL_MAX_LIMIT") > 0 AndAlso CDbl(x.ToString) >= dt1.Rows(i - 1)("PL_MAX_LIMIT") Then
                        If dt1.Rows(i - 1)("PL_MAX_LIMIT") > 0 AndAlso CDbl(arrData(dt1.Rows(i - 1)("PL_SL_NO") - 1)) >= dt1.Rows(i - 1)("PL_MAX_LIMIT") Then
                            color = "#F05D5E"
                        End If
                        ydata &= ",{value:" & arrData(dt1.Rows(i - 1)("PL_SL_NO") - 1) & ",itemStyle:{normal:{color:'" & color & "'}}}"
                        i = i + 1
                    Next
                    s.Append("option" & cidx & "={grid:{bottom:150,top:20,show:false},tooltip : {trigger: 'axis',axisPointer : {type : 'line'}},xAxis: {type: 'category',axisLabel:{show:true,rotate:90},data: [" & xdata.Substring(1) & "]},yAxis: { type: 'value',name: 'Speed StdDev (MPM)',splitLine:{show:false},nameLocation: 'middle',nameGap: 50}, series: [{ data: [" & ydata.Substring(1) & "],type: 'bar'}]};")
                    s.Append("var chart" & cidx & "=echarts.init(document.getElementById('container" & cidx & "'));chart" & cidx & ".setOption(option" & cidx & ");")
                    s.Append("chart" & cidx & ".on('click',function(params){window.open('pltcm_sub_chart.aspx?subparam=' + escape(params.name) + '', ""_blank"", ""toolbar=no,location=no,directories=no,status=no,scrollbars=yes,resizable=no,top=100,left=200,width=800,height=400"");});")
                    cidx += 1

                Next
                s.Append("</script>")
                Lit1.Text = s.ToString
            End If

            'If dt.Rows.Count > 0 Then
            '    lblFName.Text = dt.Rows(0)(0)

            '    Dim arrData() As String = dt.Rows(0)(2).ToString.Split(",")

            '    'Dim results = arrData.Select(Function(v, ix) New With {.value = v, .index = ix}).GroupBy(Function(x) x.index \ 15).Select(Function(x) x.Select(Function(z) z.value))

            '    Dim results = arrData.Select(Function(v, ix) New With {.value = v, .index = ix}).GroupBy(Function(x) x.index \ 15).Select(Function(x) x.Select(Function(z) z.value))

            '    Dim i As Integer = 1
            '    Dim cidx As Integer = 0
            '    Dim s As New StringBuilder("<script>")
            '    For Each x In results
            '        Dim xdata As String = ""
            '        Dim ydata As String = ""

            '        For Each item In x
            '            xdata &= ",'" & dt1.Rows(i - 1)("PL_ALIAS") & "'"
            '            ' ydata &= "," & item
            '            Dim color As String = "#3398DB"
            '            If dt1.Rows(i - 1)("PL_MAX_LIMIT") > 0 AndAlso item >= dt1.Rows(i - 1)("PL_MAX_LIMIT") Then
            '                color = "#F05D5E"
            '            End If
            '            ydata &= ",{value:" & item & ",itemStyle:{normal:{color:'" & color & "'}}}"
            '            i = i + 1
            '        Next
            '        s.Append("option" & cidx & "={grid:{bottom:100,top:20},tooltip : {trigger: 'axis',axisPointer : {type : 'line'}},xAxis: {type: 'category',axisLabel:{show:true,rotate:30},data: [" & xdata.Substring(1) & "]},yAxis: { type: 'value',name: 'StdDev. Max',nameLocation: 'middle',nameGap: 50}, series: [{ data: [" & ydata.Substring(1) & "],type: 'bar'}]};")
            '        s.Append("var chart" & cidx & "=echarts.init(document.getElementById('container" & cidx & "'));chart" & cidx & ".setOption(option" & cidx & ");")
            '        s.Append("chart" & cidx & ".on('click',function(params){window.open('pltcm_sub_chart.aspx?subparam=' + escape(params.name) + '', ""_blank"", ""toolbar=no,location=no,directories=no,status=no,scrollbars=yes,resizable=no,top=100,left=200,width=800,height=400"");});")
            '        cidx += 1
            '    Next
            '    s.Append("</script>")
            '    Lit1.Text = s.ToString

            'End If

        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Private Sub DrawDynamicContainer(ByRef dt1 As DataTable)
        Try
            Dim arr = dt1.AsEnumerable.Select(Function(x) x.Field(Of String)("PL_HEADER_NAME")).Distinct().ToArray
            Dim appendString = ""
            For i As Integer = 0 To arr.length - 1
                appendString &= "<div class='col-md-6'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>" & arr(i).ToString() & "</h3> <span></span></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='container" & i.ToString() & "' style='height: 300px;'></div></div></div></div>"
            Next
            divHolder.InnerHtml = appendString
        Catch ex As Exception

        End Try
    End Sub


End Class
