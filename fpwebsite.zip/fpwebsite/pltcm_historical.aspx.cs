﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.IO;

public partial class pltcm_historical : System.Web.UI.Page
{
      DataHandler objda = new DataHandler();
    Controller objController = new Controller();


    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Session["pagehit"] = objController.SaveAndRetrievePageHits(Session["LoginTime"].ToString(), Path.GetFileName(Request.Path));
            TextBox1.Text = DateTime.Now.AddDays(-1).ToString("yyyy-MM-ddTHH:mm");
            TextBox2.Text = DateTime.Now.ToString("yyyy-MM-ddTHH:mm");
            fillsms();
        }


    }

    private void fillsms()
    {
        
       DataTable dt = objda.GetDataSetFromQuery("select pl_alias,pl_sl_no from  FP_CRM_EQUIP_MAINTENANCE.dbo.CRM_PLTCM_LIMITS where pl_header_name is not null order by pl_sl_no").Tables[0];


        DropDownList1.DataSource = dt;
        DropDownList1.DataTextField = "pl_alias";
        DropDownList1.DataValueField = "pl_sl_no";
        DropDownList1.DataBind();
        DropDownList1.Items.Insert(0, "--choose--");
    }





    protected void Button1_Click(object sender, EventArgs e)
    {
        if (DropDownList1.SelectedIndex == 0)
        {
            return;
        }
        string date = TextBox1.Text.Replace("T"," ");
        string date2 = TextBox2.Text.Replace("T", " ");
        //fetch data
        
        DataTable dt = objda.GetDataSetFromQuery("select PEM_STARTTIME,PEM_SPD_STDDEV_MAX from [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_PLTCM_ENCODER_MAX]  where PEM_STARTTIME between '" + date + "' and '" + date2 + "' order by PEM_STARTTIME").Tables[0];
        int i = Int16.Parse(DropDownList1.SelectedItem.Value) - 1;
        if (i < 0)
        {
            Lit1.Text = "";
            return;
        }

        Literal1.Text = DropDownList1.SelectedItem.Text;
        Controller objcontroller = new Controller();
        Lit1.Text = objcontroller.PlotLineEChart(dt, "PEM_STARTTIME", "PEM_SPD_STDDEV_MAX", "chart1", "plot1", "", "", i);
    }
}
