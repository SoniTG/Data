﻿Imports System.Data
Imports System.IO
Partial Class pltcm_load_cell
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim objDataHandler As New DataHandler
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    txtDate_TextChanged()
                End If
            Catch ex As Exception

            End Try

        End If

        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd HH:mm:ss")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                hfFrom.Value = dtStart
                hfTo.Value = dtEnd
                GetData()
            Catch ex As Exception

            End Try

        End If
        'If Page.IsPostBack Then
        '    Try

        '        GetData()
        '    Catch ex As Exception

        '    End Try
        'End If
    End Sub

    Sub CreateDynamicContainer(ByVal dt As DataTable)


        Try
            Dim appendString = ""
            For i As Integer = 0 To dt.Rows.Count - 1
                appendString &= "<div class='col-md-6'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>" & dt.Rows(i)("CPLM_LOADCELLNAME") & "</h3> <span></span></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='cy" & i + 1 & "' style='height: 200px;'></div></div></div></div>"
                appendString &= "<div class='col-md-6'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>" & dt.Rows(i)("CPLM_LOADCELLNAME") & " Limits</h3> <span></span></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='cyc" & i + 1 & "' style='height: 200px;'></div></div></div></div>"

            Next
            divHolder.InnerHtml = appendString
        Catch ex As Exception

        End Try


    End Sub
    Sub GetData()
        Try
            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select * From [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_PLTCM_LOADCELL_MONITORING] where CPLM_DATETIME between '" & dtStart & "' and '" & dtEnd & "' order by CPLM_DATETIME").Tables(0)
            Dim dtDist As DataTable = objDataHandler.GetDataSetFromQuery("select distinct CPLM_LOADCELLNAME From [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_PLTCM_LOADCELL_MONITORING] order by 1").Tables(0)
            CreateDynamicContainer(dtDist)
            Dim l As Literal
            l = Page.Master.FindControl("content_body").FindControl("Lit1")
            For i As Integer = 0 To dtDist.Rows.Count - 1
                Dim dttemp As DataTable
                Dim dv As DataView = dt.DefaultView
                dv.RowFilter = "CPLM_LOADCELLNAME='" & dtDist.Rows(i)(0) & "'"
                dttemp = dv.ToTable()
                If dt.Rows.Count > 0 Then
                    l.Text &= BoxPlotForPltcmCylinder(dttemp, l, "cy", "plot", "", i + 1, plottypeDDl.SelectedValue.ToString)
                End If
                dv.RowFilter = ""
            Next


        Catch ex As Exception

        End Try

    End Sub


    Function BoxPlotForPltcmCylinder(ByVal dt As DataTable, ByVal lit As Literal, ByVal containerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal VAL As Integer, ByVal plottype As String) As String

        If (plottype = "Box Plot") Then

            lit.Text = ""
            Try
                ChartTitle = ""
                Dim ticks As String = "["
                Dim line1, line2, line3, line4 As String
                line1 &= "["
                line2 &= "["
                line3 &= "["
                line4 &= "["

                For i As Integer = 0 To dt.Rows.Count - 1
                    If (dt.Rows(i)(2).ToString <> "") Then

                        Try
                            ticks &= "'" & CDate(dt.Rows(i)("CPLM_DATETIME")).ToString("yyyy-MM-dd HH:mm:ss") & "'"

                            Dim tmpCyl() As String = dt.Rows(i)("CPLM_VALUE").ToString.Split(",")
                            line1 &= "[" & tmpCyl(0) & "," & tmpCyl(4) & "," & tmpCyl(3) & "," & tmpCyl(5) & "," & tmpCyl(1) & "]"

                            line2 &= tmpCyl(2) 'avg
                            line3 &= tmpCyl(0) 'min
                            line4 &= tmpCyl(1) 'max


                            If (i <> 0 Or i <> dt.Rows.Count - 1) Then
                                ticks &= ","
                                line1 &= ","
                                line2 &= ","
                                line3 &= ","
                                line4 &= ","
                            End If



                        Catch ex As Exception
                            Continue For
                        End Try
                    End If

                Next
                ticks &= "]"
                line1 &= "]"
                line2 &= "]"
                line3 &= "]"
                line4 &= "]"
                Dim js = "<script language='javascript' type='text/javascript'>"
                js &= "var ticks=" & ticks & ";"
                js &= "var pl1=" & line1 & ";"
                js &= "var pl2=" & line2 & ";"
                js &= "var pl3=" & line3 & ";"
                js &= "var pl4=" & line4 & ";"
                js &= "var lmin = Math.min(Math.min.apply(null,pl2),Math.min.apply(null,pl3),Math.min.apply(null,pl4));"
                js &= "var lmax = Math.max(Math.max.apply(null,pl2),Math.max.apply(null,pl3),Math.max.apply(null,pl4));"
                js &= "var yMin = (lmin<-300)?lmin-5:-310; var yMax = (lmax>300)?lmax+ 5:310;"

                js &= "option" & VAL & " = {toolbox:{feature:{dataZoom:{}}}, tooltip: {trigger:    'item',axisPointer: {type:       'shadow'}},grid: {left:       '10%',top:'20%',right:      '10%',bottom: '15%'}, xAxis: {"
                js &= "type:       'category',   data:ticks, boundaryGap: true, nameGap: 30, splitArea: { show: true}, axisLabel: {formatter:  ' {value}'}, splitLine: {show: false}}, yAxis: {name:'Ton',nameGap:50,nameLocation:'middle',type:'value',splitArea: {show: false}},"
                js &= " dataZoom: [{type:       'inside',start: 0,end: 100},{show: true,height: 20,type: 'slider',top:'90%',xAxisIndex: [0]}],"
                js &= " series: [{name:       'ACR Output (Count)',type:       'boxplot', data: pl1,tooltip: {formatter: formatter}}]};"
                js &= "function formatter(param) {return ['upper: ' + param.data[5],'Q3: ' + param.data[4],'median: ' + param.data[3],'Q1: ' + param.data[2],'lower: ' + param.data[1]].join('<br/>')}"
                js &= "var " & PlotName & VAL & " = echarts.init(document.getElementById('" & containerName & VAL & "'));" & PlotName & VAL & ".setOption(option" & VAL & ");"

                js &= "option1" & VAL & "= { tooltip: {trigger: 'axis'}, legend: { y: '10%', data: ['Avg','Min','Max']},grid: {left:       '10%',top:'20%',right:      '10%',bottom: '15%'}, xAxis: {"
                js &= "type:       'category',   data:ticks}, yAxis: {name:'Ton',nameLocation:'middle',nameGap:50,type: 'value'},"
                js &= " dataZoom: [{type:       'inside',start: 0,end: 100},{show: true,height: 20,type: 'slider',top:'90%',xAxisIndex: [0]}],"
                js &= "series: [{name:       'Avg',data: pl2, type:'line'},{name:       'Min',data: pl3, type:'line'},{name:       'Max',data: pl4, type:'line'}]"
                'js &= "series: [{name:       'Avg',data: pl2, type:'line',markLine:{data:[{yAxis:300,name:'UCL'},{yAxis:-300,name:'LCL'}]}},{name:       'Min',data: pl3, type:'line'},{name:       'Max',data: pl4, type:'line'}]"
                js &= "};var  " & PlotName & "1" & VAL & " =  echarts.init(document.getElementById('" & containerName & "c" & VAL & "'));" & PlotName & "1" & VAL & ".setOption(option1" & VAL & ");"
                js &= "</script>"

                Return js
            Catch ex As Exception

            End Try
        End If
        If (plottype = "Average" Or plottype = "Std Deviation") Then
            lit.Text = ""
            Try
                ChartTitle = ""
                Dim ticks As String = "["
                Dim line1, line2 As String
                line1 &= "["
                line2 &= "["
                Dim Cylinder As String = ""
                Cylinder = String.Format("{0}{1}", "Cylinder", VAL)
                Dim Strip As String = ""
                Strip = String.Format("{0}{1}", "Strip", VAL)
                For i As Integer = 0 To dt.Rows.Count - 1
                    If (dt.Rows(i)(Cylinder).ToString <> "") Then

                        Try
                            ticks &= "'" & dt.Rows(i)("CPCT_START_TIME") & "'"

                            Dim tmpCyl() As String = dt.Rows(i)(Cylinder).ToString.Split(",")
                            If (plottype = "Average") Then
                                line1 &= tmpCyl(2)
                            Else
                                line1 &= tmpCyl(6)
                            End If


                            Dim tmpStrip() As String = dt.Rows(i)(Strip).ToString.Split(",")
                            If (plottype = "Average") Then
                                line2 &= tmpStrip(2)
                            Else
                                line2 &= tmpStrip(6)
                            End If


                            If (i <> 0 Or i <> dt.Rows.Count - 1) Then
                                ticks &= ","
                                line1 &= ","
                                line2 &= ","
                            End If



                        Catch ex As Exception
                            Continue For
                        End Try
                    End If

                Next
                ticks &= "]"
                line1 &= "]"
                line2 &= "]"
                Dim js = "<script language='javascript' type='text/javascript'>"
                js &= "var ticks=" & ticks & ";"
                js &= "var pl1=" & line1 & ";"
                js &= "var pl2=" & line2 & ";"
                js &= "  option = { tooltip: {trigger:'axis' }, legend: { data:['Cylinder','Strip']},toolbox: { show: true, feature: { "
                js &= " magicType: {type: ['line', 'bar']},} },dataZoom: [{show: true,start:1, end: 100},{type:'inside',start: 0,end: 20 }, ], xAxis:  {type:'category', boundaryGap: false, data: ticks },"
                js &= "  yAxis: {type: 'value', axisLabel: {formatter:  '{value}'  } }, series: [ {name: 'Cylinder',type: 'line',data:pl1, },"
                js &= " {name: 'Strip',type: 'line',data:pl2, } ]};"
                js &= "var " & PlotName & " = echarts.init(document.getElementById('" & containerName & "'));" & PlotName & ".setOption(option);"
                js &= "</script>"
                Return js
            Catch ex As Exception

            End Try



        End If

    End Function
    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try
            GetData()
            'CreateDynamicContainer()
        Catch ex As Exception

        End Try


    End Sub

End Class
