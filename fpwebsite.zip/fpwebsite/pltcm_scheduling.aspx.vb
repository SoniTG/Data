﻿Imports System.Data
Imports Oracle.ManagedDataAccess.Client
Partial Class pltcm_scheduling
    Inherits System.Web.UI.Page
    Dim obj_sch_model As New PLTCM_TSJ_Schedule
    Dim objDataHandler As New DataHandler
    Private Sub pltcm_scheduling_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            LoadGridView()
        End If
    End Sub

    Private Sub LoadGridView()
        Dim dt As New DataTable
        dt = objDataHandler.GetOracleData("select PDM_ID_PDI,PDM_ID_CR_COIL,PDM_CD_STATUS,PDM_GRADE_STEEL,PDM_SEC1_HR as HRTHK,PDM_SEC2_HR as HRWDT, PDM_SEC1_CR_AIM/1000 as CRTHK,PDM_YIELD_POINT as YP_AIM, PDM_TDC_NO,PDM_MS_HR_COIL as CRWT,PDM_LN_HR,PDM_SEC2_AFTR_TRIM as CRWDT,PDM_HR_TDC,PDM_CD_TRIMMER,PDM_ACT_NEXT_PROC from V_PR_DATA_IP_PCM where pdm_cd_status like 'WC%' or pdm_cd_status like 'WS%' order by pdm_id_pdi asc")
        obj_sch_model.Main()
        dt = obj_sch_model.ww_dt
        GridView1.DataSource = dt
        GridView1.DataBind()

        If dt.Rows.Count > 0 Then
            GridView1.UseAccessibleHeader = True
            GridView1.HeaderRow.TableSection = TableRowSection.TableHeader
        End If
    End Sub

    Private Sub GridView1_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridView1.RowDataBound
        Dim counter As Integer = 0

        For Each oItem As GridViewRow In GridView1.Rows
            counter += 1
            oItem.Attributes("id") = "tr_" + counter.ToString


        Next
        Try
            If e.Row.Cells(22).Text > 900 Then
                e.Row.BackColor = Drawing.Color.BurlyWood
            End If
        Catch ex As Exception

        End Try


        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim text = e.Row.Cells(7).Text
            e.Row.Cells(7).Attributes.Add("style", "background:linear-gradient(to right,#4C787E " & text & "%, transparent 0) no-repeat")
            'e.Row.Cells(7).Text = "<div>" & text & "</div>"
        End If
    End Sub
End Class
