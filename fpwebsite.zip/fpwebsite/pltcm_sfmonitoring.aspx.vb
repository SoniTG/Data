﻿Imports System.Data
Imports System.IO
Partial Class pltcm_sfmonitoring
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    txtDate_TextChanged()
                End If
            Catch ex As Exception

            End Try

        End If

        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
                'Dim dtStart As DateTime = DateTime.Now.AddMonths(-6).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                DrawChart(dtStart, dtEnd)
            Catch ex As Exception

            End Try

        End If

    End Sub
    Sub DrawChart(ByVal FromDate As String, ByVal ToDate As String)
        Try
            Dim strfrmDt As String = FromDate
            Dim strtoDt As String = ToDate
            Dim dt As DataTable = objController.GetDataForSFMonitoring(strfrmDt, strtoDt)
            If dt.Rows.Count > 0 Then

                ' objController.PlotLineChartForSFMonitoring(dt, "PTCI_DATETIME", "PSM_SF_RATIO", Lit1, "container", "plot1", "", "", "PTCI_GRADE")
                'objController.PlotChartForSFMonitoring(dt, "PTCI_DATETIME", "PSM_SF_RATIO", Lit1, "container", "plot1", "", "Speed Ratio (%)", "PTCI_GRADE", "", "")
                objController.PlotScatterChartForSFMonitoring(dt, "HR_WIDTH", "PSM_SF_RATIO", Lit1, "container", "plot1", "CR Width (mm)", "Speed Ratio (%)")
            Else
                Lit1.Text = ""
            End If
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try
            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            DrawChart(dtStart, dtEnd)
        Catch ex As Exception

        End Try

    End Sub

End Class
