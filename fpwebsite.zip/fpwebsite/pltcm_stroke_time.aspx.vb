﻿Imports System.Data
Imports System.IO
Partial Class pltcm_stroke_time
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim objDataHandler As New DataHandler
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    txtDate_TextChanged()
                End If
            Catch ex As Exception

            End Try

        End If

        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-10).ToString("yyyy-MM-dd HH:mm:ss")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                hfFrom.Value = dtStart
                hfTo.Value = dtEnd
                GetData()
            Catch ex As Exception

            End Try

        End If
        'If Page.IsPostBack Then
        '    Try

        '        GetData()
        '    Catch ex As Exception

        '    End Try
        'End If
    End Sub

    Sub CreateDynamicContainer(ByVal dt As DataTable)


        Try
            Dim appendString = ""
            For i As Integer = 0 To dt.Rows.Count - 1
                appendString &= "<div class='col-md-6'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>" & dt.Rows(i)("CPW_PARAM_ALIAS") & "</h3> <span></span></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='cy" & i + 1 & "' style='height: 200px;'></div></div></div></div>"


            Next
            divHolder.InnerHtml = appendString
        Catch ex As Exception

        End Try


    End Sub
    Sub GetData()
        Try
            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select * From [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_PLTCM_WELDER_DATA] where CPW_DATETIME between '" & dtStart & "' and '" & dtEnd & "' order by CPW_DATETIME").Tables(0)
            Dim dtDist As DataTable = objDataHandler.GetDataSetFromQuery("select CPW_PARAM_ALIAS,CPW_PARAM_NAME From [FP_CRM_EQUIP_MAINTENANCE].[dbo].[CRM_PLTCM_WELDER_LIMIT] order by cpwl_slno").Tables(0)
            CreateDynamicContainer(dtDist)
            Dim l As Literal
            l = Page.Master.FindControl("content_body").FindControl("Lit1")
            l.Text = ""
            For i As Integer = 0 To dtDist.Rows.Count - 1
                Dim dttemp As DataTable
                Dim dv As DataView = dt.DefaultView
                dv.RowFilter = "CPW_PARAM_NAME='" & dtDist.Rows(i)(1) & "'"
                dttemp = dv.ToTable()
                If dt.Rows.Count > 0 Then
                    l.Text &= PlotLineChart(dttemp, "CPW_DATETIME", "CPW_PARAM_VAL", "cy" & (i + 1), "plot" & (i + 1), "", "seconds", "") 's BoxPlotForPltcmCylinder(dttemp, l, "cy", "plot", "", i + 1, plottypeDDl.SelectedValue.ToString)
                End If
                dv.RowFilter = ""
            Next


        Catch ex As Exception

        End Try

    End Sub

    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try
           
            GetData()
            'CreateDynamicContainer()
        Catch ex As Exception

        End Try


    End Sub

    Public Function PlotLineChart(ByVal dt As DataTable, ByVal XAxisColName As String, ByVal YAxisColName As String, ByVal ContainerName As String, ByVal PlotName As String, ByVal ChartTitle As String, ByVal YAxisLabelName As String, ByVal index As String) As String
        Try


            Dim min_time, max_time As String
            min_time = Format(DateTime.Parse(dt.Rows(0)(XAxisColName)).AddMinutes(-30), "yyyy-MM-dd HH:mm")
            max_time = Format(DateTime.Parse(dt.Rows(dt.Rows.Count - 1)(XAxisColName)).AddMinutes(30), "yyyy-MM-dd HH:mm")

            'Dim xTimestampVal(), yVal() As String
            Dim yVal() As Decimal

            'xTimestampVal = (From row In dt Select col = row(XAxisColName).ToString).ToArray
            yVal = (From row In dt Select col = CDec(IIf(IsDBNull(row(YAxisColName)), 0, row(YAxisColName))) Where col > 0).ToArray()
            If yVal.Length = 0 Then Return ""

            'Dim y_min As String = yVal.Min()
            'Dim y_max As String = yVal.Max()
            Dim y_min As String = yVal.Min() - (10 / 100 * yVal.Min)
            Dim y_max As String = yVal.Max() + (10 / 100 * yVal.Max)

            Dim js As String = "<script language='javascript' type='text/javascript'>" & vbCrLf &
                    "$.jqplot.config.enablePlugins = true;" & vbCrLf
            js &= "var line" & index & " = ["
            For j As Integer = 0 To dt.Rows.Count - 1
                If j > 0 Then
                    'js &= ","
                End If

                Dim dtTime As DateTime = dt.Rows(j)(XAxisColName)

                If IsDBNull(dt.Rows(j)(YAxisColName)) = False Then
                    js &= "['" & dtTime.ToString("yyyy-MM-dd HH:mm:ss") & "', " & dt.Rows(j)(YAxisColName) & "],"

                End If

            Next

            js &= "];" & vbCrLf
            'Dim strg As String = ""
            'Dim strseries As String = ""
            'If flag Then
            '    strg = "[line1"
            '    strseries = " {showLine:true, lineWidth:2, markerOptions:{ size: 5 }, highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}"

            '    strg &= "]"
            'End If
            'js &= "var seriesName = ['"
            'Dim str As String = ""
            'For i As Integer = 0 To dtGroups.Rows.Count - 1
            '    str &= dtGroups.Rows(i)(0).ToString().Trim() + "', '"
            'Next
            'str = str.Remove(str.LastIndexOf(", '"))
            'str &= "];"
            'js &= str
            js &= "opts = {" & vbCrLf &
            "title: '" & ChartTitle & "'," & vbCrLf &
            "seriesDefaults: { showMarker:true,lineWidth: 2,markerOptions: {size: 5}, pointLabels: { show:false },color: '#4832DB', highlighter: {show: true,showMarker: false,tooltipAxes:'xy',yvalues: 2,formatString: '<table style=""background-color:#FFFDBF; font-weight:bold;"" class=""jqplot-highlighter""> \ <tr><td>%s</td></tr>\ <tr><td>%s</td></tr></table>'}}," &
            "axesDefaults: {" & vbCrLf &
            "tickRenderer: $.jqplot.CanvasAxisTickRenderer ," & vbCrLf &
            "tickOptions: {" & vbCrLf &
            "fontSize:'8pt'" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "axes: {" & vbCrLf &
            "xaxis: {" & vbCrLf &
            "//min: '" & min_time & "', max: '" & max_time & "'," & vbCrLf &
            "renderer:$.jqplot.DateAxisRenderer," & vbCrLf &
            "tickOptions:{formatString:'%d-%b %H:%M:%S', angle: -30}," & vbCrLf &
            "//tickInterval:'1 day'," & vbCrLf &
            "pad:0" & vbCrLf &
            "}," & vbCrLf &
            "yaxis: { " & vbCrLf &
            "tickOptions: { formatString: '%8.3f' },min:0.0," & vbCrLf &
            "label: '" & YAxisLabelName & "'," & vbCrLf &
            "labelRenderer: $.jqplot.CanvasAxisLabelRenderer" & vbCrLf &
            "}" & vbCrLf &
            "}," & vbCrLf &
            "cursor: {" & vbCrLf &
            "showTooltip: false," & vbCrLf &
            "zoom: true" & vbCrLf &
            "}," & vbCrLf &
            "animate: true," & vbCrLf &
            "grid: {backgroundColor:  'rgb(255,255,255)'}" & vbCrLf &
            "};" & vbCrLf &
            "" & PlotName & " = $.jqplot('" & ContainerName & "',[line" & index & "],opts);" & vbCrLf &
            "</script>" & vbCrLf

            Return js
        Catch ex As Exception
            Return ""
        End Try
    End Function
End Class
