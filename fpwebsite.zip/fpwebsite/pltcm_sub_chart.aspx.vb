Public Class pltcm_sub_chart
    Inherits System.Web.UI.Page

End Class