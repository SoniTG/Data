﻿Imports System.Data
Imports System.IO
Imports OfficeOpenXml
Imports OfficeOpenXml.Style
Imports System.Globalization
Imports System.Data.SqlClient
Imports System.Collections.Generic
Imports System.Text
Imports System.Data.OleDb
Imports System.Configuration

Partial Class pltcm_surface_insp
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim objDataHandler As New DataHandler
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub

    Sub UserMsgBoxSuccess(ByVal Message As String, ByVal Url As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalertandredirect('" + Message + "', '" + Url + "');", True)
    End Sub

    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        If Not Page.IsPostBack Then
            Session("pagehit") = New Controller().SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
            Dim qry As String = "  select (select max(Date_Create) from RCL_JCAP_SURFACE_INSPECTION where Daughter_Coil like 'j%') as Jcap,(select max(Date_Create) from RCL_JCAP_SURFACE_INSPECTION where Daughter_Coil not like 'j%') as Hsm "
            Dim tab As DataSet = objDataHandler.GetDataSetFromQueryAnalysis(qry)
            Label1.Text = tab.Tables(0).Rows(0)("Hsm")
            Label2.Text = tab.Tables(0).Rows(0)("Jcap")
            'Dim constring As String = 
            'Using con As New SqlConnection(constring)
            '    Using cmd As New SqlCommand("SELECT * FROM Customers", con)
            '        cmd.CommandType = CommandType.Text
            '        Using sda As New SqlDataAdapter(cmd)
            '            Using dt As New DataTable()
            '                sda.Fill(dt)
            '                dataGridView1.DataSource = dt
            '            End Using
            '        End Using
            '    End Using
            'End Using
        End If
    End Sub

    Protected Sub btnUpload_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnUpload.Click
        If FileUpload1.HasFile Then
            FileUpload1.PostedFile.SaveAs(Server.MapPath("~/Uploads/" + FileUpload1.FileName))
            Dim exfname As String = Server.MapPath("~/Uploads/" + FileUpload1.FileName)
            Dim connString As String = String.Empty

            Dim extension As String = Path.GetExtension(FileUpload1.PostedFile.FileName)
            Dim validFileTypes As String() = {".xls", ".xlsx"}
            Dim isValidFile As Boolean = False
            'To Check Valid file or not
            For i As Integer = 0 To validFileTypes.Length - 1

                If extension = validFileTypes(i) Then

                    isValidFile = True

                    Exit For

                End If

            Next

            If Not isValidFile Then
                UserMsgBoxWarning("Choose .xls or .xlsx file only.Try Again")

            Else

                String.Join(",", validFileTypes)
                Select Case extension
                    Case ".xls"
                        'Excel 97-03
                        connString = ConfigurationManager.ConnectionStrings("Excel03ConString").ConnectionString
                        Exit Select
                    Case ".xlsx"
                        'Excel 07 or higher
                        connString = ConfigurationManager.ConnectionStrings("Excel07+ConString").ConnectionString
                        Exit Select

                End Select
                connString = String.Format(connString, exfname)
                Using excel_con As New OleDbConnection(connString)
                    excel_con.Open()
                    Dim dtInsert As New DataTable()


                    Dim sheet1 As String = excel_con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing).Rows(0)("TABLE_NAME").ToString()
                    'dtInsert.Columns.AddRange(New DataColumn(18) {New DataColumn("Daughter Coil", GetType(String)), _
                    '                                            New DataColumn("Defect Name", GetType(String)), _
                    '                                            New DataColumn("Surface", GetType(String)), _
                    '                                            New DataColumn("Defect Length", GetType(Integer)), _
                    '                                            New DataColumn("Severity", GetType(Integer)), _
                    '                                            New DataColumn("Date Create", GetType(DateTime)), _
                    '                                            New DataColumn("Length Coil", GetType(Integer)), _
                    '                                            New DataColumn("Grade", GetType(String)), _
                    '                                            New DataColumn("Sec1_PDI", GetType(String)), _
                    '                                            New DataColumn("Sec2 PDI", GetType(String)), _
                    '                                            New DataColumn("TDC No", GetType(String)), _
                    '                                            New DataColumn("TDC Desc", GetType(String)), _
                    '                                            New DataColumn("Defect St. Width", GetType(String)), _
                    '                                            New DataColumn("Defect End Width", GetType(String)), _
                    '                                            New DataColumn("Defect St. Length", GetType(String)), _
                    '                                            New DataColumn("Defect End Length", GetType(String)), _
                    '                                            New DataColumn("Surface Standard", GetType(String)), _
                    '                                            New DataColumn("Expert", GetType(String)), _
                    '                                            New DataColumn("Coil Yield", GetType(String))})

                    Using oda As New OleDbDataAdapter((Convert.ToString("SELECT * FROM [") & sheet1) + "]", excel_con)
                        'Using oda As New OleDbDataAdapter((Convert.ToString("SELECT * FROM [" & sheet1 + "A") & n) + "] where [Daughter Coil] is not null", excel_con)
                        oda.Fill(dtInsert)

                        'To delete empty  and unwanted rows
                        For i As Integer = dtInsert.Rows.Count - 1 To 0 Step -1
                            Dim row As DataRow = dtInsert.Rows(i)
                            If row.Item(9) Is Nothing Then
                                dtInsert.Rows.Remove(row)
                            ElseIf row.Item(9).ToString = "" Then
                                dtInsert.Rows.Remove(row)
                            End If
                        Next
                        dtInsert.AcceptChanges()

                    End Using
                    excel_con.Close()

                    If dtInsert.Rows.Count > 0 Then

                        Using sqlConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("TG-GWL").ConnectionString)
                            Using sqlCommand As New SqlCommand
                                sqlConnection.Open()
                                Dim strQuery As String = ""
                                If dtInsert.Rows.Count > 0 Then
                                    For i As Short = 1 To dtInsert.Rows.Count - 1
                                        If dtInsert.Rows(i)(3) IsNot DBNull.Value Or dtInsert.Rows(i)(4) IsNot DBNull.Value Then
                                            If dtInsert.Rows(i)(3) <> 0 Or dtInsert.Rows(i)(4) <> 0 Then

                                                Try
                                                    Dim mother_coil As String = Nothing
                                                    If dtInsert.Rows(i)(0).ToString().Replace("'", "").StartsWith("J") Then
                                                        mother_coil = dtInsert.Rows(i)(0).ToString().Replace("'", "").ToString.Substring(1, 6) & "0000"
                                                    Else
                                                        mother_coil = dtInsert.Rows(i)(0).ToString().Replace("'", "").ToString.Substring(0, 6) & "0000"
                                                    End If
                                                    strQuery = "insert into RCL_JCAP_SURFACE_INSPECTION (Daughter_Coil, Defect_Name, Surface, Defect_Length, Severity, " &
                                              "Date_Create, Length_Coil, Grade, Sec1_PDI, Sec2_PDI, TDC_No, TDC_Desc, Defect_St_Width, " &
                                              "Defect_End_Width, Defect_St_Length, Defect_End_Length, Surface_Standard, Expert, Coil_Yield,Mother_Coil) " &
                                              " values('" & dtInsert.Rows(i)(0).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(1).ToString().Replace("'", "") & "'," &
                                              "'" & dtInsert.Rows(i)(2).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(3).ToString().Replace("'", "") & "'," &
                                              "'" & dtInsert.Rows(i)(4).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(5).ToString().Replace("'", "") & "'," &
                                              "'" & dtInsert.Rows(i)(6).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(7).ToString().Replace("'", "") & "'," &
                                              "'" & dtInsert.Rows(i)(8).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(9).ToString().Replace("'", "") & "'," &
                                              "'" & dtInsert.Rows(i)(10).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(11).ToString().Replace("'", "") & "'," &
                                              "'" & dtInsert.Rows(i)(12).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(13).ToString().Replace("'", "") & "'," &
                                              "'" & dtInsert.Rows(i)(14).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(15).ToString().Replace("'", "") & "'," &
                                             "'" & dtInsert.Rows(i)(16).ToString().Replace("'", "") & "','" & dtInsert.Rows(i)(17).ToString().Replace("'", "") & "'," &
                                              "'" & dtInsert.Rows(i)(18).ToString().Replace("'", "") & "','" & mother_coil & "'); " & vbCrLf
                                                    sqlCommand.Connection = sqlConnection

                                                    sqlCommand.CommandText = strQuery
                                                    sqlCommand.CommandTimeout = 10000
						    If sqlConnection.State = ConnectionState.Closed Then sqlConnection.Open
                                                    sqlCommand.ExecuteNonQuery()
                                                Catch sqle As SqlException
                                                    Continue For
                                                Catch ex As Exception

                                                    UserMsgBoxWarning("Data Not Matching.Select other file.")
                                                End Try
                                            End If
                                        End If
                                    Next
                                    sqlConnection.Close()
                                    UserMsgBoxSuccess("File Uploaded Successfully.")
                                End If
                                Dim dtgrid As New DataTable
                                dtgrid = dtInsert

                                uploadeddata.DataSource = dtgrid

                                ''  uploadeddata.DeleteRow(1)
                                uploadeddata.DataBind()

                            End Using
                        End Using
                    Else
                        UserMsgBoxWarning("Data not found.")
                    End If


                End Using
            End If
            'to automatically download the uploaded file
            If File.Exists(Server.MapPath("~/Uploads/" + FileUpload1.FileName)) Then
                File.Delete(Server.MapPath("~/Uploads/" + FileUpload1.FileName))
            End If
        Else
            UserMsgBoxWarning("No file selected. Please select the excel file.")
        End If

        Dim qry As String = "  select (select max(Date_Create) from RCL_JCAP_SURFACE_INSPECTION where Daughter_Coil like 'j%') as Jcap,(select max(Date_Create) from RCL_JCAP_SURFACE_INSPECTION where Daughter_Coil not like 'j%') as Hsm "
        Dim tab As DataSet = objDataHandler.GetDataSetFromQueryAnalysis(qry)
        Label1.Text = tab.Tables(0).Rows(0)("Hsm")
        Label2.Text = tab.Tables(0).Rows(0)("Jcap")
    End Sub



End Class
