﻿Imports System.Data
Imports System.IO
Imports System.Data.OleDb
Partial Class pltcmcylinder
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Dim HeaderName() As String = {"CPC 1 Cylinder & Strip Trend", "CPC 2 Cylinder & Strip Trend", "CPC 3 Cylinder & Strip Trend", "CPC 4 Cylinder & Strip Trend", "CPC 5 Cylinder & Strip Trend", "CPC 6 Cylinder & Strip Trend", "CPC 7 Cylinder & Strip Trend"}
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
                If p = "date" Then
                    txtDate_TextChanged()
                End If
            Catch ex As Exception

            End Try

        End If

        If Not Page.IsPostBack Then
            Try
                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd HH:mm:ss")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                CreateDynamicContainer(HeaderName)
                Dim dt As DataTable = objController.PopulatePltcmCylinderData(dtStart, dtEnd)

                Dim l As Literal
                Dim COUNT As Integer = 1
                Dim literals = Page.Master.FindControl("content_body").Controls.OfType(Of Literal)()
                For Each lit In literals
                    Dim i As Integer = i + COUNT
                    If (lit.ID = "Lit" & i) Then
                        l = lit
                        If dt.Rows.Count > 0 Then
                            objController.BoxPlotForPltcmCylinder(dt, l, "c" & i - 1, "plot", "", i, plottypeDDl.SelectedValue.ToString)

                        End If
                    Else
                        Exit For
                    End If
                Next

                'If dt.Rows.Count > 0 Then
                '    objController.BoxPlotForPltcmCylinder(dt, l, "c0", "plot", "", i)

                'End If


            Catch ex As Exception

            End Try

        End If
        If Page.IsPostBack Then
            Try
                CreateDynamicContainer(HeaderName)
                GetData()
            Catch ex As Exception

            End Try
        End If
    End Sub
    Sub GetData()
        Try
            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            Dim dt As DataTable = objController.PopulatePltcmCylinderData(dtStart, dtEnd)
            Dim l As Literal
            Dim COUNT As Integer = 1
            Dim literals = Page.Master.FindControl("content_body").Controls.OfType(Of Literal)()
            For Each lit In literals
                Dim i As Integer = i + COUNT
                If (lit.ID = "Lit" & i) Then
                    l = lit
                    If dt.Rows.Count > 0 Then
                        objController.BoxPlotForPltcmCylinder(dt, l, "c" & i - 1, "plot", "", i, plottypeDDl.SelectedValue.ToString)

                    End If
                Else
                    Exit For
                End If
            Next

        Catch ex As Exception

        End Try

    End Sub

    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try
            GetData()
            'CreateDynamicContainer()
        Catch ex As Exception

        End Try


    End Sub
    Sub CreateDynamicContainer(ByVal Header() As String)
        Try
            Dim appendString = ""
            For i As Integer = 0 To Header.Length - 1
                appendString &= "<div class='col-md-4'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>" & Header(i).ToString() & "</h3> <span></span></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='c" & i.ToString() & "' style='height: 200px;'></div></div></div></div>"
            Next
            divHolder.InnerHtml = appendString
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub btnCpc_Click(sender As Object, e As System.EventArgs) Handles btnCpc.Click
        Try
            CreateDynamicContainer(HeaderName)
            GetData()
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub Button2_Click(sender As Object, e As System.EventArgs) Handles Button2.Click
        'CreateDynamicContainer(2, HeaderName)
    End Sub
End Class
