﻿Imports System.Data
Imports System.IO
Partial Class spmcoildetaillabview
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
                If (p = "thickness(mm)") Then
                    'processThickness()
                ElseIf p = "coil" Then
                    'processCoil()
                ElseIf p = "width(mm)" Then
                    'processWidth()
                ElseIf p = "date" Then
                    txtDate_TextChanged()
                End If
            Catch ex As Exception

            End Try

        End If



        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-5).ToString("yyyy-MM-dd HH:mm")
                'Dim dtStart As DateTime = DateTime.Now.AddMonths(-6).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                objController.PopulateGradeForSPM(ddlGrade, dtStart, dtEnd)
                objController.PopulateTdcForSPM(ddlTdc, dtStart, dtEnd, "")
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForSPMDetailAnalysis(dtStart, dtEnd, "", "")
                If dt.Rows.Count > 0 AndAlso Not IsDBNull(dt.Rows(0)(0)) Then
                    txtFromThickness.Text = dt.Rows(0)(0)
                    txtToThickness.Text = dt.Rows(0)(1)
                    If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                        dt1 = objController.PopulateWidthForSPMDetailAnalysis(dtStart, dtEnd, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                        txtWidthFrom.Text = dt1.Rows(0)(0)
                        txtWidthTo.Text = dt1.Rows(0)(1)
                    End If
                End If
                objController.LoadColumnNameForSPMCoilDetailLabView(clbParamTest, Session("ColumnName"))

            Catch ex As Exception

            End Try
        End If
    End Sub


    Protected Sub btnOk_Click(sender As Object, e As EventArgs) Handles btnOk.Click
        Try

            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            Dim str1 As String = ""
            Dim count As Integer = 0
            Dim appendString = ""
            For i As Integer = 0 To clbParamTest.Items.Count - 1
                If clbParamTest.Items(i).Selected Then
                    count += 1
                    str1 &= "," & clbParamTest.Items(i).Value
                    appendString &= "<div class='col-md-2'></div><div class='col-md-10'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>" & clbParamTest.Items(i).Text & "</h3> <span></span></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='" & clbParamTest.Items(i).Value & "' style='height: 200px;'></div></div></div></div>"


                End If
            Next
            divHolder.InnerHtml = appendString
            If str1 = "" Then

            Else
                str1 = str1.Substring(1)
                Dim filter As String = " 1=1"
                If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
                    filter &= " and GRADE = '" & ddlGrade.SelectedItem.Text & "'"
                End If
                If ddlTdc.SelectedItem.Text.ToLower <> "all" Then
                    filter &= " and TDC_No = '" & ddlTdc.SelectedItem.Text & "'"
                End If
                If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                    filter &= " and THICKNESS between " & txtFromThickness.Text & " and " & txtToThickness.Text & ""
                    'divHolder.Attributes.Add("style", "display:none")
                End If
                If txtWidthFrom.Text <> "" And txtWidthTo.Text <> "" Then
                    filter &= " and WIDTH between " & txtWidthFrom.Text & " and " & txtWidthTo.Text & ""
                End If
                DrawChartTop(str1, fromDt, toDt, filter)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Sub DrawChartTop(ByVal ColumnName As String, ByVal FromDt As String, ByVal ToDt As String, ByVal Filter As String)
        Try

            Dim strfrmDt As String = FromDt
            Dim strToDt As String = ToDt

            Dim dtUnit As DataTable = objController.GetUnitForSPM("UNIT_DETAILS", ColumnName)

            Dim dt As DataTable = objController.GetDataForSPM("CRM_SPM_PROCESS_DATA_COILWISE_BODY", strfrmDt, strToDt, "COIL_STARTDATETIME", ColumnName.Replace("UNIT_", ""), Filter)

            Dim a() As String = ColumnName.Split(",")
            Dim unit(a.Length) As String
            Dim multiplier As String = "1.0"
            For k As Integer = 0 To a.Length - 1
                Dim c As String = a(k)

                Dim row() As DataRow = dtUnit.Select("PARAMETER_NAME='" & c & "'")
                If row.Length > 0 Then
                    multiplier = row(0)(1)
                    unit(k) = row(0)(2)
                Else
                    multiplier = "1.0"
                End If
                dt.Columns.Add(a(k) & "_C", GetType(Double), a(k).Replace("UNIT_", "") & "*" & multiplier)
            Next



            'Dim yVal As String = ""

            Dim l As Literal
            For i As Integer = 0 To UBound(a)
                Dim literals = Page.Master.FindControl("content_body").Controls.OfType(Of Literal)()
                For Each lit In literals
                    If (lit.ID = "Lit" & i + 1) Then
                        l = lit
                        Exit For
                    End If
                Next
                ' Dim literal As Literal = CType(Me.Master.FindControl("Lit" & i + 1), Literal)
                objController.PlotLineChartForSPM(dt, "COIL_STARTDATETIME", a(i) & "_C", l, a(i), "plot" & i + 1, "", unit(i), i)
                'objController.PlotLineChartForSPMCoil(dt, "COIL_STARTDATETIME", a(i), l, a(i), "plot" & i + 1, "", "", "DAUGHTER_COILID_NUM")
            Next




        Catch ex As Exception

        End Try
    End Sub

    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try

            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            If (hfIsButton.Value = "false") Then
                'If ddlGrade.SelectedIndex > 0 And ddlTdc.SelectedIndex > 0 And ddlThickness.SelectedIndex > 0 Then
                objController.PopulateGradeForSPM(ddlGrade, dtStart, dtEnd)
                objController.PopulateTdcForSPM(ddlTdc, dtStart, dtEnd, "")
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForSPMDetailAnalysis(dtStart, dtEnd, "", "")
                If dt.Rows.Count > 0 AndAlso Not IsDBNull(dt.Rows(0)(0)) Then
                    txtFromThickness.Text = dt.Rows(0)(0)
                    txtToThickness.Text = dt.Rows(0)(1)
                    If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                        dt1 = objController.PopulateWidthForSPMDetailAnalysis(dtStart, dtEnd, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                        txtWidthFrom.Text = dt1.Rows(0)(0)
                        txtWidthTo.Text = dt1.Rows(0)(1)
                    End If
                End If
                objController.LoadColumnNameForSPMCoilDetailLabView(clbParamTest, Session("ColumnName"))
                btnOk_Click(Nothing, Nothing)

            End If

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub ddlGrade_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlGrade.SelectedIndexChanged
        Try

            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value

            If ddlGrade.SelectedItem.Text.ToLower = "all" Then
                hfThickness.Value = ""
                hfWidth.Value = ""
                hfCoil.Value = ""
                objController.PopulateTdcForSPM(ddlTdc, fromDt, toDt, "")
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
                txtFromThickness.Text = dt.Rows(0)(0)
                txtToThickness.Text = dt.Rows(0)(1)
                If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                    dt1 = objController.PopulateWidthForSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                    txtWidthFrom.Text = dt1.Rows(0)(0)
                    txtWidthTo.Text = dt1.Rows(0)(1)
                End If
            Else
                objController.PopulateTdcForSPM(ddlTdc, fromDt, toDt, ddlGrade.SelectedItem.Text)
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
                txtFromThickness.Text = dt.Rows(0)(0)
                txtToThickness.Text = dt.Rows(0)(1)
                If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                    dt1 = objController.PopulateWidthForSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                    txtWidthFrom.Text = dt1.Rows(0)(0)
                    txtWidthTo.Text = dt1.Rows(0)(1)
                End If
            End If
            'processThickness()
            btnOk_Click(sender, e)

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub txtFromThickness_TextChanged(sender As Object, e As EventArgs) Handles txtFromThickness.TextChanged
        Try
            btnOk_Click(sender, e)
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub txtToThickness_TextChanged(sender As Object, e As EventArgs) Handles txtToThickness.TextChanged
        Try
            btnOk_Click(sender, e)
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub txtWidthFrom_TextChanged(sender As Object, e As EventArgs) Handles txtWidthFrom.TextChanged
        Try
            btnOk_Click(sender, e)
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub txtWidthTo_TextChanged(sender As Object, e As EventArgs) Handles txtWidthTo.TextChanged
        Try
            btnOk_Click(sender, e)
        Catch ex As Exception

        End Try

    End Sub


    Protected Sub ddlTdc_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlTdc.SelectedIndexChanged
        Try

            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value

            If ddlTdc.SelectedItem.Text.ToLower = "all" Then
                hfThickness.Value = ""
                hfWidth.Value = ""
                hfCoil.Value = ""

                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForSPMDetailAnalysis(fromDt, toDt, "", "")
                If dt.Rows.Count > 0 AndAlso Not IsDBNull(dt.Rows(0)(0)) Then
                    txtFromThickness.Text = dt.Rows(0)(0)
                    txtToThickness.Text = dt.Rows(0)(1)
                    If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                        dt1 = objController.PopulateWidthForSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                        txtWidthFrom.Text = dt1.Rows(0)(0)
                        txtWidthTo.Text = dt1.Rows(0)(1)
                    End If
                End If
                objController.LoadColumnNameForSPMCoilDetailLabView(clbParamTest, Session("ColumnName"))
                Return
            Else
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
                txtFromThickness.Text = dt.Rows(0)(0)
                txtToThickness.Text = dt.Rows(0)(1)
                If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                    dt1 = objController.PopulateWidthForSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                    txtWidthFrom.Text = dt1.Rows(0)(0)
                    txtWidthTo.Text = dt1.Rows(0)(1)
                End If

            End If
            'processThickness()
            btnOk_Click(sender, e)

        Catch ex As Exception

        End Try
    End Sub
End Class
