﻿Imports System.Data
Imports System.IO
Imports System.Web.Services
Imports System.Data.SqlClient

Partial Class spmdetailanalysis
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try

                Dim p As String = Request("__EVENTARGUMENT")
                If (p = "thickness") Then
                    'processThickness()
                ElseIf p = "width" Then
                    'processWidth()
                ElseIf p = "date" Then
                    txtDate_TextChanged()
                End If

            Catch ex As Exception

            End Try
        End If
        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-5).ToString("yyyy-MM-dd HH:mm")
                'Dim dtStart As DateTime = DateTime.Now.AddMonths(-6).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                objController.PopulateGradeForSPM(ddlGrade, dtStart, dtEnd)
                objController.PopulateTdcForSPM(ddlTdc, dtStart, dtEnd, "")
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForSPMDetailAnalysis(dtStart, dtEnd, "", "")
                If dt.Rows.Count > 0 AndAlso Not IsDBNull(dt.Rows(0)(0)) Then
                    txtFromThickness.Text = dt.Rows(0)(0)
                    txtToThickness.Text = dt.Rows(0)(1)

                    If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                        dt1 = objController.PopulateWidthForSPMDetailAnalysis(dtStart, dtEnd, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                        txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0) * 1000, 0)
                        txtWidthTo.Text = Math.Round(dt1.Rows(0)(1) * 1000, 0)
                    End If
                End If




                Dim filter As String = " 1=1"

                objController.PopulateCoilIdForSPMDetailAnalysis(clbcoilid, dtStart, dtEnd, filter)
                objController.LoadColumnNameForSPMProcessDataCoilWiseNew(clbParamTest, "")

                'objController.LoadColumnNameForSPMDetailAnalysis(clbParamTest, "")

            Catch ex As Exception

            End Try
        End If
    End Sub


    Protected Sub btnOk_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnOk.Click
        Try

            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            Dim str1 As String = ""
            If clbcoilid.Items.Count > 0 Then
                Dim count As Integer = 0
                Dim appendString = ""
                For i As Integer = 0 To clbParamTest.Items.Count - 1
                    If clbParamTest.Items(i).Selected Then
                        count += 1
                        str1 &= "," & clbParamTest.Items(i).Value
                        Dim ChartTitle As String = ""
                        If clbParamTest.Items(i).Text = "Rollforce" Then
                            ChartTitle = "Rollforce (SKU past data (Yellow- Minimum, Red- Maximum, Green- Average))"

                        Else
                            ChartTitle = clbParamTest.Items(i).Text
                        End If
                        Dim spanClass As String = ""
                        If clbParamTest.Items(i).Value.ToUpper = "ENLONGATION_ACT" Then
                            spanClass = "crmis_span"
                        End If
                        appendString &= "<div class='col-md-12'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>" & ChartTitle & "</h3> <span class='" & spanClass & "'></span></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='" & clbParamTest.Items(i).Value & "' style='height: 200px;'></div></div></div></div>"


                    End If
                Next
                divHolder.InnerHtml = appendString
                If str1 = "" Then

                Else
                    str1 = str1.Substring(1)

                    Dim filter As String = ""
                    For j As Integer = 0 To clbcoilid.Items.Count - 1
                        If clbcoilid.Items(j).Selected Then
                            filter &= "," & clbcoilid.Items(j).Value
                        End If

                    Next
                    If filter.Length > 0 Then
                        filter = filter.Substring(1)
                        'If rdbtnDatewise.Checked = True Then
                        DrawChartTop(str1, fromDt, toDt, filter)
                        'Else
                        'DrawChartTop1(str1, fromDt, toDt, filter)
                        'End If

                    End If

                End If
            End If


        Catch ex As Exception

        End Try

    End Sub

    Sub DrawChartTop(ByVal ColumnName As String, ByVal FromDt As String, ByVal ToDt As String, ByVal Filter As String)
        Try

            Dim strfrmDt As String = FromDt
            Dim strToDt As String = ToDt
            Dim al() As String = Filter.Split(",")
            Dim dt As New DataTable
            For j As Integer = 0 To al.Length - 1
                dt.Merge(objController.GetSPMProcessDataDetailAnalysis("CRM_SPM_PROCESS_DATA_COILWISE_BODY", al(j)))
            Next
            Dim SelectedValues = dt.AsEnumerable().Where(Function(s) s.Field(Of String)("ELONGATION_SET_ORA") <> "").Select(Function(s) s.Field(Of String)("ELONGATION_SET_ORA")).ToArray()
            Dim csv As String = String.Join(",", SelectedValues)

            For c As Integer = 0 To dt.Columns.Count - 1
                If dt.Columns(c).ColumnName = "Coil Thickness" Then
                    dt.Columns(c).ColumnName = "Thickness"
                End If
                If dt.Columns(c).ColumnName = "Coil Width" Then
                    dt.Columns(c).ColumnName = "Width"
                End If
            Next
            Dim coilid = dt.Rows(0)("Coil_Id")
            For k As Integer = 0 To dt.Rows.Count - 1

                If k > 0 Then
                    If IsDBNull(dt.Rows(k)("Coil_Id")) Then
                        dt.Rows(k)("Coil_Id") = coilid
                    Else
                        coilid = dt.Rows(k)("Coil_Id")
                    End If
                End If

            Next
            Dim dtUnit As DataTable = objController.GetUnitForSPM("UNIT_DETAILS", ColumnName)
            Dim a() As String = ColumnName.Split(",")
            Dim l As Literal
            Dim unit(a.Length) As String
            Dim multiplier As String = "1.0"
            For i As Integer = 0 To UBound(a)
                Dim literals = Page.Master.FindControl("content_body").Controls.OfType(Of Literal)()
                For Each lit In literals
                    If (lit.ID = "Lit" & i + 1) Then
                        l = lit
                        Exit For
                    End If
                Next

                Dim c As String = a(i)

                Dim row() As DataRow = dtUnit.Select("PARAMETER_NAME='" & c & "'")
                If row.Length > 0 Then
                    multiplier = row(0)(1)
                    unit(i) = row(0)(2)
                    ' multiplier.Replace("THICKNESS", "Convert(Thickness,System.Double)").Replace("WIDTH", "Convert(Width,System.Double)")
                Else
                    multiplier = "1.0"
                End If

                Dim index As Integer = 0

                Dim isDerived As Boolean = False
                Dim containerName As String = a(i)
                If a(i).StartsWith("UNIT_") Then
                    isDerived = True
                    a(i) = a(i).Replace("UNIT_", "")
                End If

                If a(i) = "C00_COILER_SPEED_ACT" Then
                    index = 5
                ElseIf a(i) = "S11_SPEED_ACT" Then
                    index = 6
                ElseIf a(i) = "C90_COILER_SPEED_ACT" Then
                    index = 7
                    'ElseIf a(i) = "ENLONGATION_SET" Then
                    '    index = 8
                ElseIf a(i) = "ENLONGATION_ACT" Then
                    hfElonOra.Value = " CRMIS Set Value: " & csv
                    index = 9
                ElseIf a(i) = "ROLLFORCE" Then
                    index = 10
                ElseIf a(i) = "ROLLFORCE_DS" Then
                    index = 11
                ElseIf a(i) = "ROLLFORCE_OS" Then
                    index = 12
                ElseIf a(i) = "WORK_ROLL_BEND_POS_SET" Then
                    index = 13
                ElseIf a(i) = "WORK_ROLL_BEND_POS_ACT" Then
                    index = 14
                ElseIf a(i) = "WORK_ROLL_BEND_NEG_SET" Then
                    index = 15
                ElseIf a(i) = "WORK_ROLL_BEND_NEG_ACT" Then
                    index = 16
                ElseIf a(i) = "ROLL_GAP_DS" Then
                    index = 17
                ElseIf a(i) = "ROLL_GAP_OS" Then
                    index = 18
                ElseIf a(i) = "TENSION_POR_ENTRY_REF" Then
                    index = 19
                ElseIf a(i) = "TENSION_POR_ENTRY" Then
                    index = 20
                ElseIf a(i) = "TENSION_TR_REF" Then
                    index = 21
                ElseIf a(i) = "TENSION_TR" Then
                    index = 22


                End If
                Dim cname = dt.Columns(index - 1).ColumnName
                Dim newcname = cname
                If isDerived Then
                    newcname = "UNIT_" & cname
                End If
                dt.Columns.Add("[" & newcname & "_C]", GetType(Double), " Convert([" & cname & "],System.Double)" & "*" & multiplier)
                'If newcname = "Work_Roll_bend_Neg_Set" Then
                '    objController.PlotLineChartForSPMDetailAnalysis1(dt, "[" & newcname & "_C]", l, containerName, "plot" & i + 1, "", unit(i), "Coil_Id")
                'Else
                objController.PlotLineChartForSPMDetailAnalysis(dt, "[" & newcname & "_C]", l, containerName, "plot" & i + 1, "", unit(i), "Coil_Id", a(i))
                'End If

                divHolder.Attributes.Add("style", "display:block")

            Next




        Catch ex As Exception

        End Try
    End Sub

    'Sub DrawChartTop1(ByVal ColumnName As String, ByVal FromDt As String, ByVal ToDt As String, ByVal Filter As String)
    '    Try

    '        Dim strfrmDt As String = FromDt
    '        Dim strToDt As String = ToDt
    '        Dim al() As String = Filter.Split(",")
    '        Dim dt As New DataTable
    '        For j As Integer = 0 To al.Length - 1
    '            dt.Merge(objController.GetSPMProcessDataDetailAnalysisCoilwise("CRM_SPM_PROCESS_DATA_COILWISE_BODY", al(j)))
    '        Next
    '        For c As Integer = 0 To dt.Columns.Count - 1
    '            If dt.Columns(c).ColumnName = "Coil Thickness" Then
    '                dt.Columns(c).ColumnName = "Thickness"
    '            End If
    '            If dt.Columns(c).ColumnName = "Coil Width" Then
    '                dt.Columns(c).ColumnName = "Width"
    '            End If
    '        Next
    '        Dim coilid = dt.Rows(0)("Coil_Id")
    '        For k As Integer = 0 To dt.Rows.Count - 1

    '            If k > 0 Then
    '                If IsDBNull(dt.Rows(k)("Coil_Id")) Then
    '                    dt.Rows(k)("Coil_Id") = coilid
    '                Else
    '                    coilid = dt.Rows(k)("Coil_Id")
    '                End If
    '            End If

    '        Next
    '        Dim dtUnit As DataTable = objController.GetUnitForSPM("UNIT_DETAILS", ColumnName)
    '        Dim a() As String = ColumnName.Split(",")
    '        Dim l As Literal
    '        Dim unit(a.Length) As String
    '        Dim multiplier As String = "1.0"
    '        For i As Integer = 0 To UBound(a)
    '            Dim literals = Page.Master.FindControl("content_body").Controls.OfType(Of Literal)()
    '            For Each lit In literals
    '                If (lit.ID = "Lit" & i + 1) Then
    '                    l = lit
    '                    Exit For
    '                End If
    '            Next

    '            Dim c As String = a(i)

    '            Dim row() As DataRow = dtUnit.Select("PARAMETER_NAME='" & c & "'")
    '            If row.Length > 0 Then
    '                multiplier = row(0)(1)
    '                unit(i) = row(0)(2)
    '                ' multiplier.Replace("THICKNESS", "Convert(Thickness,System.Double)").Replace("WIDTH", "Convert(Width,System.Double)")
    '            Else
    '                multiplier = "1.0"
    '            End If

    '            Dim index As Integer = 0

    '            Dim isDerived As Boolean = False
    '            Dim containerName As String = a(i)
    '            If a(i).StartsWith("UNIT_") Then
    '                isDerived = True
    '                a(i) = a(i).Replace("UNIT_", "")
    '            End If

    '            If a(i) = "C00_COILER_SPEED_ACT" Then
    '                index = 5
    '            ElseIf a(i) = "S11_SPEED_ACT" Then
    '                index = 6
    '            ElseIf a(i) = "C90_COILER_SPEED_ACT" Then
    '                index = 7
    '                'ElseIf a(i) = "ENLONGATION_SET" Then
    '                '    index = 8
    '            ElseIf a(i) = "ENLONGATION_ACT" Then
    '                index = 9
    '            ElseIf a(i) = "ROLLFORCE" Then
    '                index = 10
    '            ElseIf a(i) = "ROLLFORCE_DS" Then
    '                index = 11
    '            ElseIf a(i) = "ROLLFORCE_OS" Then
    '                index = 12
    '            ElseIf a(i) = "WORK_ROLL_BEND_POS_SET" Then
    '                index = 13
    '            ElseIf a(i) = "WORK_ROLL_BEND_POS_ACT" Then
    '                index = 14
    '            ElseIf a(i) = "WORK_ROLL_BEND_NEG_SET" Then
    '                index = 15
    '            ElseIf a(i) = "WORK_ROLL_BEND_NEG_ACT" Then
    '                index = 16
    '            ElseIf a(i) = "ROLL_GAP_DS" Then
    '                index = 17
    '            ElseIf a(i) = "ROLL_GAP_OS" Then
    '                index = 18
    '            ElseIf a(i) = "TENSION_POR_ENTRY_REF" Then
    '                index = 19
    '            ElseIf a(i) = "TENSION_POR_ENTRY" Then
    '                index = 20
    '            ElseIf a(i) = "TENSION_TR_REF" Then
    '                index = 21
    '            ElseIf a(i) = "TENSION_TR" Then
    '                index = 22


    '            End If
    '            Dim cname = dt.Columns(index - 1).ColumnName
    '            Dim newcname = cname
    '            If isDerived Then
    '                newcname = "UNIT_" & cname
    '            End If
    '            dt.Columns.Add("[" & newcname & "_C]", GetType(Double), " Convert([" & cname & "],System.Double)" & "*" & multiplier)

    '            objController.PlotLineChartForSPMDetailAnalysis(dt, "[" & newcname & "_C]", l, containerName, "plot" & i + 1, "", unit(i), "Coil_Id")
    '            divHolder.Attributes.Add("style", "display:block")

    '        Next




    '    Catch ex As Exception

    '    End Try
    'End Sub
    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try

            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            If (hfIsButton.Value = "false") Then

                objController.PopulateGradeForSPM(ddlGrade, dtStart, dtEnd)
                objController.PopulateTdcForSPM(ddlTdc, dtStart, dtEnd, "")
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForSPMDetailAnalysis(dtStart, dtEnd, "", "")
                If dt.Rows.Count > 0 AndAlso Not IsDBNull(dt.Rows(0)(0)) Then
                    txtFromThickness.Text = dt.Rows(0)(0)
                    txtToThickness.Text = dt.Rows(0)(1)
                    If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                        dt1 = objController.PopulateWidthForSPMDetailAnalysis(dtStart, dtEnd, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                        txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0) * 1000, 0)
                        txtWidthTo.Text = Math.Round(dt1.Rows(0)(1) * 1000, 0)
                    End If
                End If
                Dim filter As String = " 1=1"
                If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
                    filter &= " and GRADE = '" & ddlGrade.SelectedItem.Text & "'"
                End If
                If ddlTdc.SelectedItem.Text.ToLower <> "all" Then
                    filter &= " and TDC_No = '" & ddlTdc.SelectedItem.Text & "'"
                End If
                If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                    filter &= " and THICKNESS between " & txtFromThickness.Text & " and " & txtToThickness.Text & ""
                    'divHolder.Attributes.Add("style", "display:none")
                End If
                If txtWidthFrom.Text <> "" And txtWidthTo.Text <> "" Then
                    filter &= " and WIDTH between " & txtWidthFrom.Text / 1000 & " and " & txtWidthTo.Text / 1000 & ""

                End If
                objController.PopulateCoilIdForSPMDetailAnalysis(clbcoilid, dtStart, dtEnd, filter)
                objController.LoadColumnNameForSPMProcessDataCoilWiseNew(clbParamTest, "")

                divHolder.Attributes.Add("style", "display:none")
            End If

        Catch ex As Exception

        End Try

    End Sub


    Protected Sub ddlGrade_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlGrade.SelectedIndexChanged
        Try

            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value

            If ddlGrade.SelectedItem.Text.ToLower = "all" Then
                'hfThickness.Value = ""
                'hfWidth.Value = ""
                'hfCoil.Value = ""
                objController.PopulateTdcForSPM(ddlTdc, fromDt, toDt, "")
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
                txtFromThickness.Text = dt.Rows(0)(0)
                txtToThickness.Text = dt.Rows(0)(1)
                If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                    dt1 = objController.PopulateWidthForSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                    txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0) * 1000, 0)
                    txtWidthTo.Text = Math.Round(dt1.Rows(0)(1) * 1000, 0)
                End If

            Else
                objController.PopulateTdcForSPM(ddlTdc, fromDt, toDt, ddlGrade.SelectedItem.Text)
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
                txtFromThickness.Text = dt.Rows(0)(0)
                txtToThickness.Text = dt.Rows(0)(1)
                If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                    dt1 = objController.PopulateWidthForSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                    txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0) * 1000, 0)
                    txtWidthTo.Text = Math.Round(dt1.Rows(0)(1) * 1000, 0)
                End If
            End If
            'processThickness()
            btnGo_Click(sender, e)
            divHolder.Attributes.Add("style", "display:none")

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnGo_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnGo.Click
        Try

            Dim dtStart As String = hfFrom.Value
            Dim dtEnd As String = hfTo.Value
            Dim filter As String = " 1=1"
            If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
                filter &= " and GRADE = '" & ddlGrade.SelectedItem.Text & "'"
            End If
            If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                filter &= " and THICKNESS between " & txtFromThickness.Text & " and " & txtToThickness.Text & ""
                'divHolder.Attributes.Add("style", "display:none")
            End If
            If txtWidthFrom.Text <> "" And txtWidthTo.Text <> "" Then
                filter &= " and WIDTH between " & txtWidthFrom.Text / 1000 & " and " & txtWidthTo.Text / 1000 & ""
            End If
            objController.PopulateCoilIdForSPMDetailAnalysis(clbcoilid, dtStart, dtEnd, filter)
            objController.LoadColumnNameForSPMProcessDataCoilWiseNew(clbParamTest, "")

        Catch ex As Exception

        End Try

    End Sub

    Protected Sub txtFromThickness_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtFromThickness.TextChanged
        Try
            btnGo_Click(Nothing, Nothing)
            divHolder.Attributes.Add("style", "display:none")
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub txtToThickness_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtToThickness.TextChanged
        Try
            btnGo_Click(Nothing, Nothing)
            divHolder.Attributes.Add("style", "display:none")
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub txtWidthFrom_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtWidthFrom.TextChanged
        Try
            btnGo_Click(Nothing, Nothing)
            divHolder.Attributes.Add("style", "display:none")
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub txtWidthTo_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtWidthTo.TextChanged
        Try
            btnGo_Click(Nothing, Nothing)
            divHolder.Attributes.Add("style", "display:none")
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub ddlTdc_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlTdc.SelectedIndexChanged
        Try

            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value


            If ddlTdc.SelectedItem.Text.ToLower = "all" Then
                hfThickness.Value = ""
                hfWidth.Value = ""
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForSPMDetailAnalysis(fromDt, toDt, "", "")
                If dt.Rows.Count > 0 AndAlso Not IsDBNull(dt.Rows(0)(0)) Then
                    txtFromThickness.Text = dt.Rows(0)(0)
                    txtToThickness.Text = dt.Rows(0)(1)
                    If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                        dt1 = objController.PopulateWidthForSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                        txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0) * 1000, 0)
                        txtWidthTo.Text = Math.Round(dt1.Rows(0)(1) * 1000, 0)
                    End If
                End If
                objController.PopulateCoilIdForSPMDetailAnalysis(clbcoilid, fromDt, toDt, " 1=1")

                divHolder.Attributes.Add("style", "display:none")
                objController.LoadColumnNameForSPMProcessDataCoilWiseNew(clbParamTest, "")
                'txtFromThickness.Text = ""
                'txtToThickness.Text = ""
                'txtWidthFrom.Text = ""
                'txtWidthTo.Text = ""
                Return
            Else
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
                If dt.Rows.Count > 0 AndAlso Not IsDBNull(dt.Rows(0)(0)) Then
                    txtFromThickness.Text = dt.Rows(0)(0)
                    txtToThickness.Text = dt.Rows(0)(1)
                    If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                        dt1 = objController.PopulateWidthForSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                        txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0) * 1000, 0)
                        txtWidthTo.Text = Math.Round(dt1.Rows(0)(1) * 1000, 0)
                    End If
                End If

            End If
            btnGo_Click(Nothing, Nothing)
            divHolder.Attributes.Add("style", "display:none")

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub rdbtnCoilwise_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles rdbtnCoilwise.CheckedChanged
        Try

            txtCoilwise.Enabled = True
            Panel1.Enabled = False
            ddlGrade.Enabled = False
            ddlTdc.Enabled = False
            txtFromThickness.Enabled = False
            txtToThickness.Enabled = False
            txtWidthFrom.Enabled = False
            txtWidthTo.Enabled = False
            clbcoilid.Items.Clear()
            objController.LoadColumnNameForSPMProcessDataCoilWiseNew(clbParamTest, "")
            divHolder.Attributes.Add("style", "display:none")

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub rdbtnDatewise_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles rdbtnDatewise.CheckedChanged
        Try

            txtCoilwise.Text = ""
            txtCoilwise.Enabled = False
            Panel1.Enabled = True
            ddlGrade.Enabled = True
            ddlTdc.Enabled = True
            txtFromThickness.Enabled = True
            txtToThickness.Enabled = True
            txtWidthFrom.Enabled = True
            txtWidthTo.Enabled = True
            divHolder.Attributes.Add("style", "display:none")
            hfIsButton.Value = "false"
            txtDate_TextChanged()

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub txtCoilwise_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtCoilwise.TextChanged
        Try

            'objController.PopulateCoilIdForSPMDetailAnalysisCoilwise(clbcoilid, txtCoilwise.Text)
            objController.PopulateCoilIdForSPMDetailAnalysisCoilwise(clbcoilid, txtCoilwise.Text.Substring(0, 6))
            objController.LoadColumnNameForSPMProcessDataCoilWiseNew(clbParamTest, "")
            divHolder.Attributes.Add("style", "display:none")

        Catch ex As Exception

        End Try

    End Sub


    <WebMethod()>
    Public Shared Function GetAutoCompleteData(ByVal username As String) As List(Of String)
        Dim result As List(Of String) = New List(Of String)()

        Using con As SqlConnection = New SqlConnection("server=176.0.0.60\LPTGSQLDEV;database=FP_PROCESS_DATA;uid=153521;pwd=Welcome@135")

            Using cmd As SqlCommand = New SqlCommand("select top 10 DAUGHTER_COILID_NUM from CRM_SPM_PROCESS_DATA_COILWISE_BODY where DAUGHTER_COILID_NUM LIKE '%'+@SearchText+'%'", con)
                con.Open()
                cmd.Parameters.AddWithValue("@SearchText", username)
                Dim dr As SqlDataReader = cmd.ExecuteReader()

                While dr.Read()
                    result.Add(String.Format("{0}", dr("DAUGHTER_COILID_NUM")))
                End While

                Return result
            End Using
        End Using
    End Function
End Class
