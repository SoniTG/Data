﻿Imports System.Data
Imports System.IO
Partial Class spmdetailanalysis_Old
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Dim p As String = Request("__EVENTARGUMENT")
            If (p = "thickness") Then
                'processThickness()
            ElseIf p = "width" Then
                'processWidth()
            ElseIf p = "date" Then
                txtDate_TextChanged()
            End If
        End If
        If Not Page.IsPostBack Then
            Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
            Dim dtStart As String = DateTime.Now.AddDays(-5).ToString("yyyy-MM-dd HH:mm")
            'Dim dtStart As DateTime = DateTime.Now.AddMonths(-6).ToString("yyyy-MM-dd HH:mm")
            Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
            objController.PopulateGradeForSPM(ddlGrade, dtStart, dtEnd)
            objController.PopulateTdcForSPM(ddlTdc, dtStart, dtEnd, "")
            Dim dt, dt1 As DataTable
            dt = objController.PopulateThicknessForSPMDetailAnalysis(dtStart, dtEnd, "", "")
            If dt.Rows.Count > 0 AndAlso Not IsDBNull(dt.Rows(0)(0)) Then
                txtFromThickness.Text = dt.Rows(0)(0)
                txtToThickness.Text = dt.Rows(0)(1)
                If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                    dt1 = objController.PopulateWidthForSPMDetailAnalysis(dtStart, dtEnd, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                    txtWidthFrom.Text = dt1.Rows(0)(0)
                    txtWidthTo.Text = dt1.Rows(0)(1)
                End If
            End If




            Dim filter As String = " 1=1"

            objController.PopulateCoilIdForSPMDetailAnalysis(clbcoilid, dtStart, dtEnd, filter)
            objController.LoadColumnNameForSPMProcessDataCoilWise(clbParamTest, "")



        End If
    End Sub


    Protected Sub btnOk_Click(sender As Object, e As EventArgs) Handles btnOk.Click
        Dim fromDt As String = hfFrom.Value
        Dim toDt As String = hfTo.Value
        Dim str1 As String = ""
        If clbcoilid.Items.Count > 0 Then
            Dim count As Integer = 0
            Dim appendString = ""
            For i As Integer = 0 To clbParamTest.Items.Count - 1
                If clbParamTest.Items(i).Selected Then
                    count += 1
                    str1 &= "," & clbParamTest.Items(i).Value

                    appendString &= "<div class='col-md-12'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>" & clbParamTest.Items(i).Text & "</h3> <span></span></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='" & clbParamTest.Items(i).Value & "' style='height: 200px;'></div></div></div></div>"


                End If
            Next
            divHolder.InnerHtml = appendString
            If str1 = "" Then

            Else
                str1 = str1.Substring(1)

                Dim filter As String = ""
                For j As Integer = 0 To clbcoilid.Items.Count - 1
                    If clbcoilid.Items(j).Selected Then
                        filter &= "," & clbcoilid.Items(j).Value
                    End If

                Next
                If filter.Length > 0 Then
                    filter = filter.Substring(1)

                    DrawChartTop(str1, fromDt, toDt, filter)
                End If

            End If
        End If


    End Sub

    Sub DrawChartTop(ByVal ColumnName As String, ByVal FromDt As String, ByVal ToDt As String, ByVal Filter As String)
        Try

            Dim strfrmDt As String = FromDt
            Dim strToDt As String = ToDt
            Dim al() As String = Filter.Split(",")
            Dim dt As New DataTable
            For j As Integer = 0 To al.Length - 1
                dt.Merge(objController.GetSPMProcessDataDetailAnalysis("CRM_SPM_PROCESS_DATA_COILWISE_BODY", al(j)))
            Next
            For c As Integer = 0 To dt.Columns.Count - 1
                If dt.Columns(c).ColumnName = "Coil Thickness" Then
                    dt.Columns(c).ColumnName = "Thickness"
                End If
                If dt.Columns(c).ColumnName = "Coil Width" Then
                    dt.Columns(c).ColumnName = "Width"
                End If
            Next
            Dim coilid = dt.Rows(0)("Coil_Id")
            For k As Integer = 0 To dt.Rows.Count - 1

                If k > 0 Then
                    If IsDBNull(dt.Rows(k)("Coil_Id")) Then
                        dt.Rows(k)("Coil_Id") = coilid
                    Else
                        coilid = dt.Rows(k)("Coil_Id")
                    End If
                End If

            Next
            Dim dtUnit As DataTable = objController.GetUnitForSPM("UNIT_DETAILS", ColumnName)
            Dim a() As String = ColumnName.Split(",")
            Dim l As Literal
            Dim unit(a.Length) As String
            Dim multiplier As String = "1.0"
            For i As Integer = 0 To UBound(a)
                Dim literals = Page.Master.FindControl("content_body").Controls.OfType(Of Literal)()
                For Each lit In literals
                    If (lit.ID = "Lit" & i + 1) Then
                        l = lit
                        Exit For
                    End If
                Next

                Dim c As String = a(i)

                Dim row() As DataRow = dtUnit.Select("PARAMETER_NAME='" & c & "'")
                If row.Length > 0 Then
                    multiplier = row(0)(1)
                    unit(i) = row(0)(2)
                    ' multiplier.Replace("THICKNESS", "Convert(Thickness,System.Double)").Replace("WIDTH", "Convert(Width,System.Double)")
                Else
                    multiplier = "1.0"
                End If

                Dim index As Integer = 0

                Dim isDerived As Boolean = False
                Dim containerName As String = a(i)
                If a(i).StartsWith("UNIT_") Then
                    isDerived = True
                    a(i) = a(i).Replace("UNIT_", "")
                End If

                If a(i) = "C00_COILER_SPEED_ACT" Then
                    index = 5
                ElseIf a(i) = "S11_SPEED_ACT" Then
                    index = 6
                ElseIf a(i) = "C90_COILER_SPEED_ACT" Then
                    index = 7
                    'ElseIf a(i) = "ENLONGATION_SET" Then
                    '    index = 8
                ElseIf a(i) = "ENLONGATION_ACT" Then
                    index = 9
                ElseIf a(i) = "ROLLFORCE" Then
                    index = 10
                ElseIf a(i) = "ROLLFORCE_DS" Then
                    index = 11
                ElseIf a(i) = "ROLLFORCE_OS" Then
                    index = 12
                ElseIf a(i) = "WORK_ROLL_BEND_POS_SET" Then
                    index = 13
                ElseIf a(i) = "WORK_ROLL_BEND_POS_ACT" Then
                    index = 14
                ElseIf a(i) = "WORK_ROLL_BEND_NEG_SET" Then
                    index = 15
                ElseIf a(i) = "WORK_ROLL_BEND_NEG_ACT" Then
                    index = 16
                ElseIf a(i) = "ROLL_GAP_DS" Then
                    index = 17
                ElseIf a(i) = "ROLL_GAP_OS" Then
                    index = 18
                ElseIf a(i) = "TENSION_POR_ENTRY_REF" Then
                    index = 19
                ElseIf a(i) = "TENSION_POR_ENTRY" Then
                    index = 20
                ElseIf a(i) = "TENSION_TR_REF" Then
                    index = 21
                ElseIf a(i) = "TENSION_TR" Then
                    index = 22


                End If
                Dim cname = dt.Columns(index - 1).ColumnName
                Dim newcname = cname
                If isDerived Then
                    newcname = "UNIT_" & cname
                End If
                dt.Columns.Add("[" & newcname & "_C]", GetType(Double), " Convert([" & cname & "],System.Double)" & "*" & multiplier)

                objController.PlotLineChartForSPMDetailAnalysis(dt, "[" & newcname & "_C]", l, containerName, "plot" & i + 1, "", unit(i), "Coil_Id")
                divHolder.Attributes.Add("style", "display:block")

            Next




        Catch ex As Exception

        End Try
    End Sub

    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged

        Dim dtStart As String = hfFrom.Value
        Dim dtEnd As String = hfTo.Value
        If (hfIsButton.Value = "false") Then

            objController.PopulateGradeForSPM(ddlGrade, dtStart, dtEnd)
            objController.PopulateTdcForSPM(ddlTdc, dtStart, dtEnd, "")
            Dim dt, dt1 As DataTable
            dt = objController.PopulateThicknessForSPMDetailAnalysis(dtStart, dtEnd, "", "")
            If dt.Rows.Count > 0 AndAlso Not IsDBNull(dt.Rows(0)(0)) Then
                txtFromThickness.Text = dt.Rows(0)(0)
                txtToThickness.Text = dt.Rows(0)(1)
                If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                    dt1 = objController.PopulateWidthForSPMDetailAnalysis(dtStart, dtEnd, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                    txtWidthFrom.Text = dt1.Rows(0)(0)
                    txtWidthTo.Text = dt1.Rows(0)(1)
                End If
            End If
            Dim filter As String = " 1=1"
            If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
                filter &= " and GRADE = '" & ddlGrade.SelectedItem.Text & "'"
            End If
            If ddlTdc.SelectedItem.Text.ToLower <> "all" Then
                filter &= " and TDC_No = '" & ddlTdc.SelectedItem.Text & "'"
            End If
            If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                filter &= " and THICKNESS between " & txtFromThickness.Text & " and " & txtToThickness.Text & ""
                'divHolder.Attributes.Add("style", "display:none")
            End If
            If txtWidthFrom.Text <> "" And txtWidthTo.Text <> "" Then
                filter &= " and WIDTH between " & txtWidthFrom.Text & " and " & txtWidthTo.Text & ""

            End If
            objController.PopulateCoilIdForSPMDetailAnalysis(clbcoilid, dtStart, dtEnd, filter)
            objController.LoadColumnNameForSPMProcessDataCoilWise(clbParamTest, "")

            divHolder.Attributes.Add("style", "display:none")
        End If


    End Sub


    Protected Sub ddlGrade_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlGrade.SelectedIndexChanged
        Dim fromDt As String = hfFrom.Value
        Dim toDt As String = hfTo.Value

        If ddlGrade.SelectedItem.Text.ToLower = "all" Then
            'hfThickness.Value = ""
            'hfWidth.Value = ""
            'hfCoil.Value = ""
            objController.PopulateTdcForSPM(ddlTdc, fromDt, toDt, "")
            Dim dt, dt1 As DataTable
            dt = objController.PopulateThicknessForSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
            txtFromThickness.Text = dt.Rows(0)(0)
            txtToThickness.Text = dt.Rows(0)(1)
            If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                dt1 = objController.PopulateWidthForSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                txtWidthFrom.Text = dt1.Rows(0)(0)
                txtWidthTo.Text = dt1.Rows(0)(1)
            End If

        Else
            objController.PopulateTdcForSPM(ddlTdc, fromDt, toDt, ddlGrade.SelectedItem.Text)
            Dim dt, dt1 As DataTable
            dt = objController.PopulateThicknessForSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
            txtFromThickness.Text = dt.Rows(0)(0)
            txtToThickness.Text = dt.Rows(0)(1)
            If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                dt1 = objController.PopulateWidthForSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                txtWidthFrom.Text = dt1.Rows(0)(0)
                txtWidthTo.Text = dt1.Rows(0)(1)
            End If
        End If
        'processThickness()
        btnGo_Click(sender, e)
        divHolder.Attributes.Add("style", "display:none")
    End Sub

    Protected Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click
        Dim dtStart As String = hfFrom.Value
        Dim dtEnd As String = hfTo.Value
        Dim filter As String = " 1=1"
        If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
            filter &= " and GRADE = '" & ddlGrade.SelectedItem.Text & "'"
        End If
        If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
            filter &= " and THICKNESS between " & txtFromThickness.Text & " and " & txtToThickness.Text & ""
            'divHolder.Attributes.Add("style", "display:none")
        End If
        If txtWidthFrom.Text <> "" And txtWidthTo.Text <> "" Then
            filter &= " and WIDTH between " & txtWidthFrom.Text & " and " & txtWidthTo.Text & ""
        End If
        objController.PopulateCoilIdForSPMDetailAnalysis(clbcoilid, dtStart, dtEnd, filter)
        objController.LoadColumnNameForSPMProcessDataCoilWise(clbParamTest, "")

    End Sub

    Protected Sub txtFromThickness_TextChanged(sender As Object, e As EventArgs) Handles txtFromThickness.TextChanged
        btnGo_Click(Nothing, Nothing)
        divHolder.Attributes.Add("style", "display:none")
    End Sub

    Protected Sub txtToThickness_TextChanged(sender As Object, e As EventArgs) Handles txtToThickness.TextChanged
        btnGo_Click(Nothing, Nothing)
        divHolder.Attributes.Add("style", "display:none")
    End Sub

    Protected Sub txtWidthFrom_TextChanged(sender As Object, e As EventArgs) Handles txtWidthFrom.TextChanged
        btnGo_Click(Nothing, Nothing)
        divHolder.Attributes.Add("style", "display:none")
    End Sub

    Protected Sub txtWidthTo_TextChanged(sender As Object, e As EventArgs) Handles txtWidthTo.TextChanged
        btnGo_Click(Nothing, Nothing)
        divHolder.Attributes.Add("style", "display:none")
    End Sub

    Protected Sub ddlTdc_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlTdc.SelectedIndexChanged
        Dim fromDt As String = hfFrom.Value
        Dim toDt As String = hfTo.Value


        If ddlTdc.SelectedItem.Text.ToLower = "all" Then
            hfThickness.Value = ""
            hfWidth.Value = ""
            Dim dt, dt1 As DataTable
            dt = objController.PopulateThicknessForSPMDetailAnalysis(fromDt, toDt, "", "")
            If dt.Rows.Count > 0 AndAlso Not IsDBNull(dt.Rows(0)(0)) Then
                txtFromThickness.Text = dt.Rows(0)(0)
                txtToThickness.Text = dt.Rows(0)(1)
                If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                    dt1 = objController.PopulateWidthForSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                    txtWidthFrom.Text = dt1.Rows(0)(0)
                    txtWidthTo.Text = dt1.Rows(0)(1)
                End If
            End If
            objController.PopulateCoilIdForSPMDetailAnalysis(clbcoilid, fromDt, toDt, " 1=1")

            divHolder.Attributes.Add("style", "display:none")
            objController.LoadColumnNameForSPMProcessDataCoilWise(clbParamTest, "")
            'txtFromThickness.Text = ""
            'txtToThickness.Text = ""
            'txtWidthFrom.Text = ""
            'txtWidthTo.Text = ""
            Return
        Else
            Dim dt, dt1 As DataTable
            dt = objController.PopulateThicknessForSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
            If dt.Rows.Count > 0 AndAlso Not IsDBNull(dt.Rows(0)(0)) Then
                txtFromThickness.Text = dt.Rows(0)(0)
                txtToThickness.Text = dt.Rows(0)(1)
                If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                    dt1 = objController.PopulateWidthForSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                    txtWidthFrom.Text = dt1.Rows(0)(0)
                    txtWidthTo.Text = dt1.Rows(0)(1)
                End If
            End If

        End If
        btnGo_Click(Nothing, Nothing)
        divHolder.Attributes.Add("style", "display:none")
    End Sub
End Class
