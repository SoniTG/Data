﻿Imports System.Data
Imports System.IO
Imports System.Data.OleDb
Partial Class spmdetailscoilwise
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Dim strConnectionString As String = ConfigurationManager.ConnectionStrings("ACPM_Ora").ConnectionString
    Dim Oleconnection_ora As New OleDbConnection(strConnectionString)
    Dim OleAdap As New OleDbDataAdapter
    Dim OleCom As New OleDbCommand
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            Try
                Dim p As String = Request("__EVENTARGUMENT")
                If (p = "thickness") Then
                    'processThickness()
                ElseIf p = "coil" Then
                    'processCoil()
                ElseIf p = "width" Then
                    'processWidth()
                ElseIf p = "txtdate" Then
                    txtDate_TextChanged()
                End If
            Catch ex As Exception

            End Try
        End If

        If gvCoilData1.Rows.Count > 0 Then
            gvCoilData1.UseAccessibleHeader = True
            gvCoilData1.HeaderRow.TableSection = TableRowSection.TableHeader
        End If




        If Not Page.IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                Dim dtStart As String = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm")
                'Dim dtStart As DateTime = DateTime.Now.AddMonths(-6).ToString("yyyy-MM-dd HH:mm")
                Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                objController.PopulateGradeForSPM(ddlGrade, dtStart, dtEnd)
                objController.PopulateTdcForSPM(ddlTdc, dtStart, dtEnd, "")
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForSPMDetailAnalysis(dtStart, dtEnd, "", "")
                If dt.Rows.Count > 0 AndAlso Not IsDBNull(dt.Rows(0)(0)) Then
                    txtFromThickness.Text = dt.Rows(0)(0)
                    txtToThickness.Text = dt.Rows(0)(1)
                    If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                        dt1 = objController.PopulateWidthForSPMDetailAnalysis(dtStart, dtEnd, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                        txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0) * 1000, 0)
                        txtWidthTo.Text = Math.Round(dt1.Rows(0)(1) * 1000, 0)
                    End If
                End If
                Dim filter As String = " 1=1"
                If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
                    filter &= " and T.GRADE = '" & ddlGrade.SelectedItem.Text & "'"
                End If
                If ddlTdc.SelectedItem.Text.ToLower <> "all" Then
                    filter &= " and TDC_No = '" & ddlTdc.SelectedItem.Text & "'"
                End If
                If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                    filter &= " and THICKNESS between " & txtFromThickness.Text & " and " & txtToThickness.Text & ""
                    'divHolder.Attributes.Add("style", "display:none")
                End If
                If txtWidthFrom.Text <> "" And txtWidthTo.Text <> "" Then
                    filter &= " and WIDTH between " & txtWidthFrom.Text / 1000 & " and " & txtWidthTo.Text / 1000 & ""
                End If
                Dim dt2 As DataTable = objController.PopulateCoilData(dtStart, dtEnd, filter)
                If dt2.Rows.Count > 0 Then
                    Session("SpmUsername") = ""
                    For row As Integer = 0 To dt2.Rows.Count - 1
                        ''oracle data
                        Dim YS1 As Double = GetData(dt2.Rows(row)("Coil ID"))
                        dt2.Rows(row)("YS Testing") = YS1
                    Next

                    gvCoilData1.DataSource = dt2
                    gvCoilData1.DataBind()
                    gvCoilData1.UseAccessibleHeader = True
                    gvCoilData1.HeaderRow.TableSection = TableRowSection.TableHeader
                    btnLogout.Visible = False
                    'objController.HideGridViewColumns(gvCoilData)
                End If
            Catch ex As Exception

            End Try
        End If
    End Sub

    Sub CloseConnection()
        Try
            If Oleconnection_ora.State <> ConnectionState.Closed Then
                Oleconnection_ora.Close()
            End If
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try

    End Sub
    Public Function Ora_selectquery(ByVal strselect As String) As OleDbDataAdapter
        Try
            OleCom.Connection = Oleconnection_ora
            OleCom.CommandText = strselect
            OleAdap.SelectCommand = OleCom

            Return OleAdap
        Catch ex As Exception

        End Try
       
    End Function
    Public Function GetData(ByVal CoilId As String) As Double
        Try

            Dim ds As New DataSet
            Dim dt As New DataTable
            Dim Rval As Double = 0
            CloseConnection()
            Oleconnection_ora.Open()
            dt.Clear()
            dt.Clear()
            Dim dt1 As New DataTable
            Dim OraQuery As String = "select LTR_TEST_VALUE from crmdba.T_lab_tst_res where  ltr_param_test='YS' and ltr_id_coil = '" & CoilId & "' and (LTR_ID_DECSN_BY in('126327','ARBIND','AMITBJ','JEETU','JPATRA','SATYAB','ANILKR') or LTR_ID_DECSN_BY is null)"
            Ora_selectquery(OraQuery)
            OleAdap.Fill(ds)
            dt = ds.Tables(0)



            If dt.Rows.Count = 0 OrElse IsDBNull(dt.Rows(0)(0)) Then
                OraQuery = "select LTRA_OLD_VALUE,LTRA_NEW_VALUE from crmdba.T_lab_tst_res_aud where ltra_id_coil = '" & CoilId & "' and  ltra_param_test='YS' and ltra_column_name = 'LTR_TEST_VALUE' and (LTRA_USERID in('126327','ARBIND','AMITBJ','JEETU','JPATRA','SATYAB','ANILKR') or LTRA_USERID is null) order by LTRA_TS_TEST desc"
                OleAdap.Fill(ds)

                dt1 = ds.Tables(0)
                If dt1.Rows.Count > 0 Then
                    Rval = dt1.Rows(0)(0)
                End If

                'If dt1.Rows.Count = 1 Then
                '    Rval = dt1.Rows(0)(0)
                'ElseIf dt1.Rows.Count > 1 Then
                '    If dt1.Rows(0)(" LTRA_OLD_VALUE") > 0 Then
                '        Rval = dt1.Rows(0)(0)
                '    Else
                '        Rval = dt1.Rows(0)(1)
                '    End If

                'End If
            Else
                Rval = dt.Rows(0)(0)
            End If

            Return Rval

        Catch ex As Exception

        End Try
    End Function
    Protected Sub btnOk_Click(sender As Object, e As EventArgs) Handles btnOk.Click
        Try

            Dim fromDt As String = hfFrom.Value
        Dim toDt As String = hfTo.Value
        Dim str1 As String = ""
        Dim count As Integer = 0
        Dim appendString = ""
        For i As Integer = 0 To clbParamTest.Items.Count - 1
            If clbParamTest.Items(i).Selected Then
                count += 1
                str1 &= "," & clbParamTest.Items(i).Value
                appendString &= "<div class='col-md-2'></div><div class='col-md-10'><div class='panel panel-default'><div class='panel-heading'><div class='panel-title-box'><h3>" & clbParamTest.Items(i).Text & "</h3> <span></span></div><ul class='panel-controls' style='margin-top: 2px;'><li><a href='#' class='panel-fullscreen'><span class='fa fa-expand'></span></a></li></ul></div><div class='panel-body padding-0'><div class='chart-holder' id='" & clbParamTest.Items(i).Value & "' style='height: 200px;'></div></div></div></div>"


            End If
        Next
        divHolder.InnerHtml = appendString
        If str1 = "" Then

        Else
            str1 = str1.Substring(1)
            'Dim filter As String = " 1=1"
            'If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
            '    filter &= " and GRADE = '" & ddlGrade.SelectedItem.Text & "'"
            'End If
            'If hfThickness.Value <> "" Then
            '    filter &= " and THICKNESS in (" & hfThickness.Value & ")"
            'End If
            'If hfWidth.Value <> "" Then
            '    filter &= " and WIDTH in (" & hfWidth.Value & ")"
            'End If
            'If hfCoil.Value <> "" Then
            '    filter &= " and DAUGHTER_COILID_NUM in ('" & hfCoil.Value.Replace(",", "','") & "')"
            'End If
            DrawChartTop(str1)
            End If
        Catch ex As Exception

        End Try
    End Sub

    Sub DrawChartTop(ByVal ColumnName As String)
        Try

          

            Dim dtUnit As DataTable = objController.GetUnitForSPM("UNIT_DETAILS", ColumnName)
            'Dim dt As DataTable = objController.GetDataForSPM("CRM_SPM_PROCESS_DATA_COILWISE_BODY", strfrmDt, strToDt, "COIL_STARTDATETIME", ColumnName, Filter)
            Dim dt As DataTable = objController.GetSPMProcessData("CRM_SPM_PROCESS_DATA_COILWISE_BODY", Session("CoilNo"), Session("CoilDate"))
            For c As Integer = 0 To dt.Columns.Count - 1
                If dt.Columns(c).ColumnName = "Coil Thickness" Then
                    dt.Columns(c).ColumnName = "Thickness"
                End If
                If dt.Columns(c).ColumnName = "Coil Width" Then
                    dt.Columns(c).ColumnName = "Width"
                End If
            Next
            'Dim yVal As String = ""
            Dim a() As String = ColumnName.Split(",")
            Dim l As Literal
            Dim unit(a.Length) As String
            Dim multiplier As String = "1.0"
            For i As Integer = 0 To UBound(a)
                Dim literals = Page.Master.FindControl("content_body").Controls.OfType(Of Literal)()
                For Each lit In literals
                    If (lit.ID = "Lit" & i + 1) Then
                        l = lit
                        Exit For
                    End If
                Next

                Dim c As String = a(i)

                Dim row() As DataRow = dtUnit.Select("PARAMETER_NAME='" & c & "'")
                If row.Length > 0 Then
                    multiplier = row(0)(1)
                    unit(i) = row(0)(2)
                Else
                    multiplier = "1.0"
                End If

                Dim index As Integer = 0
                Dim isDerived As Boolean = False
                Dim containerName As String = a(i)
                If a(i).StartsWith("UNIT_") Then
                    isDerived = True
                    a(i) = a(i).Replace("UNIT_", "")
                End If

                If a(i) = "C00_COILER_SPEED_ACT" Then
                    index = 5
                ElseIf a(i) = "S11_SPEED_ACT" Then
                    index = 6
                ElseIf a(i) = "C90_COILER_SPEED_ACT" Then
                    index = 7
                    'ElseIf a(i) = "ENLONGATION_SET" Then
                    '    index = 8
                ElseIf a(i) = "ENLONGATION_ACT" Then
                    index = 9
                ElseIf a(i) = "ROLLFORCE" Then
                    index = 10
                ElseIf a(i) = "ROLLFORCE_DS" Then
                    index = 11
                ElseIf a(i) = "ROLLFORCE_OS" Then
                    index = 12
                ElseIf a(i) = "WORK_ROLL_BEND_POS_SET" Then
                    index = 13
                ElseIf a(i) = "WORK_ROLL_BEND_POS_ACT" Then
                    index = 14
                ElseIf a(i) = "WORK_ROLL_BEND_NEG_SET" Then
                    index = 15
                ElseIf a(i) = "WORK_ROLL_BEND_NEG_ACT" Then
                    index = 16
                ElseIf a(i) = "ROLL_GAP_DS" Then
                    index = 17
                ElseIf a(i) = "ROLL_GAP_OS" Then
                    index = 18
                ElseIf a(i) = "TENSION_POR_ENTRY_REF" Then
                    index = 19
                ElseIf a(i) = "TENSION_POR_ENTRY" Then
                    index = 20
                ElseIf a(i) = "TENSION_TR_REF" Then
                    index = 21
                ElseIf a(i) = "TENSION_TR" Then
                    index = 22


                End If
                Dim cname = dt.Columns(index - 1).ColumnName
                Dim newcname = cname
                If isDerived Then
                    newcname = "UNIT_" & cname
                End If
                dt.Columns.Add("[" & newcname & "_C]", GetType(Double), " Convert([" & cname & "],System.Double)" & "*" & multiplier)

                ' Dim literal As Literal = CType(Me.Master.FindControl("Lit" & i + 1), Literal)
                'objController.PlotLineChartForSPM(dt, "COIL_STARTDATETIME", a(i), l, a(i), "plot" & i + 1, "", "", i)
                objController.PlotLineChartForSPMCoilWise(dt, "[" & newcname & "_C]", l, containerName, "plot" & i + 1, "", unit(i), i)
                'objController.PlotLineChartForSPMCoil(dt, "COIL_STARTDATETIME", a(i), l, a(i), "plot" & i + 1, "", "", "DAUGHTER_COILID_NUM")
            Next




        Catch ex As Exception

        End Try
    End Sub

    Protected Sub txtDate_TextChanged() 'Handles txtDate.TextChanged
        Try

        Dim dtStart As String = hfFrom.Value
        Dim dtEnd As String = hfTo.Value
        If (hfIsButton.Value = "false") Then
            'If ddlGrade.SelectedIndex > 0 And ddlTdc.SelectedIndex > 0 And ddlThickness.SelectedIndex > 0 Then
            objController.PopulateGradeForSPM(ddlGrade, dtStart, dtEnd)
            objController.PopulateTdcForSPM(ddlTdc, dtStart, dtEnd, "")
            Dim dt, dt1 As DataTable
            dt = objController.PopulateThicknessForSPMDetailAnalysis(dtStart, dtEnd, "", "")
            If dt.Rows.Count > 0 AndAlso Not IsDBNull(dt.Rows(0)(0)) Then
                txtFromThickness.Text = dt.Rows(0)(0)
                txtToThickness.Text = dt.Rows(0)(1)
                If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                    dt1 = objController.PopulateWidthForSPMDetailAnalysis(dtStart, dtEnd, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                    txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0) * 1000, 0)
                    txtWidthTo.Text = Math.Round(dt1.Rows(0)(1) * 1000, 0)
                End If
            End If
            'If objController.PopulateCoilData(dtStart, dtEnd, "").Rows.Count > 0 Then
            '    gvCoilData.DataSource = objController.PopulateCoilData(dtStart, dtEnd, "")
            '    gvCoilData.DataBind()
            '    objController.HideGridViewColumns(gvCoilData)
            'End If
            btnGo_Click(Nothing, Nothing)
            pnlParams.Attributes.Add("style", "display:none")
            divHolder.Attributes.Add("style", "display:none")
            'End If
            'btnOk_Click(sender, e)
        End If
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub ddlGrade_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlGrade.SelectedIndexChanged
        Try

            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value

            'ddlThickness_SelectedIndexChanged(sender, e)
            If ddlGrade.SelectedItem.Text.ToLower = "all" Then
                hfThickness.Value = ""
                hfWidth.Value = ""
                hfCoil.Value = ""
                'objController.PopulateThicknessForSPM(ddlThickness, fromDt, toDt, "")
                'objController.PopulateWidthForSPM(ddlWidth, fromDt, toDt, "", "")
                'objController.PopulateCoilIdForSPM(ddlCoilId, fromDt, toDt, "", "", "")
                objController.PopulateTdcForSPM(ddlTdc, fromDt, toDt, "")
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
                txtFromThickness.Text = dt.Rows(0)(0)
                txtToThickness.Text = dt.Rows(0)(1)
                If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                    dt1 = objController.PopulateWidthForSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                    txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0) * 1000, 0)
                    txtWidthTo.Text = Math.Round(dt1.Rows(0)(1) * 1000, 0)
                End If
            Else
                objController.PopulateTdcForSPM(ddlTdc, fromDt, toDt, ddlGrade.SelectedItem.Text)
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
                txtFromThickness.Text = dt.Rows(0)(0)
                txtToThickness.Text = dt.Rows(0)(1)
                If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                    dt1 = objController.PopulateWidthForSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                    txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0) * 1000, 0)
                    txtWidthTo.Text = Math.Round(dt1.Rows(0)(1) * 1000, 0)
                End If
            End If
            'processThickness()
            'btnOk_Click(sender, e)
            btnGo_Click(sender, e)

        Catch ex As Exception

        End Try
    End Sub


    'Sub processThickness()
    '    Dim hv As String = hfThickness.Value
    '    If hv.Length <> 0 Then
    '        Dim fromDt As String = hfFrom.Value
    '        Dim toDt As String = hfTo.Value
    '        objController.PopulateWidthForSPM(ddlWidth, fromDt, toDt, ddlGrade.SelectedItem.Text, hv)
    '        'btnOk_Click(Nothing, Nothing)
    '        Dim filter As String = " 1=1"
    '        If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
    '            filter &= " and GRADE = '" & ddlGrade.SelectedItem.Text & "'"
    '        End If
    '        If hfThickness.Value <> "" Then
    '            filter &= " and THICKNESS in (" & hfThickness.Value & ")"
    '        End If
    '        'If hfWidth.Value <> "" Then
    '        '    filter &= " and WIDTH in (" & hfWidth.Value & ")"
    '        'End If
    '        'If hfCoil.Value <> "" Then
    '        '    filter &= " and DAUGHTER_COILID_NUM in ('" & hfCoil.Value.Replace(",", "','") & "')"
    '        'End If
    '        If objController.PopulateCoilData(fromDt, toDt, filter).Rows.Count > 0 Then
    '            gvCoilData.DataSource = objController.PopulateCoilData(fromDt, toDt, filter)
    '            gvCoilData.DataBind()
    '            objController.HideGridViewColumns(gvCoilData)
    '        End If
    '    Else
    '        Dim fromDt As String = hfFrom.Value
    '        Dim toDt As String = hfTo.Value
    '        Dim filter As String = " 1=1"
    '        If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
    '            filter &= " and GRADE = '" & ddlGrade.SelectedItem.Text & "'"
    '        End If
    '        If hfThickness.Value <> "" Then
    '            filter &= " and THICKNESS in (" & hfThickness.Value & ")"
    '        End If
    '        'If hfWidth.Value <> "" Then
    '        '    filter &= " and WIDTH in (" & hfWidth.Value & ")"
    '        'End If
    '        'If hfCoil.Value <> "" Then
    '        '    filter &= " and DAUGHTER_COILID_NUM in ('" & hfCoil.Value.Replace(",", "','") & "')"
    '        'End If
    '        If objController.PopulateCoilData(fromDt, toDt, filter).Rows.Count > 0 Then
    '            gvCoilData.DataSource = objController.PopulateCoilData(fromDt, toDt, filter)
    '            gvCoilData.DataBind()
    '            objController.HideGridViewColumns(gvCoilData)
    '        End If
    '    End If

    'End Sub
    'Sub processWidth()
    '    Dim hv As String = hfWidth.Value
    '    If hv.Length <> 0 Then
    '        Dim fromDt As String = hfFrom.Value
    '        Dim toDt As String = hfTo.Value

    '        objController.PopulateCoilIdForSPM(ddlCoilId, fromDt, toDt, ddlGrade.SelectedItem.Text, hfThickness.Value, hv)
    '        'btnOk_Click(Nothing, Nothing)
    '        Dim filter As String = " 1=1"
    '        If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
    '            filter &= " and GRADE = '" & ddlGrade.SelectedItem.Text & "'"
    '        End If
    '        If hfThickness.Value <> "" Then
    '            filter &= " and THICKNESS in (" & hfThickness.Value & ")"
    '        End If
    '        If hfWidth.Value <> "" Then
    '            filter &= " and WIDTH in (" & hfWidth.Value & ")"
    '        End If
    '        'If hfCoil.Value <> "" Then
    '        '    filter &= " and DAUGHTER_COILID_NUM in ('" & hfCoil.Value.Replace(",", "','") & "')"
    '        'End If
    '        If objController.PopulateCoilData(fromDt, toDt, filter).Rows.Count > 0 Then
    '            gvCoilData.DataSource = objController.PopulateCoilData(fromDt, toDt, filter)
    '            gvCoilData.DataBind()
    '            objController.HideGridViewColumns(gvCoilData)
    '        End If
    '    Else
    '        Dim fromDt As String = hfFrom.Value
    '        Dim toDt As String = hfTo.Value
    '        Dim filter As String = " 1=1"
    '        If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
    '            filter &= " and GRADE = '" & ddlGrade.SelectedItem.Text & "'"
    '        End If
    '        If hfThickness.Value <> "" Then
    '            filter &= " and THICKNESS in (" & hfThickness.Value & ")"
    '        End If
    '        If hfWidth.Value <> "" Then
    '            filter &= " and WIDTH in (" & hfWidth.Value & ")"
    '        End If
    '        'If hfCoil.Value <> "" Then
    '        '    filter &= " and DAUGHTER_COILID_NUM in ('" & hfCoil.Value.Replace(",", "','") & "')"
    '        'End If
    '        If objController.PopulateCoilData(fromDt, toDt, filter).Rows.Count > 0 Then
    '            gvCoilData.DataSource = objController.PopulateCoilData(fromDt, toDt, filter)
    '            gvCoilData.DataBind()
    '            objController.HideGridViewColumns(gvCoilData)
    '        End If
    '    End If

    'End Sub
    'Sub processCoil()
    '    Dim hv As String = hfCoil.Value
    '    'btnOk_Click(Nothing, Nothing)
    '    If hv.Length <> 0 Then
    '        Dim fromDt As String = hfFrom.Value
    '        Dim toDt As String = hfTo.Value
    '        Dim filter As String = " 1=1"
    '        If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
    '            filter &= " and GRADE = '" & ddlGrade.SelectedItem.Text & "'"
    '        End If
    '        If hfThickness.Value <> "" Then
    '            filter &= " and THICKNESS in (" & hfThickness.Value & ")"
    '        End If
    '        If hfWidth.Value <> "" Then
    '            filter &= " and WIDTH in (" & hfWidth.Value & ")"
    '        End If
    '        If hfCoil.Value <> "" Then
    '            filter &= " and DAUGHTER_COILID_NUM in ('" & hfCoil.Value.Replace(",", "','") & "')"
    '        End If
    '        If objController.PopulateCoilData(fromDt, toDt, filter).Rows.Count > 0 Then
    '            gvCoilData.DataSource = objController.PopulateCoilData(fromDt, toDt, filter)
    '            gvCoilData.DataBind()
    '            objController.HideGridViewColumns(gvCoilData)
    '        End If
    '    Else
    '        Dim fromDt As String = hfFrom.Value
    '        Dim toDt As String = hfTo.Value
    '        Dim filter As String = " 1=1"
    '        If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
    '            filter &= " and GRADE = '" & ddlGrade.SelectedItem.Text & "'"
    '        End If
    '        If hfThickness.Value <> "" Then
    '            filter &= " and THICKNESS in (" & hfThickness.Value & ")"
    '        End If
    '        If hfWidth.Value <> "" Then
    '            filter &= " and WIDTH in (" & hfWidth.Value & ")"
    '        End If
    '        If hfCoil.Value <> "" Then
    '            filter &= " and DAUGHTER_COILID_NUM in ('" & hfCoil.Value.Replace(",", "','") & "')"
    '        End If
    '        If objController.PopulateCoilData(fromDt, toDt, filter).Rows.Count > 0 Then
    '            gvCoilData.DataSource = objController.PopulateCoilData(fromDt, toDt, filter)
    '            gvCoilData.DataBind()
    '            objController.HideGridViewColumns(gvCoilData)
    '        End If
    '    End If

    'End Sub

    Protected Sub gvCoilData_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles gvCoilData.RowCommand
        Try

            Dim index As Integer = CType(CType(e.CommandSource, Button).NamingContainer, GridViewRow).RowIndex
            Session("CoilNo") = CType(gvCoilData.Rows(index).Cells(2).FindControl("btnDaughterCoilNo"), Button).Text.Trim()
            Session("CoilDate") = CType(gvCoilData.Rows(index).FindControl("btnCoilStDatetime"), Label).Text.Trim()
            Session("ColumnName") = CType(CType(e.CommandSource, Button).Parent, DataControlFieldCell).ContainingField.ToString()
            objController.LoadColumnNameForSPMProcessDataCoilWise(clbParamTest, Session("ColumnName"))
            pnlParams.Attributes.Add("style", "display:block")
            divHolder.Attributes.Add("style", "display:block")
            btnOk_Click(sender, e)

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub gvCoilData_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles gvCoilData.RowDataBound
        Try

            If e.Row.RowType = DataControlRowType.DataRow Then
                Dim dtCutOff As DataTable
                Dim a() As DataRow
                'YS---------------start---------------
                Dim vYS As Double = 0
                If Not IsDBNull(DataBinder.Eval(e.Row.DataItem, "YS")) Then
                    vYS = DataBinder.Eval(e.Row.DataItem, "YS")
                End If

                Dim btnYS As Button = CType(e.Row.FindControl("btnYS"), Button)
                dtCutOff = objController.GetProcessDataCutOff()
                a = dtCutOff.Select("COLUMN_NAME='YS'")
                If a.Length > 0 Then
                    Dim dblYS As Double = a(0)(2)
                    If vYS > dblYS Then
                        btnYS.BackColor = Drawing.Color.Red
                        btnYS.ForeColor = Drawing.Color.AntiqueWhite
                    Else
                        btnYS.BackColor = Drawing.Color.FromArgb(201, 246, 155)
                    End If
                End If
                'YS---------------end-----------------

                'C00_COILER_SPEED_SET --- start--------------
                Dim vC00_COILER_SPEED_SET As Double = DataBinder.Eval(e.Row.DataItem, "C00_COILER_SPEED_SET")
                Dim btnC00CoilerSpeedSet As Button = CType(e.Row.FindControl("btnC00CoilerSpeedSet"), Button)
                dtCutOff = objController.GetProcessDataCutOff()
                a = dtCutOff.Select("COLUMN_NAME='C00_COILER_SPEED_SET'")
                If a.Length > 0 Then
                    Dim dblCoilerSpeedSet As Double = a(0)(2)
                    If vC00_COILER_SPEED_SET > dblCoilerSpeedSet Then
                        btnC00CoilerSpeedSet.BackColor = Drawing.Color.Red
                        btnC00CoilerSpeedSet.ForeColor = Drawing.Color.AntiqueWhite
                    Else
                        btnC00CoilerSpeedSet.BackColor = Drawing.Color.FromArgb(201, 246, 155)
                    End If
                End If
                'C00_COILER_SPEED_SET --- end--------------

                'C00_COILER_SPEED_ACT --- start--------------
                Dim vC00_COILER_SPEED_ACT As Double = DataBinder.Eval(e.Row.DataItem, "C00_COILER_SPEED_ACT")
                Dim btnC00CoilerSpeedAct As Button = CType(e.Row.FindControl("btnC00CoilerSpeedAct"), Button)
                dtCutOff = objController.GetProcessDataCutOff()
                a = dtCutOff.Select("COLUMN_NAME='C00_COILER_SPEED_ACT'")
                If a.Length > 0 Then
                    Dim dblCoilerSpeedAct As Double = a(0)(2)
                    If vC00_COILER_SPEED_ACT > dblCoilerSpeedAct Then
                        btnC00CoilerSpeedAct.BackColor = Drawing.Color.Red
                        btnC00CoilerSpeedAct.ForeColor = Drawing.Color.AntiqueWhite
                    Else
                        btnC00CoilerSpeedAct.BackColor = Drawing.Color.FromArgb(201, 246, 155)
                    End If
                End If
                'C00_COILER_SPEED_ACT --- end--------------

                'S11_SPEED_SET --- start--------------
                Dim vS11_SPEED_SET As Double = DataBinder.Eval(e.Row.DataItem, "S11_SPEED_SET")
                Dim btnS11SpeedSet As Button = CType(e.Row.FindControl("btnS11SpeedSet"), Button)
                dtCutOff = objController.GetProcessDataCutOff()
                a = dtCutOff.Select("COLUMN_NAME='S11_SPEED_SET'")
                If a.Length > 0 Then
                    Dim dblS11SpeedSet As Double = a(0)(2)
                    If vS11_SPEED_SET > dblS11SpeedSet Then
                        btnS11SpeedSet.BackColor = Drawing.Color.Red
                        btnS11SpeedSet.ForeColor = Drawing.Color.AntiqueWhite
                    Else
                        btnS11SpeedSet.BackColor = Drawing.Color.FromArgb(201, 246, 155)
                    End If
                End If
                'S11_SPEED_SET --- end--------------

                'S11_SPEED_ACT --- start--------------
                Dim vS11_SPEED_ACT As Double = DataBinder.Eval(e.Row.DataItem, "S11_SPEED_ACT")
                Dim btnS11SpeedAct As Button = CType(e.Row.FindControl("btnS11SpeedAct"), Button)
                dtCutOff = objController.GetProcessDataCutOff()
                a = dtCutOff.Select("COLUMN_NAME='S11_SPEED_ACT'")
                If a.Length > 0 Then
                    Dim dblS11SpeedAct As Double = a(0)(2)
                    If vS11_SPEED_ACT > dblS11SpeedAct Then
                        btnS11SpeedAct.BackColor = Drawing.Color.Red
                        btnS11SpeedAct.ForeColor = Drawing.Color.AntiqueWhite
                    Else
                        btnS11SpeedAct.BackColor = Drawing.Color.FromArgb(201, 246, 155)
                    End If
                End If
                'S11_SPEED_ACT --- end--------------

                'C90_COILER_SPEED_SET --- start--------------
                Dim vC90_COILER_SPEED_SET As Double = DataBinder.Eval(e.Row.DataItem, "C90_COILER_SPEED_SET")
                Dim btnC90CoilerSpeedSet As Button = CType(e.Row.FindControl("btnC90CoilerSpeedSet"), Button)
                dtCutOff = objController.GetProcessDataCutOff()
                a = dtCutOff.Select("COLUMN_NAME='C90_COILER_SPEED_SET'")
                If a.Length > 0 Then
                    Dim dblC90CoilerSpeedSet As Double = a(0)(2)
                    If vC90_COILER_SPEED_SET > dblC90CoilerSpeedSet Then
                        btnC90CoilerSpeedSet.BackColor = Drawing.Color.Red
                        btnC90CoilerSpeedSet.ForeColor = Drawing.Color.AntiqueWhite
                    Else
                        btnC90CoilerSpeedSet.BackColor = Drawing.Color.FromArgb(201, 246, 155)
                    End If
                End If
                'C90_COILER_SPEED_SET --- end--------------

                'C90_COILER_SPEED_ACT --- start--------------
                Dim vC90_COILER_SPEED_ACT As Double = DataBinder.Eval(e.Row.DataItem, "C90_COILER_SPEED_ACT")
                Dim btnC90CoilerSpeedAct As Button = CType(e.Row.FindControl("btnC90CoilerSpeedAct"), Button)
                dtCutOff = objController.GetProcessDataCutOff()
                a = dtCutOff.Select("COLUMN_NAME='C90_COILER_SPEED_ACT'")
                If a.Length > 0 Then
                    Dim dblC90CoilerSpeedAct As Double = a(0)(2)
                    If vC90_COILER_SPEED_ACT > dblC90CoilerSpeedAct Then
                        btnC90CoilerSpeedAct.BackColor = Drawing.Color.Red
                        btnC90CoilerSpeedAct.ForeColor = Drawing.Color.AntiqueWhite
                    Else
                        btnC90CoilerSpeedAct.BackColor = Drawing.Color.FromArgb(201, 246, 155)
                    End If
                End If
                'C90_COILER_SPEED_ACT --- end--------------

                'ENLONGATION_SET --- start--------------
                Dim vENLONGATION_SET As Double = DataBinder.Eval(e.Row.DataItem, "ENLONGATION_SET")
                Dim btnEnlongationSet As Button = CType(e.Row.FindControl("btnEnlongationSet"), Button)
                dtCutOff = objController.GetProcessDataCutOff()
                a = dtCutOff.Select("COLUMN_NAME='ENLONGATION_SET'")
                If a.Length > 0 Then
                    Dim dblEnlongationSet As Double = a(0)(2)
                    If vC90_COILER_SPEED_ACT > dblEnlongationSet Then
                        btnEnlongationSet.BackColor = Drawing.Color.Red
                        btnEnlongationSet.ForeColor = Drawing.Color.AntiqueWhite
                    Else
                        btnEnlongationSet.BackColor = Drawing.Color.FromArgb(201, 246, 155)
                    End If
                End If
                'ENLONGATION_SET --- end--------------

                'ENLONGATION_ACT --- start--------------
                Dim vENLONGATION_ACT As Double = DataBinder.Eval(e.Row.DataItem, "ENLONGATION_ACT")
                Dim btnEnlongationAct As Button = CType(e.Row.FindControl("btnEnlongationAct"), Button)
                dtCutOff = objController.GetProcessDataCutOff()
                a = dtCutOff.Select("COLUMN_NAME='ENLONGATION_ACT'")
                If a.Length > 0 Then
                    Dim dblEnlongationAct As Double = a(0)(2)
                    If vENLONGATION_ACT > dblEnlongationAct Then
                        btnEnlongationAct.BackColor = Drawing.Color.Red
                        btnEnlongationAct.ForeColor = Drawing.Color.AntiqueWhite
                    Else
                        btnEnlongationAct.BackColor = Drawing.Color.FromArgb(201, 246, 155)
                    End If
                End If
                'ENLONGATION_ACT --- end--------------

                'ROLLFORCE --- start--------------
                Dim vROLLFORCE As Double = DataBinder.Eval(e.Row.DataItem, "ROLLFORCE")
                Dim btnRollforce As Button = CType(e.Row.FindControl("btnRollforce"), Button)
                dtCutOff = objController.GetProcessDataCutOff()
                a = dtCutOff.Select("COLUMN_NAME='ROLLFORCE'")
                If a.Length > 0 Then
                    Dim dblRollforce As Double = a(0)(2)
                    If vROLLFORCE > dblRollforce Then
                        btnRollforce.BackColor = Drawing.Color.Red
                        btnRollforce.ForeColor = Drawing.Color.AntiqueWhite
                    Else
                        btnRollforce.BackColor = Drawing.Color.FromArgb(201, 246, 155)
                    End If
                End If
                'ROLLFORCE --- end--------------

                'ROLLFORCE_DS --- start--------------
                Dim vROLLFORCE_DS As Double = DataBinder.Eval(e.Row.DataItem, "ROLLFORCE_DS")
                Dim btnRollforceDs As Button = CType(e.Row.FindControl("btnRollforceDs"), Button)
                dtCutOff = objController.GetProcessDataCutOff()
                a = dtCutOff.Select("COLUMN_NAME='ROLLFORCE_DS'")
                If a.Length > 0 Then
                    Dim dblRollforceDs As Double = a(0)(2)
                    If vROLLFORCE_DS > dblRollforceDs Then
                        btnRollforceDs.BackColor = Drawing.Color.Red
                        btnRollforceDs.ForeColor = Drawing.Color.AntiqueWhite
                    Else
                        btnRollforceDs.BackColor = Drawing.Color.FromArgb(201, 246, 155)
                    End If
                End If
                'ROLLFORCE_DS --- end--------------

                'ROLLFORCE_OS --- start--------------
                Dim vROLLFORCE_OS As Double = DataBinder.Eval(e.Row.DataItem, "ROLLFORCE_OS")
                Dim btnRollforceOs As Button = CType(e.Row.FindControl("btnRollforceOs"), Button)
                dtCutOff = objController.GetProcessDataCutOff()
                a = dtCutOff.Select("COLUMN_NAME='ROLLFORCE_OS'")
                If a.Length > 0 Then
                    Dim dblRollforceOs As Double = a(0)(2)
                    If vROLLFORCE_OS > dblRollforceOs Then
                        btnRollforceOs.BackColor = Drawing.Color.Red
                        btnRollforceOs.ForeColor = Drawing.Color.AntiqueWhite
                    Else
                        btnRollforceOs.BackColor = Drawing.Color.FromArgb(201, 246, 155)
                    End If
                End If
                'ROLLFORCE_OS --- end--------------

                'WORK_ROLL_BEND_POS_SET --- start--------------
                Dim vWORK_ROLL_BEND_POS_SET As Double = DataBinder.Eval(e.Row.DataItem, "WORK_ROLL_BEND_POS_SET")
                Dim btnWorkRollBendPosSet As Button = CType(e.Row.FindControl("btnWorkRollBendPosSet"), Button)
                dtCutOff = objController.GetProcessDataCutOff()
                a = dtCutOff.Select("COLUMN_NAME='WORK_ROLL_BEND_POS_SET'")
                If a.Length > 0 Then
                    Dim dblWorkRollBendPosSet As Double = a(0)(2)
                    If vWORK_ROLL_BEND_POS_SET > dblWorkRollBendPosSet Then
                        btnWorkRollBendPosSet.BackColor = Drawing.Color.Red
                        btnWorkRollBendPosSet.ForeColor = Drawing.Color.AntiqueWhite
                    Else
                        btnWorkRollBendPosSet.BackColor = Drawing.Color.FromArgb(201, 246, 155)
                    End If
                End If
                'WORK_ROLL_BEND_POS_SET --- end--------------

                'WORK_ROLL_BEND_POS_ACT --- start--------------
                Dim vWORK_ROLL_BEND_POS_ACT As Double = DataBinder.Eval(e.Row.DataItem, "WORK_ROLL_BEND_POS_ACT")
                Dim btnWorkRollBendPosAct As Button = CType(e.Row.FindControl("btnWorkRollBendPosAct"), Button)
                dtCutOff = objController.GetProcessDataCutOff()
                a = dtCutOff.Select("COLUMN_NAME='WORK_ROLL_BEND_POS_ACT'")
                If a.Length > 0 Then
                    Dim dblWorkRollBendPosAct As Double = a(0)(2)
                    If vWORK_ROLL_BEND_POS_ACT > dblWorkRollBendPosAct Then
                        btnWorkRollBendPosAct.BackColor = Drawing.Color.Red
                        btnWorkRollBendPosAct.ForeColor = Drawing.Color.AntiqueWhite
                    Else
                        btnWorkRollBendPosAct.BackColor = Drawing.Color.FromArgb(201, 246, 155)
                    End If
                End If
                'WORK_ROLL_BEND_POS_ACT --- end--------------

                'WORK_ROLL_BEND_NEG_SET --- start--------------
                Dim vWORK_ROLL_BEND_NEG_SET As Double = DataBinder.Eval(e.Row.DataItem, "WORK_ROLL_BEND_NEG_SET")
                Dim btnWorkRollBendNegSet As Button = CType(e.Row.FindControl("btnWorkRollBendNegSet"), Button)
                dtCutOff = objController.GetProcessDataCutOff()
                a = dtCutOff.Select("COLUMN_NAME='WORK_ROLL_BEND_NEG_SET'")
                If a.Length > 0 Then
                    Dim dblWorkRollBendNegSet As Double = a(0)(2)
                    If vWORK_ROLL_BEND_NEG_SET > dblWorkRollBendNegSet Then
                        btnWorkRollBendNegSet.BackColor = Drawing.Color.Red
                        btnWorkRollBendNegSet.ForeColor = Drawing.Color.AntiqueWhite
                    Else
                        btnWorkRollBendNegSet.BackColor = Drawing.Color.FromArgb(201, 246, 155)
                    End If
                End If
                'WORK_ROLL_BEND_NEG_SET --- end--------------

                'WORK_ROLL_BEND_NEG_ACT --- start--------------
                Dim vWORK_ROLL_BEND_NEG_ACT As Double = DataBinder.Eval(e.Row.DataItem, "WORK_ROLL_BEND_NEG_ACT")
                Dim btnWorkRollBendNegAct As Button = CType(e.Row.FindControl("btnWorkRollBendNegAct"), Button)
                dtCutOff = objController.GetProcessDataCutOff()
                a = dtCutOff.Select("COLUMN_NAME='WORK_ROLL_BEND_NEG_ACT'")
                If a.Length > 0 Then
                    Dim dblWorkRollBendNegAct As Double = a(0)(2)
                    If vWORK_ROLL_BEND_NEG_ACT > dblWorkRollBendNegAct Then
                        btnWorkRollBendNegAct.BackColor = Drawing.Color.Red
                        btnWorkRollBendNegAct.ForeColor = Drawing.Color.AntiqueWhite
                    Else
                        btnWorkRollBendNegAct.BackColor = Drawing.Color.FromArgb(201, 246, 155)
                    End If
                End If
                'WORK_ROLL_BEND_NEG_ACT --- end--------------

                'ROLL_GAP_DS --- start--------------
                Dim vROLL_GAP_DS As Double = DataBinder.Eval(e.Row.DataItem, "ROLL_GAP_DS")
                Dim btnRollGapDs As Button = CType(e.Row.FindControl("btnRollGapDs"), Button)
                dtCutOff = objController.GetProcessDataCutOff()
                a = dtCutOff.Select("COLUMN_NAME='ROLL_GAP_DS'")
                If a.Length > 0 Then
                    Dim dblRollGapDs As Double = a(0)(2)
                    If vROLL_GAP_DS > dblRollGapDs Then
                        btnRollGapDs.BackColor = Drawing.Color.Red
                        btnRollGapDs.ForeColor = Drawing.Color.AntiqueWhite
                    Else
                        btnRollGapDs.BackColor = Drawing.Color.FromArgb(201, 246, 155)
                    End If
                End If
                'ROLL_GAP_DS --- end--------------

                'ROLL_GAP_OS --- start--------------
                Dim vROLL_GAP_OS As Double = DataBinder.Eval(e.Row.DataItem, "ROLL_GAP_OS")
                Dim btnRollGapOs As Button = CType(e.Row.FindControl("btnRollGapOs"), Button)
                dtCutOff = objController.GetProcessDataCutOff()
                a = dtCutOff.Select("COLUMN_NAME='ROLL_GAP_OS'")
                If a.Length > 0 Then
                    Dim dblRollGapOs As Double = a(0)(2)
                    If vROLL_GAP_OS > dblRollGapOs Then
                        btnRollGapOs.BackColor = Drawing.Color.Red
                        btnRollGapOs.ForeColor = Drawing.Color.AntiqueWhite
                    Else
                        btnRollGapOs.BackColor = Drawing.Color.FromArgb(201, 246, 155)
                    End If
                End If
                'ROLL_GAP_OS --- end--------------

                'TENSION_POR_ENTRY_REF --- start--------------
                Dim vTENSION_POR_ENTRY_REF As Double = DataBinder.Eval(e.Row.DataItem, "TENSION_POR_ENTRY_REF")
                Dim btnTensionPorEntryRef As Button = CType(e.Row.FindControl("btnTensionPorEntryRef"), Button)
                dtCutOff = objController.GetProcessDataCutOff()
                a = dtCutOff.Select("COLUMN_NAME='TENSION_POR_ENTRY_REF'")
                If a.Length > 0 Then
                    Dim dblTensionPorEntryRef As Double = a(0)(2)
                    If vTENSION_POR_ENTRY_REF > dblTensionPorEntryRef Then
                        btnTensionPorEntryRef.BackColor = Drawing.Color.Red
                        btnTensionPorEntryRef.ForeColor = Drawing.Color.AntiqueWhite
                    Else
                        btnTensionPorEntryRef.BackColor = Drawing.Color.FromArgb(201, 246, 155)
                    End If
                End If
                'TENSION_POR_ENTRY_REF --- end--------------


                'TENSION_POS_ENTRY --- start--------------
                Dim vTENSION_POS_ENTRY As Double = DataBinder.Eval(e.Row.DataItem, "TENSION_POS_ENTRY")
                Dim btnTensionPosEntry As Button = CType(e.Row.FindControl("btnTensionPosEntry"), Button)
                dtCutOff = objController.GetProcessDataCutOff()
                a = dtCutOff.Select("COLUMN_NAME='TENSION_POS_ENTRY'")
                If a.Length > 0 Then
                    Dim dblTensionPosEntry As Double = a(0)(2)
                    If vTENSION_POS_ENTRY > dblTensionPosEntry Then
                        btnTensionPosEntry.BackColor = Drawing.Color.Red
                        btnTensionPosEntry.ForeColor = Drawing.Color.AntiqueWhite
                    Else
                        btnTensionPosEntry.BackColor = Drawing.Color.FromArgb(201, 246, 155)
                    End If
                End If
                'TENSION_POS_ENTRY --- end--------------

                'TENSION_TR_REF --- start--------------
                Dim vTENSION_TR_REF As Double = DataBinder.Eval(e.Row.DataItem, "TENSION_TR_REF")
                Dim btnTensionTrRef As Button = CType(e.Row.FindControl("btnTensionTrRef"), Button)
                dtCutOff = objController.GetProcessDataCutOff()
                a = dtCutOff.Select("COLUMN_NAME='TENSION_TR_REF'")
                If a.Length > 0 Then
                    Dim dblTensionTrRef As Double = a(0)(2)
                    If vTENSION_TR_REF > dblTensionTrRef Then
                        btnTensionTrRef.BackColor = Drawing.Color.Red
                        btnTensionTrRef.ForeColor = Drawing.Color.AntiqueWhite
                    Else
                        btnTensionTrRef.BackColor = Drawing.Color.FromArgb(201, 246, 155)
                    End If
                End If
                'TENSION_TR_REF --- end--------------

                'TENSION_TR --- start--------------
                Dim vTENSION_TR As Double = DataBinder.Eval(e.Row.DataItem, "TENSION_TR")
                Dim btnTensionTr As Button = CType(e.Row.FindControl("btnTensionTr"), Button)
                dtCutOff = objController.GetProcessDataCutOff()
                a = dtCutOff.Select("COLUMN_NAME='TENSION_TR'")
                If a.Length > 0 Then
                    Dim dblTensionTr As Double = a(0)(2)
                    If vTENSION_TR > dblTensionTr Then
                        btnTensionTr.BackColor = Drawing.Color.Red
                        btnTensionTr.ForeColor = Drawing.Color.AntiqueWhite
                    Else
                        btnTensionTr.BackColor = Drawing.Color.FromArgb(201, 246, 155)
                    End If
                End If
                'TENSION_TR --- end--------------
            End If
            e.Row.Cells(0).Enabled = False
            e.Row.Cells(1).Enabled = False
            e.Row.Cells(2).Enabled = False
            e.Row.Cells(3).Enabled = False
            e.Row.Cells(4).Enabled = False
            e.Row.Cells(5).Enabled = False
            e.Row.Cells(7).Enabled = False
            e.Row.Cells(9).Visible = False

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub ddlTdc_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlTdc.SelectedIndexChanged
        Try

            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            'objController.PopulateThicknessForSPM(ddlThickness, fromDt, toDt, ddlGrade.SelectedItem.Text)
            'ddlThickness_SelectedIndexChanged(sender, e)
            If ddlTdc.SelectedItem.Text.ToLower = "all" Then
                hfThickness.Value = ""
                hfWidth.Value = ""
                hfCoil.Value = ""
                'objController.PopulateThicknessForSPM(ddlThickness, fromDt, toDt, "")
                'objController.PopulateWidthForSPM(ddlWidth, fromDt, toDt, "", "")
                'objController.PopulateCoilIdForSPM(ddlCoilId, fromDt, toDt, "", "", "")
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForSPMDetailAnalysis(fromDt, toDt, "", "")
                If dt.Rows.Count > 0 AndAlso Not IsDBNull(dt.Rows(0)(0)) Then
                    txtFromThickness.Text = dt.Rows(0)(0)
                    txtToThickness.Text = dt.Rows(0)(1)
                    If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                        dt1 = objController.PopulateWidthForSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                        txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0) * 1000, 2)
                        txtWidthTo.Text = Math.Round(dt1.Rows(0)(1) * 1000, 2)
                    End If
                End If
            Else
                Dim dt, dt1 As DataTable
                dt = objController.PopulateThicknessForSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text)
                txtFromThickness.Text = dt.Rows(0)(0)
                txtToThickness.Text = dt.Rows(0)(1)
                If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                    dt1 = objController.PopulateWidthForSPMDetailAnalysis(fromDt, toDt, ddlGrade.SelectedItem.Text, ddlTdc.SelectedItem.Text, txtFromThickness.Text, txtToThickness.Text)
                    txtWidthFrom.Text = Math.Round(dt1.Rows(0)(0) * 1000, 2)
                    txtWidthTo.Text = Math.Round(dt1.Rows(0)(1) * 1000, 2)
                End If

            End If
            'processThickness()
            'btnOk_Click(sender, e)
            btnGo_Click(sender, e)

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click
        Try

            Dim fromDt As String = hfFrom.Value
            Dim toDt As String = hfTo.Value
            Dim filter As String = " 1=1"
            If ddlGrade.SelectedItem.Text.ToLower <> "all" Then
                filter &= " and T.GRADE = '" & ddlGrade.SelectedItem.Text & "'"
            End If
            If ddlTdc.SelectedItem.Text.ToLower <> "all" Then
                filter &= " and TDC_No = '" & ddlTdc.SelectedItem.Text & "'"
            End If
            If txtFromThickness.Text <> "" And txtToThickness.Text <> "" Then
                filter &= " and THICKNESS between " & txtFromThickness.Text & " and " & txtToThickness.Text & ""
                'divHolder.Attributes.Add("style", "display:none")
            End If
            If txtWidthFrom.Text <> "" And txtWidthTo.Text <> "" Then
                filter &= " and WIDTH between " & txtWidthFrom.Text / 1000 & " and " & txtWidthTo.Text / 1000 & ""
            End If
            Dim dt2 As DataTable = objController.PopulateCoilData(fromDt, toDt, filter)
            If dt2.Rows.Count > 0 Then

                For row As Integer = 0 To dt2.Rows.Count - 1
                    ''oracle data
                    Dim YS1 As Double = GetData(dt2.Rows(row)("Coil ID"))
                    dt2.Rows(row)("YS Testing") = YS1
                Next

                gvCoilData1.DataSource = dt2
                gvCoilData1.DataBind()
                gvCoilData1.UseAccessibleHeader = True
                gvCoilData1.HeaderRow.TableSection = TableRowSection.TableHeader
                'objController.HideGridViewColumns(gvCoilData)
            End If
            pnlParams.Attributes.Add("style", "display:none")
            divHolder.Attributes.Add("style", "display:none")
            If Session("SpmUsername") IsNot "" Then
                btnLogin.Visible = False
                btnLogout.Visible = True
            End If

        Catch ex As Exception

        End Try
    End Sub
    Protected Sub txtFromThickness_TextChanged(sender As Object, e As EventArgs) Handles txtFromThickness.TextChanged
        Try
            btnGo_Click(sender, e)
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub txtToThickness_TextChanged(sender As Object, e As EventArgs) Handles txtToThickness.TextChanged
        Try
            btnGo_Click(sender, e)
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub txtWidthFrom_TextChanged(sender As Object, e As EventArgs) Handles txtWidthFrom.TextChanged
        Try
            btnGo_Click(sender, e)
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub txtWidthTo_TextChanged(sender As Object, e As EventArgs) Handles txtWidthTo.TextChanged
        Try
            btnGo_Click(sender, e)
        Catch ex As Exception

        End Try

    End Sub

    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)
        ' Verifies that the control is rendered 

    End Sub

    Protected Sub btnDownload_Click(sender As Object, e As System.EventArgs) Handles btnDownload.Click
        If gvCoilData1.Rows.Count > 0 Then
            Try
                'gvCoilData1.Columns(0).Visible = False
                Response.ClearContent()
                Response.Buffer = True
                Response.AddHeader("content-disposition", String.Format("attachment; filename={0}", "CoilDetail.xls"))
                Response.ContentEncoding = Encoding.UTF8
                Response.ContentType = "application/ms-excel"
                Dim sw As New StringWriter()
                Dim htw As New HtmlTextWriter(sw)
                gvCoilData1.RenderControl(htw)
                Response.Write(sw.ToString())
                Response.End()

            Catch ex As Exception
            Finally
                'gvCoilData1.Columns(0).Visible = True
            End Try
        End If

    End Sub
    Private Sub btnLoginSave_Click(sender As Object, e As EventArgs) Handles btnLoginSave.Click
        Try

            If txtUsername.Text.Trim() IsNot "" Then

                If txtPassword.Text.Trim() = "" Then
                    UserMsgBoxWarning("Enter password.")
                    txtPassword.Focus()
                Else
                    If txtUsername.Text.Trim().ToLower = "admin" And txtPassword.Text.Trim().ToLower = "admin" Then
                        Session("SpmUsername") = txtUsername.Text.Trim().ToLower
                        'gvCoilData1.Columns("YS").Visible = False
                        'gvCoilData1.Columns("YS Testing").Visible = True
                        btnGo_Click(sender, e)
                        'gvCoilData1.Columns(3).Visible = False
                        'gvCoilData1.Columns(4).Visible = True
                        txtUsername.Text = ""
                        txtPassword.Text = ""
                    Else
                        txtUsername.Text = ""
                        txtPassword.Text = ""
                        UserMsgBoxWarning("Incorrect login details.")
                        Exit Sub
                    End If
                End If
            Else
                UserMsgBoxWarning("Enter username.")
                txtUsername.Focus()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub gvCoilData1_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles gvCoilData1.RowDataBound
        Try
            If Session("SpmUsername") IsNot "" Then
                e.Row.Cells(3).Visible = False
                e.Row.Cells(4).Visible = True
            Else
                e.Row.Cells(3).Visible = True
                e.Row.Cells(4).Visible = False
            End If
        Catch ex As Exception

        End Try
      
    End Sub
    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        Try
            Session("SpmUsername") = ""
            btnGo_Click(sender, e)
            btnLogin.Visible = True
            btnLogout.Visible = False
        Catch ex As Exception

        End Try
        
    End Sub
End Class
