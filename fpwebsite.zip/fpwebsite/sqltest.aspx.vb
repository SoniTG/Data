﻿
Imports System.Data.SqlClient

Partial Class sqltest
    Inherits System.Web.UI.Page

    Dim fpcs As String = "server=176.0.0.60\LPTGSQLDEV;database=FP_PROCESS_DATA;uid=153521;pwd=Welcome@135"
    Dim lpcs As String = "server=176.0.0.60\LPTGSQLDEV;database=LP_PROCESS_DATA;uid=153521;pwd=Welcome@135"
    Dim machcs As String = "server=176.0.0.60\LPTGSQLDEV;database=MachCardio;uid=153521;pwd=Welcome@135"
    Dim tsmcs As String = "server=176.0.0.60\LPTGSQLDEV;database=TSM_ANGUL;uid=153521;pwd=Welcome@135"
    Dim skumcs As String = "server=176.0.0.60\LPTGSQLDEV;database=FP_DEFECT_ANALYSIS;uid=153521;pwd=Welcome@135"

    Private Sub sqltest_Load(sender As Object, e As EventArgs) Handles Me.Load
        Trace.Warn("FP")
        Dim confp As New SqlConnection(fpcs)
        confp.Open()
        Trace.Warn("FP Connected")
        confp.Close()
        Trace.Warn("FP Disconnected")

        Trace.Warn("LP")
        Dim conLp As New SqlConnection(lpcs)
        conLp.Open()
        Trace.Warn("LP Connected")
        conLp.Close()
        Trace.Warn("LP Disconnected")

        Trace.Warn("Mach Cardio")
        Dim conmach As New SqlConnection(machcs)
        conmach.Open()
        Trace.Warn("Mach Connected")
        conmach.Close()
        Trace.Warn("Mach Disconnected")

        Trace.Warn("TSM")
        Dim contsm As New SqlConnection(tsmcs)
        contsm.Open()
        Trace.Warn("TSM Connected")
        contsm.Close()
        Trace.Warn("TSM Disconnected")

        Trace.Warn("Scum")
        Dim conscum As New SqlConnection(skumcs)
        conscum.Open()
        Trace.Warn("SCUM Connected")
        conscum.Close()
        Trace.Warn("SCUM Disconnected")


    End Sub
End Class
