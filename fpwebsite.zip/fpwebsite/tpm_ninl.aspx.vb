﻿
Partial Class tpm_ninl
    Inherits System.Web.UI.Page
    Dim objCSV As New csv
    Private objController As New Controller

    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub
    Private Sub tpm_tscr_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then

            Session("pagehit") = objController.SaveAndRetrievePageHits("", IO.Path.GetFileName(Request.Path))

            cbFromGrade.DataSource = objCSV.getListNINL
            cbFromGrade.DataBind()

            cbToGrade.DataSource = objCSV.getListNINL
            cbToGrade.DataBind()

            divOutput.Visible = False
        End If

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Reset()
    End Sub

    Sub Reset()
        divOutput.Visible = False
        txtCastingSpeed.Text = ""

        'cbThroughput.SelectedIndex = 0
        cbFromGrade.SelectedIndex = 0
        cbToGrade.SelectedIndex = 0

        lblTrL.Text = ""
        lblTrW.Text = ""
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        divOutput.Visible = True
        lblCS.Text = txtCastingSpeed.Text
        lblG.Text = cbFromGrade.SelectedItem.Text & " - " & cbToGrade.SelectedItem.Text

        DoCalculation()

        Dim okl, okw, trl, trw As String

    End Sub

    Sub DoCalculation()

        Dim throughput As Double = txtCastingSpeed.Text

        Dim datafileidx As Integer = -1

        If throughput >= 2.2 And throughput <= 2.65 Then
            datafileidx = 0
        ElseIf throughput >= 2.66 And throughput <= 3.05 Then
            datafileidx = 1
        ElseIf throughput >= 3.06 And throughput <= 3.4 Then
            datafileidx = 2
        End If

        If datafileidx = -1 Then
            UserMsgBoxWarning("No input data found.")
            Return
        End If

        Dim s As String = objCSV.SearchNINL(cbFromGrade.SelectedItem.Text, cbToGrade.SelectedItem.Text, datafileidx)
        If (s <> "-1") Then
            Dim temp() As String = s.Split(",")

            Dim mulfactor As Double = txtTundishWt.Text / 18.0

            Dim OkTonnage = (temp(2) * 7020 * (0.15) * (0.15) * txtCastingSpeed.Text * mulfactor * 5) / (1000) '5=no of strands
            Dim OkLength = OkTonnage / (7.02 * (0.15) * (0.15))

            Dim TotalTimeInMin As Double = temp(3) - temp(2)
            Dim TransitionTonnage = (TotalTimeInMin * 7020 * (0.15) * (0.15) * txtCastingSpeed.Text * mulfactor * 5) / (1000)
            Dim TransitionLength = TransitionTonnage / (7.02 * (0.15) * (0.15))

            lblTrL.Text = Math.Round(TransitionLength, 1)
            lblTrW.Text = Math.Round(TransitionTonnage, 0)

            lblOKW.Text = Math.Round(OkTonnage, 0)
            lblOKL.Text = Math.Round(OkLength, 1)
        Else
            lblTrL.Text = 0
            lblTrW.Text = 0

            lblOKW.Text = 0
            lblOKL.Text = 0
        End If
    End Sub
End Class
