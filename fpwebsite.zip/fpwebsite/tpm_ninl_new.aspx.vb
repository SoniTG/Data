﻿
Partial Class tpm_ninl_new
    Inherits System.Web.UI.Page
    Dim objCSV As New csv
    Private objController As New Controller

    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub
    Private Sub btn1c_Click(sender As Object, e As EventArgs) Handles btn1c.Click
        mv.SetActiveView(view1Closed)
        divOutput1C.Visible = False
    End Sub

    Private Sub btn2c_Click(sender As Object, e As EventArgs) Handles btn2c.Click
        mv.SetActiveView(view2Closed)
        divOutput2C.Visible = False
    End Sub

    Private Sub btnAll_Click(sender As Object, e As EventArgs) Handles btnAll.Click
        mv.SetActiveView(viewAllOpen)
        divOutput.Visible = False
    End Sub

    Private Sub tpm_ninl_new_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            mv.ActiveViewIndex = 0
            cbFromGrade.DataSource = objCSV.getListNINL
            cbFromGrade.DataBind()

            cbToGrade.DataSource = objCSV.getListNINL
            cbToGrade.DataBind()

            cbFromGrade1c.DataSource = objCSV.getListNINL
            cbFromGrade1c.DataBind()

            cbToGrade1c.DataSource = objCSV.getListNINL
            cbToGrade1c.DataBind()

            cbFromGrade2c.DataSource = objCSV.getListNINL
            cbFromGrade2c.DataBind()

            cbToGrade2c.DataSource = objCSV.getListNINL
            cbToGrade2c.DataBind()
        End If
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        divOutput.Visible = False
        txtCastingSpeed.Text = ""
        txtTundishWt.Text = ""

        cbFromGrade.SelectedIndex = 0
        cbToGrade.SelectedIndex = 0
    End Sub

    Private Sub btnReset1c_Click(sender As Object, e As EventArgs) Handles btnReset1c.Click
        divOutput1C.Visible = False
        txtCastingSpeed1c.Text = ""
        txtTundishWt1c.Text = ""

        cbFromGrade1c.SelectedIndex = 0
        cbToGrade1c.SelectedIndex = 0
    End Sub

    Private Sub btnReset2c_Click(sender As Object, e As EventArgs) Handles btnReset2c.Click
        divOutput2C.Visible = False
        txtCastingSpeed2c.Text = ""
        txtTundishWt2c.Text = ""

        cbFromGrade2c.SelectedIndex = 0
        cbToGrade2c.SelectedIndex = 0
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        divOutput.Visible = True
        lblCS.Text = txtCastingSpeed.Text
        lblG.Text = cbFromGrade.SelectedItem.Text & " - " & cbToGrade.SelectedItem.Text
        hfstand.Value = ""
        DoCalculation(txtCastingSpeed.Text, txtTundishWt.Text, cbFromGrade.SelectedItem.Text, cbToGrade.SelectedItem.Text, hfstand.Value)
    End Sub

    Private Sub btnCalculate1c_Click(sender As Object, e As EventArgs) Handles btnCalculate1c.Click
        divOutput1C.Visible = True
        lblCS1C.Text = txtCastingSpeed1c.Text
        lblG1C.Text = cbFromGrade1c.SelectedItem.Text & " - " & cbToGrade1c.SelectedItem.Text

        DoCalculation(txtCastingSpeed1c.Text, txtTundishWt1c.Text, cbFromGrade1c.SelectedItem.Text, cbToGrade1c.SelectedItem.Text, hfstand.Value)
    End Sub

    Private Sub btnCalculate2c_Click(sender As Object, e As EventArgs) Handles btnCalculate2c.Click
        divOutput2C.Visible = True
        lblCS2C.Text = txtCastingSpeed2c.Text
        lblG2C.Text = cbFromGrade2c.SelectedItem.Text & " - " & cbToGrade2c.SelectedItem.Text

        DoCalculation(txtCastingSpeed2c.Text, txtTundishWt2c.Text, cbFromGrade2c.SelectedItem.Text, cbToGrade2c.SelectedItem.Text, hfstand.Value)
    End Sub

    Sub DoCalculation(ByVal castingspeed As String, ByVal tundishwt As String, ByVal fromgrade As String, ByVal tograde As String, ByVal closedstand As String)

        Dim throughput As Double = castingspeed

        Dim datafileidx As Integer = -1

        If throughput >= 2.2 And throughput <= 2.65 Then
            datafileidx = 0
        ElseIf throughput >= 2.66 And throughput <= 3.05 Then
            datafileidx = 1
        ElseIf throughput >= 3.06 And throughput <= 3.4 Then
            datafileidx = 2
        End If

        If datafileidx = -1 Then
            UserMsgBoxWarning("No input data found.")
            Return
        End If

        Dim totOKL, totOKW, totTL, totTW As Double
        Dim totNo As Integer

        For i As Integer = 1 To 6
            Dim s As String = ""
            If closedstand.Length = 0 Then
                s = objCSV.SearchNINLStrandWise(fromgrade, tograde, datafileidx, i, csv.TundishType.allopen)
            ElseIf closedstand.Length = 1
                s = objCSV.SearchNINLStrandWise(fromgrade, tograde, datafileidx, i, csv.TundishType.oneclosed)
            Else
                s = objCSV.SearchNINLStrandWise(fromgrade, tograde, datafileidx, i, csv.TundishType.twoclosed)
            End If

            If closedstand.Contains(i) Then
                s = -1
            End If

            If (s <> "-1") Then
                Dim temp() As String = s.Split(",")

                Dim mulfactor As Double = tundishwt / 18.0

                Dim OkTonnage = (temp(2) * 7200 * (0.15) * (0.15) * castingspeed * mulfactor) / (1000)
                Dim OkLength = OkTonnage / (7.2 * (0.15) * (0.15))

                Dim TotalTimeInMin As Double = temp(3) - temp(2)
                Dim TransitionTonnage = (TotalTimeInMin * 7200 * (0.15) * (0.15) * castingspeed * mulfactor) / (1000)
                Dim TransitionLength = TransitionTonnage / (7.2 * (0.15) * (0.15))
                Dim NoBillets As Integer = Math.Ceiling(Math.Round(TransitionLength, 1) / 12)

                totOKL = totOKL + Math.Round(OkLength, 1)
                totOKW = totOKW + Math.Round(OkTonnage, 1)
                totTL = totTL + Math.Round(TransitionLength, 1)
                totTW = totTW + Math.Round(TransitionTonnage, 1)
                totNo = totNo + NoBillets


                If closedstand.Length = 0 Then
                    If i = 1 Then
                        lblS1OKL.Text = Math.Round(OkLength, 1)
                        lblS1OKW.Text = Math.Round(OkTonnage, 1)
                        lblS1TRL.Text = Math.Round(TransitionLength, 1)
                        lblS1TRW.Text = Math.Round(TransitionTonnage, 1)
                        lblS1No.Text = NoBillets
                    ElseIf i = 2 Then
                        lblS2OKL.Text = Math.Round(OkLength, 1)
                        lblS2OKW.Text = Math.Round(OkTonnage, 1)
                        lblS2TRL.Text = Math.Round(TransitionLength, 1)
                        lblS2TRW.Text = Math.Round(TransitionTonnage, 1)
                        lblS2No.Text = NoBillets
                    ElseIf i = 3 Then
                        lblS3OKL.Text = Math.Round(OkLength, 1)
                        lblS3OKW.Text = Math.Round(OkTonnage, 1)
                        lblS3TRL.Text = Math.Round(TransitionLength, 1)
                        lblS3TRW.Text = Math.Round(TransitionTonnage, 1)
                        lblS3No.Text = NoBillets
                    ElseIf i = 4 Then
                        lblS4OKL.Text = Math.Round(OkLength, 1)
                        lblS4OKW.Text = Math.Round(OkTonnage, 1)
                        lblS4TRL.Text = Math.Round(TransitionLength, 1)
                        lblS4TRW.Text = Math.Round(TransitionTonnage, 1)
                        lblS4No.Text = NoBillets
                    ElseIf i = 5 Then
                        lblS5OKL.Text = Math.Round(OkLength, 1)
                        lblS5OKW.Text = Math.Round(OkTonnage, 1)
                        lblS5TRL.Text = Math.Round(TransitionLength, 1)
                        lblS5TRW.Text = Math.Round(TransitionTonnage, 1)
                        lblS5No.Text = NoBillets
                    ElseIf i = 6 Then
                        lblS6OKL.Text = Math.Round(OkLength, 1)
                        lblS6OKW.Text = Math.Round(OkTonnage, 1)
                        lblS6TRL.Text = Math.Round(TransitionLength, 1)
                        lblS6TRW.Text = Math.Round(TransitionTonnage, 1)
                        lblS6No.Text = NoBillets
                    End If
                ElseIf closedstand.Length = 1
                    If i = 1 Then
                        lblS11COKL.Text = Math.Round(OkLength, 1)
                        lblS11COKW.Text = Math.Round(OkTonnage, 1)
                        lblS11CTRL.Text = Math.Round(TransitionLength, 1)
                        lblS11CTRW.Text = Math.Round(TransitionTonnage, 1)
                        lblS11CNo.Text = NoBillets
                    ElseIf i = 2 Then
                        lblS21COKL.Text = Math.Round(OkLength, 1)
                        lblS21COKW.Text = Math.Round(OkTonnage, 1)
                        lblS21CTRL.Text = Math.Round(TransitionLength, 1)
                        lblS21CTRW.Text = Math.Round(TransitionTonnage, 1)
                        lblS21CNo.Text = NoBillets
                    ElseIf i = 3 Then
                        lblS31COKL.Text = Math.Round(OkLength, 1)
                        lblS31COKW.Text = Math.Round(OkTonnage, 1)
                        lblS31CTRL.Text = Math.Round(TransitionLength, 1)
                        lblS31CTRW.Text = Math.Round(TransitionTonnage, 1)
                        lblS31CNo.Text = NoBillets
                    ElseIf i = 4 Then
                        lblS41COKL.Text = Math.Round(OkLength, 1)
                        lblS41COKW.Text = Math.Round(OkTonnage, 1)
                        lblS41CTRL.Text = Math.Round(TransitionLength, 1)
                        lblS41CTRW.Text = Math.Round(TransitionTonnage, 1)
                        lblS41CNo.Text = NoBillets
                    ElseIf i = 5 Then
                        lblS51COKL.Text = Math.Round(OkLength, 1)
                        lblS51COKW.Text = Math.Round(OkTonnage, 1)
                        lblS51CTRL.Text = Math.Round(TransitionLength, 1)
                        lblS51CTRW.Text = Math.Round(TransitionTonnage, 1)
                        lblS51CNo.Text = NoBillets
                    ElseIf i = 6 Then
                        lblS61COKL.Text = Math.Round(OkLength, 1)
                        lblS61COKW.Text = Math.Round(OkTonnage, 1)
                        lblS61CTRL.Text = Math.Round(TransitionLength, 1)
                        lblS61CTRW.Text = Math.Round(TransitionTonnage, 1)
                        lblS61CNo.Text = NoBillets
                    End If
                Else
                    If i = 1 Then
                        lblS12COKL.Text = Math.Round(OkLength, 1)
                        lblS12COKW.Text = Math.Round(OkTonnage, 1)
                        lblS12CTRL.Text = Math.Round(TransitionLength, 1)
                        lblS12CTRW.Text = Math.Round(TransitionTonnage, 1)
                        lblS12CNo.Text = NoBillets
                    ElseIf i = 2 Then
                        lblS22COKL.Text = Math.Round(OkLength, 1)
                        lblS22COKW.Text = Math.Round(OkTonnage, 1)
                        lblS22CTRL.Text = Math.Round(TransitionLength, 1)
                        lblS22CTRW.Text = Math.Round(TransitionTonnage, 1)
                        lblS22CNo.Text = NoBillets
                    ElseIf i = 3 Then
                        lblS32COKL.Text = Math.Round(OkLength, 1)
                        lblS32COKW.Text = Math.Round(OkTonnage, 1)
                        lblS32CTRL.Text = Math.Round(TransitionLength, 1)
                        lblS32CTRW.Text = Math.Round(TransitionTonnage, 1)
                        lblS32CNo.Text = NoBillets
                    ElseIf i = 4 Then
                        lblS42COKL.Text = Math.Round(OkLength, 1)
                        lblS42COKW.Text = Math.Round(OkTonnage, 1)
                        lblS42CTRL.Text = Math.Round(TransitionLength, 1)
                        lblS42CTRW.Text = Math.Round(TransitionTonnage, 1)
                        lblS42CNo.Text = NoBillets
                    ElseIf i = 5 Then
                        lblS52COKL.Text = Math.Round(OkLength, 1)
                        lblS52COKW.Text = Math.Round(OkTonnage, 1)
                        lblS52CTRL.Text = Math.Round(TransitionLength, 1)
                        lblS52CTRW.Text = Math.Round(TransitionTonnage, 1)
                        lblS52CNo.Text = NoBillets
                    ElseIf i = 6 Then
                        lblS62COKL.Text = Math.Round(OkLength, 1)
                        lblS62COKW.Text = Math.Round(OkTonnage, 1)
                        lblS62CTRL.Text = Math.Round(TransitionLength, 1)
                        lblS62CTRW.Text = Math.Round(TransitionTonnage, 1)
                        lblS62CNo.Text = NoBillets
                    End If
                End If


            Else
                If closedstand.Length = 0 Then
                    If i = 1 Then
                        lblS1OKL.Text = ""
                        lblS1OKW.Text = ""
                        lblS1TRL.Text = ""
                        lblS1TRW.Text = ""
                        lblS1No.Text = ""
                    ElseIf i = 2 Then
                        lblS2OKL.Text = ""
                        lblS2OKW.Text = ""
                        lblS2TRL.Text = ""
                        lblS2TRW.Text = ""
                        lblS2No.Text = ""
                    ElseIf i = 3 Then
                        lblS3OKL.Text = ""
                        lblS3OKW.Text = ""
                        lblS3TRL.Text = ""
                        lblS3TRW.Text = ""
                        lblS3No.Text = ""
                    ElseIf i = 4 Then
                        lblS4OKL.Text = ""
                        lblS4OKW.Text = ""
                        lblS4TRL.Text = ""
                        lblS4TRW.Text = ""
                        lblS4No.Text = ""
                    ElseIf i = 5 Then
                        lblS5OKL.Text = ""
                        lblS5OKW.Text = ""
                        lblS5TRL.Text = ""
                        lblS5TRW.Text = ""
                        lblS5No.Text = ""
                    ElseIf i = 6 Then
                        lblS6OKL.Text = ""
                        lblS6OKW.Text = ""
                        lblS6TRL.Text = ""
                        lblS6TRW.Text = ""
                        lblS6No.Text = ""
                    End If
                ElseIf closedstand.Length = 1
                    If i = 1 Then
                        lblS11COKL.Text = ""
                        lblS11COKW.Text = ""
                        lblS11CTRL.Text = ""
                        lblS11CTRW.Text = ""
                        lblS11CNo.Text = ""
                    ElseIf i = 2 Then
                        lblS21COKL.Text = ""
                        lblS21COKW.Text = ""
                        lblS21CTRL.Text = ""
                        lblS21CTRW.Text = ""
                        lblS21CNo.Text = ""
                    ElseIf i = 3 Then
                        lblS31COKL.Text = ""
                        lblS31COKW.Text = ""
                        lblS31CTRL.Text = ""
                        lblS31CTRW.Text = ""
                        lblS31CNo.Text = ""
                    ElseIf i = 4 Then
                        lblS41COKL.Text = ""
                        lblS41COKW.Text = ""
                        lblS41CTRL.Text = ""
                        lblS41CTRW.Text = ""
                        lblS41CNo.Text = ""
                    ElseIf i = 5 Then
                        lblS51COKL.Text = ""
                        lblS51COKW.Text = ""
                        lblS51CTRL.Text = ""
                        lblS51CTRW.Text = ""
                        lblS51CNo.Text = ""
                    ElseIf i = 6 Then
                        lblS61COKL.Text = ""
                        lblS61COKW.Text = ""
                        lblS61CTRL.Text = ""
                        lblS61CTRW.Text = ""
						lblS61CNo.Text = ""
                    End If
                Else
                    If i = 1 Then
                        lblS12COKL.Text = ""
                        lblS12COKW.Text = ""
                        lblS12CTRL.Text = ""
                        lblS12CTRW.Text = ""
                        lblS12CNo.Text = ""
                    ElseIf i = 2 Then
                        lblS22COKL.Text = ""
                        lblS22COKW.Text = ""
                        lblS22CTRL.Text = ""
                        lblS22CTRW.Text = ""
                        lblS22CNo.Text = ""
                    ElseIf i = 3 Then
                        lblS32COKL.Text = ""
                        lblS32COKW.Text = ""
                        lblS32CTRL.Text = ""
                        lblS32CTRW.Text = ""
                        lblS32CNo.Text = ""
                    ElseIf i = 4 Then
                        lblS42COKL.Text = ""
                        lblS42COKW.Text = ""
                        lblS42CTRL.Text = ""
                        lblS42CTRW.Text = ""
                        lblS42CNo.Text = ""
                    ElseIf i = 5 Then
                        lblS52COKL.Text = ""
                        lblS52COKW.Text = ""
                        lblS52CTRL.Text = ""
                        lblS52CTRW.Text = ""
                        lblS52CNo.Text = ""
                    ElseIf i = 6 Then
                        lblS62COKL.Text = ""
                        lblS62COKW.Text = ""
                        lblS62CTRL.Text = ""
                        lblS62CTRW.Text = ""
                        lblS62CNo.Text = ""
                    End If
                End If
            End If
        Next

        If closedstand.Length = 0 Then
            'lblOKLTot.Text = totOKL
            'lblOKWTot.Text = totOKW
            'lblTrLTot.Text = totTL
            'lblTrWTot.Text = totTW
            lblNo.Text = totNo
        ElseIf closedstand.Length = 1
            'lbl1COKLTot.Text = totOKL
            'lbl1COKWTot.Text = totOKW
            'lbl1CTrLTot.Text = totTL
            'lbl1CTrWTot.Text = totTW
            lbl1CNo.Text = totNo
        Else
            'lbl2COKLTot.Text = totOKL
            'lbl2COKWTot.Text = totOKW
            'lbl2CTrLTot.Text = totTL
            'lbl2CTrWTot.Text = totTW
            lbl2CNo.Text = totNo
        End If

    End Sub

End Class