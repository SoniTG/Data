﻿
Partial Class tpm_tscr
    Inherits System.Web.UI.Page
    Dim objCSV As New csv
    Private objController As New Controller

    Sub UserMsgBoxWarning(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "warningalert('" + Message + "');", True)
    End Sub
    Private Sub tpm_tscr_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then

            'Session("pagehit") = objController.SaveAndRetrievePageHits("", IO.Path.GetFileName(Request.Path))

            cbFromGrade.DataSource = objCSV.getList
            cbFromGrade.DataBind()

            cbToGrade.DataSource = objCSV.getList
            cbToGrade.DataBind()

            divOutput.Visible = False
        End If

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Reset()
    End Sub

    Sub Reset()
        divOutput.Visible = False
        txtCastingSpeed.Text = ""
        txtSlabWidth.Text = ""
        'cbThroughput.SelectedIndex = 0
        cbFromGrade.SelectedIndex = 0
        cbToGrade.SelectedIndex = 0

        lblTrL.Text = ""
        lblTrW.Text = ""
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        divOutput.Visible = True
        lblTW.Text = Math.Round((7020 * (txtSlabWidth.Text / 1000) * (txtSlabThickness.Text / 1000) * txtCastingSpeed.Text) / 1000, 2)
        lblCS.Text = txtCastingSpeed.Text
        lblSW.Text = txtSlabWidth.Text
        lblG.Text = cbFromGrade.SelectedItem.Text & " - " & cbToGrade.SelectedItem.Text

        DoCalculation()

        Dim okl, okw, trl, trw As String
        'Dim objCalculation As New calculation
        'objCalculation.DoCalculation(txtTundWt.Text, txtSlabWidth.Text, txtCastingSpeed.Text, cbFromGrade.SelectedItem.Text, cbToGrade.SelectedItem.Text, okw, trw, okl, trl)

        'lblOKL.Text = okl
        'lblOKW.Text = okw
        'lblTrL.Text = trl
        'lblTrW.Text = trw
    End Sub

    Sub DoCalculation()

        Dim throughput As Double = lblTW.Text

        Dim datafileidx As Integer = -1

        If throughput >= 2.26 And throughput <= 2.75 Then
            datafileidx = 0
        ElseIf throughput >= 2.76 And throughput <= 3.25 Then
            datafileidx = 1
        ElseIf throughput >= 3.26 And throughput <= 3.75 Then
            datafileidx = 2
        ElseIf throughput >= 3.76 And throughput <= 4.25 Then
            datafileidx = 3
        ElseIf throughput >= 4.26 And throughput <= 4.75 Then
            datafileidx = 4
        End If

        If datafileidx = -1 Then
            UserMsgBoxWarning("No input data found.")
            Return
        End If

        Dim s As String = objCSV.Search(cbFromGrade.SelectedItem.Text, cbToGrade.SelectedItem.Text, datafileidx)
        If (s <> "-1") Then
            Dim temp() As String = s.Split(",")

            Dim mulfactor As Double = txtTundishWt.Text / 18.0    '27.6 Changed to 18 on 22-01-24

            Dim OkTonnage = (temp(2) * 7020 * (txtSlabWidth.Text / 1000) * (txtSlabThickness.Text / 1000) * txtCastingSpeed.Text * mulfactor) / (1000)
            Dim OkLength = OkTonnage / (7.02 * (txtSlabWidth.Text / 1000) * (txtSlabThickness.Text / 1000))

            Dim TotalTimeInMin As Double = temp(3) - temp(2)
            Dim TransitionTonnage = (TotalTimeInMin * 7020 * (txtSlabWidth.Text / 1000) * (txtSlabThickness.Text / 1000) * txtCastingSpeed.Text * mulfactor) / (1000)
            Dim TransitionLength = TransitionTonnage / (7.02 * (txtSlabWidth.Text / 1000) * (txtSlabThickness.Text / 1000))

            lblTrL.Text = Math.Round(TransitionLength, 1)
            lblTrW.Text = Math.Round(TransitionTonnage, 0)

            lblOKW.Text = Math.Round(OkTonnage, 0)
            lblOKL.Text = Math.Round(OkLength, 1)
			
			if (lblTrW.Text = "0") Then
				lblOKW.Text = "0"
				lblOKL.Text ="0"
			end if
        Else
		lblTrW.Text = "0"
				lblTrL.Text ="0"
				lblOKW.Text = "0"
				lblOKL.Text ="0"
        End If
    End Sub
End Class
