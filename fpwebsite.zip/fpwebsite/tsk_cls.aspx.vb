﻿Imports System.Data
Partial Class tsk_cls
    Inherits System.Web.UI.Page
    Dim objDataHandler As New DataHandler
Dim objController As New Controller
    Dim flag As Boolean = True
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Private Sub tsk_cls_Load(sender As Object, e As EventArgs) Handles Me.Load
        flag = True
        If Page.IsPostBack Then
            Try

                Dim p As String = Request("__EVENTARGUMENT")
                If (p = "txtdate") Then
                    PopulateSlabID()
                    clearFields()
                End If

            Catch ex As Exception

            End Try
        End If
        If Not Page.IsPostBack Then
Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), IO.Path.GetFileName(Request.Path))
            flag = False
            Dim dtStart As String = DateTime.Now.AddDays(-7).ToString("yyyy-MM-dd HH:mm")
            Dim dtEnd As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
            hfFrom.Value = dtStart
            hfTo.Value = dtEnd

            Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select distinct GRADE_CODE from [FP_PROCESS_DATA].[dbo].[T_SLABCUT_INFO] where grade_code is not null order by 1").Tables(0)
            ddlGrade.DataSource = dt
            ddlGrade.DataTextField = "GRADE_CODE"
            ddlGrade.DataValueField = "GRADE_CODE"
            ddlGrade.DataBind()
            ddlGrade.Items.Insert(0, New ListItem("All", "All"))

            Dim dt1 As DataTable = objDataHandler.GetDataSetFromQuery("select slab_id from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_CLS] where l2_slab_cut_time between '" & hfFrom.Value & "' and '" & hfTo.Value & "' " & "order by l2_slab_cut_time desc").Tables(0)
            ddlSlabID.DataSource = dt1

            ddlSlabID.DataTextField = "slab_id"
            ddlSlabID.DataValueField = "slab_id"
            ddlSlabID.DataBind()

            ddlSlabID.Items.Insert(0, New ListItem("Select", "select"))

            lblCCM1.Text = "77%"
            lblCCM2.Text = "23%"
            lblCCM3.Text = "28%"
            lblCCM4.Text = "72%"

            lblICM1.Text = "64%"
            lblICM2.Text = "36%"
            lblICM3.Text = "14%"
            lblICM4.Text = "86%"
        End If
    End Sub

    Sub PopulateSlabID()
        Dim filter As String = ""
        If ddlGrade.SelectedIndex > 0 Then
            filter = " and grade='" & ddlGrade.SelectedItem.Value & "'"
        End If
        Dim dt As DataTable = objDataHandler.GetDataSetFromQuery("select slab_id from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_CLS] where l2_slab_cut_time between '" & hfFrom.Value & "' and '" & hfTo.Value & "' " & filter & "order by l2_slab_cut_time desc").Tables(0)
        ddlSlabID.DataSource = dt

        ddlSlabID.DataTextField = "slab_id"
        ddlSlabID.DataValueField = "slab_id"
        ddlSlabID.DataBind()

        ddlSlabID.Items.Insert(0, New ListItem("Select", "select"))

    End Sub

    Private Sub ddlGrade_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlGrade.SelectedIndexChanged
        If flag Then
            PopulateSlabID()
            clearFields()
        End If

    End Sub

    Private Sub clearFields()
        lblCastingSpeedMean.Text = ""
        lblGrade.Text = ""
        lblSlabCutTime.Text = ""
        lblSlabID.Text = ""
        lblAPCSS.Text = ""
        lblAPICCS.Text = ""
        lblMPCSS.Text = ""
        lblMPICCS.Text = ""
        'lblCCM1.text = ""
        'lblCCM2.Text = ""
        'lblCCM3.Text = ""
        'lblCCM4.Text = ""
        lblC.Text = ""
        lblMn.Text = ""
        lblSi.Text = ""
        lblP.Text = ""
        lblS.Text = ""
        lblN.Text = ""
        lblNb.Text = ""
        lblV.Text = ""
        lblTi.Text = ""
        lblCu.Text = ""
        lblNi.Text = ""
        lblCr.Text = ""
        lblMo.Text = ""
        lblSCW.Text = ""

        lit1.Text = ""
        lit2.Text = ""
        lit3.Text = ""
        lit4.Text = ""
        lit5.Text = ""
        lit6.Text = ""
        lit7.Text = ""


    End Sub

    'Private Sub txtDate_TextChanged(sender As Object, e As EventArgs) Handles txtDate.TextChanged
    '    If flag Then
    '        PopulateSlabID()
    '        clearFields()
    '    End If

    'End Sub

    Private Sub ddlSlabID_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlSlabID.SelectedIndexChanged
        If flag Then
            clearFields()
            If ddlSlabID.SelectedIndex > 0 Then
                Dim slabid As String = ddlSlabID.SelectedItem.Value
                Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("SELECT casting_speed_mean FROM [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB] where slab_id='" & slabid & "';SELECT * FROM [FP_PROCESS_DATA].[dbo].[T_SLABCUT_INFO] WHERE SLAB_ID='" & slabid & "';select * from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_CLS] where slab_id='" & slabid & "';select ((scw_flow_zone_1_mean + scw_flow_zone_2_0_mean + scw_flow_zone_2_1_mean + scw_flow_zone_3_0_mean + scw_flow_zone_3_1_mean + scw_flow_zone_3_2_mean + scw_flow_zone_4_0_mean + scw_flow_zone_4_1_mean + scw_flow_zone_4_2_mean + scw_flow_zone_5_0_mean + scw_flow_zone_5_1_mean + scw_flow_zone_5_2_mean + scw_flow_zone_6_mean + scw_flow_zone_7_mean + scw_flow_zone_8_mean + scw_flow_zone_9_mean + scw_flow_zone_10_mean + scw_flow_zone_11_mean + scw_flow_zone_12_mean + scw_flow_zone_13_mean + scw_flow_zone_14_mean)/(casting_speed_mean*0.239*(BOC_width_mean/1000)*7085)) from [FP_PROCESS_DATA].[dbo].[T_TSK_SMS_SLAB] where slab_id='" & slabid & "';")
                lblSlabID.Text = slabid
                If ds.Tables(0).Rows.Count > 0 Then
                    lblCastingSpeedMean.Text = ds.Tables(0).Rows(0)(0)

                End If
                If ds.Tables(1).Rows.Count > 0 Then
                    lblGrade.Text = ds.Tables(1).Rows(0)("grade_code")
                    lblSlabCutTime.Text = CDate(ds.Tables(1).Rows(0)("cut_time")).ToString("dd-MMM-yyyy HH:mm:ss")

                    lblC.Text = RoundVal(ds.Tables(1).Rows(0)("C").ToString(), 3)
                    lblMn.Text = RoundVal(ds.Tables(1).Rows(0)("MN").ToString(), 3)
                    lblSi.Text = RoundVal(ds.Tables(1).Rows(0)("SI").ToString(), 3)
                    lblP.Text = RoundVal(ds.Tables(1).Rows(0)("P").ToString(), 3)
                    lblS.Text = RoundVal(ds.Tables(1).Rows(0)("S").ToString(), 3)
                    lblN.Text = RoundVal(ds.Tables(1).Rows(0)("N").ToString(), 0)
                    lblNb.Text = RoundVal(ds.Tables(1).Rows(0)("NB").ToString(), 3)
                    lblV.Text = RoundVal(ds.Tables(1).Rows(0)("V").ToString(), 3)
                    lblTi.Text = RoundVal(ds.Tables(1).Rows(0)("TI").ToString(), 3)
                    lblCu.Text = RoundVal(ds.Tables(1).Rows(0)("CU").ToString(), 3)
                    lblNi.Text = RoundVal(ds.Tables(1).Rows(0)("NI").ToString(), 3)
                    lblCr.Text = RoundVal(ds.Tables(1).Rows(0)("CR").ToString(), 3)
                    lblMo.Text = RoundVal(ds.Tables(1).Rows(0)("MO").ToString(), 3)


                End If
                If ds.Tables(2).Rows.Count > 0 Then
                    If Not isdbnull(ds.Tables(2).Rows(0)("cls_pred")) Then lblMPCSS.Text = IIf(ds.Tables(2).Rows(0)("cls_pred") = 1, "High", "Low")
                    If Not isdbnull(ds.Tables(2).Rows(0)("icc_pred")) Then lblMPICCS.Text = IIf(ds.Tables(2).Rows(0)("icc_pred") = 1, "High", "Low")
                    If ds.Tables(1).Rows.Count = 0 Then
                        lblGrade.Text = ds.Tables(2).Rows(0)("grade")
                        lblSlabCutTime.Text = CDate(ds.Tables(2).Rows(0)("l2_slab_cut_time")).ToString("dd-MMM-yyyy HH:mm:ss")
                    End If

                End If
                If ds.Tables(3).Rows.Count > 0 Then
                    lblSCW.Text = Math.Round(ds.Tables(3).Rows(0)(0), 2)
                End If

                PrepareBoxPlot()
            End If
        End If

    End Sub

    Private Function RoundVal(str As String, places As Integer) As String
        If str = "" Then
            Return ""
        End If
        Return Math.Round(CDec(str), places)
    End Function

    Sub PrepareBoxPlot()
        Dim slabid As String = ddlSlabID.SelectedItem.Value
        Dim ds As DataSet = objDataHandler.GetDataSetFromQuery("SELECT ROUND(hsa_speed_q0,2),ROUND(hsa_speed_q1,2),ROUND(hsa_speed_q2,2),ROUND(hsa_speed_q3,2),ROUND(hsa_speed_q4,2),hsa_speed_out FROM [FP_PROCESS_DATA].[dbo].T_TSK_SMS_SLAB_EXT WHERE SLAB_ID='" & slabid & "';SELECT ROUND(hsa_speed_mean,2) FROM [FP_PROCESS_DATA].[dbo].T_TSK_SMS_SLAB WHERE SLAB_ID='" & slabid & "'")

        Dim ds1 As DataSet = objDataHandler.GetDataSetFromQuery("SELECT total_soft_reduction_act_q0,total_soft_reduction_act_q1,total_soft_reduction_act_q2,total_soft_reduction_act_q3,total_soft_reduction_act_q4,total_soft_reduction_act_out" &
            " FROM [FP_PROCESS_DATA].[dbo].T_TSK_SMS_SLAB WHERE SLAB_ID='" & slabid & "';SELECT total_soft_reduction_act_mean FROM [FP_PROCESS_DATA].[dbo].T_TSK_SMS_SLAB WHERE SLAB_ID='" & slabid & "'")

        Dim ds2 As DataSet = objDataHandler.GetDataSetFromQuery("SELECT scw_flow_zone_13_q0,scw_flow_zone_13_q1,scw_flow_zone_13_q2,scw_flow_zone_13_q3,scw_flow_zone_13_q4,scw_flow_zone_13_out" &
            " FROM [FP_PROCESS_DATA].[dbo].T_TSK_SMS_SLAB_EXT WHERE SLAB_ID='" & slabid & "';SELECT scw_flow_zone_13_mean FROM [FP_PROCESS_DATA].[dbo].T_TSK_SMS_SLAB WHERE SLAB_ID='" & slabid & "'")

        Dim ds3 As DataSet = objDataHandler.GetDataSetFromQuery("SELECT scw_flow_zone_14_q0,scw_flow_zone_14_q1,scw_flow_zone_14_q2,scw_flow_zone_14_q3,scw_flow_zone_14_q4,scw_flow_zone_14_out" &
            " FROM [FP_PROCESS_DATA].[dbo].T_TSK_SMS_SLAB_EXT WHERE SLAB_ID='" & slabid & "';SELECT scw_flow_zone_14_mean FROM [FP_PROCESS_DATA].[dbo].T_TSK_SMS_SLAB WHERE SLAB_ID='" & slabid & "'")

        Dim ds4 As DataSet = objDataHandler.GetDataSetFromQuery("SELECT hsa_force_10_el_q0,hsa_force_10_el_q1,hsa_force_10_el_q2,hsa_force_10_el_q3,hsa_force_10_el_q4,hsa_force_10_el_out" &
            " FROM [FP_PROCESS_DATA].[dbo].T_TSK_SMS_SLAB_EXT WHERE SLAB_ID='" & slabid & "';SELECT hsa_force_10_el_mean FROM [FP_PROCESS_DATA].[dbo].T_TSK_SMS_SLAB WHERE SLAB_ID='" & slabid & "'")

        Dim ds5 As DataSet = objDataHandler.GetDataSetFromQuery("SELECT hsa_force_10_er_q0,hsa_force_10_er_q1,hsa_force_10_er_q2,hsa_force_10_er_q3,hsa_force_10_er_q4,hsa_force_10_er_out" &
            " FROM [FP_PROCESS_DATA].[dbo].T_TSK_SMS_SLAB_EXT WHERE SLAB_ID='" & slabid & "';SELECT hsa_force_10_er_mean FROM [FP_PROCESS_DATA].[dbo].T_TSK_SMS_SLAB WHERE SLAB_ID='" & slabid & "'")

        Dim ds6 As DataSet = objDataHandler.GetDataSetFromQuery("SELECT tundish_liq_temp_q0,tundish_liq_temp_q1,tundish_liq_temp_q2,tundish_liq_temp_q3,tundish_liq_temp_q4,tundish_liq_temp_out" &
            " FROM [FP_PROCESS_DATA].[dbo].T_TSK_SMS_SLAB_EXT WHERE SLAB_ID='" & slabid & "';SELECT tundish_liq_temp_mean - tundish_liquidus_temp_mean,tundish_liquidus_temp_mean FROM [FP_PROCESS_DATA].[dbo].T_TSK_SMS_SLAB WHERE SLAB_ID='" & slabid & "'")



        If ds.Tables(0).Rows.Count > 0 Then
            lit1.Text = getBoxPlotString(ds.Tables(0), ds.Tables(1).Rows(0)(0).ToString(), "b1", "1")
            lit3.Text = getBoxPlotString(ds1.Tables(0), ds1.Tables(1).Rows(0)(0).ToString(), "b3", "3")
            lit4.Text = getBoxPlotString(ds2.Tables(0), ds2.Tables(1).Rows(0)(0).ToString(), "b4", "4")
            lit5.Text = getBoxPlotString(ds3.Tables(0), ds3.Tables(1).Rows(0)(0).ToString(), "b5", "5")
            lit6.Text = getBoxPlotString(ds4.Tables(0), ds4.Tables(1).Rows(0)(0).ToString(), "b6", "6")
            lit7.Text = getBoxPlotString(ds5.Tables(0), ds5.Tables(1).Rows(0)(0).ToString(), "b7", "7")

            For c As Integer = 0 To ds6.Tables(0).Columns.Count - 2
                ds6.Tables(0).Rows(0)(c) -= ds6.Tables(1).Rows(0)(1)
            Next

            lit2.Text = getBoxPlotString(ds6.Tables(0), ds6.Tables(1).Rows(0)(0).ToString(), "b2", "2")
        End If




    End Sub

    Function getBoxPlotString(ByVal dt As DataTable, ByVal meanval As String, ByVal container As String, ByVal idx As String) As String
        Dim retval As String = ""
        'meanval = 0.5
        Try
            Dim data As String = "[" & dt.Rows(0)(0) & "," & dt.Rows(0)(1) & "," & dt.Rows(0)(2) & "," & dt.Rows(0)(3) & "," & dt.Rows(0)(4) & "]"
            Dim csvoutlier As String = dt.Rows(0)(5).ToString().Replace("NA", "")
            Dim outliers As String = ""
            If csvoutlier.Length > 0 And container = "b2" Then
				outliers = ""
                For Each s As String In csvoutlier.Split(",")
					If CDbl(s) < 100 Then
						outliers &= ",[0," & s & "]"
					End If
                Next
				If outliers.Length > 0 Then
					outliers = "[" & outliers.Substring(1) & "]"
				Else
					outliers = "[]"
				End If
			Else If csvoutlier.Length > 0 Then
				For Each s As String In csvoutlier.Split(",")
					outliers &= ",[0," & s & "]"
				Next
				outliers = "[" & outliers.Substring(1) & "]"
            Else
                outliers = "[]"
            End If


            ' retval &= "<script>var option" & idx & "={backgroundColor:'#FFF9CA',tooltip:{trigger:'item',position:'right',axisPointer:{type:'shadow'}},grid: {top:'10%',bottom:'10%',left: '10%',right: '10%',},xAxis:{type:'category',data:['0'],boundaryGap:true,show:!1},yAxis:{type:'value',show:!1},series:[{name:'boxplot',type:'boxplot',itemStyle:{borderColor:'#007ACC'},data:[" & data & "],tooltip:{formatter:function(a){console.log(a);return['upper: '+a.data[5],'Q3: '+a.data[4],'median: '+a.data[3],'Q1: '+a.data[2],'lower: '+a.data[1]].join('<br/>')}},markPoint:{symbol:'diamond',silent:true,label:{show:false},symbolSize:10,data:[{name:'mean',coord:[0," & meanval & "]}]}},{name:'outlier',type:'scatter',data:" & outliers & "}]}; var crt" & idx & "=document.getElementById('" & container & "');var mycrt" & idx & "=echarts.init(crt" & idx & ");mycrt" & idx & ".setOption(option" & idx & ");</script>"
            retval &= "<script>var option" & idx & "={toolbox: {show: true, itemSize: 8, top: -8, right: -7, feature: {dataZoom: {}}}, backgroundColor:'#FFF9CA',tooltip:{trigger:'item',position:'right',axisPointer:{type:'shadow'}},grid: {top:'5%',bottom:'5%',left: '27%',right: 0,},xAxis:{type:'category',data:['0'],boundaryGap:true,show:!1},yAxis:{type:'value', scale: true},series:[{name:'boxplot',type:'boxplot',itemStyle:{borderColor:'#007ACC'},data:[" & data & "],tooltip:{formatter:function(a){return['upper: '+a.data[5],'Q3: '+a.data[4],'median: '+a.data[3],'Q1: '+a.data[2],'lower: '+a.data[1]].join('<br/>')}},markPoint:{symbol:'diamond',silent:true,label:{show:false},symbolSize:10,data:[{name:'mean',coord:[0," & meanval & "]}]}},{name:'outlier',type:'scatter',data:" & outliers & ", color: '#007ACC', symbolSize: 5}]}; var crt" & idx & "=document.getElementById('" & container & "');var mycrt" & idx & "=echarts.init(crt" & idx & ");mycrt" & idx & ".setOption(option" & idx & ");</script>"
            Return retval
        Catch ex As Exception
            Return ""
        End Try
    End Function
End Class
