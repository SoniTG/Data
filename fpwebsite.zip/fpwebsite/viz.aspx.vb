﻿Imports System
Imports System.Data
Imports System.IO

Partial Class _analysis
    Inherits System.Web.UI.Page
    Dim message As String = ""
    Dim flag As Boolean = False
    Dim ObjController As New Controller
    Dim Ylabel As String
    Dim ChartTitle As String

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Session("pagehit") = ObjController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
            fillColumns()

        End If

        'lblHeading.Text = ""
    End Sub
    Public Function validateDate(ByRef txtFrmDt As TextBox, ByRef txtToDt As TextBox) As Boolean

        If txtFrmDt.Text = "" Then
            message = "From DateTime text box  should not be empty"
            txtFrmDt.Focus()
            Return False
        ElseIf txtToDt.Text = "" Then
            message = "To DateTime text box  should not be empty"
            txtToDt.Focus()
            Return False

        End If

        Dim Frm_Datetime As String = txtFrmDt.Text
        Dim To_Datetime As String = txtToDt.Text
        Dim f_dttime As DateTime = Frm_Datetime
        Dim t_dttime As DateTime = To_Datetime
        If DateTime.Compare(f_dttime, t_dttime) > 0 Then
            message = "From Date Time should be less then To Date Time"
            txtToDt.Focus()
            Return False
        Else
            flag = True
            Return True
        End If
    End Function

    Sub fillColumns()
        ObjController.GetColumnNames(listboxColumName, Session("TableName"))

    End Sub
    Sub openShapeModal()
        Dim sb As New StringBuilder()
        sb.Append("<script type='text/javascript'>")
        sb.Append("$('#ColumnName').modal('show');")
        sb.Append("</script>")
        ScriptManager.RegisterClientScriptBlock(Me, Me.GetType(), "ShowModal", sb.ToString(), False)
    End Sub
    Sub CloseShapeModal()
        Dim sb As New StringBuilder()
        sb.Append("<script type='text/javascript'>")
        sb.Append("$('#DivChartHeading').modal('hide');")
        sb.Append("</script>")
        ScriptManager.RegisterClientScriptBlock(Me, Me.GetType(), "HideModal", sb.ToString(), False)
    End Sub
    Protected Sub listboxColumName_SelectedIndexChanged(sender As Object, e As EventArgs) Handles listboxColumName.SelectedIndexChanged
        addlistbox()
    End Sub
    Sub addlistbox()

        If listboxColumName.Items.Count > 0 Then
            For ir As Integer = 0 To listboxColumName.Items.Count - 1
                If listboxColumName.Items(ir).Selected = True Then
                    If hf1.Value = "xColumnNames" Then
                        listXAxis.Items.Add(listboxColumName.Items(ir).ToString())

                    ElseIf hf1.Value = "yColumnNames" Then
                        listYAsis.Items.Add(listboxColumName.Items(ir).ToString())
                    ElseIf hf1.Value = "zColumnNames" Then
                        listZAxis.Items.Add(listboxColumName.Items(ir).ToString())

                    ElseIf hf1.Value = "LegendColor" Then
                        listLegendColor.Items.Add(listboxColumName.Items(ir).ToString())
                    End If
                Else
                    'Exit For
                End If
            Next
            listboxColumName.SelectedIndex = -1
        Else
            Exit Sub
        End If
    End Sub

    Sub DrawChart(ByVal Filter As String)
        Try
            Dim ycolumn As String = listYAsis.SelectedItem.Text
            Dim strfrmDt As String = txtFromDatetime.Text.Trim
            Dim strToDt As String = txtToDatetime.Text.Trim

            Dim dt As DataTable = ObjController.GetWetChemicalTestData(Session("TableName"), strfrmDt, strToDt, Session("DateColumn"), Filter)
            Dim dv As DataView = dt.DefaultView
            dv.RowFilter = "CLR_PARAM_TEST='ZAAL' AND " & ycolumn & "<1"
            Dim dtAL As DataTable = dv.ToTable

            dt.DefaultView.RowFilter = String.Empty
            dv = dt.DefaultView
            dv.RowFilter = "CLR_PARAM_TEST='ZAFE' AND " & listYAsis.SelectedItem.Text & "<1"
            Dim dtFE As DataTable = dv.ToTable

            ObjController.PlotLineChart(dtAL, listXAxis.SelectedItem.Text.ToString(), listYAsis.SelectedItem.Text.ToString(), Lit1, "DivChart", "plot1", ViewState("Title"), ViewState("YAxisLabel"))

        Catch ex As Exception

        End Try
    End Sub


    Sub DrawScatterChart(ByVal Filter As String)
        Try
            Dim ycolumn As String = listYAsis.SelectedItem.Text
            Dim strfrmDt As String = txtFromDatetime.Text.Trim
            Dim strToDt As String = txtToDatetime.Text.Trim

            Dim dt As DataTable = ObjController.GetWetChemicalTestData(Session("TableName"), strfrmDt, strToDt, Session("DateColumn"), Filter)
            Dim dv As DataView = dt.DefaultView
            dv.RowFilter = "CLR_PARAM_TEST='ZAAL' AND " & ycolumn & "<1"
            Dim dtAL As DataTable = dv.ToTable

            dt.DefaultView.RowFilter = String.Empty
            dv = dt.DefaultView
            dv.RowFilter = "CLR_PARAM_TEST='ZAFE' AND " & listYAsis.SelectedItem.Text & "<1"
            Dim dtFE As DataTable = dv.ToTable

            ObjController.PlotScatterChart(dtAL, listXAxis.SelectedItem.Text.ToString(), listYAsis.SelectedItem.Text.ToString(), Lit1, "DivChart", "plot1", ViewState("Title"), ViewState("YAxisLabel"))

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnColunchart_Click(sender As Object, e As EventArgs) Handles btnColunchart.Click
        lblXAxis.Visible = True
        listXAxis.Visible = True
        x.Visible = True
        lblYAxis.Text = "Y Axis"
        lblLegendShape.Visible = False
        listLegendShape.Visible = False
        ls.Visible = False
        lblZAxis.Visible = False
        listZAxis.Visible = False
        z.Visible = False
    End Sub

    Protected Sub btnStackedColumn_Click(sender As Object, e As EventArgs) Handles btnStackedColumn.Click
        lblXAxis.Visible = True
        listXAxis.Visible = True
        x.Visible = True
        lblYAxis.Text = "Y Axis"
        lblLegendShape.Visible = False
        listLegendShape.Visible = False
        ls.Visible = False
        lblZAxis.Visible = False
        listZAxis.Visible = False
        z.Visible = False
    End Sub

    Protected Sub btnLineChart_Click(sender As Object, e As EventArgs) Handles btnLineChart.Click
        'LinkButton1.CssClass = "green"
        lblXAxis.Visible = True
        listXAxis.Visible = True
        x.Visible = True
        lblYAxis.Text = "Y Axis"
        lblLegendShape.Visible = False
        listLegendShape.Visible = False
        ls.Visible = False
        lblZAxis.Visible = False
        listZAxis.Visible = False
        z.Visible = False
        DrawChart("")
    End Sub

    Protected Sub btnLineChart2YAxis_Click(sender As Object, e As EventArgs) Handles btnLineChart2YAxis.Click
        lblXAxis.Visible = True
        listXAxis.Visible = True
        x.Visible = True
        lblYAxis.Text = "Y Axis"
        lblZAxis.Visible = True
        listZAxis.Visible = True
        z.Visible = True
        lblZAxis.Text = "Y Axis 1"
        lblLegendShape.Visible = False
        listLegendShape.Visible = False
        ls.Visible = False
    End Sub

    Protected Sub btnPieChart_Click(sender As Object, e As EventArgs) Handles btnPieChart.Click
        lblXAxis.Visible = False
        listXAxis.Visible = False
        x.Visible = False
        lblYAxis.Text = "Pie Sectors"
        lblLegendShape.Visible = False
        listLegendShape.Visible = False
        ls.Visible = False
        lblZAxis.Visible = False
        listZAxis.Visible = False
        z.Visible = False

    End Sub

    Protected Sub btnDonutChart_Click(sender As Object, e As EventArgs) Handles btnDonutChart.Click
        lblXAxis.Visible = False
        listXAxis.Visible = False
        x.Visible = False
        lblYAxis.Text = "Pie Sectors"
        lblLegendShape.Visible = False
        listLegendShape.Visible = False
        ls.Visible = False
        lblZAxis.Visible = False
        listZAxis.Visible = False
        z.Visible = False
    End Sub

    Protected Sub btnBubbleChart_Click(sender As Object, e As EventArgs) Handles btnBubbleChart.Click
        lblXAxis.Visible = True
        listXAxis.Visible = True
        x.Visible = True
        lblYAxis.Text = "Y Axis"
        lblZAxis.Text = "Z Axis"
        lblZAxis.Visible = True
        listZAxis.Visible = True
        z.Visible = True
        lblLegendShape.Visible = True
        listLegendShape.Visible = True
        ls.Visible = True
    End Sub

    Protected Sub btnScatterChart_Click(sender As Object, e As EventArgs) Handles btnScatterChart.Click


        lblXAxis.Visible = True
        listXAxis.Visible = True
        x.Visible = True
        lblYAxis.Text = "Y Axis"
        lblLegendShape.Visible = True
        listLegendShape.Visible = True
        ls.Visible = True
        lblZAxis.Visible = False
        listZAxis.Visible = False
        z.Visible = False
        DrawScatterChart("")
    End Sub

    Protected Sub btnBoxPlot_Click(sender As Object, e As EventArgs) Handles btnBoxPlot.Click
        lblXAxis.Visible = True
        listXAxis.Visible = True
        x.Visible = True
        lblYAxis.Text = "Y Axis"
        lblLegendShape.Visible = False
        listLegendShape.Visible = False
        ls.Visible = False
        lblZAxis.Visible = False
        listZAxis.Visible = False
        z.Visible = False
    End Sub

    Protected Sub txtChartHeading_TextChanged(sender As Object, e As EventArgs) Handles txtChartHeading.TextChanged

        'If hf1.Value = "ChartTitle" Then
        '    ChartTitle = txtChartHeading.Text.ToUpper()

        '    'ElseIf hf1.Value = "YAxisLabel" Then
        '    '    'txtChartHeading.Text = ""
        '    '    txtYAxisLabel.Visible = True
        '    '    Ylabel = txtYAxisLabel.Text.ToUpper()
        'End If
        'If btnChartTitle.Text = "Chart Title" Then
        ChartTitle = txtChartHeading.Text.ToUpper()
        ViewState("Title") = ChartTitle
        'End If

        DrawChart("")
        DrawScatterChart("")
    End Sub

    Protected Sub txtYAxisLabel_TextChanged(sender As Object, e As EventArgs) Handles txtYAxisLabel.TextChanged
        ''If hf1.Value = "ChartTitle" Then
        ''    ChartTitle = txtChartHeading.Text.ToUpper()
        ''If hf1.Value = "YAxisLabel" Then
        ''    'txtChartHeading.Text = ""
        ''    txtChartHeading.Visible = False
        ''    txtYAxisLabel.Visible = True
        ''    Ylabel = txtYAxisLabel.Text.ToUpper()
        ''End If

        'If btnYAxisLabel.Text = "Y Axis Label" Then
        Ylabel = txtYAxisLabel.Text.ToUpper()
        ViewState("YAxisLabel") = Ylabel
        'End If
        DrawChart("")
        DrawScatterChart("")
    End Sub

    Protected Sub lnkFilter_Click(sender As Object, e As EventArgs) Handles lnkFilter.Click

    End Sub
End Class
