﻿Imports System.Data
Imports System.IO

Partial Class wetchemtestchart
    Inherits System.Web.UI.Page
    Dim objController As New Controller
    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Try

                Session("pagehit") = objController.SaveAndRetrievePageHits(Session("LoginTime"), Path.GetFileName(Request.Path))
                txtFrom.Text = Now.AddDays(-30).ToString("yyyy-MM-dd HH:mm:ss")
                'txtFrom.Text = Now.AddMonths(-4).ToString("yyyy-MM-dd HH:mm:ss")
                txtTo.Text = Now.ToString("yyyy-MM-dd HH:mm:ss")
                Dim arrFilters() As String = objController.GetFilterColumnArray("FP_MASTER_DATA", Session("SubDivId"))
                LoadFilterColumns(ddlFilterCol1, arrFilters)
                LoadFilterColumns(ddlFilterCol2, arrFilters)
                LoadFilterColumns(ddlFilterCol3, arrFilters)
                LoadFilterColumns(ddlFilterCol4, arrFilters)
                LoadFilterColumns(ddlFilterCol5, arrFilters)
                LoadFilterColumns(ddlFilterCol6, arrFilters)
                'LoadColourColumn(ddlColour1)
                'LoadColourColumn(ddlSecColour)
                Label2.Visible = False
                ddlColour1.Visible = False
                lblSecColour.Visible = False
                ddlSecColour.Visible = False

                If Session("SelectVal") = "CGL" Then
                    'ddlFilterCol1.SelectedIndex = 1
                    ''ddlFilterCol1.Items.FindByText("CLR_PROCESS_LINE").Selected = True
                    'ddlFilterCol1_SelectedIndexChanged(sender, e)
                    'ddlFilterColVal1.Items.FindByText("L").Selected = True
                    'ddlFilterCol1.Enabled = False
                    'ddlFilterColVal1.Enabled = False
                    'ddlFilterCol2.SelectedIndex = 2
                    'ddlFilterCol2_SelectedIndexChanged(sender, e)
                    'ddlFilterColVal2.Items.FindByText("ZAAL").Selected = True
                    'ddlFilterCol2.Enabled = False
                    'ddlFilterColVal2.Enabled = False
                    'btnGo_Click(sender, e)

                    'ddlFilterCol4.SelectedIndex = 1
                    ''ddlFilterCol1.Items.FindByText("CLR_PROCESS_LINE").Selected = True
                    'ddlFilterCol4_SelectedIndexChanged(sender, e)
                    'ddlFilterColVal4.Items.FindByText("L").Selected = True
                    'ddlFilterCol4.Enabled = False
                    'ddlFilterColVal4.Enabled = False
                    'ddlFilterCol5.SelectedIndex = 2
                    'ddlFilterCol5_SelectedIndexChanged(sender, e)
                    'ddlFilterColVal5.Items.FindByText("ZAAL").Selected = True
                    'ddlFilterCol5.Enabled = False
                    'ddlFilterColVal5.Enabled = False
                    'btnSecGo_Click(sender, e)
                    ddlFilterCol1.SelectedValue = "CLR_PROCESS_LINE"
                    ddlFilterCol1_SelectedIndexChanged(sender, e)
                    ddlFilterCol2.SelectedValue = "CLR_PARAM_TEST"
                    ddlFilterCol2_SelectedIndexChanged(sender, e)
                    ddlFilterCol3.SelectedValue = "CLR_PARAM_TEST"
                    ddlFilterCol3_SelectedIndexChanged(sender, e)

                    ddlFilterCol4.SelectedValue = "CLR_PROCESS_LINE"
                    ddlFilterCol4_SelectedIndexChanged(sender, e)
                    ddlFilterCol5.SelectedValue = "CLR_PARAM_TEST"
                    ddlFilterCol5_SelectedIndexChanged(sender, e)
                    ddlFilterCol6.SelectedValue = "CLR_PARAM_TEST"
                    ddlFilterCol6_SelectedIndexChanged(sender, e)

                    ddlFilterCol1.Items.Remove("CLR_PARAM_TEST")
                    ddlFilterCol2.Items.Remove("CLR_PROCESS_LINE")
                    ddlFilterCol3.Items.Remove("CLR_PROCESS_LINE")
                    ddlFilterCol5.Items.Remove("CLR_PROCESS_LINE")
                    ddlFilterCol6.Items.Remove("CLR_PROCESS_LINE")
                    ddlFilterCol1.Enabled = False
                    ddlFilterCol2.Enabled = False
                    ddlFilterCol3.Enabled = False
                    ddlFilterCol4.Enabled = False
                    ddlFilterCol5.Enabled = False
                    ddlFilterCol6.Enabled = False
                    button2.Visible = False
                    'container1.Visible = False
                    'container3.Visible = False
                    divstd.Style("display") = "none"
                    container1.Style("display") = "none"
                    container3.Style("display") = "none"
                    button3.Visible = False
                    divpitch.Attributes("class") = "col-lg-12"

                ElseIf Session("SelectVal") = "CGL1" Then
                    'Try
                    ddlFilterCol1.SelectedIndex = 1
                    ddlFilterCol1_SelectedIndexChanged(sender, e)
                    ddlFilterColVal1.Items.FindByText("G").Selected = True
                    ddlFilterCol2.SelectedIndex = 2
                    ddlFilterCol2_SelectedIndexChanged(sender, e)
                    ddlFilterColVal2.Items.FindByText("Aluminium").Selected = True
                    ddlFilterCol3.SelectedIndex = 2
                    ddlFilterCol3_SelectedIndexChanged(sender, e)
                    ddlFilterColVal3.Items.FindByText("Iron").Selected = True
                    'Catch ex As Exception

                    'End Try

                    ddlFilterCol1.Enabled = False
                    ddlFilterColVal1.Enabled = False
                    ddlFilterCol2.Enabled = False
                    ddlFilterColVal2.Enabled = False
                    ddlFilterCol3.Enabled = False
                    ddlFilterColVal3.Enabled = False
                    btnGo_Click(sender, e)

                    'ddlFilterCol4.SelectedIndex = 1
                    ''ddlFilterCol1.Items.FindByText("CLR_PROCESS_LINE").Selected = True
                    'ddlFilterCol4_SelectedIndexChanged(sender, e)
                    'ddlFilterColVal4.Items.FindByText("L").Selected = True
                    'ddlFilterCol4.Enabled = False
                    'ddlFilterColVal4.Enabled = False
                    'ddlFilterCol5.SelectedIndex = 2
                    'ddlFilterCol5_SelectedIndexChanged(sender, e)
                    'ddlFilterColVal5.Items.FindByText("ZAAL").Selected = True
                    'ddlFilterCol5.Enabled = False
                    'ddlFilterColVal5.Enabled = False
                    'btnSecGo_Click(sender, e)
                    ddlFilterCol4.Visible = False
                    ddlFilterColVal4.Visible = False
                    ddlFilterCol5.Visible = False
                    ddlFilterColVal5.Visible = False
                    ddlFilterCol6.Visible = False
                    ddlFilterColVal6.Visible = False
                    btnSecGo.Visible = False
                    container2.Visible = False
                    container3.Visible = False
                    lblSecChartTitle.Visible = False
                    txtSecChartTitle.Visible = False
                    lblSecColour.Visible = False
                    ddlSecColour.Visible = False
                    ddlFilterCol2.Items.Remove("CLR_PROCESS_LINE")
                    ddlFilterCol3.Items.Remove("CLR_PROCESS_LINE")
                    ddlFilterCol5.Items.Remove("CLR_PROCESS_LINE")
                    ddlFilterCol6.Items.Remove("CLR_PROCESS_LINE")
                ElseIf Session("SelectVal") = "CGL2" Then
                    ddlFilterCol1.SelectedIndex = 1
                    'ddlFilterCol1.Items.FindByText("CLR_PROCESS_LINE").Selected = True
                    ddlFilterCol1_SelectedIndexChanged(sender, e)
                    ddlFilterColVal1.Items.FindByText("L").Selected = True
                    ddlFilterCol1.Enabled = False
                    ddlFilterColVal1.Enabled = False
                    ddlFilterCol2.SelectedIndex = 2
                    ddlFilterCol2_SelectedIndexChanged(sender, e)
                    ddlFilterColVal2.Items.FindByText("Aluminium").Selected = True
                    ddlFilterCol2.Enabled = False
                    ddlFilterColVal2.Enabled = False
                    ddlFilterCol3.SelectedIndex = 2
                    ddlFilterCol3_SelectedIndexChanged(sender, e)
                    ddlFilterColVal3.Items.FindByText("Iron").Selected = True
                    ddlFilterCol3.Enabled = False
                    ddlFilterColVal3.Enabled = False
                    btnGo_Click(sender, e)

                    'ddlFilterCol4.SelectedIndex = 1
                    ''ddlFilterCol1.Items.FindByText("CLR_PROCESS_LINE").Selected = True
                    'ddlFilterCol4_SelectedIndexChanged(sender, e)
                    'ddlFilterColVal4.Items.FindByText("G").Selected = True
                    'ddlFilterCol4.Enabled = False
                    'ddlFilterColVal4.Enabled = False
                    'ddlFilterCol5.SelectedIndex = 2
                    'ddlFilterCol5_SelectedIndexChanged(sender, e)
                    'ddlFilterColVal5.Items.FindByText("ZAAL").Selected = True
                    'ddlFilterCol5.Enabled = False
                    'ddlFilterColVal5.Enabled = False
                    'btnSecGo_Click(sender, e

                    ddlFilterCol4.Visible = False
                    ddlFilterColVal4.Visible = False
                    ddlFilterCol5.Visible = False
                    ddlFilterColVal5.Visible = False
                    ddlFilterCol6.Visible = False
                    ddlFilterColVal6.Visible = False
                    btnSecGo.Visible = False
                    container2.Visible = False
                    container3.Visible = False
                    lblSecChartTitle.Visible = False
                    txtSecChartTitle.Visible = False
                    lblSecColour.Visible = False
                    ddlSecColour.Visible = False

                    ddlFilterCol2.Items.Remove("CLR_PROCESS_LINE")
                    ddlFilterCol3.Items.Remove("CLR_PROCESS_LINE")
                    ddlFilterCol5.Items.Remove("CLR_PROCESS_LINE")
                    ddlFilterCol6.Items.Remove("CLR_PROCESS_LINE")
                ElseIf Session("SelectVal") = "PLTCM" Then
                    ddlFilterCol1.SelectedIndex = 1
                    'ddlFilterCol1.Items.FindByText("CLR_PROCESS_LINE").Selected = True

                    ddlFilterCol1_SelectedIndexChanged(sender, e)
                    ddlFilterColVal1.Items.FindByText("P").Selected = True
                    ddlFilterCol1.Enabled = False
                    ddlFilterColVal1.Enabled = False
                    ddlFilterCol2.SelectedIndex = 2
                    ddlFilterCol2_SelectedIndexChanged(sender, e)
                    ddlFilterColVal2.Items.FindByText("HCL Acid T1").Selected = True
                    ddlFilterCol2.Enabled = False
                    ddlFilterColVal2.Enabled = False
                    'ddlFilterCol3.SelectedIndex = 2
                    'ddlFilterCol3_SelectedIndexChanged(sender, e)
                    'ddlFilterColVal3.Items.FindByText("Iron").Selected = True
                    ddlFilterCol3.Enabled = False
                    ddlFilterColVal3.Enabled = False
                    btnGo_Click(sender, e)

                    'ddlFilterCol4.SelectedIndex = 1
                    ''ddlFilterCol1.Items.FindByText("CLR_PROCESS_LINE").Selected = True
                    'ddlFilterCol4_SelectedIndexChanged(sender, e)
                    'ddlFilterColVal4.Items.FindByText("P").Selected = True
                    'ddlFilterCol4.Enabled = False
                    'ddlFilterColVal4.Enabled = False
                    'ddlFilterCol5.SelectedIndex = 2
                    'ddlFilterCol5_SelectedIndexChanged(sender, e)
                    'ddlFilterColVal5.Items.FindByText("ZAAL").Selected = True
                    'ddlFilterCol5.Enabled = False
                    'ddlFilterColVal5.Enabled = False
                    'btnSecGo_Click(sender, e)

                    ddlFilterCol4.Visible = False
                    ddlFilterColVal4.Visible = False
                    ddlFilterCol5.Visible = False
                    ddlFilterColVal5.Visible = False
                    ddlFilterCol6.Visible = False
                    ddlFilterColVal6.Visible = False
                    btnSecGo.Visible = False
                    container2.Visible = False
                    container3.Visible = False
                    lblSecChartTitle.Visible = False
                    txtSecChartTitle.Visible = False
                    lblSecColour.Visible = False
                    ddlSecColour.Visible = False

                    ddlFilterCol2.Items.Remove("CLR_PROCESS_LINE")
                    ddlFilterCol3.Items.Remove("CLR_PROCESS_LINE")
                    ddlFilterCol5.Items.Remove("CLR_PROCESS_LINE")
                    ddlFilterCol6.Items.Remove("CLR_PROCESS_LINE")
                ElseIf Session("SelectVal") = "ECL" Then

                End If

            Catch ex As Exception

            End Try
        ElseIf IsPostBack
            Try

                If objController.IsValidDateRange(txtFrom, txtTo) Then


                    'Try
                    Dim filter As String = ""
                    If ddlFilterCol1.SelectedItem.Text <> "Select" Then
                        filter = ddlFilterCol1.SelectedItem.Text & " = '" & ddlFilterColVal1.SelectedItem.Text & "'"
                    End If
                    filter &= " AND ("
                    If ddlFilterCol2.SelectedItem.Text <> "Select" Then
                        If ddlFilterCol2.Text = ddlFilterCol1.Text Then
                            'filter &= " or " & ddlFilterCol2.SelectedItem.Text & " = '" & ddlFilterColVal2.SelectedItem.Value & "'"
                            filter &= "" & ddlFilterCol2.SelectedItem.Text & " in (" & ddlFilterColVal2.SelectedItem.Value & ")"
                        Else
                            filter &= "" & ddlFilterCol2.SelectedItem.Text & " in (" & ddlFilterColVal2.SelectedItem.Value & ")"
                        End If

                    End If
                    If ddlFilterCol3.Text <> "" Then
                        If ddlFilterCol3.SelectedItem.Text <> "Select" Then
                            If ddlFilterCol3.Text = ddlFilterCol2.Text Then
                                filter &= " or " & ddlFilterCol3.SelectedItem.Text & " in (" & ddlFilterColVal3.SelectedItem.Value & ")"
                            ElseIf ddlFilterCol3.Text = ddlFilterCol1.Text Then
                                filter &= " or " & ddlFilterCol3.SelectedItem.Text & " in (" & ddlFilterColVal3.SelectedItem.Value & ")"
                            Else
                                filter &= " and " & ddlFilterCol3.SelectedItem.Text & " in (" & ddlFilterColVal3.SelectedItem.Value & ")"
                            End If
                            ViewState("HaveY2AxisTop") = True
                        Else
                            'filter = filter.Replace(" and (", " and ")
                            ViewState("HaveY2AxisTop") = False
                        End If
                        filter = filter.Replace(" and (", " and ")
                        filter &= ")"
                    End If

                    'If ddlFilterColVal3.Text <> "" Then
                    '    txtChartTitle.Text = ddlFilterColVal1.Text & " " & ddlFilterColVal2.SelectedItem.Text & " " & ddlFilterColVal3.SelectedItem.Text
                    'ElseIf ddlFilterColVal2.Text <> "" Then
                    '    txtChartTitle.Text = ddlFilterColVal1.Text & " " & ddlFilterColVal2.SelectedItem.Text
                    'Else
                    '    txtChartTitle.Text = ddlFilterColVal1.Text
                    'End If
                    If ddlFilterColVal1.Text <> "" Then
                        txtChartTitle.Text = ddlFilterColVal1.Text
                    End If
                    If ddlFilterColVal2.Text <> "" Then
                        txtChartTitle.Text &= " " & ddlFilterColVal2.SelectedItem.Text
                    End If
                    If ddlFilterColVal3.Text <> "" Then
                        txtChartTitle.Text &= " " & ddlFilterColVal3.SelectedItem.Text
                    End If

                    If Session("SelectVal") = "CGL" Or Session("SelectVal") = "CGL1" Or Session("SelectVal") = "PLTCM" Then
                        DrawChartTop(filter, txtChartTitle.Text, "first", Lit1, Lit3)

                    ElseIf Session("SelectVal") = "CGL2" Then
                        DrawChartTop(filter, txtChartTitle.Text, "first", Lit1, Lit3)
                        DrawChartForCGL2(filter, txtChartTitle.Text, "first")
                    End If


                    'ddl_Colour.Items.FindByText(Session("DefaultColourCol")).Selected = True
                    'Catch ex As Exception

                    'End Try
                Else
                    UserMsgBoxError("Date range incorrect.")
                End If

            Catch ex As Exception

            End Try
        End If
    End Sub

    Sub LoadColourColumn(ByVal Dropdown As DropDownList)
        Try

            Dim dt As DataTable = objController.LoadColourColumns(Session("TableName"))
            Dropdown.DataSource = dt
            Dropdown.DataTextField = "column_name"
            Dropdown.DataValueField = "data_type"
            Dropdown.DataBind()
            'ddl_Colour.Items.Insert(0, "Select")
            Dropdown.Items.FindByText(Session("DefaultColourCol")).Selected = True

        Catch ex As Exception

        End Try
    End Sub

    Sub LoadFilterColumns(ByVal Dropdown As DropDownList, ByVal arr() As String)
        Try

            Dropdown.DataSource = arr
            Dropdown.DataBind()
            Dropdown.Items.Insert(0, "Select")
            Dropdown.SelectedIndex = 0

        Catch ex As Exception

        End Try
    End Sub

    'Sub DrawChart(ByVal Filter As String, ByVal ChartTitle As String, ByVal val As String, ByVal lita As Literal, ByVal litb As Literal)
    '    Try
    '        'Lit1.Text = ""
    '        'Lit2.Text = ""
    '        'Lit3.Text = ""
    '        'Lit4.Text = ""
    '        lita.Text = ""
    '        litb.Text = ""
    '        Dim strfrmDt As String = txtFrom.Text.Trim
    '        Dim strToDt As String = txtTo.Text.Trim

    '        Dim dt As DataTable = objController.GetWetChemicalTestData(Session("TableName"), strfrmDt, strToDt, Session("DateColumn"), Filter, "CLR_PARAM_MIN")
    '        Dim dv As DataView = dt.DefaultView
    '        If val = "first" Then
    '            dv.RowFilter = ddlFilterCol2.Text & " IN (" & ddlFilterColVal2.Text & ")"
    '        ElseIf val = "second" Then
    '            dv.RowFilter = ddlFilterCol5.Text & " IN (" & ddlFilterColVal5.Text & ")"
    '        End If
    '        Dim dtAL As DataTable = dv.ToTable
    '        ViewState("dtAL") = dtAL

    '        Dim dtFE As New DataTable
    '        dt.DefaultView.RowFilter = String.Empty
    '        If ddlFilterCol3.SelectedIndex > 0 Then
    '            dv = dt.DefaultView
    '            dv.RowFilter = ddlFilterCol3.Text & " IN (" & ddlFilterColVal3.Text & ")"
    '            dtFE = dv.ToTable
    '            ViewState("dtFE") = dtFE
    '        End If
    '        If val = "first" Then
    '            If ViewState("HaveY2AxisTop") = True Then
    '                Dim y1Values(), y2Values() As String
    '                y1Values = (From row In dtAL Select col = row(Session("YValueColumn")).ToString).ToArray
    '                y2Values = (From row In dtFE Select col = row(Session("YValueColumn")).ToString).ToArray

    '                Dim y1_min As String = y1Values.Min() - (10 / 100 * y1Values.Min)
    '                Dim y1_max As String = y1Values.Max() + (10 / 100 * y1Values.Max)
    '                Dim y2_min As String = y2Values.Min() - (10 / 100 * y2Values.Min)
    '                Dim y2_max As String = y2Values.Max() + (10 / 100 * y2Values.Max)
    '                objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), y1_min, y1_max, y2_min, y2_max, Lit1, "container", "plot1", ChartTitle, ddlFilterColVal2.Text, ddlFilterColVal3.Text, "priData", "secData", ddlFilterColVal2.SelectedItem.Text, ddlFilterColVal3.SelectedItem.Text)
    '                'objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), Session("YValueColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, ddlFilterColVal2.Text, ddlFilterColVal3.Text, "dataPri", "dataSec")
    '            Else
    '                objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
    '            End If
    '            objController.PlotBoxPlotChart(dt, Session("YValueColumn"), Lit3, "container1", "plot11", "dataA", "CLR_PARAM_MIN", "outlierDataA", ChartTitle, "", "Avg_A")
    '        ElseIf val = "second" Then
    '            If ViewState("HaveY2AxisTop") = True Then
    '                Dim y1Values(), y2Values() As String
    '                y1Values = (From row In dtAL Select col = row(Session("YValueColumn")).ToString).ToArray
    '                y2Values = (From row In dtFE Select col = row(Session("YValueColumn")).ToString).ToArray

    '                Dim y1_min As String = y1Values.Min() - (10 / 100 * y1Values.Min)
    '                Dim y1_max As String = y1Values.Max() + (10 / 100 * y1Values.Max)
    '                Dim y2_min As String = y2Values.Min() - (10 / 100 * y2Values.Min)
    '                Dim y2_max As String = y2Values.Max() + (10 / 100 * y2Values.Max)
    '                objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), y1_min, y1_max, y2_min, y2_max, Lit2, "container2", "plot2", ChartTitle, ddlFilterColVal5.Text, ddlFilterColVal6.Text, "priData1", "secData1", ddlFilterColVal5.SelectedItem.Text, ddlFilterColVal6.SelectedItem.Text)
    '                'objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), Session("YValueColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, ddlFilterColVal2.Text, ddlFilterColVal3.Text, "dataPri", "dataSec")
    '            Else
    '                objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit2, "container2", "plot2", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
    '            End If
    '            objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit4, "container3", "plot22", "dataB", "CLR_PARAM_MIN", "outlierDataB", ChartTitle, "", "Avg_B")
    '            '--------------

    '            'objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit2, "container2", "plot2", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
    '            'objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit4, "container3", "plot22", "dataB", "CLR_PARAM_MIN", "outlierDataB", ChartTitle, "", "Avg_B")
    '        ElseIf val = "" Then
    '            objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
    '            objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit3, "container1", "plot11", "dataA", "CLR_PARAM_MIN", "outlierDataA", ChartTitle, "", "Avg_A")

    '            objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit2, "container2", "plot2", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
    '            objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit4, "container3", "plot22", "dataB", "CLR_PARAM_MIN", "outlierDataB", ChartTitle, "", "Avg_B")
    '        End If
    '        'PlotLineChart(dtAL, dtFE, ChartTitle)
    '        'PlotBoxPlot(dtAL, dtFE, ChartTitle)
    '    Catch ex As Exception

    '    End Try
    'End Sub

    Sub DrawChartTop(ByVal Filter As String, ByVal ChartTitle As String, ByVal val As String, ByVal lita As Literal, ByVal litb As Literal)
        Try
            'Lit1.Text = ""
            'Lit2.Text = ""
            'Lit3.Text = ""
            'Lit4.Text = ""
            lita.Text = ""
            litb.Text = ""
            'ChartTitle = "Trend of Eff. Aluminium & Eff. Iron"
            Dim strfrmDt As String = txtFrom.Text.Trim
            Dim strToDt As String = txtTo.Text.Trim

            Dim dt As DataTable = objController.GetWetChemicalTestData(Session("TableName"), strfrmDt, strToDt, Session("DateColumn"), Filter, "CLR_PARAM_MIN")
            Dim dv As DataView = dt.DefaultView
            If val = "first" Then
                dv.RowFilter = ddlFilterCol2.Text & " IN (" & ddlFilterColVal2.Text & ")"
            End If
            Dim dtAL As DataTable = dv.ToTable
            ViewState("dtAL") = dtAL

            Dim dtFE As New DataTable
            dt.DefaultView.RowFilter = String.Empty
            If ddlFilterColVal3.SelectedIndex >= 0 And ddlFilterCol3.SelectedItem.Text <> "Select" Then
                dv = dt.DefaultView
                dv.RowFilter = ddlFilterCol3.Text & " IN (" & ddlFilterColVal3.Text & ")"
                dtFE = dv.ToTable
                ViewState("dtFE") = dtFE
            End If
            If val = "first" Then
                If ViewState("HaveY2AxisTop") = True Then
                    Dim y1Values(), y2Values() As String
                    y1Values = (From row In dtAL Select col = row(Session("YValueColumn")).ToString).ToArray
                    y2Values = (From row In dtFE Select col = row(Session("YValueColumn")).ToString).ToArray

                    Dim y1_min As String = y1Values.Min() - (10 / 100 * y1Values.Min)
                    Dim y1_max As String = y1Values.Max() + (10 / 100 * y1Values.Max)
                    Dim y2_min As String = y2Values.Min() - (10 / 100 * y2Values.Min)
                    Dim y2_max As String = y2Values.Max() + (10 / 100 * y2Values.Max)
                    If Session("SelectVal") = "CGL1" Then
                        'objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), y1_min, y1_max, y2_min, y2_max, Lit1, "container", "plot1", ChartTitle, ddlFilterColVal2.Text, ddlFilterColVal3.Text, "priData", "secData", ddlFilterColVal2.SelectedItem.Text, ddlFilterColVal3.SelectedItem.Text)
                        objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), y1_min, y1_max, y2_min, y2_max, Lit1, "container", "plot1", ChartTitle, ddlFilterColVal2.Text, ddlFilterColVal3.Text, "priData", "secData", "% Al", "% Fe",ddlline.SelectedValue.ToString)
                    ElseIf Session("SelectVal") = "CGL" Then
                        Dim yVal As String = ""
                        'yVal = ddlFilterColVal2.SelectedValue.Replace("'", "") & " " & ddlFilterColVal3.SelectedValue.Replace("'", "")
                        objController.PlotLineChartForCGL(dt, Session("DateColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, yVal, "CLR_PARAM_TEST")
                    ElseIf Session("SelectVal") = "CGL2" Then
                        'Dim dtNew As DataTable = dt.Clone
                        'dtNew.Columns.Add("Campaign")
                        'For i As Integer = 0 To dt.Rows.Count - 1
                        '    Dim dr As DataRow = dtNew.NewRow

                        '    dtNew.Rows.Add(dr)
                        'Next
                        'objController.PlotLineChartWithSecondaryYAxisCampaignwise(dt, Session("DateColumn"), y1_min, y1_max, y2_min, y2_max, Lit1, "container", "plot1", ChartTitle, ddlFilterColVal2.Text, ddlFilterColVal3.Text, "priData", "secData", ddlFilterColVal2.SelectedItem.Text, ddlFilterColVal3.SelectedItem.Text)
                        objController.PlotLineChartWithSecondaryYAxisCampaignwise(dt, Session("DateColumn"), y1_min, y1_max, y2_min, y2_max, Lit1, "container", "plot1", ChartTitle, ddlFilterColVal2.Text, ddlFilterColVal3.Text, "priData", "secData", "% Al", "% Fe", ddlline.SelectedValue.ToString)
                    End If
                    'objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), y1_min, y1_max, y2_min, y2_max, Lit1, "container", "plot1", ChartTitle, ddlFilterColVal2.Text, ddlFilterColVal3.Text, "priData", "secData", ddlFilterColVal2.SelectedItem.Text, ddlFilterColVal3.SelectedItem.Text)
                    'objController.PlotLineChartWithSecondaryYAxisCampaignwise(dt, Session("DateColumn"), y1_min, y1_max, y2_min, y2_max, Lit1, "container", "plot1", ChartTitle, ddlFilterColVal2.Text, ddlFilterColVal3.Text, "priData", "secData", ddlFilterColVal2.SelectedItem.Text, ddlFilterColVal3.SelectedItem.Text)
                    'objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), Session("YValueColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, ddlFilterColVal2.Text, ddlFilterColVal3.Text, "dataPri", "dataSec")
                ElseIf Session("SelectVal") = "PLTCM" Then
                    objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN", ddlline.SelectedValue.ToString)
                Else
                    'Dim line As Boolean = False
                    'If ddlline.SelectedValue = 1 Then
                    '    line = False
                    'ElseIf ddlline.SelectedValue = 2 Then
                    '    line = True
                    'End If
                    objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
                End If
                    'Commented by pratik
                    'objController.PlotBoxPlotChart(dt, Session("YValueColumn"), Lit3, "container1", "plot11", "dataA", "CLR_PARAM_MIN", "outlierDataA", ChartTitle, "", "Avg_A")

                    Dim Campaign As String = ""
                If ddlFilterColVal2.SelectedIndex >= 0 And ddlFilterCol2.SelectedItem.Text <> "Select" Then
                    Campaign = ddlFilterColVal2.SelectedItem.Text
                End If
                If ddlFilterColVal3.SelectedIndex >= 0 And ddlFilterCol3.SelectedItem.Text <> "Select" Then
                    Campaign &= "," & ddlFilterColVal3.SelectedItem.Text
                End If
                If Session("SelectVal") <> "CGL" Then
                    objController.PlotBoxPlotChart1(dt, Session("YValueColumn"), Lit3, "container1", "plot11", "dataA", "CLR_PARAM_MIN", "outlierDataA", ChartTitle, "", "Avg_A", Campaign)
                End If

                'ElseIf val = "second" Then
                'If ViewState("HaveY2AxisTop") = True Then
                '    Dim y1Values(), y2Values() As String
                '    y1Values = (From row In dtAL Select col = row(Session("YValueColumn")).ToString).ToArray
                '    y2Values = (From row In dtFE Select col = row(Session("YValueColumn")).ToString).ToArray

                '    Dim y1_min As String = y1Values.Min() - (10 / 100 * y1Values.Min)
                '    Dim y1_max As String = y1Values.Max() + (10 / 100 * y1Values.Max)
                '    Dim y2_min As String = y2Values.Min() - (10 / 100 * y2Values.Min)
                '    Dim y2_max As String = y2Values.Max() + (10 / 100 * y2Values.Max)
                '    objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), y1_min, y1_max, y2_min, y2_max, Lit2, "container2", "plot2", ChartTitle, ddlFilterColVal5.Text, ddlFilterColVal6.Text, "priData1", "secData1", ddlFilterColVal5.SelectedItem.Text, ddlFilterColVal6.SelectedItem.Text)
                '    'objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), Session("YValueColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, ddlFilterColVal2.Text, ddlFilterColVal3.Text, "dataPri", "dataSec")
                'Else
                '    objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit2, "container2", "plot2", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
                'End If
                'objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit4, "container3", "plot22", "dataB", "CLR_PARAM_MIN", "outlierDataB", ChartTitle, "", "Avg_B")
                '--------------

                'objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit2, "container2", "plot2", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
                'objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit4, "container3", "plot22", "dataB", "CLR_PARAM_MIN", "outlierDataB", ChartTitle, "", "Avg_B")
                'ElseIf val = "" Then
                '    objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
                '    objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit3, "container1", "plot11", "dataA", "CLR_PARAM_MIN", "outlierDataA", ChartTitle, "", "Avg_A")

                '    objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit2, "container2", "plot2", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
                '    objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit4, "container3", "plot22", "dataB", "CLR_PARAM_MIN", "outlierDataB", ChartTitle, "", "Avg_B")
            End If
        Catch ex As Exception

        End Try
    End Sub

    Sub DrawChartBottom(ByVal Filter As String, ByVal ChartTitle As String, ByVal val As String, ByVal lita As Literal, ByVal litb As Literal)
        Try
            'Lit1.Text = ""
            'Lit2.Text = ""
            'Lit3.Text = ""
            'Lit4.Text = ""
            lita.Text = ""
            litb.Text = ""
            Dim strfrmDt As String = txtFrom.Text.Trim
            Dim strToDt As String = txtTo.Text.Trim

            Dim dt As DataTable = objController.GetWetChemicalTestData(Session("TableName"), strfrmDt, strToDt, Session("DateColumn"), Filter, "CLR_PARAM_MIN")
            Dim dv As DataView = dt.DefaultView
            If val = "second" Then
                dv.RowFilter = ddlFilterCol5.Text & " IN (" & ddlFilterColVal5.Text & ")"
            End If
            Dim dtAL As DataTable = dv.ToTable
            ViewState("dtAL") = dtAL

            Dim dtFE As New DataTable
            dt.DefaultView.RowFilter = String.Empty
            If ddlFilterColVal6.SelectedIndex >= 0 And ddlFilterCol6.SelectedItem.Text <> "Select" Then
                dv = dt.DefaultView
                dv.RowFilter = ddlFilterCol6.Text & " IN (" & ddlFilterColVal6.Text & ")"
                dtFE = dv.ToTable
                ViewState("dtFE") = dtFE
            End If
            'If val = "first" Then
            '    If ViewState("HaveY2AxisTop") = True Then
            '        Dim y1Values(), y2Values() As String
            '        y1Values = (From row In dtAL Select col = row(Session("YValueColumn")).ToString).ToArray
            '        y2Values = (From row In dtFE Select col = row(Session("YValueColumn")).ToString).ToArray

            '        Dim y1_min As String = y1Values.Min() - (10 / 100 * y1Values.Min)
            '        Dim y1_max As String = y1Values.Max() + (10 / 100 * y1Values.Max)
            '        Dim y2_min As String = y2Values.Min() - (10 / 100 * y2Values.Min)
            '        Dim y2_max As String = y2Values.Max() + (10 / 100 * y2Values.Max)
            '        objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), y1_min, y1_max, y2_min, y2_max, Lit1, "container", "plot1", ChartTitle, ddlFilterColVal2.Text, ddlFilterColVal3.Text, "priData", "secData", ddlFilterColVal2.SelectedItem.Text, ddlFilterColVal3.SelectedItem.Text)
            '        'objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), Session("YValueColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, ddlFilterColVal2.Text, ddlFilterColVal3.Text, "dataPri", "dataSec")
            '    Else
            '        objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
            '    End If
            '    objController.PlotBoxPlotChart(dt, Session("YValueColumn"), Lit3, "container1", "plot11", "dataA", "CLR_PARAM_MIN", "outlierDataA", ChartTitle, "", "Avg_A")
            'ElseIf val = "second" Then
            If val = "second" Then
                If Session("SelectVal") = "CGL" Then
                    ViewState("HaveY2AxisBottom") = False
                End If
                If ViewState("HaveY2AxisBottom") = True Then
                    Dim y1Values(), y2Values() As String
                    y1Values = (From row In dtAL Select col = row(Session("YValueColumn")).ToString).ToArray
                    y2Values = (From row In dtFE Select col = row(Session("YValueColumn")).ToString).ToArray

                    Dim y1_min As String = y1Values.Min() - (10 / 100 * y1Values.Min)
                    Dim y1_max As String = y1Values.Max() + (10 / 100 * y1Values.Max)
                    Dim y2_min As String = y2Values.Min() - (10 / 100 * y2Values.Min)
                    Dim y2_max As String = y2Values.Max() + (10 / 100 * y2Values.Max)
                    'objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), y1_min, y1_max, y2_min, y2_max, Lit2, "container2", "plot2", ChartTitle, ddlFilterColVal5.Text, ddlFilterColVal6.Text, "priData1", "secData1", ddlFilterColVal5.SelectedItem.Text, ddlFilterColVal6.SelectedItem.Text)
                    objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), y1_min, y1_max, y2_min, y2_max, Lit2, "container2", "plot2", ChartTitle, ddlFilterColVal5.Text, ddlFilterColVal6.Text, "priData1", "secData1", "% Al", "% Fe")
                    'objController.PlotLineChartWithSecondaryYAxis(dt, Session("DateColumn"), Session("YValueColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, ddlFilterColVal2.Text, ddlFilterColVal3.Text, "dataPri", "dataSec")
                Else
                    If Session("SelectVal") = "CGL" Then
                        Dim yVal As String = ""
                        'yVal = ddlFilterColVal5.SelectedValue.Replace("'", "") & " " & ddlFilterColVal6.SelectedValue.Replace("'", "")
                        objController.PlotLineChartForCGL(dt, Session("DateColumn"), Session("YValueColumn"), Lit2, "container2", "plot2", ChartTitle, yVal, "CLR_PARAM_TEST")
                    Else
                        objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit2, "container2", "plot2", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
                    End If


                End If
                ' objController.PlotBoxPlotChart(dt, Session("YValueColumn"), Lit4, "container3", "plot22", "dataB", "CLR_PARAM_MIN", "outlierDataB", ChartTitle, "", "Avg_B")

                Dim Campaign As String = ""
                If ddlFilterColVal5.SelectedIndex >= 0 And ddlFilterCol5.SelectedItem.Text <> "Select" Then
                    Campaign = ddlFilterColVal5.SelectedItem.Text
                End If
                If ddlFilterColVal6.SelectedIndex >= 0 And ddlFilterCol6.SelectedItem.Text <> "Select" Then
                    Campaign &= "," & ddlFilterColVal6.SelectedItem.Text
                End If
                If Session("SelectVal") <> "CGL" Then
                    objController.PlotBoxPlotChart1(dt, Session("YValueColumn"), Lit4, "container3", "plot22", "dataB", "CLR_PARAM_MIN", "outlierDataB", ChartTitle, "", "Avg_B", Campaign)
                End If

                '--------------

                'objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit2, "container2", "plot2", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
                'objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit4, "container3", "plot22", "dataB", "CLR_PARAM_MIN", "outlierDataB", ChartTitle, "", "Avg_B")
                'ElseIf val = "" Then
                '    objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
                '    objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit3, "container1", "plot11", "dataA", "CLR_PARAM_MIN", "outlierDataA", ChartTitle, "", "Avg_A")

                '    objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit2, "container2", "plot2", ChartTitle, "Test Value (%)", "CLR_PARAM_MIN")
                '    objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit4, "container3", "plot22", "dataB", "CLR_PARAM_MIN", "outlierDataB", ChartTitle, "", "Avg_B")
            End If
            'PlotLineChart(dtAL, dtFE, ChartTitle)
            'PlotBoxPlot(dtAL, dtFE, ChartTitle)
        Catch ex As Exception

        End Try
    End Sub

    'Sub PlotLineChart(ByVal LineChartData1 As DataTable, ByVal LineChartData2 As DataTable, ByVal ChartTitle As String)
    '    objController.PlotLineChart(LineChartData1, Session("DateColumn"), Session("YValueColumn"), Lit1, "container", "plot1", ChartTitle, "Test Value (%)", ddl_Colour.SelectedItem.Text)
    '    objController.PlotLineChart(LineChartData2, Session("DateColumn"), Session("YValueColumn"), Lit2, "container2", "plot2", "%FE Analysis", "Test Value (%)", ddl_Colour.SelectedItem.Text)
    'End Sub

    'Sub PlotBoxPlot(ByVal LineChartData1 As DataTable, ByVal LineChartData2 As DataTable, ByVal ChartTitle As String)
    '    objController.PlotBoxPlotChart(LineChartData1, Session("YValueColumn"), Lit3, "container1", "plot11", "dataA", ddl_Colour.SelectedItem.Text, "outlierDataA", ChartTitle, "", "Avg_A")
    '    objController.PlotBoxPlotChart(LineChartData2, Session("YValueColumn"), Lit4, "container3", "plot22", "dataB", ddl_Colour.SelectedItem.Text, "outlierDataB", "FE Test Value (%)", "", "Avg_B")
    'End Sub

    'Protected Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
    '    'DrawChart("", "", "")
    'End Sub

    Protected Sub ddlFilterCol1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlFilterCol1.SelectedIndexChanged
        Try

            If ddlFilterCol1.Text <> "Select" Then
                If objController.IsValidDateRange(txtFrom, txtTo) Then
                    objController.LoadColumnsData(ddlFilterColVal1, Session("TableName"), ddlFilterCol1.Text, Session("DateColumn"), txtFrom.Text, txtTo.Text)
                Else
                    UserMsgBoxError("Date range incorrect.")
                End If

            Else
                ddlFilterColVal1.DataSource = ""
                ddlFilterColVal1.DataBind()
            End If
            'ddl_Colour.Items.FindByText(Session("DefaultColourCol")).Selected = True

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click
        Try

            If objController.IsValidDateRange(txtFrom, txtTo) Then


                'Try
                Dim filter As String = ""
                If ddlFilterCol1.SelectedItem.Text <> "Select" Then
                    filter = ddlFilterCol1.SelectedItem.Text & " = '" & ddlFilterColVal1.SelectedItem.Text & "'"
                End If
                filter &= " AND ("
                If ddlFilterCol2.SelectedItem.Text <> "Select" Then
                    If ddlFilterCol2.Text = ddlFilterCol1.Text Then
                        'filter &= " or " & ddlFilterCol2.SelectedItem.Text & " = '" & ddlFilterColVal2.SelectedItem.Value & "'"
                        filter &= "" & ddlFilterCol2.SelectedItem.Text & " in (" & ddlFilterColVal2.SelectedItem.Value & ")"
                    Else
                        filter &= "" & ddlFilterCol2.SelectedItem.Text & " in (" & ddlFilterColVal2.SelectedItem.Value & ")"
                    End If

                End If
                If ddlFilterCol3.Text <> "" Then
                    If ddlFilterCol3.SelectedItem.Text <> "Select" Then
                        If ddlFilterCol3.Text = ddlFilterCol2.Text Then
                            filter &= " or " & ddlFilterCol3.SelectedItem.Text & " in (" & ddlFilterColVal3.SelectedItem.Value & ")"
                        ElseIf ddlFilterCol3.Text = ddlFilterCol1.Text Then
                            filter &= " or " & ddlFilterCol3.SelectedItem.Text & " in (" & ddlFilterColVal3.SelectedItem.Value & ")"
                        Else
                            filter &= " and " & ddlFilterCol3.SelectedItem.Text & " in (" & ddlFilterColVal3.SelectedItem.Value & ")"
                        End If
                        ViewState("HaveY2AxisTop") = True
                    Else
                        'filter = filter.Replace(" and (", " and ")
                        ViewState("HaveY2AxisTop") = False
                    End If
                    filter = filter.Replace(" and (", " and ")
                    filter &= ")"
                End If

                'If ddlFilterColVal3.Text <> "" Then
                '    txtChartTitle.Text = ddlFilterColVal1.Text & " " & ddlFilterColVal2.SelectedItem.Text & " " & ddlFilterColVal3.SelectedItem.Text
                'ElseIf ddlFilterColVal2.Text <> "" Then
                '    txtChartTitle.Text = ddlFilterColVal1.Text & " " & ddlFilterColVal2.SelectedItem.Text
                'Else
                '    txtChartTitle.Text = ddlFilterColVal1.Text
                'End If
                If ddlFilterColVal1.Text <> "" Then
                    txtChartTitle.Text = ddlFilterColVal1.Text
                End If
                If ddlFilterColVal2.Text <> "" Then
                    txtChartTitle.Text &= " " & ddlFilterColVal2.SelectedItem.Text
                End If
                If ddlFilterColVal3.Text <> "" Then
                    txtChartTitle.Text &= " " & ddlFilterColVal3.SelectedItem.Text
                End If

                If Session("SelectVal") = "CGL" Or Session("SelectVal") = "CGL1" Or Session("SelectVal") = "PLTCM" Then
                    DrawChartTop(filter, txtChartTitle.Text, "first", Lit1, Lit3)

                ElseIf Session("SelectVal") = "CGL2" Then
                    DrawChartTop(filter, txtChartTitle.Text, "first", Lit1, Lit3)
                    DrawChartForCGL2(filter, txtChartTitle.Text, "first")
                End If


                'ddl_Colour.Items.FindByText(Session("DefaultColourCol")).Selected = True
                'Catch ex As Exception

                'End Try
            Else
                UserMsgBoxError("Date range incorrect.")
            End If

        Catch ex As Exception

        End Try
    End Sub
    Sub DrawChartForCGL2(ByVal Filter As String, ByVal ChartTitle As String, ByVal val As String)
        Try
            'lita.Text = ""
            'litb.Text = ""
            ''ChartTitle = "Trend of Eff. Aluminium & Eff. Iron"
            Dim strfrmDt As String = txtFrom.Text.Trim
            Dim strToDt As String = txtTo.Text.Trim

            'Dim dt As DataTable = objController.GetWetChemicalTestData("CGL2_ZNBATH_TREND", strfrmDt, strToDt, "CZT_TIMESTAMP")

            'Dim dt1 As New DataTable
            'dt1.Columns.Add("CLR_DT_SAMPLING_DATE", GetType(DateTime))
            'dt1.Columns.Add("CLR_PARAM_MIN", GetType(Decimal))
            'dt1.Columns.Add("CLR_PARAM_TEST", GetType(String))
            'dt1.Columns.Add("CLR_TEST_VALUE", GetType(Decimal))

            'Dim dt2 As DataTable = dt.DefaultView.ToTable(True, "CLR_PARAM_TEST")
            'Dim dv As DataView = dt.DefaultView


            'For row As Integer = 0 To dt2.Rows.Count - 1
            '    dv.RowFilter = "CLR_PARAM_TEST='" & dt2.Rows(row)(0) & "' and CZT_POT_AL < 1 and CZT_POT_FE < 1"
            '    For j As Integer = 0 To dv.Count - 1
            '        If dt2.Rows(row)(0) = "ZAAL" Then
            '            dt1.Rows.Add(dv(j)(0), 1.0, "ZAAL", dv.Item(j)(1))
            '            dt1.Rows.Add(dv(j)(0), 2.0, "ZAFE_AL", dv.Item(j)(2))
            '        ElseIf dt2.Rows(row)(0) = "ZAZS" Then
            '            dt1.Rows.Add(dv(j)(0), 3.0, "ZAZS", dv.Item(j)(1))
            '            dt1.Rows.Add(dv(j)(0), 4.0, "ZAFE_ZS", dv.Item(j)(2))
            '        ElseIf dt2.Rows(row)(0) = "ZAGA" Then
            '            dt1.Rows.Add(dv(j)(0), 5.0, "ZAGA", dv.Item(j)(1))
            '            dt1.Rows.Add(dv(j)(0), 6.0, "ZAFE_GA", dv.Item(j)(2))
            '        End If
            '    Next
            '    dv.RowFilter = ""
            'Next

            'objController.PlotBoxPlotChartForCGL2(dt1, "CLR_TEST_VALUE", Lit3, "container1", "plot11", "dataA", "CLR_PARAM_MIN", "outlierDataA", ChartTitle, "", "Avg_A")
            '----------------------------Top Right Chart-----------------------------------------------------------------------------------------------------------------
            Dim dt As DataTable = objController.GetWetChemicalTestData("CGL2_ZNBATH_TREND", strfrmDt, strToDt, "CZT_TIMESTAMP", "CZT_POT_AL", "CZT_POT_FE", "CZT_CAMP_AL")


            Dim dt1 As New DataTable
            dt1.Columns.Add("CLR_DT_SAMPLING_DATE", GetType(DateTime))
            dt1.Columns.Add("CLR_PARAM_MIN", GetType(Decimal))
            dt1.Columns.Add("CLR_PARAM_TEST", GetType(String))
            dt1.Columns.Add("CLR_TEST_VALUE", GetType(Decimal))

            Dim dt2 As DataTable = dt.DefaultView.ToTable(True, "CLR_PARAM_TEST")
            Dim dv As DataView = dt.DefaultView


            'For row As Integer = 0 To dt2.Rows.Count - 1
            '    dv.RowFilter = "CLR_PARAM_TEST='" & dt2.Rows(row)(0) & "' and CZT_POT_AL < 1 and CZT_POT_FE < 1"
            '    For j As Integer = 0 To dv.Count - 1
            '        If dt2.Rows(row)(0) = "ZAAL" Then
            '            dt1.Rows.Add(dv(j)(0), 1.0, "ZAAL", dv.Item(j)(1))
            '            dt1.Rows.Add(dv(j)(0), 2.0, "ZAFE_AL", dv.Item(j)(2))
            '        ElseIf dt2.Rows(row)(0) = "ZAZS" Then
            '            dt1.Rows.Add(dv(j)(0), 3.0, "ZAZS", dv.Item(j)(1))
            '            dt1.Rows.Add(dv(j)(0), 4.0, "ZAFE_ZS", dv.Item(j)(2))
            '        ElseIf dt2.Rows(row)(0) = "ZAGA" Then
            '            dt1.Rows.Add(dv(j)(0), 5.0, "ZAGA", dv.Item(j)(1))
            '            dt1.Rows.Add(dv(j)(0), 6.0, "ZAFE_GA", dv.Item(j)(2))
            '        End If
            '    Next
            '    dv.RowFilter = ""
            'Next
            For row As Integer = 0 To dt2.Rows.Count - 1
                dv.RowFilter = "CLR_PARAM_TEST='" & dt2.Rows(row)(0) & "' and CZT_POT_AL < 1 and CZT_POT_FE < 1"
                For j As Integer = 0 To dv.Count - 1
                    'If dt2.Rows(row)(0) = "ZAAL" Then
                    '    dt1.Rows.Add(dv(j)(0), 1.0, "ZAAL", dv.Item(j)(1))
                    '    dt1.Rows.Add(dv(j)(0), 2.0, "ZAFE_AL", dv.Item(j)(2))
                    'ElseIf dt2.Rows(row)(0) = "ZAZS" Then
                    '    dt1.Rows.Add(dv(j)(0), 3.0, "ZAZS", dv.Item(j)(1))
                    '    dt1.Rows.Add(dv(j)(0), 4.0, "ZAFE_ZS", dv.Item(j)(2))
                    'ElseIf dt2.Rows(row)(0) = "ZAGA" Then
                    '    dt1.Rows.Add(dv(j)(0), 5.0, "ZAGA", dv.Item(j)(1))
                    '    dt1.Rows.Add(dv(j)(0), 6.0, "ZAFE_GA", dv.Item(j)(2))
                    'End If
                    If dv(j)(1) >= 0.1 And dv(j)(1) <= 0.15 Then
                        dt1.Rows.Add(dv(j)(0), 1.0, "GA_AL", dv.Item(j)(1))
                        dt1.Rows.Add(dv(j)(0), 2.0, "GA_FE", dv.Item(j)(2))
                    ElseIf dv(j)(1) > 0.15 And dv(j)(1) <= 0.4 Then
                        dt1.Rows.Add(dv(j)(0), 3.0, "GI_AL", dv.Item(j)(1))
                        dt1.Rows.Add(dv(j)(0), 4.0, "GI_FE", dv.Item(j)(2))

                    End If
                Next
                dv.RowFilter = ""
            Next

            objController.PlotBoxPlotChartForCGL2(dt1, "CLR_TEST_VALUE", Lit3, "container1", "plot11", "dataA", "CLR_PARAM_MIN", "outlierDataA", ChartTitle, "", "Avg_A", "Pot", 0, 0.4)
            '-----------------Top Right Chart End-------------------------------------------------------------------------------------------------------------------------

            ''-----------------Bottom Right Chart--------------------------------------------------------------------------------------------------------------------------
            'Dim dt3 As DataTable = objController.GetWetChemicalTestData("CGL2_ZNBATH_TREND", strfrmDt, strToDt, "CZT_TIMESTAMP", "CZT_EFF_AL", "CZT_EFF_FE", "CZT_CAMP_AL")


            'Dim dt4 As New DataTable
            'dt4.Columns.Add("CLR_DT_SAMPLING_DATE", GetType(DateTime))
            'dt4.Columns.Add("CLR_PARAM_MIN", GetType(Decimal))
            'dt4.Columns.Add("CLR_PARAM_TEST", GetType(String))
            'dt4.Columns.Add("CLR_TEST_VALUE", GetType(Decimal))

            'Dim dt5 As DataTable = dt3.DefaultView.ToTable(True, "CLR_PARAM_TEST")
            'Dim dv1 As DataView = dt3.DefaultView


            'For row As Integer = 0 To dt5.Rows.Count - 1
            '    dv1.RowFilter = "CLR_PARAM_TEST='" & dt5.Rows(row)(0) & "' and CZT_EFF_AL < 1 and CZT_EFF_FE < 1"
            '    For j As Integer = 0 To dv1.Count - 1
            '        If dt5.Rows(row)(0) = "ZAAL" Then
            '            dt4.Rows.Add(dv1(j)(0), 1.0, "ZAAL", dv1.Item(j)(1))
            '            dt4.Rows.Add(dv1(j)(0), 2.0, "ZAFE_AL", dv1.Item(j)(2))
            '        ElseIf dt5.Rows(row)(0) = "ZAZS" Then
            '            dt4.Rows.Add(dv1(j)(0), 3.0, "ZAZS", dv1.Item(j)(1))
            '            dt4.Rows.Add(dv1(j)(0), 4.0, "ZAFE_ZS", dv1.Item(j)(2))
            '        ElseIf dt5.Rows(row)(0) = "ZAGA" Then
            '            dt4.Rows.Add(dv1(j)(0), 5.0, "ZAGA", dv1.Item(j)(1))
            '            dt4.Rows.Add(dv1(j)(0), 6.0, "ZAFE_GA", dv1.Item(j)(2))
            '        End If
            '    Next
            '    dv1.RowFilter = ""
            'Next

            'objController.PlotBoxPlotChartForCGL2(dt4, "CLR_TEST_VALUE", Lit4, "container3", "plot22", "dataB", "CLR_PARAM_MIN", "outlierDataB", ChartTitle, "", "Avg_B", "Eff")
            ''-----------------Bottom Right Chart End----------------------------------------------------------------------------------------------------------------------
            ''--------------TOP LEFT CHART----------------------------------------------------------------------
            ''--------------TOP LEFT CHART END----------------------------------------------------------------------
            ''--------------TOP RIGHT CHART----------------------------------------------------------------------
            ''--------------TOP RIGHT CHART END----------------------------------------------------------------------
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub btnSecGo_Click(sender As Object, e As EventArgs) Handles btnSecGo.Click
        Try

            If objController.IsValidDateRange(txtFrom, txtTo) Then
                Dim filter As String = ""
                If ddlFilterCol4.SelectedItem.Text <> "Select" Then
                    filter = ddlFilterCol4.SelectedItem.Text & " = '" & ddlFilterColVal4.SelectedItem.Text & "'"
                End If
                If ddlFilterCol5.SelectedItem.Text <> "Select" Then
                    If ddlFilterCol5.Text = ddlFilterCol4.Text Then
                        filter &= " or " & ddlFilterCol5.SelectedItem.Text & " IN (" & ddlFilterColVal5.SelectedItem.Value & ")"
                    Else
                        filter &= " and " & ddlFilterCol5.SelectedItem.Text & " IN (" & ddlFilterColVal5.SelectedItem.Value & ")"
                    End If

                End If
                If ddlFilterCol6.Text <> "" Then
                    If ddlFilterCol6.SelectedItem.Text <> "Select" Then
                        If ddlFilterCol6.Text = ddlFilterCol5.Text Then
                            filter &= " or " & ddlFilterCol6.SelectedItem.Text & " IN (" & ddlFilterColVal6.SelectedItem.Value & ")"
                        ElseIf ddlFilterCol6.Text = ddlFilterCol4.Text Then
                            filter &= " or " & ddlFilterCol6.SelectedItem.Text & " IN (" & ddlFilterColVal6.SelectedItem.Value & ")"
                        Else
                            filter &= " and " & ddlFilterCol6.SelectedItem.Text & " IN (" & ddlFilterColVal6.SelectedItem.Value & ")"
                        End If
                        ViewState("HaveY2AxisBottom") = True
                    Else
                        ViewState("HaveY2AxisBottom") = False
                    End If
                    filter = filter.Replace(" and (", " and ")
                End If

                'If ddlFilterColVal6.Text <> "" Then
                '    txtSecChartTitle.Text = ddlFilterColVal4.Text & " " & ddlFilterColVal5.SelectedItem.Text & " " & ddlFilterColVal6.SelectedItem.Text
                'ElseIf ddlFilterColVal5.Text <> "" Then
                '    txtSecChartTitle.Text = ddlFilterColVal4.Text & " " & ddlFilterColVal5.SelectedItem.Text
                'Else
                '    txtSecChartTitle.Text = ddlFilterColVal4.Text
                'End If

                If ddlFilterColVal4.Text <> "" Then
                    txtSecChartTitle.Text = ddlFilterColVal4.Text
                End If
                If ddlFilterColVal5.Text <> "" Then
                    txtSecChartTitle.Text &= " " & ddlFilterColVal5.SelectedItem.Text
                End If
                If ddlFilterColVal6.Text <> "" Then
                    txtSecChartTitle.Text &= " " & ddlFilterColVal6.SelectedItem.Text
                End If

                'txtSecChartTitle.Text = ddlFilterColVal4.Text & " " & ddlFilterColVal5.SelectedItem.Text & " " & ddlFilterColVal6.SelectedItem.Text

                If Session("SelectVal") = "CGL" Or Session("SelectVal") = "CGL1" Or Session("SelectVal") = "PLTCM" Then
                    DrawChartBottom(filter, txtSecChartTitle.Text, "second", Lit2, Lit4)

                ElseIf Session("SelectVal") = "CGL2" Then
                    DrawChartBottom(filter, txtSecChartTitle.Text, "second", Lit2, Lit4)
                    DrawChartForCGL2(filter, txtChartTitle.Text, "first")
                End If
            Else
                UserMsgBoxError("Date range incorrect.")
            End If

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub ddlFilterCol2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlFilterCol2.SelectedIndexChanged
        Try

            If ddlFilterCol2.SelectedItem.Text <> "Select" Then
                If objController.IsValidDateRange(txtFrom, txtTo) Then
                    objController.LoadColumnsData(ddlFilterColVal2, Session("TableName"), ddlFilterCol2.SelectedItem.Text, Session("DateColumn"), txtFrom.Text, txtTo.Text, ddlFilterColVal1.SelectedItem.Text)
                Else
                    UserMsgBoxError("Date range incorrect.")
                End If

            Else
                ddlFilterColVal2.DataSource = ""
                ddlFilterColVal2.DataBind()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub ddlFilterCol3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlFilterCol3.SelectedIndexChanged
        Try

            If ddlFilterCol3.SelectedItem.Text <> "Select" Then
                If objController.IsValidDateRange(txtFrom, txtTo) Then
                    objController.LoadColumnsData(ddlFilterColVal3, Session("TableName"), ddlFilterCol3.SelectedItem.Text, Session("DateColumn"), txtFrom.Text, txtTo.Text, ddlFilterColVal1.SelectedItem.Text)
                Else
                    UserMsgBoxError("Date range incorrect.")
                End If

            Else
                ddlFilterColVal3.DataSource = ""
                ddlFilterColVal3.DataBind()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub ddlFilterCol4_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlFilterCol4.SelectedIndexChanged
        Try

            If ddlFilterCol4.SelectedItem.Text <> "Select" Then
                If objController.IsValidDateRange(txtFrom, txtTo) Then
                    objController.LoadColumnsData(ddlFilterColVal4, Session("TableName"), ddlFilterCol4.SelectedItem.Text, Session("DateColumn"), txtFrom.Text, txtTo.Text)
                Else
                    UserMsgBoxError("Date range incorrect.")
                End If

            Else
                ddlFilterColVal4.DataSource = ""
                ddlFilterColVal4.DataBind()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub ddlFilterCol5_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlFilterCol5.SelectedIndexChanged
        Try

            If ddlFilterCol5.SelectedItem.Text <> "Select" Then
                If objController.IsValidDateRange(txtFrom, txtTo) Then
                    objController.LoadColumnsData(ddlFilterColVal5, Session("TableName"), ddlFilterCol5.SelectedItem.Text, Session("DateColumn"), txtFrom.Text, txtTo.Text, ddlFilterColVal4.SelectedItem.Text)
                Else
                    UserMsgBoxError("Date range incorrect.")
                End If

            Else
                ddlFilterColVal5.DataSource = ""
                ddlFilterColVal5.DataBind()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub ddlFilterCol6_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlFilterCol6.SelectedIndexChanged
        Try

            If ddlFilterCol6.SelectedItem.Text <> "Select" Then
                If objController.IsValidDateRange(txtFrom, txtTo) Then
                    objController.LoadColumnsData(ddlFilterColVal6, Session("TableName"), ddlFilterCol6.SelectedItem.Text, Session("DateColumn"), txtFrom.Text, txtTo.Text, ddlFilterColVal4.SelectedItem.Text)
                Else
                    UserMsgBoxError("Date range incorrect.")
                End If

            Else
                ddlFilterColVal6.DataSource = ""
                ddlFilterColVal6.DataBind()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub txtChartTitle_TextChanged(sender As Object, e As EventArgs) Handles txtChartTitle.TextChanged
        Try

            Dim dtAL As DataTable = ViewState("dtAL")
            Dim dtFE As DataTable = ViewState("dtFE")
            'PlotLineChart(dtAL, dtFE, txtChartTitle.Text)
            'PlotBoxPlot(dtAL, dtFE, txtChartTitle.Text)
            objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit1, "container", "plot1", txtChartTitle.Text, "Test Value (%)", "CLR_PARAM_MIN")
            objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit3, "container1", "plot11", "dataA", "CLR_PARAM_MIN", "outlierDataA", txtChartTitle.Text, "", "Avg_A")

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub txtSecChartTitle_TextChanged(sender As Object, e As EventArgs) Handles txtSecChartTitle.TextChanged
        Try

            Dim dtAL As DataTable = ViewState("dtAL")
            Dim dtFE As DataTable = ViewState("dtFE")
            'PlotLineChart(dtAL, dtFE, txtChartTitle.Text)
            'PlotBoxPlot(dtAL, dtFE, txtChartTitle.Text)
            objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit2, "container2", "plot2", txtSecChartTitle.Text, "Test Value (%)", "CLR_PARAM_MIN")
            objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit4, "container3", "plot22", "dataB", "CLR_PARAM_MIN", "outlierDataB", txtSecChartTitle.Text, "", "Avg_B")

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub ddlColour1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlColour1.SelectedIndexChanged
        Try

            Dim dtAL As DataTable = ViewState("dtAL")
            Dim dtFE As DataTable = ViewState("dtFE")
            'PlotLineChart(dtAL, dtFE, txtChartTitle.Text)
            'PlotBoxPlot(dtAL, dtFE, txtChartTitle.Text)
            objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit1, "container", "plot1", txtChartTitle.Text, "Test Value (%)", "CLR_PARAM_MIN")
            objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit3, "container1", "plot11", "dataA", "CLR_PARAM_MIN", "outlierDataA", txtChartTitle.Text, "", "Avg_A")

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub ddlSecColour_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlSecColour.SelectedIndexChanged
        Try

            Dim dtAL As DataTable = ViewState("dtAL")
            Dim dtFE As DataTable = ViewState("dtFE")
            'PlotLineChart(dtAL, dtFE, txtSecChartTitle.Text)
            'PlotBoxPlot(dtAL, dtFE, txtSecChartTitle.Text)
            objController.PlotLineChart(dtAL, Session("DateColumn"), Session("YValueColumn"), Lit2, "container2", "plot2", txtSecChartTitle.Text, "Test Value (%)", "CLR_PARAM_MIN")
            objController.PlotBoxPlotChart(dtFE, Session("YValueColumn"), Lit4, "container3", "plot22", "dataB", "CLR_PARAM_MIN", "outlierDataB", txtSecChartTitle.Text, "", "Avg_B")

        Catch ex As Exception

        End Try
    End Sub

    Function GetParamTestAliasName(ByVal DropDownName As DropDownList) As String
        Try

            Dim alias_name As String = ""
            If DropDownName.Text = "ZAAL" Or DropDownName.Text = "ZAGA" Or DropDownName.Text = "ZAZS" Then
                alias_name = "Aluminium"
            ElseIf DropDownName.Text = "ZAEAL" Then
                alias_name = "Eff Aluminium"
            ElseIf DropDownName.Text = "ZAFE" Then
                alias_name = "Iron"
            ElseIf DropDownName.Text = "ZASN" Then
                alias_name = "Tin"
            ElseIf DropDownName.Text = "ZASB" Then
                alias_name = "Antimony"
            ElseIf DropDownName.Text = "ZAPB" Then
                alias_name = "Lead"
            ElseIf DropDownName.Text = "ZAZN" Then
                alias_name = "Zinc"
            ElseIf DropDownName.Text = "ZIAL" Then
                alias_name = "Aluminium"
            ElseIf DropDownName.Text = "ZIEAL" Then
                alias_name = "Eff Aluminium"
            ElseIf DropDownName.Text = "ZIFE" Then
                alias_name = "Iron"
            ElseIf DropDownName.Text = "ZISN" Then
                alias_name = "Tin"
            ElseIf DropDownName.Text = "ZISB" Then
                alias_name = "Anitmony"
            ElseIf DropDownName.Text = "ZIPB" Then
                alias_name = "Lead"
            ElseIf DropDownName.Text = "ZIZN" Then
                alias_name = "Zinc"
            ElseIf DropDownName.Text = "ZIAL" Then
                alias_name = "Aluminium"
            ElseIf DropDownName.Text = "ZIEAL" Then
                alias_name = "Eff Aluminium"
            ElseIf DropDownName.Text = "ZIFE" Then
                alias_name = "Iron"
            ElseIf DropDownName.Text = "ZISN" Then
                alias_name = "Tin"
            ElseIf DropDownName.Text = "ZISB" Then
                alias_name = "Antimony"
            ElseIf DropDownName.Text = "ZIPB" Then
                alias_name = "Lead"
            ElseIf DropDownName.Text = "ZIZN" Then
                alias_name = "Zinc"
            ElseIf DropDownName.Text = "ZRAL" Then
                alias_name = "Aluminium"
            ElseIf DropDownName.Text = "ZREAL" Then
                alias_name = "Eff Aluminium"
            ElseIf DropDownName.Text = "ZRFE" Then
                alias_name = "Iron"
            ElseIf DropDownName.Text = "ZRSN" Then
                alias_name = "Tin"
            ElseIf DropDownName.Text = "ZRSB" Then
                alias_name = "Antimony"
            ElseIf DropDownName.Text = "ZRPB" Then
                alias_name = "Lead"
            ElseIf DropDownName.Text = "ZRZN" Then
                alias_name = "Zinc"
            ElseIf DropDownName.Text = "ZZAL" Then
                alias_name = "Aluminium"
            ElseIf DropDownName.Text = "ZZEAL" Then
                alias_name = "Eff Aluminium"
            ElseIf DropDownName.Text = "ZZFE" Then
                alias_name = "Iron"
            ElseIf DropDownName.Text = "ZZSN" Then
                alias_name = "Tin"
            ElseIf DropDownName.Text = "ZZSB" Then
                alias_name = "Antimony"
            ElseIf DropDownName.Text = "ZZPB" Then
                alias_name = "Lead"
            ElseIf DropDownName.Text = "ZZZN" Then
                alias_name = "Zinc"
            ElseIf DropDownName.Text = "ALPT" Then
                alias_name = "Predeg.tank"
            ElseIf DropDownName.Text = "ALET" Then
                alias_name = "ECL tank"
            ElseIf DropDownName.Text = "ALPTO" Then
                alias_name = "Predeg.tank(oil%)"
            ElseIf DropDownName.Text = "ALPTF" Then
                alias_name = "Predeg.tank(Fe%)"
            ElseIf DropDownName.Text = "ALTK" Then
                alias_name = "Alkali tank"
            ElseIf DropDownName.Text = "ALHW" Then
                alias_name = "Hot Rinse Water"
            ElseIf DropDownName.Text = "CRPT" Then
                alias_name = "Chromate Preperation Tank"
            ElseIf DropDownName.Text = "CRWT" Then
                alias_name = "Working tank"
            ElseIf DropDownName.Text = "CRTK" Then
                alias_name = "Chromate Tank"
            ElseIf DropDownName.Text = "ACIDT1" Then
                alias_name = "HCL Acid T1"
            ElseIf DropDownName.Text = "ACIDT2" Then
                alias_name = "HCL Acid T2"
            ElseIf DropDownName.Text = "ACIDT3" Then
                alias_name = "HCL Acid T3"
            ElseIf DropDownName.Text = "ACIDT4" Then
                alias_name = "HCL Acid T4"
            ElseIf DropDownName.Text = "PLCL" Then
                alias_name = "Chloride ppm"
            ElseIf DropDownName.Text = "PLSL" Then
                alias_name = "Suplhate ppm"
            ElseIf DropDownName.Text = "HCLWT1" Then
                alias_name = "HCL T1"
            ElseIf DropDownName.Text = "HCLWT2" Then
                alias_name = "HCL T2"
            ElseIf DropDownName.Text = "HCLWT3" Then
                alias_name = "HCL T3"
            ElseIf DropDownName.Text = "HCLWT4" Then
                alias_name = "HCL T4"
            ElseIf DropDownName.Text = "CNT1" Then
                alias_name = "Cndctvty T1"
            ElseIf DropDownName.Text = "CNT2" Then
                alias_name = "Cndctvty T2"
            ElseIf DropDownName.Text = "CNT3" Then
                alias_name = "Cndctvty T3"
            ElseIf DropDownName.Text = "CNT4" Then
                alias_name = "Cndctvty T4"
            ElseIf DropDownName.Text = "FET1" Then
                alias_name = "Iron T1"
            ElseIf DropDownName.Text = "FET2" Then
                alias_name = "Iron T2"
            ElseIf DropDownName.Text = "FET3" Then
                alias_name = "Iron T3"
            ElseIf DropDownName.Text = "FET4" Then
                alias_name = "Iron T4"
            ElseIf DropDownName.Text = "FEWT1" Then
                alias_name = "Iron T1"
            ElseIf DropDownName.Text = "FEWT2" Then
                alias_name = "Iron T2"
            ElseIf DropDownName.Text = "FEWT3" Then
                alias_name = "Iron T3"
            ElseIf DropDownName.Text = "FEWT4" Then
                alias_name = "Iron T4"
            ElseIf DropDownName.Text = "SGT1" Then
                alias_name = "Sp Gravity T1"
            ElseIf DropDownName.Text = "SGT2" Then
                alias_name = "Sp Gravity T2"
            ElseIf DropDownName.Text = "SGT3" Then
                alias_name = "Sp Gravity T3"
            ElseIf DropDownName.Text = "SGT4" Then
                alias_name = "Sp Gravity T4"
            ElseIf DropDownName.Text = "SO" Then
                alias_name = "Surface Oil"
            ElseIf DropDownName.Text = "SC" Then
                alias_name = "Surface Carbon"
            ElseIf DropDownName.Text = "SF" Then
                alias_name = "Surface Iron"
            ElseIf DropDownName.Text = "ZLPT" Then
                alias_name = "Zinc Load Prep. Tank"
            ElseIf DropDownName.Text = "ZLWT" Then
                alias_name = "Zinc Load Working Tank"
            ElseIf DropDownName.Text = "PHPT" Then
                alias_name = "PH Prep. Tank"
            ElseIf DropDownName.Text = "PHWT" Then
                alias_name = "PH Working Tank"
            ElseIf DropDownName.Text = "TCRPT" Then
                alias_name = "Total Chromate Prep. Tank"
            ElseIf DropDownName.Text = "TCRWT" Then
                alias_name = "Total Chromate Working Tank"
            ElseIf DropDownName.Text = "CR6PT" Then
                alias_name = "CR6 Prep. Tank"
            ElseIf DropDownName.Text = "CR6WT" Then
                alias_name = "CR6 Working Tank"
            ElseIf DropDownName.Text = "CR63PT" Then
                alias_name = "CR63 Prep. Tank"
            ElseIf DropDownName.Text = "CR63WT" Then
                alias_name = "CR63 Working Tank"
            ElseIf DropDownName.Text = "ALETO" Then
                alias_name = "ECL Tank (Fe %)"
            ElseIf DropDownName.Text = "ALETF" Then
                alias_name = "ECL Tank (Oil %)"
            ElseIf DropDownName.Text = "ARBD" Then
                alias_name = "Bulk Density"
            ElseIf DropDownName.Text = "ARPS" Then
                alias_name = "Avg. Particle Size"
            ElseIf DropDownName.Text = "ARMO" Then
                alias_name = "Moisture"
            ElseIf DropDownName.Text = "ARP" Then
                alias_name = "P"
            ElseIf DropDownName.Text = "ARV" Then
                alias_name = "V"
            ElseIf DropDownName.Text = "ARCU" Then
                alias_name = "Cu"
            ElseIf DropDownName.Text = "ARMGO" Then
                alias_name = "MgO"
            ElseIf DropDownName.Text = "ARALO" Then
                alias_name = "Al2O3"
            ElseIf DropDownName.Text = "ARSIO" Then
                alias_name = "SiO2"
            ElseIf DropDownName.Text = "ARCAO" Then
                alias_name = "CaO"
            ElseIf DropDownName.Text = "ARMNO" Then
                alias_name = "MnO"
            ElseIf DropDownName.Text = "ARFEO" Then
                alias_name = "Fe2O3"
            ElseIf DropDownName.Text = "ARCL" Then
                alias_name = "Chloride"
            ElseIf DropDownName.Text = "SHCR" Then
                alias_name = "Sheet Chromium"
            ElseIf DropDownName.Text = "WL" Then
                alias_name = "WL"
            ElseIf DropDownName.Text = "FE" Then
                alias_name = "FE"
            End If
            Return alias_name

        Catch ex As Exception

        End Try
    End Function

   
    Protected Sub ddlFilterColVal1_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlFilterColVal1.SelectedIndexChanged
        Try

            If ddlFilterCol2.SelectedItem.Text <> "Select" Then
                If objController.IsValidDateRange(txtFrom, txtTo) Then
                    objController.LoadColumnsData(ddlFilterColVal2, Session("TableName"), ddlFilterCol2.SelectedItem.Text, Session("DateColumn"), txtFrom.Text, txtTo.Text, ddlFilterColVal1.SelectedItem.Text)
                Else
                    UserMsgBoxError("Date range incorrect.")
                End If

            Else
                ddlFilterColVal2.DataSource = ""
                ddlFilterColVal2.DataBind()
            End If


            If ddlFilterCol3.SelectedItem.Text <> "Select" Then
                If objController.IsValidDateRange(txtFrom, txtTo) Then
                    objController.LoadColumnsData(ddlFilterColVal3, Session("TableName"), ddlFilterCol3.SelectedItem.Text, Session("DateColumn"), txtFrom.Text, txtTo.Text, ddlFilterColVal1.SelectedItem.Text)
                Else
                    UserMsgBoxError("Date range incorrect.")
                End If

            Else
                ddlFilterColVal3.DataSource = ""
                ddlFilterColVal3.DataBind()
            End If

        Catch ex As Exception

        End Try
    End Sub

    
    Protected Sub ddlFilterColVal4_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlFilterColVal4.SelectedIndexChanged
        Try

            If ddlFilterCol5.SelectedItem.Text <> "Select" Then
                If objController.IsValidDateRange(txtFrom, txtTo) Then
                    objController.LoadColumnsData(ddlFilterColVal5, Session("TableName"), ddlFilterCol5.SelectedItem.Text, Session("DateColumn"), txtFrom.Text, txtTo.Text, ddlFilterColVal4.SelectedItem.Text)
                Else
                    UserMsgBoxError("Date range incorrect.")
                End If

            Else
                ddlFilterColVal5.DataSource = ""
                ddlFilterColVal5.DataBind()
            End If

            If ddlFilterCol6.SelectedItem.Text <> "Select" Then
                If objController.IsValidDateRange(txtFrom, txtTo) Then
                    objController.LoadColumnsData(ddlFilterColVal6, Session("TableName"), ddlFilterCol6.SelectedItem.Text, Session("DateColumn"), txtFrom.Text, txtTo.Text, ddlFilterColVal4.SelectedItem.Text)
                Else
                    UserMsgBoxError("Date range incorrect.")
                End If

            Else
                ddlFilterColVal6.DataSource = ""
                ddlFilterColVal6.DataBind()
            End If

        Catch ex As Exception

        End Try
    End Sub
End Class